const fs = require('fs');
let content = fs.readFileSync('src/components/BrandPortalDashboard.tsx', 'utf8');

content = content.replace(
  /setNewTicketForm\(\{ subject: '', priority: 'Medium', description: '' \}\);/,
  "setNewTicketForm({ subject: '', priority: 'Medium', description: '' });\n    setShowAddTicketModal(false);"
);

fs.writeFileSync('src/components/BrandPortalDashboard.tsx', content);
