/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Role = 'director' | 'agentmgr' | 'agent' | 'agency' | 'brand' | 'creator' | 'contractor' | 'subagency' | 'coordinator' | 'none';

export interface Creator {
  id: string;
  handle: string;
  name: string;
  email?: string;
  platform: string;
  niche: string;
  followers: string;
  eng: string;
  agreement: string; // e.g. "Exclusive (80%)", "Non-Exclusive (70%)", "One-Time Project / Single Deal", "Flat Fee ($500 Agency Fee)", "Co-Representation (50%)", "Monthly Retainer", etc.
  agreementType?: 'Exclusive' | 'Non-Exclusive' | 'One-Time Deal' | 'Flat Fee' | 'Co-Representation' | 'Monthly Retainer' | 'Work-for-Hire' | 'Standby_Bench' | string;
  rosterType?: 'Exclusive' | 'Non-Exclusive' | 'One_Time_Contractor' | 'Standby_Contractor' | string;
  engagementType?: 'Roster' | 'Standby_Bench' | 'One_Time_Contractor' | string;
  exclusivityScope?: string; // e.g. "Full Commercial & UGC", "Niche Specific", "TikTok Only", "Brand Category Exclusive", "None / One-Off"
  contractStartDate?: string;
  contractEndDate?: string;
  contractId?: string;
  contractStatus?: 'Active' | 'Pending Signature' | 'Expiring' | 'Expired' | 'Draft';
  paymentMethod?: 'Agency Debit Card' | 'Direct Deposit' | 'PayPal' | 'Other' | string;
  paymentDetails?: string;
  paymentNote?: string;
  bankName?: string;
  routingNumber?: string;
  accountNumber?: string;
  accountType?: 'Checking' | 'Savings';
  stripeCardholderId?: string;
  stripeCardId?: string;
  stripeCardLast4?: string;
  stripeCardStatus?: 'Active' | 'Virtual Ready' | 'Physical Shipped' | 'Pending Setup' | string;
  stripeCardBrand?: string;
  stripeCardExpiry?: string;
  stripeCardType?: 'Virtual' | 'Physical' | 'Both' | string;
  status: 'Active' | 'Paused' | 'Offboarded' | 'Inactive' | 'Risk' | 'Pending Onboarding' | 'Pending Director Approval' | 'Needs Audit' | string;
  assignedAgent?: string;
  assignedManager?: string;
  assignedCoordinator?: string;
  coordinator?: string;
  dateSigned?: string;
  ytdEarnings?: number | string;
  monthlyRevenue?: number;
  w9Status?: string;
  bankAccount?: string;
  subagency?: string;
  agency?: string;
  w9Uploaded?: boolean;
  w9FileName?: string;
  w9FileSize?: string;
  w9FileUrl?: string;
  w9FileData?: string;
  taxIdStatus?: string;
  tax1099Uploaded?: boolean;
  tax1099FileName?: string;
  tax1099FileSize?: string;
  status1099?: string;
  totalEarned?: number;
  age?: string;
  phone?: string; // E.164 format e.g. +18005550199
  smsConsent?: boolean;
  smsConsentDate?: string;
  emailConsent?: boolean;
  emailConsentDate?: string;
  isDeleted?: boolean;
  deletedAt?: string;
  secondaryInterests?: string;
  tiktok?: string;
  instagram?: string;
  youtube?: string;
  bio?: string;
  location?: string;
  preferredBrands?: string;
  excludedBrands?: string;
  contentPreferences?: string;
  availability?: string;
  tier?: string;
  commissionSplit?: string;
  avatar?: string;
  skinTypeMatrix?: string;
  skinTone?: string;
  hairMatrix?: string;
  petBreedMetrics?: string;
  petAgeWeight?: string;
  petDietCategory?: string;
  aestheticMatrix?: string;
  lightingStyle?: string;
  colorStory?: string;
  ftcComplianceVerified?: boolean;
  copyrightClearanceActive?: boolean;
  galleryImages?: string[];
  matchOrPassActive?: boolean;
  matchOrPassPrimaryPhoto?: string;
  matchOrPassImages?: string[];
  matchOrPassTagline?: string;
  matchOrPassFeaturedNiche?: string;
  matchOrPassHighlights?: string[];
  matchCount?: number;
  passCount?: number;
  q1Availability?: 'Available' | 'Limited' | 'Booked';
  q2Availability?: 'Available' | 'Limited' | 'Booked';
  q3Availability?: 'Available' | 'Limited' | 'Booked';
  q4Availability?: 'Available' | 'Limited' | 'Booked';
  statusChangeDate?: string;
  statusChangeReason?: string;
  statusChangeAuthor?: string;
  statusHistory?: Array<{
    id: string;
    status: string;
    date: string;
    reason: string;
    changedBy: string;
    timestamp?: string;
  }>;
  rateCard?: {
    dedicatedVideo?: number;
    reel?: number;
    story?: number;
    photo?: number;
    usage30d?: number;
    usage90d?: number;
    usagePerpetual?: number;
  };
}

export interface Deal {
  id: string;
  brand: string;
  title?: string;
  creator: string;
  creatorHandle?: string;
  agent?: string;
  coordinator?: string;
  assignedCoordinator?: string;
  assignedManager?: string;
  assignedAgent?: string;
  budget: number;
  value?: number;
  amount?: number;
  type?: string;
  status?: string;
  platform: string;
  stage: 'Lead' | 'Pitched' | 'Negotiating' | 'Contracted' | 'Live' | 'Completed' | 'Paused — crisis hold' | string;
  due: string;
  dueDate?: string;
  deliverable?: string;
  payoutStatus?: string;
  notes?: string;
  invoiceGenerated?: boolean;
  subagency?: string;
  tenantId?: string;
  agency?: string;
  w9Uploaded?: boolean;
  w9FileName?: string;
  w9FileSize?: string;
  taxIdStatus?: string;
  tax1099Uploaded?: boolean;
  tax1099FileName?: string;
  tax1099FileSize?: string;
  status1099?: string;
  totalEarned?: number;
  split?: string;
  splitType?: 'Standard' | 'Exclusive' | 'Non-Exclusive' | 'One-Time' | 'Flat Fee' | 'Custom Flat Fee' | 'Custom %' | string;
  compensationModel?: 'standard' | 'custom_flat_fee' | 'custom_percentage' | 'flat_fee';
  flatFeeAmount?: number;
  flatFeeCadence?: 'per_deal' | 'per_deliverable' | 'monthly_retainer' | string;
  customAgencyCut?: number;
  dealPricingNotes?: string;
  creatorPayout?: number;
  agencyEarnings?: number;
  commissionRate?: number;
  agencyGrossCommission?: number;
  creatorNetPayout?: number;
  escrowStatus?: string;
  paymentStatus?: string;
  description?: string;
  isAcknowledged?: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: string;
  isDeleted?: boolean;
  deletedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface MissionChecklistItem {
  id: string;
  label: string;
  done: boolean;
  dueDate?: string;
  submissionUrl?: string;
}

export interface Mission {
  id: string;
  name: string;
  type: 'Campaign' | 'Challenge' | 'Event' | 'Promo' | 'Collab';
  brand: string;
  creator: string;
  brief: string;
  total: number;
  completed: number;
  status: 'On track' | 'Delayed' | 'Completed' | 'Dispatched' | 'Pending Acceptance' | 'Accepted (On track)' | 'Declined' | string;
  budget?: number;
  due?: string;
  deadline?: string;
  responseNote?: string;
  assignedAgent?: string;
  assignedAgentMgr?: string;
  submissionStatus?: 'Pending' | 'In Review' | 'Approved' | 'Changes Requested';
  checklists?: MissionChecklistItem[];
  isDeleted?: boolean;
  deletedAt?: string;
}

export interface Invoice {
  id: string;
  to?: string;
  brand?: string;
  brandName?: string;
  campaignName?: string;
  commitment?: string;
  subtitle?: string;
  terms?: string;
  forWork?: string;
  amount: number;
  amountDue?: number;
  due?: string;
  date?: string;
  status: 'Pending' | 'Paid' | 'Overdue' | 'Rejected' | 'Approved' | 'Draft' | 'Sent' | 'Cancelled';
  notes?: string;
  submittedBy?: string;
  rejectionReason?: string;
  subagency?: string;
  tenantId?: string;
  agencyName?: string;
  directorId?: string;
  directorName?: string;
  directorEmail?: string;
  isDeleted?: boolean;
  deletedAt?: string;
  updates?: any[];
}

export interface Agent {
  id: string;
  name: string;
  email?: string;
  role: string;
  pod?: string;
  headcount: number;
  volume?: number;
  score: number;
  split: string;
  status?: string;
  isSignedCreator?: boolean;
  signedCreatorHandle?: string;
  talentCommissionSplit?: string;
  creatorNiche?: string;
  agentAgreementId?: string;
  talentContractId?: string;
  inviteCode?: string;
  inviteLink?: string;
  createdAt?: string;
}

export interface ContractEmailDispatch {
  id: string;
  recipientEmail: string;
  recipientName: string;
  recipientRole: string; // 'Talent' | 'Brand Contact' | 'Legal Counsel' | 'Agent' | 'Agent Manager'
  subject: string;
  coverNote?: string;
  sentAt: string;
  sentBy: string;
  status: 'Delivered' | 'Opened' | 'Signed' | 'Pending';
  secureToken: string;
  accessPin?: string;
  expiresAt?: string;
}

export interface Contract {
  id: string;
  party?: string;
  partyEmail?: string;
  creatorId?: string;
  creatorHandle?: string;
  agentId?: string;
  agentName?: string;
  agentRole?: string;
  brandName?: string;
  brandEmail?: string;
  name?: string;
  title?: string;
  client?: string;
  partner?: string;
  type: string; // 'Exclusive Talent Representation' | 'Non-Exclusive Representation' | 'Agent Management & Commission Override Agreement' | 'Staff Talent Agent Operating Agreement' | 'One-Time Project / Single Deal' | 'Co-Representation Agreement' | 'Monthly Retainer & Ambassador' | 'Brand Sponsorship Agreement' | 'UGC Deliverables Agreement' | 'Non-Disclosure Agreement (NDA)' | 'Master Services Agreement (MSA)' | string;
  agreementCategory?: 'Talent Representation' | 'Agent Manager Agreement' | 'Agent Agreement' | 'Coordinator Agreement' | 'Brand Deal / UGC' | 'NDA / Confidentiality' | 'MSA / Agency' | 'One-Time Deal' | 'Flat Fee Deal' | 'Sub-Agency' | string;
  contractTargetRole?: 'creator' | 'agentmgr' | 'agent' | 'coordinator' | 'brand' | 'agency' | 'dual_creator_agent' | string;
  isAgentManagerContract?: boolean;
  isDualSignedContract?: boolean;
  exclusivityType?: 'Exclusive' | 'Non-Exclusive' | 'One-Time' | 'Flat Fee' | 'Co-Representation' | 'Retainer' | 'Commission Override' | 'Non-Applicable';
  exclusivityScope?: string; // e.g. "Full Commercial Representation", "Assigned Roster Deals & Escrow Oversight", "TikTok & IG Beverage Category Only"
  start?: string;
  end?: string;
  signedDate?: string;
  expiryDate?: string;
  terms?: string;
  value?: string | number;
  revenueSplit?: string; // e.g. "80% Creator / 20% Agency" or "15% Agent Commission Override"
  agentCommissionOverride?: string;
  baseSalaryOrRetainer?: string;
  status: 'Active' | 'Expired' | 'Pending' | 'Unsigned' | 'Expiring' | 'Draft' | 'Terminated' | 'Pending Signature' | string;
  autoRenew?: boolean;
  renewalNoticeDays?: number;
  governingLaw?: string;
  fullText?: string;
  fileAttachment?: {
    name: string;
    size?: string;
    type?: string;
    dataUrl?: string;
  };
  signatures?: {
    agencySigned?: boolean;
    agencySignedBy?: string;
    agencySignedDate?: string;
    talentSigned?: boolean;
    talentSignedBy?: string;
    talentSignedDate?: string;
    agentSigned?: boolean;
    agentSignedBy?: string;
    agentSignedDate?: string;
    brandSigned?: boolean;
    brandSignedBy?: string;
    brandSignedDate?: string;
  };
  securityHash?: string; // SHA-256 verification hash
  encryptionLevel?: string; // 'AES-256-GCM'
  accessTier?: 'director_only' | 'agent_and_talent' | 'all_parties' | 'agency_internal';
  dispatchedEmails?: ContractEmailDispatch[];
  notes?: string;
  subagency?: string;
  isDeleted?: boolean;
  deletedAt?: string;
}

export interface Bot {
  id: string;
  name: string;
  trigger: string;
  action: string;
  purpose: string;
  enabled: boolean;
  status: 'on' | 'off';
}

export interface TrashItem {
  id: string;
  type: 'creator' | 'deal' | 'mission' | 'invoice' | 'contract' | 'brand' | 'agency' | 'campaign' | 'lead' | 'exclusivity' | 'agent';
  name: string;
  deletedAt: string;
  originalCollection: string;
  originalData: any;
  subagency?: string;
  deletedBy?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  detail: string;
  type: 'info' | 'warning' | 'success' | 'danger';
  created: string;
  read: boolean;
}

export type Notification = AppNotification;

export interface Referral {
  id: string;
  referrer: string;
  referrerName?: string;
  type: 'Creator' | 'Brand' | 'Agency partner' | 'Direct outreach' | 'Other';
  what: string;
  newclient: string;
  referredCreatorName?: string;
  referredCreatorHandle?: string;
  value?: number;
  reward?: string;
  date: string;
  status: 'Pending review' | 'Approved' | 'Paid';
  notes?: string;
  subagency?: string;
  tenantId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Message {
  id: string;
  from: 'me' | 'other';
  senderName: string;
  senderRole?: string;
  text: string;
  time: string;
  attachment?: {
    name: string;
    data: string;
    type: string;
  };
}

export interface Thread {
  id: string;
  name: string; // The person we are talking with (or the handle)
  role: string; // e.g. Creator, Brand, Agent
  withWho?: string; // Optional nested identifier
  creator?: string;
  brand?: string;
  handle?: string;
  messages: Message[];
  participantIds?: string[];
}

export interface KBArticle {
  id: string;
  title: string;
  category: 'ftc' | 'pay' | 'deals' | 'contracts' | 'agency' | 'platform' | 'other';
  section: string;
  content: string;
  builtin?: boolean;
}

export interface TrainingGuide {
  id: string;
  title: string;
  role: string; // Target audience, e.g. 'Creator', 'Agent', 'Agent Manager', 'Sub-Agency', 'Brand', 'All'
  category: string;
  type: string; // e.g. 'Article', 'Video', 'PDF', 'Checklist'
  description: string;
  url?: string;
  embedVideoUrl?: string; // Simulated video URL or direct link
  builtin?: boolean;
  assignedRoles?: string[];
  dubbedTracks?: Record<string, string>;
}

export interface ActiveCampaign {
  id: string;
  brand: string;
  name: string;
  creators: string;
  deliverables: string;
  completed: number;
  total: number;
  deadline: string;
  value: number;
  status: 'On track' | 'At risk' | 'Delayed' | 'Completed';
  isDeleted?: boolean;
  deletedAt?: string;
}

export interface EscrowHold {
  id: string;
  brand: string;
  campaign: string;
  creator: string;
  amount: number;
  m1label?: string;
  m1pct?: number;
  m1released?: boolean;
  m2label?: string;
  m2pct?: number;
  m2released?: boolean;
  status: 'Held in escrow' | 'Released to creator' | 'Refunded to brand';
  isDeleted?: boolean;
  deletedAt?: string;
}

export interface TimestampedComment {
  timestamp: number;
  comment: string;
  author: string;
  createdAt: string;
}

export interface ReviewItem {
  id: string;
  creator: string;
  dealId: string;
  brand: string;
  platform: string;
  contentType: string;
  mediaUrl: string;
  captionDraft: string;
  submittedAt: string;
  status: 'Pending' | 'Approved' | 'Revision Requested' | 'Approved with Warning' | 'Posted' | 'Rejected' | 'Pending Agent Review' | 'Pending Agent Manager Review' | 'Pending Director Approval' | 'Pending Final Review';
  comments: string[];
  timestampedComments?: TimestampedComment[];
  subagency?: string;
  ftcFlagged?: boolean;
  ftcFlagReason?: string;
  ftcOverrideBy?: string;
  ftcOverrideAt?: string;
  ftcOverrideNote?: string;
  brandReviewStartedAt?: string;
  brandReviewTriggered12hWarning?: boolean;
  brandReviewStatus?: 'Active' | 'Feedback Received' | 'Auto Approved' | 'Warning Sent' | 'Approved';
  forwardedToReviewBy?: string;
  forwardedToReviewAt?: string;
  forwardedNotes?: string;
  finalApprovalBy?: string;
  finalApprovalAt?: string;
  assignedCoordinator?: string;
  denialFeedback?: string;
  denialFeedbackBy?: string;
  denialFeedbackAt?: string;
}

export interface RosterProfileSubmission {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  email?: string;
  phone?: string;
  platform?: string;
  niche: string;
  secondaryInterests?: string;
  bio?: string;
  tiktok?: string;
  instagram?: string;
  youtube?: string;
  preferredBrands?: string;
  excludedBrands?: string;
  contentPreferences?: string;
  availability?: string;
  q1Availability?: 'Available' | 'Limited' | 'Booked';
  q2Availability?: 'Available' | 'Limited' | 'Booked';
  q3Availability?: 'Available' | 'Limited' | 'Booked';
  q4Availability?: 'Available' | 'Limited' | 'Booked';
  paymentMethod?: string;
  paymentDetails?: string;
  cardholderLegalName?: string;
  stripeCardLast4?: string;
  stripeCardStatus?: string;
  stripeCardExpiry?: string;
  paymentNote?: string;
  tier?: string;
  assignedAgent?: string;
  assignedManager?: string;
  assignedCoordinator?: string;
  submittedAt: string;
  timestamp: number;
  status: 'Pending Review' | 'Director Approved' | 'Agent Assigned' | 'Synced to Roster' | 'Needs Revision';
  reviewedBy?: string;
  reviewDate?: string;
  notes?: string;
  targetAudience?: string;
  isDeleted?: boolean;
}

export interface HiringSettings {
  isHiringActive: boolean;
  showCareersOnLanding: boolean;
  openRoles: {
    talentAgent: boolean;
    agentManager: boolean;
    campaignCoordinator: boolean;
    operationsSpecialist: boolean;
    brandPartnerships: boolean;
    inboundSales: boolean;
  };
  customHiringNote?: string;
}

export interface BrandSwipeRecord {
  id: string;
  brandName: string;
  brandContactName?: string;
  brandContactEmail?: string;
  creatorId: string;
  creatorHandle: string;
  creatorName: string;
  creatorNumber: string;
  creatorNiche: string;
  creatorAvatar?: string;
  action: 'match' | 'pass';
  timestamp: number;
  dateStr: string;
  timeAgo?: string;
  proposedBudget?: number;
  platform?: string;
  deliverables?: string;
  notes?: string;
  dealCreated?: boolean;
  dealId?: string;
}

export interface JitExpenseRequest {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  itemCategory: 'Beauty Textures & Swatches' | 'Studio Lighting & Props' | 'Pet Accessories & Nutrition' | 'Wardrobe & Styling' | 'Camera & Rigging' | 'Location Rental' | 'Other Production Gear';
  itemTitle: string;
  requestedAmount: number;
  brandAssociation: string;
  campaignId?: string;
  justification: string;
  status: 'PENDING_APPROVAL' | 'APPROVED_UNLOCKED' | 'SWIPE_RECONCILED' | 'EXPIRED_LOCKED' | 'REJECTED';
  requestedAt: string;
  approvedAt?: string;
  windowExpiresAt?: string;
  unlockedLimit: number;
  currentBalance: number;
  receiptUrl?: string;
  receiptFileName?: string;
  receiptUploadedAt?: string;
  swipeMerchantName?: string;
  swipeAmount?: number;
  swipeTimestamp?: string;
  reconciliationAuditId?: string;
}

export interface AffiliateTrackingLink {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  brandName: string;
  campaignTitle: string;
  customUrl: string;
  discountCode: string;
  discountRate: string;
  commissionRateCreator: number; // e.g. 15%
  agencyBrandSplitAgencyPercent: number; // 80%
  agencyBrandSplitBrandPercent: number; // 20%
  tenantId?: string;
  status: 'active' | 'paused' | 'archived';
  totalClicks: number;
  totalConversions: number;
  grossSalesGenerated: number;
}

export interface AffiliateTransaction {
  id: string;
  orderId: string;
  storefront: 'Shopify' | 'TikTok Shop' | 'Amazon Storefront' | 'WooCommerce' | 'Stripe Checkout';
  timestamp: string;
  brandName: string;
  creatorId: string;
  creatorHandle: string;
  creatorName: string;
  discountCodeUsed: string;
  trackingLinkUrl: string;
  customerCity?: string;
  itemsCount: number;
  grossAmount: number;
  agencyGrossSplit: number; // 80% of agency commission pool
  brandGrossSplit: number;  // 20% of agency commission pool
  creatorCommissionAmount: number; // Isolated to creator private view
  tenantId: string;
  status: 'settled' | 'pending_escrow' | 'refunded';
}

export interface OfficialW9Record {
  id: string;
  userId: string;
  fullName: string;
  businessName?: string;
  taxClassification: 'Individual/sole proprietor' | 'C Corporation' | 'S Corporation' | 'Partnership' | 'Trust/estate' | 'LLC';
  llcTaxType?: 'C' | 'S' | 'P';
  exemptionsPayeeCode?: string;
  fatcaCode?: string;
  streetAddress: string;
  cityStateZip: string;
  taxIdType: 'SSN' | 'EIN';
  taxIdNumber: string; // masked for display
  certificationAgreed: boolean;
  signatureLegalName: string;
  signatureDate: string;
  signedPdfUrl?: string;
  signedPdfName?: string;
  uploadedAt: string;
  verifiedStatus: 'Verified & Tax Compliant' | 'Pending Review' | 'Needs Update' | 'Pending Director Check-Off' | 'Verified & Tax Compliant (Director Approved)';
  irsAuditHash: string;
}


