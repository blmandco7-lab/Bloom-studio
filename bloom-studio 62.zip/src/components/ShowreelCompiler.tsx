import React, { useState } from 'react';
import { getSafeUrl } from '../utils/security';
import { Video, Sparkles, Download, Play, Pause, Layers, Sliders, CheckCircle2, Film, RefreshCw } from 'lucide-react';

export interface UGCVideoClip {
  id: string;
  creatorHandle: string;
  campaignTitle: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  durationSeconds: number;
  videoUrl: string;
  previewThumbnail: string;
  metricHighlight: string;
}

interface ShowreelCompilerProps {
  initialClips?: UGCVideoClip[];
  onExportShowreel?: (renderedPayload: any) => Promise<void> | void;
}

/**
 * ShowreelCompiler:
 * Director dashboard workspace tool to automatically construct vertical 9:16 agency promotional showreels
 * from approved UGC creator assets with custom high-contrast metric overlays.
 */
export default function ShowreelCompiler({
  initialClips = [
    {
      id: "clip_1",
      creatorHandle: "@ava_glow",
      campaignTitle: "Summer Botanical Serum",
      niche: "Beauty",
      durationSeconds: 15,
      videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-woman-applying-skincare-lotion-on-her-face-41133-large.mp4",
      previewThumbnail: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&auto=format&fit=crop&q=80",
      metricHighlight: "+240% Engagement Shift"
    },
    {
      id: "clip_2",
      creatorHandle: "@paws_and_palette",
      campaignTitle: "Organic Pet Shampoo Launch",
      niche: "Pets",
      durationSeconds: 12,
      videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-dog-catching-a-ball-in-a-pool-42998-large.mp4",
      previewThumbnail: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=500&auto=format&fit=crop&q=80",
      metricHighlight: "840K Organic Views"
    },
    {
      id: "clip_3",
      creatorHandle: "@velvet_botanics",
      campaignTitle: "Aromatherapy Seeding",
      niche: "Lifestyle",
      durationSeconds: 10,
      videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-hands-holding-a-small-glass-bottle-of-perfume-41134-large.mp4",
      previewThumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80",
      metricHighlight: "100% FTC Clearance"
    }
  ],
  onExportShowreel
}: ShowreelCompilerProps) {
  const [clips, setClips] = useState<UGCVideoClip[]>(initialClips);
  const [selectedClipIndex, setSelectedClipIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [overlayText, setOverlayText] = useState("+240% Engagement Shift");
  const [secondaryOverlay, setSecondaryOverlay] = useState("Bloom Studio Whitelisted UGC");
  const [rendering, setRendering] = useState(false);
  const [renderComplete, setRenderComplete] = useState(false);

  const currentClip = clips[selectedClipIndex] || clips[0];

  const handleExport = async () => {
    setRendering(true);
    setRenderComplete(false);

    try {
      if (onExportShowreel) {
        await onExportShowreel({
          clipCount: clips.length,
          primaryOverlay: overlayText,
          secondaryOverlay: secondaryOverlay,
          aspectRatio: "9:16",
          renderedAt: new Date().toISOString()
        });
      }
      
      // Simulate Remotion/Creatomate webhook execution
      setTimeout(() => {
        setRendering(false);
        setRenderComplete(true);
      }, 2500);
    } catch (err) {
      console.error('Export failed:', err);
      setRendering(false);
    }
  };

  return (
    <div className="bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl text-agency-textLight space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Director Studio Tool
            </span>
            <span className="text-xs text-slate-400 font-mono">
              9:16 Social Showreel Compiler
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5">
            Agency UGC Showreel Engine
          </h2>
          <p className="text-xs text-slate-400">
            Stitch approved creator deliverables into vertical reels with branded dynamic reach &amp; engagement graphic overlays.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExport}
          disabled={rendering}
          className="inline-flex items-center gap-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg transition-all cursor-pointer disabled:opacity-50"
        >
          {rendering ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Rendering 9:16 MP4...</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Export Finished MP4 Showreel</span>
            </>
          )}
        </button>
      </div>

      {renderComplete && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs px-4 py-3 rounded-2xl flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Master 9:16 Showreel rendered successfully (1080x1920 @ 60fps)!</span>
          </div>
          <a
            href={getSafeUrl(currentClip.videoUrl)}
            download="bloom_studio_showreel_916.mp4"
            className="text-xs font-mono font-bold text-agency-gold hover:underline"
          >
            Download File
          </a>
        </div>
      )}

      {/* Main Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: 9:16 Canvas Stage */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2 block">
            Live 9:16 Vertical Preview
          </span>

          {/* Phone Canvas Container */}
          <div className="w-[280px] sm:w-[320px] aspect-[9/16] bg-black rounded-3xl overflow-hidden border-2 border-agency-gold/40 shadow-2xl relative flex items-center justify-center group">
            {/* Background Simulated Video / Image */}
            <img
              src={currentClip.previewThumbnail}
              alt={`Video preview for ${currentClip.creatorHandle}'s ${currentClip.campaignTitle} campaign`}
              className="w-full h-full object-cover"
            />

            {/* Dark Vignette Gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 pointer-events-none" />

            {/* Top Creator Tag */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
              <span className="bg-black/80 backdrop-blur-md border border-agency-gold/40 text-agency-gold font-mono text-[10px] font-bold px-2.5 py-1 rounded-full">
                {currentClip.creatorHandle}
              </span>
              <span className="bg-black/80 backdrop-blur-md text-white font-mono text-[10px] px-2 py-1 rounded-full">
                {currentClip.niche}
              </span>
            </div>

            {/* Dynamic Graphic Overlay (Deep black background with gold border) */}
            <div className="absolute bottom-6 left-4 right-4 space-y-2 pointer-events-none">
              <div className="bg-black/90 backdrop-blur-md border-2 border-agency-gold rounded-2xl p-3.5 shadow-2xl space-y-1">
                <span className="text-[9px] uppercase font-mono font-bold tracking-widest text-agency-gold block">
                  {secondaryOverlay}
                </span>
                <p className="text-base font-bold font-serif text-white leading-tight">
                  {overlayText}
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded">
                    Verified ROI
                  </span>
                  <span className="text-[9px] font-mono text-slate-400">
                    Bloom Studio Whitelisted
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Clip Sequence & Overlay Config */}
        <div className="lg:col-span-7 space-y-6">
          {/* Graphic Overlay Controls */}
          <div className="bg-agency-navy border border-white/10 rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-mono uppercase font-bold text-agency-gold tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4" /> Dynamic Overlay Customizer
            </h3>

            <div className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Primary Metric Callout Text</label>
                <input
                  type="text"
                  value={overlayText}
                  onChange={e => setOverlayText(e.target.value)}
                  className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl px-3 py-2 text-white font-mono outline-none"
                  placeholder="+240% Engagement Shift"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Secondary Subtitle</label>
                <input
                  type="text"
                  value={secondaryOverlay}
                  onChange={e => setSecondaryOverlay(e.target.value)}
                  className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl px-3 py-2 text-white font-mono outline-none"
                  placeholder="Bloom Studio Whitelisted UGC"
                />
              </div>
            </div>
          </div>

          {/* Sequence Clip Selector */}
          <div className="bg-agency-navy border border-white/10 rounded-2xl p-5 space-y-4">
            <h3 className="text-xs font-mono uppercase font-bold text-white tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-agency-gold" /> Active UGC Deliverable Sequence
            </h3>

            <div className="space-y-2.5">
              {clips.map((clip, idx) => (
                <button
                  type="button"
                  key={clip.id}
                  onClick={() => {
                    setSelectedClipIndex(idx);
                    setOverlayText(clip.metricHighlight);
                  }}
                  className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                    selectedClipIndex === idx
                      ? 'bg-agency-navyLight border-agency-gold ring-1 ring-agency-gold/40'
                      : 'bg-agency-navy hover:bg-agency-navyLight border-white/5'
                  }`}
                  aria-pressed={selectedClipIndex === idx}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={clip.previewThumbnail}
                      alt={`Thumbnail for ${clip.creatorHandle} clip`}
                      className="w-12 h-12 rounded-lg object-cover border border-white/10"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-xs">{clip.creatorHandle}</span>
                        <span className="text-[10px] font-mono text-agency-gold bg-agency-navy px-1.5 py-0.5 rounded">
                          {clip.niche}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">{clip.campaignTitle}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-mono font-bold text-emerald-400 block">
                      {clip.metricHighlight}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      {clip.durationSeconds}s cut
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
