import React from 'react';
import { Video, ExternalLink, ShieldCheck, AlertTriangle, Instagram, Sparkles, CheckCircle2, Clock } from 'lucide-react';
import { UserProfile } from './RoleGuardedCampaignWorkspace';
import { getSafeUrl } from '../utils/security';

export interface MilestoneAlertItem {
  id: string;
  creatorHandle: string;
  platform: 'Instagram' | 'TikTok';
  campaignName: string;
  headline: string;
  liveUrl: string;
  timestamp: string;
  ftcStatus: 'Verified Safe' | 'Pending Scan' | 'Flagged';
  manualPayout: number; // Only visible if user.role === 'Owner'
}

interface LiveMilestoneAlertsProps {
  user: UserProfile;
  alerts?: MilestoneAlertItem[];
}

/**
 * LiveMilestoneAlerts:
 * Administrative monitoring panel for active UGC deliverables on social media.
 * Accessible to both Owner & Manager for content reviews & FTC verification.
 * 
 * PERSONAL FINANCIAL HIGHLIGHT (OWNER ONLY):
 * Appends a gold text badge showing the creator's manual payout ($)
 * strictly when user.role === 'Owner', keeping it completely unrendered for Managers.
 */
export default function LiveMilestoneAlerts({
  user,
  alerts = [
    {
      id: "alert_1",
      creatorHandle: "@ava",
      platform: "TikTok",
      campaignName: "GlowLab Rose Quartz Skincare",
      headline: "ALERT: @ava has posted their Live UGC Video Link",
      liveUrl: "https://tiktok.com/@ava/video/739281920",
      timestamp: "12m ago",
      ftcStatus: "Verified Safe",
      manualPayout: 6200.00
    },
    {
      id: "alert_2",
      creatorHandle: "@paws_and_palette",
      platform: "Instagram",
      campaignName: "BarkHydrate Eco Travel Push",
      headline: "ALERT: @paws_and_palette published Story Reel with Trackable Link",
      liveUrl: "https://instagram.com/stories/paws_and_palette",
      timestamp: "45m ago",
      ftcStatus: "Pending Scan",
      manualPayout: 5000.00
    },
    {
      id: "alert_3",
      creatorHandle: "@velvet_botanics",
      platform: "Instagram",
      campaignName: "Velvet Home Aromatherapy",
      headline: "ALERT: @velvet_botanics published Feed Carousel with #ad disclosure",
      liveUrl: "https://instagram.com/p/C99281729",
      timestamp: "2h ago",
      ftcStatus: "Verified Safe",
      manualPayout: 4200.00
    }
  ]
}: LiveMilestoneAlertsProps) {
  const isOwner = user.role === 'Owner';

  const formatUSD = (val: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  return (
    <div className="bg-agency-navy border border-agency-gold/30 rounded-3xl p-6 shadow-2xl text-agency-textLight space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navyLight border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Live Milestone Monitoring
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Live Deliverables Stream
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white mt-1.5">
            Active UGC Social Publications
          </h2>
          <p className="text-xs text-slate-400">
            Real-time feed monitoring live posts, compliance disclosures, and direct review links.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-300 bg-agency-navyLight border border-white/10 px-3.5 py-1.5 rounded-xl">
          <Clock className="w-3.5 h-3.5 text-agency-gold animate-spin" />
          <span>Listening for Live Links</span>
        </div>
      </div>

      {/* Active Alert Stream */}
      <div className="space-y-3">
        {alerts.map((alert) => {
          const isVerified = alert.ftcStatus === 'Verified Safe';

          return (
            <div
              key={alert.id}
              className="bg-agency-navyLight border border-white/10 hover:border-agency-gold/40 transition-all rounded-2xl p-4.5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md"
            >
              {/* Creator, Platform & Headline */}
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-agency-navy border border-white/10 flex items-center justify-center text-agency-gold">
                  {alert.platform === 'Instagram' ? (
                    <Instagram className="w-5 h-5" />
                  ) : (
                    <Video className="w-5 h-5" />
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold text-white font-mono">{alert.creatorHandle}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-agency-navy border border-white/10 text-slate-300">
                      {alert.platform}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{alert.timestamp}</span>

                    {/* OWNER-ONLY PERSONAL FINANCIAL HIGHLIGHT */}
                    {isOwner && (
                      <span className="text-[11px] font-mono font-bold text-agency-gold bg-agency-navy border border-agency-gold/30 px-2 py-0.5 rounded-md">
                        Payout: {formatUSD(alert.manualPayout)}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-200 font-sans font-medium">
                    {alert.headline}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Campaign: <strong className="text-white">{alert.campaignName}</strong>
                  </p>
                </div>
              </div>

              {/* Action Buttons & FTC Status Badge */}
              <div className="flex flex-wrap items-center gap-2.5">
                {/* FTC Compliance Badge */}
                <span
                  className={`text-[11px] font-mono px-3 py-1 rounded-full border flex items-center gap-1.5 ${
                    isVerified
                      ? 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30'
                      : 'bg-amber-950/60 text-amber-400 border-amber-500/30'
                  }`}
                >
                  {isVerified ? (
                    <ShieldCheck className="w-3.5 h-3.5" />
                  ) : (
                    <AlertTriangle className="w-3.5 h-3.5" />
                  )}
                  <span>FTC: {alert.ftcStatus}</span>
                </span>

                {/* Review Live Content Button */}
                <a
                  href={getSafeUrl(alert.liveUrl)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 bg-agency-navy hover:bg-agency-navy/80 text-agency-gold border border-agency-gold/30 hover:border-agency-gold px-3.5 py-1.5 rounded-xl text-xs font-mono font-semibold transition-all shadow-sm"
                >
                  <span>Review Live Content</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
