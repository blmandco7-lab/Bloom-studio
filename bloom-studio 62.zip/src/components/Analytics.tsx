import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, TrendingDown, Users, DollarSign, Award, Target, 
  Landmark, ChevronDown, CheckCircle2, RefreshCw, Lock, BarChart3, 
  Layers, Sparkles, Download, Filter, Calendar, ArrowUpRight, 
  ArrowDownRight, Search, PieChart, Eye, FileText, Sliders, 
  Zap, Globe, Activity, Clock, ShieldCheck, X, ChevronRight,
  Share2, PlayCircle, MessageSquare, ThumbsUp, HeartHandshake, ShieldAlert, AlertTriangle
} from 'lucide-react';
import { Creator, Deal } from '../types';
import { formatCsvRow, sanitizeCsvCell } from '../utils/security';

interface AnalyticsProps {
  creators?: Creator[];
  deals?: Deal[];
  invoices?: any[];
  contracts?: any[];
  currentRole?: string;
  currentUser?: any;
  primaryBrandColor?: string;
  onAddActivityLog?: (actorName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger' | 'error') => void;
}

type TimeframeOption = '7d' | '30d' | '90d' | 'ytd' | 'all';
type AnalyticsTab = 'overview' | 'creators' | 'campaigns' | 'benchmarks' | 'forecasting' | 'retention';
type MetricViewMode = 'revenue' | 'margin' | 'volume';

export default function Analytics({
  creators = [],
  deals = [],
  invoices = [],
  contracts = [],
  currentRole = 'director',
  currentUser,
  primaryBrandColor = '#C9A46A',
  onAddActivityLog,
  triggerNotification
}: AnalyticsProps) {
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const isAgent = (currentRole || '').toLowerCase() === 'agent';
  const isBrand = (currentRole || '').toLowerCase() === 'brand';
  const isRestrictedRole = isAgentMgr || isAgent || isBrand;
  const mgrName = currentUser?.name || 'Agent Workspace';
  const brandName = currentUser?.name || '';

  // State controls
  const [activeTab, setActiveTab] = useState<AnalyticsTab>('overview');
  const [timeframe, setTimeframe] = useState<TimeframeOption>('90d');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');
  const [selectedNiche, setSelectedNiche] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [metricViewMode, setMetricViewMode] = useState<MetricViewMode>('revenue');
  const [hoveredBarIndex, setHoveredBarIndex] = useState<number | null>(null);
  const [selectedCreatorModal, setSelectedCreatorModal] = useState<any | null>(null);
  const [revenueTarget, setRevenueTarget] = useState<number>(250000);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Role scoping: filter creators and deals if role is restricted
  const scopedCreators = useMemo(() => {
    if (!isRestrictedRole) return creators;
    if (isBrand) {
      const brandDeals = deals.filter(d => (d.brand || '').toLowerCase() === brandName.toLowerCase());
      const creatorHandles = brandDeals.map(d => (d.creator || '').toLowerCase());
      return creators.filter(c => creatorHandles.includes(c.handle.toLowerCase()) || creatorHandles.includes((c.name || '').toLowerCase()));
    }
    return creators.filter(c => 
      (c.assignedAgent && c.assignedAgent.toLowerCase() === mgrName.toLowerCase()) ||
      c.handle.toLowerCase() === (currentUser?.handle || '').toLowerCase()
    );
  }, [creators, isRestrictedRole, isBrand, brandName, mgrName, currentUser, deals]);

  const scopedDeals = useMemo(() => {
    if (!isRestrictedRole) return deals;
    if (isBrand) {
      return deals.filter(d => (d.brand || '').toLowerCase() === brandName.toLowerCase());
    }
    const allowedHandles = scopedCreators.map(c => c.handle.toLowerCase());
    const allowedNames = scopedCreators.map(c => c.name.toLowerCase());
    return deals.filter(d => 
      (d.agent && d.agent.toLowerCase() === mgrName.toLowerCase()) ||
      (d.creator && (allowedNames.includes(d.creator.toLowerCase()) || allowedHandles.includes(d.creator.toLowerCase())))
    );
  }, [deals, isRestrictedRole, isBrand, brandName, mgrName, scopedCreators]);

  // Apply filters (Platform, Niche, Search)
  const filteredDeals = useMemo(() => {
    return scopedDeals.filter(d => {
      // Platform filter
      if (selectedPlatform !== 'all') {
        const plat = (d.platform || '').toLowerCase();
        if (selectedPlatform === 'TikTok' && !plat.includes('tik')) return false;
        if (selectedPlatform === 'Instagram' && !plat.includes('insta')) return false;
        if (selectedPlatform === 'YouTube' && !plat.includes('you')) return false;
        if (selectedPlatform === 'Twitch' && !plat.includes('twi')) return false;
        if (selectedPlatform === 'Direct' && (plat.includes('tik') || plat.includes('insta') || plat.includes('you') || plat.includes('twi'))) return false;
      }
      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const brandMatch = (d.brand || '').toLowerCase().includes(q);
        const creatorMatch = (d.creator || '').toLowerCase().includes(q);
        const titleMatch = (d.title || '').toLowerCase().includes(q);
        if (!brandMatch && !creatorMatch && !titleMatch) return false;
      }
      return true;
    });
  }, [scopedDeals, selectedPlatform, searchQuery]);

  const filteredCreators = useMemo(() => {
    return scopedCreators.filter(c => {
      // Niche filter
      if (selectedNiche !== 'all') {
        if ((c.niche || '').toLowerCase() !== selectedNiche.toLowerCase()) return false;
      }
      // Platform filter
      if (selectedPlatform !== 'all') {
        const plat = (c.platform || '').toLowerCase();
        if (selectedPlatform === 'TikTok' && !plat.includes('tik')) return false;
        if (selectedPlatform === 'Instagram' && !plat.includes('insta')) return false;
        if (selectedPlatform === 'YouTube' && !plat.includes('you')) return false;
        if (selectedPlatform === 'Twitch' && !plat.includes('twi')) return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const nameMatch = (c.name || '').toLowerCase().includes(q);
        const handleMatch = (c.handle || '').toLowerCase().includes(q);
        const nicheMatch = (c.niche || '').toLowerCase().includes(q);
        if (!nameMatch && !handleMatch && !nicheMatch) return false;
      }
      return true;
    });
  }, [scopedCreators, selectedNiche, selectedPlatform, searchQuery]);

  // Aggregate Metrics Calculations
  const metrics = useMemo(() => {
    // 1. Gross Deal Value
    const totalGrossRevenue = filteredDeals.reduce((sum, d) => {
      const val = Number(d.budget || d.value || 0);
      return sum + val;
    }, 0);

    // 2. Agency Margin (20% default or deal specific)
    const agencyMargin = Math.round(totalGrossRevenue * 0.20);
    const talentPayouts = totalGrossRevenue - agencyMargin;

    // 3. Completed Deals & Deliverables
    const completedDeals = filteredDeals.filter(d => (d.stage || '').toLowerCase() === 'completed');
    const liveDeals = filteredDeals.filter(d => (d.stage || '').toLowerCase() === 'live');
    const negotiatingDeals = filteredDeals.filter(d => 
      ['negotiating', 'contracted', 'pitched', 'lead'].includes((d.stage || '').toLowerCase())
    );

    const completedValue = completedDeals.reduce((s, d) => s + Number(d.budget || d.value || 0), 0);
    const liveEscrowValue = liveDeals.reduce((s, d) => s + Number(d.budget || d.value || 0), 0);
    const pipelineValue = negotiatingDeals.reduce((s, d) => s + Number(d.budget || d.value || 0), 0);

    const completionRate = filteredDeals.length > 0 
      ? Math.round((completedDeals.length / filteredDeals.length) * 100) 
      : 100;

    // 4. Total Verified Roster Reach (Followers/Subscribers)
    const totalReachNumber = filteredCreators.reduce((sum, c) => {
      const raw = String(c.followers || '0').replace(/[^0-9.]/g, '');
      const num = parseFloat(raw) || 0;
      const mult = String(c.followers || '').toUpperCase().includes('M') ? 1000000 
                 : String(c.followers || '').toUpperCase().includes('K') ? 1000 : 1;
      return sum + (num * mult);
    }, 0);

    const formattedReach = totalReachNumber >= 1000000 
      ? `${(totalReachNumber / 1000000).toFixed(1)}M` 
      : totalReachNumber >= 1000 
      ? `${Math.round(totalReachNumber / 1000)}K` 
      : `${totalReachNumber}`;

    // 5. Blended Engagement Rate
    let totalWeightedEng = 0;
    let totalEngWeight = 0;
    filteredCreators.forEach(c => {
      const rawEng = parseFloat(String(c.eng || '4.2').replace(/[^0-9.]/g, '')) || 4.2;
      const raw = String(c.followers || '0').replace(/[^0-9.]/g, '');
      const num = parseFloat(raw) || 10000;
      const mult = String(c.followers || '').toUpperCase().includes('M') ? 1000000 
                 : String(c.followers || '').toUpperCase().includes('K') ? 1000 : 1;
      const weight = num * mult;
      totalWeightedEng += rawEng * weight;
      totalEngWeight += weight;
    });
    const blendedEngRate = totalEngWeight > 0 
      ? (totalWeightedEng / totalEngWeight).toFixed(2) 
      : '4.50';

    // 6. Average Deal Size
    const avgDealSize = filteredDeals.length > 0 
      ? Math.round(totalGrossRevenue / filteredDeals.length) 
      : 0;

    // 7. Estimated Impressions & CPM
    // Est. impressions based on average view-to-follower ratio (~18% on short form)
    const estimatedImpressions = Math.round(totalReachNumber * 0.22 * Math.max(1, filteredDeals.length));
    const effectiveCPM = estimatedImpressions > 0 && totalGrossRevenue > 0
      ? ((totalGrossRevenue / estimatedImpressions) * 1000).toFixed(2)
      : '9.40';

    return {
      totalGrossRevenue,
      agencyMargin,
      talentPayouts,
      completedValue,
      liveEscrowValue,
      pipelineValue,
      dealCount: filteredDeals.length,
      completedCount: completedDeals.length,
      liveCount: liveDeals.length,
      negotiatingCount: negotiatingDeals.length,
      completionRate,
      totalReachNumber,
      formattedReach,
      blendedEngRate,
      avgDealSize,
      estimatedImpressions,
      effectiveCPM
    };
  }, [filteredDeals, filteredCreators]);

  // Monthly Aggregated Data for Dynamic Chart
  const monthlyTimelineData = useMemo(() => {
    const months = [
      { label: 'Feb 2026', short: 'Feb', target: 28000 },
      { label: 'Mar 2026', short: 'Mar', target: 35000 },
      { label: 'Apr 2026', short: 'Apr', target: 45000 },
      { label: 'May 2026', short: 'May', target: 55000 },
      { label: 'Jun 2026', short: 'Jun', target: 68000 },
      { label: 'Jul 2026', short: 'Jul', target: 80000 },
      { label: 'Aug 2026', short: 'Aug', target: 95000 }
    ];

    // Compute actual deals by month or distribute gracefully
    const totalRev = metrics.totalGrossRevenue;
    const hasEnoughDeals = filteredDeals.length >= 3;

    return months.map((m, idx) => {
      // Realistic growth curve applied to actual total
      const weight = [0.08, 0.11, 0.13, 0.16, 0.18, 0.20, 0.14][idx];
      const monthGross = hasEnoughDeals && totalRev > 10000
        ? Math.round(totalRev * weight)
        : Math.round(m.target * (0.9 + (idx * 0.05)));
      
      const monthMargin = Math.round(monthGross * 0.20);
      const monthTalent = monthGross - monthMargin;
      const monthDeals = Math.max(1, Math.round(monthGross / Math.max(3000, metrics.avgDealSize || 5000)));

      return {
        month: m.label,
        short: m.short,
        gross: monthGross,
        margin: monthMargin,
        talent: monthTalent,
        dealsCount: monthDeals,
        cpm: (8.5 + (idx * 0.4)).toFixed(2)
      };
    });
  }, [metrics, filteredDeals]);

  // Platform Breakdown Calculations
  const platformBreakdown = useMemo(() => {
    const plats: Record<string, { label: string; gross: number; dealsCount: number; color: string; bg: string; icon: string }> = {
      'TikTok': { label: 'TikTok', gross: 0, dealsCount: 0, color: '#00F2FE', bg: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20', icon: '🎵' },
      'Instagram': { label: 'Instagram', gross: 0, dealsCount: 0, color: '#E1306C', bg: 'bg-pink-500/10 text-pink-400 border-pink-500/20', icon: '📸' },
      'YouTube': { label: 'YouTube', gross: 0, dealsCount: 0, color: '#FF0033', bg: 'bg-rose-500/10 text-rose-400 border-rose-500/20', icon: '▶️' },
      'Twitch': { label: 'Twitch', gross: 0, dealsCount: 0, color: '#9146FF', bg: 'bg-purple-500/10 text-purple-400 border-purple-500/20', icon: '🎮' },
      'Direct / UGC': { label: 'Direct / UGC', gross: 0, dealsCount: 0, color: '#C9A46A', bg: 'bg-amber-500/10 text-amber-300 border-amber-500/20', icon: '💼' }
    };

    filteredDeals.forEach(d => {
      const plat = (d.platform || '').toLowerCase();
      const val = Number(d.budget || d.value || 0);
      if (plat.includes('tik')) {
        plats['TikTok'].gross += val;
        plats['TikTok'].dealsCount += 1;
      } else if (plat.includes('insta')) {
        plats['Instagram'].gross += val;
        plats['Instagram'].dealsCount += 1;
      } else if (plat.includes('you')) {
        plats['YouTube'].gross += val;
        plats['YouTube'].dealsCount += 1;
      } else if (plat.includes('twi')) {
        plats['Twitch'].gross += val;
        plats['Twitch'].dealsCount += 1;
      } else {
        plats['Direct / UGC'].gross += val;
        plats['Direct / UGC'].dealsCount += 1;
      }
    });

    // Fallback baseline distribution if filtered deals are 0 or sparse
    const sumGross = Object.values(plats).reduce((a, b) => a + b.gross, 0);
    if (sumGross === 0 && metrics.totalGrossRevenue > 0) {
      const base = metrics.totalGrossRevenue;
      plats['TikTok'].gross = Math.round(base * 0.42);
      plats['TikTok'].dealsCount = Math.max(2, Math.round(filteredDeals.length * 0.4));
      plats['Instagram'].gross = Math.round(base * 0.28);
      plats['Instagram'].dealsCount = Math.max(1, Math.round(filteredDeals.length * 0.3));
      plats['YouTube'].gross = Math.round(base * 0.18);
      plats['YouTube'].dealsCount = Math.max(1, Math.round(filteredDeals.length * 0.2));
      plats['Twitch'].gross = Math.round(base * 0.08);
      plats['Twitch'].dealsCount = 1;
      plats['Direct / UGC'].gross = Math.round(base * 0.04);
      plats['Direct / UGC'].dealsCount = 1;
    }

    const total = Object.values(plats).reduce((a, b) => a + b.gross, 0) || 1;
    return Object.values(plats).map(p => ({
      ...p,
      percentage: Math.round((p.gross / total) * 100)
    }));
  }, [filteredDeals, metrics.totalGrossRevenue]);

  // Creator Leaderboard Computed Table
  const creatorLeaderboard = useMemo(() => {
    return filteredCreators.map(c => {
      const creatorDeals = filteredDeals.filter(d => 
        (d.creator && d.creator.toLowerCase() === (c.name || '').toLowerCase()) ||
        (d.creator && d.creator.toLowerCase() === (c.handle || '').toLowerCase()) ||
        (d.creatorHandle && d.creatorHandle.toLowerCase() === (c.handle || '').toLowerCase())
      );

      const grossRevenue = creatorDeals.reduce((sum, d) => sum + Number(d.budget || d.value || 0), 0);
      const commission = Math.round(grossRevenue * 0.20);
      const talentEarnings = grossRevenue - commission;

      const completedCount = creatorDeals.filter(d => (d.stage || '').toLowerCase() === 'completed').length;
      const activeCount = creatorDeals.filter(d => ['live', 'negotiating', 'contracted'].includes((d.stage || '').toLowerCase())).length;

      // Extract raw follower number
      const rawFollowers = String(c.followers || '0').replace(/[^0-9.]/g, '');
      const num = parseFloat(rawFollowers) || 0;
      const mult = String(c.followers || '').toUpperCase().includes('M') ? 1000000 
                 : String(c.followers || '').toUpperCase().includes('K') ? 1000 : 1;
      const reachScore = num * mult;

      // Engagement parse
      const engValue = parseFloat(String(c.eng || '4.5').replace(/[^0-9.]/g, '')) || 4.5;
      
      // On-time score calculation (simulated realistic agency metric 90-100%)
      const onTimeScore = Math.min(100, Math.max(88, 95 + (completedCount % 5)));

      return {
        id: c.id,
        name: c.name,
        handle: c.handle,
        platform: c.platform || 'TikTok',
        niche: c.niche || 'Lifestyle',
        followers: c.followers || '100K',
        reachScore,
        eng: c.eng || '4.5%',
        engValue,
        tier: c.tier || (reachScore >= 1000000 ? 'Mega Talent' : reachScore >= 250000 ? 'Macro' : 'Mid-Tier'),
        dealsCount: creatorDeals.length,
        completedCount,
        activeCount,
        grossRevenue,
        commission,
        talentEarnings,
        onTimeScore,
        assignedAgent: c.assignedAgent || 'Unassigned',
        agreement: c.agreement || 'Exclusive (80%)',
        deals: creatorDeals
      };
    }).sort((a, b) => b.grossRevenue - a.grossRevenue || b.reachScore - a.reachScore);
  }, [filteredCreators, filteredDeals]);

  // Export CSV Handler
  const handleExportCSV = () => {
    const headers = ['Rank', 'Creator Name', 'Handle', 'Platform', 'Niche', 'Followers', 'Eng Rate', 'Total Deals', 'Gross Revenue (USD)', 'Agency Margin (20%)', 'Talent Payout (80%)', 'On-Time Delivery %'];
    const rows = creatorLeaderboard.map((item, idx) => formatCsvRow([
      idx + 1,
      item.name,
      item.handle,
      item.platform,
      item.niche,
      item.followers,
      item.eng,
      item.dealsCount,
      item.grossRevenue,
      item.commission,
      item.talentEarnings,
      `${item.onTimeScore}%`
    ]));

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.map(sanitizeCsvCell).join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bloom_studio_analytics_report_${timeframe}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    triggerNotification?.('Report Exported', 'Analytics CSV downloaded successfully.', 'success');
    onAddActivityLog?.(currentUser?.name || 'User', currentRole || 'none', `Exported full agency analytics report (${timeframe}) to CSV`);
  };

  // Export JSON Handler
  const handleExportJSON = () => {
    const exportData = {
      generatedAt: new Date().toISOString(),
      timeframe,
      filters: { platform: selectedPlatform, niche: selectedNiche },
      metrics,
      platformBreakdown,
      monthlyTimeline: monthlyTimelineData,
      creators: creatorLeaderboard
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', dataStr);
    link.setAttribute('download', `bloom_analytics_${timeframe}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    triggerNotification?.('JSON Exported', 'Analytics JSON summary exported successfully.', 'success');
  };

  // Live Refresh simulation
  const handleLiveRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      triggerNotification?.('Analytics Refreshed', 'Synced latest deal pipeline and roster metrics from database.', 'info');
      onAddActivityLog?.(currentUser?.name || 'User', currentRole || 'none', 'Triggered live agency analytics recalculation');
    }, 600);
  };

  // Calculation for SVG dynamic chart coordinates
  const maxChartValue = useMemo(() => {
    if (metricViewMode === 'revenue') {
      const maxVal = Math.max(...monthlyTimelineData.map(m => m.gross), 10000);
      return Math.ceil(maxVal / 10000) * 10000;
    } else if (metricViewMode === 'margin') {
      const maxVal = Math.max(...monthlyTimelineData.map(m => m.margin), 5000);
      return Math.ceil(maxVal / 5000) * 5000;
    } else {
      const maxVal = Math.max(...monthlyTimelineData.map(m => m.dealsCount), 10);
      return Math.ceil(maxVal / 5) * 5;
    }
  }, [monthlyTimelineData, metricViewMode]);

  if (isBrand) {
    return (
      <div className="space-y-6 max-w-full">
        {/* Brand Header */}
        <div className="relative bg-[#0D1830] border border-blue-950 rounded-2xl p-6 shadow-xl overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-radial-gradient(circle,rgba(201,164,106,0.08)_0%,transparent_70%) pointer-events-none" />
          <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold tracking-widest uppercase px-2.5 py-0.5 rounded-full bg-[#16243F] text-[#C9A46A] border border-[#C9A46A]/30 flex items-center gap-1.5">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Verified Client Account
                </span>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">
                  {brandName} • Campaign Intelligence
                </span>
              </div>
              <h1 className="font-serif font-bold text-2xl sm:text-3xl text-white tracking-tight">
                Brand Impact &amp; Campaign Performance
              </h1>
              <p className="text-xs text-[#7C8AA8] max-w-2xl leading-relaxed">
                Aggregated performance metrics from your active and completed campaigns with Bloom Studio. 
                Values represent your total media investment and verified audience engagement.
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <button
                onClick={handleLiveRefresh}
                disabled={isRefreshing}
                className="bg-[#16243F] hover:bg-[#1C2E52] border border-white/10 text-slate-200 px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-[#C9A46A] ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>{isRefreshing ? 'Syncing...' : 'Sync Data'}</span>
              </button>
              <button
                onClick={handleExportCSV}
                className="bg-[#C9A46A] hover:bg-[#D4B27D] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-md"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Report</span>
              </button>
            </div>
          </div>
        </div>

        {/* Brand KPI Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#0D1830] border border-white/5 p-5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 uppercase tracking-widest">
              <span>Active Campaigns</span>
              <Layers className="w-3.5 h-3.5 text-[#C9A46A]" />
            </div>
            <div className="text-2xl font-bold text-white font-mono">
              {metrics.dealCount}
            </div>
            <div className="text-[10px] text-emerald-400 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> Tracked in Real-time
            </div>
          </div>

          <div className="bg-[#0D1830] border border-white/5 p-5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 uppercase tracking-widest">
              <span>Audience Reach</span>
              <Users className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold text-white font-mono">
              {metrics.formattedReach}
            </div>
            <div className="text-[10px] text-cyan-400 flex items-center gap-1">
              <Eye className="w-3 h-3" /> Estimated Impressions
            </div>
          </div>

          <div className="bg-[#0D1830] border border-white/5 p-5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 uppercase tracking-widest">
              <span>Engagement Rate</span>
              <Target className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <div className="text-2xl font-bold text-emerald-400 font-mono">
              {metrics.blendedEngRate}%
            </div>
            <div className="text-[10px] text-slate-400 flex items-center gap-1">
              <Activity className="w-3 h-3" /> Campaign Performance
            </div>
          </div>

          <div className="bg-[#0D1830] border border-white/5 p-5 rounded-2xl space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 uppercase tracking-widest">
              <span>Production Status</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-2xl font-bold text-white font-mono">
              {metrics.completionRate}%
            </div>
            <div className="text-[10px] text-amber-400 flex items-center gap-1">
              <Clock className="w-3 h-3" /> {metrics.liveCount} Deliverables Pending
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Chart Area */}
          <div className="lg:col-span-8 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div>
                <h3 className="font-serif font-bold text-white text-lg">Campaign Momentum</h3>
                <p className="text-[11px] text-[#7C8AA8]">Deliverable volume and investment over time</p>
              </div>
              <div className="flex gap-1 bg-[#111E33] p-1 rounded-xl">
                {(['revenue', 'volume'] as MetricViewMode[]).map(mode => (
                  <button
                    key={mode}
                    onClick={() => setMetricViewMode(mode)}
                    className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      metricViewMode === mode ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8]'
                    }`}
                  >
                    {mode === 'revenue' ? 'Spend' : 'Assets'}
                  </button>
                ))}
              </div>
            </div>

            <div className="h-[300px] w-full relative pt-4">
               <svg viewBox="0 0 600 220" className="w-full h-full overflow-visible">
                  {/* Reuse chart logic but with simplified restricted data */}
                  {[0.2, 0.4, 0.6, 0.8, 1.0].map((ratio, i) => {
                    const yPos = 180 - ratio * 150;
                    const val = Math.round(maxChartValue * ratio);
                    return (
                      <g key={i}>
                        <line x1="45" y1={yPos} x2="580" y2={yPos} stroke="rgba(255,255,255,0.06)" strokeDasharray="3" />
                        <text x="5" y={yPos + 3} fill="#7C8AA8" fontSize="9" fontFamily="monospace">
                          {metricViewMode === 'revenue' ? `$${(val / 1000).toFixed(0)}k` : val}
                        </text>
                      </g>
                    );
                  })}
                  <line x1="45" y1="180" x2="580" y2="180" stroke="rgba(255,255,255,0.15)" />
                  {monthlyTimelineData.map((item, idx) => {
                    const count = monthlyTimelineData.length;
                    const slotWidth = 510 / count;
                    const barWidth = 30;
                    const xCenter = 60 + idx * slotWidth + slotWidth / 2;
                    const currentValue = metricViewMode === 'revenue' ? item.gross : item.dealsCount;
                    const barHeight = Math.max(10, (currentValue / (maxChartValue || 1)) * 150);
                    return (
                      <g key={idx}>
                        <rect x={xCenter - 15} y={180 - barHeight} width={barWidth} height={barHeight} rx="4" fill="#C9A46A" opacity="0.8" />
                        <text x={xCenter} y="198" fill="#7C8AA8" fontSize="9" textAnchor="middle">{item.short}</text>
                      </g>
                    );
                  })}
               </svg>
            </div>
          </div>

          {/* Platform Performance */}
          <div className="lg:col-span-4 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6">
            <h3 className="font-serif font-bold text-white text-lg border-b border-white/5 pb-4">Audience Source</h3>
            <div className="space-y-5">
              {platformBreakdown.map(p => (
                <div key={p.label} className="space-y-2">
                  <div className="flex justify-between items-center text-[11px] font-bold">
                    <span className="text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }} />
                      {p.label}
                    </span>
                    <span className="text-slate-400">{p.percentage}%</span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${p.percentage}%`, backgroundColor: p.color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Talent ROI Table */}
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden shadow-lg">
          <div className="p-6 border-b border-white/5 bg-[#111E33]/30">
            <h3 className="font-serif font-bold text-white text-lg">Hired Talent Performance</h3>
            <p className="text-xs text-[#7C8AA8]">Detailed breakdown of creators assigned to your active campaigns.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5 bg-[#111E33]/50">
                  <th className="px-6 py-4 text-[10px] font-mono text-slate-400 uppercase tracking-widest">Creator</th>
                  <th className="px-6 py-4 text-[10px] font-mono text-slate-400 uppercase tracking-widest">Platform</th>
                  <th className="px-6 py-4 text-[10px] font-mono text-slate-400 uppercase tracking-widest">Reach</th>
                  <th className="px-6 py-4 text-[10px] font-mono text-slate-400 uppercase tracking-widest">Deals</th>
                  <th className="px-6 py-4 text-[10px] font-mono text-slate-400 uppercase tracking-widest">Delivery</th>
                  <th className="px-6 py-4 text-[10px] font-mono text-slate-400 uppercase tracking-widest text-right">Investment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {creatorLeaderboard.map((item) => (
                  <tr key={item.id} className="hover:bg-white/[0.02] transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-white">{item.name}</span>
                        <span className="text-[10px] text-[#C9A46A]">{item.handle}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs text-slate-300">{item.platform}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs text-slate-300">{item.followers}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs text-slate-300">{item.dealsCount} campaigns</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${item.onTimeScore}%` }} />
                        </div>
                        <span className="text-[10px] text-emerald-400 font-bold">{item.onTimeScore}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-xs font-mono font-bold text-white">${item.grossRevenue.toLocaleString()}</span>
                    </td>
                  </tr>
                ))}
                {creatorLeaderboard.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-slate-500 text-xs italic">
                      No active hired talent ROI data available.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-full">
      {/* Top Header Card with Real-time DB Sync status & Action Tools */}
      <div className="relative bg-[#0D1830] border border-[#rgba(201,164,106,0.2)] rounded-2xl p-5 sm:p-6 shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-radial-gradient(circle,rgba(201,164,106,0.08)_0%,transparent_70%) pointer-events-none" />
        
        <div className="relative flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5">
              <span className="text-[10px] font-mono font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-[#16243F] text-[#C9A46A] border border-[#C9A46A]/30 flex items-center gap-1.5">
                <Activity className="w-3 h-3 text-emerald-400" />
                Live Performance Intelligence
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Database Synced
              </span>
            </div>
            
            <h1 className="font-serif font-semibold text-2xl sm:text-3xl text-white tracking-tight">
              Agency Performance &amp; ROI Analytics
            </h1>
            <p className="text-xs text-[#7C8AA8] max-w-2xl leading-relaxed">
              Real-time audit of gross campaign deal flow, 20% agency margins, talent payout disbursements, and multi-platform reach momentum.
            </p>
          </div>

          {/* Quick Action Export & Refresh Controls */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={handleLiveRefresh}
              disabled={isRefreshing}
              className="bg-[#16243F] hover:bg-[#1C2E52] border border-white/10 text-slate-200 px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm disabled:opacity-50"
              title="Refresh and recalculate live stats"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#C9A46A] ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'Syncing...' : 'Sync Data'}</span>
            </button>

            <div className="relative">
              <button
                onClick={handleExportCSV}
                className="bg-[#C9A46A] hover:bg-[#D4B27D] text-[#0A1220] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                title="Download CSV report"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
            </div>

            <button
              onClick={handleExportJSON}
              className="bg-[#111E33] hover:bg-[#162844] border border-white/10 text-[#B8C0D4] hover:text-white px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Export structured JSON"
            >
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>JSON</span>
            </button>
          </div>
        </div>

        {/* Global Filter Bar (Timeframe, Platform, Niche, Search) */}
        <div className="mt-6 pt-5 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Timeframe Chips */}
          <div className="flex items-center gap-1 bg-[#111E33] p-1 rounded-xl border border-white/5">
            <span className="text-[10px] font-mono text-[#7C8AA8] px-2 font-semibold">RANGE:</span>
            {(['7d', '30d', '90d', 'ytd', 'all'] as TimeframeOption[]).map(t => (
              <button
                key={t}
                onClick={() => setTimeframe(t)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  timeframe === t 
                    ? 'bg-[#C9A46A] text-[#0A1220] shadow-sm font-bold' 
                    : 'text-[#7C8AA8] hover:text-white hover:bg-white/5'
                }`}
              >
                {t === '7d' ? '7D' : t === '30d' ? '30D' : t === '90d' ? '90D' : t === 'ytd' ? 'YTD 2026' : 'All Time'}
              </button>
            ))}
          </div>

          {/* Filter Dropdowns */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Platform Filter */}
            <div className="flex items-center gap-1 bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-1">
              <Filter className="w-3 h-3 text-[#C9A46A]" />
              <select
                value={selectedPlatform}
                onChange={e => setSelectedPlatform(e.target.value)}
                className="bg-transparent text-xs text-white outline-none cursor-pointer pr-2"
              >
                <option value="all" className="bg-[#0D1830] text-white">All Platforms</option>
                <option value="TikTok" className="bg-[#0D1830] text-white">TikTok</option>
                <option value="Instagram" className="bg-[#0D1830] text-white">Instagram</option>
                <option value="YouTube" className="bg-[#0D1830] text-white">YouTube</option>
                <option value="Twitch" className="bg-[#0D1830] text-white">Twitch</option>
                <option value="Direct" className="bg-[#0D1830] text-white">Direct / UGC</option>
              </select>
            </div>

            {/* Niche Filter */}
            <div className="flex items-center gap-1 bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-1">
              <span className="text-[10px] text-[#7C8AA8] font-mono">NICHE:</span>
              <select
                value={selectedNiche}
                onChange={e => setSelectedNiche(e.target.value)}
                className="bg-transparent text-xs text-white outline-none cursor-pointer pr-2"
              >
                <option value="all" className="bg-[#0D1830] text-white">All Niches</option>
                <option value="Beauty & Skincare" className="bg-[#0D1830] text-white">Beauty &amp; Skincare</option>
                <option value="Lifestyle" className="bg-[#0D1830] text-white">Lifestyle</option>
                <option value="Tech & Gaming" className="bg-[#0D1830] text-white">Tech &amp; Gaming</option>
                <option value="Fitness & Wellness" className="bg-[#0D1830] text-white">Fitness &amp; Wellness</option>
                <option value="Fashion" className="bg-[#0D1830] text-white">Fashion</option>
                <option value="Food & Beverage" className="bg-[#0D1830] text-white">Food &amp; Beverage</option>
              </select>
            </div>

            {/* Search filter input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#7C8AA8] absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search talent or brand..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="bg-[#111E33] border border-white/10 text-xs text-white pl-8 pr-7 py-1 rounded-xl outline-none focus:border-[#C9A46A] w-36 sm:w-48 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main KPI High-Level Performance Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {/* Metric 1: Aggregate Deal Value */}
        <div className="bg-[#0D1830] border border-white/5 hover:border-[#C9A46A]/30 p-4 sm:p-5 rounded-2xl space-y-2 transition-all shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-[#7C8AA8] font-mono uppercase font-bold tracking-wider">
              Total Deal Volume
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white tracking-tight font-mono">
            {isRestrictedRole ? 'Protected' : `$${metrics.totalGrossRevenue.toLocaleString()}`}
          </div>
          <div className="flex items-center justify-between text-[10px] pt-0.5 border-t border-white/5">
            <span className="text-emerald-400 font-semibold flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3" /> {metrics.dealCount} active campaigns
            </span>
            <span className="text-[#7C8AA8]">Avg: ${metrics.avgDealSize.toLocaleString()}</span>
          </div>
        </div>

        {/* Metric 2: Net Agency Margin (20%) */}
        <div className="bg-[#0D1830] border border-white/5 hover:border-[#C9A46A]/30 p-4 sm:p-5 rounded-2xl space-y-2 transition-all shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-[#7C8AA8] font-mono uppercase font-bold tracking-wider">
              Agency Net Margin (20%)
            </span>
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center text-[#C9A46A]">
              <Landmark className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-[#C9A46A] tracking-tight font-mono">
            {isRestrictedRole ? 'Masked' : `$${metrics.agencyMargin.toLocaleString()}`}
          </div>
          <div className="flex items-center justify-between text-[10px] pt-0.5 border-t border-white/5">
            <span className="text-amber-300 font-semibold">
              Talent Pool: ${metrics.talentPayouts.toLocaleString()}
            </span>
            <span className="text-slate-400">80% Payout</span>
          </div>
        </div>

        {/* Metric 3: Verified Aggregate Reach */}
        <div className="bg-[#0D1830] border border-white/5 hover:border-[#C9A46A]/30 p-4 sm:p-5 rounded-2xl space-y-2 transition-all shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-[#7C8AA8] font-mono uppercase font-bold tracking-wider">
              Roster Aggregate Reach
            </span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white tracking-tight font-mono">
            {metrics.formattedReach}
          </div>
          <div className="flex items-center justify-between text-[10px] pt-0.5 border-t border-white/5">
            <span className="text-cyan-400 font-semibold flex items-center gap-0.5">
              <Eye className="w-3 h-3" /> {filteredCreators.length} verified creators
            </span>
            <span className="text-[#7C8AA8]">Cross-Platform</span>
          </div>
        </div>

        {/* Metric 4: Blended Engagement & CPM */}
        <div className="bg-[#0D1830] border border-white/5 hover:border-[#C9A46A]/30 p-4 sm:p-5 rounded-2xl space-y-2 transition-all shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-[#7C8AA8] font-mono uppercase font-bold tracking-wider">
              Blended Eng. &amp; CPM
            </span>
            <div className="w-7 h-7 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-emerald-400 tracking-tight font-mono flex items-center gap-2">
            <span>{metrics.blendedEngRate}%</span>
            <span className="text-xs text-[#7C8AA8] font-normal">/ ${metrics.effectiveCPM} CPM</span>
          </div>
          <div className="flex items-center justify-between text-[10px] pt-0.5 border-t border-white/5">
            <span className="text-emerald-400 font-semibold">
              {metrics.completionRate}% On-Time Delivery
            </span>
            <span className="text-[#7C8AA8]">High Tier</span>
          </div>
        </div>
      </div>

      {/* Analytics Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        {[
          { id: 'overview', label: 'Executive Overview', icon: BarChart3 },
          { id: 'retention', label: 'Roster Retention Analytics', icon: HeartHandshake, badge: '98.1% Rate' },
          { id: 'creators', label: 'Creator Roster ROI', icon: Users, badge: `${filteredCreators.length}` },
          { id: 'campaigns', label: 'Active Deliverables', icon: Layers, badge: `${filteredDeals.length}` },
          { id: 'benchmarks', label: 'Audience & CPM Benchmarks', icon: Globe },
          { id: 'forecasting', label: 'Revenue Forecasting', icon: Zap }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as AnalyticsTab)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-[#16243F] text-[#C9A46A] border border-[#C9A46A]/40 shadow-sm'
                  : 'text-[#7C8AA8] hover:text-white hover:bg-[#111E33]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                  isActive ? 'bg-amber-400/20 text-amber-300 font-bold' : 'bg-white/5 text-[#7C8AA8]'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: EXECUTIVE OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Main Visualizer: Dynamic Monthly Growth Chart & Platform Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Dynamic Monthly Revenue SVG Chart (2 columns) */}
            <div className="lg:col-span-2 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3.5">
                <div>
                  <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                    <span>Monthly Trajectory &amp; Growth</span>
                    <span className="text-[10px] font-mono text-[#C9A46A] bg-[#16243F] px-2 py-0.5 rounded border border-[#C9A46A]/30">
                      2026 Audit
                    </span>
                  </h3>
                  <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                    Calculated from active deal escrow contracts and verified disbursements.
                  </p>
                </div>

                {/* Metric toggle mode */}
                <div className="flex items-center gap-1 bg-[#111E33] p-1 rounded-xl border border-white/5 self-start sm:self-auto">
                  <button
                    onClick={() => setMetricViewMode('revenue')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                      metricViewMode === 'revenue' ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-[#7C8AA8] hover:text-white'
                    }`}
                  >
                    Gross Deal Flow
                  </button>
                  <button
                    onClick={() => setMetricViewMode('margin')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                      metricViewMode === 'margin' ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-[#7C8AA8] hover:text-white'
                    }`}
                  >
                    Agency Margin (20%)
                  </button>
                  <button
                    onClick={() => setMetricViewMode('volume')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                      metricViewMode === 'volume' ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-[#7C8AA8] hover:text-white'
                    }`}
                  >
                    Deal Count
                  </button>
                </div>
              </div>

              {/* Responsive SVG Chart */}
              <div className="relative py-2">
                <svg viewBox="0 0 600 220" className="w-full h-[220px] overflow-visible">
                  <defs>
                    <linearGradient id="barGoldGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#E3C48F" />
                      <stop offset="100%" stopColor="#C9A46A" />
                    </linearGradient>
                    <linearGradient id="barEmeraldGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#34D399" />
                      <stop offset="100%" stopColor="#059669" />
                    </linearGradient>
                    <linearGradient id="barCyanGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#38BDF8" />
                      <stop offset="100%" stopColor="#0284C7" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal Gridlines */}
                  {[0.2, 0.4, 0.6, 0.8, 1.0].map((ratio, i) => {
                    const yPos = 180 - ratio * 150;
                    const val = Math.round(maxChartValue * ratio);
                    const formattedVal = metricViewMode === 'volume' 
                      ? `${val}` 
                      : val >= 1000 ? `$${(val / 1000).toFixed(0)}k` : `$${val}`;
                    return (
                      <g key={i}>
                        <line x1="45" y1={yPos} x2="580" y2={yPos} stroke="rgba(255,255,255,0.06)" strokeDasharray="3" />
                        <text x="5" y={yPos + 3} fill="#7C8AA8" fontSize="9" fontFamily="monospace">
                          {formattedVal}
                        </text>
                      </g>
                    );
                  })}
                  <line x1="45" y1="180" x2="580" y2="180" stroke="rgba(255,255,255,0.15)" />

                  {/* Dynamic Bars for each month */}
                  {monthlyTimelineData.map((item, idx) => {
                    const count = monthlyTimelineData.length;
                    const availableWidth = 510;
                    const slotWidth = availableWidth / count;
                    const barWidth = Math.min(36, slotWidth * 0.55);
                    const xCenter = 60 + idx * slotWidth + slotWidth / 2;
                    const barX = xCenter - barWidth / 2;

                    const currentValue = metricViewMode === 'revenue' 
                      ? item.gross 
                      : metricViewMode === 'margin' 
                      ? item.margin 
                      : item.dealsCount;

                    const barHeight = Math.max(8, (currentValue / (maxChartValue || 1)) * 150);
                    const barY = 180 - barHeight;
                    const isHovered = hoveredBarIndex === idx;

                    const gradFill = metricViewMode === 'revenue' 
                      ? 'url(#barGoldGradient)' 
                      : metricViewMode === 'margin' 
                      ? 'url(#barEmeraldGradient)' 
                      : 'url(#barCyanGradient)';

                    return (
                      <g key={idx}>
                        {/* Hover trigger zone */}
                        <rect
                          x={barX - 10}
                          y="10"
                          width={barWidth + 20}
                          height="180"
                          fill="transparent"
                          className="cursor-pointer"
                          onMouseEnter={() => setHoveredBarIndex(idx)}
                          onMouseLeave={() => setHoveredBarIndex(null)}
                        />

                        {/* Background subtle bar */}
                        <rect
                          x={barX}
                          y="30"
                          width={barWidth}
                          height="150"
                          rx="6"
                          fill="rgba(255,255,255,0.02)"
                        />

                        {/* Actual data bar */}
                        <rect
                          x={barX}
                          y={barY}
                          width={barWidth}
                          height={barHeight}
                          rx="6"
                          fill={gradFill}
                          className="transition-all duration-300"
                          opacity={isHovered ? 1 : 0.9}
                        />

                        {/* X-axis Label */}
                        <text
                          x={xCenter}
                          y="198"
                          fill={isHovered ? '#C9A46A' : '#7C8AA8'}
                          fontSize="10"
                          fontFamily="monospace"
                          fontWeight={isHovered ? 'bold' : 'normal'}
                          textAnchor="middle"
                        >
                          {item.short}
                        </text>

                        {/* Hover Tooltip Box */}
                        {isHovered && (
                          <g>
                            <rect
                              x={Math.max(10, Math.min(480, xCenter - 55))}
                              y={Math.max(5, barY - 45)}
                              width="110"
                              height="38"
                              rx="8"
                              fill="#0D1830"
                              stroke="#C9A46A"
                              strokeWidth="1.5"
                              filter="drop-shadow(0px 4px 12px rgba(0,0,0,0.5))"
                            />
                            <text
                              x={Math.max(10, Math.min(480, xCenter - 55)) + 55}
                              y={Math.max(5, barY - 45) + 16}
                              fill="white"
                              fontSize="11"
                              fontWeight="bold"
                              fontFamily="monospace"
                              textAnchor="middle"
                            >
                              {metricViewMode === 'volume' 
                                ? `${currentValue} Deals` 
                                : `$${currentValue.toLocaleString()}`}
                            </text>
                            <text
                              x={Math.max(10, Math.min(480, xCenter - 55)) + 55}
                              y={Math.max(5, barY - 45) + 30}
                              fill="#7C8AA8"
                              fontSize="9"
                              fontFamily="sans-serif"
                              textAnchor="middle"
                            >
                              {item.month} • {item.cpm} CPM
                            </text>
                          </g>
                        )}
                      </g>
                    );
                  })}
                </svg>
              </div>

              {/* Chart Footer Stats */}
              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-white/5 text-center text-xs">
                <div>
                  <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Gross Trajectory</span>
                  <span className="font-bold text-white font-mono text-sm">${metrics.totalGrossRevenue.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Commission Pool (20%)</span>
                  <span className="font-bold text-[#C9A46A] font-mono text-sm">${metrics.agencyMargin.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Talent Escrow Payouts</span>
                  <span className="font-bold text-emerald-400 font-mono text-sm">${metrics.talentPayouts.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Platform Revenue & Deals Distribution (1 column) */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 shadow-lg flex flex-col justify-between">
              <div>
                <div className="border-b border-white/5 pb-3">
                  <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                    <PieChart className="w-4 h-4 text-[#C9A46A]" />
                    <span>Platform Distribution</span>
                  </h3>
                  <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                    Gross revenue breakdown by social channel.
                  </p>
                </div>

                <div className="space-y-3.5 mt-4">
                  {platformBreakdown.map((plat, i) => (
                    <div key={i} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span>{plat.icon}</span>
                          <span className="font-medium text-slate-200">{plat.label}</span>
                        </div>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="text-[#B8C0D4] font-semibold">${plat.gross.toLocaleString()}</span>
                          <span className="text-[11px] text-[#7C8AA8]">({plat.percentage}%)</span>
                        </div>
                      </div>
                      
                      {/* Visual progress bar */}
                      <div className="w-full bg-[#111E33] h-2 rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full transition-all duration-500"
                          style={{ 
                            width: `${Math.max(4, plat.percentage)}%`,
                            backgroundColor: plat.color 
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] text-[#7C8AA8] font-mono">
                        <span>{plat.dealsCount} deals recorded</span>
                        <span>Avg deal: ${plat.dealsCount > 0 ? Math.round(plat.gross / plat.dealsCount).toLocaleString() : '0'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-[#7C8AA8]">
                <span className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 100% Escrow protected
                </span>
                <span className="font-mono font-bold text-white">5 Active Channels</span>
              </div>
            </div>
          </div>

          {/* Deal Pipeline Funnel Conversion Grid */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
              <div>
                <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#C9A46A]" />
                  <span>Agency Pipeline Conversion Funnel</span>
                </h3>
                <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                  Flow of brand proposals from initial pitch through escrow release.
                </p>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-semibold bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                {metrics.completionRate}% Contract Success Rate
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 pt-2">
              {[
                { stage: '1. Inbound & Pitch', count: Math.max(2, Math.round(metrics.dealCount * 0.35)), value: Math.round(metrics.totalGrossRevenue * 0.4), color: 'border-slate-500/30 text-slate-300', rate: '100% Inbound' },
                { stage: '2. Negotiating', count: Math.max(1, metrics.negotiatingCount), value: metrics.pipelineValue, color: 'border-cyan-500/30 text-cyan-300', rate: '72% Advance' },
                { stage: '3. Contract Draft', count: Math.max(1, Math.round(metrics.dealCount * 0.2)), value: Math.round(metrics.totalGrossRevenue * 0.25), color: 'border-purple-500/30 text-purple-300', rate: '88% Signed' },
                { stage: '4. Live in Escrow', count: Math.max(1, metrics.liveCount), value: metrics.liveEscrowValue, color: 'border-amber-500/40 text-amber-300', rate: '96% Deliver' },
                { stage: '5. Settled & Paid', count: Math.max(1, metrics.completedCount), value: metrics.completedValue, color: 'border-emerald-500/40 text-emerald-300', rate: '100% Release' },
              ].map((step, i) => (
                <div key={i} className={`bg-[#111E33] border ${step.color} p-3.5 rounded-xl space-y-2 relative`}>
                  <div className="flex items-center justify-between text-[10px] font-mono uppercase font-bold text-[#7C8AA8]">
                    <span>{step.stage}</span>
                  </div>
                  <div className="text-base sm:text-lg font-bold text-white font-mono">
                    ${step.value.toLocaleString()}
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-[#7C8AA8] font-mono">
                    <span>{step.count} deals</span>
                    <span className="font-semibold text-emerald-400">{step.rate}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CREATOR ROSTER ROI LEADERBOARD */}
      {activeTab === 'creators' && (
        <div className="space-y-4">
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 sm:p-5 border-b border-white/5 bg-[#111E33]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-serif font-semibold text-white text-base">
                  Roster Performance &amp; ROI Leaderboard
                </h3>
                <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                  Ranked by total gross billing generated, engagement benchmarks, and on-time deliverable scoring.
                </p>
              </div>
              <div className="text-xs font-mono text-[#C9A46A] bg-[#16243F] px-3 py-1.5 rounded-xl border border-[#C9A46A]/20">
                {creatorLeaderboard.length} Ranked Creators
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/10 bg-[#111E33] text-[#7C8AA8] font-mono uppercase text-[10px] tracking-wider">
                    <th className="p-4 w-12 text-center">#</th>
                    <th className="p-4">Creator / Handle</th>
                    <th className="p-4">Niche &amp; Channel</th>
                    <th className="p-4">Total Reach</th>
                    <th className="p-4">Eng. Rate</th>
                    <th className="p-4">Deals Done</th>
                    <th className="p-4">Gross Billing</th>
                    <th className="p-4">Agency 20%</th>
                    <th className="p-4 text-center">On-Time</th>
                    <th className="p-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono">
                  {creatorLeaderboard.map((item, idx) => (
                    <tr key={item.id} className="hover:bg-[#111E33]/50 transition-colors">
                      <td className="p-4 text-center font-bold text-[#7C8AA8]">
                        #{idx + 1}
                      </td>
                      <td className="p-4 font-sans">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-[#16243F] border border-[#C9A46A]/40 flex items-center justify-center font-serif font-bold text-xs text-[#C9A46A] shrink-0">
                            {item.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-semibold text-white flex items-center gap-1.5">
                              <span>{item.name}</span>
                              <span className="text-[9px] font-mono bg-white/5 text-[#7C8AA8] px-1.5 py-0.2 rounded">
                                {item.tier}
                              </span>
                            </div>
                            <div className="text-[11px] text-[#C9A46A] font-mono">{item.handle}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 font-sans">
                        <div className="text-slate-200 font-medium">{item.niche}</div>
                        <div className="text-[10px] text-[#7C8AA8]">{item.platform}</div>
                      </td>
                      <td className="p-4 font-semibold text-white">
                        {item.followers}
                      </td>
                      <td className="p-4">
                        <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-950/60 text-emerald-400 border border-emerald-500/20">
                          {item.eng.startsWith('+') ? item.eng : `+${item.eng}`}
                        </span>
                      </td>
                      <td className="p-4 text-[#B8C0D4]">
                        {item.dealsCount} deals
                      </td>
                      <td className="p-4 font-bold text-white">
                        {isRestrictedRole ? 'Masked' : `$${item.grossRevenue.toLocaleString()}`}
                      </td>
                      <td className="p-4 font-semibold text-[#C9A46A]">
                        {isRestrictedRole ? 'Masked' : `$${item.commission.toLocaleString()}`}
                      </td>
                      <td className="p-4 text-center">
                        <span className="text-emerald-400 font-bold text-[11px]">
                          {item.onTimeScore}%
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => setSelectedCreatorModal(item)}
                          className="bg-[#16243F] hover:bg-[#1C2E52] border border-white/10 hover:border-[#C9A46A]/50 text-xs text-[#C9A46A] px-2.5 py-1.5 rounded-lg transition-all cursor-pointer font-sans"
                        >
                          View Dossier
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ACTIVE CAMPAIGNS & DELIVERABLES */}
      {activeTab === 'campaigns' && (
        <div className="space-y-4">
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3.5">
              <div>
                <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#C9A46A]" />
                  <span>Campaign Deliverables Intelligence</span>
                </h3>
                <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                  Performance audit of brand contracts, deliverable status, estimated views, and effective CPM.
                </p>
              </div>
              <div className="text-xs font-mono text-emerald-400 bg-emerald-950/40 px-3 py-1.5 rounded-xl border border-emerald-500/20">
                {filteredDeals.length} Active &amp; Historical Deals
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDeals.map((deal, idx) => {
                const val = Number(deal.budget || deal.value || 0);
                const estViews = Math.round(val * 24);
                const isCompleted = (deal.stage || '').toLowerCase() === 'completed';
                const isLive = (deal.stage || '').toLowerCase() === 'live';

                return (
                  <div key={deal.id || idx} className="bg-[#111E33] border border-white/5 hover:border-[#C9A46A]/30 p-4 rounded-xl space-y-3 transition-all shadow-md">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold tracking-wider">
                          {deal.brand}
                        </span>
                        <h4 className="font-semibold text-white text-sm mt-0.5">
                          {deal.title || `${deal.brand} Q3 Campaign`}
                        </h4>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                        isCompleted 
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' 
                          : isLive
                          ? 'bg-amber-950 text-amber-300 border border-amber-500/20'
                          : 'bg-cyan-950 text-cyan-300 border border-cyan-500/20'
                      }`}>
                        {deal.stage || 'Negotiating'}
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs text-[#B8C0D4]">
                      <div className="flex justify-between">
                        <span className="text-[#7C8AA8]">Creator:</span>
                        <span className="font-semibold text-white">{deal.creator}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#7C8AA8]">Platform:</span>
                        <span>{deal.platform}</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-[#7C8AA8]">Deal Budget:</span>
                        <span className="font-bold text-white">${val.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-[#7C8AA8]">Est. Impressions:</span>
                        <span className="text-cyan-400 font-semibold">{estViews.toLocaleString()} views</span>
                      </div>
                      <div className="flex justify-between font-mono">
                        <span className="text-[#7C8AA8]">Effective CPM:</span>
                        <span className="text-emerald-400 font-semibold">${((val / Math.max(1, estViews)) * 1000).toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-[#7C8AA8]">
                      <span>Due: {deal.due || deal.dueDate || 'End of Month'}</span>
                      <span className="text-[#C9A46A] font-semibold">20% Agency Split</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AUDIENCE DEMOGRAPHICS & BENCHMARKS */}
      {activeTab === 'benchmarks' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Audience Demographics */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 shadow-lg">
            <div className="border-b border-white/5 pb-3">
              <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                <Globe className="w-4 h-4 text-[#C9A46A]" />
                <span>Audience Demographics &amp; Geography</span>
              </h3>
              <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                Aggregate follower distribution across Bloom Studio roster.
              </p>
            </div>

            {/* Age Brackets */}
            <div className="space-y-2">
              <span className="text-[10px] font-mono uppercase font-bold text-[#C9A46A] block">
                Age Brackets Breakdown
              </span>
              {[
                { label: '18 - 24 Years (Gen-Z)', percentage: 44, color: '#00F2FE' },
                { label: '25 - 34 Years (Millennials)', percentage: 38, color: '#C9A46A' },
                { label: '35 - 44 Years', percentage: 12, color: '#38BDF8' },
                { label: '45+ Years', percentage: 6, color: '#7C8AA8' },
              ].map((age, i) => (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300">{age.label}</span>
                    <span className="font-mono font-bold text-white">{age.percentage}%</span>
                  </div>
                  <div className="w-full bg-[#111E33] h-2 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${age.percentage}%`, backgroundColor: age.color }} />
                  </div>
                </div>
              ))}
            </div>

            {/* Top Geographic Markets */}
            <div className="pt-3 border-t border-white/5 space-y-2">
              <span className="text-[10px] font-mono uppercase font-bold text-[#C9A46A] block">
                Top Geographic Markets
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2.5 bg-[#111E33] rounded-xl border border-white/5 flex justify-between">
                  <span className="text-slate-300">🇺🇸 United States</span>
                  <span className="text-emerald-400 font-bold">72.4%</span>
                </div>
                <div className="p-2.5 bg-[#111E33] rounded-xl border border-white/5 flex justify-between">
                  <span className="text-slate-300">🇬🇧 United Kingdom</span>
                  <span className="text-emerald-400 font-bold">12.1%</span>
                </div>
                <div className="p-2.5 bg-[#111E33] rounded-xl border border-white/5 flex justify-between">
                  <span className="text-slate-300">🇨🇦 Canada</span>
                  <span className="text-emerald-400 font-bold">8.5%</span>
                </div>
                <div className="p-2.5 bg-[#111E33] rounded-xl border border-white/5 flex justify-between">
                  <span className="text-slate-300">🇦🇺 Australia</span>
                  <span className="text-emerald-400 font-bold">4.2%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Industry CPM Benchmarks Comparison */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 shadow-lg">
            <div className="border-b border-white/5 pb-3">
              <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-400" />
                <span>Industry CPM &amp; Conversion Benchmarks</span>
              </h3>
              <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                Comparing Bloom Studio performance against national creator agency averages.
              </p>
            </div>

            <div className="space-y-3 text-xs">
              {[
                { channel: 'TikTok Sponsored Video', bloom: '$8.40 CPM', industry: '$12.20 CPM', status: '31% More Efficient' },
                { channel: 'Instagram Reel + Story', bloom: '$14.20 CPM', industry: '$19.50 CPM', status: '27% Cost Advantage' },
                { channel: 'YouTube Integrated Video', bloom: '$22.00 CPM', industry: '$28.00 CPM', status: 'High Retention' },
                { channel: 'Deliverable On-Time Rate', bloom: '96.8%', industry: '82.4%', status: 'Top 5% Tier' },
                { channel: 'Average Engagement Rate', bloom: '4.8%', industry: '2.9%', status: '+65% Engagement' }
              ].map((bench, idx) => (
                <div key={idx} className="p-3 bg-[#111E33] border border-white/5 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white">{bench.channel}</div>
                    <div className="text-[10px] text-[#7C8AA8] mt-0.5">
                      Bloom: <strong className="text-[#C9A46A]">{bench.bloom}</strong> vs Industry: <strong className="text-slate-400">{bench.industry}</strong>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-950/60 border border-emerald-500/20 text-emerald-400 rounded-lg text-[10px] font-mono font-bold">
                    {bench.status}
                  </span>
                </div>
              ))}
            </div>

            <div className="p-3 bg-[#16243F] border border-[#C9A46A]/20 rounded-xl text-[11px] text-[#C9A46A] flex items-center gap-2">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>Agency creators consistently outperform standard creator CPM by 25-35%.</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: REVENUE FORECASTING & GOAL TRACKING */}
      {activeTab === 'forecasting' && (
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3.5">
            <div>
              <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Quarterly Agency Goal &amp; Revenue Projection</span>
              </h3>
              <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                Set quarterly gross billing targets and simulate pipeline close probabilities.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-[#7C8AA8]">TARGET:</span>
              <select
                value={revenueTarget}
                onChange={e => setRevenueTarget(Number(e.target.value))}
                className="bg-[#16243F] border border-[#C9A46A]/30 text-[#C9A46A] px-3 py-1 rounded-xl text-xs font-mono font-bold outline-none cursor-pointer"
              >
                <option value={100000}>$100,000 Target</option>
                <option value={250000}>$250,000 Target</option>
                <option value={500000}>$500,000 Target</option>
                <option value={1000000}>$1,000,000 Target</option>
              </select>
            </div>
          </div>

          {/* Goal Progress Bar */}
          <div className="p-5 bg-[#111E33] border border-white/5 rounded-2xl space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-white">Target Completion Progress</span>
              <span className="font-mono font-bold text-amber-400">
                {Math.min(100, Math.round((metrics.totalGrossRevenue / revenueTarget) * 100))}% of Goal
              </span>
            </div>
            <div className="w-full bg-[#0D1830] h-3.5 rounded-full overflow-hidden p-0.5 border border-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#C9A46A] to-amber-400 transition-all duration-500"
                style={{ width: `${Math.min(100, Math.max(2, (metrics.totalGrossRevenue / revenueTarget) * 100))}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] font-mono text-[#7C8AA8]">
              <span>Current Pipeline: ${metrics.totalGrossRevenue.toLocaleString()}</span>
              <span>Remaining to Goal: ${Math.max(0, revenueTarget - metrics.totalGrossRevenue).toLocaleString()}</span>
            </div>
          </div>

          {/* Probability Weighted Projection Simulator */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 bg-[#111E33] border border-white/5 rounded-xl space-y-1.5">
              <span className="text-[10px] text-[#7C8AA8] font-mono uppercase font-bold">Conservative Projection</span>
              <div className="text-xl font-bold text-white font-mono">
                ${Math.round(metrics.completedValue + metrics.liveEscrowValue).toLocaleString()}
              </div>
              <p className="text-[10px] text-slate-400">
                100% of Completed &amp; Escrow-locked deals only.
              </p>
            </div>

            <div className="p-4 bg-[#111E33] border border-[#C9A46A]/30 rounded-xl space-y-1.5">
              <span className="text-[10px] text-[#C9A46A] font-mono uppercase font-bold">Expected Scenario (Weighted)</span>
              <div className="text-xl font-bold text-[#C9A46A] font-mono">
                ${Math.round(metrics.completedValue + metrics.liveEscrowValue + (metrics.pipelineValue * 0.65)).toLocaleString()}
              </div>
              <p className="text-[10px] text-slate-400">
                Factoring 65% close probability on active negotiations.
              </p>
            </div>

            <div className="p-4 bg-[#111E33] border border-white/5 rounded-xl space-y-1.5">
              <span className="text-[10px] text-emerald-400 font-mono uppercase font-bold">Best Case Ceiling</span>
              <div className="text-xl font-bold text-emerald-400 font-mono">
                ${Math.round(metrics.totalGrossRevenue * 1.3).toLocaleString()}
              </div>
              <p className="text-[10px] text-slate-400">
                100% pipeline conversion + expected Q3 inbound expansions.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB: ROSTER RETENTION ANALYTICS */}
      {activeTab === 'retention' && (
        <div className="space-y-6">
          {/* 1. What is Roster Retention Analytics & Key KPI Strip */}
          <div className="p-5 bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#C9A46A]/30 rounded-2xl space-y-4 shadow-lg">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1 max-w-3xl">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded font-mono bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/40">
                    📈 Roster Longevity &amp; Health
                  </span>
                  <span className="text-xs text-emerald-400 font-mono font-bold">
                    98.1% Retention vs 94% Benchmark
                  </span>
                </div>
                <h3 className="font-serif font-bold text-xl text-white">
                  What is Roster Retention Analytics?
                </h3>
                <p className="text-xs text-[#B8C0D4] leading-relaxed">
                  Roster Retention Analytics measures the stability, contract renewal rates, churn probability, creator satisfaction, and lifetime value (LTV) of talent signed to your agency. It tracks talent contract renewals vs expirations, repeat brand deal frequency, and provides early warning triggers before talent goes inactive or considers signing elsewhere.
                </p>
              </div>

              <div className="flex items-center gap-2 bg-[#0A1220] p-3 rounded-xl border border-white/10 shrink-0">
                <div className="text-right font-mono">
                  <span className="text-[10px] text-[#7C8AA8] uppercase block">Talent Health Score</span>
                  <span className="text-lg font-bold text-emerald-400">96.4 / 100</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <ShieldCheck className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Retention KPI Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-white/10 text-xs font-mono">
              <div className="p-3 bg-[#0A1220] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] block uppercase">Avg Talent Tenure</span>
                <span className="text-lg font-bold text-white">14.8 Mos</span>
                <span className="text-[10px] text-emerald-400 block">+2.4 mos YoY</span>
              </div>
              <div className="p-3 bg-[#0A1220] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] block uppercase">Contract Renewal Rate</span>
                <span className="text-lg font-bold text-[#C9A46A]">94.2%</span>
                <span className="text-[10px] text-emerald-400 block">36 of 38 renewed</span>
              </div>
              <div className="p-3 bg-[#0A1220] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] block uppercase">Churn Risk Index</span>
                <span className="text-lg font-bold text-emerald-400">1.8%</span>
                <span className="text-[10px] text-slate-400 block">Low flight risk</span>
              </div>
              <div className="p-3 bg-[#0A1220] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] block uppercase">Avg Talent LTV</span>
                <span className="text-lg font-bold text-white">$42,850</span>
                <span className="text-[10px] text-[#C9A46A] block">20% net $8,570</span>
              </div>
            </div>
          </div>

          {/* 2. Cohort Retention Funnel & Retention Drivers */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Retention Funnel / Milestones (2 cols) */}
            <div className="lg:col-span-2 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                  <span>Talent Cohort Retention Milestones</span>
                </h3>
                <span className="text-[10px] font-mono text-[#7C8AA8]">All Active Contracts</span>
              </div>

              <div className="space-y-3.5 text-xs">
                {[
                  { stage: 'Day 30 (Onboarding & 1st Deal Setup)', rate: 100, count: `${filteredCreators.length} creators`, color: 'bg-emerald-500', desc: '100% complete KYC, W-9, and Media Kit setup' },
                  { stage: 'Day 90 (First Payout & Campaign Velocity)', rate: 98.1, count: '37 of 38 active', color: 'bg-emerald-400', desc: 'Repeat campaign proposals delivered within 45 days' },
                  { stage: 'Day 180 (Mid-Contract Growth Check)', rate: 95.8, count: '35 of 38 active', color: 'bg-[#C9A46A]', desc: 'Rate card adjusted up based on follower growth' },
                  { stage: 'Day 365+ (Annual Representation Renewal)', rate: 94.2, count: '36 renewals', color: 'bg-amber-400', desc: 'Exclusive agency representation extended for 12 mos' }
                ].map((cohort, idx) => (
                  <div key={idx} className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-white/5 text-[10px] font-mono flex items-center justify-center text-[#C9A46A]">
                          {idx + 1}
                        </span>
                        {cohort.stage}
                      </span>
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-white font-bold">{cohort.rate}%</span>
                        <span className="text-[#7C8AA8]">({cohort.count})</span>
                      </div>
                    </div>
                    <div className="w-full bg-[#0A1220] h-2.5 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${cohort.color}`} style={{ width: `${cohort.rate}%` }} />
                    </div>
                    <p className="text-[11px] text-slate-400">{cohort.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Retention Risk Triggers & Health Checklist */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="border-b border-white/5 pb-3 flex items-center justify-between">
                  <h3 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400" /> Early Warning Triggers
                  </h3>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/20">0 Critical</span>
                </div>

                <div className="space-y-2.5 text-xs text-slate-300">
                  <div className="p-3 bg-[#111E33] rounded-xl border border-white/5 space-y-1">
                    <div className="flex items-center justify-between font-semibold text-white">
                      <span>Deal Gap &gt; 45 Days</span>
                      <span className="text-[10px] text-emerald-400 font-mono">Clean (0)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">All creators have actively pitched or running deals.</p>
                  </div>

                  <div className="p-3 bg-[#111E33] rounded-xl border border-white/5 space-y-1">
                    <div className="flex items-center justify-between font-semibold text-white">
                      <span>Contract Expiry &lt; 60 Days</span>
                      <span className="text-[10px] text-[#C9A46A] font-mono">2 Due</span>
                    </div>
                    <p className="text-[11px] text-slate-400">Renewal proposals generated automatically in Contracts Vault.</p>
                  </div>

                  <div className="p-3 bg-[#111E33] rounded-xl border border-white/5 space-y-1">
                    <div className="flex items-center justify-between font-semibold text-white">
                      <span>Payment Speed</span>
                      <span className="text-[10px] text-emerald-400 font-mono">Instant (24h)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">Escrow disbursements released within 24h of brand deliverable approval.</p>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-white/5">
                <button
                  onClick={() => {
                    triggerNotification?.('Retention Audit Complete', 'All 38 roster creator accounts verified active with healthy pipeline velocity.', 'success');
                    onAddActivityLog?.(currentUser?.name || 'User', currentRole || 'none', 'Ran full roster retention health check audit.');
                  }}
                  className="w-full py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Run Full Roster Retention Health Audit</span>
                </button>
              </div>
            </div>
          </div>

          {/* 3. Creator-by-Creator Retention & Health Matrix */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3">
              <div>
                <h3 className="font-serif font-semibold text-white text-base">
                  Individual Creator Retention &amp; Health Radar
                </h3>
                <p className="text-xs text-[#7C8AA8] mt-0.5">
                  Detailed retention health breakdown for every talent represented across your active roster.
                </p>
              </div>
              <span className="text-xs font-mono text-[#C9A46A]">
                Showing {filteredCreators.length} talent profiles
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-[10px] font-mono text-[#7C8AA8] uppercase">
                    <th className="pb-3 px-3">Creator / Handle</th>
                    <th className="pb-3 px-3">Platform &amp; Niche</th>
                    <th className="pb-3 px-3">Tenure</th>
                    <th className="pb-3 px-3">Contract Status</th>
                    <th className="pb-3 px-3">Campaign Velocity</th>
                    <th className="pb-3 px-3">Retention Risk</th>
                    <th className="pb-3 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredCreators.map((creator, i) => {
                    const healthLevel = i % 7 === 0 ? 'Review Due' : 'Optimal';
                    const tenureMonths = 6 + (i * 3) % 18;
                    const dealsCount = filteredDeals.filter(d => d.creator === creator.handle || d.creator === creator.name).length || (1 + (i % 4));
                    
                    return (
                      <tr key={creator.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full bg-[#16243F] border border-white/10 flex items-center justify-center font-bold text-[#C9A46A] text-xs">
                              {creator.name.charAt(0)}
                            </div>
                            <div>
                              <div className="font-semibold text-white">{creator.name}</div>
                              <div className="text-[10px] font-mono text-[#C9A46A]">{creator.handle}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <span className="text-slate-300 block">{creator.platform}</span>
                          <span className="text-[10px] text-[#7C8AA8]">{creator.niche || 'Lifestyle'}</span>
                        </td>
                        <td className="py-3 px-3 font-mono">
                          <span className="text-white font-bold">{tenureMonths} mos</span>
                          <span className="text-[10px] text-slate-500 block">Signed 2025</span>
                        </td>
                        <td className="py-3 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-500/20 font-semibold">
                            Active (Exclusive)
                          </span>
                        </td>
                        <td className="py-3 px-3 font-mono">
                          <span className="text-white">{dealsCount} deals logged</span>
                          <span className="text-[10px] text-emerald-400 block font-normal">Active flow</span>
                        </td>
                        <td className="py-3 px-3">
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                            healthLevel === 'Optimal'
                              ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/20'
                              : 'bg-amber-950/60 text-amber-300 border border-amber-500/20'
                          }`}>
                            {healthLevel === 'Optimal' ? '● Healthy (0.5% Churn)' : '▲ 60d Renewal Check'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right">
                          <button
                            onClick={() => {
                              triggerNotification?.('Check-In Dispatched', `Sent VIP touchpoint reminder to ${creator.name}'s assigned agent.`, 'info');
                              onAddActivityLog?.(currentUser?.name || 'User', currentRole || 'none', `Scheduled retention touchpoint for ${creator.handle}`);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-[11px] font-semibold transition-colors cursor-pointer"
                          >
                            Touchpoint
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Creator Detail Modal / Drawer */}
      {selectedCreatorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0D1830] border-2 border-[#C9A46A]/50 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-2xl">
            <div className="flex items-start justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#16243F] border-2 border-[#C9A46A] flex items-center justify-center text-lg font-serif font-bold text-[#C9A46A]">
                  {selectedCreatorModal.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-serif font-bold text-white text-lg flex items-center gap-2">
                    <span>{selectedCreatorModal.name}</span>
                    <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                      {selectedCreatorModal.tier}
                    </span>
                  </h3>
                  <div className="text-xs font-mono text-[#C9A46A]">{selectedCreatorModal.handle}</div>
                </div>
              </div>
              <button
                onClick={() => setSelectedCreatorModal(null)}
                className="text-[#7C8AA8] hover:text-white p-1 rounded-lg hover:bg-white/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
              <div className="p-3 bg-[#111E33] rounded-xl border border-white/5">
                <span className="text-[9px] text-[#7C8AA8] block uppercase">Reach</span>
                <span className="text-sm font-bold text-white">{selectedCreatorModal.followers}</span>
              </div>
              <div className="p-3 bg-[#111E33] rounded-xl border border-white/5">
                <span className="text-[9px] text-[#7C8AA8] block uppercase">Eng. Rate</span>
                <span className="text-sm font-bold text-emerald-400">{selectedCreatorModal.eng}</span>
              </div>
              <div className="p-3 bg-[#111E33] rounded-xl border border-white/5">
                <span className="text-[9px] text-[#7C8AA8] block uppercase">Gross Rev</span>
                <span className="text-sm font-bold text-white">${selectedCreatorModal.grossRevenue.toLocaleString()}</span>
              </div>
              <div className="p-3 bg-[#111E33] rounded-xl border border-white/5">
                <span className="text-[9px] text-[#7C8AA8] block uppercase">Agency 20%</span>
                <span className="text-sm font-bold text-[#C9A46A]">${selectedCreatorModal.commission.toLocaleString()}</span>
              </div>
            </div>

            {/* Campaign History List */}
            <div className="space-y-2">
              <h4 className="text-xs font-mono font-bold text-[#C9A46A] uppercase tracking-wider">
                Assigned Brand Deals ({selectedCreatorModal.deals?.length || 0})
              </h4>
              {selectedCreatorModal.deals && selectedCreatorModal.deals.length > 0 ? (
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {selectedCreatorModal.deals.map((d: any, i: number) => (
                    <div key={i} className="p-3 bg-[#111E33] border border-white/5 rounded-xl flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-white">{d.brand}</div>
                        <div className="text-[10px] text-[#7C8AA8]">{d.platform} • {d.stage}</div>
                      </div>
                      <div className="text-right font-mono">
                        <div className="font-bold text-white">${Number(d.budget || d.value || 0).toLocaleString()}</div>
                        <div className="text-[10px] text-emerald-400">80% Payout: ${Math.round(Number(d.budget || d.value || 0) * 0.8).toLocaleString()}</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 bg-[#111E33] border border-white/5 rounded-xl text-center text-xs text-[#7C8AA8]">
                  No deals recorded yet for this creator.
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setSelectedCreatorModal(null)}
                className="bg-[#16243F] hover:bg-[#1C2E52] border border-white/10 text-white px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Close Dossier
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
