import React, { useState, useMemo, useEffect } from 'react';
import { 
  Users, Search, ArrowUpDown, ArrowUp, ArrowDown, Sparkles, Flame, 
  TrendingUp, Plus, Edit2, Tag, Globe, Award, CheckCircle2, AlertTriangle, 
  Check, X, ChevronDown, SlidersHorizontal, Layers, PieChart, BarChart2, 
  Activity, FileSpreadsheet, Trash2, Eye, MessageSquare, Mail, Smartphone, 
  DollarSign, Target, Shield, Heart, HelpCircle, Calendar, Clock, FileText, CheckCircle,
  CreditCard, History
} from 'lucide-react';
import { Creator, Role, RosterProfileSubmission } from '../types';
import { useAgencyNiches, CORE_AGENCY_NICHES } from '../lib/nicheConfig';
import RosterCharts from './RosterCharts';
import { RosterHeatMap } from './RosterHeatMap';
import { BatchActionsBar } from './BatchActionsBar';
import DaysUntilExpiryBadge from './DaysUntilExpiryBadge';
import { db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';

export interface CreatorRosterManagerProps {
  creators: Creator[];
  setCreators: React.Dispatch<React.SetStateAction<Creator[]>>;
  currentRole: Role | string;
  currentUser: any;
  isRestrictedRole: boolean;
  isAgentMgr: boolean;
  myHandles: string[];
  primaryBrandColor?: string;
  onSelectCreatorForDetail: (creator: Creator, defaultTab?: 'profile' | 'payouts' | 'messages') => void;
  onDeleteCreator: (creatorId: string) => void;
  onUpdateCreatorStatus: (creatorId: string, newStatus: string, date?: string, why?: string) => void;
  onExportCSV: () => void;
  onOpenQuickAddModal: () => void;
  onOpenLogDealModal: () => void;
  onOpenLaunchMission: () => void;
  onAssignAgent: (creatorId: string) => void;
  rosterViewMode: 'table' | 'heatmap' | 'profiles';
  setRosterViewMode: (mode: 'table' | 'heatmap' | 'profiles') => void;
  showRosterCharts: boolean;
  setShowRosterCharts: (show: boolean) => void;
  selectedCreatorIds: string[];
  setSelectedCreatorIds: React.Dispatch<React.SetStateAction<string[]>>;
  onBatchDeleteCreators?: (creatorIds: string[]) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'error' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  getManagerPerms?: () => any;
  rosterProfileSubmissions?: RosterProfileSubmission[];
  setRosterProfileSubmissions?: React.Dispatch<React.SetStateAction<RosterProfileSubmission[]>>;
  onApproveRosterProfile?: (submissionId: string) => void;
}

// Utility: Follower Reach Parser
export function parseFollowerCount(followersStr: string | number | undefined): number {
  if (typeof followersStr === 'number') return followersStr;
  if (!followersStr) return 0;
  const clean = String(followersStr).trim().toUpperCase();
  const num = parseFloat(clean.replace(/[^0-9.]/g, '')) || 0;
  if (clean.includes('B')) return num * 1_000_000_000;
  if (clean.includes('M')) return num * 1_000_000;
  if (clean.includes('K')) return num * 1_000;
  return num;
}

export function formatFollowerCount(followers: string | number | undefined): string {
  const num = parseFollowerCount(followers);
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  if (num >= 1_000) return `${(num / 1_000).toFixed(1).replace(/\.0$/, '')}K`;
  return num.toLocaleString();
}

export function getFollowerReachTier(followers: string | number | undefined): {
  tier: 'Macro' | 'Mid-Tier' | 'Micro' | 'Nano';
  badgeClass: string;
} {
  const num = parseFollowerCount(followers);
  if (num >= 1_000_000) {
    return { tier: 'Macro', badgeClass: 'bg-purple-500/20 text-purple-300 border-purple-500/40' };
  } else if (num >= 100_000) {
    return { tier: 'Mid-Tier', badgeClass: 'bg-blue-500/20 text-blue-300 border-blue-500/40' };
  } else if (num >= 10_000) {
    return { tier: 'Micro', badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' };
  } else {
    return { tier: 'Nano', badgeClass: 'bg-slate-700 text-slate-300 border-slate-600' };
  }
}

// Utility: Engagement Rate Parser & Smart Engagement Classification
export function parseEngagementRate(engStr: string | number | undefined): number {
  if (typeof engStr === 'number') return engStr;
  if (!engStr) return 0;
  const clean = String(engStr).trim();
  const num = parseFloat(clean.replace(/[^0-9.]/g, '')) || 0;
  return num;
}

export type SmartEngTier = 'viral' | 'high' | 'standard' | 'low';

export function getSmartEngagementInfo(rateInput: number | string): {
  tier: SmartEngTier;
  label: string;
  badgeText: string;
  badgeClass: string;
  borderClass: string;
  icon: string;
  deltaVsBenchmark: string;
} {
  const rate = typeof rateInput === 'number' ? rateInput : parseEngagementRate(rateInput);
  // Baseline agency benchmark = 3.5%
  const benchmark = 3.5;
  const delta = rate - benchmark;
  const deltaStr = delta >= 0 ? `+${delta.toFixed(1)}%` : `${delta.toFixed(1)}%`;

  if (rate >= 6.0) {
    return {
      tier: 'viral',
      label: 'Viral Tier',
      badgeText: '🔥 Viral Tier',
      badgeClass: 'bg-gradient-to-r from-amber-500/25 to-rose-500/25 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/10',
      borderClass: 'border-amber-500/40',
      icon: '🔥',
      deltaVsBenchmark: `${deltaStr} vs 3.5% avg`
    };
  } else if (rate >= 4.0) {
    return {
      tier: 'high',
      label: 'High Performer',
      badgeText: '⭐ High Performer',
      badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      borderClass: 'border-emerald-500/30',
      icon: '⭐',
      deltaVsBenchmark: `${deltaStr} vs 3.5% avg`
    };
  } else if (rate >= 2.5) {
    return {
      tier: 'standard',
      label: 'Solid Standard',
      badgeText: '⚡ Solid Standard',
      badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
      borderClass: 'border-sky-500/30',
      icon: '⚡',
      deltaVsBenchmark: `${deltaStr} vs 3.5% avg`
    };
  } else {
    return {
      tier: 'low',
      label: 'Underperforming',
      badgeText: '⚠️ Low Engagement',
      badgeClass: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
      borderClass: 'border-rose-500/30',
      icon: '⚠️',
      deltaVsBenchmark: `${deltaStr} vs 3.5% avg`
    };
  }
}

// Niche Styling & Icon Mapping
export const NICHE_META: Record<string, { icon: string; color: string; bg: string; border: string }> = {
  'Pets': { icon: '🐾', color: 'text-emerald-300', bg: 'bg-emerald-950/60', border: 'border-emerald-500/40' },
  'Beauty': { icon: '💄', color: 'text-pink-300', bg: 'bg-pink-950/60', border: 'border-pink-500/40' },
  'Lifestyle': { icon: '✨', color: 'text-amber-300', bg: 'bg-amber-950/60', border: 'border-amber-500/40' },
  'Fashion': { icon: '👗', color: 'text-purple-300', bg: 'bg-purple-950/60', border: 'border-purple-500/40' },
  'Fitness': { icon: '🏋️', color: 'text-orange-300', bg: 'bg-orange-950/60', border: 'border-orange-500/40' },
  'Tech': { icon: '💻', color: 'text-cyan-300', bg: 'bg-cyan-950/60', border: 'border-cyan-500/40' },
  'Gaming': { icon: '🎮', color: 'text-indigo-300', bg: 'bg-indigo-950/60', border: 'border-indigo-500/40' },
  'Food & Cooking': { icon: '🍳', color: 'text-agency-gold', bg: 'bg-amber-950/60', border: 'border-[#C9A46A]/40' },
  'Travel': { icon: '✈️', color: 'text-teal-300', bg: 'bg-teal-950/60', border: 'border-teal-500/40' },
  'Other': { icon: '🏷️', color: 'text-slate-300', bg: 'bg-slate-900/60', border: 'border-slate-600' }
};

export function getNicheBadge(nicheName: string): {
  icon: string;
  color: string;
  bg: string;
  border: string;
  badgeClass: string;
} {
  const norm = nicheName?.trim() || 'Other';
  const meta = NICHE_META[norm] || {
    icon: '🏷️',
    color: 'text-amber-200',
    bg: 'bg-amber-950/40',
    border: 'border-amber-500/30'
  };
  return {
    ...meta,
    badgeClass: `${meta.bg} ${meta.color} ${meta.border}`
  };
}

export type RosterSortField = 
  | 'niche'
  | 'followers-desc'
  | 'followers-asc'
  | 'eng-desc'
  | 'eng-asc'
  | 'platform'
  | 'representation'
  | 'agent'
  | 'name-asc'
  | 'name-desc'
  | 'status';

export default function CreatorRosterManager({
  creators,
  setCreators,
  currentRole,
  currentUser,
  isRestrictedRole,
  isAgentMgr,
  myHandles,
  primaryBrandColor = '#C9A46A',
  onSelectCreatorForDetail,
  onDeleteCreator,
  onUpdateCreatorStatus,
  onExportCSV,
  onOpenQuickAddModal,
  onOpenLogDealModal,
  onOpenLaunchMission,
  onAssignAgent,
  rosterViewMode,
  setRosterViewMode,
  showRosterCharts,
  setShowRosterCharts,
  selectedCreatorIds,
  setSelectedCreatorIds,
  onBatchDeleteCreators,
  triggerNotification,
  onAddActivityLog,
  getManagerPerms,
  rosterProfileSubmissions,
  setRosterProfileSubmissions,
  onApproveRosterProfile
}: CreatorRosterManagerProps) {
  // --- Search & Filters State ---
  const [searchQuery, setSearchQuery] = useState('');
  const [nicheFilter, setNicheFilter] = useState<string>('all');
  const [smartEngFilter, setSmartEngFilter] = useState<'all' | 'viral' | 'high' | 'standard' | 'low'>('all');
  const [platformFilter, setPlatformFilter] = useState<string>('all');
  const [representationFilter, setRepresentationFilter] = useState<string>('all');
  const [agentFilter, setAgentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<RosterSortField>('niche');

  // --- Share Showcase Modal State ---
  const [showShareShowcaseModal, setShowShareShowcaseModal] = useState(false);

  // --- Dynamic Niches Management ---
  const { strictCoreOnly, setStrictCoreOnly, activeNiches } = useAgencyNiches();
  const isDirector = (currentRole || '').toLowerCase() === 'director';
  const DEFAULT_NICHES = ['Pets', 'Beauty', 'Lifestyle', 'Fashion', 'Fitness', 'Tech', 'Gaming'];
  const [customNiches, setCustomNiches] = useState<string[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_agency_niches');
      return saved ? JSON.parse(saved) : DEFAULT_NICHES;
    } catch {
      return DEFAULT_NICHES;
    }
  });

  useEffect(() => {
    try {
      safeStorage.setItem('wl_agency_niches', JSON.stringify(customNiches));
    } catch {}
  }, [customNiches]);

  // Submissions State with persistence and initial seed for signed creators
  const [localSubmissions, setLocalSubmissions] = useState<RosterProfileSubmission[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_roster_profile_submissions');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to parse wl_roster_profile_submissions', e);
    }
    return [
      {
        id: 'sub_charli_01',
        creatorId: 'c_charli',
        creatorName: "Charli D'Amelio",
        creatorHandle: '@charlidamelio',
        email: 'charli@damelioent.com',
        phone: '(310) 890-4421',
        platform: 'TikTok & IG',
        niche: 'Beauty & Lifestyle',
        secondaryInterests: 'Dance, Teen Beauty, Athleisure, Beverage Brands',
        bio: 'Digital content pioneer and top creator with over 150M global reach. Focused on high-engagement beauty routines, dance collaborations, and premium lifestyle partnerships.',
        tiktok: 'https://tiktok.com/@charlidamelio',
        instagram: 'https://instagram.com/charlidamelio',
        youtube: 'https://youtube.com/@charlidamelio',
        preferredBrands: 'Dunkin, Morphe, Prada, Hollister, Target, Lululemon, Glossier',
        excludedBrands: 'Fast Fashion, Off-Brand Energy Drinks, Unverified Crypto, Predatory Lending',
        contentPreferences: '60s TikTok Reels, High-production IG Carousel, YouTube Shorts & Vlog integration',
        availability: 'High (Open for Q3/Q4 Brand Activations)',
        q1Availability: 'Booked',
        q2Availability: 'Booked',
        q3Availability: 'Available',
        q4Availability: 'Available',
        paymentMethod: 'Agency Debit Card',
        paymentDetails: 'Agency Visa Debit (•••• 8821) - Stripe Issuing',
        cardholderLegalName: "Charli Grace D'Amelio",
        stripeCardLast4: '8821',
        stripeCardStatus: 'Active',
        stripeCardExpiry: '08/28',
        tier: 'Diamond Elite Tier',
        assignedAgent: 'Marcus Cole',
        assignedManager: 'Senior Agent Manager',
        assignedCoordinator: 'Campaign Lead',
        submittedAt: 'Today at 02:45 PM',
        timestamp: Date.now() - 3600000,
        status: 'Pending Review',
        targetAudience: 'Director, Agent & Agent Managers'
      },
      {
        id: 'sub_jiffpom_01',
        creatorId: 'c_jiffpom',
        creatorName: 'Jiffpom',
        creatorHandle: '@jiffpom',
        email: 'press@jiffpom.com',
        phone: '(310) 414-9920',
        platform: 'TikTok & IG',
        niche: 'Pets',
        secondaryInterests: 'Pet Wellness, Organic Treats, Luxury Pet Apparel, Family Entertainment',
        bio: 'Guinness World Record holding Pomeranian sensation with 30M+ cross-platform family audience. Iconic lifestyle campaigns with top global family & pet brands.',
        tiktok: 'https://tiktok.com/@jiffpom',
        instagram: 'https://instagram.com/jiffpom',
        youtube: 'https://youtube.com/@jiffpom',
        preferredBrands: 'Chewy, BarkBox, Petco, Disney, Target Pet, Royal Canin',
        excludedBrands: 'Non-Organic Treats, Rawhide Chews, Non-Pet Friendly Cleaning',
        contentPreferences: 'Short-form comedic skits, Pet product unboxing, Cute lifestyle reels',
        availability: 'High (Open for Q3 Pet Wellness)',
        q1Availability: 'Booked',
        q2Availability: 'Available',
        q3Availability: 'Available',
        q4Availability: 'Available',
        paymentMethod: 'Agency Debit Card',
        paymentDetails: 'Agency Visa Debit (•••• 3419) - Stripe Issuing',
        cardholderLegalName: 'Jiffpom Ent LLC',
        stripeCardLast4: '3419',
        stripeCardStatus: 'Active',
        stripeCardExpiry: '11/27',
        tier: 'Diamond Elite Tier',
        assignedAgent: 'Marcus Cole',
        assignedManager: 'Senior Agent Manager',
        assignedCoordinator: 'Campaign Lead',
        submittedAt: 'Yesterday at 04:15 PM',
        timestamp: Date.now() - 86400000,
        status: 'Director Approved',
        reviewedBy: 'Director',
        reviewDate: '2026-08-07',
        targetAudience: 'Director, Agent & Agent Managers'
      },
      {
        id: 'sub_noahbeck_01',
        creatorId: 'c_noahbeck',
        creatorName: 'Noah Beck',
        creatorHandle: '@noahbeck',
        email: 'mgmt@noahbeck.la',
        phone: '(310) 555-8833',
        platform: 'TikTok & IG',
        niche: 'Fitness & Lifestyle',
        secondaryInterests: 'Men\'s Grooming, Soccer, Luxury Travel, High Fashion',
        bio: 'Premier athlete & lifestyle tastemaker connecting sports, luxury men\'s grooming, and high-fashion editorial campaigns.',
        tiktok: 'https://tiktok.com/@noahbeck',
        instagram: 'https://instagram.com/noahbeck',
        youtube: 'https://youtube.com/@noahbeck',
        preferredBrands: 'Calvin Klein, Ralph Lauren, Theragun, Equinox, Nike, Alo Men',
        excludedBrands: 'Unregulated Supplements, Quick Weight Loss Gimmicks, Shady Betting',
        contentPreferences: 'High-energy fitness shorts, Grooming morning routine, Fashion fit-checks',
        availability: 'Limited (3 Campaign Slots for Q3)',
        q1Availability: 'Booked',
        q2Availability: 'Booked',
        q3Availability: 'Limited',
        q4Availability: 'Available',
        paymentMethod: 'Agency Debit Card',
        paymentDetails: 'Agency Visa Debit (•••• 9920) - Stripe Issuing',
        cardholderLegalName: 'Noah Beck Media Inc',
        stripeCardLast4: '9920',
        stripeCardStatus: 'Active',
        stripeCardExpiry: '05/29',
        tier: 'Gold Certified Tier',
        assignedAgent: 'Rachel Sterling',
        assignedManager: 'Senior Agent Manager',
        assignedCoordinator: 'Campaign Lead',
        submittedAt: 'Today at 11:20 AM',
        timestamp: Date.now() - 14400000,
        status: 'Pending Review',
        targetAudience: 'Director, Agent & Agent Managers'
      },
      {
        id: 'sub_alixearle_01',
        creatorId: 'c_alixearle',
        creatorName: 'Alix Earle',
        creatorHandle: '@alixearle',
        email: 'alix@earleagency.com',
        phone: '(305) 771-4402',
        platform: 'TikTok & IG',
        niche: 'Beauty & Lifestyle',
        secondaryInterests: 'Get Ready With Me (GRWM), College Lifestyle, Travel, Fashion Week',
        bio: 'Viral beauty sensation and podcast host known for unfiltered, authentic storytelling, GRWM routines, and high-converting product integrations.',
        tiktok: 'https://tiktok.com/@alixearle',
        instagram: 'https://instagram.com/alixearle',
        youtube: 'https://youtube.com/@alixearle',
        preferredBrands: 'Benefit Cosmetics, Tarte, Rare Beauty, Revolve, Amazon Style, Poppi',
        excludedBrands: 'Knockoff Cosmetics, Extreme Diets, Untested Skincare, Low-tier dropshipping',
        contentPreferences: 'Authentic unfiltered GRWM, Multi-product makeup reviews, Lifestyle travel vlogs',
        availability: 'Selective (High Value Brand Exclusives)',
        q1Availability: 'Booked',
        q2Availability: 'Booked',
        q3Availability: 'Available',
        q4Availability: 'Available',
        paymentMethod: 'Agency Debit Card',
        paymentDetails: 'Agency Visa Debit (•••• 5512) - Stripe Issuing',
        cardholderLegalName: 'Alix Earle Productions',
        stripeCardLast4: '5512',
        stripeCardStatus: 'Active',
        stripeCardExpiry: '09/28',
        tier: 'Diamond Elite Tier',
        assignedAgent: 'Marcus Cole',
        assignedManager: 'Senior Agent Manager',
        assignedCoordinator: 'Campaign Lead',
        submittedAt: 'Today at 09:10 AM',
        timestamp: Date.now() - 25000000,
        status: 'Agent Assigned',
        targetAudience: 'Director, Agent & Agent Managers'
      }
    ];
  });

  const effectiveSubmissions = rosterProfileSubmissions || localSubmissions;

  useEffect(() => {
    if (!rosterProfileSubmissions) {
      try {
        safeStorage.setItem('wl_roster_profile_submissions', JSON.stringify(localSubmissions));
      } catch {}
    }
  }, [localSubmissions, rosterProfileSubmissions]);

  // Profile Submissions Filter & Dossier Modal State
  const [submissionStatusFilter, setSubmissionStatusFilter] = useState<string>('All');
  const [submissionNicheFilter, setSubmissionNicheFilter] = useState<string>('All');
  const [submissionSearch, setSubmissionSearch] = useState<string>('');
  const [selectedSubmissionForDetail, setSelectedSubmissionForDetail] = useState<RosterProfileSubmission | null>(null);
  const [activeDossierTab, setActiveDossierTab] = useState<'overview' | 'brandFit' | 'socials' | 'financial' | 'availability'>('overview');
  const [assignAgentModalSub, setAssignAgentModalSub] = useState<RosterProfileSubmission | null>(null);
  const [assignSelectedAgentName, setAssignSelectedAgentName] = useState<string>('Marcus Cole');
  const [assignSelectedManagerName, setAssignSelectedManagerName] = useState<string>('Senior Agent Manager');

  // Modal for Adding a New Niche (available when director enables extended niches)
  const [showAddNicheModal, setShowAddNicheModal] = useState(false);
  const [newNicheName, setNewNicheName] = useState('');
  const [newNicheEmoji, setNewNicheEmoji] = useState('✨');

  // Inline Quick Niche Edit
  const [editingNicheCreatorId, setEditingNicheCreatorId] = useState<string | null>(null);

  // Director Creator Status & Reason Control Modal State
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [selectedCreatorForStatus, setSelectedCreatorForStatus] = useState<Creator | null>(null);
  const [statusFormValue, setStatusFormValue] = useState<string>('Active');
  const [statusFormDate, setStatusFormDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [statusFormReason, setStatusFormReason] = useState<string>('');

  const handleOpenStatusModal = (creator: Creator) => {
    setSelectedCreatorForStatus(creator);
    setStatusFormValue(creator.status === 'Active' ? 'Active' : (creator.status || 'Not Active'));
    setStatusFormDate(creator.statusChangeDate || new Date().toISOString().split('T')[0]);
    setStatusFormReason(creator.statusChangeReason || '');
    setShowStatusModal(true);
  };

  const handleSaveStatusForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCreatorForStatus) return;
    if (!statusFormReason.trim()) {
      if (triggerNotification) {
        triggerNotification('Reason Required', 'Please enter a brief explanation for why this creator is being marked as ' + statusFormValue + '.', 'warning');
      }
      return;
    }

    const creatorId = selectedCreatorForStatus.id;
    const effectiveDate = statusFormDate || new Date().toISOString().split('T')[0];
    const reasonText = statusFormReason.trim();
    const newStatus = statusFormValue;
    const author = currentUser?.name || 'User';

    // Optimistically update local creators state
    setCreators(prev => prev.map(c => {
      if (c.id === creatorId) {
        const historyItem = {
          id: 'sh_' + Date.now(),
          status: newStatus,
          date: effectiveDate,
          reason: reasonText,
          changedBy: author,
          timestamp: new Date().toISOString()
        };
        return {
          ...c,
          status: newStatus,
          statusChangeDate: effectiveDate,
          statusChangeReason: reasonText,
          statusChangeAuthor: author,
          statusHistory: [...(c.statusHistory || []), historyItem]
        };
      }
      return c;
    }));

    // Call prop handler to update parent and Firestore
    onUpdateCreatorStatus(creatorId, newStatus, effectiveDate, reasonText);

    if (triggerNotification) {
      triggerNotification(
        'Creator Status Updated',
        `${selectedCreatorForStatus.name} (${selectedCreatorForStatus.handle}) is now ${newStatus}. Date: ${effectiveDate}`,
        'success'
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        author,
        typeof currentRole === 'string' ? currentRole : 'none',
        `Updated ${selectedCreatorForStatus.name} (${selectedCreatorForStatus.handle}) to "${newStatus}" on ${effectiveDate}. Reason: ${reasonText}`
      );
    }

    setShowStatusModal(false);
    setSelectedCreatorForStatus(null);
  };

  // Submissions Actions & Multi-Role Dispatch Handlers
  const handleApproveSubmission = (subId: string) => {
    const reviewer = currentUser?.name || 'User';
    const todayStr = new Date().toISOString().split('T')[0];
    
    if (setRosterProfileSubmissions) {
      setRosterProfileSubmissions(prev => prev.map(s => s.id === subId ? {
        ...s,
        status: 'Director Approved',
        reviewedBy: reviewer,
        reviewDate: todayStr
      } : s));
    }
    setLocalSubmissions(prev => prev.map(s => s.id === subId ? {
      ...s,
      status: 'Director Approved',
      reviewedBy: reviewer,
      reviewDate: todayStr
    } : s));

    if (onApproveRosterProfile) {
      onApproveRosterProfile(subId);
    }

    const targetSub = effectiveSubmissions.find(s => s.id === subId);
    if (targetSub) {
      if (triggerNotification) {
        triggerNotification(
          '✅ Profile Approved by Director',
          `Creator profile for ${targetSub.creatorName} (${targetSub.creatorHandle}) has been approved and unlocked for brand pitch deals.`,
          'success'
        );
      }
      if (onAddActivityLog) {
        onAddActivityLog(
          reviewer,
          typeof currentRole === 'string' ? currentRole : 'none',
          `Director approved creator roster profile & brand preferences for ${targetSub.creatorName} (${targetSub.creatorHandle})`
        );
      }
    }
  };

  const handleAssignAgentToSubmission = (subId: string, agentName: string, managerName: string) => {
    if (setRosterProfileSubmissions) {
      setRosterProfileSubmissions(prev => prev.map(s => s.id === subId ? {
        ...s,
        assignedAgent: agentName,
        assignedManager: managerName,
        status: 'Agent Assigned'
      } : s));
    }
    setLocalSubmissions(prev => prev.map(s => s.id === subId ? {
      ...s,
      assignedAgent: agentName,
      assignedManager: managerName,
      status: 'Agent Assigned'
    } : s));

    const targetSub = effectiveSubmissions.find(s => s.id === subId);
    if (targetSub) {
      if (triggerNotification) {
        triggerNotification(
          '👤 Agent Assigned to Profile',
          `Assigned ${agentName} (Agent) and ${managerName} (Manager) to manage ${targetSub.creatorName}'s roster profile.`,
          'info'
        );
      }
      if (onAddActivityLog) {
        onAddActivityLog(
          currentUser?.name || 'User',
          typeof currentRole === 'string' ? currentRole : 'none',
          `Assigned Agent ${agentName} to ${targetSub.creatorName}'s profile submission`
        );
      }
    }
    setAssignAgentModalSub(null);
  };

  const handleArchiveSubmission = (subId: string) => {
    if (setRosterProfileSubmissions) {
      setRosterProfileSubmissions(prev => prev.filter(s => s.id !== subId));
    }
    setLocalSubmissions(prev => prev.filter(s => s.id !== subId));
    if (triggerNotification) {
      triggerNotification('Submission Archived', 'Creator profile submission has been archived.', 'info');
    }
  };

  const handleSimulateNewSubmission = () => {
    const randomHandles = ['@brookemonk', '@khaby.lame', '@lexirivera', '@lorengray'];
    const chosen = randomHandles[Math.floor(Math.random() * randomHandles.length)];
    const cleanName = chosen.replace('@', '').replace('.', ' ').toUpperCase();
    const newSub: RosterProfileSubmission = {
      id: 'sub_sim_' + Date.now(),
      creatorId: 'c_' + chosen.replace('@', '').replace('.', ''),
      creatorName: cleanName,
      creatorHandle: chosen,
      email: `${chosen.replace('@', '').replace('.', '')}@talentmail.com`,
      phone: '(310) 555-' + Math.floor(1000 + Math.random() * 9000),
      platform: 'TikTok & IG',
      niche: 'Beauty & Lifestyle',
      secondaryInterests: 'Viral Comedy, High Fashion, Beauty Hauls',
      bio: `Top verified creator with dedicated global following, high viral index, and authentic community engagement.`,
      tiktok: `https://tiktok.com/${chosen}`,
      instagram: `https://instagram.com/${chosen.replace('@', '')}`,
      preferredBrands: 'Rare Beauty, Glossier, Revolve, Target, Celsius',
      excludedBrands: 'Fast Fashion, Gambling, Predatory Apps',
      contentPreferences: '60s TikTok UGC, Lifestyle Vlogs, GRWM routines',
      availability: 'High (Open for Q3 Sponsorships)',
      q1Availability: 'Booked',
      q2Availability: 'Booked',
      q3Availability: 'Available',
      q4Availability: 'Available',
      paymentMethod: 'Agency Debit Card',
      paymentDetails: `Agency Visa Debit (•••• ${Math.floor(1000 + Math.random() * 9000)}) - Stripe Issuing`,
      stripeCardLast4: String(Math.floor(1000 + Math.random() * 9000)),
      stripeCardStatus: 'Active',
      stripeCardExpiry: '12/28',
      tier: 'Diamond Elite Tier',
      assignedAgent: 'Marcus Cole',
      assignedManager: 'Senior Agent Manager',
      assignedCoordinator: 'Campaign Lead',
      submittedAt: `Today at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      timestamp: Date.now(),
      status: 'Pending Review',
      targetAudience: 'Director, Agent & Agent Managers'
    };

    if (setRosterProfileSubmissions) {
      setRosterProfileSubmissions(prev => [newSub, ...prev]);
    }
    setLocalSubmissions(prev => [newSub, ...prev]);

    if (triggerNotification) {
      triggerNotification(
        '📋 New Profile Submission Received',
        `Inbound profile submission from ${newSub.creatorName} (${newSub.creatorHandle}) received and delivered to Director, Agent & Agent Managers.`,
        'success'
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        newSub.creatorName,
        'creator',
        `Submitted new creator roster profile & brand preferences (Transmitted to Director, Agent & Agent Managers)`
      );
    }
  };

  const pendingSubmissionsCount = effectiveSubmissions.filter(s => s.status === 'Pending Review').length;
  const approvedSubmissionsCount = effectiveSubmissions.filter(s => s.status === 'Director Approved').length;
  const assignedSubmissionsCount = effectiveSubmissions.filter(s => s.status === 'Agent Assigned').length;
  const cardsSubmissionsCount = effectiveSubmissions.filter(s => s.stripeCardLast4).length;

  const filteredSubmissions = useMemo(() => {
    return effectiveSubmissions.filter(s => {
      if (isRestrictedRole && myHandles.length > 0) {
        const isMine = myHandles.includes(s.creatorHandle.toLowerCase()) || 
                       (s.assignedAgent && s.assignedAgent.toLowerCase().includes((currentUser?.name || '').toLowerCase()));
        if (!isMine) return false;
      }
      if (submissionStatusFilter !== 'All' && s.status !== submissionStatusFilter) {
        return false;
      }
      if (submissionNicheFilter !== 'All' && !s.niche.toLowerCase().includes(submissionNicheFilter.toLowerCase())) {
        return false;
      }
      if (submissionSearch.trim()) {
        const q = submissionSearch.toLowerCase();
        const match = s.creatorName.toLowerCase().includes(q) ||
                      s.creatorHandle.toLowerCase().includes(q) ||
                      s.niche.toLowerCase().includes(q) ||
                      (s.preferredBrands || '').toLowerCase().includes(q) ||
                      (s.excludedBrands || '').toLowerCase().includes(q) ||
                      (s.bio || '').toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [effectiveSubmissions, isRestrictedRole, myHandles, currentUser, submissionStatusFilter, submissionNicheFilter, submissionSearch]);

  // Filter Scoped Creators based on user role (e.g. subagency / coordinator / agent pod isolation)
  const scopedCreators = useMemo(() => {
    if (currentRole === 'subagency') {
      const normSub = (currentUser?.subagency || currentUser?.name || 'Bloom & Co').toLowerCase();
      return creators.filter(c => 
        (c.subagency && c.subagency.toLowerCase().includes(normSub)) ||
        (c.agency && c.agency.toLowerCase().includes(normSub)) ||
        (normSub.includes('bloom') && (c.subagency?.toLowerCase().includes('bloom') || c.agency?.toLowerCase().includes('bloom'))) ||
        (normSub.includes('viral') && (c.subagency?.toLowerCase().includes('viral') || c.agency?.toLowerCase().includes('viral')))
      );
    }
    if (currentRole === 'coordinator') {
      const coordName = (currentUser?.name || '').toLowerCase().trim();
      // Filter strictly to creators assigned to this coordinator (only show who they are working with)
      const assigned = creators.filter(c => {
        const cCoord = (c.assignedCoordinator || (c as any).coordinator || '').toLowerCase().trim();
        return cCoord && (
          cCoord.includes(coordName) ||
          (coordName && coordName.includes(cCoord))
        );
      });
      return assigned;
    }
    if (isAgentMgr || currentRole === 'agentmgr' || currentRole === 'agent') {
      const mgrName = (currentUser?.name || '').toLowerCase().trim();
      return creators.filter(c => {
        const agName = (c.assignedAgent || '').toLowerCase().trim();
        const mName = (c.assignedManager || '').toLowerCase().trim();
        const isAssigned = (agName && (agName.includes(mgrName) || mgrName.includes(agName))) ||
                           (mName && (mName.includes(mgrName) || mgrName.includes(mName)));
        const isHandle = myHandles.length > 0 && myHandles.includes(c.handle.toLowerCase());
        return isAssigned || isHandle;
      });
    }
    return creators.filter(c => !isRestrictedRole || myHandles.includes(c.handle.toLowerCase()));
  }, [creators, currentRole, currentUser, isRestrictedRole, myHandles]);

  // Extract all existing unique niches from data
  const allUniqueNiches = useMemo(() => {
    if (strictCoreOnly) {
      return ['Pets', 'Beauty', 'Lifestyle'];
    }
    const nicheSet = new Set<string>(customNiches);
    scopedCreators.forEach(c => {
      if (c.niche && c.niche.trim()) {
        nicheSet.add(c.niche.trim());
      }
    });
    return Array.from(nicheSet);
  }, [strictCoreOnly, customNiches, scopedCreators]);

  // Extract all unique agents
  const allAgents = useMemo(() => {
    const agentSet = new Set<string>();
    scopedCreators.forEach(c => {
      if (c.assignedAgent && c.assignedAgent.trim()) {
        agentSet.add(c.assignedAgent.trim());
      }
    });
    return Array.from(agentSet);
  }, [scopedCreators]);

  // Extract all unique representation / agreement types
  const allAgreements = useMemo(() => {
    const agSet = new Set<string>();
    scopedCreators.forEach(c => {
      if (c.agreement && c.agreement.trim()) {
        agSet.add(c.agreement.trim());
      }
    });
    return Array.from(agSet);
  }, [scopedCreators]);

  // Handler to add a new custom niche
  const handleAddNewNiche = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newNicheName.trim();
    if (!trimmed) return;
    if (!customNiches.some(n => n.toLowerCase() === trimmed.toLowerCase())) {
      const updated = [...customNiches, trimmed];
      setCustomNiches(updated);
      NICHE_META[trimmed] = {
        icon: newNicheEmoji || '🏷️',
        color: 'text-amber-300',
        bg: 'bg-amber-950/60',
        border: 'border-amber-500/40'
      };
      if (triggerNotification) {
        triggerNotification('New Niche Added', `Niche "${trimmed}" is now available for all creator profiles & filters.`, 'success');
      }
      if (onAddActivityLog) {
        onAddActivityLog(currentUser?.name || 'User', currentRole, `Added new agency niche: ${trimmed}`);
      }
    }
    setNicheFilter(trimmed);
    setNewNicheName('');
    setShowAddNicheModal(false);
  };

  // Quick Update Creator Niche
  const handleUpdateCreatorNiche = (creatorId: string, newNiche: string) => {
    setCreators(prev => prev.map(c => c.id === creatorId ? { ...c, niche: newNiche } : c));
    setEditingNicheCreatorId(null);
    if (triggerNotification) {
      triggerNotification('Niche Updated', `Updated creator niche to ${newNiche}.`, 'info');
    }
  };

  // Filtered & Sorted Creators
  const processedCreators = useMemo(() => {
    return scopedCreators
      .filter(c => {
        // Search query filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = c.name?.toLowerCase().includes(q);
          const matchHandle = c.handle?.toLowerCase().includes(q);
          const matchBio = c.bio?.toLowerCase().includes(q);
          const matchNiche = c.niche?.toLowerCase().includes(q);
          const matchAgent = c.assignedAgent?.toLowerCase().includes(q);
          const matchPlatform = c.platform?.toLowerCase().includes(q);
          if (!matchName && !matchHandle && !matchBio && !matchNiche && !matchAgent && !matchPlatform) {
            return false;
          }
        }

        // Niche filter
        if (nicheFilter !== 'all') {
          if (nicheFilter === 'Other') {
            const isStandard = ['Pets', 'Beauty', 'Lifestyle'].includes(c.niche);
            if (isStandard) return false;
          } else if ((c.niche || '').toLowerCase() !== nicheFilter.toLowerCase()) {
            return false;
          }
        }

        // Smart Engagement filter
        if (smartEngFilter !== 'all') {
          const engRate = parseEngagementRate(c.eng);
          const { tier } = getSmartEngagementInfo(engRate);
          if (tier !== smartEngFilter) return false;
        }

        // Platform filter
        if (platformFilter !== 'all') {
          if ((c.platform || '').toLowerCase() !== platformFilter.toLowerCase()) return false;
        }

        // Representation / Agreement filter
        if (representationFilter !== 'all') {
          if ((c.agreement || '').toLowerCase() !== representationFilter.toLowerCase()) return false;
        }

        // Agent filter
        if (agentFilter !== 'all') {
          if (agentFilter === 'unassigned') {
            if (c.assignedAgent && c.assignedAgent.trim() !== '') return false;
          } else if ((c.assignedAgent || '').toLowerCase() !== agentFilter.toLowerCase()) {
            return false;
          }
        }

        // Status filter
        if (statusFilter !== 'all') {
          const s = (c.status || 'Active').toLowerCase();
          const f = statusFilter.toLowerCase();
          if (f === 'active') {
            if (s !== 'active') return false;
          } else if (f === 'not active' || f === 'inactive') {
            if (s === 'active') return false;
          } else if (f === 'paused') {
            if (!s.includes('pause') && !s.includes('hiatus')) return false;
          } else if (f === 'offboarded') {
            if (!s.includes('offboard') && !s.includes('archive')) return false;
          } else if (f === 'risk') {
            if (!s.includes('risk')) return false;
          } else if (s !== f) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'niche': {
            // Sort primary niches (Pets -> Beauty -> Lifestyle) then alphabetically
            const priority: Record<string, number> = { 'pets': 1, 'beauty': 2, 'lifestyle': 3 };
            const pA = priority[(a.niche || '').toLowerCase()] || 99;
            const pB = priority[(b.niche || '').toLowerCase()] || 99;
            if (pA !== pB) return pA - pB;
            return (a.niche || '').localeCompare(b.niche || '');
          }
          case 'followers-desc':
            return parseFollowerCount(b.followers) - parseFollowerCount(a.followers);
          case 'followers-asc':
            return parseFollowerCount(a.followers) - parseFollowerCount(b.followers);
          case 'eng-desc':
            return parseEngagementRate(b.eng) - parseEngagementRate(a.eng);
          case 'eng-asc':
            return parseEngagementRate(a.eng) - parseEngagementRate(b.eng);
          case 'platform':
            return (a.platform || '').localeCompare(b.platform || '');
          case 'representation':
            return (a.agreement || '').localeCompare(b.agreement || '');
          case 'agent':
            return (a.assignedAgent || 'ZZZ').localeCompare(b.assignedAgent || 'ZZZ');
          case 'name-asc':
            return (a.name || '').localeCompare(b.name || '');
          case 'name-desc':
            return (b.name || '').localeCompare(a.name || '');
          case 'status':
            return (a.status || 'Active').localeCompare(b.status || 'Active');
          default:
            return 0;
        }
      });
  }, [
    scopedCreators, 
    searchQuery, 
    nicheFilter, 
    smartEngFilter, 
    platformFilter, 
    representationFilter, 
    agentFilter, 
    statusFilter, 
    sortBy
  ]);

  // Aggregate KPI metrics for visible roster
  const metrics = useMemo(() => {
    const total = processedCreators.length;
    let totalFollowers = 0;
    let totalEngSum = 0;
    let viralCount = 0;
    const nicheCounts: Record<string, number> = {};

    processedCreators.forEach(c => {
      totalFollowers += parseFollowerCount(c.followers);
      const rate = parseEngagementRate(c.eng);
      totalEngSum += rate;
      if (rate >= 6.0) viralCount++;
      const n = c.niche || 'Other';
      nicheCounts[n] = (nicheCounts[n] || 0) + 1;
    });

    const avgEng = total > 0 ? (totalEngSum / total).toFixed(1) : '0.0';
    
    // Find top niche
    let topNiche = 'None';
    let maxNicheCount = 0;
    Object.entries(nicheCounts).forEach(([n, count]) => {
      if (count > maxNicheCount) {
        maxNicheCount = count;
        topNiche = n;
      }
    });

    return {
      total,
      totalFollowers: formatFollowerCount(totalFollowers),
      avgEng,
      viralCount,
      topNiche
    };
  }, [processedCreators]);

  const hasActiveFilters = searchQuery !== '' || nicheFilter !== 'all' || smartEngFilter !== 'all' || platformFilter !== 'all' || representationFilter !== 'all' || agentFilter !== 'all' || statusFilter !== 'all';

  const handleResetFilters = () => {
    setSearchQuery('');
    setNicheFilter('all');
    setSmartEngFilter('all');
    setPlatformFilter('all');
    setRepresentationFilter('all');
    setAgentFilter('all');
    setStatusFilter('all');
    setSortBy('niche');
  };

  return (
    <div className="space-y-5 min-w-0 w-full font-sans">
      {/* 1. TOP HEADER & WORKSPACE TOOLBAR */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-300 shrink-0">
              <Users className="w-5 h-5 text-[#C9A46A]" />
            </div>
            <div>
              <h1 className="font-sans font-semibold text-2xl tracking-tight text-white flex items-center gap-2">
                Creator Roster
              </h1>
              <p className="text-xs text-[#7C8AA8]">
                Intelligent creator directory with niche sorting (Pets, Beauty, Lifestyle), follower reach, and smart engagement analytics
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          {/* View Mode Toggle: Table vs Heat Map vs Profiles & Submissions */}
          <div className="bg-[#0D1830] border border-white/10 p-1 rounded-xl inline-flex font-mono text-xs shadow-inner flex-wrap gap-1">
            <button
              id="btn-roster-view-table"
              onClick={() => setRosterViewMode('table')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                rosterViewMode === 'table' ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Roster Table</span>
            </button>
            <button
              id="btn-roster-view-heatmap"
              onClick={() => setRosterViewMode('heatmap')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                rosterViewMode === 'heatmap' ? 'bg-amber-500 text-slate-950 font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>🔥 Roster Heat Map</span>
            </button>
            <button
              id="btn-roster-view-profiles"
              onClick={() => setRosterViewMode('profiles')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                rosterViewMode === 'profiles' ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-sm' : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>📋 Roster Profiles &amp; Submissions</span>
              {pendingSubmissionsCount > 0 && (
                <span className="bg-amber-400 text-slate-950 text-[10px] font-bold px-1.5 py-0.5 rounded-full font-mono animate-pulse">
                  {pendingSubmissionsCount} New
                </span>
              )}
            </button>
          </div>

          {/* Toggle KPI Visual Charts */}
          <button
            id="btn-toggle-roster-charts"
            onClick={() => setShowRosterCharts(!showRosterCharts)}
            className={`px-3.5 py-2 rounded-xl font-semibold text-xs transition cursor-pointer flex items-center gap-1.5 border shadow-sm ${
              showRosterCharts 
                ? 'bg-[#16243F] text-amber-300 border-amber-500/30' 
                : 'bg-[#0D1830] text-slate-400 hover:text-white border-white/10'
            }`}
            title="Toggle visual analytics, niche distributions, and KPI charts"
          >
            <PieChart className="w-3.5 h-3.5" />
            <span>{showRosterCharts ? 'Hide KPI Charts' : 'Show KPI Charts'}</span>
          </button>

          {/* Share Showcase Link Button */}
          <button
            id="btn-share-showcase-link"
            onClick={() => {
              const url = `${typeof window !== 'undefined' ? window.location.origin : ''}/#showcase`;
              if (typeof navigator !== 'undefined' && navigator.clipboard) {
                navigator.clipboard.writeText(url).catch(() => {});
              }
              if (triggerNotification) {
                triggerNotification(
                  '🔗 Showcase Link Copied!',
                  `Agency Showcase URL copied to clipboard: ${url}. Send this to brands to share your live roster.`,
                  'success'
                );
              }
              setShowShareShowcaseModal(true);
            }}
            className="bg-[#112240] hover:bg-[#1A325C] text-[#D4AF37] border border-[#D4AF37]/50 px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md hover:shadow-amber-500/10"
            title="Copy & share public agency roster showcase link with brands"
          >
            <Globe className="w-4 h-4 text-[#D4AF37]" />
            <span>Share Showcase Link</span>
          </button>

          {/* Export CSV */}
          <button
            id="btn-export-roster-csv"
            onClick={onExportCSV}
            className="bg-[#111E33] hover:bg-[#16243F] text-emerald-400 border border-emerald-500/30 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            title="Download Roster CSV spreadsheet"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export CSV</span>
          </button>

          {/* Role Action: Log Campaign */}
          {(!isRestrictedRole || (isAgentMgr && getManagerPerms && getManagerPerms().canLogCampaigns)) && (
            <button 
              id="btn-log-campaign-roster"
              onClick={onOpenLogDealModal}
              className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            >
              <DollarSign className="w-4 h-4" /> Log Deal
            </button>
          )}

          {/* Role Action: Launch Mission */}
          {(!isRestrictedRole || (isAgentMgr && getManagerPerms && getManagerPerms().canCreateMissions)) && (
            <button 
              id="btn-launch-mission-roster"
              onClick={onOpenLaunchMission}
              className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
            >
              <Target className="w-4 h-4" /> Mission
            </button>
          )}

          {/* Sign New Creator */}
          {(!isRestrictedRole || isAgentMgr) && (
            <button 
              id="btn-sign-new-creator"
              onClick={onOpenQuickAddModal}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg"
            >
              <Plus className="w-4 h-4" /> {(currentRole === 'agent' || currentRole === 'agentmgr') ? 'Suggest Creator' : 'Sign Creator'}
            </button>
          )}
        </div>
      </div>

      {/* 2. SUMMARY KPI METRIC STRIP */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="bg-[#0D1830] border border-white/10 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-[#7C8AA8] uppercase tracking-wider block">Visible Talent</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-white font-serif">{metrics.total}</span>
            <span className="text-[11px] text-slate-400">creators</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-white/10 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-[#7C8AA8] uppercase tracking-wider block">Total Follower Reach</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-amber-300 font-serif">{metrics.totalFollowers}</span>
            <span className="text-[11px] text-slate-400">audience</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-white/10 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-[#7C8AA8] uppercase tracking-wider block">Avg Engagement</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-emerald-400 font-serif">{metrics.avgEng}%</span>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1 rounded font-mono">Healthy</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-white/10 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-[#7C8AA8] uppercase tracking-wider block">Top Niche</span>
          <div className="flex items-center gap-1.5 truncate">
            <span className="text-base">{getNicheBadge(metrics.topNiche).icon}</span>
            <span className="text-sm font-bold text-white truncate">{metrics.topNiche}</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-white/10 rounded-xl p-3.5 space-y-1 col-span-2 sm:col-span-1">
          <span className="text-[10px] font-mono text-[#7C8AA8] uppercase tracking-wider block">Viral Tier (&gt;6% Eng)</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-rose-400 font-serif">{metrics.viralCount}</span>
            <span className="text-[11px] text-amber-300/80 font-mono">🔥 High converting</span>
          </div>
        </div>
      </div>

      {/* 3. NICHE FILTER PILL BAR WITH CORE FOCUS: PETS, BEAUTY, LIFESTYLE & DIRECTOR NON-CORE TOGGLE */}
      <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-3.5 shadow-md">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-white/5 pb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <Tag className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">Agency Niches</span>
            </div>
            <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-medium border flex items-center gap-1.5 ${
              strictCoreOnly 
                ? 'text-pink-300 bg-pink-950/50 border-pink-500/30' 
                : 'text-emerald-300 bg-emerald-950/50 border-emerald-500/30'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${strictCoreOnly ? 'bg-pink-400' : 'bg-emerald-400 animate-pulse'}`} />
              {strictCoreOnly 
                ? 'Strict Core Focus: Pets • Beauty • Lifestyle' 
                : 'Extended & Non-Core Categories Active'}
            </span>
          </div>

          <div className="flex items-center flex-wrap gap-2.5">
            {/* Director UI Toggle for Enabling/Disabling Non-Core Niche Categories */}
            {isDirector && (
              <div className="flex items-center gap-2 bg-[#111E33] border border-amber-500/30 rounded-xl px-3 py-1.5 shadow-inner">
                <span className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-wider hidden sm:inline">
                  Director Override:
                </span>
                <button
                  id="btn-director-toggle-noncore-niches"
                  onClick={() => {
                    const nextState = !strictCoreOnly;
                    setStrictCoreOnly(nextState);
                    if (triggerNotification) {
                      triggerNotification(
                        nextState ? '🔒 Core Niches Locked' : '✨ Non-Core Niches Enabled',
                        nextState 
                          ? 'Creator roster locked strictly to Bloom Studio core specialties: Pets, Beauty, and Lifestyle.' 
                          : 'Non-core categories (Fashion, Fitness, Tech, Gaming, Food, Travel, etc.) are now enabled across the agency.',
                        nextState ? 'info' : 'success'
                      );
                    }
                    if (onAddActivityLog) {
                      onAddActivityLog(
                        currentUser?.name || 'User', 
                        String(currentRole || 'none'), 
                        `Toggled Non-Core Agency Niches to ${nextState ? 'LOCKED (Strict Core Only)' : 'ENABLED'}`
                      );
                    }
                  }}
                  className={`text-xs font-semibold px-3 py-1 rounded-lg border transition cursor-pointer flex items-center gap-1.5 shadow-sm ${
                    strictCoreOnly
                      ? 'bg-amber-500/10 text-amber-300 border-amber-500/40 hover:bg-amber-500/20'
                      : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30 font-bold'
                  }`}
                  title={strictCoreOnly ? 'Click to enable non-core niche categories' : 'Click to lock strictly to Pets, Beauty, and Lifestyle'}
                >
                  <span className={`w-2 h-2 rounded-full ${strictCoreOnly ? 'bg-amber-400' : 'bg-emerald-400 animate-pulse'}`}></span>
                  <span>{strictCoreOnly ? 'Enable Non-Core Niches' : 'Disable Non-Core (Lock Core)'}</span>
                </button>
              </div>
            )}

            {!strictCoreOnly && (
              <button
                id="btn-add-custom-niche-modal"
                onClick={() => setShowAddNicheModal(true)}
                className="text-xs bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-xl font-semibold transition-colors cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Niche</span>
              </button>
            )}
          </div>
        </div>

        {/* Niche Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
          <button
            id="filter-niche-all"
            onClick={() => setNicheFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 border ${
              nicheFilter === 'all'
                ? 'bg-amber-500 text-slate-950 border-amber-500 font-bold shadow-sm'
                : 'bg-[#111E33] text-slate-300 border-white/10 hover:border-white/25 hover:text-white'
            }`}
          >
            <span>🌐 All Niches</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/30 font-mono">
              {scopedCreators.length}
            </span>
          </button>

          {/* Primary Core Niches: Pets, Beauty, Lifestyle */}
          {['Pets', 'Beauty', 'Lifestyle'].map(n => {
            const count = scopedCreators.filter(c => (c.niche || '').toLowerCase() === n.toLowerCase()).length;
            const meta = getNicheBadge(n);
            const isSelected = nicheFilter.toLowerCase() === n.toLowerCase();
            return (
              <button
                key={n}
                id={`filter-niche-${n.toLowerCase()}`}
                onClick={() => setNicheFilter(n)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 border ${
                  isSelected
                    ? 'bg-[#16243F] text-amber-300 border-amber-500 font-bold ring-1 ring-amber-500/50 shadow-md'
                    : 'bg-[#111E33] text-slate-200 border-white/10 hover:border-amber-500/40 hover:text-white'
                }`}
              >
                <span>{meta.icon}</span>
                <span>{n}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                  isSelected ? 'bg-amber-500/30 text-amber-200' : 'bg-black/30 text-slate-400'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}

          {/* Other / Additional Niches (Only when extended mode is enabled in director dash) */}
          {!strictCoreOnly && allUniqueNiches
            .filter(n => !['Pets', 'Beauty', 'Lifestyle'].includes(n))
            .map(n => {
              const count = scopedCreators.filter(c => (c.niche || '').toLowerCase() === n.toLowerCase()).length;
              const meta = getNicheBadge(n);
              const isSelected = nicheFilter.toLowerCase() === n.toLowerCase();
              return (
                <button
                  key={n}
                  id={`filter-niche-${n.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => setNicheFilter(n)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 border ${
                    isSelected
                      ? 'bg-[#16243F] text-amber-300 border-amber-500 font-bold ring-1 ring-amber-500/50'
                      : 'bg-[#111E33] text-slate-300 border-white/10 hover:border-white/20 hover:text-white'
                  }`}
                >
                  <span>{meta.icon}</span>
                  <span>{n}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected ? 'bg-amber-500/30 text-amber-200' : 'bg-black/30 text-slate-400'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
        </div>
      </div>

      {/* 4. COMPREHENSIVE FILTER & SORTING TOOLBAR */}
      <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-4 shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-3 items-center">
          {/* Search Input */}
          <div className="lg:col-span-4 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-roster-search"
              type="text"
              placeholder="Search creator, @handle, niche, bio, agent..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-slate-400 outline-none focus:border-amber-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Primary Sort Selector */}
          <div className="lg:col-span-3 space-y-1">
            <div className="flex items-center gap-1 text-[10px] font-mono text-[#7C8AA8] uppercase">
              <ArrowUpDown className="w-3 h-3 text-amber-400" />
              <span>Sort Creators By</span>
            </div>
            <select
              id="select-roster-sort"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as RosterSortField)}
              className="w-full bg-[#111E33] border border-amber-500/30 text-amber-200 rounded-xl px-3 py-1.5 text-xs font-semibold outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="niche" className="bg-[#0D1830] text-white">🗂️ Niche (Pets, Beauty, Lifestyle...)</option>
              <option value="followers-desc" className="bg-[#0D1830] text-white">👥 Follower Reach (Highest First)</option>
              <option value="followers-asc" className="bg-[#0D1830] text-white">👥 Follower Reach (Lowest First)</option>
              <option value="eng-desc" className="bg-[#0D1830] text-white">🔥 Engagement Rate (Highest First)</option>
              <option value="eng-asc" className="bg-[#0D1830] text-white">⚡ Engagement Rate (Lowest First)</option>
              <option value="platform" className="bg-[#0D1830] text-white">📱 Platform (TikTok, IG, YouTube)</option>
              <option value="representation" className="bg-[#0D1830] text-white">📜 Representation (Exclusive to Standard)</option>
              <option value="agent" className="bg-[#0D1830] text-white">👤 Assigned Agent (A to Z)</option>
              <option value="name-asc" className="bg-[#0D1830] text-white">🔤 Creator Name (A to Z)</option>
              <option value="status" className="bg-[#0D1830] text-white">🟢 Status (Active, Paused...)</option>
            </select>
          </div>

          {/* Smart Engagement Filter */}
          <div className="lg:col-span-3 space-y-1">
            <div className="flex items-center gap-1 text-[10px] font-mono text-[#7C8AA8] uppercase">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Smart Engagement Filter</span>
            </div>
            <select
              id="select-smart-engagement"
              value={smartEngFilter}
              onChange={(e) => setSmartEngFilter(e.target.value as any)}
              className={`w-full bg-[#111E33] border rounded-xl px-3 py-1.5 text-xs font-semibold outline-none focus:border-amber-500 cursor-pointer ${
                smartEngFilter !== 'all' ? 'border-amber-500 text-amber-300 bg-[#16243F]' : 'border-white/10 text-slate-200'
              }`}
            >
              <option value="all" className="bg-[#0D1830] text-white">All Engagement Tiers</option>
              <option value="viral" className="bg-[#0D1830] text-amber-300 font-bold">🔥 Viral Tier (&gt;6.0%)</option>
              <option value="high" className="bg-[#0D1830] text-emerald-300">⭐ High Performer (4.0% - 6.0%)</option>
              <option value="standard" className="bg-[#0D1830] text-sky-300">⚡ Solid Standard (2.5% - 4.0%)</option>
              <option value="low" className="bg-[#0D1830] text-rose-300">⚠️ Underperforming (&lt;2.5%)</option>
            </select>
          </div>

          {/* Reset Filters / Actions */}
          <div className="lg:col-span-2 flex items-center justify-end gap-2 pt-3 md:pt-0">
            {hasActiveFilters && (
              <button
                id="btn-reset-roster-filters"
                onClick={handleResetFilters}
                className="text-xs bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 px-3 py-2 rounded-xl transition cursor-pointer flex items-center gap-1 font-semibold"
                title="Reset all filters and sorting"
              >
                <X className="w-3.5 h-3.5" /> Clear ({processedCreators.length} found)
              </button>
            )}
          </div>
        </div>

        {/* Secondary Detailed Filter Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-white/5 text-xs">
          {/* Platform Filter */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#7C8AA8] uppercase">Platform</label>
            <select
              id="select-roster-platform"
              value={platformFilter}
              onChange={(e) => setPlatformFilter(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="all" className="bg-[#0D1830]">All Platforms</option>
              <option value="TikTok" className="bg-[#0D1830]">TikTok</option>
              <option value="Instagram" className="bg-[#0D1830]">Instagram</option>
              <option value="YouTube" className="bg-[#0D1830]">YouTube</option>
              <option value="Twitch" className="bg-[#0D1830]">Twitch</option>
              <option value="Twitter/X" className="bg-[#0D1830]">Twitter/X</option>
            </select>
          </div>

          {/* Representation Agreement */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#7C8AA8] uppercase">Representation</label>
            <select
              id="select-roster-representation"
              value={representationFilter}
              onChange={(e) => setRepresentationFilter(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="all" className="bg-[#0D1830]">All Representation</option>
              {allAgreements.map(ag => (
                <option key={ag} value={ag} className="bg-[#0D1830]">{ag}</option>
              ))}
            </select>
          </div>

          {/* Assigned Agent */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#7C8AA8] uppercase">Assigned Agent</label>
            <select
              id="select-roster-agent"
              value={agentFilter}
              onChange={(e) => setAgentFilter(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="all" className="bg-[#0D1830]">All Agents</option>
              {allAgents.map(ag => (
                <option key={ag} value={ag} className="bg-[#0D1830]">{ag}</option>
              ))}
              <option value="unassigned" className="bg-[#0D1830]">Unassigned</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#7C8AA8] uppercase">Status</label>
            <select
              id="select-roster-status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="all" className="bg-[#0D1830]">All Statuses</option>
              <option value="Active" className="bg-[#0D1830] text-emerald-300">🟢 Active</option>
              <option value="Not Active" className="bg-[#0D1830] text-rose-300">🔴 Not Active</option>
              <option value="Paused" className="bg-[#0D1830] text-amber-300">⏸️ Paused / Hiatus</option>
              <option value="Offboarded" className="bg-[#0D1830] text-slate-300">📁 Offboarded</option>
              <option value="Risk" className="bg-[#0D1830] text-red-400">⚠️ Risk</option>
            </select>
          </div>
        </div>
      </div>

      {/* 4. VISUAL KPI ANALYTICS & CHARTS */}
      {showRosterCharts && (
        <div className="animate-fade-in">
          <RosterCharts
            creators={processedCreators}
            currentRole={currentRole as string}
            currentUser={currentUser}
            primaryBrandColor={primaryBrandColor}
          />
        </div>
      )}

      {/* 4B. BATCH SELECTION & BULK OPERATIONS ACTION BAR */}
      {selectedCreatorIds.length > 0 && (
        <div className="animate-fade-in">
          <BatchActionsBar
            selectedIds={selectedCreatorIds}
            itemType="creators"
            currentRole={currentRole as Role}
            primaryBrandColor={primaryBrandColor}
            onClearSelection={() => setSelectedCreatorIds([])}
            onBatchAssignAgent={(agentName) => {
              setCreators(prev => prev.map(c => selectedCreatorIds.includes(c.id) ? { ...c, assignedAgent: agentName } : c));
              selectedCreatorIds.forEach(id => {
                setDoc(doc(db, "studio-creators", id), {
                  assignedAgent: agentName,
                  agentAssignedAt: new Date().toISOString()
                }, { merge: true }).catch(e => console.warn("[BatchAssignAgent] Firestore error:", e));
              });
              if (triggerNotification) triggerNotification("Agents Assigned", `Assigned ${selectedCreatorIds.length} creators to ${agentName}`, "success");
              setSelectedCreatorIds([]);
            }}
            onBatchChangeStatus={(status) => {
              setCreators(prev => prev.map(c => selectedCreatorIds.includes(c.id) ? { ...c, status: status as any } : c));
              selectedCreatorIds.forEach(id => {
                setDoc(doc(db, "studio-creators", id), {
                  status: status,
                  statusUpdatedAt: new Date().toISOString()
                }, { merge: true }).catch(e => console.warn("[BatchChangeStatus] Firestore error:", e));
              });
              if (triggerNotification) triggerNotification("Status Updated", `Set ${selectedCreatorIds.length} creators to ${status}`, "success");
              setSelectedCreatorIds([]);
            }}
            onBatchExportCSV={onExportCSV}
            onBatchPitchCampaign={() => {
              const selectedNames = creators.filter(c => selectedCreatorIds.includes(c.id)).map(c => c.name || c.handle).join(', ');
              if (triggerNotification) {
                triggerNotification(
                  "Campaign Pitch Package Ready",
                  `Compiled pitch packet for ${selectedCreatorIds.length} creators (${selectedNames.slice(0, 45)}...) and dispatched to casting call review.`,
                  "success"
                );
              }
              if (onAddActivityLog) {
                onAddActivityLog(
                  currentUser?.name || "Staff",
                  String(currentRole),
                  `Batched pitched ${selectedCreatorIds.length} creators to active brand campaigns`
                );
              }
              setSelectedCreatorIds([]);
            }}
            onBatchExportRateCards={() => {
              const selected = creators.filter(c => selectedCreatorIds.includes(c.id));
              const summaryData = selected.map(c => 
                `Creator: ${c.name} (${c.handle})\nNiche: ${c.niche}\nFollowers: ${c.followers}\nEngagement: ${c.eng}\nDedicated Video Rate: $${((c.rateCard as any)?.dedicatedVideo || (c.rateCard as any)?.reel || 2500).toLocaleString()}\n---\n`
              ).join('\n');
              
              const blob = new Blob([`BLOOM STUDIO — TALENT RATE CARDS & MEDIA KIT SUMMARY\nGenerated: ${new Date().toLocaleDateString()}\n\n${summaryData}`], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `Bloom_Talent_RateCards_${selected.length}_Creators.txt`;
              a.click();
              URL.revokeObjectURL(url);

              if (triggerNotification) {
                triggerNotification(
                  "Rate Cards Exported",
                  `Downloaded compiled rate cards and media kits for ${selectedCreatorIds.length} creators.`,
                  "success"
                );
              }
            }}
            onBatchBroadcastMessage={() => {
              const memo = prompt(`Broadcast Announcement to ${selectedCreatorIds.length} Selected Creators:`, "Agency Memo: Please submit brand deliverables for review before Friday 5 PM EST.");
              if (memo) {
                if (triggerNotification) {
                  triggerNotification(
                    "Broadcast Dispatched",
                    `Sent studio memo to ${selectedCreatorIds.length} creators: "${memo.slice(0, 35)}..."`,
                    "success"
                  );
                }
                if (onAddActivityLog) {
                  onAddActivityLog(
                    currentUser?.name || "Staff",
                    String(currentRole),
                    `Dispatched broadcast announcement to ${selectedCreatorIds.length} creators: ${memo}`
                  );
                }
                setSelectedCreatorIds([]);
              }
            }}
            onBatchDelete={() => {
              if (onBatchDeleteCreators) {
                onBatchDeleteCreators(selectedCreatorIds);
              } else if (onDeleteCreator) {
                selectedCreatorIds.forEach(id => onDeleteCreator(id));
                setSelectedCreatorIds([]);
              }
            }}
            onBatchSendEmail={() => {
              if (triggerNotification) triggerNotification("Batch Outreach", `Composing priority update for ${selectedCreatorIds.length} creators`, "info");
            }}
          />
        </div>
      )}

      {/* 5. ROSTER TABLE VIEW */}
      {rosterViewMode === 'table' && (
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/10 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                  <th className="p-4 w-10">
                    <input
                      type="checkbox"
                      id="checkbox-select-all-creators"
                      checked={
                        selectedCreatorIds.length > 0 &&
                        selectedCreatorIds.length === processedCreators.length
                      }
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedCreatorIds(processedCreators.map(c => c.id));
                        } else {
                          setSelectedCreatorIds([]);
                        }
                      }}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 cursor-pointer"
                    />
                  </th>
                  
                  {/* Sortable Column: Creator */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy(sortBy === 'name-asc' ? 'name-desc' : 'name-asc')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Creator</span>
                      {sortBy === 'name-asc' && <ArrowUp className="w-3.5 h-3.5 text-amber-400" />}
                      {sortBy === 'name-desc' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  {/* Sortable Column: Niche */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy('niche')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Niche Category</span>
                      {sortBy === 'niche' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  {/* Sortable Column: Platform */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy('platform')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Platform</span>
                      {sortBy === 'platform' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  {/* Sortable Column: Follower Reach */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy(sortBy === 'followers-desc' ? 'followers-asc' : 'followers-desc')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Follower Reach</span>
                      {sortBy === 'followers-desc' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                      {sortBy === 'followers-asc' && <ArrowUp className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  {/* Sortable Column: Engagement Rate & Smart Metric */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy(sortBy === 'eng-desc' ? 'eng-asc' : 'eng-desc')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Smart Engagement</span>
                      {sortBy === 'eng-desc' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                      {sortBy === 'eng-asc' && <ArrowUp className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  {/* Sortable Column: Representation Agreement */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy('representation')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Representation</span>
                      {sortBy === 'representation' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  {/* Sortable Column: Assigned Agent */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy('agent')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Assigned Agent</span>
                      {sortBy === 'agent' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  {/* Sortable Column: Status */}
                  <th 
                    className="p-4 font-semibold text-white cursor-pointer hover:text-amber-300 select-none"
                    onClick={() => setSortBy('status')}
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Status</span>
                      {sortBy === 'status' && <ArrowDown className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                  </th>

                  <th className="p-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-white/5">
                {processedCreators.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="p-12 text-center text-slate-400 space-y-3">
                      <Users className="w-10 h-10 mx-auto text-slate-600 mb-2" />
                      <p className="text-sm text-slate-300 font-semibold">No creators found matching your current filters.</p>
                      <p className="text-xs text-slate-500">
                        Try resetting your search query, selecting another niche (Pets, Beauty, Lifestyle), or clearing engagement filters.
                      </p>
                      <button
                        onClick={handleResetFilters}
                        className="mt-2 text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3.5 py-1.5 rounded-xl font-semibold cursor-pointer"
                      >
                        Reset All Filters
                      </button>
                    </td>
                  </tr>
                ) : (
                  processedCreators.map((c) => {
                    const isSelected = selectedCreatorIds.includes(c.id);
                    const nicheMeta = getNicheBadge(c.niche);
                    const reachTier = getFollowerReachTier(c.followers);
                    const engRate = parseEngagementRate(c.eng);
                    const smartEng = getSmartEngagementInfo(engRate);

                    return (
                      <tr 
                        key={c.id} 
                        className={`hover:bg-[#111E33]/40 transition-colors ${isSelected ? 'bg-amber-500/10' : ''}`}
                      >
                        {/* Checkbox */}
                        <td className="p-4">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedCreatorIds(prev => [...prev, c.id]);
                              } else {
                                setSelectedCreatorIds(prev => prev.filter(id => id !== c.id));
                              }
                            }}
                            className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 cursor-pointer"
                          />
                        </td>

                        {/* Creator Info */}
                        <td className="p-4">
                          <button
                            type="button"
                            onClick={() => onSelectCreatorForDetail(c, isDirector ? 'payouts' : 'profile')}
                            className="text-left group cursor-pointer focus:outline-none flex items-center gap-3"
                            title={isDirector ? "Click to view creator profile & chronological escrow payout history" : "Click to view creator profile & details"}
                          >
                            <div className="w-9 h-9 rounded-xl bg-[#16243F] border border-amber-500/20 flex items-center justify-center font-bold text-amber-300 text-xs shrink-0 group-hover:border-amber-400 transition-colors">
                              {c.avatar ? (
                                <img src={c.avatar} alt={c.name} className="w-full h-full rounded-xl object-cover" />
                              ) : (
                                <span>{c.name.slice(0, 2).toUpperCase()}</span>
                              )}
                            </div>
                            <div>
                              <div className="font-semibold text-white text-sm group-hover:text-amber-400 transition-colors flex items-center gap-1.5">
                                {c.name}
                              </div>
                              <div className="text-xs text-[#C9A46A] font-mono mt-0.5">{c.handle}</div>
                            </div>
                          </button>
                        </td>

                        {/* Niche Badge & Quick Inline Changer */}
                        <td className="p-4">
                          {editingNicheCreatorId === c.id ? (
                            <div className="flex items-center gap-1.5">
                              <select
                                autoFocus
                                value={c.niche || 'Lifestyle'}
                                onChange={(e) => {
                                  if (e.target.value === '__add_new__') {
                                    setShowAddNicheModal(true);
                                  } else {
                                    handleUpdateCreatorNiche(c.id, e.target.value);
                                  }
                                }}
                                onBlur={() => setEditingNicheCreatorId(null)}
                                className="bg-[#111E33] border border-amber-500 text-white text-xs rounded-lg p-1 outline-none font-semibold cursor-pointer"
                              >
                                <option value="Pets">🐾 Pets</option>
                                <option value="Beauty">💄 Beauty</option>
                                <option value="Lifestyle">✨ Lifestyle</option>
                                {!strictCoreOnly && allUniqueNiches
                                  .filter(n => !['Pets', 'Beauty', 'Lifestyle'].includes(n))
                                  .map(n => (
                                    <option key={n} value={n}>{getNicheBadge(n).icon} {n}</option>
                                  ))}
                                {!strictCoreOnly && <option value="__add_new__">+ Add New Niche...</option>}
                              </select>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5">
                              <span 
                                onClick={() => setEditingNicheCreatorId(c.id)}
                                title="Click to quickly reassign niche"
                                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-semibold border cursor-pointer hover:opacity-85 transition-opacity ${nicheMeta.bg} ${nicheMeta.color} ${nicheMeta.border}`}
                              >
                                <span>{nicheMeta.icon}</span>
                                <span>{c.niche || 'Lifestyle'}</span>
                              </span>
                            </div>
                          )}
                        </td>

                        {/* Platform */}
                        <td className="p-4">
                          <span className="inline-flex items-center gap-1 text-[#B8C0D4] font-medium bg-[#111E33] px-2 py-0.5 rounded-lg border border-white/5">
                            {c.platform === 'TikTok' && '📱 TikTok'}
                            {c.platform === 'Instagram' && '📸 Instagram'}
                            {c.platform === 'YouTube' && '▶️ YouTube'}
                            {c.platform === 'Twitch' && '🎮 Twitch'}
                            {!['TikTok', 'Instagram', 'YouTube', 'Twitch'].includes(c.platform) && `🌐 ${c.platform || 'Multi'}`}
                          </span>
                        </td>

                        {/* Follower Reach & Tier Badge */}
                        <td className="p-4">
                          <div className="space-y-0.5">
                            <div className="text-white font-bold text-xs font-mono">
                              {c.followers || '100K'}
                            </div>
                            <span className={`inline-block text-[9px] font-mono px-1.5 py-0.2 rounded border uppercase font-semibold ${reachTier.badgeClass}`}>
                              {reachTier.tier}
                            </span>
                          </div>
                        </td>

                        {/* Smart Engagement Index */}
                        <td className="p-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5">
                              <span className="text-emerald-400 font-bold font-mono text-xs">
                                {c.eng || '4.5%'}
                              </span>
                            </div>
                            <span 
                              title={smartEng.deltaVsBenchmark}
                              className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-lg border ${smartEng.badgeClass}`}
                            >
                              <span>{smartEng.icon}</span>
                              <span>{smartEng.label}</span>
                            </span>
                          </div>
                        </td>

                        {/* Representation Agreement */}
                        <td className="p-4">
                          <div className="space-y-1">
                            <span className="text-slate-300 text-xs font-mono bg-[#111E33] px-2 py-1 rounded-lg border border-white/5 inline-block">
                              {isDirector ? (c.agreement || 'Exclusive (80%)') : (c.agreement ? c.agreement.replace(/\s*\(.*?\)/, '') : 'Exclusive')}
                            </span>
                            {c.contractEndDate && (
                              <div>
                                <DaysUntilExpiryBadge endDate={c.contractEndDate} compact={true} />
                              </div>
                            )}
                          </div>
                        </td>

                        {/* Assigned Agent */}
                        <td className="p-4">
                          <button
                            type="button"
                            onClick={() => onAssignAgent(c.id)}
                            className="text-left group cursor-pointer"
                            title="Click to reassign agent"
                          >
                            <span className="text-amber-300 font-mono font-medium text-xs group-hover:underline flex items-center gap-1">
                              👤 {c.assignedAgent || 'Marcus Cole'}
                            </span>
                          </button>
                        </td>

                        {/* Status & Availability Control Button */}
                        <td className="p-4">
                          <div className="space-y-1">
                            <button
                              id={`btn-status-creator-${c.id}`}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenStatusModal(c);
                              }}
                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer shadow-sm hover:scale-[1.03] ${
                                c.status === 'Active'
                                  ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/80 hover:border-emerald-400'
                                  : c.status === 'Not Active' || c.status === 'Inactive'
                                    ? 'bg-rose-950/80 border-rose-500/50 text-rose-300 hover:bg-rose-900/80 hover:border-rose-400'
                                    : c.status === 'Paused'
                                      ? 'bg-amber-950/80 border-amber-500/50 text-amber-300 hover:bg-amber-900/80 hover:border-amber-400'
                                      : c.status === 'Offboarded'
                                        ? 'bg-slate-900/90 border-slate-700 text-slate-400 hover:bg-slate-800'
                                        : 'bg-[#16243F] border-white/10 text-slate-300 hover:bg-[#1f3050]'
                              }`}
                              title="Click to set Active / Not Active, effective date, and audit reason"
                            >
                              {c.status === 'Active' ? (
                                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                              ) : c.status === 'Not Active' || c.status === 'Inactive' ? (
                                <span className="w-2 h-2 rounded-full bg-rose-400" />
                              ) : (
                                <span className="w-2 h-2 rounded-full bg-amber-400" />
                              )}
                              <span>{c.status === 'Active' ? 'Active' : (c.status || 'Not Active')}</span>
                              <Edit2 className="w-2.5 h-2.5 opacity-70 ml-0.5" />
                            </button>

                            {/* Effective Date & Why Subtitle */}
                            {(c.statusChangeDate || c.statusChangeReason) && (
                              <div className="text-[10px] text-slate-400 font-mono flex flex-wrap items-center gap-1 max-w-[210px] leading-tight">
                                {c.statusChangeDate && (
                                  <span className="text-amber-400/90 flex items-center gap-0.5 font-semibold">
                                    📅 {c.statusChangeDate}
                                  </span>
                                )}
                                {c.statusChangeReason && (
                                  <span className="text-slate-300 truncate max-w-[130px]" title={c.statusChangeReason}>
                                    • {c.statusChangeReason}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </td>

                        {/* Actions */}
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {isDirector && (
                              <button
                                type="button"
                                id={`btn-payout-history-${c.id}`}
                                onClick={() => onSelectCreatorForDetail(c, 'payouts')}
                                className="text-xs bg-[#112438] border border-emerald-500/40 text-emerald-300 hover:bg-emerald-950/70 hover:border-emerald-400 px-2.5 py-1.5 rounded-xl transition-all font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm"
                                title="View chronological escrow payout history & finance section"
                              >
                                <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
                                <span>Payout History</span>
                              </button>
                            )}

                            <button
                              type="button"
                              id={`btn-view-creator-detail-${c.id}`}
                              onClick={() => onSelectCreatorForDetail(c, 'profile')}
                              className="text-xs bg-[#16243F] border border-[#C9A46A]/30 text-[#C9A46A] hover:bg-[#1f3050] px-2.5 py-1.5 rounded-xl transition-colors font-semibold flex items-center gap-1 cursor-pointer"
                              title="View creator profile & send SMS/Email"
                            >
                              <Eye className="w-3.5 h-3.5" /> Detail
                            </button>

                            {!isRestrictedRole && (
                              <button 
                                onClick={() => onDeleteCreator(c.id)}
                                className="text-[#7C8AA8] hover:text-rose-400 p-1.5 rounded-xl hover:bg-rose-500/10 transition-colors cursor-pointer"
                                title="Delete creator from roster"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5B. VIEW MODE: ROSTER HEAT MAP */}
      {rosterViewMode === 'heatmap' && (
        <div className="animate-fade-in font-sans">
          <RosterHeatMap
            creators={processedCreators}
            currentRole={currentRole as Role}
            currentUser={currentUser}
            deals={[]}
            primaryBrandColor={primaryBrandColor}
            onUpdateCreatorStatus={(id, status) => onUpdateCreatorStatus(id, status)}
            onAssignAgent={(id) => onAssignAgent(id)}
          />
        </div>
      )}

      {/* 5C. VIEW MODE: ROSTER PROFILES & INBOUND CREATOR SUBMISSIONS */}
      {rosterViewMode === 'profiles' && (
        <div className="space-y-6 animate-fade-in font-sans">
          {/* Leadership Synchronization Banner - Director Dashboard Only */}
          {isDirector && (
            <div className="bg-gradient-to-r from-[#0D1830] via-[#111E33] to-[#0D1830] border border-[#C9A46A]/30 rounded-2xl p-5 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-full bg-[#C9A46A]/5 blur-3xl pointer-events-none" />
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
                <div className="space-y-1.5 max-w-3xl">
                  <div className="flex items-center gap-2">
                    <span className="bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/40 text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full flex items-center gap-1.5 shadow-sm">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                      Live Multi-Role Intake Synchronized
                    </span>
                    <span className="text-slate-400 text-xs font-mono">• Director • Talent Agent • Agent Managers</span>
                  </div>
                  <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                    <FileText className="w-5 h-5 text-[#C9A46A]" />
                    <span>Creator Roster Profiles &amp; Leadership Intake Stream</span>
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    When creators fill out their profile in the Creator Portal, the data (preferred brand whitelists, competitor blacklists, social reach, availability calendars, and verified Stripe debit cards) is instantly transmitted here for the <strong className="text-[#C9A46A]">Director</strong>, <strong className="text-amber-300">Talent Agent</strong>, and <strong className="text-sky-300">Agent Managers</strong>.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Metric KPI Cards for Submissions - Stripe Cards card only for Director */}
          <div className={`grid grid-cols-2 ${isDirector ? 'lg:grid-cols-4' : 'lg:grid-cols-3'} gap-3.5`}>
            <div className="bg-[#091122]/90 border border-white/10 p-4 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                <span className="font-mono uppercase font-semibold">Total Intake</span>
                <Users className="w-4 h-4 text-[#C9A46A]" />
              </div>
              <div className="text-2xl font-bold text-white font-mono">{effectiveSubmissions.length}</div>
              <p className="text-[11px] text-slate-400 mt-1">Creator profiles on file</p>
            </div>

            <div className="bg-[#091122]/90 border border-amber-500/30 p-4 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between text-amber-300 text-xs mb-1">
                <span className="font-mono uppercase font-semibold">Pending Review</span>
                <Clock className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-bold text-amber-300 font-mono">{pendingSubmissionsCount}</div>
              <p className="text-[11px] text-amber-400/80 mt-1">Awaiting Director &amp; Agent review</p>
            </div>

            <div className="bg-[#091122]/90 border border-emerald-500/30 p-4 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between text-emerald-400 text-xs mb-1">
                <span className="font-mono uppercase font-semibold">Director Approved</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-bold text-emerald-400 font-mono">{approvedSubmissionsCount}</div>
              <p className="text-[11px] text-emerald-400/80 mt-1">Unlocked for brand pitch deals</p>
            </div>

            {isDirector && (
              <div className="bg-[#091122]/90 border border-sky-500/30 p-4 rounded-2xl shadow-sm">
                <div className="flex items-center justify-between text-sky-300 text-xs mb-1">
                  <span className="font-mono uppercase font-semibold">Stripe Debit Cards</span>
                  <CreditCard className="w-4 h-4 text-sky-400" />
                </div>
                <div className="text-2xl font-bold text-sky-300 font-mono">{cardsSubmissionsCount}</div>
                <p className="text-[11px] text-sky-400/80 mt-1">Verified for automatic disbursements</p>
              </div>
            )}
          </div>

          {/* Submissions Search & Filter Bar */}
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-3.5 flex flex-col md:flex-row items-center justify-between gap-3 shadow-sm">
            <div className="relative w-full md:w-96">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={submissionSearch}
                onChange={(e) => setSubmissionSearch(e.target.value)}
                placeholder="Search profiles by creator name, @handle, brand, or bio..."
                className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-9 pr-3.5 py-2 text-xs text-white placeholder-slate-400 outline-none focus:border-[#C9A46A] transition-all"
              />
              {submissionSearch && (
                <button
                  onClick={() => setSubmissionSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center flex-wrap gap-2 w-full md:w-auto justify-end">
              {/* Status Filter */}
              <div className="bg-[#111E33] border border-white/10 rounded-xl p-1 flex items-center font-mono text-[11px]">
                {['All', 'Pending Review', 'Director Approved', 'Agent Assigned'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setSubmissionStatusFilter(st)}
                    className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                      submissionStatusFilter === st
                        ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>

              {/* Niche Filter Dropdown */}
              <select
                value={submissionNicheFilter}
                onChange={(e) => setSubmissionNicheFilter(e.target.value)}
                className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer"
              >
                <option value="All">All Niches</option>
                {allUniqueNiches.map(n => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Submissions Grid Cards */}
          {filteredSubmissions.length === 0 ? (
            <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-12 text-center space-y-3">
              <FileText className="w-12 h-12 text-slate-500 mx-auto" />
              <h4 className="text-base font-bold text-white">No Profile Submissions Found</h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                No creator profiles match your current search or status filter. Creators who save their profile in the Creator Portal will instantly appear here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {filteredSubmissions.map((sub) => {
                const isPending = sub.status === 'Pending Review';
                const isApproved = sub.status === 'Director Approved';
                const isAssigned = sub.status === 'Agent Assigned';

                return (
                  <div
                    key={sub.id}
                    className={`bg-[#0D1830] border rounded-2xl p-5 space-y-4 transition-all shadow-md hover:shadow-xl ${
                      isPending
                        ? 'border-amber-500/40 hover:border-amber-500'
                        : isApproved
                        ? 'border-emerald-500/40 hover:border-emerald-500'
                        : 'border-white/10 hover:border-white/20'
                    }`}
                  >
                    {/* Top Creator Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#1A2C4E] to-[#111E33] border border-white/15 flex items-center justify-center text-base font-bold text-[#C9A46A] shadow-inner shrink-0">
                          {sub.creatorName.split(' ').map(n => n[0]).join('').slice(0, 2) || 'CR'}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="text-base font-bold text-white tracking-tight">{sub.creatorName}</h4>
                            <span className="text-xs font-mono text-[#C9A46A] font-semibold">{sub.creatorHandle}</span>
                            {sub.tier && (
                              <span className="bg-[#C9A46A]/15 text-[#C9A46A] border border-[#C9A46A]/30 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
                                {sub.tier}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-slate-400 text-xs mt-0.5 font-mono">
                            <span>{isDirector ? (sub.email || 'creator@agency.com') : '••••@••••.com'}</span>
                            {sub.phone && <span>• {isDirector ? sub.phone : '••••••••'}</span>}
                            <span>• {sub.submittedAt}</span>
                          </div>
                        </div>
                      </div>

                      {/* Status Badge */}
                      <div>
                        {isPending && (
                          <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-mono font-bold px-2.5 py-1 rounded-xl flex items-center gap-1.5 shadow-sm">
                            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                            Pending Review
                          </span>
                        )}
                        {isApproved && (
                          <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-mono font-bold px-2.5 py-1 rounded-xl flex items-center gap-1.5 shadow-sm">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            Director Approved
                          </span>
                        )}
                        {isAssigned && (
                          <span className="bg-sky-500/20 text-sky-300 border border-sky-500/40 text-[11px] font-mono font-bold px-2.5 py-1 rounded-xl flex items-center gap-1.5 shadow-sm">
                            <Users className="w-3.5 h-3.5 text-sky-400" />
                            Agent Assigned
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Bio Statement */}
                    {sub.bio && (
                      <p className="text-xs text-slate-300 bg-[#111E33] border border-white/5 rounded-xl p-3 leading-relaxed italic">
                        "{sub.bio}"
                      </p>
                    )}

                    {/* Niche & Category Tags */}
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      <span className="bg-[#16243F] text-amber-300 border border-amber-500/30 px-2.5 py-1 rounded-lg font-mono font-semibold">
                        🏷️ {sub.niche}
                      </span>
                      {sub.secondaryInterests && (
                        <span className="bg-[#111E33] text-slate-300 border border-white/10 px-2.5 py-1 rounded-lg text-[11px]">
                          ✨ {sub.secondaryInterests}
                        </span>
                      )}
                    </div>

                    {/* Brand Whitelist & Blacklist Chips */}
                    <div className="space-y-2 pt-1">
                      {sub.preferredBrands && (
                        <div>
                          <span className="text-[10px] font-mono uppercase font-bold text-emerald-400 block mb-1">
                            🎯 Preferred Brand Whitelist:
                          </span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {sub.preferredBrands.split(',').map((b, bi) => (
                              <span
                                key={bi}
                                className="bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-[11px] px-2 py-0.5 rounded-md font-medium"
                              >
                                ✓ {b.trim()}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {sub.excludedBrands && (
                        <div>
                          <span className="text-[10px] font-mono uppercase font-bold text-rose-400 block mb-1">
                            🚫 Excluded Competitors / Blacklist:
                          </span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {sub.excludedBrands.split(',').map((eb, ebi) => (
                              <span
                                key={ebi}
                                className="bg-rose-500/10 text-rose-300 border border-rose-500/30 text-[11px] px-2 py-0.5 rounded-md font-medium"
                              >
                                ✕ {eb.trim()}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Financial Setup (Director only) & Quarterly Availability */}
                    {isDirector ? (
                      <div className="grid grid-cols-2 gap-2 bg-[#091122] border border-white/5 rounded-xl p-3 text-xs">
                        <div>
                          <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold block">
                            Payout Configuration
                          </span>
                          <div className="flex items-center gap-1.5 text-white font-mono text-[11px] mt-0.5">
                            <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                            <span>
                              {sub.stripeCardLast4 ? `Visa Debit (•••• ${sub.stripeCardLast4})` : (sub.paymentMethod || 'Direct Deposit')}
                            </span>
                          </div>
                        </div>

                        <div>
                          <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold block">
                            Quarterly Availability
                          </span>
                          <div className="flex items-center gap-1 font-mono text-[10px] mt-0.5">
                            <span className={`px-1.5 py-0.5 rounded ${sub.q1Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q1</span>
                            <span className={`px-1.5 py-0.5 rounded ${sub.q2Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q2</span>
                            <span className={`px-1.5 py-0.5 rounded ${sub.q3Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q3</span>
                            <span className={`px-1.5 py-0.5 rounded ${sub.q4Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q4</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-[#091122] border border-white/5 rounded-xl p-3 text-xs flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold block">
                          Quarterly Availability
                        </span>
                        <div className="flex items-center gap-1 font-mono text-[10px]">
                          <span className={`px-1.5 py-0.5 rounded ${sub.q1Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q1</span>
                          <span className={`px-1.5 py-0.5 rounded ${sub.q2Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q2</span>
                          <span className={`px-1.5 py-0.5 rounded ${sub.q3Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q3</span>
                          <span className={`px-1.5 py-0.5 rounded ${sub.q4Availability === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'}`}>Q4</span>
                        </div>
                      </div>
                    )}

                    {/* Assigned Agent & Manager Footer */}
                    <div className="flex items-center justify-between text-xs pt-1 border-t border-white/10 font-mono">
                      <div className="text-slate-400 text-[11px]">
                        <span>Agent: <strong className="text-white">{sub.assignedAgent || 'Unassigned'}</strong></span>
                        <span className="mx-1.5">•</span>
                        <span>Manager: <strong className="text-slate-300">{sub.assignedManager || 'Agent Manager'}</strong></span>
                      </div>

                      {sub.reviewedBy && (
                        <div className="text-emerald-400 text-[11px] flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          <span>Approved by {sub.reviewedBy}</span>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons Bar */}
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/5">
                      {isPending && (
                        <button
                          onClick={() => handleApproveSubmission(sub.id)}
                          className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                          title="Director approval unlocks this creator profile for brand deal pitches"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Director Approve</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setAssignAgentModalSub(sub);
                          setAssignSelectedAgentName(sub.assignedAgent || 'Marcus Cole');
                          setAssignSelectedManagerName(sub.assignedManager || 'Senior Agent Manager');
                        }}
                        className="bg-[#111E33] hover:bg-[#16243F] text-sky-300 border border-sky-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <Users className="w-3.5 h-3.5" />
                        <span>Assign Agent</span>
                      </button>

                      <button
                        onClick={() => {
                          setSelectedSubmissionForDetail(sub);
                          setActiveDossierTab('overview');
                        }}
                        className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm flex items-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Dossier</span>
                      </button>

                      <button
                        onClick={() => handleArchiveSubmission(sub.id)}
                        className="text-slate-400 hover:text-rose-400 p-1.5 rounded-xl hover:bg-rose-500/10 transition-colors cursor-pointer"
                        title="Archive profile submission"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* MODAL: ASSIGN AGENT & MANAGER TO PROFILE SUBMISSION */}
      {assignAgentModalSub && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/50 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-fade-in font-sans">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-base font-bold text-white">Assign Staff to Creator Profile</h3>
              </div>
              <button
                onClick={() => setAssignAgentModalSub(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 text-xs space-y-1">
              <div className="font-bold text-white">{assignAgentModalSub.creatorName} ({assignAgentModalSub.creatorHandle})</div>
              <div className="text-slate-400 font-mono">Niche: {assignAgentModalSub.niche}</div>
            </div>

            <div className="space-y-3">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400 uppercase font-semibold">Assigned Talent Agent</label>
                <select
                  value={assignSelectedAgentName}
                  onChange={(e) => setAssignSelectedAgentName(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                >
                  <option value="Marcus Cole">Marcus Cole (Senior Talent Agent)</option>
                  <option value="Rachel Sterling">Rachel Sterling (Lead Creator Agent)</option>
                  <option value="David Vance">David Vance (Brand Partnerships Agent)</option>
                  <option value="Sarah Jenkins">Sarah Jenkins (VIP Talent Agent)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400 uppercase font-semibold">Assigned Agent Manager</label>
                <select
                  value={assignSelectedManagerName}
                  onChange={(e) => setAssignSelectedManagerName(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                >
                  <option value="Senior Agent Manager">Senior Agent Manager (Pod Lead)</option>
                  <option value="Director of Talent">Director of Talent</option>
                  <option value="Campaign Operations Manager">Campaign Operations Manager</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setAssignAgentModalSub(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleAssignAgentToSubmission(assignAgentModalSub.id, assignSelectedAgentName, assignSelectedManagerName)}
                className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-md"
              >
                Confirm &amp; Dispatch to Pod
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL / SLIDE-OVER: CREATOR FULL ROSTER PROFILE DOSSIER (5 TABS) */}
      {selectedSubmissionForDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 font-sans">
          <div className="bg-[#0D1830] border border-[#C9A46A]/50 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl animate-fade-in overflow-hidden">
            {/* Dossier Header */}
            <div className="p-6 border-b border-white/10 flex items-start justify-between gap-4 bg-[#111E33]">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#1A2C4E] to-[#111E33] border border-[#C9A46A]/40 flex items-center justify-center text-lg font-bold text-[#C9A46A] shadow-inner shrink-0">
                  {selectedSubmissionForDetail.creatorName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </div>
                <div>
                  <div className="flex items-center gap-2.5">
                    <h3 className="text-lg font-bold text-white tracking-tight">{selectedSubmissionForDetail.creatorName}</h3>
                    <span className="text-sm font-mono text-[#C9A46A]">{selectedSubmissionForDetail.creatorHandle}</span>
                    <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
                      {selectedSubmissionForDetail.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 font-mono">
                    Transmitted to: {selectedSubmissionForDetail.targetAudience || 'Director, Agent & Agent Managers'} • Submitted: {selectedSubmissionForDetail.submittedAt}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedSubmissionForDetail(null)}
                className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Dossier Tab Navigation */}
            <div className="flex items-center border-b border-white/10 px-6 bg-[#091122] overflow-x-auto gap-2">
              {[
                { id: 'overview', label: '1. Profile & Bio', icon: Users },
                { id: 'brandFit', label: '2. Brand Whitelist & Blacklist', icon: Target },
                { id: 'socials', label: '3. Socials & Reach', icon: Globe },
                ...(isDirector ? [{ id: 'financial', label: '4. Stripe Agency Visa Debit', icon: CreditCard }] : []),
                { id: 'availability', label: isDirector ? '5. Availability & Pod' : '4. Availability & Pod', icon: Calendar }
              ].map((tab) => {
                const Icon = tab.icon;
                const active = activeDossierTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveDossierTab(tab.id as any)}
                    className={`py-3 px-3 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                      active
                        ? 'border-[#C9A46A] text-[#C9A46A] font-bold'
                        : 'border-transparent text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Dossier Tab Body */}
            <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              {activeDossierTab === 'overview' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-[#111E33] border border-white/5 rounded-2xl p-4 space-y-3">
                    <h4 className="text-xs font-mono font-bold text-[#C9A46A] uppercase">Creator Biography Statement</h4>
                    <p className="text-slate-200 leading-relaxed text-sm">
                      {selectedSubmissionForDetail.bio || 'No bio provided.'}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 space-y-1">
                      <span className="text-[10px] font-mono text-slate-400 uppercase">Primary Niche</span>
                      <div className="text-white font-bold">{selectedSubmissionForDetail.niche}</div>
                    </div>
                    <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 space-y-1">
                      <span className="text-[10px] font-mono text-slate-400 uppercase">Secondary Interests</span>
                      <div className="text-slate-300">{selectedSubmissionForDetail.secondaryInterests || 'None specified'}</div>
                    </div>
                    <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 space-y-1">
                      <span className="text-[10px] font-mono text-slate-400 uppercase">Contact Email</span>
                      <div className="text-white font-mono">{isDirector ? (selectedSubmissionForDetail.email || 'N/A') : '••••@••••.com'}</div>
                    </div>
                    <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 space-y-1">
                      <span className="text-[10px] font-mono text-slate-400 uppercase">Phone</span>
                      <div className="text-white font-mono">{isDirector ? (selectedSubmissionForDetail.phone || 'N/A') : '••••••••'}</div>
                    </div>
                  </div>
                </div>
              )}

              {activeDossierTab === 'brandFit' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-[#111E33] border border-emerald-500/20 rounded-2xl p-4 space-y-2">
                    <h4 className="text-xs font-mono font-bold text-emerald-400 uppercase flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Preferred Brand Whitelist</span>
                    </h4>
                    <p className="text-xs text-slate-300">
                      Brands this creator actively wants to partner with for sponsorships:
                    </p>
                    <div className="flex items-center gap-2 flex-wrap pt-2">
                      {(selectedSubmissionForDetail.preferredBrands || 'Dunkin, Morphe, Prada, Target').split(',').map((b, i) => (
                        <span key={i} className="bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-xs px-3 py-1 rounded-xl font-medium">
                          ✓ {b.trim()}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#111E33] border border-rose-500/20 rounded-2xl p-4 space-y-2">
                    <h4 className="text-xs font-mono font-bold text-rose-400 uppercase flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Competitor Exclusion / Brand Blacklist</span>
                    </h4>
                    <p className="text-xs text-slate-300">
                      Categories and brands to strictly avoid pitching to this creator:
                    </p>
                    <div className="flex items-center gap-2 flex-wrap pt-2">
                      {(selectedSubmissionForDetail.excludedBrands || 'Fast Fashion, Gambling').split(',').map((b, i) => (
                        <span key={i} className="bg-rose-500/15 text-rose-300 border border-rose-500/30 text-xs px-3 py-1 rounded-xl font-medium">
                          ✕ {b.trim()}
                        </span>
                      ))}
                    </div>
                  </div>

                  {selectedSubmissionForDetail.contentPreferences && (
                    <div className="bg-[#111E33] border border-white/5 rounded-2xl p-4 space-y-1.5">
                      <h4 className="text-xs font-mono font-bold text-amber-300 uppercase">Preferred Content Formats</h4>
                      <p className="text-slate-200">{selectedSubmissionForDetail.contentPreferences}</p>
                    </div>
                  )}
                </div>
              )}

              {activeDossierTab === 'socials' && (
                <div className="space-y-3 animate-fade-in">
                  <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">🎵</span>
                      <div>
                        <div className="font-bold text-white">TikTok Profile</div>
                        <div className="text-slate-400 font-mono">{selectedSubmissionForDetail.tiktok || 'https://tiktok.com/@' + selectedSubmissionForDetail.creatorHandle.replace('@', '')}</div>
                      </div>
                    </div>
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-lg text-xs font-mono">
                      Verified
                    </span>
                  </div>

                  <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">📸</span>
                      <div>
                        <div className="font-bold text-white">Instagram Profile</div>
                        <div className="text-slate-400 font-mono">{selectedSubmissionForDetail.instagram || 'https://instagram.com/' + selectedSubmissionForDetail.creatorHandle.replace('@', '')}</div>
                      </div>
                    </div>
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-lg text-xs font-mono">
                      Verified
                    </span>
                  </div>

                  <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-lg">📺</span>
                      <div>
                        <div className="font-bold text-white">YouTube Channel</div>
                        <div className="text-slate-400 font-mono">{selectedSubmissionForDetail.youtube || 'https://youtube.com/@' + selectedSubmissionForDetail.creatorHandle.replace('@', '')}</div>
                      </div>
                    </div>
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-lg text-xs font-mono">
                      Verified
                    </span>
                  </div>
                </div>
              )}

              {isDirector && activeDossierTab === 'financial' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-gradient-to-r from-[#1A2C4E] to-[#0E1B33] border border-sky-500/30 rounded-2xl p-5 space-y-4 text-white shadow-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-6 h-6 text-sky-400" />
                        <span className="font-bold text-sm tracking-wide">STRIPE ISSUING AGENCY VISA DEBIT</span>
                      </div>
                      <span className="bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
                        {selectedSubmissionForDetail.stripeCardStatus || 'Active'}
                      </span>
                    </div>

                    <div className="font-mono text-xl tracking-widest text-slate-100 pt-2">
                      •••• •••• •••• {selectedSubmissionForDetail.stripeCardLast4 || '8821'}
                    </div>

                    <div className="flex items-center justify-between text-xs font-mono text-slate-300 pt-2 border-t border-white/10">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase block">Cardholder Legal Name</span>
                        <span className="font-bold text-white">{selectedSubmissionForDetail.cardholderLegalName || selectedSubmissionForDetail.creatorName}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase block">Expires</span>
                        <span className="font-bold text-white">{selectedSubmissionForDetail.stripeCardExpiry || '08/28'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#111E33] border border-white/5 rounded-xl p-3.5 text-slate-300 space-y-1">
                    <span className="font-bold text-[#C9A46A] block">Disbursement Routing Notice</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Sponsorship payouts and brand deal revenue for this creator will automatically be settled and disbursed to this agency debit card upon campaign completion.
                    </p>
                  </div>
                </div>
              )}

              {activeDossierTab === 'availability' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-[#111E33] border border-white/5 rounded-2xl p-4 space-y-3">
                    <h4 className="text-xs font-mono font-bold text-amber-300 uppercase">2026 Quarterly Campaign Availability</h4>
                    <div className="grid grid-cols-4 gap-2.5 text-center font-mono">
                      {[
                        { q: 'Q1 (Jan-Mar)', val: selectedSubmissionForDetail.q1Availability || 'Booked' },
                        { q: 'Q2 (Apr-Jun)', val: selectedSubmissionForDetail.q2Availability || 'Booked' },
                        { q: 'Q3 (Jul-Sep)', val: selectedSubmissionForDetail.q3Availability || 'Available' },
                        { q: 'Q4 (Oct-Dec)', val: selectedSubmissionForDetail.q4Availability || 'Available' }
                      ].map((item) => (
                        <div key={item.q} className="bg-[#091122] border border-white/5 p-3 rounded-xl space-y-1">
                          <span className="text-[10px] text-slate-400 block">{item.q}</span>
                          <span className={`text-xs font-bold px-2 py-0.5 rounded-full inline-block ${
                            item.val === 'Available' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                          }`}>
                            {item.val}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-[#111E33] border border-white/5 rounded-2xl p-4 space-y-2">
                    <h4 className="text-xs font-mono font-bold text-[#C9A46A] uppercase">Assigned Talent Leadership</h4>
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-[10px] font-mono text-slate-400 uppercase">Lead Agent</span>
                        <div className="text-white font-bold">{selectedSubmissionForDetail.assignedAgent || 'Marcus Cole'}</div>
                      </div>
                      <div>
                        <span className="text-[10px] font-mono text-slate-400 uppercase">Agent Manager</span>
                        <div className="text-white font-bold">{selectedSubmissionForDetail.assignedManager || 'Senior Agent Manager'}</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Dossier Footer Actions */}
            <div className="p-4 border-t border-white/10 bg-[#111E33] flex items-center justify-between gap-3">
              <div className="text-xs text-slate-400 font-mono">
                Status: <strong className="text-white">{selectedSubmissionForDetail.status}</strong>
              </div>

              <div className="flex items-center gap-2">
                {selectedSubmissionForDetail.status === 'Pending Review' && (
                  <button
                    onClick={() => {
                      handleApproveSubmission(selectedSubmissionForDetail.id);
                      setSelectedSubmissionForDetail(prev => prev ? { ...prev, status: 'Director Approved' } : null);
                    }}
                    className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md flex items-center gap-1.5"
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Director Approve Profile</span>
                  </button>
                )}
                <button
                  onClick={() => setSelectedSubmissionForDetail(null)}
                  className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Close Dossier
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. MODAL: ADD CUSTOM NICHE OR OTHER */}
      {showAddNicheModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-amber-500/40 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-fade-in font-sans">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Tag className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">Add Agency Niche Category</h3>
              </div>
              <button
                onClick={() => setShowAddNicheModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddNewNiche} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400 uppercase font-semibold">Niche Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Pets, Beauty, Lifestyle, Automotive, Interior Design, Wellness..."
                  value={newNicheName}
                  onChange={(e) => setNewNicheName(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:border-amber-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400 uppercase font-semibold">Category Emoji / Icon</label>
                <div className="flex items-center gap-2">
                  {['🐾', '💄', '✨', '👗', '🏋️', '💻', '🎮', '🍳', '✈️', '🐶', '🌿', '🎨'].map(emoji => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setNewNicheEmoji(emoji)}
                      className={`w-8 h-8 rounded-lg text-sm flex items-center justify-center transition border ${
                        newNicheEmoji === emoji
                          ? 'bg-amber-500/20 border-amber-500 scale-110'
                          : 'bg-[#111E33] border-white/5 hover:border-white/20'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 text-[11px] text-slate-300 space-y-1">
                <strong className="text-amber-300 block font-mono">Agency Niche Classification</strong>
                <p>
                  New niches immediately become available across all creator sign-up forms, media kits, filter pills, and smart sorting algorithms.
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddNicheModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-md"
                >
                  Add Niche Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. DIRECTOR CREATOR STATUS & REASON CONTROL MODAL */}
      {showStatusModal && selectedCreatorForStatus && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-amber-500/50 rounded-3xl w-full max-w-xl p-6 sm:p-7 space-y-6 shadow-2xl animate-fade-in font-sans max-h-[90vh] overflow-y-auto">
            {/* Header */}
            <div className="flex justify-between items-start border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/20">
                    <Shield className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      Director Creator Status & Reason Control
                    </h3>
                    <p className="text-xs text-slate-400">
                      Manage active representation status, effective dates, and audit reasons on the director roster.
                    </p>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowStatusModal(false);
                  setSelectedCreatorForStatus(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-xl hover:bg-white/5 cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Creator Profile Banner */}
            <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-300 font-bold text-base">
                  {selectedCreatorForStatus.avatar ? (
                    <img src={selectedCreatorForStatus.avatar} alt={selectedCreatorForStatus.name} className="w-full h-full object-cover rounded-xl" />
                  ) : (
                    selectedCreatorForStatus.name.charAt(0)
                  )}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    {selectedCreatorForStatus.name}
                    <span className="text-xs text-amber-400/90 font-mono font-normal">
                      ({selectedCreatorForStatus.handle})
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400 font-mono">
                    {selectedCreatorForStatus.platform || 'TikTok'} • {selectedCreatorForStatus.niche || 'Lifestyle'} • Reach: {selectedCreatorForStatus.followers || '250K'}
                  </p>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="text-[10px] uppercase font-mono text-slate-400 block mb-1">Current Status</span>
                <span className={`text-xs font-bold px-3 py-1 rounded-xl border inline-flex items-center gap-1.5 ${
                  selectedCreatorForStatus.status === 'Active'
                    ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                    : selectedCreatorForStatus.status === 'Not Active' || selectedCreatorForStatus.status === 'Inactive'
                      ? 'bg-rose-950/80 border-rose-500/40 text-rose-300'
                      : 'bg-amber-950/80 border-amber-500/40 text-amber-300'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${
                    selectedCreatorForStatus.status === 'Active' ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'
                  }`} />
                  {selectedCreatorForStatus.status === 'Active' ? 'Active' : (selectedCreatorForStatus.status || 'Not Active')}
                </span>
              </div>
            </div>

            {/* Status Change Form */}
            <form onSubmit={handleSaveStatusForm} className="space-y-5">
              {/* 1. Status Selection Grid */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-slate-300 uppercase font-semibold flex items-center justify-between">
                  <span>Select Roster Status</span>
                  <span className="text-amber-400/80 lowercase text-[11px] font-normal">* required</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Option 1: Active */}
                  <button
                    type="button"
                    id="btn-status-option-active"
                    onClick={() => setStatusFormValue('Active')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      statusFormValue === 'Active'
                        ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500/30'
                        : 'bg-[#111E33] border-white/10 text-slate-300 hover:border-emerald-500/40 hover:bg-[#15243f]'
                    }`}
                  >
                    <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0 text-base">
                      🟢
                    </span>
                    <div className="space-y-0.5">
                      <div className="font-bold text-xs flex items-center gap-1.5">
                        <span>Active Roster</span>
                        {statusFormValue === 'Active' && <Check className="w-3.5 h-3.5 text-emerald-400 ml-auto" />}
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        Available for inbound brand deals, pitch decks, and campaigns.
                      </p>
                    </div>
                  </button>

                  {/* Option 2: Not Active */}
                  <button
                    type="button"
                    id="btn-status-option-not-active"
                    onClick={() => setStatusFormValue('Not Active')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      statusFormValue === 'Not Active'
                        ? 'bg-rose-950/80 border-rose-500 text-rose-200 ring-2 ring-rose-500/30'
                        : 'bg-[#111E33] border-white/10 text-slate-300 hover:border-rose-500/40 hover:bg-[#15243f]'
                    }`}
                  >
                    <span className="p-2 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/30 shrink-0 text-base">
                      🔴
                    </span>
                    <div className="space-y-0.5">
                      <div className="font-bold text-xs flex items-center gap-1.5">
                        <span>Not Active</span>
                        {statusFormValue === 'Not Active' && <Check className="w-3.5 h-3.5 text-rose-400 ml-auto" />}
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        Hidden from active brand matchmaking and pitching.
                      </p>
                    </div>
                  </button>

                  {/* Option 3: Paused / Hiatus */}
                  <button
                    type="button"
                    id="btn-status-option-paused"
                    onClick={() => setStatusFormValue('Paused')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      statusFormValue === 'Paused'
                        ? 'bg-amber-950/80 border-amber-500 text-amber-200 ring-2 ring-amber-500/30'
                        : 'bg-[#111E33] border-white/10 text-slate-300 hover:border-amber-500/40 hover:bg-[#15243f]'
                    }`}
                  >
                    <span className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0 text-base">
                      ⏸️
                    </span>
                    <div className="space-y-0.5">
                      <div className="font-bold text-xs flex items-center gap-1.5">
                        <span>Paused / Hiatus</span>
                        {statusFormValue === 'Paused' && <Check className="w-3.5 h-3.5 text-amber-400 ml-auto" />}
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        Creator taking vacation, filming break, or temporary lockout.
                      </p>
                    </div>
                  </button>

                  {/* Option 4: Offboarded */}
                  <button
                    type="button"
                    id="btn-status-option-offboarded"
                    onClick={() => setStatusFormValue('Offboarded')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      statusFormValue === 'Offboarded'
                        ? 'bg-slate-900 border-slate-500 text-slate-200 ring-2 ring-slate-500/30'
                        : 'bg-[#111E33] border-white/10 text-slate-300 hover:border-slate-500/40 hover:bg-[#15243f]'
                    }`}
                  >
                    <span className="p-2 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 shrink-0 text-base">
                      📁
                    </span>
                    <div className="space-y-0.5">
                      <div className="font-bold text-xs flex items-center gap-1.5">
                        <span>Offboarded / Archived</span>
                        {statusFormValue === 'Offboarded' && <Check className="w-3.5 h-3.5 text-slate-300 ml-auto" />}
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        Completed one-and-done deal or contract term ended.
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* 2. Effective Date */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor="input-status-date" className="text-xs font-mono text-slate-300 uppercase font-semibold flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    <span>Effective Date</span>
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setStatusFormDate(new Date().toISOString().split('T')[0])}
                      className="text-[10px] font-mono text-amber-400 hover:underline px-1.5 py-0.5 bg-amber-500/10 rounded border border-amber-500/20 cursor-pointer"
                    >
                      Today
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const d = new Date();
                        d.setDate(d.getDate() + 1);
                        setStatusFormDate(d.toISOString().split('T')[0]);
                      }}
                      className="text-[10px] font-mono text-amber-400 hover:underline px-1.5 py-0.5 bg-amber-500/10 rounded border border-amber-500/20 cursor-pointer"
                    >
                      Tomorrow
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const d = new Date();
                        d.setMonth(d.getMonth() + 1, 1);
                        setStatusFormDate(d.toISOString().split('T')[0]);
                      }}
                      className="text-[10px] font-mono text-amber-400 hover:underline px-1.5 py-0.5 bg-amber-500/10 rounded border border-amber-500/20 cursor-pointer"
                    >
                      1st of Next Month
                    </button>
                  </div>
                </div>
                <input
                  id="input-status-date"
                  type="date"
                  required
                  value={statusFormDate}
                  onChange={(e) => setStatusFormDate(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-mono"
                />
              </div>

              {/* 3. Reason / Explanation (Why) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label htmlFor="textarea-status-reason" className="text-xs font-mono text-slate-300 uppercase font-semibold flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-amber-400" />
                    <span>Reason for Status Change (Why)</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono">Audit Logged</span>
                </div>
                <textarea
                  id="textarea-status-reason"
                  required
                  rows={3}
                  placeholder="Explain why this creator is being marked as active or not active (e.g., returned from summer vacation, exclusivity lockout with competitor brand, contract renewal negotiations, single-deal completion)..."
                  value={statusFormReason}
                  onChange={(e) => setStatusFormReason(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all placeholder:text-slate-500 leading-relaxed"
                />

                {/* Quick-Fill Reason Chips */}
                <div className="space-y-1">
                  <span className="text-[10px] font-mono text-slate-400 block">Quick 1-Click Reason Presets:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { label: "🌟 Active & Available for Brand Deals", status: "Active" },
                      { label: "🎯 Returned from Vacation / Hiatus", status: "Active" },
                      { label: "🏖️ Creator Vacation / Seasonal Break", status: "Paused" },
                      { label: "⏳ Contract Renewal Underway", status: "Paused" },
                      { label: "🛑 Brand Exclusivity Lockout Active", status: "Not Active" },
                      { label: "📋 One-and-Done Deal Complete", status: "Offboarded" },
                      { label: "⚖️ Legal & Brand Safety Compliance Review", status: "Not Active" }
                    ].map((chip) => (
                      <button
                        key={chip.label}
                        type="button"
                        onClick={() => {
                          setStatusFormReason(chip.label);
                          setStatusFormValue(chip.status);
                        }}
                        className="text-[10px] bg-[#111E33] hover:bg-[#1c2e4d] text-slate-300 hover:text-amber-300 border border-white/5 hover:border-amber-500/40 px-2.5 py-1 rounded-lg transition-colors cursor-pointer font-medium"
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* 4. Director Control Attribution */}
              <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 flex items-center justify-between text-xs text-slate-300">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span className="font-mono text-[11px]">
                    Authorized by: <strong className="text-white">{currentUser?.name || 'User'}</strong> ({typeof currentRole === 'string' ? currentRole : 'director'})
                  </span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  Saved to Director Roster & Audit Vault
                </span>
              </div>

              {/* 5. Past Status Change Audit History (if available) */}
              {selectedCreatorForStatus.statusHistory && selectedCreatorForStatus.statusHistory.length > 0 && (
                <div className="space-y-2 border-t border-white/10 pt-3">
                  <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold block flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-400" /> Past Status History Audit Trail ({selectedCreatorForStatus.statusHistory.length})
                  </span>
                  <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1">
                    {selectedCreatorForStatus.statusHistory.slice(-3).reverse().map((h, i) => (
                      <div key={h.id || i} className="bg-[#091122] border border-white/5 rounded-lg p-2 text-[10px] space-y-0.5">
                        <div className="flex items-center justify-between font-mono">
                          <span className="font-bold text-amber-300">{h.status}</span>
                          <span className="text-slate-400">{h.date} • by {h.changedBy || 'User'}</span>
                        </div>
                        {h.reason && (
                          <p className="text-slate-300 italic">"{h.reason}"</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setShowStatusModal(false);
                    setSelectedCreatorForStatus(null);
                  }}
                  className="px-4 py-2.5 text-xs font-semibold text-slate-400 hover:text-white cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  id="btn-save-creator-status"
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-lg hover:shadow-amber-500/20 flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4 text-[#0A1220]" />
                  <span>Update Creator Status & Save</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Share Showcase Links Dialog Modal */}
      {showShareShowcaseModal && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0A1220] border border-[#D4AF37]/40 rounded-2xl w-full max-w-lg p-6 space-y-5 text-white shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-serif font-bold text-white">Shareable Agency Links</h3>
                  <p className="text-[11px] text-slate-300">Copy links to share with brands, sponsors, and clients</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowShareShowcaseModal(false)}
                className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3.5">
              {/* Link 1: Master Agency Showcase */}
              <div className="bg-[#050C18] p-3.5 rounded-xl border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#D4AF37] font-mono flex items-center gap-1.5">
                    🌟 Full Talent Showcase (Entire Roster)
                  </span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-mono">Public Access</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Interactive agency gallery featuring all represented creators filtered by niche, follower tiers, and booking requests.
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    readOnly
                    value={`${typeof window !== 'undefined' ? window.location.origin : ''}/#showcase`}
                    className="flex-1 bg-[#0D1830] border border-white/15 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const url = `${window.location.origin}/#showcase`;
                      navigator.clipboard.writeText(url);
                      if (triggerNotification) triggerNotification('Copied!', 'Full Showcase link copied to clipboard.', 'success');
                    }}
                    className="bg-[#D4AF37] hover:bg-[#e0bb43] text-black font-bold text-xs px-3 py-1.5 rounded-lg font-mono transition"
                  >
                    Copy
                  </button>
                </div>
              </div>

              {/* Link 2: Match or Pass Deck */}
              <div className="bg-[#050C18] p-3.5 rounded-xl border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-300 font-mono flex items-center gap-1.5">
                    🃏 Match or Pass Casting Deck
                  </span>
                  <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded font-mono">Interactive Deck</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Swipe/Match/Pass talent deck for brands to review proposed creator lists for upcoming campaigns.
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    readOnly
                    value={`${typeof window !== 'undefined' ? window.location.origin : ''}/#match-pass`}
                    className="flex-1 bg-[#0D1830] border border-white/15 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const url = `${window.location.origin}/#match-pass`;
                      navigator.clipboard.writeText(url);
                      if (triggerNotification) triggerNotification('Copied!', 'Match or Pass Deck link copied to clipboard.', 'success');
                    }}
                    className="bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs px-3 py-1.5 rounded-lg font-mono transition"
                  >
                    Copy
                  </button>
                </div>
              </div>

              {/* Link 3: Individual Media Kits */}
              <div className="bg-[#050C18] p-3.5 rounded-xl border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-purple-300 font-mono flex items-center gap-1.5">
                    🎨 Individual Creator Media Kits
                  </span>
                  <span className="text-[10px] text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded font-mono">Single Creator</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Format: <code className="text-purple-300 font-mono">/#portfolio?creator=@handle</code> &bull; Share specific creator media kits directly with brand managers.
                </p>
              </div>
            </div>

            <div className="pt-2 text-right border-t border-white/10">
              <button
                type="button"
                onClick={() => setShowShareShowcaseModal(false)}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-mono text-xs rounded-xl transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
