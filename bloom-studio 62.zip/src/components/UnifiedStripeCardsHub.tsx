import React, { useState } from 'react';
import { 
  CreditCard, 
  ShieldCheck, 
  Zap, 
  Lock, 
  Unlock, 
  DollarSign, 
  Building, 
  Layers, 
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { Creator } from '../types';
import StripeDebitCardController from './StripeDebitCardController';
import { JustInTimeStripeCard } from './JustInTimeStripeCard';

interface UnifiedStripeCardsHubProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
  defaultTab?: 'controller' | 'jit';
}

export const UnifiedStripeCardsHub: React.FC<UnifiedStripeCardsHubProps> = ({
  creators = [],
  currentUser,
  currentRole = 'creator',
  onAddActivityLog,
  triggerNotification,
  defaultTab = 'controller'
}) => {
  const [activeTab, setActiveTab] = useState<'controller' | 'jit'>(defaultTab);

  const primaryBrandColor = '#C9A46A';
  const cardBgColor = '#0D1830';

  return (
    <div className="space-y-6 animate-fade-in" id="unifiedStripeCardsHub">
      {/* Top Banner & Hub Header */}
      <div 
        className="rounded-2xl p-6 border shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6"
        style={{
          backgroundColor: cardBgColor,
          borderColor: `${primaryBrandColor}30`
        }}
      >
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold px-2.5 py-1 rounded-full border text-[#C9A46A] border-[#C9A46A]/30 bg-[#C9A46A]/10 flex items-center gap-1.5">
              <CreditCard className="w-3 h-3" />
              Stripe Issuing &amp; Treasury Hub
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
              Zero-Trust JIT Corporate Cards
            </span>
          </div>

          <h1 className="text-2xl lg:text-3xl font-serif font-bold text-white tracking-tight flex items-center gap-3">
            <ShieldCheck className="w-7 h-7 text-[#C9A46A]" />
            <span>Stripe Debit Card Controller &amp; JIT Issuing Hub</span>
          </h1>

          <p className="text-xs text-slate-300 leading-relaxed">
            Manage corporate expense limits, review manager approval queues, and request or unlock Just-In-Time (JIT) virtual debit cards for instant production supply purchases with automated receipt reconciliation.
          </p>
        </div>

        {/* Master Tab Selector */}
        <div className="flex flex-col sm:flex-row items-center gap-2.5 shrink-0 bg-[#070D18] p-1.5 rounded-2xl border border-white/10 shadow-inner">
          <button
            type="button"
            id="tabBtnDebitController"
            onClick={() => setActiveTab('controller')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeTab === 'controller'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Stripe Debit Controller (Agency)</span>
          </button>

          <button
            type="button"
            id="tabBtnJitCard"
            onClick={() => setActiveTab('jit')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeTab === 'jit'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>JIT Virtual Cards &amp; Swipes (Creator)</span>
          </button>
        </div>
      </div>

      {/* Active Tab View */}
      <div className="transition-all">
        {activeTab === 'controller' ? (
          <StripeDebitCardController
            creators={creators}
            currentUser={currentUser}
            currentRole={currentRole as any}
            onAddActivityLog={onAddActivityLog}
            triggerNotification={triggerNotification}
          />
        ) : (
          <JustInTimeStripeCard
            creators={creators}
            currentUser={currentUser}
            currentRole={currentRole}
            onAddActivityLog={onAddActivityLog}
            triggerNotification={triggerNotification}
          />
        )}
      </div>
    </div>
  );
};

export default UnifiedStripeCardsHub;
