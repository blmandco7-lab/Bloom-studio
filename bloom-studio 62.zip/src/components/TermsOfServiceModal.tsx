import React, { useState } from 'react';
import { 
  Shield, FileText, CheckCircle2, X, Lock, Award, Landmark, 
  UserCheck, AlertCircle, Download, Clock, AlertTriangle, LogOut, 
  Loader2, Eye, HelpCircle, ExternalLink, ShieldCheck 
} from 'lucide-react';
import { computeRealSha256, persistSignatureRecord, recordAgreementInVault } from '../lib/cryptoSignatures';
import { safeStorage } from '../utils/safeStorage';
import PrivacyPolicyModal from './PrivacyPolicyModal';
import AccessibilityStatementModal from './AccessibilityStatementModal';

interface TermsOfServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: any;
  currentRole?: string;
  onSignTerms?: (signatureName: string, dateStr: string) => void;
  onDecline?: () => void;
  isMandatoryGate?: boolean;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

export default function TermsOfServiceModal({
  isOpen,
  onClose,
  currentUser,
  currentRole = 'director',
  onSignTerms,
  onDecline,
  isMandatoryGate = false,
  triggerNotification
}: TermsOfServiceModalProps) {
  const userKey = currentUser?.id || currentUser?.uid || currentUser?.email || 'guest';
  const userEmail = currentUser?.email || '';

  const [activeArticle, setActiveArticle] = useState<number>(1);
  const [signatureName, setSignatureName] = useState<string>(currentUser?.name || 'Director (Authorized Partner)');
  const [isCertified, setIsCertified] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState<boolean>(false);
  const [showAccessibilityModal, setShowAccessibilityModal] = useState<boolean>(false);

  const [signedRecord, setSignedRecord] = useState<{ name: string; timestamp: string; hash: string } | null>(() => {
    try {
      if (currentUser?.hasSignedToS || currentUser?.tosSignedAt) {
        return {
          name: currentUser.tosSignerName || currentUser.name || currentUser.displayName || 'Authorized Signer',
          timestamp: currentUser.tosSignedAt ? new Date(currentUser.tosSignedAt).toLocaleString() : new Date().toLocaleString(),
          hash: currentUser.tosDigest || 'SHA256:VERIFIED:ON_FILE'
        };
      }
      const savedUserSpecific = userKey ? safeStorage.getItem(`bloom_tos_signature_${userKey}`) : null;
      if (savedUserSpecific) return JSON.parse(savedUserSpecific);
      const saved = safeStorage.getItem('bloom_tos_signature');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });


  if (!isOpen) return null;

  const handleExecuteTerms = async () => {
    const finalName = signatureName.trim();
    if (!finalName) {
      if (triggerNotification) {
        triggerNotification('Signature Required', 'Please type your full legal name to sign the agreement.', 'danger');
      }
      return;
    }
    if (!isCertified) {
      if (triggerNotification) {
        triggerNotification('Certification Required', 'You must check the certification box to agree to the terms.', 'warning');
      }
      return;
    }

    setIsSubmitting(true);
    const nowIso = new Date().toISOString();
    const nowStr = new Date().toLocaleString();
    let record: any = null;

    try {
      const payloadToHash = `BLOOM_AGENCY_TOS_V2026|SIGNER:${finalName}|ROLE:${currentRole}|USER_ID:${currentUser?.id || currentUser?.uid || 'guest'}|DATE:${nowIso}`;
      const hashStr = await computeRealSha256(payloadToHash);

      record = {
        name: finalName,
        timestamp: nowStr,
        isoTimestamp: nowIso,
        hash: hashStr,
        version: 'v2026.1',
        role: currentRole,
        userId: currentUser?.id || currentUser?.uid || 'guest'
      };

      // Persist to secure server-side signature endpoint
      const docId = `tos_v2026_${currentUser?.id || currentUser?.uid || Date.now()}`;
      try {
        await persistSignatureRecord({
          id: docId,
          documentType: 'Agency Terms of Service',
          signerName: finalName,
          signerEmail: currentUser?.email,
          signerRole: currentRole,
          isoTimestamp: nowIso,
          formattedTimestamp: nowStr,
          digest: hashStr,
          payloadContent: payloadToHash,
          metadata: { version: 'v2026.1' }
        });
      } catch (persistErr) {
        console.warn('[TermsOfServiceModal] Remote persistence fallback triggered:', persistErr);
      }

      // Save to safe storage with verified cryptographic digest (global and per-user)
      safeStorage.setItem('bloom_tos_signature', JSON.stringify(record));
      safeStorage.setItem(`bloom_tos_signature_${userKey}`, JSON.stringify(record));
      safeStorage.setItem('bloom_agency_tos_v2026_signed', 'true');
      safeStorage.setItem(`bloom_agency_tos_v2026_signed_${userKey}`, 'true');
      if (userEmail) {
        safeStorage.setItem(`bloom_tos_signed_${userEmail}`, 'true');
      }
      setSignedRecord(record);

      if (onSignTerms) {
        onSignTerms(finalName, nowIso);
      }
      if (triggerNotification) {
        triggerNotification('Agency Terms Executed', `Agreement executed by ${finalName}. Real SHA-256 cryptographic digest recorded.`, 'success');
      }
    } catch (err: any) {
      console.error('[TermsOfServiceModal] Signature failed:', err);
      if (record) {
        recordAgreementInVault({
          id: `tos_v2026_${currentUser?.id || currentUser?.uid || Date.now()}`,
          documentType: 'Agency Terms of Service & Partner Agreement',
          signerName: finalName,
          signerEmail: currentUser?.email || '',
          organization: currentUser?.organization || currentUser?.company || 'Bloom Agency Network',
          signerRole: currentRole,
          isoTimestamp: nowIso,
          formattedTimestamp: nowStr,
          digest: record.hash,
          clausesAccepted: [
            'Master Platform License & Account Security',
            'Sub-Agency Escrow Separation Covenants',
            'Agency Indemnification & Hold Harmless',
            'FTC Advertising & Endorsement Guidelines',
            'Confidentiality & Non-Disclosure (NDA)'
          ]
        });
      }
      // Resilient fallback: accept valid cryptographic digest locally
      safeStorage.setItem('bloom_tos_signature', JSON.stringify(record));
      safeStorage.setItem(`bloom_tos_signature_${userKey}`, JSON.stringify(record));
      safeStorage.setItem('bloom_agency_tos_v2026_signed', 'true');
      safeStorage.setItem(`bloom_agency_tos_v2026_signed_${userKey}`, 'true');
      if (userEmail) {
        safeStorage.setItem(`bloom_tos_signed_${userEmail}`, 'true');
      }
      setSignedRecord(record);
      if (onSignTerms) {
        onSignTerms(finalName, nowIso);
      }
      if (triggerNotification) {
        triggerNotification('Agency Terms Executed', `Agreement executed by ${finalName}.`, 'info');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEnterWorkspace = () => {
    const finalName = signedRecord?.name || signatureName.trim() || 'Director (Authorized Partner)';
    const timestamp = signedRecord?.timestamp || new Date().toISOString();
    safeStorage.setItem('bloom_agency_tos_v2026_signed', 'true');
    safeStorage.setItem(`bloom_agency_tos_v2026_signed_${userKey}`, 'true');
    if (userEmail) {
      safeStorage.setItem(`bloom_tos_signed_${userEmail}`, 'true');
    }
    if (onSignTerms) {
      onSignTerms(finalName, timestamp);
    } else {
      onClose();
    }
  };

  const articles = [
    {
      id: 1,
      title: "Article 1: Master Agency & Software Platform License",
      summary: "Scope of access, software-as-a-service licensing, and platform availability.",
      content: `1.1 GRANT OF LICENSE: Bloom Studio ("Licensor") hereby grants to the signed user ("Partner", "Creator", or "Agency Tenant") a revocable, non-exclusive, non-transferable, limited software license to access and utilize the Bloom Studio Agency Operating System and Creator Portal.

1.2 PLATFORM AVAILABILITY & NO WARRANTY: The platform provides campaign pipeline tracking, electronic tax documentation (IRS W-9 and Form 1099-NEC workflows), escrow payout ledgers, FTC compliance verification, and communication tools. All software features are provided strictly on an "as-is" and "as-available" basis without representations or warranties of any kind.

1.3 ACCOUNT RESPONSIBILITY: Each account holder is strictly responsible for maintaining the confidentiality of their login credentials, multi-factor authentication tokens, and API secret keys.`
    },
    {
      id: 2,
      title: "Article 2: Sub-Agency Multi-Channel Network (MCN) Model & Escrow Separation",
      summary: "Financial separation of internal sub-agencies and independent escrow ledgers.",
      content: `2.1 SUB-AGENCY NETWORK ARCHITECTURE: Similar to Multi-Channel Network (MCN) and affiliate agency structures, Bloom Studio allows Master HQ to create internal and affiliate "Sub-Agency Pods." Each Sub-Agency Pod operates under its own brand identity, logo, and dedicated team leads.

2.2 STRICT ESCROW FINANCIAL SEPARATION: By executing this Agreement, all parties expressly acknowledge and agree that EACH SUB-AGENCY POD MAINTAINS ITS OWN INDEPENDENT STRIPE CONNECT ESCROW LEDGER AND FINANCIAL ACCOUNTS. Master Headquarters (Bloom Studio HQ) is NEVER financially liable, responsible, or co-liable for:
  (a) Sub-agency creator payouts, escrow distributions, or milestone settlements;
  (b) Sub-agency chargebacks, client disputes, or brand contract defaults;
  (c) Any debts, obligations, or tax withholding liabilities incurred by a Sub-Agency Pod.

2.3 SHARED COMPLIANCE & SAFETY STANDARDS: While financial accounts and escrow balances are 100% separate, all Sub-Agency Pods share and must strictly adhere to Master HQ's universal compliance framework, including FTC sponsorship disclosure rules, W-9/1099-NEC tax verification, and creator anti-poaching policies.`
    },
    {
      id: 3,
      title: "Article 3: Agency Indemnification & Hold Harmless",
      summary: "Mandatory creator/partner indemnification protecting Bloom Studio HQ from liabilities.",
      content: `3.1 FULL INDEMNIFICATION OF AGENCY: Creator, Partner, and Sub-Agency Tenant agree to defend, indemnify, and hold harmless Bloom Studio Headquarters, its founders, directors, officers, employees, and legal representatives from and against any and all claims, lawsuits, damages, FTC enforcement actions, fines, penalties, copyright infringement claims, tax audits, or legal fees arising out of or related to:
  (a) Content published, broadcast, or distributed by the Creator or their agents;
  (b) Failure by Creator or Sub-Agency to disclose sponsored advertising relationships in accordance with FTC guidelines;
  (c) Disputes between Creators and third-party brand advertisers;
  (d) Unpaid federal, state, or municipal taxes or misclassification penalties.

3.3 NO CO-LIABILITY: Bloom Studio HQ acts solely as a representation and workflow platform and shall never be joined as a co-defendant or co-liable party in any dispute arising between talent, sub-agencies, and advertising brands.`
    },
    {
      id: 4,
      title: "Article 4: Limitation of Liability & Platform Disclaimers",
      summary: "Liability caps and exclusion of indirect or consequential damages.",
      content: `4.1 EXCLUSION OF DAMAGES: In no event shall Bloom Studio HQ be liable for indirect, incidental, consequential, special, or punitive damages, including loss of brand contracts, account suspensions or bans by third-party social media platforms and digital networks, or platform downtime.

4.2 LIABILITY CAP: To the maximum extent permitted by applicable law, the total aggregate liability of Bloom Studio HQ for any claim arising out of or relating to this Agreement shall be limited to the total fees actually paid to Bloom Studio HQ by the complaining party in the thirty (30) days preceding the claim.`
    },
    {
      id: 5,
      title: "Article 5: FTC Advertising & Sponsored Content Compliance",
      summary: "Mandatory #ad and #sponsored clear disclosure requirements.",
      content: `5.1 MANDATORY DISCLOSURES: All Creators and Sub-Agencies must strictly adhere to the Federal Trade Commission (FTC) Guides Concerning the Use of Endorsements and Testimonials in Advertising (16 CFR Part 255).

5.2 EXPLICIT TAGS: Every piece of sponsored social media content (videos, photos, livestreams, stories) must include a clear, unambiguous, and conspicuous disclosure such as "#ad" or "#sponsored" placed in the first two lines of text or video overlay. Creator is solely liable for FTC compliance failures.`
    },
    {
      id: 6,
      title: "Article 6: Escrow Holds, Commission Splits & Milestone Payouts",
      summary: "Stripe Connect escrow handling and milestone release conditions.",
      content: `6.1 ESCROW DEPOSITS: Brand partners deposit campaign budgets into secure, FDIC-insured Stripe Connect Escrow accounts prior to campaign commencement.

6.2 MILESTONE RELEASE: Escrow funds are released to the Creator's registered payout method upon verified completion of contract deliverables (e.g., Draft Approval, Live Post Publication, or 30-Day Retention Check).

6.3 AGENCY COMMISSION SPLITS: Standard representation commission splits (e.g., 20% agency / 80% talent) are automatically calculated and deducted at the moment of escrow release. Creator authorizes such deductions without offset.`
    },
    {
      id: 7,
      title: "Article 7: Intellectual Property, Anti-Poaching & Non-Circumvention",
      summary: "12-month non-circumvention protection and brand license scope.",
      content: `7.1 NON-CIRCUMVENTION & ANTI-POACHING: During the term of representation and for twelve (12) months following termination, Creator and Sub-Agency agree not to circumvent Bloom Studio by entering into direct commercial contracts with any brand, advertiser, or agency introduced through the Bloom Studio platform without paying Bloom Studio its standard representation commission.

7.2 CREATOR OWNERSHIP & BRAND LICENSE: Creators retain primary copyright of original deliverables. Brand partners receive a limited digital license to display deliverables for the duration specified in the Campaign Mission Brief.`
    },
    {
      id: 8,
      title: "Article 8: Electronic W-9/1099-NEC Signatures & Tax Liability Waiver",
      summary: "E-SIGN Act compliance, IRS W-9 certifications, and independent tax liability.",
      content: `8.1 E-SIGN ACT COMPLIANCE: In accordance with the Electronic Signatures in Global and National Commerce Act (E-SIGN Act, 15 U.S.C. § 7001 et seq.), all electronic signatures executed within Bloom Studio are legally binding equivalents to handwritten physical signatures.

8.2 TAX LIABILITY WAIVER: Creator acknowledges that they operate as an independent contractor. Creator is solely liable for declaring and paying all self-employment, income, and quarterly estimated taxes. Bloom Studio HQ bears zero liability for backup withholdings or IRS penalties.

8.3 FORM 1099-NEC REPORTING: Independent contractors earning $600 or more in gross nonemployee compensation during a calendar tax year will be issued an IRS Form 1099-NEC by January 31 of the following calendar year.`
    },
    {
      id: 9,
      title: "Article 9: Confidentiality & Non-Disclosure (NDA)",
      summary: "Strict protection of agency rates, brand briefs, client rosters, and commission structures.",
      content: `9.1 CONFIDENTIALITY OBLIGATION: Creator, Partner, and Sub-Agency Tenant agree to hold in strict confidence all proprietary agency information, including but not limited to brand sponsorship budgets, master rate cards, commission structures, creator rosters, client contact lists, and unreleased Campaign Mission Briefs.

9.2 NON-DISCLOSURE: Confidential information shall not be shared with competitors, external agencies, press, or unauthorized third parties during or after representation without express written authorization from Bloom Studio HQ.`
    },
    {
      id: 10,
      title: "Article 10: Morality, Brand Reputation & Conduct Clause",
      summary: "Protection of agency and brand goodwill against public controversy or reputational harm.",
      content: `10.1 MORALITY & CONDUCT CLAUSE: If a Creator or Sub-Agency engages in illegal acts, hate speech, moral turpitude, public scandal, or intentional misconduct that materially damages the reputation or goodwill of Bloom Studio HQ or its advertising brand partners, Bloom Studio HQ reserves the right to terminate representation immediately.

10.2 FORFEITURE OF PENDING BONUSES: In the event of termination under Section 10.1, Creator forfeits rights to discretionary bonuses and unvested milestone incentives, and remains liable for any third-party brand cancellation damages.`
    },
    {
      id: 11,
      title: "Article 11: Artificial Intelligence (AI) & Synthetic Media Disclosures",
      summary: "Mandatory disclosure of AI-generated avatars, deepfakes, or cloned voiceovers.",
      content: `11.1 SYNTHETIC MEDIA COMPLIANCE: Any use of generative artificial intelligence (AI), synthetic avatars, cloned voiceovers, or digitally altered likenesses in sponsored campaign deliverables must be explicitly disclosed in accordance with FTC guidelines and platform advertising rules.

11.2 LIABILITY FOR UNDISCLOSED AI: Creator is strictly and solely liable for any copyright infringement, publicity right violation, or regulatory fine resulting from undisclosed or unauthorized AI-generated assets.`
    },
    {
      id: 12,
      title: "Article 12: Dispute Resolution, Mandatory Arbitration & Class Action Waiver",
      summary: "Binding individual arbitration under AAA rules and waiver of class action lawsuits.",
      content: `12.1 BINDING INDIVIDUAL ARBITRATION: Any controversy, claim, or dispute arising out of or relating to this Agreement, agency representation, commission splits, or escrow payouts shall be settled by binding individual arbitration administered under the rules of the American Arbitration Association (AAA).

12.2 CLASS ACTION WAIVER: All parties agree that disputes shall be arbitrated only on an individual basis and not in a class, consolidated, or representative action. Creator and Sub-Agency expressly waive any right to file or participate in a class action lawsuit against Bloom Studio HQ.`
    }
  ];

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="tos-modal-title"
    >
      <div className="bg-[#0B1424] border border-[#C9A46A]/40 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-left">
        {/* Mandatory Legal Gate Notice when popping up before app entry */}
        {isMandatoryGate && (
          <div className="bg-amber-500/20 border-b border-amber-500/40 px-5 py-2.5 flex items-center justify-between text-xs text-amber-200">
            <div className="flex items-center gap-2 font-semibold">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" aria-hidden="true" />
              <span>MANDATORY AGENCY LEGAL GATE: You must electronically execute these agency-protecting Terms of Service before accessing the Bloom Studio workspace.</span>
            </div>
            <span className="font-mono text-[10px] bg-amber-500/30 text-amber-300 px-2.5 py-0.5 rounded font-bold uppercase tracking-wider">
              REQUIRED
            </span>
          </div>
        )}

        {/* Header */}
        <div className="p-5 bg-[#111E33] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#C9A46A]/10 border border-[#C9A46A]/30 flex items-center justify-center text-[#C9A46A]">
              <Shield className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-[#C9A46A] font-mono font-bold uppercase tracking-wider">
                  Official Agency Protection Agreement • Effective 2026
                </span>
                <span className="text-[10px] font-mono text-[#7C8AA8]">
                  v2026.1
                </span>
              </div>
              <h2 id="tos-modal-title" className="text-lg font-serif font-bold text-white">
                Bloom Studio Agency Terms of Service &amp; Partner Agreement
              </h2>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPrivacyModal(true)}
              className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-[#7C8AA8] hover:text-white flex items-center gap-1.5 transition"
              title="Open Platform Privacy Policy"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="hidden sm:inline">Privacy Policy</span>
            </button>
            <button
              onClick={() => setShowAccessibilityModal(true)}
              className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-[#7C8AA8] hover:text-white flex items-center gap-1.5 transition"
              title="Open Accessibility Statement (WCAG 2.1 AA)"
            >
              <Eye className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Accessibility</span>
            </button>
            {!isMandatoryGate && (
              <button
                onClick={onClose}
                aria-label="Close Agreement Modal"
                className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-white/10">
          {/* Left Navigation Menu (4 columns) */}
          <div className="md:col-span-4 p-4 space-y-1 bg-[#09111E]" role="navigation" aria-label="Terms of Service Articles">
            <div className="text-[10px] font-mono font-bold text-[#7C8AA8] uppercase tracking-wider px-3 py-1">
              Agreement Articles
            </div>
            {articles.map((art) => (
              <button
                key={art.id}
                onClick={() => setActiveArticle(art.id)}
                className={`w-full text-left p-3 rounded-xl transition-all ${
                  activeArticle === art.id
                    ? 'bg-[#16243F] border border-[#C9A46A]/40 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
                aria-pressed={activeArticle === art.id}
              >
                <div className="text-xs font-bold leading-tight">{art.title}</div>
                <div className="text-[10px] text-[#7C8AA8] mt-1 line-clamp-2 leading-relaxed">{art.summary}</div>
              </button>
            ))}

            <div className="pt-4 mt-4 border-t border-white/10 space-y-2">
              <div className="bg-[#111E33]/80 rounded-xl p-3 border border-amber-500/20 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-amber-300 font-semibold">
                  <Shield className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Agency Indemnification</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Creator &amp; Partner agree to defend and indemnify Bloom Studio HQ from any FTC penalties, copyright claims, or tax liabilities.
                </p>
              </div>
              <div className="bg-[#111E33]/80 rounded-xl p-3 border border-blue-500/20 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-blue-300 font-semibold">
                  <Landmark className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Sub-Agency Escrow Separation</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Sub-agency pods maintain 100% separate Stripe escrow accounts. Master HQ is never liable for sub-agency financial payouts.
                </p>
              </div>
            </div>
          </div>

          {/* Right Article Viewer & Electronic Signature Box (8 columns) */}
          <div className="md:col-span-8 p-6 space-y-6 overflow-y-auto" tabIndex={0} aria-label="Active Agreement Article Content">
            {/* Article Content Only */}
            {articles.map((art) => (
              art.id === activeArticle && (
                <div key={art.id} className="space-y-4 animate-fade-in">
                  <div className="border-b border-white/10 pb-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.5 rounded">
                      Article #{art.id} of {articles.length}
                    </span>
                    <h3 className="text-xl font-serif font-bold text-white mt-2">{art.title}</h3>
                  </div>
                  <div className="text-xs text-slate-300 whitespace-pre-line leading-relaxed font-sans bg-[#0E1728] p-4 rounded-xl border border-white/5">
                    {art.content}
                  </div>
                </div>
              )
            ))}
          </div>
        </div>

        {/* STICKY ALWAYS-VISIBLE BOTTOM AGREEMENT FOOTER */}
        <div className="bg-[#0A1220] border-t border-[#C9A46A]/40 p-4 sm:p-5 shadow-2xl z-20 shrink-0">
          {signedRecord ? (
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-3.5">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" aria-hidden="true" />
                <div>
                  <div className="text-xs font-bold text-white">
                    Agency Terms Executed by {signedRecord.name}
                  </div>
                  <div className="text-[10px] text-emerald-300 font-mono">
                    Executed: {signedRecord.timestamp} • SHA-256 Audit Recorded
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
                <button
                  onClick={() => setSignedRecord(null)}
                  className="text-xs text-amber-400 hover:underline px-2 py-1"
                >
                  Re-Sign
                </button>
                <button
                  onClick={handleEnterWorkspace}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-6 py-2.5 rounded-xl text-xs transition shadow-lg shadow-emerald-500/20 flex items-center gap-1.5 shrink-0"
                >
                  <CheckCircle2 className="w-4 h-4" /> Enter Agency Workspace →
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <label htmlFor="tos-certified-checkbox" className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300 flex-1">
                  <input
                    id="tos-certified-checkbox"
                    type="checkbox"
                    checked={isCertified}
                    onChange={(e) => setIsCertified(e.target.checked)}
                    className="mt-0.5 rounded border-white/20 text-[#C9A46A] focus:ring-[#C9A46A] bg-[#0E1728]"
                  />
                  <span className="leading-relaxed">
                    I agree to be legally bound by all 12 Articles of the Bloom Studio Agency Terms of Service, including indemnification, confidentiality (NDA), morality clause, and binding individual arbitration.
                  </span>
                </label>
                <div className="w-full sm:w-64 shrink-0">
                  <label htmlFor="tos-signature-name-input" className="sr-only">Full Legal Name for Electronic Signature</label>
                  <input
                    id="tos-signature-name-input"
                    type="text"
                    value={signatureName}
                    onChange={(e) => setSignatureName(e.target.value)}
                    placeholder="Type Full Legal Name to Sign..."
                    aria-label="Full Legal Name to Sign"
                    className="w-full bg-[#0E1728] border border-white/20 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between gap-3 pt-2 border-t border-white/10">
                {isMandatoryGate ? (
                  <button
                    onClick={onDecline}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-rose-300 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 flex items-center gap-1.5 transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" aria-hidden="true" /> Decline &amp; Exit Workspace
                  </button>
                ) : (
                  <button
                    onClick={onClose}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition-colors"
                  >
                    Close
                  </button>
                )}

                <button
                  onClick={handleExecuteTerms}
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all bg-gradient-to-r from-[#C9A46A] to-[#e4c28a] hover:from-[#b8935a] hover:to-[#d3b177] text-[#0B1424] shadow-lg shadow-[#C9A46A]/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserCheck className="w-4 h-4" />}
                  {isSubmitting ? 'Recording Electronic Signature...' : (isMandatoryGate ? 'Sign Agreement & Enter Workspace →' : 'Sign & Execute Agreement →')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Embedded Sub-Modals for Privacy and Accessibility */}
      <PrivacyPolicyModal
        isOpen={showPrivacyModal}
        onClose={() => setShowPrivacyModal(false)}
        triggerNotification={triggerNotification}
      />

      <AccessibilityStatementModal
        isOpen={showAccessibilityModal}
        onClose={() => setShowAccessibilityModal(false)}
        triggerNotification={triggerNotification}
      />
    </div>
  );
}

