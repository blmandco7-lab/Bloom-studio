import React, { useState } from 'react';
import { DollarSign, ShieldAlert, CheckCircle2, Clock, ArrowRight, UserCheck, AlertCircle } from 'lucide-react';
import { UserProfile } from './RoleGuardedCampaignWorkspace';

export type PayoutStatus = 'Pending Verification' | 'Locked for Payroll' | 'Disbursed via Transfer';

export interface ManagerPayrollEntry {
  id: string;
  projectName: string;
  dateRange: string;
  assignedManagerName: string;
  assignedManagerUid: string;
  baseCompensation: number;
  bonusOverride?: number;
  payoutStatus: PayoutStatus;
}

export interface UserProfileWithRole {
  uid: string;
  name: string;
  email: string;
  role: 'Owner' | 'Manager' | 'Director' | 'AgentManager' | 'Agent' | 'Coordinator';
  position?: string;
  assignedPod?: string;
  totalEarnedToDate?: number;
  pendingDisbursal?: number;
  managerCompensation?: {
    payType?: 'Per Campaign' | 'Percentage' | 'Monthly Retainer';
    amount?: number;
  };
}

interface ManagerCommissionLogProps {
  currentUser: UserProfileWithRole;
  initialEntries?: ManagerPayrollEntry[];
}

/**
 * ManagerCommissionLog:
 * Internal payroll tracking workspace for staff compensation per campaign.
 * 
 * CRITICAL FINANCIAL ISOLATION AUDIT:
 * 1. Zero math or property links to 'brandContractValue' or agency net retains.
 * 2. Manager view is strictly limited to their own record with fixed read-only compensation.
 * 3. Owner view provides manual adjustment fields for discretionary staff bonuses or overrides.
 */
export default function ManagerCommissionLog({
  currentUser,
  initialEntries = [
    {
      id: "comm_1",
      projectName: "Summer Glow Botanical Serum",
      dateRange: "Aug 01 - Aug 20, 2026",
      assignedManagerName: "Sarah Jenkins",
      assignedManagerUid: "mgr_sarah",
      baseCompensation: 450,
      bonusOverride: 50,
      payoutStatus: "Locked for Payroll"
    },
    {
      id: "comm_2",
      projectName: "Organic Pet Balm Seeding",
      dateRange: "Aug 05 - Aug 24, 2026",
      assignedManagerName: "David Vance",
      assignedManagerUid: "mgr_david",
      baseCompensation: 350,
      bonusOverride: 0,
      payoutStatus: "Pending Verification"
    },
    {
      id: "comm_3",
      projectName: "Velvet Aromatherapy Diffuser",
      dateRange: "Jul 15 - Jul 30, 2026",
      assignedManagerName: "Sarah Jenkins",
      assignedManagerUid: "mgr_sarah",
      baseCompensation: 500,
      bonusOverride: 100,
      payoutStatus: "Disbursed via Transfer"
    }
  ]
}: ManagerCommissionLogProps) {
  const [entries, setEntries] = useState<ManagerPayrollEntry[]>(initialEntries);
  const [isOwner] = useState(currentUser.role === 'Owner' || currentUser.role === 'Director');

  // Manual Payroll Add Modal State for Directors
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProjName, setNewProjName] = useState('');
  const [newDateRange, setNewDateRange] = useState('Aug 01 - Aug 30, 2026');
  const [newMgrName, setNewMgrName] = useState('Sarah Jenkins');
  const [newBaseFee, setNewBaseFee] = useState('500');
  const [newBonus, setNewBonus] = useState('0');
  const [newStatus, setNewStatus] = useState<PayoutStatus>('Pending Verification');

  // Filter entries based on role partition
  const visibleEntries = isOwner
    ? entries
    : entries.filter(e => e.assignedManagerName.toLowerCase().includes(currentUser.name.toLowerCase()) || e.assignedManagerUid === currentUser.uid);

  // Stats calculation for Agent Manager personal view
  const totalEarnedToDate = visibleEntries
    .filter(e => e.payoutStatus === 'Disbursed via Transfer')
    .reduce((sum, e) => sum + e.baseCompensation + (e.bonusOverride || 0), 0);

  const upcomingPayments = visibleEntries
    .filter(e => e.payoutStatus === 'Pending Verification' || e.payoutStatus === 'Locked for Payroll')
    .reduce((sum, e) => sum + e.baseCompensation + (e.bonusOverride || 0), 0);

  const handleAddPayrollRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;

    const newRecord: ManagerPayrollEntry = {
      id: 'comm_' + Date.now(),
      projectName: newProjName.trim(),
      dateRange: newDateRange.trim(),
      assignedManagerName: newMgrName.trim(),
      assignedManagerUid: 'mgr_' + newMgrName.toLowerCase().replace(/[^a-z0-9]/g, ''),
      baseCompensation: parseFloat(newBaseFee) || 0,
      bonusOverride: parseFloat(newBonus) || 0,
      payoutStatus: newStatus
    };

    setEntries(prev => [newRecord, ...prev]);
    setShowAddModal(false);
    setNewProjName('');
  };

  const handleBonusChange = (id: string, newBonus: number) => {
    if (!isOwner) return;
    setEntries(prev => prev.map(item => item.id === id ? { ...item, bonusOverride: newBonus } : item));
  };

  const handleStatusChange = (id: string, status: PayoutStatus) => {
    if (!isOwner) return;
    setEntries(prev => prev.map(item => item.id === id ? { ...item, payoutStatus: status } : item));
  };

  const getStatusBadge = (status: PayoutStatus) => {
    switch (status) {
      case 'Pending Verification':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-amber-400 bg-amber-950/50 border border-amber-500/30 px-2.5 py-0.5 rounded-full">
            <Clock className="w-3 h-3" /> Pending Verification
          </span>
        );
      case 'Locked for Payroll':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-blue-400 bg-blue-950/50 border border-blue-500/30 px-2.5 py-0.5 rounded-full">
            <UserCheck className="w-3 h-3" /> Locked for Payroll
          </span>
        );
      case 'Disbursed via Transfer':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-emerald-400 bg-emerald-950/50 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
            <CheckCircle2 className="w-3 h-3" /> Disbursed via Transfer
          </span>
        );
    }
  };

  return (
    <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-2xl text-agency-textLight space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Staff Payroll &amp; Compensation
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {isOwner ? 'Executive Override Canvas' : 'Personal Staff Statement'}
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white mt-1.5">
            Manager Commission Log
          </h2>
          <p className="text-xs text-slate-400">
            {isOwner
              ? 'Review and adjust individual staff compensation, milestone bonuses, and disbursement statuses.'
              : 'View your verified project compensation and scheduled payroll disbursement milestones.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {isOwner && (
            <button
              onClick={() => setShowAddModal(true)}
              className="bg-agency-gold hover:bg-amber-400 text-slate-950 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
            >
              <span>+ Add Manual Payroll Record</span>
            </button>
          )}
          <div className="flex items-center gap-2 text-xs font-mono text-slate-300 bg-agency-navy px-3.5 py-1.5 rounded-xl border border-white/10">
            <ShieldAlert className="w-4 h-4 text-agency-gold" />
            <span>Isolated Compensation Schedule</span>
          </div>
        </div>
      </div>

      {/* Personal Earnings Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-[#0D1830] border border-emerald-500/30 rounded-2xl p-5 space-y-1">
          <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-400 font-bold block">
            Total Earned to Date
          </span>
          <div className="text-2xl font-mono font-bold text-white flex items-center gap-1">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <span>{totalEarnedToDate.toLocaleString()}</span>
          </div>
          <p className="text-[11px] text-slate-400">Total disbursed compensation across completed campaigns</p>
        </div>

        <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl p-5 space-y-1">
          <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold block">
            Up and Coming Payments
          </span>
          <div className="text-2xl font-mono font-bold text-white flex items-center gap-1">
            <DollarSign className="w-5 h-5 text-amber-400" />
            <span>{upcomingPayments.toLocaleString()}</span>
          </div>
          <p className="text-[11px] text-slate-400">Scheduled payouts pending payroll verification or transfer</p>
        </div>
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto rounded-2xl border border-white/10 bg-agency-navy">
        <table className="w-full text-left text-xs">
          <thead className="bg-agency-navyLight/80 text-agency-gold font-mono uppercase text-[10px] tracking-wider border-b border-white/10">
            <tr>
              <th className="py-3.5 px-4">Project &amp; Date Range</th>
              <th className="py-3.5 px-4">Assigned Staff</th>
              <th className="py-3.5 px-4">Base Fee</th>
              {isOwner && <th className="py-3.5 px-4">Staff Bonus ($ Override)</th>}
              <th className="py-3.5 px-4">Net Staff Total</th>
              <th className="py-3.5 px-4">Disbursement Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 font-sans">
            {visibleEntries.length === 0 ? (
              <tr>
                <td colSpan={isOwner ? 6 : 5} className="text-center py-8 text-slate-400 font-mono">
                  No active commission records found for this account.
                </td>
              </tr>
            ) : (
              visibleEntries.map((row) => {
                const totalComp = row.baseCompensation + (row.bonusOverride || 0);

                return (
                  <tr key={row.id} className="hover:bg-white/[0.02] transition-colors">
                    {/* Project & Date */}
                    <td className="py-4 px-4 space-y-0.5">
                      <span className="font-bold text-white block">{row.projectName}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{row.dateRange}</span>
                    </td>

                    {/* Assigned Manager */}
                    <td className="py-4 px-4">
                      <span className="font-mono text-slate-200 font-semibold">{row.assignedManagerName}</span>
                    </td>

                    {/* Base Fee */}
                    <td className="py-4 px-4 font-mono text-slate-300">
                      ${row.baseCompensation.toLocaleString()}
                    </td>

                    {/* Bonus Override (Owner Only) */}
                    {isOwner && (
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-400 font-mono">$</span>
                          <input
                            type="number"
                            value={row.bonusOverride || 0}
                            onChange={(e) => handleBonusChange(row.id, parseFloat(e.target.value) || 0)}
                            className="w-20 bg-agency-navyLight border border-white/10 focus:border-agency-gold text-white font-mono px-2 py-1 rounded-lg text-xs outline-none"
                          />
                        </div>
                      </td>
                    )}

                    {/* Net Total for Staff */}
                    <td className="py-4 px-4 font-mono font-bold text-agency-gold text-sm">
                      ${totalComp.toLocaleString()}
                    </td>

                    {/* Status Badge & Controller */}
                    <td className="py-4 px-4">
                      {isOwner ? (
                        <select
                          value={row.payoutStatus}
                          onChange={(e) => handleStatusChange(row.id, e.target.value as PayoutStatus)}
                          className="bg-agency-navyLight border border-white/10 text-xs font-mono text-slate-200 px-2.5 py-1.5 rounded-xl outline-none focus:border-agency-gold cursor-pointer"
                        >
                          <option value="Pending Verification">Pending Verification</option>
                          <option value="Locked for Payroll">Locked for Payroll</option>
                          <option value="Disbursed via Transfer">Disbursed via Transfer</option>
                        </select>
                      ) : (
                        getStatusBadge(row.payoutStatus)
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Director Add Manual Payroll Record Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-[#0D1830] border border-amber-500/30 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase text-amber-400 bg-amber-950 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                  Director Payroll Entry
                </span>
                <h3 className="text-lg font-serif font-bold text-white mt-1">Add Manual Payroll Record</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddPayrollRecord} className="space-y-4 text-xs">
              <div>
                <label className="text-[#7C8AA8] font-mono block mb-1">Project / Campaign Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Summer Skincare Launch"
                  value={newProjName}
                  onChange={e => setNewProjName(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#7C8AA8] font-mono block mb-1">Assigned Agent Manager</label>
                  <input
                    type="text"
                    required
                    value={newMgrName}
                    onChange={e => setNewMgrName(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-sans"
                  />
                </div>
                <div>
                  <label className="text-[#7C8AA8] font-mono block mb-1">Date Range</label>
                  <input
                    type="text"
                    required
                    value={newDateRange}
                    onChange={e => setNewDateRange(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-sans"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#7C8AA8] font-mono block mb-1">Base Compensation ($)</label>
                  <input
                    type="number"
                    required
                    value={newBaseFee}
                    onChange={e => setNewBaseFee(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-mono"
                  />
                </div>
                <div>
                  <label className="text-[#7C8AA8] font-mono block mb-1">Bonus Override ($)</label>
                  <input
                    type="number"
                    value={newBonus}
                    onChange={e => setNewBonus(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#7C8AA8] font-mono block mb-1">Initial Payout Status</label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value as PayoutStatus)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-mono cursor-pointer"
                >
                  <option value="Pending Verification">Pending Verification</option>
                  <option value="Locked for Payroll">Locked for Payroll</option>
                  <option value="Disbursed via Transfer">Disbursed via Transfer</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#111E33] hover:bg-[#16243F] text-slate-300 rounded-xl font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl cursor-pointer shadow-lg transition-all"
                >
                  Save Manual Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
