import React, { useState } from 'react';
import { 
  Landmark, Layers, RefreshCw, Search, DollarSign, Activity, 
  TrendingUp, Filter, Plus, Calendar, CheckCircle2, Clock, 
  ChevronRight, ArrowRight, ShieldCheck, PieChart, BarChart2,
  X, Receipt, Trash2, Edit3, Check, FileText, User
} from 'lucide-react';
import { Deal, Creator, Role } from '../types';
import RealtimeDealsSync from './RealtimeDealsSync';
import MonthlyRetainerQuotaLedgers from './MonthlyRetainerQuotaLedgers';
import ActivityChart from './ActivityChart';
import { db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { moveToTrash } from '../lib/trashService';
import { checkBrandBlacklist } from '../lib/blacklistService';

interface DealsAndRevenueHubProps {
  deals: Deal[];
  setDeals: React.Dispatch<React.SetStateAction<Deal[]>>;
  creators: Creator[];
  currentRole?: string;
  currentUser?: any;
  tenantId?: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'danger') => void;
  onOpenNewDealModal?: () => void;
}

export default function DealsAndRevenueHub({
  deals = [],
  setDeals,
  creators = [],
  currentRole = 'director',
  currentUser,
  tenantId = 'bloom_studio_default',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onAddActivityLog,
  triggerNotification,
  onOpenNewDealModal
}: DealsAndRevenueHubProps) {
  const [activeTab, setActiveTab] = useState<'pipeline' | 'log_deal' | 'sync' | 'retainers' | 'analytics'>('pipeline');
  const [dealSearchQuery, setDealSearchQuery] = useState('');
  const [selectedStageFilter, setSelectedStageFilter] = useState<string>('all');
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  // New Deal / Revenue Log Form State
  const [formTitle, setFormTitle] = useState('');
  const [formBrand, setFormBrand] = useState('');
  const [formCreator, setFormCreator] = useState(creators[0]?.handle || '@elenarostova');
  const [formCustomCreator, setFormCustomCreator] = useState('');
  const [formValue, setFormValue] = useState<number | ''>(5000);
  const [formCommissionRate, setFormCommissionRate] = useState<number>(20); // 20% agency commission
  const [formPlatform, setFormPlatform] = useState('TikTok');
  const [formAgent, setFormAgent] = useState('Marcus Vance');
  const [formStage, setFormStage] = useState<Deal['stage']>('Contracted');
  const [formPaymentStatus, setFormPaymentStatus] = useState<'Unbilled' | 'Invoiced' | 'Escrow Secured' | 'Paid'>('Escrow Secured');
  const [formDueDate, setFormDueDate] = useState('2026-09-15');
  const [formNotes, setFormNotes] = useState('');

  const STAGES: Deal['stage'][] = ['Lead', 'Pitched', 'Negotiating', 'Contracted', 'Live', 'Completed'];

  // Summary Metrics
  const totalPipelineValue = deals.reduce((sum, d) => sum + (Number(d.value) || 0), 0);
  const activeDealsCount = deals.filter(d => d.stage !== 'Completed' && d.stage !== 'Paused — crisis hold').length;
  const contractedValue = deals.filter(d => d.stage === 'Contracted' || d.stage === 'Live').reduce((sum, d) => sum + (Number(d.value) || 0), 0);
  const completedRevenue = deals.filter(d => d.stage === 'Completed').reduce((sum, d) => sum + (Number(d.value) || 0), 0);

  const filteredDeals = deals.filter(d => {
    if (selectedStageFilter !== 'all' && d.stage !== selectedStageFilter) return false;
    if (dealSearchQuery.trim()) {
      const q = dealSearchQuery.toLowerCase();
      return (
        (d.title || '').toLowerCase().includes(q) ||
        (d.brand || '').toLowerCase().includes(q) ||
        (d.creator || '').toLowerCase().includes(q) ||
        (d.platform || '').toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleStageChange = (dealId: string, nextStage: Deal['stage']) => {
    setDeals(prev => prev.map(d => d.id === dealId ? { ...d, stage: nextStage } : d));
    const target = deals.find(d => d.id === dealId);
    if (target) {
      setDoc(doc(db, 'studio-deals', dealId), { ...target, stage: nextStage }, { merge: true }).catch((err) => {
        console.error('[studio-deals] Error updating stage on server:', err);
        if (triggerNotification) {
          triggerNotification("Sync Error", `Failed to save stage change for deal "${target.title || dealId}" to server.`, "danger");
        }
      });
    }
    if (triggerNotification) {
      triggerNotification("Stage Updated", `Deal moved to ${nextStage}`, "success");
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "User", currentRole, `Moved deal ${dealId} stage to ${nextStage}`);
    }
  };

  const handleDeleteDeal = (dealId: string, dealTitle: string) => {
    const target = deals.find(d => d.id === dealId);
    setDeals(prev => prev.filter(d => d.id !== dealId));
    if (target) {
      moveToTrash('studio-deals', target, 'deal', currentUser).catch((err) => {
        console.error('[studio-deals] Error moving deal to trash on server:', err);
        if (triggerNotification) {
          triggerNotification("Sync Error", `Failed to move deal "${dealTitle}" to trash on server.`, "danger");
        }
      });
    } else {
      setDoc(doc(db, 'studio-deals', dealId), { id: dealId, isDeleted: true }, { merge: true }).catch((err) => {
        console.error('[studio-deals] Error marking deal deleted on server:', err);
        if (triggerNotification) {
          triggerNotification("Sync Error", `Failed to delete deal "${dealTitle}" on server.`, "danger");
        }
      });
    }
    if (triggerNotification) {
      triggerNotification("Deal Removed", `Deal "${dealTitle}" was moved to trash.`, "info");
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "User", currentRole, `Deleted deal "${dealTitle}"`);
    }
  };

  const handleLogDealSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formBrand.trim()) {
      if (triggerNotification) triggerNotification("Missing Fields", "Please provide a deal title and brand name.", "danger");
      return;
    }

    // Verify brand against Global Blacklist
    const blCheck = await checkBrandBlacklist(formBrand.trim(), currentUser?.tenantId);
    if (blCheck.isBlacklisted) {
      if (triggerNotification) {
        triggerNotification(
          "Deal Initiation Blocked",
          `Brand '${blCheck.matchedBrand || formBrand.trim()}' is on the Global Blacklist (${blCheck.reason}). Deal and contract initiation is prohibited.`,
          "danger"
        );
      }
      return;
    }

    const val = typeof formValue === 'number' ? formValue : parseFloat(formValue as string) || 0;
    const chosenCreator = formCreator === 'custom' ? (formCustomCreator.trim() || '@creator') : formCreator;
    const agencyCut = parseFloat((val * (formCommissionRate / 100)).toFixed(2));
    const creatorNet = parseFloat((val - agencyCut).toFixed(2));
    const userPod = currentUser?.subagency || "pod_main";

    const newDeal: Deal = {
      id: `deal_${Date.now()}`,
      title: formTitle.trim(),
      brand: formBrand.trim(),
      creator: chosenCreator,
      creatorHandle: chosenCreator.startsWith('@') ? chosenCreator : `@${chosenCreator}`,
      value: val,
      budget: val,
      stage: formStage,
      platform: formPlatform,
      agent: formAgent,
      due: formDueDate || '2026-09-01',
      dueDate: formDueDate,
      commissionRate: formCommissionRate,
      agencyGrossCommission: agencyCut,
      creatorNetPayout: creatorNet,
      escrowStatus: formPaymentStatus === 'Escrow Secured' ? 'Funded' : formPaymentStatus === 'Paid' ? 'Released' : 'Pending',
      paymentStatus: formPaymentStatus,
      description: formNotes.trim() || `Campaign partnership with ${formBrand.trim()} for ${chosenCreator}.`,
      subagency: userPod,
      tenantId: userPod
    };

    setDeals(prev => [newDeal, ...prev]);
    setDoc(doc(db, 'studio-deals', newDeal.id), newDeal, { merge: true }).catch((err) => {
      console.error('[studio-deals] Error creating deal on server:', err);
      if (triggerNotification) {
        triggerNotification("Sync Error", `Failed to save deal "${newDeal.title}" to server.`, "danger");
      }
    });

    if (triggerNotification) {
      triggerNotification(
        "Deal & Revenue Logged", 
        `Successfully logged "${newDeal.title}" ($${val.toLocaleString()}) for ${newDeal.brand}.`, 
        "success"
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || "User", 
        currentRole, 
        `Logged new deal "${newDeal.title}" for ${newDeal.brand} ($${val.toLocaleString()})`
      );
    }

    // Reset Form
    setFormTitle('');
    setFormBrand('');
    setFormValue(5000);
    setFormNotes('');
    setIsLogModalOpen(false);
    setActiveTab('pipeline');
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <Landmark className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                UNIFIED DEALS &amp; REVENUE COMMAND
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Live Revenue Sync
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              Deals &amp; Revenue Hub
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Consolidated workspace for deal pipeline Kanban, logging campaign revenue, retainer ledgers, and payout tracking.
            </p>
          </div>
        </div>

        {/* Action Controls & Metrics */}
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Total Pipeline</span>
            <span className="text-lg font-bold font-mono text-[#C9A46A]">${totalPipelineValue.toLocaleString()}</span>
          </div>

          <button
            type="button"
            onClick={() => setIsLogModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs shadow-lg transition-transform active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Log New Deal / Revenue</span>
          </button>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('pipeline')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'pipeline'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Pipeline Kanban &amp; Deals</span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/20 font-mono">
            {deals.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('log_deal')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'log_deal'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Log Revenue &amp; Contracts</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sync')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'sync'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <RefreshCw className="w-4 h-4" />
          <span>Deal Search &amp; Real-Time Sync</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('retainers')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'retainers'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Monthly Retainer Ledgers</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'analytics'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Revenue &amp; Deal Analytics</span>
        </button>
      </div>

      {/* TAB CONTENT: Pipeline Kanban */}
      {activeTab === 'pipeline' && (
        <div className="space-y-6">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-[#0D1830] border border-white/10 rounded-xl p-4">
              <span className="text-[10px] font-mono uppercase text-slate-400 block">Active Deals in Flight</span>
              <span className="text-2xl font-bold font-mono text-white mt-1 block">{activeDealsCount}</span>
            </div>
            <div className="bg-[#0D1830] border border-white/10 rounded-xl p-4">
              <span className="text-[10px] font-mono uppercase text-slate-400 block">Contracted / Live</span>
              <span className="text-2xl font-bold font-mono text-sky-400 mt-1 block">${contractedValue.toLocaleString()}</span>
            </div>
            <div className="bg-[#0D1830] border border-white/10 rounded-xl p-4">
              <span className="text-[10px] font-mono uppercase text-slate-400 block">Completed / Settled</span>
              <span className="text-2xl font-bold font-mono text-emerald-400 mt-1 block">${completedRevenue.toLocaleString()}</span>
            </div>
            <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-xl p-4">
              <span className="text-[10px] font-mono uppercase text-[#C9A46A] block">Total Pipeline Inflow</span>
              <span className="text-2xl font-bold font-mono text-[#C9A46A] mt-1 block">${totalPipelineValue.toLocaleString()}</span>
            </div>
          </div>

          {/* Search and Stage Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#0D1830] border border-white/10 rounded-xl p-3">
            <div className="relative flex-1 w-full">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search deals by title, brand, talent, or platform..."
                value={dealSearchQuery}
                onChange={e => setDealSearchQuery(e.target.value)}
                className="w-full bg-black/30 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <select
                value={selectedStageFilter}
                onChange={e => setSelectedStageFilter(e.target.value)}
                className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="all">All Stages</option>
                {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              
              <button
                type="button"
                onClick={() => setIsLogModalOpen(true)}
                className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-[#C9A46A] flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Log Deal</span>
              </button>
            </div>
          </div>

          {/* Kanban Stage Columns Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 overflow-x-auto">
            {STAGES.map(stage => {
              const stageDeals = filteredDeals.filter(d => d.stage === stage);
              const stageSum = stageDeals.reduce((sum, d) => sum + (Number(d.value) || 0), 0);

              return (
                <div key={stage} className="bg-[#0D1830] border border-white/10 rounded-2xl p-3 flex flex-col min-w-[200px]">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2 mb-3">
                    <span className="text-xs font-bold text-white truncate">{stage}</span>
                    <span className="text-[10px] font-mono bg-white/5 text-[#C9A46A] px-2 py-0.5 rounded-full">
                      {stageDeals.length}
                    </span>
                  </div>

                  <div className="text-[10px] font-mono text-slate-400 mb-3">
                    ${stageSum.toLocaleString()}
                  </div>

                  <div className="space-y-2 flex-1">
                    {stageDeals.map(deal => (
                      <div 
                        key={deal.id}
                        className="bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl p-3 space-y-2 transition shadow group"
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-xs font-bold text-white truncate">{deal.brand}</span>
                          <span className="text-[10px] font-mono font-bold text-emerald-400">${(Number(deal.value) || 0).toLocaleString()}</span>
                        </div>

                        <p className="text-[11px] text-slate-300 line-clamp-1">{deal.title}</p>
                        
                        <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                          <span className="truncate">{deal.creator}</span>
                          <span className="text-slate-500">{deal.platform || 'TikTok'}</span>
                        </div>

                        {/* Quick Advance Stage & Delete */}
                        <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2">
                          <select
                            value={deal.stage}
                            onChange={e => handleStageChange(deal.id, e.target.value as Deal['stage'])}
                            className="text-[10px] font-mono bg-black/40 border border-white/10 rounded px-1.5 py-0.5 text-slate-300 focus:outline-none flex-1 truncate"
                          >
                            {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                          </select>

                          <button
                            type="button"
                            onClick={() => handleDeleteDeal(deal.id, deal.title)}
                            className="text-slate-500 hover:text-rose-400 p-1 opacity-0 group-hover:opacity-100 transition cursor-pointer"
                            title="Delete deal"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                    {stageDeals.length === 0 && (
                      <div className="p-4 border border-dashed border-white/5 rounded-xl text-center">
                        <p className="text-[10px] text-slate-500 font-mono">No deals</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB CONTENT: Dedicated Log Revenue & Contracts Section */}
      {activeTab === 'log_deal' && (
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl max-w-3xl mx-auto">
          <div className="border-b border-white/10 pb-4">
            <div className="flex items-center gap-2">
              <Receipt className="w-5 h-5 text-[#C9A46A]" />
              <h2 className="text-lg font-serif font-bold text-white">Log New Campaign Deal &amp; Revenue Record</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Enter commercial terms, talent split, brand client details, and payment milestones. Automatically updates Director pipeline and revenue ledger.
            </p>
          </div>

          <form onSubmit={handleLogDealSubmit} className="space-y-4 text-xs font-mono">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Campaign / Deal Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Summer Glow Skincare UGC Series"
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Brand / Client Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. GlowLab / Nike / DripRoom"
                  value={formBrand}
                  onChange={e => setFormBrand(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Creator / Talent *</label>
                <select
                  value={formCreator}
                  onChange={e => setFormCreator(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  {creators.map(c => (
                    <option key={c.id || c.handle} value={c.handle}>
                      {c.name} ({c.handle})
                    </option>
                  ))}
                  <option value="custom">+ Custom Creator Handle...</option>
                </select>
                {formCreator === 'custom' && (
                  <input
                    type="text"
                    placeholder="e.g. @new_talent"
                    value={formCustomCreator}
                    onChange={e => setFormCustomCreator(e.target.value)}
                    className="w-full mt-2 bg-[#091122] border border-[#C9A46A]/50 rounded-xl p-2.5 text-white focus:outline-none"
                  />
                )}
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Total Contract Value ($) *</label>
                <input
                  type="number"
                  required
                  min={0}
                  step={100}
                  placeholder="e.g. 5000"
                  value={formValue}
                  onChange={e => setFormValue(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-emerald-400 font-bold focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Agency Commission (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={formCommissionRate}
                  onChange={e => setFormCommissionRate(Number(e.target.value))}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-[#C9A46A] font-bold focus:outline-none focus:border-[#C9A46A]"
                />
              </div>
            </div>

            {/* Split Breakdown Preview */}
            <div className="p-3 bg-black/40 border border-white/5 rounded-xl grid grid-cols-2 gap-3 text-[11px]">
              <div>
                <span className="text-slate-400 block">Agency Revenue Cut ({formCommissionRate}%):</span>
                <span className="text-sm font-bold text-[#C9A46A]">
                  ${parseFloat(((typeof formValue === 'number' ? formValue : 0) * (formCommissionRate / 100)).toFixed(2)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Creator Net Payout ({100 - formCommissionRate}%):</span>
                <span className="text-sm font-bold text-emerald-400">
                  ${parseFloat(((typeof formValue === 'number' ? formValue : 0) * (1 - (formCommissionRate / 100))).toFixed(2)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Platform</label>
                <select
                  value={formPlatform}
                  onChange={e => setFormPlatform(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="TikTok">TikTok</option>
                  <option value="Instagram">Instagram</option>
                  <option value="YouTube">YouTube</option>
                  <option value="UGC Raw Video">UGC Raw Video</option>
                  <option value="Cross-Platform">Cross-Platform</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Assigned Agent/Manager</label>
                <select
                  value={formAgent}
                  onChange={e => setFormAgent(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Marcus Vance">Marcus Vance (Lead Agent)</option>
                  <option value="Sarah Jenkins">Sarah Jenkins (Talent Mgr)</option>
                  <option value="Jordan Miller">Jordan Miller (Creator Mgr)</option>
                  <option value="Elena Drake">Elena Drake (Coordinator)</option>
                  <option value="Director Desk">Director Desk</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Pipeline Stage</label>
                <select
                  value={formStage}
                  onChange={e => setFormStage(e.target.value as Deal['stage'])}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Payment / Escrow Status</label>
                <select
                  value={formPaymentStatus}
                  onChange={e => setFormPaymentStatus(e.target.value as any)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Unbilled">Unbilled</option>
                  <option value="Invoiced">Invoiced</option>
                  <option value="Escrow Secured">Escrow Secured</option>
                  <option value="Paid">Paid / Settled</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1.5">Campaign Scope / Deliverable Brief</label>
              <textarea
                rows={3}
                placeholder="e.g. 2x TikTok 9:16 UGC video deliverables + 30-day Spark Ads whitelisting clearance..."
                value={formNotes}
                onChange={e => setFormNotes(e.target.value)}
                className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="pt-3 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setActiveTab('pipeline')}
                className="px-5 py-3 rounded-xl border border-white/10 text-slate-300 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-8 py-3 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold uppercase tracking-wider transition shadow-lg cursor-pointer"
              >
                Save &amp; Log Deal
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT: Real-Time Deals Sync & Search */}
      {activeTab === 'sync' && (
        <RealtimeDealsSync
          deals={deals}
          setDeals={setDeals}
          creators={creators}
          currentRole={currentRole}
          currentUser={currentUser}
          tenantId={tenantId}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
        />
      )}

      {/* TAB CONTENT: Monthly Retainer Quotas */}
      {activeTab === 'retainers' && (
        <MonthlyRetainerQuotaLedgers
          currentRole={currentRole}
          currentUser={currentUser}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
        />
      )}

      {/* TAB CONTENT: Activity & Deal Analytics */}
      {activeTab === 'analytics' && (
        <ActivityChart
          deals={deals}
          creators={creators}
          currentRole={currentRole}
          currentUser={currentUser}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
        />
      )}

      {/* POPUP MODAL: Quick Log Deal Modal */}
      {isLogModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-base font-serif font-bold text-white">Log New Deal &amp; Revenue</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsLogModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleLogDealSubmit} className="space-y-4 text-xs font-mono">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Campaign Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Summer Skincare UGC Series"
                    value={formTitle}
                    onChange={e => setFormTitle(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Brand Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. GlowLab / Nike"
                    value={formBrand}
                    onChange={e => setFormBrand(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Creator</label>
                  <select
                    value={formCreator}
                    onChange={e => setFormCreator(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    {creators.map(c => (
                      <option key={c.id || c.handle} value={c.handle}>{c.name} ({c.handle})</option>
                    ))}
                    <option value="custom">+ Custom Handle</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Value ($) *</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={formValue}
                    onChange={e => setFormValue(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-emerald-400 font-bold focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Commission %</label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={formCommissionRate}
                    onChange={e => setFormCommissionRate(Number(e.target.value))}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-[#C9A46A] font-bold focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Stage</label>
                  <select
                    value={formStage}
                    onChange={e => setFormStage(e.target.value as Deal['stage'])}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Payment Status</label>
                  <select
                    value={formPaymentStatus}
                    onChange={e => setFormPaymentStatus(e.target.value as any)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="Unbilled">Unbilled</option>
                    <option value="Invoiced">Invoiced</option>
                    <option value="Escrow Secured">Escrow Secured</option>
                    <option value="Paid">Paid</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Assigned Agent</label>
                  <select
                    value={formAgent}
                    onChange={e => setFormAgent(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="Marcus Vance">Marcus Vance</option>
                    <option value="Sarah Jenkins">Sarah Jenkins</option>
                    <option value="Jordan Miller">Jordan Miller</option>
                    <option value="Director Desk">Director Desk</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsLogModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-white/10 text-slate-300 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#C9A46A] text-[#0A1220] font-bold uppercase tracking-wider hover:brightness-110 cursor-pointer shadow-lg"
                >
                  Save Deal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
