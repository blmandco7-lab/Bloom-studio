import React, { useState, useEffect } from 'react';
import { 
  FileText, Download, Send, Plus, CheckCircle2, Clock, 
  Lock, AlertTriangle, Shield, Edit2, Info, X, DollarSign, ChevronRight, Trash2 
} from 'lucide-react';
import { exportBrandInvoicePDF } from '../utils/pdfExportUtils';
import { db } from '../lib/firebase';
import { collection, doc, setDoc, deleteDoc, onSnapshot, query, where } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';
import { getStoredDirectorDelegation } from './DirectorDelegationControls';

interface InvoiceGeneratorProps {
  currentUser?: any;
  currentRole?: string;
  tenantId?: string;
  agencyName?: string;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  onNavigate?: (screenId: string) => void;
}

export default function InvoiceGenerator({ 
  currentUser, 
  currentRole = 'director', 
  tenantId,
  agencyName,
  triggerNotification, 
  onAddActivityLog,
  onNavigate
}: InvoiceGeneratorProps) {
  
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    brandName: '',
    campaignName: '',
    commitment: '',
    subtitle: '',
    terms: 'Net 30 Days',
    amount: ''
  });

  // Director Update Invoice Modal State
  const [selectedInvoice, setSelectedInvoice] = useState<any | null>(null);
  const [updateStatus, setUpdateStatus] = useState('Sent');
  const [updateAmountDue, setUpdateAmountDue] = useState('');
  const [updateMessage, setUpdateMessage] = useState('');

  // Delete Invoice State
  const [invoiceToDelete, setInvoiceToDelete] = useState<any | null>(null);

  const handleDeleteInvoice = async (inv: any) => {
    if (!inv || !inv.id) return;

    try {
      // 1. Delete from Firestore
      await deleteDoc(doc(db, "studio-invoices", inv.id));

      // 2. Update local state
      const updatedList = invoices.filter(item => item.id !== inv.id);
      setInvoices(updatedList);

      // 3. Update safeStorage fallback
      safeStorage.setItem(`wl_invoices_${tenantPod}`, JSON.stringify(updatedList));

      // 4. Notifications & Activity log
      if (triggerNotification) {
        triggerNotification(
          "Invoice Deleted",
          `Invoice ${inv.id} for ${inv.brandName} ($${(Number(inv.amount) || 0).toLocaleString()}) has been deleted.`,
          "warning"
        );
      }

      if (onAddActivityLog) {
        onAddActivityLog(
          currentUser?.name || 'Director',
          currentRole,
          `Deleted invoice ${inv.id} for ${inv.brandName} from billing ledger`
        );
      }

      setInvoiceToDelete(null);
      if (selectedInvoice?.id === inv.id) {
        setSelectedInvoice(null);
      }
    } catch (err) {
      console.error("Failed to delete invoice:", err);
      // Fallback: delete locally if network/firestore error
      const updatedList = invoices.filter(item => item.id !== inv.id);
      setInvoices(updatedList);
      safeStorage.setItem(`wl_invoices_${tenantPod}`, JSON.stringify(updatedList));
      setInvoiceToDelete(null);
      if (selectedInvoice?.id === inv.id) {
        setSelectedInvoice(null);
      }
      if (triggerNotification) {
        triggerNotification("Invoice Removed", `Invoice ${inv.id} removed from local ledger.`, "warning");
      }
    }
  };

  const userRole = (currentRole || 'director').toLowerCase();
  const isDirector = userRole === 'director' || userRole === 'owner' || currentUser?.isPlatformOwner === true;

  // Resolve agency tenant pod: strictly isolated per agency
  const tenantPod = (
    currentUser?.subagency || 
    currentUser?.subagencyName || 
    currentUser?.pod || 
    currentUser?.tenantId || 
    tenantId || 
    'pod_main'
  ).trim();

  const displayAgency = agencyName || currentUser?.agencyName || (tenantPod === 'pod_main' ? 'Bloom & Co Network' : tenantPod);

  // Get active delegation settings
  const delegation = getStoredDirectorDelegation();
  const canView = isDirector || delegation.staffCanViewInvoices === true;
  const canCreate = isDirector || delegation.staffCanCreateInvoices === true;

  // Subscribe to multi-tenant isolated invoices in real-time
  useEffect(() => {
    if (!canView) {
      setLoading(false);
      return;
    }

    const colRef = collection(db, "studio-invoices");
    // Platform owner can view all if unscoped, otherwise strictly filter by agency pod
    const q = (currentUser?.isPlatformOwner && !currentUser?.subagency && !tenantId)
      ? query(colRef)
      : query(colRef, where("subagency", "==", tenantPod));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        // In-memory guard: verify invoice belongs strictly to current director's agency
        if (!currentUser?.isPlatformOwner) {
          const invPod = (data.subagency || data.tenantId || '').trim().toLowerCase();
          if (invPod !== tenantPod.toLowerCase()) {
            return;
          }
        }
        items.push({ id: docSnap.id, ...data });
      });

      // Seed default invoice if empty for this specific agency
      if (items.length === 0 && snapshot.empty) {
        const sanitizedPod = tenantPod.replace(/[^a-zA-Z0-9]/g, '-').toUpperCase() || 'MAIN';
        const seedId = `INV-${sanitizedPod}-INITIAL`;
        const defaultInvoice = {
          brandName: 'Nike',
          campaignName: 'Summer UGC Series',
          commitment: '50% Initial Deposit',
          subtitle: 'Upfront Production Escrow',
          terms: 'Net Immediate (Wire)',
          amount: 15000,
          amountDue: 15000,
          status: 'Sent',
          date: new Date().toISOString().split('T')[0],
          subagency: tenantPod,
          tenantId: currentUser?.tenantId || tenantId || 'bloom_studio_default',
          agencyName: displayAgency,
          directorId: currentUser?.id || currentUser?.uid || '',
          directorName: currentUser?.name || 'Creative Director',
          directorEmail: currentUser?.email || '',
          notes: 'Please wire initial production escrow to primary custody vault.',
          updates: []
        };
        setDoc(doc(db, "studio-invoices", seedId), defaultInvoice).catch(e => {
          console.warn("Could not seed default invoice in Firestore:", e);
        });
        setInvoices([{ id: seedId, ...defaultInvoice }]);
        safeStorage.setItem(`wl_invoices_${tenantPod}`, JSON.stringify([{ id: seedId, ...defaultInvoice }]));
      } else {
        // Sort newest first
        items.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
        setInvoices(items);
        safeStorage.setItem(`wl_invoices_${tenantPod}`, JSON.stringify(items));
      }
      setLoading(false);
    }, (err) => {
      console.warn("[InvoiceGenerator] subscription error:", err);
      // Fallback to safeStorage isolated strictly by subagency
      try {
        const saved = safeStorage.getItem(`wl_invoices_${tenantPod}`);
        if (saved) {
          setInvoices(JSON.parse(saved));
        }
      } catch (e) {}
      setLoading(false);
    });

    return () => unsubscribe();
  }, [canView, tenantPod, currentUser, tenantId, displayAgency]);

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canCreate) {
      if (triggerNotification) {
        triggerNotification("Action Restricted", "You do not have permission to draft invoices.", "danger");
      }
      return;
    }

    const sanitizedPod = tenantPod.replace(/[^a-zA-Z0-9]/g, '-').toUpperCase() || 'MAIN';
    const invoiceId = `INV-${sanitizedPod}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    const amountVal = parseFloat(formData.amount) || 0;
    
    const newInvoice = {
      brandName: formData.brandName.trim(),
      campaignName: formData.campaignName.trim(),
      commitment: formData.commitment.trim() || 'Direct Brand Retainer',
      subtitle: formData.subtitle.trim() || 'Production & Creator Management',
      terms: formData.terms,
      amount: amountVal,
      amountDue: amountVal, // Initially total amount
      status: 'Draft',
      date: new Date().toISOString().split('T')[0],
      subagency: tenantPod,
      tenantId: currentUser?.tenantId || tenantId || 'bloom_studio_default',
      agencyName: displayAgency,
      directorId: currentUser?.id || currentUser?.uid || '',
      directorName: currentUser?.name || 'Creative Director',
      directorEmail: currentUser?.email || '',
      notes: 'Generated via professional billing studio.',
      updates: []
    };

    try {
      await setDoc(doc(db, "studio-invoices", invoiceId), newInvoice);
      
      // Update safeStorage fallback list
      const updatedList = [ { id: invoiceId, ...newInvoice }, ...invoices ];
      safeStorage.setItem(`wl_invoices_${tenantPod}`, JSON.stringify(updatedList));

      setShowForm(false);
      setFormData({
        brandName: '',
        campaignName: '',
        commitment: '',
        subtitle: '',
        terms: 'Net 30 Days',
        amount: ''
      });

      if (triggerNotification) {
        triggerNotification("Invoice Generated", `Draft invoice ${invoiceId} logged for ${displayAgency}.`, "success");
      }
      if (onAddActivityLog) {
        onAddActivityLog(currentUser?.name || 'Director', currentRole, `Created draft invoice ${invoiceId} for ${newInvoice.brandName} (${displayAgency})`);
      }
    } catch (err) {
      console.error("Failed to create invoice:", err);
      if (triggerNotification) {
        triggerNotification("Database Write Error", "Failed to save the invoice. Please try again.", "danger");
      }
    }
  };

  const handleSendInvoice = async (inv: any) => {
    try {
      const updated = { 
        ...inv, 
        subagency: inv.subagency || tenantPod,
        tenantId: inv.tenantId || currentUser?.tenantId || tenantId || 'bloom_studio_default',
        status: 'Sent',
        updatedAt: new Date().toISOString()
      };
      await setDoc(doc(db, "studio-invoices", inv.id), updated, { merge: true });
      
      if (triggerNotification) {
        triggerNotification("Invoice Transmitted", `Invoice ${inv.id} has been securely shared with ${inv.brandName}.`, "success");
      }
      if (onAddActivityLog) {
        onAddActivityLog(currentUser?.name || 'Director', currentRole, `Sent invoice ${inv.id} to ${inv.brandName}`);
      }
    } catch (err) {
      console.error("Failed to send invoice:", err);
    }
  };

  const handleDownloadInvoice = async (inv: any) => {
    await exportBrandInvoicePDF({
      invoiceRef: inv.id,
      campaignName: inv.campaignName,
      brandName: inv.brandName,
      commitment: inv.commitment,
      subtitle: inv.subtitle,
      terms: inv.terms,
      amount: inv.amount,
      status: inv.status,
      date: inv.date,
      agencyName: inv.agencyName || displayAgency
    });
    if (triggerNotification) {
      triggerNotification("PDF Downloaded", `Pristine white paper PDF generated for ${inv.id}.`, "success");
    }
  };

  // Director: Save Amount Due Updates & Progress Logs
  const handleSaveDirectorUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isDirector) return;

    const parsedAmountDue = parseFloat(updateAmountDue);
    const logMessage = updateMessage.trim();

    const newUpdateItem = {
      date: new Date().toISOString().split('T')[0],
      amountRemaining: isNaN(parsedAmountDue) ? selectedInvoice.amountDue : parsedAmountDue,
      text: logMessage || `Status updated to ${updateStatus}.`,
      author: currentUser?.name || 'Creative Director'
    };

    const updatedInvoice = {
      ...selectedInvoice,
      subagency: selectedInvoice.subagency || tenantPod,
      tenantId: selectedInvoice.tenantId || currentUser?.tenantId || tenantId || 'bloom_studio_default',
      agencyName: selectedInvoice.agencyName || displayAgency,
      status: updateStatus,
      amountDue: isNaN(parsedAmountDue) ? selectedInvoice.amountDue : parsedAmountDue,
      updates: [...(selectedInvoice.updates || []), newUpdateItem],
      updatedAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, "studio-invoices", selectedInvoice.id), updatedInvoice);
      
      if (triggerNotification) {
        triggerNotification("Billing Status Synced", `Amount due and billing status updated for ${selectedInvoice.id}.`, "success");
      }
      if (onAddActivityLog) {
        onAddActivityLog(currentUser?.name || 'Creative Director', 'director', `Updated billing details on ${selectedInvoice.id}: Status is ${updateStatus}, Amount Due is $${updatedInvoice.amountDue}`);
      }
      setSelectedInvoice(null);
      setUpdateMessage('');
    } catch (err) {
      console.error("Error saving director update:", err);
    }
  };

  // Gate 1: Restricted View Access for unauthorized staff
  if (!canView) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[450px] p-8 text-center bg-[#0D1830]/80 border border-amber-500/20 rounded-3xl animate-fade-in text-white max-w-4xl mx-auto">
        <div className="flex items-center justify-center w-14 h-14 rounded-full bg-amber-500/10 text-amber-500 mb-5 border border-amber-500/20">
          <Lock className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-bold font-serif text-amber-400 mb-2">Access Restricted</h2>
        <p className="text-slate-300 max-w-md mb-4 text-xs leading-relaxed font-sans">
          The **Invoices &amp; Billing Workspace** is locked by the Creative Director. 
          Access is restricted to authorized administrative personnel only.
        </p>
        <span className="text-[10px] uppercase tracking-wider font-mono px-3 py-1 bg-amber-500/10 text-amber-400 rounded-full">
          Gated Staff Policy Active
        </span>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-300 text-white max-w-7xl mx-auto">
      
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#142850] p-6 md:p-8 rounded-3xl border border-white/10 shadow-2xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-mono bg-[#C9A46A] text-[#0A1220] px-3 py-0.5 rounded-full font-bold">
              {displayAgency} Ledger
            </span>
            <span className="text-[10px] uppercase font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <Shield className="w-3 h-3 text-emerald-400" /> Agency Isolated
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-white flex items-center gap-3">
            <FileText className="w-8 h-8 text-[#C9A46A]" />
            Billing &amp; Invoicing Workspace
          </h2>
          <p className="text-xs text-slate-300 font-mono">
            Managing billing ledger for <span className="text-[#C9A46A] font-semibold">{displayAgency}</span>. Invoices are strictly isolated per agency.
          </p>
        </div>

        {canCreate ? (
          <div className="flex flex-wrap items-center gap-3">
            {isDirector && onNavigate && (
              <button
                onClick={() => onNavigate('director-delegation')}
                className="bg-white/5 hover:bg-white/10 text-slate-200 border border-white/15 px-5 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer"
              >
                <Shield className="w-4 h-4 text-[#C9A46A]" /> Director Delegation
              </button>
            )}
            <button
              onClick={() => setShowForm(!showForm)}
              className="bg-[#C9A46A] hover:bg-[#b08d55] text-[#0A1220] px-5 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg hover:shadow-[#C9A46A]/25 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Create New Invoice
            </button>
          </div>
        ) : (
          <div className="flex flex-wrap items-center gap-3">
            {isDirector && onNavigate && (
              <button
                onClick={() => onNavigate('director-delegation')}
                className="bg-white/5 hover:bg-white/10 text-slate-200 border border-white/15 px-5 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer"
              >
                <Shield className="w-4 h-4 text-[#C9A46A]" /> Director Delegation
              </button>
            )}
            <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-800/60 border border-white/10 rounded-xl text-slate-400 text-xs font-mono">
              <Lock className="w-3.5 h-3.5 text-amber-500" />
              <span>Creation Locked by Director</span>
            </div>
          </div>
        )}
      </div>

      {/* New Invoice Form */}
      {showForm && canCreate && (
        <div className="bg-[#0B1B3D] border border-[#C9A46A]/30 rounded-2xl p-6 shadow-xl space-y-4 animate-fade-in">
          <h3 className="text-sm font-sans font-bold text-white border-b border-white/10 pb-3 flex items-center gap-2">
            <Plus className="w-4 h-4 text-[#C9A46A]" /> New White Paper Invoice Draft
          </h3>
          <form onSubmit={handleCreateInvoice} className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div>
              <label className="text-[10px] text-slate-300 block mb-1">Brand / Client Name</label>
              <input
                type="text"
                required
                value={formData.brandName}
                onChange={e => setFormData({ ...formData, brandName: e.target.value })}
                className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                placeholder="e.g. Lumina Cosmetics"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-300 block mb-1">Campaign Name</label>
              <input
                type="text"
                required
                value={formData.campaignName}
                onChange={e => setFormData({ ...formData, campaignName: e.target.value })}
                className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                placeholder="e.g. Holiday UGC Series"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-300 block mb-1">Commitment / Title</label>
              <input
                type="text"
                required
                value={formData.commitment}
                onChange={e => setFormData({ ...formData, commitment: e.target.value })}
                className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                placeholder="e.g. 50% Initial Deposit"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-300 block mb-1">Subtitle / Details</label>
              <input
                type="text"
                value={formData.subtitle}
                onChange={e => setFormData({ ...formData, subtitle: e.target.value })}
                className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                placeholder="e.g. Upfront Production Escrow"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-300 block mb-1">Payment Terms</label>
              <select
                value={formData.terms}
                onChange={e => setFormData({ ...formData, terms: e.target.value })}
                className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-2.5 text-white"
              >
                <option value="Net Immediate (Wire)">Net Immediate (Wire)</option>
                <option value="Net 15 Days">Net 15 Days</option>
                <option value="Net 30 Days">Net 30 Days</option>
                <option value="Net 45 Days">Net 45 Days</option>
                <option value="Net 60 Days">Net 60 Days</option>
              </select>
            </div>
            <div>
              <label className="text-[10px] text-slate-300 block mb-1">Gross Amount (USD)</label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={formData.amount}
                onChange={e => setFormData({ ...formData, amount: e.target.value })}
                className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                placeholder="e.g. 15000"
              />
            </div>
            <div className="md:col-span-2 flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2 bg-[#C9A46A] hover:bg-[#b08d55] text-[#0A1220] font-bold rounded-xl transition"
              >
                Draft Invoice
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Invoices List Panel */}
      <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl">
        {loading ? (
          <div className="text-center py-12 font-mono text-xs text-slate-400">
            Synchronizing with White Paper Billing Ledger...
          </div>
        ) : invoices.length === 0 ? (
          <div className="text-center py-12 text-slate-400 font-mono text-xs">
            No invoices generated yet for this master ledger.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs min-w-[900px]">
              <thead>
                <tr className="border-b border-white/10 text-slate-400 uppercase tracking-wider text-[10px]">
                  <th className="pb-3 px-3">Invoice Ref</th>
                  <th className="pb-3 px-3">Brand &amp; Campaign</th>
                  <th className="pb-3 px-3">Commitment</th>
                  <th className="pb-3 px-3">Gross / Remaining Due</th>
                  <th className="pb-3 px-3">Status &amp; Terms</th>
                  <th className="pb-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {invoices.map((inv) => {
                  const hasOverdue = inv.status === 'Past Due' || inv.status === 'Overdue';
                  return (
                    <tr key={inv.id} className="hover:bg-white/5 transition">
                      <td className="py-4 px-3 font-bold text-[#C9A46A]">{inv.id}</td>
                      <td className="py-4 px-3">
                        <div className="text-white font-sans font-medium">{inv.brandName}</div>
                        <div className="text-[10px] text-slate-400 line-clamp-1">{inv.campaignName}</div>
                        <div className="mt-1 flex items-center gap-1.5">
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-[#C9A46A]">
                            {inv.agencyName || inv.subagency || displayAgency}
                          </span>
                          {inv.directorName && (
                            <span className="text-[9px] text-slate-400 font-sans">
                              • {inv.directorName}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-3">
                        <div className="text-white">{inv.commitment}</div>
                        <div className="text-[10px] text-slate-400 line-clamp-1">{inv.subtitle}</div>
                      </td>
                      <td className="py-4 px-3">
                        <div className="font-bold text-white">
                          {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(inv.amount)}
                        </div>
                        <div className="text-[10px] text-amber-400 flex items-center gap-1 font-semibold mt-0.5">
                          <span>Remaining Due:</span>
                          <strong>{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(inv.amountDue !== undefined ? inv.amountDue : inv.amount)}</strong>
                        </div>
                      </td>
                      <td className="py-4 px-3">
                        <div>
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            inv.status === 'Paid'
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : hasOverdue
                              ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                              : inv.status === 'Sent'
                              ? 'bg-sky-500/15 text-sky-400 border border-sky-500/30'
                              : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          }`}>
                            {inv.status === 'Paid' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                            {inv.status}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1">{inv.terms}</div>
                      </td>
                      <td className="py-4 px-3 text-right space-x-2">
                        {isDirector && (
                          <button
                            onClick={() => {
                              setSelectedInvoice(inv);
                              setUpdateStatus(inv.status);
                              setUpdateAmountDue(inv.amountDue !== undefined ? inv.amountDue.toString() : inv.amount.toString());
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#C9A46A]/10 border border-[#C9A46A]/30 hover:bg-[#C9A46A]/20 text-[#C9A46A] text-[10px] uppercase font-bold transition"
                            title="Update status & remaining balance due"
                          >
                            <Edit2 className="w-3 h-3" /> Update Due
                          </button>
                        )}
                        <button
                          onClick={() => handleSendInvoice(inv)}
                          disabled={inv.status === 'Sent' || inv.status === 'Paid'}
                          className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg bg-sky-500/10 border border-sky-500/20 hover:bg-sky-500/20 text-sky-400 text-[10px] uppercase font-bold transition disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          <Send className="w-3 h-3" /> Send
                        </button>
                        <button
                          onClick={() => handleDownloadInvoice(inv)}
                          className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-[#C9A46A]/15 text-slate-300 hover:text-[#C9A46A] text-[10px] uppercase font-bold transition"
                        >
                          <Download className="w-3 h-3" /> PDF
                        </button>
                        {(isDirector || canCreate) && (
                          <button
                            onClick={() => setInvoiceToDelete(inv)}
                            className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 text-[10px] uppercase font-bold transition cursor-pointer"
                            title="Delete invoice from ledger"
                          >
                            <Trash2 className="w-3 h-3" /> Delete
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Director Amount Due & Progress Notes Update Modal */}
      {selectedInvoice && isDirector && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B1B3D] border border-[#C9A46A]/40 rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl relative space-y-5 animate-fade-in">
            
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div>
                <span className="text-[9px] uppercase tracking-wider font-mono px-2 py-0.5 bg-[#C9A46A]/15 text-[#C9A46A] rounded-full">
                  Executive Ledger Update
                </span>
                <h3 className="font-serif font-bold text-lg text-white mt-1.5">
                  Update Account Due: {selectedInvoice.id}
                </h3>
                <p className="text-slate-400 text-[11px] font-sans">
                  Current Client: <strong>{selectedInvoice.brandName}</strong> • {selectedInvoice.campaignName}
                </p>
              </div>
              <button 
                onClick={() => {
                  setSelectedInvoice(null);
                  setUpdateMessage('');
                }}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDirectorUpdate} className="space-y-4 text-xs font-mono">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-slate-300 block mb-1.5">Collection Status</label>
                  <select
                    value={updateStatus}
                    onChange={e => setUpdateStatus(e.target.value)}
                    className="w-full bg-[#142850] border border-white/15 rounded-xl px-4 py-2.5 text-white"
                  >
                    <option value="Draft">Draft</option>
                    <option value="Sent">Sent</option>
                    <option value="Partially Paid">Partially Paid</option>
                    <option value="Paid">Paid / Settled</option>
                    <option value="Past Due">Past Due</option>
                    <option value="Overdue">Overdue</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-slate-300 block mb-1.5">Remaining Amount Due (USD)</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">$</span>
                    <input
                      type="number"
                      required
                      min="0"
                      step="0.01"
                      value={updateAmountDue}
                      onChange={e => setUpdateAmountDue(e.target.value)}
                      className="w-full bg-[#142850] border border-white/15 rounded-xl pl-8 pr-4 py-2.5 text-white"
                      placeholder="e.g. 7500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-300 block mb-1.5">Director Progress Note &amp; Audit Trail</label>
                <textarea
                  value={updateMessage}
                  onChange={e => setUpdateMessage(e.target.value)}
                  rows={3}
                  className="w-full bg-[#142850] border border-white/15 rounded-xl px-4 py-2.5 text-white"
                  placeholder="e.g. Brand director confirmed wire instruction is processing in accounts payable. Scheduled follow up on Wednesday."
                />
                <span className="text-[9px] text-slate-400 mt-1 block">
                  This progress log will be synchronously logged into the audit trail and displayed in the brand portal.
                </span>
              </div>

              {/* Existing Progress Logs */}
              {selectedInvoice.updates && selectedInvoice.updates.length > 0 && (
                <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Activity Logs &amp; Update History</span>
                  <div className="space-y-2.5">
                    {selectedInvoice.updates.map((up: any, idx: number) => (
                      <div key={idx} className="bg-[#111F38] border border-white/5 rounded-xl p-3 space-y-1.5">
                        <div className="flex justify-between items-center text-[10px] text-slate-400">
                          <span className="font-semibold text-[#C9A46A]">{up.author}</span>
                          <span>{up.date}</span>
                        </div>
                        <p className="text-slate-300 text-[11px] font-sans leading-relaxed">{up.text}</p>
                        <span className="text-[10px] text-emerald-400 font-mono font-bold">
                          Remaining: {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(up.amountRemaining)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setInvoiceToDelete(selectedInvoice)}
                  className="px-3.5 py-2.5 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-rose-400 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete Invoice
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedInvoice(null);
                      setUpdateMessage('');
                    }}
                    className="px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-slate-300 transition"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#C9A46A] hover:bg-[#b08d55] text-[#0A1220] font-bold rounded-xl transition shadow-lg cursor-pointer"
                  >
                    Confirm Ledger Update
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {invoiceToDelete && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-[#0B1B3D] border border-rose-500/30 rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl space-y-4 relative text-left">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-3 bg-rose-500/15 rounded-2xl border border-rose-500/20">
                <AlertTriangle className="w-6 h-6 text-rose-400" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-lg text-white">Delete Invoice?</h3>
                <p className="text-[11px] text-slate-400 font-mono">{invoiceToDelete.id}</p>
              </div>
            </div>

            <div className="bg-[#111F38] border border-white/5 rounded-xl p-4 space-y-2 text-xs font-mono">
              <div className="flex justify-between text-slate-300">
                <span>Client / Brand:</span>
                <strong className="text-white">{invoiceToDelete.brandName}</strong>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Campaign:</span>
                <strong className="text-white">{invoiceToDelete.campaignName}</strong>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Invoice Amount:</span>
                <strong className="text-emerald-400">${(Number(invoiceToDelete.amount) || 0).toLocaleString()}</strong>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Status:</span>
                <span className="text-amber-400">{invoiceToDelete.status}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              Are you sure you want to permanently delete this billing invoice from the ledger? This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                className="px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-slate-300 transition text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDeleteInvoice(invoiceToDelete)}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl transition shadow-lg text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" /> Yes, Delete Invoice
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
