import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  CheckCircle, AlertTriangle, MessageSquare, ArrowRight, User, 
  Eye, Send, FileCheck, Plus, Check, RefreshCw, Upload, 
  HelpCircle, Sparkles, FileText, ChevronRight, CheckCircle2, Clock,
  Video, Wand2, Loader2, Shield
} from 'lucide-react';
import { Creator, Deal, ReviewItem } from '../types';
import { DEFAULT_DEALS } from '../data/defaultAgencyData';
import { evaluateFtcCompliance } from '../lib/ftcBot';
import CreatorAITwinToggle from './CreatorAITwinToggle';
import { db } from '../lib/firebase';
import { doc, setDoc, collection, query, where, onSnapshot } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';

function cleanForFirestore(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(cleanForFirestore);
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) out[k] = cleanForFirestore(v);
  }
  return out;
}

interface SubmitContentProps {
  creators: Creator[];
  deals: Deal[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentRole: string;
  currentUser: any;
  primaryBrandColor?: string;
  cardBgColor?: string;
  mode?: 'submit' | 'my-content';
  activeScreen?: string;
  reviewsList?: ReviewItem[];
  onSaveReview?: (review: ReviewItem) => Promise<void> | void;
  onNavigate?: (screen: string) => void;
}

export default function SubmitContent({
  creators,
  deals,
  onAddActivityLog,
  triggerNotification,
  currentRole,
  currentUser,
  primaryBrandColor = '#c7a77d',
  cardBgColor = '#0D1830',
  mode,
  activeScreen,
  reviewsList,
  onSaveReview,
  onNavigate
}: SubmitContentProps) {
  const isMyContentMode = mode === 'my-content' || activeScreen === 'my-content';
  
  const creatorHandle = currentUser?.handle || '@creator';
  const isPlatformOwner = !!currentUser?.isPlatformOwner;
  const userRole = (currentRole || 'none').toLowerCase();
  
  // Load or sync reviews from safeStorage / Firestore
  const [localReviews, setLocalReviews] = useState<ReviewItem[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_content_reviews');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Real-time Firestore sync listener
  useEffect(() => {
    if (reviewsList && reviewsList.length > 0) return;
    const colRef = collection(db, 'studio-content-reviews');
    const q = isPlatformOwner
      ? colRef
      : userRole === 'creator'
        ? query(colRef, where('creator', '==', currentUser?.handle || '@creator'))
        : query(colRef, where('subagency', '==', currentUser?.subagency || 'pod_main'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: ReviewItem[] = [];
        snapshot.forEach(docSnap => {
          items.push({ ...docSnap.data(), id: docSnap.id } as ReviewItem);
        });
        if (items.length > 0) {
          setLocalReviews(items);
          try {
            safeStorage.setItem('wl_content_reviews', JSON.stringify(items));
          } catch {}
        }
      },
      (err) => {
        console.warn('[studio-content-reviews] onSnapshot error in SubmitContent:', err);
      }
    );
    return () => unsubscribe();
  }, [userRole, currentUser, reviewsList, isPlatformOwner]);

  const reviews = (reviewsList && reviewsList.length > 0) ? reviewsList : localReviews;

  useEffect(() => {
    try {
      safeStorage.setItem('wl_content_reviews', JSON.stringify(localReviews));
    } catch {}
  }, [localReviews]);

  const isAgent = (currentRole || "").toLowerCase() === "agent";
  const isCoordinator = (currentRole || "").toLowerCase() === "coordinator";
  const isStaff = isAgent || isCoordinator;

  const userName = (currentUser?.name || "").toLowerCase();

  // Find creators assigned to this agent/coordinator
  const assignedCreatorsList = (creators || []).filter(c => {
    if (!isStaff) return false;
    const ag = (c.assignedAgent || (c as any).agent || "").toLowerCase();
    const mgr = (c.assignedManager || "").toLowerCase();
    const coord = (c.assignedCoordinator || c.coordinator || "").toLowerCase();
    return (
      ag.includes(userName) || userName.includes(ag) ||
      mgr.includes(userName) || userName.includes(mgr) ||
      coord.includes(userName) || userName.includes(coord) ||
      (userName.includes("alex") && ag.includes("alex")) ||
      (userName.includes("marcus") && (ag.includes("marcus") || mgr.includes("marcus")))
    );
  });

  const assignedHandles = useMemo(() => {
    const set = new Set(assignedCreatorsList.map(c => c.handle.toLowerCase()));
    set.add(creatorHandle.toLowerCase());
    return set;
  }, [assignedCreatorsList, creatorHandle]);

  const allAvailableDeals = useMemo(() => {
    return (deals && deals.length > 0) ? deals : DEFAULT_DEALS;
  }, [deals]);

  const assignedDeals = useMemo(() => {
    const cleanHandle = creatorHandle.toLowerCase().replace('@', '');
    const cleanName = (currentUser?.name || '').toLowerCase();

    return allAvailableDeals.filter(d => {
      if (!isStaff) {
        const dCreator = (d.creator || '').toLowerCase().replace('@', '');
        return dCreator === cleanHandle || dCreator.includes(cleanHandle) || cleanHandle.includes(dCreator) || dCreator === cleanName;
      }
      const dCreator = (d.creator || '').toLowerCase();
      const dAgent = ((d as any).assignedAgent || (d as any).agent || '').toLowerCase();
      return (
        assignedHandles.has(dCreator) ||
        assignedHandles.has(dCreator.replace('@', '')) ||
        assignedHandles.has('@' + dCreator.replace('@', '')) ||
        dAgent.includes(userName) ||
        userName.includes(dAgent)
      );
    });
  }, [allAvailableDeals, isStaff, creatorHandle, currentUser?.name, assignedHandles, userName]);

  const [showAllCampaigns, setShowAllCampaigns] = useState<boolean>(false);
  const [customBrandName, setCustomBrandName] = useState<string>('');

  // Fallback to allAvailableDeals so creator is never blocked from submitting deliverables
  const myDeals = useMemo(() => {
    if (showAllCampaigns || assignedDeals.length === 0) {
      return allAvailableDeals;
    }
    return assignedDeals;
  }, [showAllCampaigns, assignedDeals, allAvailableDeals]);

  const [selectedDealId, setSelectedDealId] = useState<string>(() => {
    return myDeals[0]?.id || 'deal_custom';
  });

  const selectedDeal = useMemo(() => {
    if (selectedDealId === 'deal_custom') {
      return {
        id: 'deal_custom',
        brand: customBrandName.trim() || 'Sponsored Partner',
        platform: 'Instagram',
        budget: 5000,
        due: 'Active Campaign',
        stage: 'In Production',
        deliverable: 'Sponsored UGC Video / Reel Draft',
        notes: 'Deliverable submitted for agency brand review and vaulting.'
      } as any;
    }
    return myDeals.find(d => d.id === selectedDealId) || myDeals[0] || {
      id: 'deal_custom',
      brand: 'Sponsored Partner',
      platform: 'Instagram',
      budget: 5000,
      due: 'Active Campaign',
      stage: 'In Production',
      deliverable: 'Sponsored UGC Video / Reel Draft',
      notes: 'Deliverable submitted for agency brand review and vaulting.'
    } as any;
  }, [selectedDealId, myDeals, customBrandName]);

  // Form inputs
  const [contentType, setContentType] = useState<string>('Video Draft');
  const [mediaUrl, setMediaUrl] = useState<string>('');
  const [captionDraft, setCaptionDraft] = useState<string>('');
  const [commentInput, setCommentInput] = useState<string>('');
  
  // Drag & drop state simulation
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Compliance check feedback
  const [complianceChecked, setComplianceChecked] = useState<boolean>(false);
  const [compliancePass, setCompliancePass] = useState<boolean>(false);

  // Filter reviews to this creator's or assigned creators' submissions for the selected deal
  const dealReviews = reviews.filter(r => {
    const rCreator = (r.creator || "").toLowerCase();
    const isMatchingCreator = !isStaff
      ? (rCreator === creatorHandle.toLowerCase() || rCreator === creatorHandle.toLowerCase().replace('@', ''))
      : (assignedHandles.has(rCreator) || assignedHandles.has(rCreator.replace("@", "")) || assignedHandles.has("@" + rCreator.replace("@", "")));
    return isMatchingCreator && (selectedDealId && selectedDealId !== 'deal_custom' ? r.dealId === selectedDealId : true);
  });

  const [selectedReviewId, setSelectedReviewId] = useState<string>(() => {
    return dealReviews[0]?.id || '';
  });

  const activeReview = reviews.find(r => r.id === selectedReviewId) || dealReviews[0];

  useEffect(() => {
    if (dealReviews.length > 0) {
      const exists = dealReviews.some(r => r.id === selectedReviewId);
      if (!exists) {
        setSelectedReviewId(dealReviews[0].id);
      }
    } else {
      setSelectedReviewId('');
    }
  }, [selectedDealId, reviews]);

  // Generate dynamic deliverables list based on platform
  const getDeliverablesForPlatform = (platform: string = 'TikTok') => {
    const isTikTok = platform.toLowerCase().includes('tiktok');
    const isInstagram = platform.toLowerCase().includes('instagram');
    const isYouTube = platform.toLowerCase().includes('youtube');

    if (isTikTok) {
      return [
        { id: 'del_1', name: 'Raw TikTok Video Draft (MP4/MOV)', required: true },
        { id: 'del_2', name: 'Caption Copy containing promo codes and campaign tags', required: true },
        { id: 'del_3', name: 'FTC compliance hashtag verification (#ad or #sponsored)', required: true },
        { id: 'del_4', name: 'Published live TikTok post url with metrics tracking', required: false }
      ];
    } else if (isInstagram) {
      return [
        { id: 'del_1', name: 'Instagram Reel video or Carousel photos draft', required: true },
        { id: 'del_2', name: 'Caption copy containing campaign @handles and promo code', required: true },
        { id: 'del_3', name: 'FTC disclosure placement confirmation (#ad)', required: true },
        { id: 'del_4', name: 'Live IG Story or Reel link with sponsor tag', required: false }
      ];
    } else if (isYouTube) {
      return [
        { id: 'del_1', name: 'YouTube Video Draft (first cut review)', required: true },
        { id: 'del_2', name: 'Description box copy with tracker links', required: true },
        { id: 'del_3', name: 'FTC disclosure placement verification', required: true },
        { id: 'del_4', name: 'Published Video link with high-resolution thumbnail', required: false }
      ];
    } else {
      return [
        { id: 'del_1', name: 'Raw Creative Footage Draft', required: true },
        { id: 'del_2', name: 'Campaign copy draft with active brief matching', required: true },
        { id: 'del_3', name: 'Required #ad hashtag disclosure check', required: true }
      ];
    }
  };

  const deliverables = getDeliverablesForPlatform(selectedDeal?.platform);

  // Handle Drag & Drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      setUploadedFileName(file.name);
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (ev.target?.result) {
          setMediaUrl(ev.target.result as string);
        }
      };
      reader.readAsDataURL(file);
      triggerNotification('File Staged', `"${file.name}" staged successfully for submission.`, 'success');
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      setUploadedFileName(file.name);
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (ev.target?.result) {
          setMediaUrl(ev.target.result as string);
        }
      };
      reader.readAsDataURL(file);
      triggerNotification('File Staged', `"${file.name}" staged successfully for submission.`, 'success');
    }
  };

  // Compliance checker button logic
  const handleComplianceCheck = () => {
    setComplianceChecked(true);
    const hasAd = captionDraft.toLowerCase().includes('#ad') || captionDraft.toLowerCase().includes('#sponsored');
    setCompliancePass(hasAd);
    if (hasAd) {
      triggerNotification('FTC Check Passed', 'Caption draft successfully validated with required disclosure hashtags.', 'success');
    } else {
      triggerNotification('Compliance Warning', 'Caption draft is missing FTC-mandated disclosure hashtags (#ad or #sponsored).', 'warning');
    }
  };

  // Submit draft content
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDealId) {
      triggerNotification('No Active Deal Selected', 'Select a brand campaign before turning in content.', 'danger');
      return;
    }

    const defaultMockUrls = [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=600&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=60'
    ];
    const finalMediaUrl = mediaUrl.trim() || defaultMockUrls[Math.floor(Math.random() * defaultMockUrls.length)];

    const dealBrandName = selectedDealId === 'deal_custom' 
      ? (customBrandName.trim() || 'Sponsored Partner') 
      : (selectedDeal?.brand || 'Brand Deal');

    const ftcEval = evaluateFtcCompliance(captionDraft.trim(), selectedDealId, dealBrandName);
    const subagency = currentUser?.subagency || 'pod_main';
    const revId = 'rev_' + Date.now();

    const newReview: ReviewItem = {
      id: revId,
      creator: creatorHandle,
      dealId: selectedDealId,
      brand: dealBrandName,
      platform: selectedDeal?.platform || 'Instagram',
      contentType: contentType,
      mediaUrl: finalMediaUrl,
      captionDraft: captionDraft.trim() || 'No caption drafted yet.',
      submittedAt: 'Just now',
      status: 'Pending',
      ftcFlagged: ftcEval.ftcFlagged,
      ftcFlagReason: ftcEval.ftcFlagReason,
      comments: [
        `System: Content draft turned in by creator ${currentUser?.name || 'Creator'}.`,
        `System: Compliance Check Status: ${!ftcEval.ftcFlagged ? '✅ PASSED (FTC Tags Verified)' : '⚠️ WARNING (Missing #ad or #sponsored)'}`
      ],
      subagency
    };

    const updatedReviews = [newReview, ...localReviews];
    setLocalReviews(updatedReviews);
    try {
      safeStorage.setItem('wl_content_reviews', JSON.stringify(updatedReviews));
    } catch {}

    // Persist to Firestore: studio-content-reviews & studio-content-submissions
    try {
      await setDoc(doc(db, 'studio-content-reviews', newReview.id), cleanForFirestore(newReview), { merge: true });
      const subId = 'sub-' + newReview.id.replace('rev_', '');
      const newSub = {
        id: subId,
        creatorHandle: creatorHandle,
        creatorName: currentUser?.name || 'Creator',
        creatorId: currentUser?.id || currentUser?.uid,
        campaignTitle: dealBrandName,
        mediaType: contentType.toLowerCase().includes('video') ? 'video' : 'image',
        fileUrl: finalMediaUrl,
        fileName: uploadedFileName || `${contentType.toLowerCase().replace(/\s+/g, '_')}_draft`,
        caption: captionDraft.trim(),
        submittedAt: new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
        status: 'Pending Internal Review',
        subagency
      };
      await setDoc(doc(db, 'studio-content-submissions', subId), cleanForFirestore(newSub), { merge: true });
    } catch (err) {
      console.warn('Error saving review to Firestore:', err);
    }

    if (onSaveReview) {
      onSaveReview(newReview);
    }

    setSelectedReviewId(newReview.id);

    // Reset Form
    setUploadedFileName('');
    setCaptionDraft('');
    setMediaUrl('');
    setComplianceChecked(false);

    triggerNotification(
      'Draft Turn-In Successful',
      `Your deliverable for ${dealBrandName} was submitted successfully and queued for Content Review.`,
      'success'
    );

    onAddActivityLog(
      currentUser?.name || 'Creator',
      'creator',
      `Submitted ${contentType} draft for campaign: ${selectedDeal?.brand}`
    );

    setSelectedReviewId(newReview.id);
  };

  // Add Comment/Response
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !activeReview) return;

    const senderLabel = `${currentUser?.name || 'Creator'} (Creator)`;
    const updatedReviews = reviews.map(r => {
      if (r.id === activeReview.id) {
        return {
          ...r,
          comments: [...r.comments, `${senderLabel}: ${commentInput.trim()}`]
        };
      }
      return r;
    });

    const updatedItem = updatedReviews.find(r => r.id === activeReview.id);
    setLocalReviews(updatedReviews);
    try {
      safeStorage.setItem('wl_content_reviews', JSON.stringify(updatedReviews));
    } catch {}

    if (updatedItem) {
      try {
        await setDoc(doc(db, 'studio-content-reviews', updatedItem.id), cleanForFirestore({
          ...updatedItem,
          subagency: (updatedItem as any).subagency || currentUser?.subagency || 'pod_main'
        }), { merge: true });
      } catch (err) {
        console.warn('Error persisting comment update to Firestore:', err);
      }
      if (onSaveReview) {
        onSaveReview(updatedItem);
      }
    }

    onAddActivityLog(
      currentUser?.name || 'Creator',
      'creator',
      `Sent response comment on ${activeReview.brand} draft`
    );

    setCommentInput('');
  };

  // Timeline stage resolver
  const getTimelineStageIndex = (status: string) => {
    switch (status) {
      case 'Pending':
        return 1; // Submitted & In Review
      case 'Revision Requested':
        return 2; // Changes Requested
      case 'Approved':
      case 'Approved with Warning':
        return 3; // Approved
      case 'Posted':
        return 4; // Posted / Live
      default:
        return 1;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Info Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-amber-500/20 rounded-2xl p-6 overflow-hidden shadow-xl" style={{ borderColor: `${primaryBrandColor}30` }}>
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>
        <div>
          <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider block font-mono" style={{ color: primaryBrandColor }}>
            {isMyContentMode ? 'TALENT DELIVERABLES PORTFOLIO' : 'CRITICAL CREATIVE OPERATIONS'}
          </span>
          <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5 flex items-center gap-2">
            {isMyContentMode 
              ? 'My Content & Approval Statuses' 
              : isStaff 
              ? 'Submitted Content & Deliverables Review' 
              : 'Submit Content & Deliverables'}
          </h1>
          <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed max-w-3xl">
            {isMyContentMode 
              ? 'View all your submitted campaign deliverables, track real-time Director & Brand approval states, review compliance comments, and manage revisions.'
              : isStaff
              ? 'Review incoming deliverables received from creators you work with. Verify FTC compliance, inspect draft copy, and submit to Content Review for Agent Manager / Director final approval.'
              : 'Upload campaign videos, Carousel photo packages, and draft captions for compliance audits and brand-partner approval before posting live.'}
          </p>
        </div>
      </div>

      {/* Staff & Management Action Banners */}
      {(userRole === 'director' || userRole === 'agentmgr' || isPlatformOwner) && (
        <div className="bg-gradient-to-r from-[#16243F] to-[#111E33] border border-amber-500/30 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#C9A46A]/20 text-[#C9A46A]">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">Management Review & Approval Desk</span>
              <span className="text-[11px] text-slate-300">
                As {userRole === 'director' || isPlatformOwner ? 'Agency Director' : 'Agent Manager'}, you have exclusive authorization to Approve (auto-vault) or Deny (with feedback) creator submissions.
              </span>
            </div>
          </div>
          {onNavigate && (
            <button
              type="button"
              onClick={() => onNavigate('content-review')}
              className="px-4 py-2 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-md"
            >
              Open Content Review & Approvals &rarr;
            </button>
          )}
        </div>
      )}

      {userRole === 'agent' && (
        <div className="bg-[#111E33] border border-sky-500/30 p-4 rounded-2xl flex items-center gap-3 text-xs text-sky-200">
          <Shield className="w-5 h-5 text-sky-400 shrink-0" />
          <div>
            <span className="font-bold text-white block">Agent Inspection View</span>
            <span>
              You have read-only visibility into creator submissions and approval statuses. Official Approval and Denial actions are executed exclusively by the Director and Agent Manager in Content Review.
            </span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT SIDE: Assigned Campaign Selector & Deliverable Checklist */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Brief / Campaign Selector */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-[#7C8AA8] tracking-widest block font-mono">
                1. Select Campaign / Sponsor
              </span>
              <button
                type="button"
                onClick={() => setShowAllCampaigns(!showAllCampaigns)}
                className="text-[10px] text-[#C9A46A] hover:underline font-semibold"
              >
                {showAllCampaigns ? 'Show Assigned Only' : 'Show All Campaigns'}
              </button>
            </div>
            
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {myDeals.map(deal => {
                const isActive = deal.id === selectedDealId;
                return (
                  <button
                    key={deal.id}
                    onClick={() => setSelectedDealId(deal.id)}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                      isActive 
                        ? 'bg-[#16243F] border-[#C9A46A] text-white shadow-md' 
                        : 'bg-[#111E33]/50 border-white/5 hover:bg-[#111E33] text-slate-300'
                    }`}
                    style={isActive ? { borderColor: primaryBrandColor } : {}}
                  >
                    <div>
                      <div className="font-semibold text-xs text-white flex items-center gap-1.5">
                        {deal.brand}
                        <span className="text-[10px] font-mono text-slate-400">({deal.platform})</span>
                      </div>
                      <div className="text-[10px] text-emerald-400 font-semibold mt-0.5">
                        Budget: ${(deal.budget || 5000).toLocaleString()} • <span className="text-slate-400">{deal.stage || 'Active'}</span>
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform ${isActive ? 'rotate-90 text-[#C9A46A]' : ''}`} style={isActive ? { color: primaryBrandColor } : {}} />
                  </button>
                );
              })}

              {/* Custom Sponsor Option */}
              <button
                type="button"
                onClick={() => setSelectedDealId('deal_custom')}
                className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                  selectedDealId === 'deal_custom'
                    ? 'bg-[#16243F] border-[#C9A46A] text-white shadow-md'
                    : 'bg-[#111E33]/50 border-white/5 hover:bg-[#111E33] text-slate-300'
                }`}
                style={selectedDealId === 'deal_custom' ? { borderColor: primaryBrandColor } : {}}
              >
                <div>
                  <div className="font-semibold text-xs text-white flex items-center gap-1.5">
                    + Custom / Other Brand Sponsor
                  </div>
                  <div className="text-[10px] text-[#C9A46A] mt-0.5">
                    Submit deliverable for unlisted sponsor
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 text-slate-400 transition-transform ${selectedDealId === 'deal_custom' ? 'rotate-90 text-[#C9A46A]' : ''}`} />
              </button>
            </div>

            {selectedDealId === 'deal_custom' && (
              <div className="space-y-1.5 pt-2 border-t border-white/5">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8] tracking-wider block">
                  Custom Brand / Sponsor Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Glossier, Gymshark, Athletic Greens"
                  value={customBrandName}
                  onChange={e => setCustomBrandName(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]/50 text-xs"
                />
              </div>
            )}

            {selectedDeal && selectedDealId !== 'deal_custom' && (
              <div className="bg-[#111E33]/70 rounded-xl p-3.5 border border-white/5 space-y-2 text-xs">
                <span className="font-semibold text-white block">Brief guidelines:</span>
                <p className="text-slate-300 leading-relaxed text-[11px] break-words whitespace-pre-wrap">
                  {selectedDeal.notes || "No special brief notes provided. Please keep content visual, premium, and on-brand."}
                </p>
                <div className="flex justify-between items-center pt-2 text-[10px] text-[#7C8AA8] border-t border-white/5">
                  <span>Due date: <strong>{selectedDeal.due}</strong></span>
                  <span>Stage: <strong className="text-amber-400">{selectedDeal.stage}</strong></span>
                </div>
              </div>
            )}
          </div>

          {/* Deliverables & Specs Checklist */}
          {selectedDeal && (
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
              <span className="text-[10px] uppercase font-bold text-[#7C8AA8] tracking-widest block font-mono">
                2. Deliverables &amp; Specs Checklist
              </span>

              <div className="space-y-3">
                {deliverables.map((del, i) => {
                  const hasSubmitted = dealReviews.some(r => 
                    (del.id === 'del_1' && (r.contentType === 'Video Draft' || r.contentType === 'Reel/Video')) ||
                    (del.id === 'del_2' && r.captionDraft && r.captionDraft !== 'No caption drafted yet.') ||
                    (del.id === 'del_3' && (r.captionDraft.toLowerCase().includes('#ad') || r.captionDraft.toLowerCase().includes('#sponsored'))) ||
                    (del.id === 'del_4' && r.status === 'Posted')
                  );

                  const isApproved = dealReviews.some(r => 
                    r.status === 'Approved' || r.status === 'Approved with Warning' || r.status === 'Posted'
                  );

                  let statusText = 'Awaiting Turn-In';
                  let statusColor = 'text-[#7C8AA8] bg-slate-500/10 border-slate-500/20';

                  if (hasSubmitted) {
                    if (isApproved) {
                      statusText = 'Verified & Approved';
                      statusColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
                    } else {
                      statusText = 'Awaiting Verification';
                      statusColor = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
                    }
                  }

                  return (
                    <div key={del.id} className="p-3 bg-[#111E33]/40 border border-white/5 rounded-xl flex items-start gap-2.5">
                      <div className="mt-0.5 shrink-0">
                        {hasSubmitted ? (
                          <CheckCircle2 className={`w-4 h-4 ${isApproved ? 'text-emerald-400' : 'text-amber-400'}`} />
                        ) : (
                          <Clock className="w-4 h-4 text-slate-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="text-[11px] font-medium text-white block leading-snug">{del.name}</span>
                        <span className={`inline-block mt-1.5 text-[9px] font-bold px-2 py-0.5 rounded-full border ${statusColor}`}>
                          {statusText}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT SIDE: Submissions, Timeline Progress & Active submission detail */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Turn-In Submission Form */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-[10px] uppercase font-bold text-[#7C8AA8] tracking-widest block font-mono">
                3. Turn In Content Draft &amp; Media
              </span>
              <button
                type="button"
                onClick={() => {
                  setUploadedFileName('ugc_campaign_product_demo.mp4');
                  setMediaUrl('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80');
                  setCaptionDraft('Unboxing and testing the new summer release! Loving the high-impact results #ad #sponsored @brand');
                  setContentType('Video Draft');
                  triggerNotification('Sample Staged', 'Sample UGC demo video and caption draft loaded.', 'info');
                }}
                className="text-[10px] font-semibold text-[#C9A46A] hover:text-white bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 border border-[#C9A46A]/30 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3 h-3" /> Quick-Fill Sample Video Demo
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[#7C8AA8] uppercase text-[10px] tracking-wider block font-mono">Content Type</label>
                  <select 
                    value={contentType}
                    onChange={e => setContentType(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]/50 font-medium"
                  >
                    <option value="Video Draft">Video Draft (Reel / TikTok)</option>
                    <option value="Reel/Video">Reel / Video</option>
                    <option value="Story Draft">Story Draft Package</option>
                    <option value="Carousel Images">Carousel Images (Photo Pack)</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[#7C8AA8] uppercase text-[10px] tracking-wider block font-mono">Media URL or File Link</label>
                  <input 
                    type="text"
                    placeholder="https://... or choose file below"
                    value={mediaUrl}
                    onChange={e => setMediaUrl(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]/50"
                  />
                </div>
              </div>

              {/* AI Twin Integration Layer */}
              <div className="bg-[#111E33]/30 rounded-2xl border border-white/5 p-4 mb-4">
                <CreatorAITwinToggle 
                  missionId={selectedDealId}
                  creatorId={currentUser?.uid || currentUser?.id || 'unknown'}
                  creatorName={currentUser?.name || 'Creator'}
                  creatorHandle={creatorHandle}
                  currentUser={currentUser}
                  onAssetGenerated={(asset) => {
                    if (asset.previewVideoUrl || asset.url) {
                      setMediaUrl(asset.previewVideoUrl || asset.url);
                    }
                    if (asset.script) {
                      setCaptionDraft(asset.script);
                    }
                    triggerNotification('AI Twin Asset Ready', 'Your synthetic video draft and FTC disclosure metadata have been generated and staged for submission.', 'success');
                  }}
                />
              </div>

              {/* Drag-and-Drop and Manual Click File Selector */}
              <div 
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-5 text-center transition-all cursor-pointer space-y-2 ${
                  isDragging 
                    ? 'border-[#C9A46A] bg-[#C9A46A]/5' 
                    : 'border-white/10 bg-[#111E33]/30 hover:bg-[#111E33]/50'
                }`}
                style={isDragging ? { borderColor: primaryBrandColor } : {}}
              >
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  className="hidden" 
                  accept="video/*,image/*"
                />

                {mediaUrl && (
                  <div className="max-w-xs mx-auto mb-2 overflow-hidden rounded-lg border border-white/10 shadow-lg">
                    {mediaUrl.includes('video') || mediaUrl.endsWith('.mp4') ? (
                      <video src={mediaUrl} className="w-full h-32 object-cover" controls autoPlay muted loop />
                    ) : (
                      <img src={mediaUrl} alt="Staged Deliverable Preview" className="w-full h-32 object-cover" />
                    )}
                  </div>
                )}

                <Upload className="w-6 h-6 mx-auto text-[#C9A46A]" style={{ color: primaryBrandColor }} />
                <div>
                  <span className="text-[11px] font-semibold text-white block">
                    {uploadedFileName ? `Staged file: ${uploadedFileName}` : 'Click to browse or drag & drop video/photo drafts here'}
                  </span>
                  <span className="text-[9px] text-[#7C8AA8] block mt-0.5">
                    Supports MP4, MOV, PNG, JPG (All draft formats supported)
                  </span>
                </div>
                {uploadedFileName && (
                  <span className="inline-block bg-emerald-500/10 text-emerald-400 text-[10px] font-semibold px-2.5 py-1 border border-emerald-500/20 rounded-lg">
                    Ready to Submit
                  </span>
                )}
              </div>

              {/* Caption draft and Compliance Button */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-[#7C8AA8] uppercase text-[10px] tracking-wider block font-mono">Caption / Copy Draft</label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setCaptionDraft(prev => (prev ? prev + ' #ad' : '#ad'))}
                      className="text-[10px] text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 px-2 py-0.5 rounded font-mono"
                    >
                      + #ad
                    </button>
                    <button
                      type="button"
                      onClick={() => setCaptionDraft(prev => (prev ? prev + ' #sponsored' : '#sponsored'))}
                      className="text-[10px] text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 px-2 py-0.5 rounded font-mono"
                    >
                      + #sponsored
                    </button>
                    <button
                      type="button"
                      onClick={handleComplianceCheck}
                      className="text-[10px] text-[#C9A46A] hover:underline font-semibold flex items-center gap-1 font-mono"
                      style={{ color: primaryBrandColor }}
                    >
                      <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Check FTC
                    </button>
                  </div>
                </div>
                <textarea 
                  rows={3}
                  placeholder="Provide your exact caption. Must include clear disclosure hashtags (e.g. #ad, #sponsored) per FTC compliance policies."
                  value={captionDraft}
                  onChange={e => {
                    setCaptionDraft(e.target.value);
                    setComplianceChecked(false);
                  }}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A]/50 font-mono text-[11px]"
                />

                {/* Compliance check visual indicator */}
                {complianceChecked && (
                  <div className={`p-3 rounded-xl border flex items-center gap-2.5 text-[11px] ${
                    compliancePass 
                      ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-400' 
                      : 'bg-rose-950/20 border-rose-500/30 text-rose-400'
                  }`}>
                    {compliancePass ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        <span>FTC Compliance Check Passed. Required disclosure tag identified in caption.</span>
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span>Warning: No #ad or #sponsored hashtag identified. Add FTC disclosure tags before submitting to avoid agency revision holds!</span>
                      </>
                    )}
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <button 
                  type="submit"
                  className="px-5 py-2.5 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                  style={{ backgroundColor: primaryBrandColor }}
                >
                  <Plus className="w-4 h-4" /> Submit Content Review Draft
                </button>
              </div>
            </form>
          </div>

            {/* LIVE SUBMISSION TRACKER TIMELINE & COMMENT DISCOVERY */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
              <span className="text-[10px] uppercase font-bold text-[#7C8AA8] tracking-widest block font-mono">
                4. Live Submission Tracker &amp; Progress Timeline
              </span>

              {dealReviews.length === 0 ? (
                <div className="py-8 text-center text-slate-500 italic text-xs">
                  No submissions found for the selected campaign yet. Submit a draft above to launch the tracking timeline.
                </div>
              ) : (
                <div className="space-y-6">
                  
                  {/* Selector tabs for current submissions */}
                  <div className="flex flex-wrap gap-2 border-b border-white/5 pb-3">
                    {dealReviews.map(r => {
                      const isActive = r.id === selectedReviewId;
                      return (
                        <button
                          key={r.id}
                          onClick={() => {
                            setSelectedReviewId(r.id);
                            setCommentInput('');
                          }}
                          className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold border transition-all ${
                            isActive
                              ? 'bg-[#16243F] border-[#C9A46A] text-white'
                              : 'bg-[#111E33]/30 border-white/5 hover:bg-[#111E33]/60 text-slate-400'
                          }`}
                          style={isActive ? { borderColor: primaryBrandColor } : {}}
                        >
                          {r.contentType} ({r.submittedAt})
                        </button>
                      );
                    })}
                  </div>

                  {activeReview && (
                    <div className="space-y-6 animate-fade-in">
                      
                      {/* Interactive Visual Timeline progress bar */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-[10px] text-[#7C8AA8] font-mono">
                          <span>Timeline Tracking: <strong>{activeReview.contentType}</strong></span>
                          <span>Current status: <strong className="text-amber-400 uppercase">{activeReview.status}</strong></span>
                        </div>

                        {/* Progress Tracker bar */}
                        <div className="relative pt-4 pb-6">
                          {/* Background Track Line */}
                          <div className="absolute top-1/2 left-0 w-full h-1 bg-[#111E33] -translate-y-1/2 rounded-full"></div>
                          
                          {/* Active filled line based on progress stage index */}
                          <div 
                            className="absolute top-1/2 left-0 h-1 bg-gradient-to-r from-amber-500 to-emerald-500 -translate-y-1/2 rounded-full transition-all duration-500"
                            style={{ 
                              width: activeReview.status === 'Posted' ? '100%' :
                                     activeReview.status === 'Approved' || activeReview.status === 'Approved with Warning' ? '75%' :
                                     activeReview.status === 'Revision Requested' ? '50%' : '25%'
                            }}
                          ></div>

                          {/* Nodes */}
                          <div className="relative flex justify-between">
                            {[
                              { label: 'Submitted', desc: 'Draft uploaded', index: 1 },
                              { label: 'In Review', desc: 'Coordinator audit', index: 1 },
                              { label: 'Feedback', desc: 'Revision Check', index: 2, isConditional: activeReview.status === 'Revision Requested' },
                              { label: 'Approved', desc: 'Cleared by Director', index: 3 },
                              { label: 'Posted', desc: 'Campaign live', index: 4 }
                            ].map((node, i) => {
                              const activeStage = getTimelineStageIndex(activeReview.status);
                              const isCompleted = activeStage >= node.index;
                              const isCurrent = (activeReview.status === 'Revision Requested' && node.label === 'Feedback') || 
                                                (activeReview.status === 'Pending' && node.label === 'In Review') ||
                                                ((activeReview.status === 'Approved' || activeReview.status === 'Approved with Warning') && node.label === 'Approved') ||
                                                (activeReview.status === 'Posted' && node.label === 'Posted');

                              return (
                                <div key={i} className="flex flex-col items-center text-center relative z-10">
                                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center text-[9px] font-bold transition-all ${
                                    isCompleted 
                                      ? 'bg-emerald-500 border-emerald-400 text-slate-900' 
                                      : isCurrent 
                                        ? 'bg-amber-500 border-amber-400 text-slate-900 animate-pulse'
                                        : 'bg-[#0D1830] border-slate-700 text-slate-500'
                                  }`}>
                                    {isCompleted ? '✓' : i + 1}
                                  </div>
                                  <span className={`text-[10px] font-bold mt-1.5 block ${isCurrent ? 'text-amber-400 font-extrabold' : isCompleted ? 'text-white' : 'text-slate-500'}`}>
                                    {node.label}
                                  </span>
                                  <span className="text-[8px] text-[#7C8AA8] hidden sm:block mt-0.5">{node.desc}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>

                      {/* Denial Feedback Banner for Creator */}
                      {(activeReview.denialFeedback || activeReview.status === 'Revision Requested' || activeReview.status === 'Rejected') && (
                        <div className="bg-rose-950/40 border border-rose-500/40 p-4 rounded-xl space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-rose-400 uppercase tracking-wider font-mono flex items-center gap-1.5">
                              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                              Director / Agent Manager Feedback on Changes Needed
                            </span>
                            {activeReview.denialFeedbackBy && (
                              <span className="text-[10px] text-rose-300 font-mono">
                                By {activeReview.denialFeedbackBy}
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-rose-100 bg-[#0A1220] p-3 rounded-lg border border-rose-500/20 font-mono leading-relaxed whitespace-pre-wrap">
                            {activeReview.denialFeedback || activeReview.comments.filter(c => c.includes('DENIAL') || c.includes('Director') || c.includes('Agent Manager')).pop() || 'Revisions requested by agency management.'}
                          </div>
                        </div>
                      )}

                      {/* Detail overview: Media & Caption Preview */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-[#111E33]/40 border border-white/5 rounded-xl p-3.5 space-y-2">
                          <span className="text-[10px] uppercase font-bold text-[#7C8AA8] font-mono block">Creative Asset Preview</span>
                          <div className="aspect-video rounded-lg bg-cover bg-center border border-white/5 overflow-hidden flex items-end relative" style={{ backgroundImage: `url(${activeReview.mediaUrl})` }}>
                            <div className="bg-black/70 backdrop-blur-xs p-2 text-[10px] text-slate-300 w-full flex justify-between items-center">
                              <span className="font-mono truncate">{activeReview.contentType}</span>
                              <span className="font-bold text-emerald-400 shrink-0">{activeReview.status}</span>
                            </div>
                          </div>
                        </div>

                        <div className="bg-[#111E33]/40 border border-white/5 rounded-xl p-3.5 flex flex-col justify-between">
                          <div className="space-y-1.5">
                            <span className="text-[10px] uppercase font-bold text-[#7C8AA8] font-mono block">Submitted Caption Copy</span>
                            <div className="font-mono text-[10px] text-slate-300 bg-slate-950/40 p-2.5 rounded-lg border border-white/5 max-h-[85px] overflow-y-auto break-all whitespace-pre-wrap">
                              {activeReview.captionDraft}
                            </div>
                          </div>
                          <div className="mt-2 text-[9px] uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Auto-FTC Compliance Checked
                          </div>
                        </div>
                      </div>

                      {/* Comments & Conversation Trail */}
                      <div className="space-y-3 pt-2">
                        <span className="text-[10px] font-bold text-[#7C8AA8] uppercase flex items-center gap-1 font-mono">
                          <MessageSquare className="w-3 h-3 text-[#C9A46A]" style={{ color: primaryBrandColor }} /> Coordinator Feedback &amp; Discussion
                        </span>
                        
                        <div className="bg-[#111E33]/30 border border-white/5 rounded-xl p-3.5 space-y-2 max-h-[160px] overflow-y-auto">
                          {activeReview.comments.length === 0 ? (
                            <span className="text-xs text-[#7C8AA8] italic block">No messages on this submission thread yet. Communication is open.</span>
                          ) : (
                            activeReview.comments.map((comment, index) => {
                              const isSystem = comment.startsWith('System:');
                              const isAgency = comment.includes('(Agent)') || comment.includes('(Director)') || comment.startsWith('Marcus Cole') || comment.startsWith('Sarah Jenkins');
                              return (
                                <div key={index} className={`text-[11px] p-2.5 rounded-xl leading-relaxed ${
                                  isSystem ? 'bg-slate-800/20 text-slate-400 font-mono text-[9px]' :
                                  isAgency ? 'bg-[#16243F] border border-[#C9A46A]/15 text-white' :
                                  'bg-[#0D1830] border border-white/5 text-slate-300'
                                }`}>
                                  {comment}
                                </div>
                              );
                            })
                          )}
                        </div>

                        {/* Send response */}
                        <form onSubmit={handleAddComment} className="flex gap-2.5 items-center">
                          <input
                            type="text"
                            placeholder="Type a response to your coordinator or agent regarding revisions..."
                            value={commentInput}
                            onChange={e => setCommentInput(e.target.value)}
                            className="flex-1 bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                          />
                          <button 
                            type="submit"
                            className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] p-2.5 rounded-xl transition-colors cursor-pointer"
                            style={{ backgroundColor: primaryBrandColor }}
                          >
                            <Send className="w-4 h-4" />
                          </button>
                        </form>
                      </div>

                    </div>
                  )}

                </div>
              )}

            </div>

          </div>

        </div>

      </div>
    );
  }
