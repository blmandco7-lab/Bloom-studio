import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Eye, Download, Share2, Award, Users, TrendingUp, DollarSign, Mail, Star, RefreshCw, Trash2, Plus, Camera, Upload, ShieldCheck, Lock, Sliders, CheckCircle2, Tag, Shield } from 'lucide-react';
import { Creator } from '../types';
import DeleteConfirmationModal, { DeleteConfirmConfig } from './DeleteConfirmationModal';
import { DAPSContainer } from './DigitalAssetProtectionSystem';
import { getStoredDirectorDelegation } from './DirectorDelegationControls';


interface MediaKitDetails {
  handle: string;
  name: string;
  platform: string;
  bio: string;
  niche?: string;
  followers: string;
  engRate: string;
  rateTikTokVideo: string;
  rateInstaReel: string;
  rateYouTubeVideo: string;
  audienceGender: { male: string; female: string };
  audienceAge: string[];
  topCountries: string[];
  recentBrandPartners: string[];
  photoURL?: string;
  skinTypeMatrix?: string;
  skinTone?: string;
  hairMatrix?: string;
  petBreedMetrics?: string;
  petAgeWeight?: string;
  petDietCategory?: string;
  aestheticMatrix?: string;
  lightingStyle?: string;
  colorStory?: string;
}

interface MediaKitsProps {
  creators: Creator[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentRole?: string;
  currentUser?: any;
}

export default function MediaKits({ creators, onAddActivityLog, triggerNotification, currentRole, currentUser }: MediaKitsProps) {
  const isCreator = (currentRole || '').toLowerCase() === 'creator';
  const isDirector = (currentRole || '').toLowerCase() === 'director';
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const isAgent = (currentRole || '').toLowerCase() === 'agent';
  const isCoordinator = (currentRole || '').toLowerCase() === 'coordinator';
  const canViewRateCards = true;

  const matchedCreator = useMemo(() => {
    return isCreator ? (creators.find(c =>
      (currentUser?.handle && c.handle?.toLowerCase() === currentUser.handle.toLowerCase()) ||
      (currentUser?.handle && c.handle?.toLowerCase().replace(/^@/, '') === currentUser.handle.replace(/^@/, '').toLowerCase()) ||
      (currentUser?.id && c.id === currentUser.id) ||
      (currentUser?.uid && c.id === currentUser.uid) ||
      (currentUser?.email && c.email?.toLowerCase() === currentUser.email?.toLowerCase()) ||
      (currentUser?.name && c.name?.toLowerCase() === currentUser.name?.toLowerCase())
    ) || creators[0] || null) : null;
  }, [isCreator, creators, currentUser]);

  const myCreatorHandle = (matchedCreator?.handle || currentUser?.handle || creators?.[0]?.handle || '').trim();

  const mgrName = currentUser?.name || 'Agency Lead';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const myCreators = (creators || []).filter(c => 
    (c.assignedAgent?.toLowerCase() === mgrName.toLowerCase() || c.assignedManager?.toLowerCase() === mgrName.toLowerCase()) &&
    c.name.toLowerCase() !== mgrName.toLowerCase() &&
    c.handle.toLowerCase() !== (currentUser?.handle || '').toLowerCase()
  );
  const myHandles = myCreators.map(c => c.handle.toLowerCase());

  const [kits, setKits] = useState<Record<string, MediaKitDetails>>({});

  // Brand Visibility of Creator Rate Cards (Director toggle)
  const [showRatesToBrands, setShowRatesToBrands] = useState<boolean>(() => {
    return localStorage.getItem('wl_show_rates_to_brands') === 'true';
  });

  useEffect(() => {
    const handleStorage = () => {
      setShowRatesToBrands(localStorage.getItem('wl_show_rates_to_brands') === 'true');
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const toggleBrandRateVisibility = () => {
    const nextVal = !showRatesToBrands;
    setShowRatesToBrands(nextVal);
    localStorage.setItem('wl_show_rates_to_brands', String(nextVal));
    window.dispatchEvent(new Event('storage'));
    triggerNotification(
      'Rate Card Policy Updated',
      nextVal ? 'Exact deliverable numbers are now displayed on brand media kits.' : 'Rates are now masked as "Custom Negotiated Rates" so creators are not boxed in on pay.',
      'info'
    );
    onAddActivityLog(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Toggled Media Kit public brand rate visibility to ${nextVal ? 'VISIBLE' : 'MASKED (FLEXIBLE SCOPE)'}`
    );
  };

  // Director Brand Share Permission State for Staff (Agents & Managers)
  const [allowBrandShare, setAllowBrandShare] = useState<boolean>(() => {
    return getStoredDirectorDelegation().allowBrandMediaKitShare;
  });

  useEffect(() => {
    const handleDelegationUpdate = (e: any) => {
      if (e?.detail) {
        setAllowBrandShare(!!e.detail.allowBrandMediaKitShare);
      }
    };
    window.addEventListener('director_delegation_updated', handleDelegationUpdate);
    return () => window.removeEventListener('director_delegation_updated', handleDelegationUpdate);
  }, []);

  useEffect(() => {
    setKits(prev => {
      const updated: Record<string, MediaKitDetails> = { ...prev };
      // Always pull freshest custom rate cards from storage
      let allCustomRates: Record<string, any> = {};
      try {
        allCustomRates = JSON.parse(localStorage.getItem('wl_custom_ratecards') || '{}');
      } catch (e) {}

      (creators || []).forEach((c) => {
        const customRates = allCustomRates[c.handle] || allCustomRates[`@${c.handle.replace(/^@/, '')}`] || {};
        
        updated[c.handle] = {
          handle: c.handle,
          name: c.name,
          platform: c.platform || 'TikTok',
          bio: updated[c.handle]?.bio || c.bio || `${c.name} is a verified talent partner specializing in digital media and brand endorsements.`,
          niche: c.niche || 'Beauty',
          followers: c.followers || '0',
          engRate: c.eng || '0%',
          rateTikTokVideo: customRates['TikTok Video'] || customRates.rateTikTokVideo || updated[c.handle]?.rateTikTokVideo || '$2,500',
          rateInstaReel: customRates['Instagram Reel'] || customRates.rateInstaReel || updated[c.handle]?.rateInstaReel || '$1,800',
          rateYouTubeVideo: customRates['YouTube Video'] || customRates.rateYouTubeVideo || updated[c.handle]?.rateYouTubeVideo || '$6,000',
          audienceGender: updated[c.handle]?.audienceGender || { male: '50%', female: '50%' },
          audienceAge: updated[c.handle]?.audienceAge || ['18-24: 50%', '25-34: 50%'],
          topCountries: updated[c.handle]?.topCountries || ['United States'],
          recentBrandPartners: updated[c.handle]?.recentBrandPartners || ['Bloom Agency Network'],
          photoURL: updated[c.handle]?.photoURL || c.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400',
          skinTypeMatrix: c.skinTypeMatrix || updated[c.handle]?.skinTypeMatrix || "Combination / Sensitive",
          skinTone: c.skinTone || updated[c.handle]?.skinTone || "Neutral Cool (Fitzpatrick II)",
          hairMatrix: c.hairMatrix || updated[c.handle]?.hairMatrix || "Type 2B Wavy / Color-Treated",
          petBreedMetrics: c.petBreedMetrics || updated[c.handle]?.petBreedMetrics || "Golden Retriever / Purebred",
          petAgeWeight: c.petAgeWeight || updated[c.handle]?.petAgeWeight || "3.5 Years • 64 lbs",
          petDietCategory: c.petDietCategory || updated[c.handle]?.petDietCategory || "Organic Raw / Grain-Free",
          aestheticMatrix: c.aestheticMatrix || updated[c.handle]?.aestheticMatrix || "Warm Minimalist / Nordic",
          lightingStyle: c.lightingStyle || updated[c.handle]?.lightingStyle || "Natural Golden Hour (5600K)",
          colorStory: c.colorStory || updated[c.handle]?.colorStory || "Earthy Terracotta & Cream"
        };
      });

      if (isCreator && myCreatorHandle && !updated[myCreatorHandle]) {
        const customRates = allCustomRates[myCreatorHandle] || {};
        updated[myCreatorHandle] = {
          handle: myCreatorHandle.startsWith('@') ? myCreatorHandle : `@${myCreatorHandle}`,
          name: currentUser?.name || matchedCreator?.name || 'Creator Talent',
          platform: matchedCreator?.platform || 'TikTok',
          bio: matchedCreator?.bio || `${currentUser?.name || 'Creator'} is a verified talent partner specializing in digital media and brand endorsements.`,
          niche: matchedCreator?.niche || 'Beauty',
          followers: matchedCreator?.followers || '0',
          engRate: matchedCreator?.eng || '0%',
          rateTikTokVideo: customRates['TikTok Video'] || customRates.rateTikTokVideo || '$2,500',
          rateInstaReel: customRates['Instagram Reel'] || customRates.rateInstaReel || '$1,800',
          rateYouTubeVideo: customRates['YouTube Video'] || customRates.rateYouTubeVideo || '$6,000',
          audienceGender: { male: '50%', female: '50%' },
          audienceAge: ['18-24: 50%', '25-34: 50%'],
          topCountries: ['United States'],
          recentBrandPartners: ['Bloom Agency Network'],
          photoURL: matchedCreator?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400',
          skinTypeMatrix: matchedCreator?.skinTypeMatrix || "Combination / Sensitive",
          skinTone: matchedCreator?.skinTone || "Neutral Cool (Fitzpatrick II)",
          hairMatrix: matchedCreator?.hairMatrix || "Type 2B Wavy / Color-Treated",
          petBreedMetrics: matchedCreator?.petBreedMetrics || "Golden Retriever / Purebred",
          petAgeWeight: matchedCreator?.petAgeWeight || "3.5 Years • 64 lbs",
          petDietCategory: matchedCreator?.petDietCategory || "Organic Raw / Grain-Free",
          aestheticMatrix: matchedCreator?.aestheticMatrix || "Warm Minimalist / Nordic",
          lightingStyle: matchedCreator?.lightingStyle || "Natural Golden Hour (5600K)",
          colorStory: matchedCreator?.colorStory || "Earthy Terracotta & Cream"
        };
      }
      return updated;
    });
  }, [creators, isCreator, myCreatorHandle, currentUser, matchedCreator]);

  const filteredKitHandles = Object.keys(kits).filter(handle => {
    if (isCreator) {
      const h1 = handle.toLowerCase().replace(/^@/, '');
      const h2 = myCreatorHandle.toLowerCase().replace(/^@/, '');
      return h1 === h2 || handle.toLowerCase() === myCreatorHandle.toLowerCase();
    }
    if (isAgent) {
      if (myHandles.length > 0) {
        return myHandles.includes(handle.toLowerCase()) || myHandles.includes(handle.toLowerCase().replace(/^@/, ''));
      }
      return true;
    }
    return true;
  });

  const [selectedHandle, setSelectedHandle] = useState<string>('');
  
  useEffect(() => {
    if (isCreator && myCreatorHandle) {
      const myKitKey = Object.keys(kits).find(k => k.toLowerCase().replace(/^@/, '') === myCreatorHandle.toLowerCase().replace(/^@/, ''));
      if (myKitKey && selectedHandle !== myKitKey) {
        setSelectedHandle(myKitKey);
      }
    } else if (filteredKitHandles.length > 0) {
      if (!filteredKitHandles.includes(selectedHandle)) {
        setSelectedHandle(filteredKitHandles[0]);
      }
    } else {
      setSelectedHandle('');
    }
  }, [currentRole, currentUser, kits, isCreator, myCreatorHandle, filteredKitHandles, selectedHandle]);

  const [isExporting, setIsExporting] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states for adding a media kit
  const [newHandle, setNewHandle] = useState('');
  const [newName, setNewName] = useState('');
  const [newPlatform, setNewPlatform] = useState('TikTok');
  const [newBio, setNewBio] = useState('');
  const [newFollowers, setNewFollowers] = useState('');
  const [newEngRate, setNewEngRate] = useState('');
  const [newTiktokRate, setNewTiktokRate] = useState('');
  const [newInstaRate, setNewInstaRate] = useState('');
  const [newYoutubeRate, setNewYoutubeRate] = useState('');

  const activeKit = kits[selectedHandle] || 
    (isCreator && myCreatorHandle ? (Object.values(kits) as MediaKitDetails[]).find(k => k.handle.toLowerCase().replace(/^@/, '') === myCreatorHandle.toLowerCase().replace(/^@/, '')) : undefined) ||
    kits[filteredKitHandles[0]] || 
    Object.values(kits)[0];

  const handleExportPdf = () => {
    if (!activeKit) return;

    const roleLower = (currentRole || '').toLowerCase();
    const isStaffOrBrand = ['agent', 'coordinator', 'agentmgr', 'brand'].includes(roleLower);

    if (isStaffOrBrand && !isDirector) {
      triggerNotification(
        'White Paper Download Restricted',
        'Talent agents, coordinators, and brands are not allowed to download white paper media kits. Download access is strictly reserved for Creative Directors and Creators.',
        'warning'
      );
      return;
    }

    setIsExporting(true);

    try {
      const exportContent = `================================================================
MEDIA KIT REPORT: ${activeKit.name} (${activeKit.handle})
Generated on: ${new Date().toLocaleString()}
================================================================

CREATOR PROFILE
- Platform Reach: ${activeKit.followers} followers (${activeKit.platform})
- Niche Focus: ${activeKit.bio || 'General Creator'}
- Primary Audience: ${activeKit.audienceGender.female}% Female / ${activeKit.audienceGender.male}% Male
- Top Age Brackets: ${activeKit.audienceAge.join(', ')}

ENGAGEMENT METRICS
- Average Engagement Rate: ${activeKit.engRate}
- Top Regions: ${activeKit.topCountries.join(', ')}

COMMERCIAL RATES & PRICING
- TikTok Dedicated Video: ${activeKit.rateTikTokVideo || 'Inquire'}
- Instagram Reel: ${activeKit.rateInstaReel || 'Inquire'}
- YouTube Integration: ${activeKit.rateYouTubeVideo || 'Inquire'}

PAST BRAND COLLABORATIONS
${activeKit.recentBrandPartners?.map(b => `- ${b}`).join('\n') || '- Verified Agency Partner'}

SECURITY & COMPLIANCE
- Verification Digest: VERIFIED_TALENT_KIT_${activeKit.handle.replace('@','')}_2026
================================================================
`;

      const blob = new Blob([exportContent], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `MediaKit_${activeKit.handle.replace(/[@\s]/g, '')}_${Date.now()}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setIsExporting(false);
      triggerNotification(
        'Media Kit Exported',
        `Media Kit report for ${activeKit.name} generated and downloaded as text summary.`,
        'success'
      );
      onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Exported Media Kit for ${selectedHandle}`);
    } catch (e) {
      setIsExporting(false);
      triggerNotification('Export Failed', 'Unable to generate media kit download.', 'danger');
    }
  };

  const handleShareKit = () => {
    if (!activeKit) return;
    const delegation = getStoredDirectorDelegation();
    if (!isDirector && !delegation.allowBrandMediaKitShare) {
      triggerNotification(
        'Brand Sharing Restricted',
        'Sharing media kit links with brands is currently locked by the Creative Director. Contact agency management to enable brand sharing.',
        'warning'
      );
      return;
    }
    const cleanHandle = activeKit.handle.replace(/^@/, '');
    const shareUrl = `${window.location.origin}/#public-portfolio?brand=true&creator=${encodeURIComponent(cleanHandle)}`;
    navigator.clipboard.writeText(shareUrl).catch(() => {});
    triggerNotification(
      'Media Kit Link Copied',
      `Sharing URL for ${activeKit.name}'s Media Kit copied to clipboard: ${shareUrl}`,
      'info'
    );
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Shared Media Kit link for ${selectedHandle}`);
  };

  const [deleteConfirmConfig, setDeleteConfirmConfig] = useState<DeleteConfirmConfig | null>(null);

  const handleDeleteActiveKit = () => {
    if (!selectedHandle || !activeKit) return;
    
    setDeleteConfirmConfig({
      isOpen: true,
      title: 'Delete Talent Media Kit',
      itemName: `${activeKit.name} (${activeKit.handle})`,
      itemType: 'media kit portfolio',
      isPermanent: true,
      message: `Are you sure you want to delete the media kit profile for ${activeKit.name}? Rates, audience analytics, and brand partnership summaries will be removed.`,
      confirmButtonText: 'Delete Media Kit',
      confirmButtonVariant: 'danger',
      onConfirm: () => {
        const remainingKeys = Object.keys(kits).filter(k => k !== selectedHandle);
        setKits(prev => {
          const copy = { ...prev };
          delete copy[selectedHandle];
          return copy;
        });

        triggerNotification(
          'Media Kit Deleted',
          `Successfully deleted the media kit profile for ${selectedHandle}.`,
          'warning'
        );
        onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Deleted media kit records for ${selectedHandle}`);

        if (remainingKeys.length > 0) {
          setSelectedHandle(remainingKeys[0]);
        } else {
          setSelectedHandle('');
        }
      }
    });
  };

  const handleRequestDeleteKit = () => {
    if (!selectedHandle || !activeKit) return;
    triggerNotification(
      'Deletion Request Sent',
      `Submitted deletion request for ${activeKit.name}'s Media Kit to the Director for approval.`,
      'info'
    );
    onAddActivityLog(
      currentUser?.name || 'Marcus Cole',
      'agentmgr',
      `Requested Director deletion of media kit for ${selectedHandle}`
    );
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedHandle) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const photoURL = event.target?.result as string;
      setKits(prev => ({
        ...prev,
        [selectedHandle]: {
          ...prev[selectedHandle],
          photoURL
        }
      }));
      triggerNotification(
        'Photo Updated',
        `Successfully updated media-kit photo for ${selectedHandle}.`,
        'success'
      );
      onAddActivityLog(
        currentUser?.name || (isAgentMgr ? 'Marcus Cole' : 'User'),
        currentRole || 'none',
        `Updated media kit photo for ${selectedHandle}`
      );
    };
    reader.readAsDataURL(file);
  };

  const handleAddMediaKit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isDirector || !newHandle) return;

    const handleKey = newHandle.startsWith('@') ? newHandle : `@${newHandle}`;
    
    setKits(prev => ({
      ...prev,
      [handleKey]: {
        handle: handleKey,
        name: newName || 'New Creator',
        platform: newPlatform,
        bio: newBio || 'No biography entered.',
        followers: newFollowers || '100K',
        engRate: newEngRate || '5.0%',
        rateTikTokVideo: newTiktokRate.startsWith('$') ? newTiktokRate : `$${newTiktokRate}`,
        rateInstaReel: newInstaRate.startsWith('$') ? newInstaRate : `$${newInstaRate}`,
        rateYouTubeVideo: newYoutubeRate.startsWith('$') ? newYoutubeRate : `$${newYoutubeRate}`,
        audienceGender: { male: '30%', female: '70%' },
        audienceAge: ['18-24: 55%', '25-34: 35%', 'Other: 10%'],
        topCountries: ['United States (60%)', 'United Kingdom (20%)', 'Canada (20%)'],
        recentBrandPartners: ['Bloom Agency Network']
      }
    }));

    triggerNotification(
      'Media Kit Built',
      `Brand-new Media Kit successfully built and indexed for ${handleKey}`,
      'success'
    );
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Created active marketing media kit for ${handleKey}`);

    setSelectedHandle(handleKey);
    setShowAddForm(false);
    
    // Clear form
    setNewHandle('');
    setNewName('');
    setNewBio('');
    setNewFollowers('');
    setNewEngRate('');
    setNewTiktokRate('');
    setNewInstaRate('');
    setNewYoutubeRate('');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden">
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider">
              Talent Marketing
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              Creator Media Kits
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
              Compile and share real-time demographics, verified engagement indices, recent campaign highlights, and rate cards with prospecting brand sponsors.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {filteredKitHandles.length > 0 && !isCreator && (
              <select
                value={selectedHandle}
                onChange={e => setSelectedHandle(e.target.value)}
                className="bg-[#16243F] border border-[#rgba(201,164,106,0.14)] text-xs text-[#C9A46A] hover:bg-[#1f3050] px-3.5 py-1.5 rounded-xl font-semibold outline-none"
              >
                {filteredKitHandles.map(handle => (
                  <option key={handle} value={handle}>{handle}</option>
                ))}
              </select>
            )}

            {isDirector ? (
              <>
                {/* Director Brand Rate Card Visibility Toggle */}
                <button
                  type="button"
                  onClick={toggleBrandRateVisibility}
                  className={`text-xs px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
                    showRatesToBrands
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40 hover:bg-emerald-900/80'
                      : 'bg-amber-950/80 text-amber-300 border-amber-500/40 hover:bg-amber-900/80'
                  }`}
                  title="Toggle whether brands see fixed dollar amounts or flexible custom quotes"
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Brand Rates: {showRatesToBrands ? 'Visible (Fixed)' : 'Masked (Flexible)'}</span>
                </button>

                <button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-xs px-4 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" /> Log Media Kit
                </button>
                
                {selectedHandle && (
                  <button
                    onClick={handleDeleteActiveKit}
                    className="bg-rose-950/40 hover:bg-rose-900/40 border border-rose-500/20 text-rose-400 text-xs px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                    title="Delete Active Media Kit"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete Active
                  </button>
                )}
              </>
            ) : (
              <span className="text-[11px] font-mono uppercase bg-[#111E33] border border-[#C9A46A]/40 text-[#D4AF37] px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 shadow-sm">
                <Eye className="w-3.5 h-3.5 text-[#D4AF37]" />
                {isCoordinator 
                  ? 'Coordinator Role • View-Only Mode'
                  : isCreator 
                    ? 'Creator Portal • Talent Profile' 
                    : `${(currentRole || 'Agent').toUpperCase()} Desk • View Mode`}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Add Media Kit Form */}
      {showAddForm && (
        <form onSubmit={handleAddMediaKit} className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 text-xs animate-fade-in">
          <div className="border-b border-white/5 pb-2">
            <h3 className="font-serif font-semibold text-sm text-[#C9A46A] uppercase tracking-wider">Log Dynamic Creator Media Kit</h3>
            <p className="text-[11px] text-[#7C8AA8]">Directly compile core stats and media parameters for outreach pitches.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <label className="text-[#7C8AA8]">Select Creator Roster</label>
              <select
                value={newHandle}
                onChange={e => {
                  setNewHandle(e.target.value);
                  const matched = creators.find(c => c.handle === e.target.value);
                  if (matched) setNewName(matched.name);
                }}
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                required
              >
                <option value="">-- Choose Creator --</option>
                {creators.map(c => (
                  <option key={c.id} value={c.handle}>{c.handle} ({c.name})</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[#7C8AA8]">Creator Name</label>
              <input
                type="text"
                value={newName}
                onChange={e => setNewName(e.target.value)}
                placeholder="e.g. Rachel Sterling"
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[#7C8AA8]">Key Channel Platform</label>
              <select
                value={newPlatform}
                onChange={e => setNewPlatform(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
              >
                <option value="TikTok">TikTok</option>
                <option value="Instagram">Instagram</option>
                <option value="YouTube">YouTube</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[#7C8AA8]">Total Reach Followers</label>
              <input
                type="text"
                value={newFollowers}
                onChange={e => setNewFollowers(e.target.value)}
                placeholder="e.g. 1.2M"
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[#7C8AA8]">Engagement Rate (%)</label>
              <input
                type="text"
                value={newEngRate}
                onChange={e => setNewEngRate(e.target.value)}
                placeholder="e.g. 6.8%"
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                required
              />
            </div>

            {canViewRateCards && (
              <>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">TikTok Post Gross Rate</label>
                  <input
                    type="text"
                    value={newTiktokRate}
                    onChange={e => setNewTiktokRate(e.target.value)}
                    placeholder="e.g. $1200"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Instagram Reel Rate</label>
                  <input
                    type="text"
                    value={newInstaRate}
                    onChange={e => setNewInstaRate(e.target.value)}
                    placeholder="e.g. $900"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">YouTube Video Rate</label>
                  <input
                    type="text"
                    value={newYoutubeRate}
                    onChange={e => setNewYoutubeRate(e.target.value)}
                    placeholder="e.g. $2000"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>
              </>
            )}
          </div>

          <div className="space-y-1">
            <label className="text-[#7C8AA8]">Short Bio Pitch</label>
            <textarea
              value={newBio}
              onChange={e => setNewBio(e.target.value)}
              placeholder="A brief marketing pitch about the creator's influence and styling..."
              rows={2}
              className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
              required
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="bg-[#16243F] text-[#7C8AA8] hover:text-white px-4 py-2 rounded-xl text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold"
            >
              Log Creator Kit
            </button>
          </div>
        </form>
      )}

      {/* Main Kit Layout */}
      {activeKit ? (
        <DAPSContainer title={`Media Kit: ${activeKit.name}`} isShieldActive={true}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
          
          {/* Left: Biography, platform stats */}
          <div className="lg:col-span-8 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-5 border-b border-white/5 pb-5">
              <div className="flex items-center gap-4">
                {/* Creator Photo Container */}
                <div className="relative group shrink-0">
                  <img
                    src={activeKit.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400'}
                    alt={activeKit.name}
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-[#C9A46A]/30 shadow-xl"
                  />
                  {isDirector && (
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-semibold transition-opacity duration-200 cursor-pointer p-1 text-center"
                      title="Upload / Change Creator Photo"
                    >
                      <Camera className="w-5 h-5 mb-1 text-[#C9A46A]" />
                      <span>Change Photo</span>
                    </button>
                  )}
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handlePhotoUpload}
                    accept="image/*"
                    className="hidden"
                  />
                </div>

                <div>
                  <span className="text-xs text-[#C9A46A] font-bold font-mono tracking-wider">{activeKit.handle}</span>
                  <h2 className="font-serif font-semibold text-2xl text-white mt-0.5">{activeKit.name}</h2>
                  <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed max-w-xl">{activeKit.bio}</p>
                  {isDirector && (
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="mt-2 text-[11px] text-[#C9A46A] hover:underline flex items-center gap-1 font-medium cursor-pointer"
                    >
                      <Upload className="w-3 h-3" /> Upload / Change Photo
                    </button>
                  )}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto shrink-0">
                {/* Share Link Button Controlled by Director Switch */}
                {isDirector || allowBrandShare ? (
                  <button
                    onClick={handleShareKit}
                    type="button"
                    className="flex-1 sm:flex-initial bg-[#111E33] hover:bg-[#16243F] border border-[#C9A46A]/30 text-[#C9A46A] hover:text-white px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow"
                  >
                    <Share2 className="w-3.5 h-3.5" /> Share Link
                  </button>
                ) : (
                  <button
                    onClick={handleShareKit}
                    type="button"
                    className="flex-1 sm:flex-initial bg-slate-800/80 border border-slate-700/60 text-slate-400 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-not-allowed opacity-80"
                    title="Director Lock Active: Agent & Talent Managers cannot share brand links."
                  >
                    <Lock className="w-3.5 h-3.5 text-rose-400 shrink-0" /> Brand Share Locked
                  </button>
                )}

                {/* Export PDF Button */}
                {isDirector || isCreator ? (
                  <button
                    onClick={handleExportPdf}
                    type="button"
                    disabled={isExporting}
                    className="flex-1 sm:flex-initial bg-[#16243F] hover:bg-[#1f3050] text-[#C9A46A] border border-[#rgba(201,164,106,0.14)] px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors font-mono cursor-pointer"
                  >
                    {isExporting ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Exporting...
                      </>
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5" /> Export PDF
                      </>
                    )}
                  </button>
                ) : (
                  <button
                    onClick={handleExportPdf}
                    type="button"
                    className="flex-1 sm:flex-initial bg-slate-900/90 border border-amber-500/30 text-amber-300 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-not-allowed opacity-80"
                    title="Export restricted to Director & Creator"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400 shrink-0" /> Export Restricted
                  </button>
                )}
              </div>
            </div>

            {/* Core verified stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-cyan-400" /> Total Followers
                </span>
                <span className="text-xl font-bold text-white block">{activeKit.followers}</span>
                <span className="text-[9px] text-emerald-400 font-semibold">Verified reach</span>
              </div>

              <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-[#C9A46A]" /> Engagement Rate
                </span>
                <span className="text-xl font-bold text-white block">{activeKit.engRate}</span>
                <span className="text-[9px] text-emerald-400 font-semibold">1.8x industry baseline</span>
              </div>

              <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-purple-400" /> Key Channel
                </span>
                <span className="text-xl font-bold text-white block">{activeKit.platform}</span>
                <span className="text-[9px] text-slate-400 font-semibold">Highly active</span>
              </div>
            </div>

            {/* Dynamic Niche Parameter Matrix & Legal Compliance Stamps */}
            <div className="py-2 space-y-3 border-t border-white/5 pt-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#C9A46A] flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5" />
                  <span>Niche Parameter Matrix ({activeKit.niche || 'Talent Specialty'})</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  Client-Facing Sponsor Specifications
                </span>
              </div>

              {((activeKit.niche || '').toLowerCase().includes('pet') || (activeKit.niche || '').toLowerCase().includes('dog')) ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Pet Breed Metrics</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.petBreedMetrics || 'Golden Retriever / Purebred'}</span>
                  </div>
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Age &amp; Weight Matrix</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.petAgeWeight || '3.5 Years • 64 lbs'}</span>
                  </div>
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Dietary Profile</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.petDietCategory || 'Organic Raw / Grain-Free'}</span>
                  </div>
                </div>
              ) : ((activeKit.niche || '').toLowerCase().includes('life') || (activeKit.niche || '').toLowerCase().includes('vlog')) ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Aesthetic Matrix</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.aestheticMatrix || 'Warm Minimalist / Nordic'}</span>
                  </div>
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Lighting Style</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.lightingStyle || 'Natural Golden Hour (5600K)'}</span>
                  </div>
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Color Palette</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.colorStory || 'Earthy Terracotta & Cream'}</span>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Skin Type Matrix</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.skinTypeMatrix || 'Combination / Sensitive'}</span>
                  </div>
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Tone &amp; Undertone</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.skinTone || 'Neutral Cool (Fitzpatrick II)'}</span>
                  </div>
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">Hair Matrix</span>
                    <span className="text-xs font-semibold text-white block">{activeKit.hairMatrix || 'Type 2B Wavy / Color-Treated'}</span>
                  </div>
                </div>
              )}

              {/* Legal & Safety Badges */}
              <div className="pt-3 border-t border-white/5 flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#C9A46A]/10 border-2 border-[#C9A46A] shadow-sm">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#C9A46A]">
                    FTC Compliance Registry Verified
                  </span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/10 border-2 border-emerald-400/80 shadow-sm">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-300">
                    Copyright Clearance Active
                  </span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/30 shadow-sm">
                  <Shield className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                  <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-purple-300">
                    100% Escrow Protected
                  </span>
                </div>
              </div>
            </div>

            {/* Rate card list - Controlled by Director Policy */}
            {canViewRateCards ? (
              <div className="space-y-3.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-2">
                  <h3 className="text-xs font-semibold text-[#7C8AA8] uppercase tracking-wider flex items-center gap-1.5">
                    <DollarSign className="w-4 h-4 text-[#C9A46A]" /> Deliverable Rate Card &amp; Monetization
                  </h3>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                      showRatesToBrands 
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30' 
                        : 'bg-amber-950/80 text-amber-300 border-amber-500/30'
                    }`}>
                      {showRatesToBrands ? '● Public Brand Visibility: Enabled' : '○ Brand Visibility: Masked (Custom Quote)'}
                    </span>
                  </div>
                </div>

                {!showRatesToBrands && (
                  <div className="bg-[#111E33] border border-amber-500/20 p-3 rounded-xl text-xs text-amber-200/90 flex items-start gap-2.5">
                    <span className="text-base">🛡️</span>
                    <div>
                      <span className="font-bold block text-amber-200">Director Rate Protection Policy Active</span>
                      <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                        Public brands and outbound pitches will see <strong>"Custom Negotiated Rates (Project Scope Based)"</strong> rather than fixed numbers. This ensures your creator is never boxed into rigid pay brackets before deal parameters are fully negotiated.
                      </p>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl space-y-1.5">
                    <span className="text-slate-300 font-medium block">TikTok Dedicated Video</span>
                    <div className="flex items-baseline justify-between">
                      <span className="font-bold text-emerald-400 font-mono text-sm">
                        {showRatesToBrands || isDirector ? activeKit.rateTikTokVideo : 'Custom Scope Quote'}
                      </span>
                      {!showRatesToBrands && isDirector && (
                        <span className="text-[9px] text-amber-400 font-mono uppercase">(Masked to Brand)</span>
                      )}
                    </div>
                  </div>

                  <div className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl space-y-1.5">
                    <span className="text-slate-300 font-medium block">Instagram Reel</span>
                    <div className="flex items-baseline justify-between">
                      <span className="font-bold text-emerald-400 font-mono text-sm">
                        {showRatesToBrands || isDirector ? activeKit.rateInstaReel : 'Custom Scope Quote'}
                      </span>
                      {!showRatesToBrands && isDirector && (
                        <span className="text-[9px] text-amber-400 font-mono uppercase">(Masked to Brand)</span>
                      )}
                    </div>
                  </div>

                  <div className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl space-y-1.5">
                    <span className="text-slate-300 font-medium block">YouTube Dedicated Video</span>
                    <div className="flex items-baseline justify-between">
                      <span className="font-bold text-emerald-400 font-mono text-sm">
                        {showRatesToBrands || isDirector ? activeKit.rateYouTubeVideo : 'Custom Scope Quote'}
                      </span>
                      {!showRatesToBrands && isDirector && (
                        <span className="text-[9px] text-amber-400 font-mono uppercase">(Masked to Brand)</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-[#111E33]/60 border border-amber-500/20 rounded-xl p-3.5 text-xs flex items-center justify-between">
                <span className="text-slate-400">Rate cards &amp; monetization pricing are confidential and restricted to Director clearance.</span>
                <span className="text-amber-400 font-mono font-semibold text-[10px] uppercase">Director Access Only</span>
              </div>
            )}
          </div>

          {/* Right: Demographic breakdowns */}
          <div className="lg:col-span-4 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-5">
            <h3 className="font-serif font-medium text-lg text-white border-b border-white/5 pb-2">
              Audience Demographics
            </h3>

            {/* Gender bar */}
            <div className="space-y-2">
              <span className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Audience Gender Split</span>
              <div className="h-4 w-full bg-slate-800 rounded-full overflow-hidden flex text-[9px] font-bold text-white">
                <div className="bg-[#C9A46A] h-full flex items-center justify-center" style={{ width: activeKit.audienceGender.female }}>
                  F {activeKit.audienceGender.female}
                </div>
                <div className="bg-sky-500 h-full flex items-center justify-center" style={{ width: activeKit.audienceGender.male }}>
                  M {activeKit.audienceGender.male}
                </div>
              </div>
            </div>

            {/* Age stats list */}
            <div className="space-y-2">
              <span className="text-[10px] text-[#7C8AA8] uppercase font-semibold block">Audience Age Distribution</span>
              <div className="space-y-1.5 text-xs">
                {activeKit.audienceAge.map((age, i) => (
                  <div key={i} className="p-2.5 bg-[#111E33] rounded-lg border border-white/5 text-slate-300 font-medium">
                    {age}
                  </div>
                ))}
              </div>
            </div>

            {/* Countries list */}
            <div className="space-y-2">
              <span className="text-[10px] text-[#7C8AA8] uppercase font-semibold block">Top Geographic Locations</span>
              <div className="space-y-1.5 text-xs">
                {activeKit.topCountries.map((country, i) => (
                  <div key={i} className="p-2.5 bg-[#111E33] rounded-lg border border-white/5 text-slate-300 font-medium">
                    {country}
                  </div>
                ))}
              </div>
            </div>
          </div>
          </div>
        </DAPSContainer>
      ) : (
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-12 text-center text-slate-500 italic text-xs">
          No media kits on file. Click "Log Media Kit" to compile your first outreach card.
        </div>
      )}
      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        config={deleteConfirmConfig}
        onClose={() => setDeleteConfirmConfig(null)}
      />
    </div>
  );
}
