import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Lock, CheckSquare, Square, AlertTriangle, X, Check, FileCheck, Landmark, ExternalLink } from 'lucide-react';
import { computeRealSha256, persistSignatureRecord } from '../lib/cryptoSignatures';
import { safeStorage } from '../utils/safeStorage';
import PrivacyPolicyModal from './PrivacyPolicyModal';

interface BrandTermsAgreementModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAgreed?: (signatureRecord: { signedBy: string; signedAt: string; hash: string }) => void;
  currentUser?: any;
  currentRole?: string;
}

export default function BrandTermsAgreementModal({
  isOpen,
  onClose,
  onAgreed,
  currentUser,
  currentRole = 'brand'
}: BrandTermsAgreementModalProps) {
  const [checkedBox1, setCheckedBox1] = useState(false);
  const [checkedBox2, setCheckedBox2] = useState(false);
  const [checkedBox3, setCheckedBox3] = useState(false);
  const [checkedBox4, setCheckedBox4] = useState(false);
  const [checkedBox5, setCheckedBox5] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [signerName, setSignerName] = useState(currentUser?.name || 'Brand Partnerships Lead');
  const [organizationName, setOrganizationName] = useState('Authorized Client Organization');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasAgreed, setHasAgreed] = useState(false);
  const [signatureReceipt, setSignatureReceipt] = useState<{ hash: string; timestamp: string } | null>(null);

  if (!isOpen) return null;

  const allChecked = checkedBox1 && checkedBox2 && checkedBox3 && checkedBox4 && checkedBox5;

  const handleAgreeAndProceed = async () => {
    if (!allChecked) return;
    setIsSubmitting(true);

    const nowIso = new Date().toISOString();
    const timestamp = new Date().toLocaleString();
    const payloadToHash = `BRAND_TERMS_V2026|SIGNED_BY:${signerName}|ORG:${organizationName}|PRIVACY_ACKNOWLEDGED:TRUE|DATE:${nowIso}`;
    const shaHash = await computeRealSha256(payloadToHash);

    const recordId = `brand_terms_${currentUser?.id || currentUser?.uid || Date.now()}`;
    try {
      await persistSignatureRecord({
        id: recordId,
        documentType: 'Brand Platform Terms & Non-Circumvention Agreement',
        signerName: signerName,
        signerEmail: currentUser?.email,
        signerRole: 'brand',
        isoTimestamp: nowIso,
        formattedTimestamp: timestamp,
        digest: shaHash,
        payloadContent: payloadToHash,
        metadata: { organizationName, privacyPolicyAcknowledged: true }
      });

      const fullVaultRecord = {
        id: recordId,
        documentType: 'Brand Platform Terms & Non-Circumvention Agreement',
        signerName: signerName,
        signerEmail: currentUser?.email || 'brand.partner@agency.com',
        organization: organizationName,
        signerRole: 'brand',
        isoTimestamp: nowIso,
        formattedTimestamp: timestamp,
        signedAt: timestamp,
        signedBy: signerName,
        digest: shaHash,
        hash: shaHash,
        payloadContent: payloadToHash,
        clausesAccepted: [
          'Non-Circumvention (No Platform Bypassing)',
          'Proprietary App Architecture',
          'Security and Credentials',
          'Direct Messaging and Data Visibility'
        ],
        metadata: { organizationName, privacyPolicyAcknowledged: true }
      };

      try {
        safeStorage.setItem('wl_brand_terms_accepted', 'true');
        safeStorage.setItem('wl_brand_terms_record', JSON.stringify(fullVaultRecord));
        
        // Append to Signed Agreements Vault array
        const vaultStr = safeStorage.getItem('bloom_signed_agreements_vault');
        const vaultList = vaultStr ? JSON.parse(vaultStr) : [];
        vaultList.unshift(fullVaultRecord);
        safeStorage.setItem('bloom_signed_agreements_vault', JSON.stringify(vaultList));
      } catch (e) {}

      setTimeout(() => {
        setIsSubmitting(false);
        setHasAgreed(true);
        setSignatureReceipt({ hash: shaHash, timestamp });

        if (onAgreed) {
          onAgreed(fullVaultRecord);
        }
      }, 400);
    } catch (err) {
      console.error('[BrandTermsAgreementModal] Signature failure:', err);
      setIsSubmitting(false);
      // We don't have a specific error state in the UI but we should at least reset isSubmitting
      // and maybe alert since this modal is a bit different.
      alert('Failed to record digital signature. Please check your connection and try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-[#0E1A2E] border border-blue-900 rounded-3xl max-w-2xl w-full p-6 md:p-8 space-y-6 text-left shadow-2xl my-8"
      >
        {/* Modal Header */}
        <div className="flex justify-between items-start border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                Enterprise Non-Circumvention &amp; Terms
              </span>
              <h3 className="text-xl font-bold text-white">
                Platform Rules &amp; Non-Solicitation Agreement
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {hasAgreed && signatureReceipt ? (
          <div className="p-6 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="text-base font-bold text-white">Platform Terms Verified &amp; Signed</h4>
              <p className="text-xs text-slate-300">
                Your electronic acknowledgment has been cryptographically recorded on the immutable compliance ledger.
              </p>
            </div>
            <div className="p-3 bg-[#081222] border border-white/10 rounded-xl text-left font-mono text-xs text-emerald-400 space-y-1">
              <div><strong className="text-slate-400">Audit Hash:</strong> {signatureReceipt.hash}</div>
              <div><strong className="text-slate-400">Timestamp:</strong> {signatureReceipt.timestamp}</div>
              <div><strong className="text-slate-400">Signer:</strong> {signerName} ({organizationName})</div>
            </div>
            <button
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-[#070D18] font-mono font-bold text-xs uppercase tracking-wider transition cursor-pointer"
            >
              Continue to Dashboard
            </button>
          </div>
        ) : (
          <>
            {/* Intro Notice */}
            <p className="text-xs text-slate-300 leading-relaxed bg-[#081222] border border-blue-950 p-4 rounded-2xl">
              Before creating your platform credentials and accessing the Bloom Studio dashboard, please review our core platform rules. You must acknowledge and agree to these terms to proceed.
            </p>

            {/* 4 Mandatory Checkboxes */}
            <div className="space-y-4">
              
              {/* Checkbox 1 */}
              <div 
                onClick={() => setCheckedBox1(!checkedBox1)}
                className={`p-4 rounded-2xl border transition cursor-pointer select-none flex items-start gap-3.5 ${
                  checkedBox1 
                    ? 'bg-[#0A162B] border-emerald-500/50 shadow-md shadow-emerald-950/20' 
                    : 'bg-[#081222] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="pt-0.5 shrink-0">
                  {checkedBox1 ? (
                    <CheckSquare className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-500" />
                  )}
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    1. Non-Circumvention (No Platform Bypassing)
                    <span className="text-[10px] font-mono text-rose-400 bg-rose-950/50 px-2 py-0.5 rounded border border-rose-800/30">
                      $5,000 / 30% Penalty
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    I understand and agree that any talent, influencer, model, or any creator introduced to my brand via the Bloom Studio dashboard must be booked exclusively through this platform. I agree that bypassing this platform to contract or pay talent directly will result in an immediate platform ban and an automatic liquidated damages penalty of $5,000 or 30% of the total campaign value, whichever is greater.
                  </p>
                </div>
              </div>

              {/* Checkbox 2 */}
              <div 
                onClick={() => setCheckedBox2(!checkedBox2)}
                className={`p-4 rounded-2xl border transition cursor-pointer select-none flex items-start gap-3.5 ${
                  checkedBox2 
                    ? 'bg-[#0A162B] border-emerald-500/50 shadow-md shadow-emerald-950/20' 
                    : 'bg-[#081222] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="pt-0.5 shrink-0">
                  {checkedBox2 ? (
                    <CheckSquare className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-500" />
                  )}
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-white">
                    2. Proprietary App Architecture
                  </h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    I agree not to reverse-engineer, screen-scrape, data-mine, copy, or replicate the proprietary "match or pass" user interface, swiping mechanics, or matching algorithms utilized within the dashboard.
                  </p>
                </div>
              </div>

              {/* Checkbox 3 */}
              <div 
                onClick={() => setCheckedBox3(!checkedBox3)}
                className={`p-4 rounded-2xl border transition cursor-pointer select-none flex items-start gap-3.5 ${
                  checkedBox3 
                    ? 'bg-[#0A162B] border-emerald-500/50 shadow-md shadow-emerald-950/20' 
                    : 'bg-[#081222] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="pt-0.5 shrink-0">
                  {checkedBox3 ? (
                    <CheckSquare className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-500" />
                  )}
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-white">
                    3. Security and Credentials
                  </h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    I agree that my login credentials are for my registered organization only. I will not share user access or account details with external scouts, third-party agencies, or outside contractors.
                  </p>
                </div>
              </div>

              {/* Checkbox 4 */}
              <div 
                onClick={() => setCheckedBox4(!checkedBox4)}
                className={`p-4 rounded-2xl border transition cursor-pointer select-none flex items-start gap-3.5 ${
                  checkedBox4 
                    ? 'bg-[#0A162B] border-emerald-500/50 shadow-md shadow-emerald-950/20' 
                    : 'bg-[#081222] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="pt-0.5 shrink-0">
                  {checkedBox4 ? (
                    <CheckSquare className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-500" />
                  )}
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-white">
                    4. Direct Messaging and Data Visibility
                  </h4>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    All initial campaign communication, casting calls, and content approvals must happen entirely inside the secure dashboard environment. Bloom Studio, Inc. retains master administrative database access to track user metrics, enforce safety guidelines, and verify invoicing compliance.
                  </p>
                </div>
              </div>

              {/* Checkbox 5: Master Privacy Policy & Escrow Safeguards */}
              <div 
                onClick={() => setCheckedBox5(!checkedBox5)}
                className={`p-4 rounded-2xl border transition cursor-pointer select-none flex items-start gap-3.5 ${
                  checkedBox5 
                    ? 'bg-[#0A162B] border-emerald-500/50 shadow-md shadow-emerald-950/20' 
                    : 'bg-[#081222] border-white/5 hover:border-white/20'
                }`}
              >
                <div className="pt-0.5 shrink-0">
                  {checkedBox5 ? (
                    <CheckSquare className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-500" />
                  )}
                </div>
                <div className="space-y-1 w-full">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-agency-gold" />
                      <span>5. Master Privacy Policy &amp; Data Safeguards</span>
                    </h4>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowPrivacyModal(true);
                      }}
                      className="text-[10px] font-mono text-agency-gold hover:underline bg-agency-gold/10 hover:bg-agency-gold/20 px-2.5 py-1 rounded-lg border border-agency-gold/25 flex items-center gap-1 cursor-pointer transition"
                    >
                      <span>Read Policy</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    I acknowledge, review, and accept Bloom Studio’s <strong className="text-white">Master Privacy Policy &amp; Data Protection Statement</strong>. I acknowledge our data silo guarantees, programmatic escrow boundaries, zero unauthorized data resale, and CCPA / GDPR data rights.
                  </p>
                </div>
              </div>

            </div>

            {/* Electronic Signature Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="text-[10px] font-mono text-slate-400 block mb-1">Authorized Representative Name</label>
                <input
                  type="text"
                  value={signerName}
                  onChange={e => setSignerName(e.target.value)}
                  className="w-full bg-[#081222] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
              <div>
                <label className="text-[10px] font-mono text-slate-400 block mb-1">Registered Brand / Organization</label>
                <input
                  type="text"
                  value={organizationName}
                  onChange={e => setOrganizationName(e.target.value)}
                  className="w-full bg-[#081222] border border-white/10 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            {/* Action Button: Grayed out and unclickable until all 5 are checked */}
            <button
              disabled={!allChecked || isSubmitting}
              onClick={handleAgreeAndProceed}
              className={`w-full py-3.5 rounded-2xl font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2 ${
                allChecked && !isSubmitting
                  ? 'bg-emerald-400 hover:bg-emerald-300 text-[#070D18] shadow-emerald-500/20 cursor-pointer'
                  : 'bg-slate-800 text-slate-500 border border-white/5 cursor-not-allowed opacity-60'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? 'Recording Electronic Signature...' : 'AGREE & PROCEED'}</span>
            </button>
          </>
        )}
      </motion.div>

      {/* Global Privacy Policy Modal */}
      <PrivacyPolicyModal
        isOpen={showPrivacyModal}
        onClose={() => {
          setShowPrivacyModal(false);
          setCheckedBox5(true);
        }}
      />
    </div>
  );
}
