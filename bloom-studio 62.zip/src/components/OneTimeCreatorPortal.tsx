import React, { useState, useEffect } from 'react';
import {
  FileText,
  UploadCloud,
  CheckCircle2,
  Clock,
  Truck,
  DollarSign,
  ShieldCheck,
  FileSignature,
  Video,
  AlertCircle,
  Download,
  Lock,
  ChevronRight,
  Eye,
  Check,
  Sparkles,
  UserCheck,
  Loader2
} from 'lucide-react';
import { computeRealSha256, persistSignatureRecord } from '../lib/cryptoSignatures';
import { db, auth } from '../lib/firebase';
import { doc, setDoc, onSnapshot } from 'firebase/firestore';

interface OneTimeCreatorPortalProps {
  currentUser?: any;
  currentRole?: string;
  contractorName?: string;
  contractorEmail?: string;
  contractorRole?: string;
  onSignComplete?: () => void;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

export const OneTimeCreatorPortal: React.FC<OneTimeCreatorPortalProps> = ({
  currentUser,
  currentRole = 'contractor',
  contractorName,
  contractorEmail,
  contractorRole,
  onSignComplete,
  onAddActivityLog,
  triggerNotification
}) => {
  // Session Verification Isolation Check:
  // Designed specifically for sourced, non-exclusive contractors who enter after a brand deal is signed or are in the Standby Bench.
  const isDirector = (currentRole || '').toLowerCase() === 'director' || (currentRole || '').toLowerCase() === 'owner';
  const effectiveName = contractorName || currentUser?.name || 'Jordan Taylor';
  const effectiveEmail = contractorEmail || currentUser?.email || 'jordan.contractor@bloomstudio.internal';
  const effectiveCreatorId = currentUser?.id || currentUser?.uid || currentUser?.email || 'contractor_default';

  // State for View Mode: 'active-deal' vs 'standby-roster'
  const [activeTab, setActiveTab] = useState<'active-deal' | 'standby-roster'>('active-deal');
  const [isReadyForGigs, setIsReadyForGigs] = useState(true);
  const [preferredNiches, setPreferredNiches] = useState<string[]>(['Beauty & Skincare', 'Lifestyle UGC', 'Tech & Unboxing']);
  const [standardRate, setStandardRate] = useState<number>(750);
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [benchSaveError, setBenchSaveError] = useState<string | null>(null);

  // State for 5 Linear Task Blocks
  const [w9Uploaded, setW9Uploaded] = useState(false);
  const [w9FileName, setW9FileName] = useState<string | null>(null);
  const [contractSigned, setContractSigned] = useState(false);
  const [signatureName, setSignatureName] = useState('');
  const [signedTimestamp, setSignedTimestamp] = useState<string | null>(null);

  const updateContractorProfile = async (patch: Record<string, any>) => {
    const uid = currentUser?.id || currentUser?.uid || auth.currentUser?.uid;
    if (!uid) return;
    try {
      await setDoc(doc(db, 'studio-users', uid), {
        ...patch,
        subagency: currentUser?.subagency || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default'
      }, { merge: true });
    } catch (err) {
      console.warn('[OneTimeCreatorPortal] Failed to update profile:', err);
    }
  };

  // Sync contractor profile data from Firestore
  useEffect(() => {
    const uid = currentUser?.id || currentUser?.uid;
    if (!uid) return;

    const userRef = doc(db, 'studio-users', uid);
    const unsubscribe = onSnapshot(userRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.isReadyForGigs !== undefined) setIsReadyForGigs(data.isReadyForGigs);
        if (data.preferredNiches !== undefined) setPreferredNiches(data.preferredNiches);
        if (data.standardRate !== undefined) setStandardRate(data.standardRate);
        if (data.contractSigned !== undefined) setContractSigned(data.contractSigned);
        if (data.signedTimestamp !== undefined) setSignedTimestamp(data.signedTimestamp);
        if (data.w9Status === 'Verified' || data.w9Uploaded === true) setW9Uploaded(true);
        if (data.w9FileName) setW9FileName(data.w9FileName);
      }
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Persists the standby-bench fields (availability, niches, rate, W-9 status) to
  // this contractor's real studio-creators record. Every control on this screen
  // that's meant to make someone findable/dispatchable calls this after updating
  // its own local state, so the "bench" a director searches is backed by real data
  // instead of values that only ever existed in this one browser tab.
  const persistBenchProfile = async (patch: Record<string, any>) => {
    if (!effectiveCreatorId || effectiveCreatorId === 'unknown') return;
    try {
      setBenchSaveError(null);
      await setDoc(doc(db, 'studio-creators', effectiveCreatorId), {
        ...patch,
        engagementType: 'one_time_contractor',
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err: any) {
      console.warn('[OneTimeCreatorPortal] Failed to save bench profile field:', err);
      setBenchSaveError('Could not save this change — please try again.');
      triggerNotification?.(
        'Save Failed',
        'Your bench profile update could not be saved. Please try again.',
        'danger'
      );
    }
  };

  const handleToggleReadyForGigs = () => {
    const next = !isReadyForGigs;
    setIsReadyForGigs(next);
    persistBenchProfile({ benchReadyForGigs: next });
  };

  const handleUpdateStandardRate = (nextRate: number) => {
    setStandardRate(nextRate);
    persistBenchProfile({ benchStandardRate: nextRate });
  };

  const handleToggleNiche = (niche: string) => {
    setPreferredNiches(prev => {
      const next = prev.includes(niche) ? prev.filter(n => n !== niche) : [...prev, niche];
      persistBenchProfile({ benchPreferredNiches: next });
      return next;
    });
  };

  // Deliverables Staging
  const [videoFileUploaded, setVideoFileUploaded] = useState(false);
  const [videoFileName, setVideoFileName] = useState<string | null>(null);
  const [captionText, setCaptionText] = useState(
    'Loving the new summer radiance drops! ✨ Clean ingredients, 24hr hydration. Use code GLOW20 #ad #sponsored'
  );
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);

  // Hardcoded contractor campaign data (Strictly isolated from corporate client total deal sums)
  const contractorCampaign = {
    id: 'one_time_camp_01',
    campaignName: 'Summer Glow Beauty Launch',
    brandName: 'DripRoom Beauty',
    contractorName: effectiveName,
    flatFeePayout: 750.00,
    deadline: '2026-09-08',
    deliverableType: '1x 9:16 Vertical Video (30-60s) + 3 Raw Hooks',
    shipping: {
      carrier: 'FedEx Express',
      trackingNumber: 'FDX-9942-8812-4011',
      packageDescription: 'Summer Radiance Full Box + Sample Drops',
      status: 'Delivered' as 'Shipped' | 'In Transit' | 'Delivered',
      estimatedDelivery: '2026-08-30 (Delivered to Studio)',
      currentLocation: 'Front Porch / Handed to Resident'
    }
  };

  // Block A: W-9 Upload
  const handleW9Upload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.pdf')) {
      triggerNotification?.('Invalid File Format', 'Please upload your completed W-9 in PDF format only.', 'danger');
      return;
    }

    setW9Uploaded(true);
    setW9FileName(file.name);
    persistBenchProfile({ benchW9Uploaded: true, benchW9FileName: file.name });
    triggerNotification?.(
      'W-9 Form Received',
      `Routing ${file.name} to director-tax-vault securely.`,
      'success'
    );

    onAddActivityLog?.(
      effectiveName,
      'One_Time_Contractor',
      `Uploaded IRS W-9 form (${file.name}) to director-tax-vault`
    );
  };

  const [isSubmittingSignature, setIsSubmittingSignature] = useState(false);

  // Block B: Contract Signature
  const handleSignContract = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signatureName.trim()) return;

    setIsSubmittingSignature(true);
    try {
      const nowIso = new Date().toISOString();
      const time = new Date().toLocaleString();
      
      const payloadToHash = `BLOOM_ONE_TIME_CONTRACTOR_AGREEMENT|SIGNER:${signatureName}|CAMPAIGN:${contractorCampaign.campaignName}|USER_ID:${currentUser?.id || currentUser?.uid || 'guest'}|DATE:${nowIso}`;
      const hashStr = await computeRealSha256(payloadToHash);

      const record = {
        id: `one_time_sig_${Date.now()}`,
        documentType: 'One-Time Contractor Agreement',
        signerName: signatureName,
        signerEmail: currentUser?.email || 'contractor@example.com',
        signerRole: 'One-Time Contractor',
        isoTimestamp: nowIso,
        formattedTimestamp: time,
        digest: hashStr,
        payloadContent: payloadToHash,
        metadata: {
          campaignId: contractorCampaign.id,
          campaignName: contractorCampaign.campaignName,
          flatFeePayout: contractorCampaign.flatFeePayout
        }
      };

      // Persist authentic digital signature record
      await persistSignatureRecord(record);

      setContractSigned(true);
      setSignedTimestamp(time);
      
      // Persist contract status to profile
      await updateContractorProfile({ 
        contractSigned: true, 
        signedTimestamp: time,
        contractDigest: hashStr
      });

      triggerNotification?.(
        'Contract Digitally Executed',
        `Signed flat-fee agreement ($${contractorCampaign.flatFeePayout.toFixed(2)}) as "${signatureName}". Records secured to tax-vault.`,
        'success'
      );

      onAddActivityLog?.(
        effectiveName,
        'One_Time_Contractor',
        `Digitally signed campaign contractor agreement for ${contractorCampaign.campaignName} (Audit Hash: ${hashStr})`
      );

      onSignComplete?.();
    } catch (err: any) {
      console.error('[OneTimeCreatorPortal] Signature failure:', err);
      triggerNotification?.('Signature Failed', err.message || 'Could not execute digital agreement.', 'danger');
    } finally {
      setIsSubmittingSignature(false);
    }
  };

  // Block D: Deliverables Upload
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setVideoFileUploaded(true);
    setVideoFileName(file.name);
    setVideoPreviewUrl('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4');

    triggerNotification?.(
      'Draft Deliverable Uploaded',
      `${file.name} staged for internal compliance and brand review.`,
      'success'
    );

    onAddActivityLog?.(
      currentUser?.name || 'Contractor',
      'One_Time_Contractor',
      `Uploaded draft deliverable: ${file.name}`
    );
  };

  // Compute Overall Progress
  const completedSteps = [
    w9Uploaded,
    contractSigned,
    contractorCampaign.shipping.status === 'Delivered',
    videoFileUploaded,
    false // payout pending internal review
  ].filter(Boolean).length;

  return (
    <div id="one-time-creator-portal" className="min-h-screen bg-[#0B1B3D] text-slate-100 p-4 sm:p-6 lg:p-8 space-y-8 font-sans">
      {/* Top Banner */}
      <div className="bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-2xl text-[#D4AF37]">
                <UserCheck className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-wide flex items-center gap-3">
                  Non-Exclusive Contractor Fast-Path Portal
                  <span className="text-xs font-mono px-3 py-1 bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] rounded-full font-bold">
                    Single-Campaign Fast Track
                  </span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 mt-1">
                  Welcome to the campaign staging node. Complete the 5 linear onboarding steps below to clear tax compliance, receive your product sample, stage video deliverables, and receive your flat-fee payout.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-[#0B1B3D] border border-white/10 p-4 rounded-2xl">
            <div>
              <span className="text-[10px] font-mono uppercase text-slate-400 block">Flat-Fee Compensation</span>
              <strong className="text-2xl font-bold font-mono text-[#D4AF37]">${contractorCampaign.flatFeePayout.toFixed(2)}</strong>
            </div>
            <div className="h-8 w-px bg-white/10 hidden sm:block" />
            <div>
              <span className="text-[10px] font-mono uppercase text-slate-400 block">Onboarding Progress</span>
              <span className="text-sm font-mono text-emerald-400 font-bold">{completedSteps} of 5 Milestones Complete</span>
            </div>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-3 mt-6 pt-4 border-t border-white/10">
          <button
            type="button"
            onClick={() => setActiveTab('active-deal')}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
              activeTab === 'active-deal'
                ? 'bg-[#D4AF37] text-[#0B1B3D] shadow-lg'
                : 'bg-[#0B1B3D]/80 text-slate-300 hover:text-white hover:bg-white/5 border border-white/10'
            }`}
          >
            📋 Active Deal Tasks ({completedSteps}/5)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('standby-roster')}
            className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
              activeTab === 'standby-roster'
                ? 'bg-[#D4AF37] text-[#0B1B3D] shadow-lg'
                : 'bg-[#0B1B3D]/80 text-slate-300 hover:text-white hover:bg-white/5 border border-white/10'
            }`}
          >
            ⭐ Standby Bench & Roster Profile
          </button>
        </div>
      </div>

      {/* RENDER ACTIVE TAB */}
      {activeTab === 'standby-roster' ? (
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Bench Status Card */}
          <div className="bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#D4AF37]" />
                  Standby Contractor Bench Status
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Keep your bench profile active so agents can immediately assign single-project deals when matching brand gigs arise.
                </p>
              </div>
              <div className="flex items-center gap-3 bg-[#0B1B3D] p-2 rounded-2xl border border-white/10">
                <span className="text-xs font-mono text-slate-300">Ready for Gigs:</span>
                <button
                  type="button"
                  onClick={handleToggleReadyForGigs}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                    isReadyForGigs
                      ? 'bg-emerald-500 text-[#0B1B3D]'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {isReadyForGigs ? "🟢 Active & Available" : "🔴 On Pause"}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-white/10">
              <div className="p-4 bg-[#0B1B3D] rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Standard Flat Fee</span>
                <div className="flex items-center gap-2">
                  <div className="relative group">
                    <span className="text-lg font-bold font-mono text-[#D4AF37]">$</span>
                    <input 
                      type="number"
                      value={standardRate}
                      onChange={(e) => {
                        const val = parseInt(e.target.value) || 0;
                        setStandardRate(val);
                      }}
                      onBlur={() => handleUpdateStandardRate(standardRate)}
                      className="bg-transparent border-none focus:ring-0 w-20 text-lg font-bold font-mono text-[#D4AF37] p-0"
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">/ deliverable</span>
                </div>
              </div>

              <div className="p-4 bg-[#0B1B3D] rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Tax Clearance</span>
                <div className="flex items-center gap-1.5 text-xs font-mono text-emerald-400 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  {w9Uploaded ? "W-9 on File" : "Pending Intake"}
                </div>
              </div>

              <div className="p-4 bg-[#0B1B3D] rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] font-mono text-slate-400 uppercase">Payout Route</span>
                <div className="flex items-center gap-1.5 text-xs font-mono text-[#D4AF37] font-bold">
                  <DollarSign className="w-4 h-4" />
                  Stripe Instant Payout
                </div>
              </div>
            </div>

            {/* Niches and Content Categories */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-slate-400 block font-bold">Content Niches & Specializations</span>
                <button 
                  type="button"
                  onClick={() => {
                    const niche = prompt("Add a new niche (e.g. 'Skincare', 'Tech'):");
                    if (niche && !preferredNiches.includes(niche)) {
                      handleToggleNiche(niche);
                    }
                  }}
                  className="text-[10px] font-mono text-[#D4AF37] hover:underline"
                >
                  + Add Niche
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {preferredNiches.map((niche) => (
                  <span key={niche} className="group relative px-3 py-1 bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] rounded-xl text-xs font-mono font-medium">
                    {niche}
                    <button 
                      onClick={() => {
                        const next = preferredNiches.filter(n => n !== niche);
                        setPreferredNiches(next);
                        updateContractorProfile({ preferredNiches: next });
                      }}
                      className="ml-2 text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
      /* 5 LINEAR TASK BLOCKS CONTAINER */
      <div className="max-w-4xl mx-auto space-y-6">

        {/* BLOCK A: TAX COMPLIANCE */}
        <div className={`bg-[#142850] border rounded-3xl p-6 sm:p-8 shadow-2xl transition-all ${w9Uploaded ? 'border-emerald-500/40' : 'border-white/10'}`}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                w9Uploaded ? 'bg-emerald-500 text-[#0B1B3D]' : 'bg-[#D4AF37] text-[#0B1B3D]'
              }`}>
                {w9Uploaded ? <Check className="w-4 h-4" /> : 'A'}
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Tax Compliance & W-9 Intake
                  {w9Uploaded && <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">Completed</span>}
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Required IRS compliance for non-employee contractor compensation.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-[#D4AF37] uppercase bg-[#D4AF37]/10 px-2.5 py-1 rounded-xl">
              director-tax-vault
            </span>
          </div>

          <div className="mt-6 pt-4 border-t border-white/10 space-y-4">
            {!w9Uploaded ? (
              <div className="border-2 border-dashed border-white/20 hover:border-[#D4AF37] rounded-2xl p-6 text-center space-y-3 bg-[#0B1B3D] transition-all">
                <UploadCloud className="w-8 h-8 text-[#D4AF37] mx-auto" />
                <div>
                  <p className="text-sm font-bold text-white">Upload Completed IRS W-9 Form (PDF Only)</p>
                  <p className="text-xs text-slate-400 mt-1">Upload your signed W-9 document. Files route directly to director-tax-vault.</p>
                </div>
                <label className="inline-block px-5 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] text-xs font-bold font-mono rounded-xl cursor-pointer shadow-md hover:brightness-110">
                  Select W-9 PDF File
                  <input type="file" accept=".pdf" onChange={handleW9Upload} className="hidden" />
                </label>
              </div>
            ) : (
              <div className="p-4 bg-[#0B1B3D] border border-emerald-500/30 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-emerald-400" />
                  <div>
                    <p className="text-xs font-bold text-white">{w9FileName || 'IRS_W9_Signed.pdf'}</p>
                    <span className="text-[10px] text-slate-400 font-mono">Vault Hash: TX-VAULT-2026-OK</span>
                  </div>
                </div>
                <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Verified
                </span>
              </div>
            )}
          </div>
        </div>

        {/* BLOCK B: LEGAL AGREEMENT */}
        <div className={`bg-[#142850] border rounded-3xl p-6 sm:p-8 shadow-2xl transition-all ${contractSigned ? 'border-emerald-500/40' : 'border-white/10'}`}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                contractSigned ? 'bg-emerald-500 text-[#0B1B3D]' : 'bg-[#D4AF37] text-[#0B1B3D]'
              }`}>
                {contractSigned ? <Check className="w-4 h-4" /> : 'B'}
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Flat-Fee Contractor Agreement
                  {contractSigned && <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">Signed & Executed</span>}
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Single-deal scope: {contractorCampaign.campaignName} ({contractorCampaign.deliverableType}).
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-[#D4AF37] uppercase bg-[#D4AF37]/10 px-2.5 py-1 rounded-xl">
              Flat Fee: ${contractorCampaign.flatFeePayout.toFixed(2)}
            </span>
          </div>

          <div className="mt-6 pt-4 border-t border-white/10 space-y-4">
            <div className="bg-[#0B1B3D] border border-white/10 rounded-2xl p-4 max-h-44 overflow-y-auto text-xs text-slate-300 space-y-2 font-mono leading-relaxed">
              <p className="font-bold text-white">NON-EXCLUSIVE INDEPENDENT CONTRACTOR MEMORANDUM</p>
              <p>1. SCOPE: Contractor agrees to deliver {contractorCampaign.deliverableType} by {contractorCampaign.deadline}.</p>
              <p>2. COMPENSATION: Agency shall disburse flat compensation of ${contractorCampaign.flatFeePayout.toFixed(2)} USD upon final deliverable acceptance and W-9 verification.</p>
              <p>3. FTC COMPLIANCE: Contractor must clearly disclose commercial sponsorship using #ad or #sponsored in video and caption.</p>
              <p>4. IP RIGHTS: Contractor grants brand commercial digital advertising usage for 90 days across organic & paid social channels.</p>
            </div>

            {!contractSigned ? (
              <form onSubmit={handleSignContract} className="flex flex-col sm:flex-row gap-3 pt-2">
                <input
                  type="text"
                  required
                  value={signatureName}
                  onChange={(e) => setSignatureName(e.target.value)}
                  placeholder="Type Full Legal Name to Digitally Sign"
                  className="flex-1 bg-[#0B1B3D] border border-white/20 rounded-xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none font-serif italic"
                />
                <button
                  type="submit"
                  disabled={isSubmittingSignature}
                  className="px-6 py-3 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] font-bold text-xs font-mono rounded-xl shadow-md cursor-pointer hover:brightness-110 flex items-center justify-center gap-2 min-w-[160px]"
                >
                  {isSubmittingSignature ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Executing...
                    </>
                  ) : (
                    <>✍️ Execute Agreement</>
                  )}
                </button>
              </form>
            ) : (
              <div className="p-4 bg-[#0B1B3D] border border-emerald-500/30 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileSignature className="w-5 h-5 text-[#D4AF37]" />
                  <div>
                    <p className="text-xs font-serif font-bold text-white italic">"{signatureName}"</p>
                    <span className="text-[10px] text-slate-400 font-mono">Executed on {signedTimestamp}</span>
                  </div>
                </div>
                <span className="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Legally Binding
                </span>
              </div>
            )}
          </div>
        </div>

        {/* BLOCK C: PRODUCT LOGISTICS */}
        <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500 text-[#0B1B3D] flex items-center justify-center font-mono font-bold text-xs">
                <Check className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Product Sample Logistics & Transit Tracking
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">Delivered</span>
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Synchronized from studio-fulfillment tracking feeds.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-xl">
              studio-fulfillment
            </span>
          </div>

          <div className="pt-4 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
            <div className="p-3.5 bg-[#0B1B3D] rounded-2xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 block">Carrier & Service</span>
              <strong className="text-white flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-[#D4AF37]" />
                {contractorCampaign.shipping.carrier}
              </strong>
            </div>

            <div className="p-3.5 bg-[#0B1B3D] rounded-2xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 block">Tracking Number</span>
              <strong className="text-white">{contractorCampaign.shipping.trackingNumber}</strong>
            </div>

            <div className="p-3.5 bg-[#0B1B3D] rounded-2xl border border-white/5 space-y-1">
              <span className="text-[10px] text-slate-400 block">Package Contents</span>
              <strong className="text-white truncate block">{contractorCampaign.shipping.packageDescription}</strong>
            </div>

            <div className="p-3.5 bg-[#0B1B3D] rounded-2xl border border-emerald-500/30 space-y-1">
              <span className="text-[10px] text-slate-400 block">Transit Status</span>
              <strong className="text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                Delivered to Resident
              </strong>
            </div>
          </div>
        </div>

        {/* BLOCK D: DELIVERABLES STAGING */}
        <div className={`bg-[#142850] border rounded-3xl p-6 sm:p-8 shadow-2xl transition-all ${videoFileUploaded ? 'border-emerald-500/40' : 'border-white/10'}`}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                videoFileUploaded ? 'bg-emerald-500 text-[#0B1B3D]' : 'bg-[#D4AF37] text-[#0B1B3D]'
              }`}>
                {videoFileUploaded ? <Check className="w-4 h-4" /> : 'D'}
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Deliverables Staging & Caption Review
                  {videoFileUploaded && <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">Staged for Review</span>}
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Upload raw 9:16 vertical video asset (.mp4 or .mov) and proposed social caption.
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-[#D4AF37] uppercase bg-[#D4AF37]/10 px-2.5 py-1 rounded-xl">
              Due: {contractorCampaign.deadline}
            </span>
          </div>

          <div className="mt-6 pt-4 border-t border-white/10 space-y-4">
            {!videoFileUploaded ? (
              <div className="border-2 border-dashed border-white/20 hover:border-[#D4AF37] rounded-2xl p-6 text-center space-y-3 bg-[#0B1B3D] transition-all">
                <Video className="w-8 h-8 text-[#D4AF37] mx-auto" />
                <div>
                  <p className="text-sm font-bold text-white">Upload Vertical Video File (.mp4, .mov)</p>
                  <p className="text-xs text-slate-400 mt-1">Direct upload to internal staging queue for quality assurance.</p>
                </div>
                <label className="inline-block px-5 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] text-xs font-bold font-mono rounded-xl cursor-pointer shadow-md hover:brightness-110">
                  Select Video File
                  <input type="file" accept="video/mp4,video/quicktime,video/mov" onChange={handleVideoUpload} className="hidden" />
                </label>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-[#0B1B3D] border border-emerald-500/30 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Video className="w-4 h-4 text-emerald-400" />
                      {videoFileName}
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">Ready for QA</span>
                  </div>
                  <div className="aspect-video bg-black rounded-xl overflow-hidden relative">
                    <video src={videoPreviewUrl || ''} controls className="w-full h-full object-cover" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Proposed Caption & Disclosures
                  </label>
                  <textarea
                    rows={4}
                    value={captionText}
                    onChange={(e) => setCaptionText(e.target.value)}
                    className="w-full bg-[#0B1B3D] border border-white/15 rounded-2xl p-3 text-xs text-white placeholder:text-slate-500 focus:border-[#D4AF37] outline-none resize-none leading-relaxed font-sans"
                  />
                  <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-mono">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>FTC #ad disclosure detected in caption</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* BLOCK E: PAYOUT STATUS */}
        <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] text-[#D4AF37] flex items-center justify-center font-mono font-bold text-xs">
                E
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  Payout Status & Escrow Disbursement
                  <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">In Verification</span>
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Locked flat-fee disbursement upon QA review and W-9 verification.
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 block">Pending Payout</span>
              <strong className="text-xl font-mono font-bold text-[#D4AF37]">${contractorCampaign.flatFeePayout.toFixed(2)}</strong>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10 space-y-3">
            <div className="p-4 bg-[#0B1B3D] border border-white/10 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-[#D4AF37] animate-spin" />
                <div>
                  <p className="text-xs font-bold text-white font-mono">
                    Awaiting Internal Compliance Clearance & Payout Processing
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Expected settlement window: 24-48 business hours after video publish confirmation.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs font-mono text-[#D4AF37] font-bold">
                <Lock className="w-4 h-4" />
                <span>Escrow Funded</span>
              </div>
            </div>
          </div>
        </div>

      </div>
      )}
    </div>
  );
};

export default OneTimeCreatorPortal;
