import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  FileText, 
  Download, 
  Sparkles, 
  CheckCircle2, 
  ShieldAlert, 
  Layers, 
  Send, 
  UserCheck, 
  Eye, 
  Clock, 
  DollarSign, 
  Award, 
  Check, 
  MessageSquare,
  ShieldCheck,
  Zap,
  ArrowRight,
  Info,
  Globe
} from 'lucide-react';
import { exportCreativeBriefPDF } from '../utils/pdfExportUtils';
import { Creator } from '../types';
import { safeStorage } from '../utils/safeStorage';
import { getAuthHeaders } from '../lib/firebase';
import { db } from '../lib/firebase';
import { doc, setDoc, serverTimestamp, collection, query, where, onSnapshot } from 'firebase/firestore';
import { getStoredDirectorDelegation, saveStoredDirectorDelegation, DirectorDelegationSettings } from './DirectorDelegationControls';

interface CreativeBriefingStudioProps {
  creators?: Creator[];
  initialBrandName?: string;
  initialNiche?: 'Pets' | 'Beauty' | 'Lifestyle';
  initialGoals?: string;
  initialStyleGuidelines?: string;
  initialHooks?: string;
  initialContractText?: string;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  currentUser?: any;
  currentRole?: string;
  clientId?: string;
  campaignId?: string;
  deals?: any[];
  delegationSettings?: DirectorDelegationSettings;
}

interface ApprovedBriefTemplate {
  id: string;
  brandName: string;
  campaignTitle: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  goals: string;
  deliverables: string;
  styleGuidelines: string;
  hooks: string;
  ftcCompliance: string;
  payout: string;
  deadline: string;
  directorApprovedAt: string;
  contractLegalText: string;
}

const APPROVED_BRIEFS: ApprovedBriefTemplate[] = [
  {
    id: 'brief-glowlab-01',
    brandName: 'GlowLab Beauty',
    campaignTitle: 'Summer Botanical Serum Launch',
    niche: 'Beauty',
    goals: 'Launch the new botanical serum with handcrafted creator UGC reels driving awareness, skin texture closeups, and swipe-up conversions.',
    deliverables: '1x 60s TikTok UGC Video + 1x Instagram Reel with product link sticker & 30-day paid ad usage.',
    styleGuidelines: 'Warm morning daylight, macro texture closeups of product pipette application, clear skin-type disclaimer, authentic first-impression reaction. No heavy artificial filters.',
    hooks: 'Visual hook (0-3s): "I tested this viral botanical serum for 7 days so you don\'t have to..." with bold on-screen captions.',
    ftcCompliance: 'Mandatory conspicuous #ad disclosure at the very start of caption and clear spoken overlay within the first 3 seconds.',
    payout: '$3,500 Escrow Payout',
    deadline: 'Due in 7 business days',
    directorApprovedAt: 'Approved by Director • Ready for Agent Dispatch',
    contractLegalText: `BLOOM STUDIO INFLUENCER TALENT DELIVERABLE AGREEMENT
1. SCOPE OF WORK: 1x 60s TikTok UGC Video + 1x Instagram Reel with permanent link sticker.
2. FTC COMPLIANCE: Clear, conspicuous #ad disclosure at the very start of caption and spoken overlay in first 3 seconds.
3. FINANCIAL ALLOCATION: Escrow settlement of $3,500 upon final director approval.
4. USAGE RIGHTS: 30-day organic and whitelisted digital paid distribution rights.`
  },
  {
    id: 'brief-barkhydrate-02',
    brandName: 'BarkHydrate',
    campaignTitle: 'Pet Wellness & Electrolytes Blitz',
    niche: 'Pets',
    goals: 'Showcase quick dog electrolyte powder mixing before a summer park walk, focusing on dog excitement and healthy hydration.',
    deliverables: '2x 45s TikTok UGC Videos + raw B-roll cuts with natural pet sound effects.',
    styleGuidelines: 'Outdoor park or clean kitchen lighting, dynamic pet interaction, cute dog close-ups drinking from bowl.',
    hooks: 'Visual hook (0-3s): "Stop giving your dog just plain water during summer walks..."',
    ftcCompliance: '#ad in caption and audio mention.',
    payout: '$2,800 Escrow Payout',
    deadline: 'Due in 5 business days',
    directorApprovedAt: 'Approved by Director • Ready for Agent Dispatch',
    contractLegalText: `BLOOM STUDIO INFLUENCER TALENT DELIVERABLE AGREEMENT
1. SCOPE OF WORK: 2x 45s TikTok UGC Videos + raw B-roll.
2. FTC COMPLIANCE: Clear #ad tag in video and caption.
3. FINANCIAL ALLOCATION: $2,800 Escrow Payout.
4. USAGE RIGHTS: Full brand organic social usage.`
  },
  {
    id: 'brief-zenfit-03',
    brandName: 'ZenFit Activewear',
    campaignTitle: 'Bamboo Seamless Activewear Drop',
    niche: 'Lifestyle',
    goals: 'Demonstrate squat-proof elasticity, sweat-wicking breathability, and aesthetic studio styling.',
    deliverables: '1x High-energy 30s TikTok/Reel + 3x Instagram Story Frames with discount code.',
    styleGuidelines: 'Natural studio lighting, smooth gimbal movement, fabric stretch closeups and fit commentary.',
    hooks: 'Visual hook (0-3s): "Finally found workout sets that don\'t roll down during pilates..."',
    ftcCompliance: 'Clear #sponsored or #ad hashtag above the fold in caption.',
    payout: '$4,200 Escrow Payout',
    deadline: 'Due in 10 business days',
    directorApprovedAt: 'Approved by Director • Ready for Agent Dispatch',
    contractLegalText: `BLOOM STUDIO INFLUENCER TALENT DELIVERABLE AGREEMENT
1. SCOPE OF WORK: 1x 30s Reel + 3x Story Slides.
2. FTC COMPLIANCE: Clear #ad tag.
3. FINANCIAL ALLOCATION: $4,200 Escrow Payout.
4. USAGE RIGHTS: 60-day digital advertising whitelisting.`
  }
];

export default function CreativeBriefingStudio({
  creators = [],
  initialBrandName = 'GlowLab Beauty & BarkHydrate',
  initialNiche = 'Beauty',
  initialGoals = 'Launch the new botanical serum with 12 handcrafted creator UGC reels driving awareness and clicks.',
  initialStyleGuidelines = 'Warm daylight, macro texture closeups of product application, clear skin-type disclaimer, genuine creator reaction.',
  initialHooks = 'Visual hook in seconds 0-3: "I tested this for 7 days so you don\'t have to..." with high contrast on-screen captions.',
  initialContractText = `BLOOM STUDIO INFLUENCER TALENT DELIVERABLE AGREEMENT
1. SCOPE OF WORK: 1x 60s TikTok UGC Video + 1x Instagram Reel with permanent link sticker.
2. FTC COMPLIANCE: Clear, conspicuous #ad disclosure at the very start of caption and spoken overlay in first 3 seconds.
3. FINANCIAL ALLOCATION: Escrow settlement of $3,500 upon final director approval.
4. USAGE RIGHTS: 30-day organic and whitelisted digital paid distribution rights.`,
  triggerNotification,
  onAddActivityLog,
  currentUser,
  currentRole = 'agent',
  clientId = 'client_bloom',
  campaignId = 'camp_summer_2026',
  deals = [],
  delegationSettings: propDelegationSettings,
}: CreativeBriefingStudioProps) {
  // Active selected brief for review & dispatch
  const [selectedBriefIndex, setSelectedBriefIndex] = useState(0);
  const activeBrief = APPROVED_BRIEFS[selectedBriefIndex];

  // Customizer state for Director mode
  const [brandName, setBrandName] = useState(initialBrandName);
  const [niche, setNiche] = useState<'Pets' | 'Beauty' | 'Lifestyle'>(initialNiche);
  const [campaignGoals, setCampaignGoals] = useState(initialGoals);
  const [styleGuidelines, setStyleGuidelines] = useState(initialStyleGuidelines);
  const [requiredHooks, setRequiredHooks] = useState(initialHooks);
  const [contractLegalText, setContractLegalText] = useState(initialContractText);

  // Director delegation settings state
  const [delegationSettings, setDelegationSettings] = useState<DirectorDelegationSettings>(() => {
    if (propDelegationSettings) return propDelegationSettings;
    return getStoredDirectorDelegation();
  });

  useEffect(() => {
    if (propDelegationSettings) {
      setDelegationSettings(propDelegationSettings);
    }
  }, [propDelegationSettings]);

  React.useEffect(() => {
    const handleUpdate = (e: any) => {
      if (e.detail) setDelegationSettings(e.detail);
    };
    window.addEventListener('director_delegation_updated', handleUpdate);
    return () => window.removeEventListener('director_delegation_updated', handleUpdate);
  }, []);

  const isDirectorRole = ['director', 'owner', 'agency', 'admin'].includes((currentRole || '').toLowerCase());
  const isAgentMgrRole = (currentRole || '').toLowerCase() === 'agentmgr' || (currentRole || '').toLowerCase().includes('manager');
  const isAgentRole = (currentRole || '').toLowerCase() === 'agent';
  const canDraftBriefs = (isDirectorRole || isAgentRole) ? true : delegationSettings.agentManagerCanDraftBriefs;

  // Agent Dispatch State
  const [selectedCreatorHandle, setSelectedCreatorHandle] = useState<string>(creators[0]?.handle || '@alexjones');
  const [creatorSelectMode, setCreatorSelectMode] = useState<'roster' | 'contract'>('roster');
  const [selectedContractDealId, setSelectedContractDealId] = useState<string>('');
  const [showDuplicateWarningModal, setShowDuplicateWarningModal] = useState(false);

  const [dispatchedBriefs, setDispatchedBriefs] = useState<{
    id: string;
    brand: string;
    creator: string;
    date: string;
    status: string;
    note?: string;
  }[]>([]);

  React.useEffect(() => {
    let unsub = () => {};
    if (db) {
      const isPlatformOwner = currentUser?.isPlatformOwner || false;
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';

      let q: any = collection(db, 'studio-briefs');
      if (!isPlatformOwner) {
        q = query(
          collection(db, 'studio-briefs'),
          where('tenantId', '==', userPod)
        );
      }

      unsub = onSnapshot(q, (snapshot) => {
        const list: any[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          list.push({
            id: docSnap.id,
            brand: data.brandName || data.brand || '',
            creator: data.creatorHandle || data.creator || '',
            date: data.sentAt ? new Date(data.sentAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recently',
            status: data.status === 'Sent' ? 'Passed to Creator (Pending Review)' : data.status || 'Sent',
            note: data.agentNote || ''
          });
        });

        if (list.length > 0) {
          setDispatchedBriefs(list);
        } else {
          // If Firestore is empty, seed the 2 default dispatches so we have real persistent data
          const defaultDispatches = [
            {
              id: 'dispatch-001',
              brand: 'GlowLab Beauty',
              brandName: 'GlowLab Beauty',
              title: 'GlowLab Beauty - Creative Brief',
              creatorHandle: '@sophiaglows',
              creator: '@sophiaglows',
              sentAt: new Date().toISOString(),
              date: 'Aug 28, 2026',
              status: 'Passed to Creator (Pending Review)',
              agentNote: 'Please focus on the macro dropper application in natural light.',
              note: 'Please focus on the macro dropper application in natural light.',
              tenantId: userPod,
              subagency: userPod,
              pod: userPod
            },
            {
              id: 'dispatch-002',
              brand: 'BarkHydrate',
              brandName: 'BarkHydrate',
              title: 'BarkHydrate - Creative Brief',
              creatorHandle: '@alexjones',
              creator: '@alexjones',
              sentAt: new Date().toISOString(),
              date: 'Aug 29, 2026',
              status: 'Accepted by Creator',
              agentNote: 'Ready for filming after product package arrival.',
              note: 'Ready for filming after product package arrival.',
              tenantId: userPod,
              subagency: userPod,
              pod: userPod
            }
          ];
          defaultDispatches.forEach(async (d) => {
            try {
              await setDoc(doc(db, 'studio-briefs', d.id), d);
            } catch (err) {
              console.warn("Seeding default brief failed:", err);
            }
          });
          setDispatchedBriefs(defaultDispatches);
        }
      }, (error) => {
        console.warn("Firestore studio-briefs listener warning:", error);
      });
    }
    return () => unsub();
  }, [currentUser]);

  // Check if target creator has already received this brief
  const alreadyReceivedRecord = React.useMemo(() => {
    const currentBrand = (currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief?.brandName : brandName;
    const targetCreator = (selectedCreatorHandle || '').toLowerCase();
    if (!targetCreator || !currentBrand) return null;

    const foundDispatch = dispatchedBriefs.find(d => 
      d.brand.toLowerCase() === currentBrand.toLowerCase() && 
      (d.creator.toLowerCase() === targetCreator || d.creator.toLowerCase().includes(targetCreator.replace('@', '')))
    );
    if (foundDispatch) return { ...foundDispatch, passedBy: (foundDispatch as any).passedBy || 'Agent Manager Marcus Cole / Director' };

    try {
      const stored = safeStorage.getItem('wl_creator_briefs');
      if (stored) {
        const list = JSON.parse(stored);
        const found = list.find((b: any) => 
          b.brandName?.toLowerCase() === currentBrand.toLowerCase() &&
          (b.creatorHandle?.toLowerCase() === targetCreator || b.creatorHandle?.toLowerCase().includes(targetCreator.replace('@', '')))
        );
        if (found) {
          return {
            id: found.id,
            brand: found.brandName,
            creator: found.creatorHandle,
            date: found.sentAt || 'Recently',
            status: found.status || 'Delivered to Creator Portal',
            passedBy: found.passedBy || 'Agent Manager Marcus Cole / Director',
            note: found.agentNote
          };
        }
      }
    } catch {}

    return null;
  }, [dispatchedBriefs, activeBrief, brandName, selectedCreatorHandle, currentRole]);

  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [useGrounding, setUseGrounding] = useState(false);
  const [isGeneratingTrendAI, setIsGeneratingTrendAI] = useState(false);

  const handleGenerateTrendAI = async () => {
    setIsGeneratingTrendAI(true);
    try {
      const authHeaders = await getAuthHeaders();
      const res = await fetch('/api/ai-trend-brief', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({
          brandName,
          niche,
          campaignGoals,
          useGrounding
        })
      });
      const data = await res.json();
      if (data.success) {
        if (data.goals) setCampaignGoals(data.goals);
        if (data.styleGuidelines) setStyleGuidelines(data.styleGuidelines);
        if (data.hooks) setRequiredHooks(data.hooks);
        if (data.contractTerms) {
          let contractText = data.contractTerms;
          if (data.disclosure) {
            contractText = `[DISCLOSURE: ${data.disclosure}]\n\n${contractText}`;
          }
          setContractLegalText(contractText);
        }
        
        if (triggerNotification) {
          triggerNotification(
            data.isSimulated ? "Trend Intelligence (Fallback)" : "Trend Intelligence AI",
            data.disclosure || `Successfully generated trend-optimized brief for ${brandName} with live Google Search grounding!`,
            data.isSimulated ? "warning" : "success"
          );
        }
      }
    } catch (err) {
      console.error("Trend AI error:", err);
      if (triggerNotification) {
        triggerNotification("Trend AI Error", "Failed to query live trend intelligence. Using fallback parameters.", "warning");
      }
    } finally {
      setIsGeneratingTrendAI(false);
    }
  };
  const [recipientTarget, setRecipientTarget] = useState<'creator' | 'agentmgr'>('creator');
  const [targetAgentMgr, setTargetAgentMgr] = useState('Rachel Sterling (Senior Agent Manager)');
  const [agentNote, setAgentNote] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      const bName = (currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.brandName : brandName;
      const cGoals = (currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.goals : campaignGoals;
      const sGuide = (currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.styleGuidelines : styleGuidelines;
      const rHooks = (currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.hooks : requiredHooks;
      const cLegal = (currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.contractLegalText : contractLegalText;
      const bNiche = (currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.niche : niche;

      await exportCreativeBriefPDF({
        brandName: bName,
        campaignGoals: cGoals,
        styleGuidelines: sGuide,
        requiredHooks: rHooks,
        contractLegalText: cLegal,
        niche: bNiche
      });
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3500);
    } catch (err) {
      console.error('PDF export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handlePassBriefToCreator = async (force: boolean = false) => {
    console.log('[CreativeBriefingStudio] handlePassBriefToCreator invoked:', {
      alreadyReceivedRecord,
      force,
      selectedCreatorHandle,
      currentRole,
      isAgentMgrRole
    });
    if (alreadyReceivedRecord && !force) {
      console.log('[CreativeBriefingStudio] Duplicate warning modal shown');
      setShowDuplicateWarningModal(true);
      return;
    }
    const targetCreatorHandle = selectedCreatorHandle || '@alexjones';
    const activeB: any = activeBrief || APPROVED_BRIEFS[0] || {};
    const targetBrand = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.brandName || brandName) : brandName;
    const targetGoals = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.goals || campaignGoals) : campaignGoals;
    const targetGuidelines = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.styleGuidelines || styleGuidelines) : styleGuidelines;
    const targetHooks = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.hooks || requiredHooks) : requiredHooks;
    const targetLegal = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.contractLegalText || contractLegalText) : contractLegalText;
    const targetNiche = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.niche || niche) : niche;
    const targetPayout = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.payout || '$3,500 Escrow Payout') : '$3,500 Escrow Payout';

    const newBrief = {
      id: 'brief_' + Date.now(),
      creatorHandle: targetCreatorHandle,
      brandName: targetBrand,
      niche: targetNiche,
      campaignGoals: targetGoals,
      styleGuidelines: targetGuidelines,
      requiredHooks: targetHooks,
      contractLegalText: targetLegal,
      agentNote: agentNote.trim(),
      passedBy: currentUser?.name || 'Agent Manager / Director',
      sentAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      status: 'Passed to Creator (Pending Acceptance)'
    };

    console.log('[CreativeBriefingStudio] Created brief payload:', newBrief);

    try {
      const legacyBriefId = 'brief_' + Date.now();
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
      await setDoc(doc(db, 'studio-briefs', legacyBriefId), {
        brand: targetBrand,
        brandName: targetBrand,
        title: `${targetBrand} - Creative Brief`,
        creatorHandle: targetCreatorHandle,
        briefContent: targetGoals,
        campaignGoals: targetGoals,
        deliverables: '1x UGC Video + Paid Usage Rights',
        keyHooks: [targetHooks],
        requiredHooks: targetHooks,
        styleGuidelines: targetGuidelines,
        contractLegalText: targetLegal,
        agentNote: agentNote.trim(),
        sentAt: new Date().toISOString(),
        status: 'Sent',
        payout: targetPayout,
        niche: targetNiche,
        passedBy: currentUser?.name || 'Agent Manager / Director',
        tenantId: userPod,
        subagency: userPod,
        pod: userPod
      });
      console.log('[CreativeBriefingStudio] Firestore writes succeeded for brief to creator');
    } catch (error) {
      console.warn("Firestore brief write notification:", error);
    }

    try {
      const existing = safeStorage.getItem('wl_creator_briefs');
      const list = existing ? JSON.parse(existing) : [];
      safeStorage.setItem('wl_creator_briefs', JSON.stringify([newBrief, ...list]));
      console.log('[CreativeBriefingStudio] Updated wl_creator_briefs in storage');
    } catch (e) {
      console.error('[CreativeBriefingStudio] Error saving to storage wl_creator_briefs:', e);
    }

    const newDispatchRecord = {
      id: 'dispatch-' + Date.now(),
      brand: targetBrand,
      creator: targetCreatorHandle,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      status: 'Passed to Creator (Pending Review)',
      note: agentNote.trim() || undefined
    };

    const updatedDispatches = [newDispatchRecord, ...dispatchedBriefs];
    setDispatchedBriefs(updatedDispatches);
    try {
      safeStorage.setItem('agent_dispatched_briefs', JSON.stringify(updatedDispatches));
    } catch {}

    setSendSuccess(true);
    setAgentNote('');
    setTimeout(() => setSendSuccess(false), 4500);

    if (triggerNotification) {
      triggerNotification('Brief Passed to Creator', `Creative Brief for ${targetBrand} reviewed and passed to ${targetCreatorHandle}.`, 'success');
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Reviewed and passed Creative Brief (${targetBrand}) to ${targetCreatorHandle}`);
    }
  };

  const handlePassBriefToAgent = async () => {
    console.log('[CreativeBriefingStudio] handlePassBriefToAgent invoked');
    const targetAgent = targetAgentMgr || 'Marcus Cole (Head Talent Agent)';
    const activeB: any = activeBrief || APPROVED_BRIEFS[0] || {};
    const targetBrand = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.brandName || brandName) : brandName;
    const targetGoals = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.goals || campaignGoals) : campaignGoals;
    const targetGuidelines = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.styleGuidelines || styleGuidelines) : styleGuidelines;
    const targetHooks = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.hooks || requiredHooks) : requiredHooks;
    const targetLegal = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.contractLegalText || contractLegalText) : contractLegalText;
    const targetNiche = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.niche || niche) : niche;
    const targetPayout = (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) ? (activeB.payout || '$3,500 Escrow Payout') : '$3,500 Escrow Payout';

    const newAgentDispatch = {
      id: 'brief_agent_' + Date.now(),
      targetAgent,
      brandName: targetBrand,
      niche: targetNiche,
      campaignGoals: targetGoals,
      styleGuidelines: targetGuidelines,
      requiredHooks: targetHooks,
      contractLegalText: targetLegal,
      agentNote: agentNote.trim(),
      passedBy: currentUser?.name || 'Agent Manager / Director',
      sentAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      status: `Passed to Agent (${targetAgent})`
    };

    console.log('[CreativeBriefingStudio] Created agent dispatch payload:', newAgentDispatch);

    try {
      const legacyBriefId = 'brief_ag_' + Date.now();
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
      await setDoc(doc(db, 'studio-briefs', legacyBriefId), {
        brand: targetBrand,
        brandName: targetBrand,
        title: `${targetBrand} - Agent Delegated Brief`,
        targetAgent,
        briefContent: targetGoals,
        campaignGoals: targetGoals,
        deliverables: '1x UGC Video + Paid Usage Rights',
        keyHooks: [targetHooks],
        requiredHooks: targetHooks,
        styleGuidelines: targetGuidelines,
        contractLegalText: targetLegal,
        agentNote: agentNote.trim(),
        sentAt: new Date().toISOString(),
        status: 'PassedToAgent',
        payout: targetPayout,
        niche: targetNiche,
        passedBy: currentUser?.name || 'Agent Manager / Director',
        tenantId: userPod,
        subagency: userPod,
        pod: userPod
      });
      console.log('[CreativeBriefingStudio] Firestore writes succeeded for brief to agent');
    } catch (error) {
      console.warn("Firestore agent brief write notification:", error);
    }

    try {
      const existing = safeStorage.getItem('wl_agent_briefs');
      const list = existing ? JSON.parse(existing) : [];
      safeStorage.setItem('wl_agent_briefs', JSON.stringify([newAgentDispatch, ...list]));
      console.log('[CreativeBriefingStudio] Updated wl_agent_briefs in storage');
    } catch (e) {
      console.error('[CreativeBriefingStudio] Error saving to storage wl_agent_briefs:', e);
    }

    const newDispatchRecord = {
      id: 'dispatch-ag-' + Date.now(),
      brand: targetBrand,
      creator: `Agent: ${targetAgent.split(' ')[0]}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      status: `Passed to Agent (${targetAgent.split(' ')[0]})`,
      note: agentNote.trim() || undefined
    };

    const updatedDispatches = [newDispatchRecord, ...dispatchedBriefs];
    setDispatchedBriefs(updatedDispatches);
    try {
      safeStorage.setItem('agent_dispatched_briefs', JSON.stringify(updatedDispatches));
    } catch {}

    setSendSuccess(true);
    setAgentNote('');
    setTimeout(() => setSendSuccess(false), 4500);

    if (triggerNotification) {
      triggerNotification('Brief Passed to Agent', `Creative Brief for ${targetBrand} passed to ${targetAgent}.`, 'success');
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || 'Agent Manager', currentRole || 'agentmgr', `Reviewed and passed Creative Brief (${targetBrand}) to Agent ${targetAgent}`);
    }
  };

  // AGENT & AGENT MANAGER REVIEW & PASS ON VIEW
  if (currentRole === 'agent' || currentRole === 'agentmgr' || isAgentMgrRole) {
    const selectedCreatorObj = creators.find(c => c.handle === selectedCreatorHandle);

    return (
      <div className="space-y-6 max-w-5xl mx-auto pb-12">
        {/* Top Header Card */}
        <div className="bg-[#152238] border border-[#233554] rounded-2xl p-6 shadow-xl relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#c7a77d]/15 text-[#c7a77d] border border-[#c7a77d]/30">
                  <FileText className="w-3.5 h-3.5" />
                  Agent Creative Brief Desk
                </span>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-500/30">
                  ✓ Director Approved Spec
                </span>
              </div>
              <h2 className="text-2xl font-bold text-white tracking-tight">
                Review &amp; Pass Creative Briefs to Creators
              </h2>
              <p className="text-xs text-[#6b7c96] max-w-2xl leading-relaxed">
                Review the campaign objectives, required hooks, style guidelines, and compliance terms approved by the Director, then pass the brief directly to your assigned creators.
              </p>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={handleExportPDF}
                disabled={isExporting}
                className="px-4 py-2.5 rounded-xl bg-[#0f1a2c] hover:bg-[#1a2c47] border border-[#233554] text-xs font-semibold text-[#e2e8f0] transition-colors flex items-center gap-2 cursor-pointer shadow-sm disabled:opacity-50"
              >
                <Download className="w-4 h-4 text-[#c7a77d]" />
                <span>{isExporting ? 'Exporting...' : 'Export Brief PDF'}</span>
              </button>
            </div>
          </div>

          {exportSuccess && (
            <div className="mt-4 p-3 bg-emerald-950/70 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>✓ Official Creative Brief PDF generated and ready for client or talent delivery!</span>
            </div>
          )}

          {sendSuccess && (
            <div className="mt-4 p-3.5 bg-emerald-950/90 border border-emerald-500/60 rounded-xl text-emerald-200 text-xs flex items-center gap-2 animate-fade-in shadow-lg">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                ✓ Creative brief successfully passed on to <strong>{selectedCreatorHandle}</strong>'s portal and logged to campaign records!
              </span>
            </div>
          )}
        </div>

        {/* 1. Approved Brief Selection Ribbon */}
        <div className="bg-[#152238] border border-[#233554] rounded-2xl p-5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#c7a77d] uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              1. Select Approved Campaign Brief (From Director)
            </span>
            <span className="text-[11px] text-[#6b7c96]">
              {APPROVED_BRIEFS.length} campaigns ready for dispatch
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {APPROVED_BRIEFS.map((b, idx) => {
              const isSelected = selectedBriefIndex === idx;
              return (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setSelectedBriefIndex(idx)}
                  className={`p-4 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    isSelected
                      ? 'bg-[#1a2c47] border-[#c7a77d] ring-1 ring-[#c7a77d]/40 shadow-md'
                      : 'bg-[#0f1a2c] border-[#233554] hover:border-[#384f73] opacity-80 hover:opacity-100'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{b.brandName}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#c7a77d]/20 text-[#c7a77d] font-semibold">
                        {b.niche}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 font-medium line-clamp-1">{b.campaignTitle}</p>
                    <p className="text-[10px] text-[#6b7c96] line-clamp-2">{b.goals}</p>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-emerald-400">{b.payout}</span>
                    <span className="text-[10px] text-[#6b7c96]">{b.deadline}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Brief Details Review & Pass On Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Detailed Brief Review */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-[#152238] border border-[#233554] rounded-2xl p-6 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-[#0f1a2c] border border-[#233554] flex items-center justify-center text-[#c7a77d] font-bold text-sm">
                    {activeBrief.brandName.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">{activeBrief.brandName}</h3>
                    <p className="text-xs text-[#6b7c96]">{activeBrief.campaignTitle}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-emerald-400 block">{activeBrief.payout}</span>
                  <span className="text-[10px] text-slate-400">{activeBrief.deadline}</span>
                </div>
              </div>

              {/* Objectives & Deliverables */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-[#c7a77d] flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  Campaign Objectives &amp; Deliverables
                </label>
                <div className="p-3.5 rounded-xl bg-[#0f1a2c] border border-[#233554] text-xs text-slate-200 leading-relaxed">
                  <p className="mb-2">{activeBrief.goals}</p>
                  <div className="pt-2 border-t border-white/5 flex items-center gap-2 text-[11px] text-amber-300 font-medium">
                    <span>📦 Deliverables:</span>
                    <span>{activeBrief.deliverables}</span>
                  </div>
                </div>
              </div>

              {/* Hook & Visual Guidelines */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-[#c7a77d] flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  Mandatory Visual Hook (Seconds 0-3)
                </label>
                <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-xs text-amber-200 leading-relaxed font-mono">
                  {activeBrief.hooks}
                </div>
              </div>

              {/* Style & Aesthetic Rules */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-[#c7a77d] flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  Style &amp; Lighting Guidelines
                </label>
                <div className="p-3.5 rounded-xl bg-[#0f1a2c] border border-[#233554] text-xs text-slate-300 leading-relaxed">
                  {activeBrief.styleGuidelines}
                </div>
              </div>

              {/* FTC & Legal Safeguards */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-[#c7a77d] flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  FTC Compliance &amp; Legal Terms
                </label>
                <div className="p-3.5 rounded-xl bg-[#0f1a2c] border border-[#233554] text-[11px] text-slate-400 space-y-1.5">
                  <p className="text-slate-200">⚖️ {activeBrief.ftcCompliance}</p>
                  <p className="text-[10px] text-[#6b7c96]">30-Day organic &amp; paid whitelisting rights included upon delivery.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Creator / Agent Target Selection & Pass-On Control */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-[#152238] border border-[#233554] rounded-2xl p-6 shadow-xl space-y-5">
              <div className="border-b border-white/10 pb-3">
                <span className="text-xs font-bold text-[#c7a77d] uppercase tracking-wider flex items-center gap-2">
                  <UserCheck className="w-4 h-4" />
                  2. Route &amp; Pass Brief
                </span>
                <p className="text-[11px] text-[#6b7c96] mt-0.5">
                  Receive brief from Director and pass it to an agent or creator.
                </p>
              </div>

              {/* Route Selector Toggle */}
              <div className="grid grid-cols-2 gap-2 bg-[#0f1a2c] p-1.5 rounded-xl border border-[#233554]">
                <button
                  type="button"
                  onClick={() => setRecipientTarget('creator')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    recipientTarget === 'creator'
                      ? 'bg-[#1a2c47] text-[#c7a77d] border border-[#c7a77d]/40 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Pass to Creator</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRecipientTarget('agentmgr')}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    recipientTarget === 'agentmgr'
                      ? 'bg-[#1a2c47] text-[#c7a77d] border border-[#c7a77d]/40 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Award className="w-3.5 h-3.5" />
                  <span>Pass to Agent</span>
                </button>
              </div>

              {/* Creator Selector Mode */}
              {recipientTarget === 'creator' ? (
                <>
                  {/* Selector Type Toggle: Roster vs Contracted Deal */}
                  <div className="flex items-center gap-1.5 p-1 bg-[#091122] rounded-lg border border-white/10 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setCreatorSelectMode('roster')}
                      className={`flex-1 py-1.5 px-2 rounded-md font-semibold transition cursor-pointer ${
                        creatorSelectMode === 'roster'
                          ? 'bg-[#1a2c47] text-white border border-[#c7a77d]/30'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Roster Creator
                    </button>
                    <button
                      type="button"
                      onClick={() => setCreatorSelectMode('contract')}
                      className={`flex-1 py-1.5 px-2 rounded-md font-semibold transition cursor-pointer ${
                        creatorSelectMode === 'contract'
                          ? 'bg-[#1a2c47] text-[#c7a77d] border border-[#c7a77d]/30'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Brand Contract Deal
                    </button>
                  </div>

                  {creatorSelectMode === 'contract' ? (
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-white">Select Active Brand Contract</label>
                      <select
                        value={selectedContractDealId}
                        onChange={(e) => {
                          const dId = e.target.value;
                          setSelectedContractDealId(dId);
                          const chosenDeal = (deals || []).find(d => String(d.id) === String(dId));
                          if (chosenDeal) {
                            const handleVal = chosenDeal.creatorHandle || chosenDeal.creator || '@alexjones';
                            setSelectedCreatorHandle(handleVal);
                            if (chosenDeal.brand) setBrandName(chosenDeal.brand);
                            if (chosenDeal.description || chosenDeal.title) {
                              setCampaignGoals(chosenDeal.description || chosenDeal.title);
                            }
                            if (chosenDeal.category || chosenDeal.niche) {
                              const nVal = chosenDeal.category || chosenDeal.niche;
                              if (['Pets', 'Beauty', 'Lifestyle'].includes(nVal)) {
                                setNiche(nVal as any);
                              }
                            }
                          }
                        }}
                        className="w-full bg-[#0f1a2c] border border-[#233554] focus:border-[#c7a77d] rounded-xl px-3.5 py-3 text-xs text-white font-medium outline-none cursor-pointer"
                      >
                        <option value="">-- Choose Brand Contract Deal --</option>
                        {(deals || []).map((d: any) => (
                          <option key={d.id} value={d.id}>
                            {d.brand} — {d.title || 'Brand Deal'} (Creator: {d.creatorHandle || d.creator || 'Assigned'})
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-white">Target Creator</label>
                      <select
                        value={selectedCreatorHandle}
                        onChange={(e) => setSelectedCreatorHandle(e.target.value)}
                        className="w-full bg-[#0f1a2c] border border-[#233554] focus:border-[#c7a77d] rounded-xl px-3.5 py-3 text-xs text-white font-medium outline-none cursor-pointer"
                      >
                        {creators.length > 0 ? (
                          creators.map(c => (
                            <option key={c.id || c.handle} value={c.handle}>
                              {c.name} ({c.handle}) — {c.niche || 'Beauty/Lifestyle'}
                            </option>
                          ))
                        ) : (
                          <>
                            <option value="@alexjones">Alex Jones (@alexjones) — Beauty</option>
                            <option value="@sophiaglows">Sophia Chen (@sophiaglows) — Skincare</option>
                            <option value="@marcusfit">Marcus Vance (@marcusfit) — Fitness</option>
                          </>
                        )}
                      </select>
                    </div>
                  )}

                  {/* Selected Creator Snapshot */}
                  <div className="p-3.5 rounded-xl bg-[#0f1a2c] border border-[#233554] flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-[#1a2c47] border border-[#384f73] flex items-center justify-center text-white font-bold text-xs">
                        {(selectedCreatorObj?.name || selectedCreatorHandle.replace('@', ''))[0]?.toUpperCase()}
                      </div>
                      <div>
                        <span className="font-semibold text-white block">
                          {selectedCreatorObj?.name || selectedCreatorHandle}
                        </span>
                        <span className="text-[10px] text-[#c7a77d]">{selectedCreatorHandle}</span>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-500/30">
                      98% Niche Match
                    </span>
                  </div>

                  {alreadyReceivedRecord && (
                    <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-1 animate-fade-in">
                      <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Brief Record Dispatched Previously</span>
                      </div>
                      <p className="text-[10px] text-amber-200/90 leading-relaxed">
                        Previously sent to {selectedCreatorHandle} by {alreadyReceivedRecord.passedBy} on {alreadyReceivedRecord.date}. You can pass an updated copy below.
                      </p>
                    </div>
                  )}
                </>
              ) : (
                /* Agent Selector Mode */
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-white">Target Agent / Talent Lead</label>
                    <select
                      value={targetAgentMgr}
                      onChange={(e) => setTargetAgentMgr(e.target.value)}
                      className="w-full bg-[#0f1a2c] border border-[#233554] focus:border-[#c7a77d] rounded-xl px-3.5 py-3 text-xs text-white font-medium outline-none cursor-pointer"
                    >
                      <option value="Marcus Cole (Head Talent Agent)">Marcus Cole (Head Talent Agent)</option>
                      <option value="Elena Rostova (Fashion & Beauty Agent)">Elena Rostova (Fashion & Beauty Agent)</option>
                      <option value="David Kim (Tech & UGC Lead)">David Kim (Tech & UGC Lead)</option>
                      <option value="Sarah Jenkins (Lifestyle Agent)">Sarah Jenkins (Lifestyle Agent)</option>
                      <option value="Alex Vance (Junior Coordinator)">Alex Vance (Junior Coordinator)</option>
                    </select>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#0f1a2c] border border-[#233554] flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-[#1a2c47] border border-[#384f73] flex items-center justify-center text-[#c7a77d] font-bold text-xs">
                        {targetAgentMgr[0]}
                      </div>
                      <div>
                        <span className="font-semibold text-white block">{targetAgentMgr.split(' (')[0]}</span>
                        <span className="text-[10px] text-[#6b7c96]">{targetAgentMgr.split('(')[1]?.replace(')', '') || 'Agent'}</span>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-950/80 text-sky-400 border border-sky-500/30">
                      Active Staff
                    </span>
                  </div>
                </div>
              )}

              {/* Optional Agent Coaching Note */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-[#c7a77d]" />
                  Agent Coaching Note / Instructions (Optional)
                </label>
                <textarea
                  rows={3}
                  value={agentNote}
                  onChange={(e) => setAgentNote(e.target.value)}
                  placeholder="e.g. Hey! Make sure to capture the morning sun light on the bottle dropper in the first 3 seconds."
                  className="w-full bg-[#0f1a2c] border border-[#233554] focus:border-[#c7a77d] rounded-xl p-3 text-xs text-white placeholder:text-slate-500 outline-none resize-none leading-relaxed"
                />
              </div>

              {/* Pass Brief CTA Button - Always interactive */}
              <button
                type="button"
                id="btn-pass-brief-cta"
                onClick={() => setShowPreviewModal(true)}
                className={`w-full py-3.5 rounded-xl text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                  recipientTarget === 'agentmgr'
                    ? 'bg-gradient-to-r from-[#c7a77d] to-amber-500 hover:from-amber-400 hover:to-[#c7a77d]'
                    : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 shadow-emerald-500/20'
                }`}
              >
                <Eye className="w-4 h-4" />
                <span>
                  {recipientTarget === 'agentmgr'
                    ? `Preview & Pass Brief to ${targetAgentMgr.split(' ')[0]}`
                    : alreadyReceivedRecord
                    ? `Preview & Resend Brief to ${selectedCreatorHandle}`
                    : `Preview & Pass Brief to ${selectedCreatorHandle}`}
                </span>
              </button>

              <div className="text-[11px] text-[#6b7c96] flex items-center gap-2 bg-[#0f1a2c]/60 p-3 rounded-xl border border-white/5">
                <Info className="w-4 h-4 text-[#c7a77d] shrink-0" />
                <span>
                  {recipientTarget === 'agentmgr'
                    ? 'Passing to an agent delegates execution and talent follow-up to their management queue.'
                    : "Passing this brief will immediately sync deliverables and compensation to the creator's portal."}
                </span>
              </div>
            </div>

            {/* Dispatched History Card */}
            <div className="bg-[#152238] border border-[#233554] rounded-2xl p-5 shadow-lg space-y-3">
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#c7a77d]" />
                  Recently Passed Briefs
                </span>
                <span className="text-[10px] text-[#6b7c96]">{dispatchedBriefs.length} logged</span>
              </div>

              <div className="space-y-2">
                {dispatchedBriefs.slice(0, 3).map(item => (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-[#0f1a2c] border border-[#233554] text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-white">{item.brand}</span>
                      <span className="text-[10px] text-[#6b7c96]">{item.date}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-[#c7a77d] font-mono">{item.creator}</span>
                      <span className="text-[10px] text-emerald-400">{item.status}</span>
                    </div>
                    {item.note && (
                      <p className="text-[10px] text-slate-400 italic pt-1 border-t border-white/5">
                        "{item.note}"
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        {/* Duplicate Warning Modal */}
        {showDuplicateWarningModal && alreadyReceivedRecord && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[#152238] border border-amber-500/40 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-slate-100">
              <div className="flex items-center gap-3 border-b border-white/10 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Creator Already Received Brief</h3>
                  <p className="text-xs text-[#6b7c96]">Preventing duplicate dispatch notices</p>
                </div>
              </div>

              <div className="bg-[#0f1a2c] p-3.5 rounded-xl border border-white/5 space-y-2 text-xs">
                <p className="text-slate-200">
                  <strong>{selectedCreatorHandle}</strong> was already sent the <strong>{activeBrief.brandName}</strong> creative brief on <strong>{alreadyReceivedRecord.date}</strong> by <strong>{alreadyReceivedRecord.passedBy}</strong>.
                </p>
                <p className="text-[#6b7c96] text-[11px]">
                  Resending will dispatch another notification to the talent. Only resend if you have significant brief changes or special instructions.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowDuplicateWarningModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-[#0f1a2c] border border-[#233554] cursor-pointer"
                >
                  Cancel (Keep Existing)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowDuplicateWarningModal(false);
                    handlePassBriefToCreator(true);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 shadow-md cursor-pointer"
                >
                  Resend Updated Brief
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // DIRECTOR / FULL STUDIO MODE
  return (
    <div className="bg-[#0B1B3D] border border-[#233554] rounded-3xl p-6 shadow-2xl text-slate-100 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-[#D4AF37] bg-[#142850] border border-[#D4AF37]/30 px-3 py-0.5 rounded-full">
              Creative Briefing Studio
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Director Master Compiler
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white mt-1.5">
            Campaign Creative Brief &amp; Deliverable Compiler
          </h2>
          <p className="text-xs text-slate-400">
            Compile visual style guidelines, hooks, and legal contracts into a client-ready white-paper PDF or pass to creator.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Director Switch: Agent Manager Brief Drafting Control */}
          <div className="flex items-center gap-2 bg-[#142850] border border-[#D4AF37]/30 px-3 py-2 rounded-xl text-xs">
            <span className="text-[10px] font-mono text-slate-300">Agent Mgr Draft Switch:</span>
            <button
              type="button"
              id="switch-director-agent-draft-briefs"
              onClick={() => {
                const updated = {
                  ...delegationSettings,
                  agentManagerCanDraftBriefs: !delegationSettings.agentManagerCanDraftBriefs
                };
                setDelegationSettings(updated);
                saveStoredDirectorDelegation(updated);
                if (triggerNotification) {
                  triggerNotification(
                    'Director Brief Access Updated',
                    `Agent Manager Brief Drafting is now ${updated.agentManagerCanDraftBriefs ? 'ENABLED' : 'DISABLED'}.`,
                    updated.agentManagerCanDraftBriefs ? 'success' : 'warning'
                  );
                }
              }}
              className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition cursor-pointer ${
                delegationSettings.agentManagerCanDraftBriefs ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-300'
              }`}
              title="Toggle whether Agent Managers have access to draft briefs"
            >
              {delegationSettings.agentManagerCanDraftBriefs ? 'Allowed' : 'Locked'}
            </button>
          </div>

          <button
            type="button"
            onClick={handleGenerateTrendAI}
            disabled={isGeneratingTrendAI}
            className="inline-flex items-center gap-2 bg-[#142850] hover:bg-[#1a2c47] border border-[#D4AF37]/50 text-xs font-semibold text-[#D4AF37] px-4 py-2.5 rounded-xl shadow transition-all cursor-pointer"
          >
            <Globe className={`w-4 h-4 text-[#D4AF37] ${isGeneratingTrendAI ? 'animate-spin' : ''}`} />
            <span>{isGeneratingTrendAI ? 'Searching TikTok & IG Trends...' : '✨ AI Trend Brief (Google Grounding)'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowPreviewModal(true)}
            className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg transition-all cursor-pointer"
          >
            <Eye className="w-4 h-4" />
            <span>Preview &amp; Send Brief...</span>
          </button>

          <button
            type="button"
            onClick={handleExportPDF}
            disabled={isExporting}
            className="inline-flex items-center gap-2 bg-[#142850] hover:bg-[#1a2c47] border border-[#233554] text-xs font-semibold text-white px-4 py-2.5 rounded-xl shadow transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#D4AF37]" />
            <span>{isExporting ? 'Compiling PDF...' : 'Download PDF Spec'}</span>
          </button>
        </div>
      </div>

      {sendSuccess && (
        <div className="p-4 bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs rounded-2xl flex items-center gap-3 animate-fade-in shadow-xl">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <strong className="font-semibold text-white block">Brief Dispatched to Talent!</strong>
            Creative Brief generated and passed to {selectedCreatorHandle} for {brandName}.
          </div>
        </div>
      )}

      {exportSuccess && (
        <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs rounded-xl flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>✓ Creative Brief PDF successfully compiled and downloaded.</span>
        </div>
      )}

      {/* Form Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#D4AF37]">Brand / Campaign Entity</label>
            <input
              type="text"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              className="w-full bg-[#142850] border border-white/10 focus:border-[#D4AF37] rounded-xl px-3.5 py-2.5 text-xs text-white font-mono outline-none"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-[#D4AF37]">Campaign Vertical (Niche)</label>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-slate-400">
                  Google Search Grounding: <strong className={useGrounding ? "text-[#D4AF37]" : "text-slate-500"}>{useGrounding ? "ON" : "OFF"}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setUseGrounding(!useGrounding)}
                  className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer p-0.5 ${
                    useGrounding ? 'bg-[#D4AF37]' : 'bg-[#142850] border border-white/20'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                      useGrounding ? 'translate-x-4 bg-slate-950' : 'translate-x-0 bg-slate-300'
                    }`}
                  />
                </button>
              </div>
            </div>
            <select
              value={niche}
              onChange={(e) => {
                const newNiche = e.target.value as any;
                setNiche(newNiche);
                // Automated Legal Appender
                if (newNiche === 'Beauty') {
                  setContractLegalText(`BLOOM STUDIO 1099 TALENT DELIVERABLE AGREEMENT - BEAUTY & SKINCARE\n1. SCOPE OF WORK: 1x 60s TikTok UGC Video + 1x Instagram Reel with skin texture closeups.\n2. FTC COMPLIANCE: Conspicuous #ad disclosure within first 3 seconds.\n3. FINANCIAL ALLOCATION: Escrow settlement of $3,500 upon approval.\n4. USAGE RIGHTS: 30-day paid digital whitelisting.`);
                } else if (newNiche === 'Pets') {
                  setContractLegalText(`BLOOM STUDIO 1099 TALENT DELIVERABLE AGREEMENT - PET CARE\n1. SCOPE OF WORK: 2x 45s TikTok UGC Videos + dog interaction B-roll.\n2. FTC COMPLIANCE: Clear #ad tag in video and caption.\n3. FINANCIAL ALLOCATION: $2,800 Escrow Payout.\n4. USAGE RIGHTS: Full brand organic social usage.`);
                } else if (newNiche === 'Lifestyle') {
                  setContractLegalText(`BLOOM STUDIO 1099 TALENT DELIVERABLE AGREEMENT - LIFESTYLE & WELLNESS\n1. SCOPE OF WORK: 1x 30s Reel + 3x Story Slides.\n2. FTC COMPLIANCE: Clear #ad tag above the fold.\n3. FINANCIAL ALLOCATION: $4,200 Escrow Payout.\n4. USAGE RIGHTS: 60-day digital advertising rights.`);
                }
              }}
              className="w-full bg-[#142850] border border-white/10 focus:border-[#D4AF37] rounded-xl px-3.5 py-2.5 text-xs text-white font-mono outline-none cursor-pointer"
            >
              <option value="Beauty">Beauty &amp; Skincare</option>
              <option value="Pets">Pets &amp; Pet Care</option>
              <option value="Lifestyle">Lifestyle &amp; Wellness</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#D4AF37]">Target Creator (Talent Roster)</label>
            <select
              value={selectedCreatorHandle}
              onChange={(e) => setSelectedCreatorHandle(e.target.value)}
              className="w-full bg-[#142850] border border-white/10 focus:border-[#D4AF37] rounded-xl px-3.5 py-2.5 text-xs text-white font-mono outline-none cursor-pointer"
            >
              {creators.length > 0 ? (
                creators.map(c => (
                  <option key={c.id || c.handle} value={c.handle}>
                    {c.name} ({c.handle}) — {c.niche || 'Beauty'}
                  </option>
                ))
              ) : (
                <>
                  <option value="@alexjones">Alex Jones (@alexjones)</option>
                  <option value="@sophiaglows">Sophia Chen (@sophiaglows)</option>
                </>
              )}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#D4AF37]">Campaign Goals &amp; Deliverables</label>
            <textarea
              rows={3}
              value={campaignGoals}
              onChange={(e) => setCampaignGoals(e.target.value)}
              className="w-full bg-[#142850] border border-white/10 focus:border-[#D4AF37] rounded-xl p-3 text-xs text-white font-mono outline-none resize-none"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#D4AF37]">Visual &amp; Style Guidelines</label>
            <textarea
              rows={3}
              value={styleGuidelines}
              onChange={(e) => setStyleGuidelines(e.target.value)}
              className="w-full bg-[#142850] border border-white/10 focus:border-[#D4AF37] rounded-xl p-3 text-xs text-white font-mono outline-none resize-none mb-2"
            />
            {/* SceneBlueprint Sub-Grid */}
            <div className="p-3 bg-[#142850] border border-white/10 rounded-xl space-y-2">
              <span className="text-[10px] font-mono font-bold text-[#D4AF37] uppercase tracking-wider block">
                🎬 SceneBlueprint Timeline Assembly
              </span>
              <div className="grid grid-cols-2 gap-2">
                <div className="p-2 rounded-lg bg-[#0B1B3D] border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold text-amber-400 font-mono">0-3s (Hook)</span>
                  <p className="text-[10px] text-slate-300 leading-tight">Attention grabber &amp; bold hook text.</p>
                </div>
                <div className="p-2 rounded-lg bg-[#0B1B3D] border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold text-sky-400 font-mono">3-15s (Problem)</span>
                  <p className="text-[10px] text-slate-300 leading-tight">Relatable pain point or challenge.</p>
                </div>
                <div className="p-2 rounded-lg bg-[#0B1B3D] border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold text-emerald-400 font-mono">15-45s (Solution)</span>
                  <p className="text-[10px] text-slate-300 leading-tight">Product demonstration &amp; results.</p>
                </div>
                <div className="p-2 rounded-lg bg-[#0B1B3D] border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold text-purple-400 font-mono">45-60s (CTA)</span>
                  <p className="text-[10px] text-slate-300 leading-tight">Link in bio &amp; discount code mention.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#D4AF37]">Mandatory Hook Directives (0-3s)</label>
            {/* Script Hook Shortcuts */}
            <div className="flex items-center gap-2 flex-wrap mb-1.5">
              <button
                type="button"
                onClick={() => setRequiredHooks('Visual hook (0-3s): "I tested this viral botanical serum for 7 days and my skin texture completely transformed..."')}
                className="text-[10px] font-mono px-2.5 py-1 rounded-lg border border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37]/15 transition-colors cursor-pointer"
              >
                + Skincare Hook
              </button>
              <button
                type="button"
                onClick={() => setRequiredHooks('Visual hook (0-3s): "Stop giving your dog plain water during summer walks until you try this..."')}
                className="text-[10px] font-mono px-2.5 py-1 rounded-lg border border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37]/15 transition-colors cursor-pointer"
              >
                + Pet Hook
              </button>
              <button
                type="button"
                onClick={() => setRequiredHooks('Visual hook (0-3s): "Finally found workout sets that don\'t roll down during pilates..."')}
                className="text-[10px] font-mono px-2.5 py-1 rounded-lg border border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37]/15 transition-colors cursor-pointer"
              >
                + Lifestyle Hook
              </button>
            </div>
            <textarea
              rows={3}
              value={requiredHooks}
              onChange={(e) => setRequiredHooks(e.target.value)}
              className="w-full bg-[#142850] border border-white/10 focus:border-[#D4AF37] rounded-xl p-3 text-xs text-white font-mono outline-none resize-none"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#D4AF37]">Deliverable Contract Terms</label>
            <textarea
              rows={3}
              value={contractLegalText}
              onChange={(e) => setContractLegalText(e.target.value)}
              className="w-full bg-[#142850] border border-white/10 focus:border-[#D4AF37] rounded-xl p-3 text-[11px] text-white font-mono outline-none resize-none"
            />
          </div>
        </div>
      </div>

      {/* Brief Preview & Routing Modal */}
      {showPreviewModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B1B3D] border border-[#D4AF37]/50 rounded-3xl max-w-2xl w-full p-6 space-y-5 shadow-2xl animate-fade-in text-slate-100 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#142850] border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shrink-0">
                  <Eye className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-lg text-white">Pre-Dispatch Brief Review &amp; Routing</h3>
                  <p className="text-xs text-slate-400">Inspect the compiled white-paper spec and choose recipient route</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPreviewModal(false)}
                className="w-8 h-8 rounded-full bg-[#142850] hover:bg-[#1a2c47] text-slate-300 hover:text-white flex items-center justify-center text-sm font-bold cursor-pointer transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Recipient Routing Option */}
            <div className="bg-[#142850] p-4 rounded-2xl border border-white/10 space-y-3">
              <label className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider block">
                Select Dispatch Route
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRecipientTarget('creator')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                    recipientTarget === 'creator'
                      ? 'bg-[#0B1B3D] border-[#D4AF37] text-white shadow-md'
                      : 'bg-[#0B1B3D]/60 border-white/10 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserCheck className={`w-5 h-5 ${recipientTarget === 'creator' ? 'text-[#D4AF37]' : 'text-slate-500'}`} />
                  <div>
                    <span className="font-semibold text-xs block text-white">Direct to Creator</span>
                    <span className="text-[10px] text-slate-400">Send to {selectedCreatorHandle} portal</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setRecipientTarget('agentmgr')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                    recipientTarget === 'agentmgr'
                      ? 'bg-[#0B1B3D] border-[#D4AF37] text-white shadow-md'
                      : 'bg-[#0B1B3D]/60 border-white/10 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Award className={`w-5 h-5 ${recipientTarget === 'agentmgr' ? 'text-[#D4AF37]' : 'text-slate-500'}`} />
                  <div>
                    <span className="font-semibold text-xs block text-white">Pass to Agent / Manager</span>
                    <span className="text-[10px] text-slate-400">Review via management queue</span>
                  </div>
                </button>
              </div>

              {recipientTarget === 'agentmgr' && (
                <div className="pt-2 space-y-1.5 animate-fade-in">
                  <label className="text-[11px] font-semibold text-slate-300">Target Managing Agent or Lead:</label>
                  <select
                    value={targetAgentMgr}
                    onChange={(e) => setTargetAgentMgr(e.target.value)}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none cursor-pointer"
                  >
                    <option value="Rachel Sterling (Senior Agent Manager)">Rachel Sterling (Senior Agent Manager)</option>
                    <option value="Marcus Cole (Head Talent Agent)">Marcus Cole (Head Talent Agent)</option>
                    <option value="Alex Vance (Coordinator Review)">Alex Vance (Coordinator Review)</option>
                  </select>
                </div>
              )}
            </div>

            {/* Compiled Brief Preview Card */}
            <div className="bg-[#142850] border border-white/10 rounded-2xl p-4 space-y-3 text-xs">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="font-bold text-white text-sm">
                  {(currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.brandName : brandName}
                </span>
                <span className="text-[10px] font-mono text-[#D4AF37] bg-[#0B1B3D] px-2.5 py-0.5 rounded-full border border-[#D4AF37]/30">
                  {(currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.niche : niche} Campaign Spec
                </span>
              </div>

              <div className="space-y-2 text-slate-300">
                <p>
                  <strong className="text-white">Campaign Goals:</strong> {(currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.goals : campaignGoals}
                </p>
                <p>
                  <strong className="text-white">Style Guidelines:</strong> {(currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.styleGuidelines : styleGuidelines}
                </p>
                <p>
                  <strong className="text-white">Mandatory Hooks:</strong> {(currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.hooks : requiredHooks}
                </p>
                <p>
                  <strong className="text-white">Legal Contract Terms:</strong>
                </p>
                <pre className="p-2.5 bg-[#0B1B3D] rounded-xl text-[10px] font-mono text-slate-300 whitespace-pre-wrap border border-white/5">
                  {(currentRole === 'agent' || currentRole === 'agentmgr') ? activeBrief.contractLegalText : contractLegalText}
                </pre>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowPreviewModal(false)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-[#142850] border border-white/10 cursor-pointer"
              >
                Cancel &amp; Edit
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowPreviewModal(false);
                  if (recipientTarget === 'agentmgr') {
                    handlePassBriefToAgent();
                  } else {
                    handlePassBriefToCreator();
                  }
                }}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-[#D4AF37] hover:bg-[#c5a030] shadow-lg flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>
                  {recipientTarget === 'creator' ? `Confirm & Send to ${selectedCreatorHandle}` : `Forward to ${targetAgentMgr}`}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
