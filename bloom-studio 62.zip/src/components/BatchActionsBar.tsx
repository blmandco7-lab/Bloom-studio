import React, { useState } from 'react';
import { 
  CheckSquare, UserCheck, Tag, Download, Trash2, X, 
  CheckCircle, AlertCircle, FileSpreadsheet, ShieldAlert, Mail,
  Layers, FileText, Megaphone
} from 'lucide-react';
import { Role } from '../types';
import DeleteConfirmationModal, { DeleteConfirmConfig } from './DeleteConfirmationModal';

interface BatchActionsBarProps {
  selectedIds: string[];
  itemType: 'creators' | 'content_submissions' | 'talent_applications' | 'brand_inquiries';
  currentRole: Role;
  primaryBrandColor?: string;
  onClearSelection: () => void;
  onBatchAssignAgent?: (agentName: string) => void;
  onBatchChangeStatus?: (status: string) => void;
  onBatchExportCSV?: () => void;
  onBatchExportRateCards?: () => void;
  onBatchPitchCampaign?: () => void;
  onBatchDelete?: () => void;
  onBatchSendEmail?: () => void;
  onBatchBroadcastMessage?: () => void;
  onBatchApproveContent?: () => void;
  onBatchRequestRevision?: () => void;
  onBatchApproveApplications?: () => void;
  onBatchRejectApplications?: () => void;
}

export const BatchActionsBar: React.FC<BatchActionsBarProps> = ({
  selectedIds,
  itemType,
  currentRole,
  primaryBrandColor = '#C9A46A',
  onClearSelection,
  onBatchAssignAgent,
  onBatchChangeStatus,
  onBatchExportCSV,
  onBatchDelete,
  onBatchSendEmail,
  onBatchApproveContent,
  onBatchRequestRevision,
  onBatchApproveApplications,
  onBatchRejectApplications,
  onBatchPitchCampaign,
  onBatchExportRateCards,
  onBatchBroadcastMessage
}) => {
  const [showAssignDropdown, setShowAssignDropdown] = useState(false);
  const [showStatusDropdown, setShowStatusDropdown] = useState(false);
  const [deleteConfirmConfig, setDeleteConfirmConfig] = useState<DeleteConfirmConfig | null>(null);

  if (selectedIds.length === 0) return null;

  const role = (currentRole || 'none').toLowerCase();

  // Role permissions checks
  const canAssignAgent = role === 'director' || role === 'agentmgr';
  const canDelete = role === 'director' || role === 'agentmgr';
  const canApproveContent = role === 'director' || role === 'agentmgr' || role === 'brand' || role === 'agent';
  const canApproveApplications = role === 'director' || role === 'agentmgr';

  const handleRequestBatchDelete = () => {
    setDeleteConfirmConfig({
      isOpen: true,
      title: `Batch Trash ${selectedIds.length} ${itemType.replace('_', ' ')}`,
      itemName: `${selectedIds.length} items selected`,
      itemType: itemType.replace('_', ' '),
      isPermanent: false,
      message: `Are you sure you want to move all ${selectedIds.length} selected ${itemType.replace('_', ' ')} to the 30-day Recoup Trash Bin?`,
      confirmButtonText: `Trash ${selectedIds.length} Items`,
      confirmButtonVariant: 'danger',
      onConfirm: () => {
        if (onBatchDelete) onBatchDelete();
      }
    });
  };

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-11/12 max-w-3xl bg-[#0D1830] border-2 border-amber-500/50 rounded-2xl p-4 shadow-2xl backdrop-blur-md text-white animate-slide-up font-mono">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Selected count info */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold flex items-center justify-center text-xs">
            {selectedIds.length}
          </div>
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <CheckSquare className="w-4 h-4 text-amber-400" />
              <span>{selectedIds.length} {itemType.replace('_', ' ')} Selected</span>
            </h4>
            <p className="text-[10px] text-slate-400">Apply batch operation across all selected items (§ Scoped to {role.toUpperCase()})</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* 1. CREATORS BATCH ACTIONS */}
          {itemType === 'creators' && (
            <>
              {canAssignAgent && onBatchAssignAgent && (
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowAssignDropdown(!showAssignDropdown);
                      setShowStatusDropdown(false);
                    }}
                    className="bg-[#111E33] hover:bg-white/10 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Assign Agent</span>
                  </button>

                  {showAssignDropdown && (
                    <div className="absolute bottom-full mb-2 right-0 w-44 bg-[#081220] border border-amber-500/40 rounded-xl shadow-2xl overflow-hidden py-1 z-50">
                      {['Agency Lead', 'Senior Talent Lead', 'Senior Campaign Lead', 'Unassigned'].map((agent) => (
                        <button
                          key={agent}
                          onClick={() => {
                            onBatchAssignAgent(agent);
                            setShowAssignDropdown(false);
                          }}
                          className="w-full text-left px-3 py-2 text-xs text-slate-200 hover:bg-amber-500/20 hover:text-amber-300 transition"
                        >
                          {agent}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {onBatchChangeStatus && (
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowStatusDropdown(!showStatusDropdown);
                      setShowAssignDropdown(false);
                    }}
                    className="bg-[#111E33] hover:bg-white/10 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <Tag className="w-3.5 h-3.5" />
                    <span>Set Status</span>
                  </button>

                  {showStatusDropdown && (
                    <div className="absolute bottom-full mb-2 right-0 w-40 bg-[#081220] border border-emerald-500/40 rounded-xl shadow-2xl overflow-hidden py-1 z-50">
                      {['Active', 'Pending Onboarding', 'Risk', 'On Hold'].map((st) => (
                        <button
                          key={st}
                          onClick={() => {
                            onBatchChangeStatus(st);
                            setShowStatusDropdown(false);
                          }}
                          className="w-full text-left px-3 py-2 text-xs text-slate-200 hover:bg-emerald-500/20 hover:text-emerald-300 transition"
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {onBatchPitchCampaign && (
                <button
                  type="button"
                  onClick={onBatchPitchCampaign}
                  className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Pitch to Campaign ({selectedIds.length})</span>
                </button>
              )}

              {onBatchExportRateCards && (
                <button
                  type="button"
                  onClick={onBatchExportRateCards}
                  className="bg-[#111E33] hover:bg-white/10 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Rate Cards & Media Kits</span>
                </button>
              )}

              {onBatchBroadcastMessage && (
                <button
                  type="button"
                  onClick={onBatchBroadcastMessage}
                  className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Megaphone className="w-3.5 h-3.5" />
                  <span>Cohort Announcement</span>
                </button>
              )}

              {onBatchExportCSV && (
                <button
                  onClick={onBatchExportCSV}
                  className="bg-[#111E33] hover:bg-white/10 text-sky-300 border border-sky-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </button>
              )}

              {onBatchSendEmail && (
                <button
                  onClick={onBatchSendEmail}
                  className="bg-[#C9A46A] hover:bg-[#d8b57d] text-[#0A1220] border border-[#C9A46A] px-3 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 transition cursor-pointer shadow-sm"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Bulk Email ({selectedIds.length})</span>
                </button>
              )}

              {canDelete && onBatchDelete && (
                <button
                  onClick={handleRequestBatchDelete}
                  className="bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Trash All ({selectedIds.length})</span>
                </button>
              )}
            </>
          )}

          {/* 2. CONTENT SUBMISSIONS BATCH ACTIONS */}
          {itemType === 'content_submissions' && (
            <>
              {canApproveContent && onBatchApproveContent && (
                <button
                  onClick={onBatchApproveContent}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-3.5 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Approve Selected ({selectedIds.length})</span>
                </button>
              )}

              {onBatchRequestRevision && (
                <button
                  onClick={onBatchRequestRevision}
                  className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 px-3 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Request Revision</span>
                </button>
              )}
            </>
          )}

          {/* 3. TALENT APPLICATIONS BATCH ACTIONS */}
          {itemType === 'talent_applications' && (
            <>
              {canApproveApplications && onBatchApproveApplications && (
                <button
                  onClick={onBatchApproveApplications}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-3.5 py-1.5 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Approve &amp; Onboard ({selectedIds.length})</span>
                </button>
              )}

              {onBatchRejectApplications && (
                <button
                  onClick={onBatchRejectApplications}
                  className="bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 transition cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Decline All</span>
                </button>
              )}
            </>
          )}

          {/* Deselect / Cancel Button */}
          <button
            onClick={onClearSelection}
            title="Deselect All"
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Delete Confirmation Modal for Batch Actions */}
      <DeleteConfirmationModal
        config={deleteConfirmConfig}
        onClose={() => setDeleteConfirmConfig(null)}
      />
    </div>
  );
};
