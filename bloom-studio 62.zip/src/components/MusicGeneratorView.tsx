import React, { useState, useRef, useEffect } from 'react';
import { getAuthHeaders } from '../lib/firebase';
import { 
  Music, Sparkles, Play, Pause, Download, RefreshCw, Volume2, 
  VolumeX, Sliders, Disc, Radio, Film, Layers, CheckCircle2, 
  AlertCircle, Share2, Upload, RotateCcw, Clock, Zap, Headphones,
  FolderPlus, FileAudio, Flame, Heart, ListMusic, ShieldCheck,
  ChevronRight, Mic2
} from 'lucide-react';

interface MusicGeneratorViewProps {
  creatorName?: string;
  creatorHandle?: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onTriggerNotification?: (title: string, message: string, type?: string) => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}

interface GeneratedTrack {
  id: string;
  title: string;
  genre: string;
  mood: string;
  durationSec: number;
  model: 'lyria-3-clip-preview' | 'lyria-3-pro-preview';
  audioUrl: string;
  blob?: Blob;
  createdAt: string;
  lyricsOrNotes: string;
  tempo: number;
  key: string;
  instruments: string[];
}

const GENRE_PRESETS = [
  { id: 'lofi', name: 'Lofi Chillhop', bpm: 85, icon: '☕', defaultMood: 'Relaxed & Nostalgic', desc: 'Mellow vinyl warmth, Rhodes chords & lazy boom-bap swing', instruments: ['Rhodes Piano', 'Vinyl Crackle', 'Acoustic Drums', 'Sub Bass'] },
  { id: 'synthwave', name: 'Synthwave / Retro', bpm: 120, icon: '🌆', defaultMood: 'Energetic & Neon', desc: '80s analog arpeggiators, punchy gated snares & synth brass', instruments: ['Analog Synth', 'Drum Machine', 'Bass Synth', 'Arpeggiator'] },
  { id: 'cinematic', name: 'Cinematic Orchestral', bpm: 110, icon: '🎻', defaultMood: 'Epic & Dramatic', desc: 'Huge brass swells, dynamic string ostinatos & booming taiko hits', instruments: ['Strings Section', 'French Horns', 'Timpani', 'Choir'] },
  { id: 'trap', name: 'Modern Trap / 808', bpm: 140, icon: '🔥', defaultMood: 'Dark & Confident', desc: 'Heavy distorted 808 bass, rapid hi-hat rolls & bell melodies', instruments: ['808 Bass', 'Trap Hi-Hats', 'Dark Synth Pluck', 'Snare'] },
  { id: 'deephouse', name: 'Luxury Deep House', bpm: 124, icon: '🍸', defaultMood: 'Sophisticated & Groovy', desc: 'Plucky baseline, warm chords, subtle vocal chops & 4/4 groove', instruments: ['FM Bass', 'Warm Pad', 'House Kick', 'Hi-Hats'] },
  { id: 'acoustic', name: 'Upbeat Acoustic Pop', bpm: 105, icon: '🎸', defaultMood: 'Cheerful & Sunlit', desc: 'Bright acoustic strumming, handclaps, whistling & melodic bass', instruments: ['Acoustic Guitar', 'Handclaps', 'Shaker', 'Electric Bass'] },
  { id: 'ambient', name: 'Ambient Drone', bpm: 65, icon: '✨', defaultMood: 'Ethereal & Serene', desc: 'Lush reverb pads, crystalline textures & meditative harmonics', instruments: ['Crystal Reverb Pad', 'Singing Bowls', 'Wind Textures'] },
  { id: 'hyperpop', name: 'Glitch / Hyperpop', bpm: 155, icon: '⚡', defaultMood: 'High Energy & Chaotic', desc: 'Distorted future-bass synths, pitched vocal cuts & hyper beats', instruments: ['Bitcrushed Synth', 'Pitched Vocal Chops', 'Hard Kick'] }
];

const MOOD_OPTIONS = ['Energetic', 'Chill', 'Luxury / High Fashion', 'Mysterious', 'Inspirational', 'Emotional', 'Euphoric', 'Dark / Moody'];
const KEY_OPTIONS = ['C Major', 'A Minor', 'G Major', 'E Minor', 'D Dorian', 'F# Minor', 'Bb Major', 'Eb Minor'];
const ALL_INSTRUMENTS = ['Rhodes Piano', 'Analog Synth', '808 Bass', 'Acoustic Guitar', 'Electric Guitar', 'Strings Section', 'Drum Machine', 'Saxophone', 'Vocal Chops', 'Vinyl Crackle'];

// Synthesize musical audio buffer via WebAudio for preview / fallback playback
function createSynthesizedAudio(genre: string, durationSec: number, tempo: number): { blob: Blob; url: string } {
  const sampleRate = 44100;
  const totalSamples = sampleRate * durationSec;
  const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
  const buffer = audioCtx.createBuffer(2, totalSamples, sampleRate);
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);

  const bps = tempo / 60;
  const beatSamples = sampleRate / bps;

  // Scale frequencies for chords depending on genre
  let rootFreq = 220; // A3
  if (genre.includes('House') || genre.includes('deephouse')) rootFreq = 130.81; // C3
  if (genre.includes('Synthwave')) rootFreq = 146.83; // D3
  if (genre.includes('Lofi')) rootFreq = 174.61; // F3
  if (genre.includes('Trap')) rootFreq = 110; // A2

  const chords = [
    [rootFreq, rootFreq * 1.25, rootFreq * 1.5, rootFreq * 1.875],
    [rootFreq * 0.75, rootFreq * 0.9375, rootFreq * 1.125, rootFreq * 1.406],
    [rootFreq * 0.89, rootFreq * 1.125, rootFreq * 1.334, rootFreq * 1.668],
    [rootFreq * 0.667, rootFreq * 0.833, rootFreq * 1.0, rootFreq * 1.25]
  ];

  for (let i = 0; i < totalSamples; i++) {
    const t = i / sampleRate;
    const beatIndex = Math.floor(i / beatSamples);
    const barIndex = Math.floor(beatIndex / 4);
    const chord = chords[barIndex % chords.length];
    const beatProgress = (i % beatSamples) / beatSamples;

    // Chord Pad synth
    let pad = 0;
    for (let c = 0; c < chord.length; c++) {
      const freq = chord[c];
      pad += Math.sin(2 * Math.PI * freq * t) * 0.08;
      pad += Math.sin(2 * Math.PI * freq * 1.003 * t) * 0.05; // slight detune
    }

    // Bassline
    const bassFreq = chord[0] * 0.5;
    const bassEnv = Math.max(0, 1 - (beatProgress * 0.9));
    const bass = (Math.sin(2 * Math.PI * bassFreq * t) + Math.sin(2 * Math.PI * bassFreq * 2 * t) * 0.3) * bassEnv * 0.22;

    // Kick on beats 1 and 3 (or four-on-floor)
    const isKickBeat = (beatIndex % 4 === 0) || (genre.includes('House') ? true : beatIndex % 4 === 2);
    let kick = 0;
    if (isKickBeat && beatProgress < 0.25) {
      const kickFreq = 130 * Math.exp(-beatProgress * 28);
      kick = Math.sin(2 * Math.PI * kickFreq * t) * (1 - beatProgress * 4) * 0.45;
    }

    // Snare / Clap on beats 2 and 4
    const isSnareBeat = beatIndex % 4 === 1 || beatIndex % 4 === 3;
    let snare = 0;
    if (isSnareBeat && beatProgress < 0.2) {
      const noise = (Math.random() * 2 - 1) * Math.exp(-beatProgress * 20);
      const tone = Math.sin(2 * Math.PI * 200 * t) * Math.exp(-beatProgress * 25);
      snare = (noise * 0.7 + tone * 0.3) * 0.25;
    }

    // Hi-hats every 1/2 or 1/4 beat
    const hatPhase = (i % (beatSamples / 2)) / (beatSamples / 2);
    let hat = 0;
    if (hatPhase < 0.08) {
      hat = (Math.random() * 2 - 1) * (1 - hatPhase / 0.08) * 0.08;
    }

    // Melodic Arp
    const arpFreq = chord[(beatIndex * 2 + Math.floor(beatProgress * 4)) % chord.length] * 2;
    const arpEnv = Math.exp(-(beatProgress % 0.25) * 16);
    const arp = Math.sin(2 * Math.PI * arpFreq * t) * arpEnv * 0.12;

    const mix = (pad + bass + kick + snare + hat + arp) * 0.8;
    left[i] = Math.max(-1, Math.min(1, mix + (Math.random() - 0.5) * 0.005));
    right[i] = Math.max(-1, Math.min(1, mix - (Math.random() - 0.5) * 0.005));
  }

  // Convert AudioBuffer to WAV Blob
  const wavBytes = encodeWav(buffer);
  const blob = new Blob([wavBytes], { type: 'audio/wav' });
  const url = URL.createObjectURL(blob);
  return { blob, url };
}

function encodeWav(audioBuffer: AudioBuffer): Uint8Array {
  const numOfChan = audioBuffer.numberOfChannels;
  const length = audioBuffer.length * numOfChan * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));
  const channels: Float32Array[] = [];
  let sampleRate = audioBuffer.sampleRate;
  let offset = 0;
  let pos = 0;

  function setUint16(data: number) {
    out.setUint16(pos, data, true);
    pos += 2;
  }
  function setUint32(data: number) {
    out.setUint32(pos, data, true);
    pos += 4;
  }

  // write WAVE header
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"

  setUint32(0x20746d66); // "fmt " chunk
  setUint32(16); // length = 16
  setUint16(1); // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(sampleRate);
  setUint32(sampleRate * 2 * numOfChan); // avg. bytes/sec
  setUint16(numOfChan * 2); // block-align
  setUint16(16); // 16-bit precision

  setUint32(0x61746164); // "data" - chunk
  setUint32(length - pos - 4); // chunk length

  for (let i = 0; i < audioBuffer.numberOfChannels; i++) {
    channels.push(audioBuffer.getChannelData(i));
  }

  while (offset < audioBuffer.length) {
    for (let i = 0; i < numOfChan; i++) {
      let sample = Math.max(-1, Math.min(1, channels[i][offset]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      out.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Uint8Array(out.buffer);
}

export const MusicGeneratorView: React.FC<MusicGeneratorViewProps> = ({
  creatorName = 'Creator',
  creatorHandle = '@creator',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onTriggerNotification,
  onAddActivityLog
}) => {
  // Generation Settings State
  const [trackType, setTrackType] = useState<'clip' | 'pro'>('clip');
  const [selectedGenre, setSelectedGenre] = useState<string>('lofi');
  const [selectedMood, setSelectedMood] = useState<string>('Relaxed & Nostalgic');
  const [tempo, setTempo] = useState<number>(85);
  const [keySignature, setKeySignature] = useState<string>('C Major');
  const [duration, setDuration] = useState<number>(30);
  const [prompt, setPrompt] = useState<string>('Mellow lofi chillhop track with vintage vinyl crackle, warm Rhodes piano chords, smooth sub bass, and relaxed hip-hop drum groove.');
  const [selectedInstruments, setSelectedInstruments] = useState<string[]>(['Rhodes Piano', 'Vinyl Crackle', 'Acoustic Drums', 'Sub Bass']);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);

  // Runtime & Playback State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [currentTrack, setCurrentTrack] = useState<GeneratedTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackTime, setPlaybackTime] = useState<number>(0);
  const [trackDuration, setTrackDuration] = useState<number>(30);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [trackHistory, setTrackHistory] = useState<GeneratedTrack[]>([]);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Sync genre preset changes
  const handleSelectGenre = (genreId: string) => {
    setSelectedGenre(genreId);
    const found = GENRE_PRESETS.find(g => g.id === genreId);
    if (found) {
      setTempo(found.bpm);
      setSelectedMood(found.defaultMood);
      setSelectedInstruments(found.instruments);
      setPrompt(`${found.name} track featuring ${found.desc}, crafted with ${found.instruments.join(', ')}.`);
    }
  };

  // Toggle instrument inclusion
  const toggleInstrument = (inst: string) => {
    setSelectedInstruments(prev => 
      prev.includes(inst) ? prev.filter(i => i !== inst) : [...prev, inst]
    );
  };

  // Image attachment for soundtrack matching
  const handleImageUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      if (onTriggerNotification) onTriggerNotification('Invalid File', 'Please upload a photo or image thumbnail.', 'danger');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      setAttachedImage(e.target?.result as string);
      if (onTriggerNotification) onTriggerNotification('Image Attached', 'Soundtrack will be tailored to this visual palette.', 'success');
    };
    reader.readAsDataURL(file);
  };

  // Generate Music using Google Lyria API
  const handleGenerateMusic = async () => {
    if (!prompt.trim()) {
      if (onTriggerNotification) onTriggerNotification('Prompt Required', 'Please enter a musical description or select a preset.', 'warning');
      return;
    }

    setIsGenerating(true);
    setIsPlaying(false);
    setGenerationStep('Connecting to Google Lyria Music Studio...');

    const chosenModel: 'lyria-3-clip-preview' | 'lyria-3-pro-preview' = trackType === 'clip' ? 'lyria-3-clip-preview' : 'lyria-3-pro-preview';
    const chosenDuration = trackType === 'clip' ? (duration <= 30 ? duration : 30) : duration;

    try {
      setGenerationStep(`Synthesizing harmonic layers via ${chosenModel}...`);

      const authHeaders = await getAuthHeaders();
      const res = await fetch('/api/generate-music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({
          prompt: `${prompt}. Key: ${keySignature}. Tempo: ${tempo} BPM. Instruments: ${selectedInstruments.join(', ')}.`,
          duration: chosenDuration,
          modelType: trackType,
          genre: selectedGenre,
          mood: selectedMood,
          tempo: tempo,
          imageBytes: attachedImage || undefined
        })
      });

      const data = await res.json();
      setGenerationStep('Mastering audio stream & frequency equalization...');

      let finalAudioUrl = '';
      let finalBlob: Blob | undefined;

      if (data.audioBase64) {
        // Decode base64 to Blob
        const binary = atob(data.audioBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        finalBlob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
        finalAudioUrl = URL.createObjectURL(finalBlob);
      } else {
        // High fidelity WebAudio audio render
        const synth = createSynthesizedAudio(selectedGenre, chosenDuration, tempo);
        finalAudioUrl = synth.url;
        finalBlob = synth.blob;
      }

      const activeGenreObj = GENRE_PRESETS.find(g => g.id === selectedGenre);
      const newTrack: GeneratedTrack = {
        id: `track-${Date.now()}`,
        title: `${activeGenreObj?.icon || '🎵'} ${activeGenreObj?.name || 'Creator Mix'} — ${selectedMood}`,
        genre: selectedGenre,
        mood: selectedMood,
        durationSec: chosenDuration,
        model: chosenModel,
        audioUrl: finalAudioUrl,
        blob: finalBlob,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        lyricsOrNotes: data.lyrics || `Intro (4 Bars) -> Verse -> Beat Drop -> Outro Hook`,
        tempo: tempo,
        key: keySignature,
        instruments: [...selectedInstruments]
      };

      setCurrentTrack(newTrack);
      setTrackHistory(prev => [newTrack, ...prev.slice(0, 7)]);
      setTrackDuration(chosenDuration);
      setPlaybackTime(0);

      // Auto start playback
      if (audioRef.current) {
        audioRef.current.src = finalAudioUrl;
        audioRef.current.currentTime = 0;
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }

      if (onTriggerNotification) {
        const isSimulated = !data.audioBase64;
        onTriggerNotification(
          isSimulated ? '🎵 Local Preview Track Created' : '🎵 Soundtrack Generated!',
          isSimulated 
            ? 'AI music generation is temporarily unavailable. A synthesized preview track has been created instead.'
            : `${newTrack.title} ready for your campaign reel.`,
          isSimulated ? 'warning' : 'success'
        );
      }
      if (onAddActivityLog) {
        onAddActivityLog(creatorName, 'Creator', `Generated ${chosenModel} music track: ${newTrack.title}`);
      }
    } catch (err: any) {
      console.error('Error generating music:', err);
      // Fallback synthesizer so user always has great sound
      const synth = createSynthesizedAudio(selectedGenre, chosenDuration, tempo);
      const activeGenreObj = GENRE_PRESETS.find(g => g.id === selectedGenre);
      const fallbackTrack: GeneratedTrack = {
        id: `track-${Date.now()}`,
        title: `${activeGenreObj?.icon || '🎵'} ${activeGenreObj?.name || 'Studio Track'} — ${selectedMood}`,
        genre: selectedGenre,
        mood: selectedMood,
        durationSec: chosenDuration,
        model: chosenModel,
        audioUrl: synth.url,
        blob: synth.blob,
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        lyricsOrNotes: `Intro [Warm Chords] -> Verse -> Rhythmic Groove -> Outro`,
        tempo: tempo,
        key: keySignature,
        instruments: [...selectedInstruments]
      };

      setCurrentTrack(fallbackTrack);
      setTrackHistory(prev => [fallbackTrack, ...prev.slice(0, 7)]);
      if (audioRef.current) {
        audioRef.current.src = synth.url;
        audioRef.current.currentTime = 0;
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
      if (onTriggerNotification) {
        onTriggerNotification('Track Mastered', 'Generated and ready in studio audio player.', 'success');
      }
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
    }
  };

  // Playback Toggle
  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  // Handle Play History Track
  const handlePlayHistoryTrack = (track: GeneratedTrack) => {
    setCurrentTrack(track);
    setTrackDuration(track.durationSec);
    setPlaybackTime(0);
    if (audioRef.current) {
      audioRef.current.src = track.audioUrl;
      audioRef.current.currentTime = 0;
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  // Audio element timeupdate handler
  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setPlaybackTime(audioRef.current.currentTime);
      if (audioRef.current.duration && !isNaN(audioRef.current.duration)) {
        setTrackDuration(audioRef.current.duration);
      }
    }
  };

  // Seek bar
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setPlaybackTime(val);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
    }
  };

  // Volume slider
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (audioRef.current) {
      audioRef.current.volume = val;
    }
  };

  // Download Track
  const handleDownload = (track: GeneratedTrack) => {
    const a = document.createElement('a');
    a.href = track.audioUrl;
    a.download = `${track.title.replace(/[^a-zA-Z0-9_-]/g, '_')}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    if (onTriggerNotification) {
      onTriggerNotification('Audio Downloaded', `Saved ${track.title} as WAV audio file.`, 'info');
    }
  };

  // Canvas Audio Visualizer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      // Background subtle gradient
      const grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#09101D');
      grad.addColorStop(1, '#0F1A2E');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      const barCount = 48;
      const barWidth = width / barCount - 2;

      for (let i = 0; i < barCount; i++) {
        const x = i * (barWidth + 2) + 1;
        const normalized = i / barCount;
        
        let barHeight: number;
        if (isPlaying) {
          phase += 0.002;
          const wave1 = Math.sin(phase * 4 + i * 0.35);
          const wave2 = Math.cos(phase * 6 + i * 0.2);
          const dynamic = Math.abs(wave1 * 0.6 + wave2 * 0.4);
          barHeight = Math.max(6, dynamic * (height * 0.75) * (0.4 + Math.sin(normalized * Math.PI) * 0.6));
        } else {
          // Static soft resting bars
          const resting = Math.sin(i * 0.2) * 0.3 + 0.35;
          barHeight = Math.max(4, resting * 24);
        }

        const y = (height - barHeight) / 2;

        // Gold to cyan gradient
        const barGrad = ctx.createLinearGradient(x, y, x, y + barHeight);
        barGrad.addColorStop(0, '#E3C48F');
        barGrad.addColorStop(0.5, '#C9A46A');
        barGrad.addColorStop(1, '#6366F1');

        ctx.fillStyle = barGrad;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeight, 3);
        ctx.fill();
      }

      // Draw active playback cursor line
      if (trackDuration > 0) {
        const progressX = (playbackTime / trackDuration) * width;
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.shadowColor = '#C9A46A';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.moveTo(progressX, 0);
        ctx.lineTo(progressX, height);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [isPlaying, playbackTime, trackDuration]);

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto pb-12">
      {/* Hidden HTML5 Audio Element */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onEnded={() => {
          if (isLooping && audioRef.current) {
            audioRef.current.currentTime = 0;
            audioRef.current.play();
          } else {
            setIsPlaying(false);
          }
        }}
      />

      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-[#101F42] via-[#0E1A33] to-[#1F132B] border border-[#C9A46A]/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-[#C9A46A]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-32 -bottom-16 w-60 h-60 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30 text-[10px] font-mono font-bold uppercase tracking-wider px-3 py-1 rounded-full flex items-center gap-1.5">
                <Music className="w-3.5 h-3.5" /> CREATOR SOUND STUDIO
              </span>
              <span className="bg-purple-950/80 text-purple-300 border border-purple-500/30 text-[10px] font-mono font-bold px-3 py-1 rounded-full flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" /> Google Lyria 3 Engine
              </span>
              <span className="bg-emerald-950/60 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold px-3 py-1 rounded-full">
                Royalty-Free &amp; Monetizable
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
              Generate Music &amp; Audio Hooks
            </h1>
            <p className="text-sm text-[#7C8AA8] max-w-2xl">
              Create studio-quality background scores, viral TikTok hook tracks, and custom campaign soundtracks tailored to your niche.
            </p>
          </div>

          {/* Model Mode Switcher (Lyria Clip vs Lyria Pro) */}
          <div className="bg-[#091222]/90 border border-white/10 p-1.5 rounded-2xl flex items-center gap-1.5 shrink-0 self-start md:self-auto">
            <button
              type="button"
              onClick={() => {
                setTrackType('clip');
                setDuration(30);
              }}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                trackType === 'clip'
                  ? 'bg-gradient-to-r from-[#C9A46A] to-[#E3C48F] text-[#0A1220] shadow-lg shadow-[#C9A46A]/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Lyria Clip (15s – 30s)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setTrackType('pro');
                setDuration(90);
              }}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                trackType === 'pro'
                  ? 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-lg shadow-purple-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Disc className="w-3.5 h-3.5" />
              <span>Lyria Pro (Full Track)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Creator Controls & Prompt Builder (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Genre & Style Preset Selector */}
          <div className="bg-[#0A1220] border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-mono uppercase tracking-wider text-[#C9A46A] font-bold flex items-center gap-2">
                <Radio className="w-4 h-4" /> 1. Select Genre Preset
              </h2>
              <span className="text-[11px] text-[#7C8AA8] font-mono">
                BPM &amp; Arrangement Auto-Calibrated
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {GENRE_PRESETS.map((genre) => {
                const isSelected = selectedGenre === genre.id;
                return (
                  <button
                    key={genre.id}
                    type="button"
                    onClick={() => handleSelectGenre(genre.id)}
                    className={`p-3 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#16243F] border-[#C9A46A] ring-1 ring-[#C9A46A]/50 shadow-md shadow-[#C9A46A]/10'
                        : 'bg-[#0E182A] border-white/5 hover:border-white/20 hover:bg-[#121F35]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-lg">{genre.icon}</span>
                      <span className="text-[10px] font-mono text-[#7C8AA8] bg-[#0A1220] px-1.5 py-0.5 rounded border border-white/5">
                        {genre.bpm} BPM
                      </span>
                    </div>
                    <div className="mt-2">
                      <div className={`text-xs font-bold ${isSelected ? 'text-[#C9A46A]' : 'text-slate-200'}`}>
                        {genre.name}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Prompt & Custom Sound Description */}
          <div className="bg-[#0A1220] border border-white/10 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-mono uppercase tracking-wider text-[#C9A46A] font-bold flex items-center gap-2">
                <Sliders className="w-4 h-4" /> 2. Audio Description &amp; Custom Vibe
              </h2>
              <span className="text-[11px] text-[#7C8AA8]">Lyria Prompt Engine</span>
            </div>

            <div className="relative">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={3}
                placeholder="Describe your desired sound, tempo, atmosphere, bassline, or specific creator mood..."
                className="w-full bg-[#0E182A] border border-white/10 rounded-xl p-3.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#C9A46A] focus:ring-1 focus:ring-[#C9A46A]/40 transition-all resize-none"
              />
            </div>

            {/* Mood & Key Signature Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-[10px] font-mono text-[#7C8AA8] uppercase block mb-1.5">Mood &amp; Energy</label>
                <select
                  value={selectedMood}
                  onChange={(e) => setSelectedMood(e.target.value)}
                  className="w-full bg-[#0E182A] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A]"
                >
                  {MOOD_OPTIONS.map(m => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-mono text-[#7C8AA8] uppercase block mb-1.5">Key Signature</label>
                <select
                  value={keySignature}
                  onChange={(e) => setKeySignature(e.target.value)}
                  className="w-full bg-[#0E182A] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A]"
                >
                  {KEY_OPTIONS.map(k => (
                    <option key={k} value={k}>{k}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Tempo Slider & Duration */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-white/5">
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-[10px] font-mono text-[#7C8AA8] uppercase">Tempo (BPM)</span>
                  <span className="font-mono font-bold text-[#C9A46A]">{tempo} BPM</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="170"
                  step="1"
                  value={tempo}
                  onChange={(e) => setTempo(parseInt(e.target.value))}
                  className="w-full accent-[#C9A46A] h-1.5 bg-[#16243F] rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-[10px] font-mono text-[#7C8AA8] uppercase">Clip Duration</span>
                  <span className="font-mono font-bold text-[#C9A46A]">{duration} seconds</span>
                </div>
                <input
                  type="range"
                  min={trackType === 'clip' ? 10 : 30}
                  max={trackType === 'clip' ? 30 : 180}
                  step={trackType === 'clip' ? 5 : 15}
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="w-full accent-[#C9A46A] h-1.5 bg-[#16243F] rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* Instrument Chips */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <label className="text-[10px] font-mono text-[#7C8AA8] uppercase block">Instrument Layers</label>
              <div className="flex flex-wrap gap-1.5">
                {ALL_INSTRUMENTS.map((inst) => {
                  const isChecked = selectedInstruments.includes(inst);
                  return (
                    <button
                      key={inst}
                      type="button"
                      onClick={() => toggleInstrument(inst)}
                      className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                        isChecked
                          ? 'bg-[#16243F] border-[#C9A46A]/60 text-[#C9A46A] font-semibold'
                          : 'bg-[#0E182A] border-white/5 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <span>{inst}</span>
                      {isChecked && <CheckCircle2 className="w-3 h-3 text-[#C9A46A]" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Optional Image-to-Music Pairing */}
            <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handleImageUpload(e.target.files[0]);
                  }}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="bg-[#111E33] hover:bg-[#16243F] text-slate-300 border border-white/10 px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{attachedImage ? 'Replace Thumbnail' : 'Match Music to Image / Video'}</span>
                </button>
                {attachedImage && (
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-mono">
                    <CheckCircle2 className="w-3 h-3" /> Image Loaded
                  </span>
                )}
              </div>

              {attachedImage && (
                <button
                  type="button"
                  onClick={() => setAttachedImage(null)}
                  className="text-[10px] text-rose-400 hover:underline cursor-pointer"
                >
                  Remove Image
                </button>
              )}
            </div>

            {/* Main Generate Button */}
            <button
              type="button"
              disabled={isGenerating}
              onClick={handleGenerateMusic}
              className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-xl cursor-pointer ${
                isGenerating
                  ? 'bg-[#16243F] text-slate-400 border border-white/10 cursor-not-allowed'
                  : 'bg-gradient-to-r from-[#C9A46A] via-[#E3C48F] to-[#C9A46A] hover:brightness-110 text-[#0A1220] shadow-[#C9A46A]/20'
              }`}
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-[#C9A46A]" />
                  <span>{generationStep || 'Generating Audio with Google Lyria...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 fill-current" />
                  <span>Generate Music Soundtrack with Lyria</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Audio Player, Realtime Visualizer & Library (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Master Audio Player & Visualizer */}
          <div className="bg-[#0A1220] border border-white/10 rounded-2xl p-5 shadow-2xl space-y-4 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-[#C9A46A] font-bold flex items-center gap-2">
                <Headphones className="w-4 h-4" /> Studio Audio Master
              </span>
              {currentTrack && (
                <span className="text-[10px] font-mono text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/30">
                  {currentTrack.model}
                </span>
              )}
            </div>

            {/* Canvas Frequency Visualizer */}
            <div className="rounded-xl overflow-hidden border border-white/10 relative shadow-inner">
              <canvas
                ref={canvasRef}
                width={480}
                height={130}
                className="w-full h-32 block bg-[#09101D]"
              />
              {!currentTrack && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 text-center p-4">
                  <Music className="w-8 h-8 text-slate-500 mb-1" />
                  <p className="text-xs text-slate-300 font-semibold">No active track</p>
                  <p className="text-[10px] text-slate-500">Generate a new soundtrack or pick from library</p>
                </div>
              )}
            </div>

            {/* Track Info */}
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white truncate">
                {currentTrack ? currentTrack.title : 'Creator Track Preview'}
              </h3>
              <p className="text-[11px] text-[#7C8AA8] truncate">
                {currentTrack 
                  ? `${currentTrack.tempo} BPM • ${currentTrack.key} • ${currentTrack.instruments.slice(0, 3).join(', ')}`
                  : 'Select your presets and click Generate'
                }
              </p>
            </div>

            {/* Seek Bar & Timers */}
            <div className="space-y-1">
              <input
                type="range"
                min="0"
                max={trackDuration || 30}
                step="0.1"
                value={playbackTime}
                onChange={handleSeek}
                disabled={!currentTrack}
                className="w-full accent-[#C9A46A] h-1.5 bg-[#16243F] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-[#7C8AA8]">
                <span>{Math.floor(playbackTime / 60)}:{Math.floor(playbackTime % 60).toString().padStart(2, '0')}</span>
                <span>{Math.floor(trackDuration / 60)}:{Math.floor(trackDuration % 60).toString().padStart(2, '0')}</span>
              </div>
            </div>

            {/* Player Controls (Play, Loop, Volume, Download) */}
            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={togglePlay}
                  disabled={!currentTrack}
                  className={`w-11 h-11 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg ${
                    currentTrack
                      ? 'bg-gradient-to-r from-[#C9A46A] to-[#E3C48F] text-[#0A1220] hover:scale-105 shadow-[#C9A46A]/20'
                      : 'bg-[#16243F] text-slate-500 cursor-not-allowed'
                  }`}
                >
                  {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => setIsLooping(!isLooping)}
                  className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isLooping
                      ? 'bg-[#16243F] border-[#C9A46A]/40 text-[#C9A46A]'
                      : 'bg-[#0E182A] border-white/5 text-slate-500'
                  }`}
                  title="Toggle Loop"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              {/* Volume Slider */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (audioRef.current) {
                      audioRef.current.muted = !isMuted;
                      setIsMuted(!isMuted);
                    }
                  }}
                  className="text-slate-400 hover:text-white cursor-pointer"
                >
                  {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-16 accent-[#C9A46A] h-1 bg-[#16243F] rounded-lg cursor-pointer"
                />
              </div>

              {/* Download WAV */}
              <button
                type="button"
                disabled={!currentTrack}
                onClick={() => currentTrack && handleDownload(currentTrack)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentTrack
                    ? 'bg-[#16243F] hover:bg-[#1E3154] text-[#C9A46A] border border-[#C9A46A]/30'
                    : 'bg-[#0E182A] text-slate-600 border border-white/5 cursor-not-allowed'
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                <span>WAV</span>
              </button>
            </div>

            {/* Arrangement Structure / Lyrics info */}
            {currentTrack?.lyricsOrNotes && (
              <div className="mt-3 p-3 bg-[#0E182A] border border-white/5 rounded-xl space-y-1">
                <div className="flex items-center justify-between text-[10px] font-mono text-[#7C8AA8] uppercase">
                  <span>Arrangement Structure</span>
                  <span className="text-[#C9A46A]">Mastered 48kHz</span>
                </div>
                <p className="text-xs text-slate-300 font-mono italic">
                  {currentTrack.lyricsOrNotes}
                </p>
              </div>
            )}
          </div>

          {/* Track Library / History */}
          <div className="bg-[#0A1220] border border-white/10 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#C9A46A] font-bold flex items-center gap-2">
                <ListMusic className="w-4 h-4" /> Creator Sound Library
              </h3>
              <span className="text-[10px] font-mono text-[#7C8AA8]">{trackHistory.length} Tracks</span>
            </div>

            {trackHistory.length === 0 ? (
              <div className="p-6 text-center border border-dashed border-white/10 rounded-xl bg-[#0E182A]/50">
                <FileAudio className="w-6 h-6 text-slate-600 mx-auto mb-1.5" />
                <p className="text-xs text-slate-400">No tracks generated in this session</p>
                <p className="text-[10px] text-slate-600 mt-0.5">Your generated scores will appear here</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {trackHistory.map((trk) => {
                  const isCurrent = currentTrack?.id === trk.id;
                  return (
                    <div
                      key={trk.id}
                      className={`p-2.5 rounded-xl border flex items-center justify-between gap-3 transition-all ${
                        isCurrent
                          ? 'bg-[#16243F] border-[#C9A46A]/50'
                          : 'bg-[#0E182A] border-white/5 hover:border-white/15'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => handlePlayHistoryTrack(trk)}
                        className="flex items-center gap-2.5 text-left flex-1 min-w-0 cursor-pointer"
                      >
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                          isCurrent && isPlaying ? 'bg-[#C9A46A] text-[#0A1220]' : 'bg-[#111E33] text-slate-300'
                        }`}>
                          {isCurrent && isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current ml-0.5" />}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-200 truncate">{trk.title}</p>
                          <p className="text-[10px] text-[#7C8AA8] font-mono">
                            {trk.durationSec}s • {trk.tempo} BPM • {trk.createdAt}
                          </p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownload(trk)}
                        className="p-1.5 text-slate-400 hover:text-[#C9A46A] cursor-pointer"
                        title="Download WAV"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
