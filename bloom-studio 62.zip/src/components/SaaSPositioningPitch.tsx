import React from 'react';
import { ShieldCheck, Clock, Layers, Sparkles, CheckCircle2, TrendingUp, Lock } from 'lucide-react';

/**
 * SaaSPositioningPitch:
 * High-converting B2B SaaS pitch framework for Bloom Studio.
 */
export default function SaaSPositioningPitch() {
  return (
    <div className="bg-agency-navy border border-agency-gold/30 rounded-3xl p-6 sm:p-10 shadow-2xl text-agency-textLight space-y-8 max-w-5xl mx-auto">
      {/* Hero Pitch */}
      <div className="text-center space-y-3 max-w-3xl mx-auto">
        <span className="text-[11px] uppercase font-mono font-bold tracking-widest text-agency-gold bg-agency-navyLight border border-agency-gold/30 px-3.5 py-1 rounded-full">
          B2B Agency Operating System
        </span>
        <h2 className="font-serif font-bold text-3xl sm:text-4xl text-white leading-tight">
          The Enterprise Operating System Built for High-Volume Creator &amp; UGC Agencies
        </h2>
        <p className="text-sm text-slate-300 leading-relaxed">
          Scale your pet, beauty, and lifestyle influencer operations with ironclad financial privacy, automated cash-flow time-locks, and turnkey multi-tenant pod isolation.
        </p>
      </div>

      {/* 3 Core Valuation Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
        {/* Pillar 1 */}
        <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-6 space-y-3 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-agency-navy text-agency-gold border border-agency-gold/40 flex items-center justify-center">
              <Lock className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-lg text-white">
              Multi-Tier Permission Curtains
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enforce total executive financial privacy. Managers, agents, and coordinators can execute casting workflows, shipping logistics, and review 4K deliverables freely—while top-line corporate client contracts, net agency margins, and corporate billing statements remain 100% invisible to staff eyes.
            </p>
          </div>
          <div className="pt-2 border-t border-white/5 text-[11px] font-mono text-agency-gold flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Zero Staff Margin Leakage</span>
          </div>
        </div>

        {/* Pillar 2 */}
        <div className="bg-agency-navyLight border border-agency-gold/30 rounded-2xl p-6 space-y-3 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-agency-navy text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-lg text-white">
              Cash-Flow Alignment Engine
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Never float payroll on your own balance sheet again. The system natively time-locks employee commissions and creator compensation to the brand's settlement terms (Upfront, Net 15, Net 30, Net 60), completely eliminating out-of-pocket cash drain risks before brand funds clear in escrow.
            </p>
          </div>
          <div className="pt-2 border-t border-white/5 text-[11px] font-mono text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Guaranteed Risk-Free Payroll</span>
          </div>
        </div>

        {/* Pillar 3 */}
        <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-6 space-y-3 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-agency-navy text-blue-400 border border-blue-500/40 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="font-serif font-bold text-lg text-white">
              Turnkey Multi-Tenant Pods
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Automated logistics pipelines engineered specifically for physical product seeding, FTC disclosure audits, and W-9 tax compliance. Onboard agency client pods and creator networks in seconds with dedicated Firestore sandboxes.
            </p>
          </div>
          <div className="pt-2 border-t border-white/5 text-[11px] font-mono text-blue-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Rapid Physical Fulfillment</span>
          </div>
        </div>
      </div>
    </div>
  );
}
