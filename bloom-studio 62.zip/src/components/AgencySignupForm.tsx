import { useState } from 'react';
import { Building2, ArrowLeft, Check, Loader2 } from 'lucide-react';

interface AgencySignupFormProps {
  primaryBrandColor: string;
  cardBgColor: string;
  onBack: () => void;
}

const PLANS = [
  {
    id: 'core',
    name: 'Core OS',
    price: '$149/mo',
    priceEnvKey: 'core',
    features: ['Up to 10 creators', 'Deal & campaign pipeline', 'Basic contracts vault'],
  },
  {
    id: 'growth',
    name: 'Growth',
    price: '$399/mo',
    priceEnvKey: 'growth',
    features: ['Up to 50 creators', 'Sub-agency isolation', 'AI media studio', 'Priority support'],
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 'Custom',
    priceEnvKey: 'enterprise',
    features: ['Unlimited creators', 'White-label branding', 'Dedicated onboarding'],
  },
];

export default function AgencySignupForm({ primaryBrandColor, cardBgColor, onBack }: AgencySignupFormProps) {
  const [step, setStep] = useState<'details' | 'plan'>('details');
  const [form, setForm] = useState({
    agencyName: '',
    subdomain: '',
    adminEmail: '',
    plan: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubdomainChange = (value: string) => {
    const clean = value.toLowerCase().replace(/[^a-z0-9-]/g, '');
    setForm({ ...form, subdomain: clean });
  };

  const handleContinueToPlan = () => {
    setError(null);
    if (!form.agencyName.trim() || !form.subdomain.trim() || !form.adminEmail.trim()) {
      setError('Agency name, subdomain, and admin email are all required.');
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(form.adminEmail)) {
      setError('Enter a valid email address.');
      return;
    }
    setStep('plan');
  };

  const handleSubmit = async () => {
    setError(null);
    if (!form.plan) {
      setError('Select a plan to continue.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not start checkout.');
      }
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error('No checkout URL returned.');
      }
    } catch (err: any) {
      setError(err.message || 'Something went wrong starting checkout. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A1220] flex items-center justify-center p-6">
      <div className="max-w-2xl w-full space-y-6">
        <button
          type="button"
          onClick={() => (step === 'plan' ? setStep('details') : onBack())}
          className="flex items-center gap-2 text-xs text-[#7C8AA8] hover:text-white cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" /> {step === 'plan' ? 'Back to agency details' : 'Back to sign in'}
        </button>

        <div className="flex items-center gap-2 text-[10px] uppercase font-mono text-[#7C8AA8]">
          <span className={step === 'details' ? 'text-[#C9A46A]' : ''}>1. Agency Details</span>
          <span>&rarr;</span>
          <span className={step === 'plan' ? 'text-[#C9A46A]' : ''}>2. Choose a Plan</span>
        </div>

        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: primaryBrandColor }}
            >
              <Building2 className="w-5 h-5 text-[#0A1220]" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-white">
                {step === 'details' ? 'Start Your Own Agency Workspace' : 'Choose Your Plan'}
              </h1>
              <p className="text-xs text-[#7C8AA8]">
                {step === 'details'
                  ? 'A dedicated, white-labeled instance for your team.'
                  : `Setting up "${form.agencyName}" - this determines what your agency pays, not what your staff pay.`}
              </p>
            </div>
          </div>

          {error && (
            <div className="bg-rose-950/60 border border-rose-500/30 rounded-xl p-3 text-xs text-rose-300">
              {error}
            </div>
          )}

          {step === 'details' && (
            <>
              <div className="space-y-3">
                <div>
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Agency Name</label>
                  <input
                    value={form.agencyName}
                    onChange={(e) => setForm({ ...form, agencyName: e.target.value })}
                    placeholder="e.g. Velvet Media Group"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-sm text-white mt-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Subdomain</label>
                  <div className="flex items-center mt-1">
                    <input
                      value={form.subdomain}
                      onChange={(e) => handleSubdomainChange(e.target.value)}
                      placeholder="velvet-media"
                      className="w-full bg-[#111E33] border border-white/10 rounded-l-lg p-2.5 text-sm text-white"
                    />
                    <span className="bg-[#0A1220] border border-l-0 border-white/10 rounded-r-lg p-2.5 text-xs text-[#7C8AA8]">
                      .bloomstudio.app
                    </span>
                  </div>
                </div>
                <div>
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Admin Email (Director)</label>
                  <input
                    type="email"
                    value={form.adminEmail}
                    onChange={(e) => setForm({ ...form, adminEmail: e.target.value })}
                    placeholder="you@youragency.com"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-sm text-white mt-1"
                  />
                  <p className="text-[10px] text-[#7C8AA8] mt-1">
                    This is your own director login. Staff and creators inside your agency join later via
                    invite code, at no additional charge to them.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleContinueToPlan}
                className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-sm font-semibold px-4 py-3 rounded-xl cursor-pointer"
              >
                Continue to Plan Selection
              </button>
            </>
          )}

          {step === 'plan' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {PLANS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setForm({ ...form, plan: p.id })}
                    className={`text-left border rounded-xl p-4 transition-colors cursor-pointer ${
                      form.plan === p.id
                        ? 'border-[#C9A46A] bg-[#C9A46A]/10'
                        : 'border-white/10 bg-[#111E33] hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-white">{p.name}</span>
                      {form.plan === p.id && <Check className="w-4 h-4 text-[#C9A46A]" />}
                    </div>
                    <div className="text-lg font-bold text-[#C9A46A] mt-1">{p.price}</div>
                    <ul className="mt-2 space-y-1">
                      {p.features.map((f) => (
                        <li key={f} className="text-[10px] text-[#7C8AA8]">{f}</li>
                      ))}
                    </ul>
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handleSubmit}
                disabled={isSubmitting || !form.plan}
                className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] disabled:opacity-60 text-[#0A1220] text-sm font-semibold px-4 py-3 rounded-xl flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Redirecting to secure checkout...
                  </>
                ) : (
                  `Continue to Payment`
                )}
              </button>
              <p className="text-[10px] text-[#7C8AA8] text-center">
                You'll be redirected to Stripe's secure checkout. Your workspace is created automatically once
                payment completes. This charges the agency account only - staff and creators you invite never
                see a payment screen.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
