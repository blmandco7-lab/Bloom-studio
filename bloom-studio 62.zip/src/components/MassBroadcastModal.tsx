/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Megaphone, 
  X, 
  Send, 
  Users, 
  User, 
  Smartphone, 
  MessageSquare, 
  Check, 
  ShieldCheck, 
  AlertTriangle,
  Building2,
  Sparkles,
  Mail,
  Loader2
} from 'lucide-react';
import { Role, Creator } from '../types';
import { AnnouncementItem } from './AnnouncementsModal';

export interface BroadcastDispatchOptions {
  sendPush: boolean;
  sendSms: boolean;
  sendChat: boolean;
  sendEmail?: boolean;
}

interface MassBroadcastModalProps {
  isOpen: boolean;
  onClose: () => void;
  creators: Creator[];
  currentRole: Role;
  currentUser: any;
  onSendBroadcast: (announcement: Partial<AnnouncementItem>, options: BroadcastDispatchOptions) => Promise<void> | void;
}

export const MassBroadcastModal: React.FC<MassBroadcastModalProps> = ({
  isOpen,
  onClose,
  creators,
  currentRole,
  currentUser,
  onSendBroadcast
}) => {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [audienceType, setAudienceType] = useState<'everyone' | 'creators_all' | 'creator_single' | 'team_all' | 'team_managers' | 'team_agents' | 'team_coordinators' | 'brands'>('everyone');
  const [selectedCreatorHandle, setSelectedCreatorHandle] = useState(creators[0]?.handle || '');
  const [priority, setPriority] = useState<'normal' | 'important' | 'urgent'>('normal');
  
  // Multi-channel dispatch options
  const [sendPush, setSendPush] = useState(true);
  const [sendSms, setSendSms] = useState(true);
  const [sendChat, setSendChat] = useState(true);
  const [sendEmail, setSendEmail] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase());
  if (!isOpen || !isDirector) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim() || isSending) return;

    let audienceLabel = 'All Agency';
    let targetCreatorName: string | undefined = undefined;
    let targetCreatorHandle: string | undefined = undefined;
    let targetTeamName: string | undefined = undefined;

    if (audienceType === 'everyone') {
      audienceLabel = 'All Agency';
    } else if (audienceType === 'creators_all') {
      audienceLabel = 'Creators Only';
    } else if (audienceType === 'creator_single') {
      const c = creators.find(cr => cr.handle === selectedCreatorHandle || cr.name === selectedCreatorHandle);
      audienceLabel = `Specific Creator: ${selectedCreatorHandle}`;
      targetCreatorName = c?.name;
      targetCreatorHandle = c?.handle || selectedCreatorHandle;
    } else if (audienceType === 'team_all') {
      audienceLabel = 'Staff Only';
      targetTeamName = 'All Staff & Agents';
    } else if (audienceType === 'team_managers') {
      audienceLabel = 'Staff Only';
      targetTeamName = 'Agent Managers';
    } else if (audienceType === 'team_agents') {
      audienceLabel = 'Staff Only';
      targetTeamName = 'Talent Agents';
    } else if (audienceType === 'team_coordinators') {
      audienceLabel = 'Staff Only';
      targetTeamName = 'Coordinators';
    } else if (audienceType === 'brands') {
      audienceLabel = 'Brands Only';
      targetTeamName = 'Brand Partners';
    }

    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    const newAnnouncement: Partial<AnnouncementItem> = {
      id: 'an_' + Date.now(),
      title: title.trim(),
      text: message.trim(),
      date: formattedDate,
      createdAt: now.toISOString(),
      author: currentUser?.name || (currentRole === 'director' ? 'Agency Director' : 'Marcus Cole'),
      authorRole: currentRole,
      audience: audienceLabel,
      targetCreatorName,
      targetCreatorHandle,
      targetTeamName,
      priority,
      readBy: []
    };

    setIsSending(true);
    try {
      await onSendBroadcast(newAnnouncement, { sendPush, sendSms, sendChat, sendEmail });
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        setIsSending(false);
        setTitle('');
        setMessage('');
        onClose();
      }, 1200);
    } catch (err) {
      console.error("Broadcast dispatch failed:", err);
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in font-sans">
      <div className="bg-[#0D1830] border border-sky-500/40 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#111E33]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Mass Send Text &amp; Announcement</h3>
              <p className="text-xs text-[#7C8AA8]">Broadcast notifications to Everyone, Per Creator, or Per Team.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          
          {/* Target Audience */}
          <div>
            <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1.5">
              Target Audience
            </label>
            <select
              value={audienceType}
              onChange={e => setAudienceType(e.target.value as any)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:border-sky-500 cursor-pointer"
            >
              <optgroup label="🌐 Studio-Wide (Everyone)">
                <option value="everyone">Everyone (All Agency Roster &amp; Staff)</option>
              </optgroup>
              <optgroup label="⭐ Per Creator / Talent Roster">
                <option value="creators_all">All Creators (Talent Roster Only)</option>
                <option value="creator_single">Specific Creator (1-on-1 Broadcast Notice)</option>
              </optgroup>
              <optgroup label="👥 Per Team / Agency Staff">
                <option value="team_all">All Staff &amp; Team (Managers, Agents, Coordinators)</option>
                <option value="team_managers">Agent Managers Only</option>
                <option value="team_agents">Talent Agents Only</option>
                <option value="team_coordinators">Coordinators Only</option>
              </optgroup>
              <optgroup label="🏢 Brands &amp; Sponsors">
                <option value="brands">Brand Partners Only</option>
              </optgroup>
            </select>
          </div>

          {/* If Single Creator Chosen */}
          {audienceType === 'creator_single' && (
            <div className="p-3 bg-[#111E33] rounded-xl border border-emerald-500/30 space-y-1.5 animate-fade-in">
              <label className="text-[10px] font-mono text-emerald-400 uppercase">Select Target Creator</label>
              <select
                value={selectedCreatorHandle}
                onChange={e => setSelectedCreatorHandle(e.target.value)}
                className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-emerald-500 cursor-pointer"
              >
                {creators.map(c => (
                  <option key={c.id} value={c.handle || c.name}>
                    {c.name} ({c.handle}) — {c.niche || 'Talent'}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Announcement Title */}
          <div>
            <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1.5">
              Announcement / Text Title
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Q4 Brand Pitch Opportunities & FTC Compliance Update"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:border-sky-500 placeholder-slate-500"
            />
          </div>

          {/* Priority */}
          <div>
            <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1.5">
              Priority Level
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPriority('normal')}
                className={`py-1.5 px-3 rounded-lg font-semibold transition cursor-pointer ${
                  priority === 'normal'
                    ? 'bg-slate-700 text-white border border-white/20'
                    : 'bg-[#111E33] text-slate-400 border border-white/5 hover:text-white'
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => setPriority('important')}
                className={`py-1.5 px-3 rounded-lg font-semibold transition cursor-pointer ${
                  priority === 'important'
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-[#111E33] text-slate-400 border border-white/5 hover:text-white'
                }`}
              >
                Important
              </button>
              <button
                type="button"
                onClick={() => setPriority('urgent')}
                className={`py-1.5 px-3 rounded-lg font-semibold transition cursor-pointer ${
                  priority === 'urgent'
                    ? 'bg-rose-500 text-white font-bold'
                    : 'bg-[#111E33] text-slate-400 border border-white/5 hover:text-white'
                }`}
              >
                Urgent / Mandatory
              </button>
            </div>
          </div>

          {/* Message Content */}
          <div>
            <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1.5">
              Message Content (Text Body)
            </label>
            <textarea
              rows={4}
              required
              placeholder="Type your mass message details here..."
              value={message}
              onChange={e => setMessage(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-sky-500 placeholder-slate-500 resize-none"
            />
          </div>

          {/* Multi-Channel Distribution Controls */}
          <div className="p-3 bg-[#111E33] rounded-xl border border-white/5 space-y-2">
            <span className="text-[10px] font-mono text-slate-400 uppercase block mb-1">
              Dispatch Delivery Channels
            </span>
            <div className="space-y-1.5">
              <label className="flex items-center gap-2 cursor-pointer select-none text-slate-300">
                <input
                  type="checkbox"
                  checked={sendPush}
                  onChange={e => setSendPush(e.target.checked)}
                  className="rounded border-white/20 text-sky-500 focus:ring-0"
                />
                <span className="flex items-center gap-1.5 text-xs">
                  <Megaphone className="w-3.5 h-3.5 text-sky-400" />
                  Publish to In-App Announcements Feed & Push Notifications
                </span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none text-slate-300">
                <input
                  type="checkbox"
                  checked={sendSms}
                  onChange={e => setSendSms(e.target.checked)}
                  className="rounded border-white/20 text-sky-500 focus:ring-0"
                />
                <span className="flex items-center gap-1.5 text-xs">
                  <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                  Send Live SMS via Twilio Messaging Gateway (/api/send-sms)
                </span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none text-slate-300">
                <input
                  type="checkbox"
                  checked={sendChat}
                  onChange={e => setSendChat(e.target.checked)}
                  className="rounded border-white/20 text-sky-500 focus:ring-0"
                />
                <span className="flex items-center gap-1.5 text-xs">
                  <MessageSquare className="w-3.5 h-3.5 text-[#C9A46A]" />
                  Push Direct Broadcast Message to Agency Chat Channels
                </span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer select-none text-slate-300">
                <input
                  type="checkbox"
                  checked={sendEmail}
                  onChange={e => setSendEmail(e.target.checked)}
                  className="rounded border-white/20 text-sky-500 focus:ring-0"
                />
                <span className="flex items-center gap-1.5 text-xs">
                  <Mail className="w-3.5 h-3.5 text-purple-400" />
                  Dispatch Official Email Notice via SendGrid Gateway (/api/send-email)
                </span>
              </label>
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isSending}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer transition disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim() || !message.trim() || isSuccess || isSending}
              className={`flex-1 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition flex items-center justify-center gap-2 ${
                isSuccess 
                  ? 'bg-emerald-500 text-slate-950'
                  : isSending
                    ? 'bg-sky-600 text-white cursor-wait'
                    : 'bg-sky-500 hover:bg-sky-400 text-slate-950'
              }`}
            >
              {isSuccess ? (
                <>
                  <Check className="w-4 h-4" /> Dispatched Across Channels!
                </>
              ) : isSending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Dispatching Broadcast...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" /> Dispatch Multi-Channel Broadcast
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
