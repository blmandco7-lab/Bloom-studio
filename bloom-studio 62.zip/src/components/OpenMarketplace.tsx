/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Megaphone, Plus, Search, Filter, Sparkles, Star, CheckCircle, 
  Clock, X, Eye, ThumbsUp, Send, Check, AlertCircle, ChevronRight, 
  User, Users, Heart, Play, Film, Award, TrendingUp, DollarSign, Calendar,
  Building, Briefcase, Share2, Tag, ShieldCheck, FileText, CheckCircle2,
  ExternalLink, Layers, ArrowUpRight
} from 'lucide-react';
import { Creator, Deal } from '../types';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, setDoc, doc, getDocs } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';
import { getSafeUrl } from '../utils/security';

export interface OpenOpportunity {
  id: string;
  title: string;
  brand: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle' | 'Tech' | 'Fashion' | 'Food';
  platform: 'TikTok' | 'Instagram' | 'YouTube' | 'Multi-Platform';
  budget: string;
  budgetValue: number;
  deadline: string;
  spotsTotal: number;
  spotsFilled: number;
  deliverables: string[];
  requirements: string;
  description: string;
  status: 'Open' | 'Filling Fast' | 'Closed';
  verifiedBrand: boolean;
  featured?: boolean;
}

const DEFAULT_OPPORTUNITIES: OpenOpportunity[] = [
  {
    id: 'opp-1',
    title: 'Spring Botanical Serum UGC Reel Campaign',
    brand: 'Aura Glow Cosmetics',
    niche: 'Beauty',
    platform: 'Instagram',
    budget: '$2,500 - $4,000',
    budgetValue: 3500,
    deadline: 'In 5 days',
    spotsTotal: 8,
    spotsFilled: 5,
    deliverables: ['1x Instagram 60s Reel (Macro Texture + Routine)', '2x High-Res Product Photos', '30-Day Paid Ad Usage Rights'],
    requirements: 'Female/Male creators with clear natural skin lighting. Must demonstrate product texture on camera with FTC #ad disclosure.',
    description: 'Looking for beauty and skincare creators to highlight our new botanical glow serum. Emphasize organic ingredients, non-greasy finish, and natural radiance.',
    status: 'Filling Fast',
    verifiedBrand: true,
    featured: true
  },
  {
    id: 'opp-2',
    title: 'Smart Pet Hydration Fountain & Treat Dispenser',
    brand: 'Bark & Purr Tech',
    niche: 'Pets',
    platform: 'TikTok',
    budget: '$1,800 - $3,200',
    budgetValue: 2500,
    deadline: 'In 8 days',
    spotsTotal: 10,
    spotsFilled: 4,
    deliverables: ['1x TikTok 45s Hook-Driven UGC Video', '1x TikTok Spark Ads Code (30 Days)', 'Raw B-Roll Clips'],
    requirements: 'Dog or Cat owners. Animals must be comfortable on camera. High-energy humorous or relatable pet parent storytelling.',
    description: 'Launch of our whisper-quiet smart water fountain. Highlight filter technology, app connectivity, and pet fascination.',
    status: 'Open',
    verifiedBrand: true,
    featured: true
  },
  {
    id: 'opp-3',
    title: 'Minimalist Morning Routine & Matcha Ritual',
    brand: 'Zenith Organic Botanicals',
    niche: 'Lifestyle',
    platform: 'TikTok',
    budget: '$3,000 - $5,500',
    budgetValue: 4200,
    deadline: 'In 12 days',
    spotsTotal: 6,
    spotsFilled: 2,
    deliverables: ['2x 45s Aesthetic Lifestyle Vlogs', '1x Dedicated IG Story Series with Link Sticker'],
    requirements: 'Clean aesthetic, warm natural lighting, ASMR audio quality. Ideal for creators with a calm aesthetic and wellness focus.',
    description: 'Aesthetic morning routine integration featuring our ceremonial grade matcha and wellness elixir.',
    status: 'Open',
    verifiedBrand: true,
    featured: false
  },
  {
    id: 'opp-4',
    title: 'Ergonomic Creator Workspace & Lighting Setup',
    brand: 'Lumina Studio Pro',
    niche: 'Tech',
    platform: 'YouTube',
    budget: '$4,500 - $7,000',
    budgetValue: 5800,
    deadline: 'In 14 days',
    spotsTotal: 5,
    spotsFilled: 1,
    deliverables: ['1x 60s YouTube Short Review', '1x 90s In-Depth Integration', 'Product Gifting Included'],
    requirements: 'Tech, creator, or gaming desk setups. Clear 4K crisp visual style with sound design.',
    description: 'Demonstrating the new RGB magnetic desk bar and soft diffusion key light for content creators.',
    status: 'Open',
    verifiedBrand: true,
    featured: false
  },
  {
    id: 'opp-5',
    title: 'Sustainable Activewear Summer Capsule Drop',
    brand: 'Verde Movement',
    niche: 'Fashion',
    platform: 'Instagram',
    budget: '$2,200 - $3,800',
    budgetValue: 3000,
    deadline: 'In 7 days',
    spotsTotal: 12,
    spotsFilled: 9,
    deliverables: ['1x Transition Reel (3 Outfits)', '3x High Fashion Carousel Frames', 'Story Takeover Link'],
    requirements: 'Active lifestyle creators (pilates, running, gym, daily walks). Fit and flare aesthetic with bright daylight.',
    description: 'Summer collection made from 100% recycled ocean plastic. Celebrate sustainable motion and premium texture.',
    status: 'Filling Fast',
    verifiedBrand: true,
    featured: false
  }
];

interface OpenMarketplaceProps {
  creators?: Creator[];
  deals?: Deal[];
  setDeals?: React.Dispatch<React.SetStateAction<Deal[]>>;
  currentUser?: any;
  currentRole?: string;
  triggerNotification?: (title: string, message: string, type?: any) => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}

export default function OpenMarketplace({
  creators = [],
  deals = [],
  setDeals,
  currentUser,
  currentRole = 'director',
  triggerNotification = () => {},
  onAddActivityLog = () => {}
}: OpenMarketplaceProps) {
  const [activeTab, setActiveTab] = useState<'opportunities' | 'creators' | 'my-applications'>('opportunities');
  const [opportunities, setOpportunities] = useState<OpenOpportunity[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_open_marketplace_opps');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_OPPORTUNITIES;
  });

  const [selectedNiche, setSelectedNiche] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('All');
  const [budgetTier, setBudgetTier] = useState<string>('All');

  // Application Modal State
  const [selectedOpp, setSelectedOpp] = useState<OpenOpportunity | null>(null);
  const [selectedOppDetails, setSelectedOppDetails] = useState<OpenOpportunity | null>(null);
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [pitchCreatorHandle, setPitchCreatorHandle] = useState<string>(currentUser?.handle || '@elenarostova');
  const [pitchRateQuote, setPitchRateQuote] = useState<string>('$2,500');
  const [pitchReelUrl, setPitchReelUrl] = useState<string>('');
  const [pitchAngle, setPitchAngle] = useState<string>('');
  const [pitchSubmitting, setPitchSubmitting] = useState<boolean>(false);
  const [viewingAppPitch, setViewingAppPitch] = useState<any | null>(null);
  const [appFilter, setAppFilter] = useState<'All' | 'Submitted' | 'Shortlisted' | 'Approved' | 'Declined'>('All');

  // New Casting Post Modal State (for Brands & Staff)
  const [isCreatingPost, setIsCreatingPost] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState('');
  const [newBrand, setNewBrand] = useState(currentUser?.company || 'Bloom Studio Brand Partner');
  const [newNiche, setNewNiche] = useState<'Pets' | 'Beauty' | 'Lifestyle' | 'Tech' | 'Fashion' | 'Food'>('Beauty');
  const [newPlatform, setNewPlatform] = useState<'TikTok' | 'Instagram' | 'YouTube' | 'Multi-Platform'>('TikTok');
  const [newBudget, setNewBudget] = useState('$2,000 - $3,500');
  const [newRequirements, setNewRequirements] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newDeliverables, setNewDeliverables] = useState('1x TikTok Video (60s), 1x Usage Rights (30 Days)');

  // Applications Log State
  const [applications, setApplications] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_open_marketplace_apps');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'app-init-1',
        oppId: 'opp-1',
        oppTitle: 'Spring Botanical Serum UGC Reel Campaign',
        brand: 'Aura Glow Cosmetics',
        creatorHandle: '@elenarostova',
        rateQuote: '$3,200',
        reelUrl: 'https://instagram.com/reel/demo-skincare',
        pitchAngle: 'Natural morning bathroom lighting showing product absorption and glowing skin finish.',
        submittedAt: 'Yesterday, 4:15 PM',
        status: 'Shortlisted'
      }
    ];
  });

  useEffect(() => {
    try {
      safeStorage.setItem('wl_open_marketplace_opps', JSON.stringify(opportunities));
    } catch {}
  }, [opportunities]);

  useEffect(() => {
    try {
      safeStorage.setItem('wl_open_marketplace_apps', JSON.stringify(applications));
    } catch {}
  }, [applications]);

  // Sync with Firestore open-casting-calls and open-casting-applications
  useEffect(() => {
    let unsubCalls: (() => void) | undefined;
    let unsubApps: (() => void) | undefined;

    try {
      const qCalls = query(collection(db, 'open-casting-calls'));
      unsubCalls = onSnapshot(qCalls, (snapshot) => {
        if (!snapshot.empty) {
          const fetched: OpenOpportunity[] = [];
          snapshot.forEach(docSnap => {
            const data = docSnap.data();
            fetched.push({
              id: docSnap.id,
              title: data.title || 'Brand Casting Call',
              brand: data.brand || 'Brand Partner',
              niche: data.niche || 'Lifestyle',
              platform: data.platform || 'TikTok',
              budget: data.budget || '$2,000',
              budgetValue: Number(data.budgetValue) || 2000,
              deadline: data.deadline || 'Open',
              spotsTotal: Number(data.spotsTotal) || 5,
              spotsFilled: Number(data.spotsFilled) || 1,
              deliverables: Array.isArray(data.deliverables) ? data.deliverables : [data.requirements || '1x UGC Video'],
              requirements: data.requirements || '',
              description: data.description || '',
              status: data.status || 'Open',
              verifiedBrand: true,
              featured: !!data.featured
            });
          });
          if (fetched.length > 0) {
            setOpportunities(prev => {
              const existingIds = new Set(fetched.map(f => f.id));
              const nonOverlapping = prev.filter(p => !existingIds.has(p.id));
              return [...fetched, ...nonOverlapping];
            });
          }
        }
      }, (err) => {
        console.warn('Firestore open-casting-calls listener notice:', err?.message || err);
      });
    } catch {}

    try {
      const qApps = query(collection(db, 'open-casting-applications'));
      unsubApps = onSnapshot(qApps, (snapshot) => {
        if (!snapshot.empty) {
          const fetchedApps: any[] = [];
          snapshot.forEach(docSnap => {
            const data = docSnap.data();
            fetchedApps.push({
              id: docSnap.id,
              ...data,
              submittedAt: data.submittedAt || data.createdAt || 'Recently'
            });
          });
          if (fetchedApps.length > 0) {
            setApplications(prev => {
              const fetchedIds = new Set(fetchedApps.map(a => a.id));
              const nonOverlapping = prev.filter(p => !fetchedIds.has(p.id));
              return [...fetchedApps, ...nonOverlapping];
            });
          }
        }
      }, (err) => {
        console.warn('Firestore open-casting-applications listener notice:', err?.message || err);
      });
    } catch {}

    return () => {
      if (unsubCalls) unsubCalls();
      if (unsubApps) unsubApps();
    };
  }, []);

  // Filtered Opportunities
  const filteredOpportunities = useMemo(() => {
    return opportunities.filter(opp => {
      if (selectedNiche !== 'All' && opp.niche.toLowerCase() !== selectedNiche.toLowerCase()) return false;
      if (selectedPlatform !== 'All' && opp.platform.toLowerCase() !== selectedPlatform.toLowerCase()) return false;
      if (budgetTier === 'high' && opp.budgetValue < 4000) return false;
      if (budgetTier === 'mid' && (opp.budgetValue < 2000 || opp.budgetValue >= 4000)) return false;
      if (budgetTier === 'low' && opp.budgetValue >= 2000) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return opp.title.toLowerCase().includes(q) || 
               opp.brand.toLowerCase().includes(q) || 
               opp.requirements.toLowerCase().includes(q) ||
               opp.niche.toLowerCase().includes(q);
      }
      return true;
    });
  }, [opportunities, selectedNiche, selectedPlatform, budgetTier, searchQuery]);

  // Handle Submit Pitch
  const handleSubmitPitch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOpp) return;
    setPitchSubmitting(true);

    const effectiveCreatorId = currentUser?.uid || currentUser?.id || 'creator_' + Date.now();
    const effectiveCreatorHandle = pitchCreatorHandle || currentUser?.handle || '@creator';
    const effectiveCreatorName = currentUser?.name || effectiveCreatorHandle;
    const cleanHandleKey = effectiveCreatorHandle.replace('@', '').toLowerCase();
    const timestampIso = new Date().toISOString();

    const newApp = {
      id: 'app-' + Date.now(),
      oppId: selectedOpp.id,
      oppTitle: selectedOpp.title,
      brand: selectedOpp.brand,
      creatorId: effectiveCreatorId,
      creatorHandle: effectiveCreatorHandle,
      creatorName: effectiveCreatorName,
      rateQuote: pitchRateQuote,
      reelUrl: pitchReelUrl || 'https://vimeo.com/portfolio-demo',
      pitchAngle: pitchAngle || 'Fast-paced hook showcasing direct product efficacy and lifestyle integration.',
      submittedAt: timestampIso,
      createdAt: timestampIso,
      status: 'Submitted',
      subagency: currentUser?.subagency || 'pod_main'
    };

    try {
      // 1. Direct verified write to open-casting-applications (protected by firestore.rules)
      await setDoc(doc(db, 'open-casting-applications', newApp.id), newApp, { merge: true });

      // 1.5 Increment spotsFilled on the casting call
      try {
        const oppRef = doc(db, 'open-casting-calls', selectedOpp.id);
        const { increment } = await import('firebase/firestore');
        await setDoc(oppRef, { spotsFilled: increment(1) }, { merge: true });
      } catch (incErr) {
        console.warn('Failed to increment spotsFilled:', incErr);
      }

      // 2. Also write to nested auditions subcollection for unified architecture parity with CreatorCastingMarketplace
      try {
        const auditionRef = doc(db, 'open-casting-calls', selectedOpp.id, 'auditions', cleanHandleKey);
        await setDoc(auditionRef, {
          id: cleanHandleKey,
          oppId: selectedOpp.id,
          creatorId: effectiveCreatorId,
          creatorHandle: effectiveCreatorHandle,
          creatorName: effectiveCreatorName,
          rateQuote: pitchRateQuote,
          reelUrl: newApp.reelUrl,
          pitchAngle: newApp.pitchAngle,
          status: 'Under Review',
          submittedAt: timestampIso
        }, { merge: true });
      } catch (nestedErr) {
        console.warn('Audition subcollection sync note:', nestedErr);
      }

      // 3. Update local state
      const updated = [newApp, ...applications.filter(a => a.id !== newApp.id)];
      setApplications(updated);

      triggerNotification(
        "🎉 Pitch Submitted Successfully!", 
        `Your audition pitch for ${selectedOpp.brand} has been recorded in the casting database. The brand coordinator will review within 24 hours.`, 
        "success"
      );

      onAddActivityLog(
        pitchCreatorHandle,
        currentRole,
        `Submitted marketplace audition pitch for "${selectedOpp.title}" (${selectedOpp.brand})`
      );

      setIsApplying(false);
      setSelectedOpp(null);
      setPitchReelUrl('');
      setPitchAngle('');
    } catch (error: any) {
      console.error('Pitch Submission Error:', error);
      triggerNotification(
        "Submission Error", 
        error?.message || "Failed to persist pitch application to database. Please check your connection and try again.", 
        "danger"
      );
    } finally {
      setPitchSubmitting(false);
    }
  };

  // Handle Approve / Cast Application
  const handleApproveApplication = async (app: any) => {
    try {
      const updatedStatus = 'Approved';
      // 1. Update Firestore open-casting-applications
      await setDoc(doc(db, 'open-casting-applications', app.id), {
        ...app,
        status: updatedStatus,
        approvedAt: new Date().toISOString(),
        approvedBy: currentUser?.name || 'Director'
      }, { merge: true });

      // 2. Also update nested subcollection if oppId and handle exist
      if (app.oppId && app.creatorHandle) {
        const cleanHandle = app.creatorHandle.replace('@', '').toLowerCase();
        try {
          await setDoc(doc(db, 'open-casting-calls', app.oppId, 'auditions', cleanHandle), {
            status: 'Approved',
            reviewedAt: new Date().toISOString()
          }, { merge: true });
        } catch (err) {
          console.warn('Audition subcollection update note:', err);
        }
      }

      // 3. Update local state
      setApplications(prev => prev.map(a => a.id === app.id ? { ...a, status: updatedStatus } : a));

      // 4. Optionally create or sync deal if setDeals provided
      if (setDeals) {
        const parsedBudget = Number(String(app.rateQuote || '').replace(/[^0-9.-]+/g, '')) || 2500;
        const newDeal: Deal = {
          id: `deal_mkt_${Date.now()}`,
          brand: app.brand || 'Marketplace Brand',
          title: app.oppTitle || 'Marketplace Campaign',
          creator: app.creatorHandle || '@creator',
          platform: 'TikTok',
          value: parsedBudget,
          budget: parsedBudget,
          stage: 'Active Deliverables',
          status: 'In Progress',
          due: 'In 14 Days',
          dueDate: 'In 14 Days',
          description: 'Complete approved marketplace deliverable and submit for review.',
          deliverable: '1x 4K Video Deliverable, FTC #ad compliance verification'
        };
        setDeals(prev => [newDeal, ...prev]);
      }

      triggerNotification(
        "🎉 Creator Cast & Approved!",
        `Successfully approved ${app.creatorHandle} for "${app.oppTitle}". Assignment synced to creator workflow.`,
        "success"
      );

      onAddActivityLog(
        currentUser?.name || 'Director',
        currentRole,
        `Approved and cast ${app.creatorHandle} for marketplace campaign "${app.oppTitle}" (${app.brand})`
      );
    } catch (err: any) {
      console.error('Failed to approve application:', err);
      triggerNotification("Approval Error", err?.message || "Failed to update audition status.", "danger");
    }
  };

  const handleShortlistApplication = async (app: any) => {
    try {
      const updatedStatus = 'Shortlisted';
      await setDoc(doc(db, 'open-casting-applications', app.id), {
        ...app,
        status: updatedStatus,
        shortlistedAt: new Date().toISOString()
      }, { merge: true });

      setApplications(prev => prev.map(a => a.id === app.id ? { ...a, status: updatedStatus } : a));

      triggerNotification(
        "Application Shortlisted",
        `${app.creatorHandle} has been marked as Shortlisted for "${app.oppTitle}".`,
        "info"
      );

      onAddActivityLog(
        currentUser?.name || 'Director',
        currentRole,
        `Shortlisted ${app.creatorHandle} for marketplace campaign "${app.oppTitle}"`
      );
    } catch (err: any) {
      console.error('Failed to shortlist application:', err);
    }
  };

  const handleDeclineApplication = async (app: any) => {
    try {
      const updatedStatus = 'Declined';
      await setDoc(doc(db, 'open-casting-applications', app.id), {
        ...app,
        status: updatedStatus,
        declinedAt: new Date().toISOString()
      }, { merge: true });

      setApplications(prev => prev.map(a => a.id === app.id ? { ...a, status: updatedStatus } : a));

      triggerNotification(
        "Application Declined",
        `Audition submission for ${app.creatorHandle} was marked as declined.`,
        "warning"
      );

      onAddActivityLog(
        currentUser?.name || 'Director',
        currentRole,
        `Declined audition pitch from ${app.creatorHandle} for "${app.oppTitle}"`
      );
    } catch (err: any) {
      console.error('Failed to decline application:', err);
    }
  };

  // Filtered Applications for Staff/Creators
  const filteredApplications = useMemo(() => {
    return applications.filter(app => {
      if (appFilter === 'All') return true;
      if (appFilter === 'Submitted') return app.status === 'Submitted' || app.status === 'Under Review' || app.status === 'Pending Review';
      return (app.status || '').toLowerCase() === appFilter.toLowerCase();
    });
  }, [applications, appFilter]);

  // Handle Create New Casting Call
  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const delivArray = newDeliverables.split(',').map(s => s.trim()).filter(Boolean);
    const newOpp: OpenOpportunity = {
      id: 'opp-' + Date.now(),
      title: newTitle,
      brand: newBrand,
      niche: newNiche,
      platform: newPlatform,
      budget: newBudget,
      budgetValue: parseInt(newBudget.replace(/[^0-9]/g, '')) || 2500,
      deadline: 'In 14 days',
      spotsTotal: 6,
      spotsFilled: 0,
      deliverables: delivArray.length > 0 ? delivArray : ['1x Deliverable Video', 'Usage Rights'],
      requirements: newRequirements || 'High aesthetic lighting, authentic creator voice.',
      description: newDescription || 'Exclusive UGC campaign opportunity for registered creators.',
      status: 'Open',
      verifiedBrand: true,
      featured: true
    };

    const updated = [newOpp, ...opportunities];
    setOpportunities(updated);

    try {
      await setDoc(doc(db, 'open-casting-calls', newOpp.id), {
        ...newOpp,
        createdAt: new Date().toISOString()
      }, { merge: true });
    } catch {}

    triggerNotification(
      "🚀 Casting Call Published!", 
      `"${newTitle}" is now live on the Open Marketplace for creators to pitch.`, 
      "success"
    );

    onAddActivityLog(
      currentUser?.name || 'Staff',
      currentRole,
      `Published new Open Marketplace casting call: "${newTitle}" (${newBrand})`
    );

    setIsCreatingPost(false);
    setNewTitle('');
    setNewRequirements('');
    setNewDescription('');
  };

  return (
    <div className="space-y-6 text-slate-100 max-w-7xl mx-auto animate-fade-in">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <Megaphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                OPEN UGC DEALS MARKETPLACE
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                {opportunities.length} Live UGC Deals
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              Open Marketplace for UGC Deals
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Browse live UGC brand sponsorship campaigns, TikTok Spark ad deliverables, product reviews, and submit audition pitches.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {(currentRole === 'director' || currentRole === 'agency' || currentRole === 'subagency' || currentRole === 'agent' || currentRole === 'brand') && (
            <button
              onClick={() => setIsCreatingPost(true)}
              className="bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] px-4 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition cursor-pointer shadow-lg"
            >
              <Plus className="w-4 h-4" />
              Post Casting Call
            </button>
          )}
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-3 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('opportunities')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'opportunities'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>Brand Castings &amp; Briefs ({opportunities.length})</span>
        </button>

        {currentRole !== 'creator' && (
          <button
            onClick={() => setActiveTab('creators')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
              activeTab === 'creators'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Talent Roster Directory ({creators.length})</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('my-applications')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'my-applications'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>
            {currentRole !== 'creator'
              ? `Auditions & Casting Review (${applications.length})`
              : `My Pitches & Auditions (${applications.length})`}
          </span>
          {currentRole !== 'creator' && applications.filter(a => a.status === 'Submitted' || a.status === 'Under Review').length > 0 && (
            <span className="bg-amber-400 text-slate-900 font-mono text-[10px] font-bold px-1.5 py-0.2 rounded-full">
              {applications.filter(a => a.status === 'Submitted' || a.status === 'Under Review').length} new
            </span>
          )}
        </button>
      </div>

      {/* TAB 1: Brand Opportunities & Castings */}
      {activeTab === 'opportunities' && (
        <div className="space-y-6">
          {/* Search & Filter Bar */}
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search campaigns, brands, deliverables, or keywords..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={selectedNiche}
                onChange={(e) => setSelectedNiche(e.target.value)}
                className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="All">All Niches</option>
                <option value="Commercial">Commercial</option>
                <option value="Runway">Runway</option>
                <option value="Beauty">Beauty &amp; Skincare</option>
                <option value="Lifestyle">Lifestyle &amp; Wellness</option>
                <option value="Fashion">Fashion &amp; Apparel</option>
                <option value="Tech">Tech &amp; Studio</option>
                <option value="Pets">Pets &amp; Animals</option>
              </select>

              <select
                value={selectedPlatform}
                onChange={(e) => setSelectedPlatform(e.target.value)}
                className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="All">All Platforms</option>
                <option value="TikTok">TikTok</option>
                <option value="Instagram">Instagram</option>
                <option value="YouTube">YouTube</option>
              </select>

              <select
                value={budgetTier}
                onChange={(e) => setBudgetTier(e.target.value)}
                className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="All">All Budgets</option>
                <option value="low">Under $2,000</option>
                <option value="mid">$2,000 - $4,000</option>
                <option value="high">$4,000+</option>
              </select>
            </div>
          </div>

          {/* Opportunities Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredOpportunities.map((opp) => (
              <div 
                key={opp.id}
                className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A]/50 transition rounded-2xl p-5 flex flex-col justify-between space-y-4 relative group shadow-lg"
              >
                {opp.featured && (
                  <div className="absolute top-3 right-3 flex items-center gap-1 bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/40 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono">
                    <Sparkles className="w-3 h-3" />
                    FEATURED
                  </div>
                )}

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-white/5 border border-white/10 text-cyan-400">
                      {opp.niche}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                      {opp.platform}
                    </span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      opp.status === 'Filling Fast'
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}>
                      {opp.status}
                    </span>
                  </div>

                  <div>
                    <span className="text-xs font-mono text-[#C9A46A] flex items-center gap-1">
                      <Building className="w-3.5 h-3.5" />
                      {opp.brand}
                      {opp.verifiedBrand && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />}
                    </span>
                    <h3 className="text-base font-serif font-bold text-white mt-1 group-hover:text-[#C9A46A] transition">
                      {opp.title}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    {opp.description}
                  </p>

                  <div className="space-y-1.5 pt-2 border-t border-white/5">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block font-bold">
                      Key Deliverables:
                    </span>
                    {opp.deliverables.map((del, idx) => (
                      <div key={idx} className="flex items-center gap-1.5 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
                        <span className="line-clamp-1">{del}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 pt-3 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 uppercase block">Compensation</span>
                      <span className="text-base font-bold font-serif text-[#C9A46A]">{opp.budget}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-mono text-slate-400 uppercase block">Spots Left</span>
                      <span className="text-xs font-bold text-slate-200">
                        {opp.spotsTotal - opp.spotsFilled} of {opp.spotsTotal} open
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        setSelectedOpp(opp);
                        setIsApplying(true);
                      }}
                      className="bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] py-2 rounded-xl text-xs font-bold uppercase font-mono tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5 shadow"
                    >
                      <Send className="w-3.5 h-3.5" />
                      Pitch Reel
                    </button>
                    <button
                      onClick={() => {
                        setSelectedOppDetails(opp);
                      }}
                      className="bg-[#111E33] hover:bg-white/10 text-white border border-white/10 py-2 rounded-xl text-xs font-bold uppercase font-mono tracking-wider transition cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      Details
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: Talent Directory */}
      {activeTab === 'creators' && (
        <div className="space-y-6">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 flex justify-between items-center">
            <div>
              <h3 className="text-base font-serif font-bold text-white">Talent Roster Directory</h3>
              <p className="text-xs text-slate-400">Direct booking directory with verified engagement scores and rates.</p>
            </div>
            <span className="text-xs font-mono text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-1 rounded-full">
              {creators.length} Creators Ready to Cast
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {creators.map((c) => (
              <div key={c.id} className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4 hover:border-[#C9A46A]/40 transition">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#111E33] border border-[#C9A46A]/40 flex items-center justify-center text-lg font-bold text-[#C9A46A] overflow-hidden">
                    {c.avatar ? (
                      <img src={c.avatar} alt={c.name} className="w-full h-full object-cover" />
                    ) : (
                      c.name.charAt(0)
                    )}
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-white text-base">{c.name}</h4>
                    <span className="text-xs font-mono text-[#C9A46A]">{c.handle}</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-[#111E33] p-3 rounded-xl text-center border border-white/5">
                  <div>
                    <span className="text-[9px] font-mono text-slate-400 uppercase block">Followers</span>
                    <span className="text-xs font-bold text-white">{c.followers || '180K'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-slate-400 uppercase block">Niche</span>
                    <span className="text-xs font-bold text-cyan-400">{c.niche || 'Beauty'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-slate-400 uppercase block">Engagement</span>
                    <span className="text-xs font-bold text-emerald-400">{((c as any).engagementRate || (c as any).engagement || '4.8%')}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2">
                  {c.bio || 'Professional creator producing high-converting UGC video campaigns and social media assets.'}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                  <span className="text-xs font-mono font-bold text-[#C9A46A]">
                    Est. Rate: ${(c as any).ratePerPost || (c as any).contractRate || (c as any).rate || '2,500'}
                  </span>
                  <button
                    onClick={() => {
                      triggerNotification("Invitation Sent", `Direct casting inquiry dispatched to ${c.name} (${c.handle}).`, "success");
                    }}
                    className="bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition cursor-pointer"
                  >
                    Direct Cast
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: Auditions & Applications Review */}
      {activeTab === 'my-applications' && (
        <div className="space-y-6">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-serif font-bold text-white">
                  {currentRole !== 'creator'
                    ? 'Auditions & Casting Review Board'
                    : 'Audition Submissions & Pitch Status'}
                </h3>
                <p className="text-xs text-slate-400">
                  {currentRole !== 'creator'
                    ? 'Review creator audition pitches, shortlist promising talent, and approve applicants to cast them into campaign workflows.'
                    : 'Track real-time decisions, shortlisted pitches, and brand feedback.'}
                </p>
              </div>

              {/* Filter Pills */}
              <div className="flex flex-wrap items-center gap-1.5 bg-[#111E33] p-1 rounded-xl border border-white/5">
                {(['All', 'Submitted', 'Shortlisted', 'Approved', 'Declined'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setAppFilter(filter)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                      appFilter === filter
                        ? 'bg-[#C9A46A] text-[#0A1220] shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {filter === 'Submitted' ? 'Pending Review' : filter}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 text-[10px] font-mono text-slate-400 uppercase">
                    <th className="pb-3 px-3">Opportunity / Campaign</th>
                    <th className="pb-3 px-3">Brand</th>
                    <th className="pb-3 px-3">Creator</th>
                    <th className="pb-3 px-3">Rate Quote</th>
                    <th className="pb-3 px-3">Pitch Angle / Hook</th>
                    <th className="pb-3 px-3">Demo Reel</th>
                    <th className="pb-3 px-3">Submitted</th>
                    <th className="pb-3 px-3">Status</th>
                    {currentRole !== 'creator' && (
                      <th className="pb-3 px-3 text-right">Casting Decision</th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredApplications.length === 0 ? (
                    <tr>
                      <td colSpan={currentRole !== 'creator' ? 9 : 8} className="py-8 text-center text-slate-500 font-mono text-xs">
                        No audition applications found for "{appFilter}".
                      </td>
                    </tr>
                  ) : (
                    filteredApplications.map((app) => (
                      <tr key={app.id} className="hover:bg-white/[0.02] transition">
                        <td className="py-3 px-3 font-semibold text-white max-w-[200px]">
                          <div className="truncate font-medium">{app.oppTitle}</div>
                        </td>
                        <td className="py-3 px-3 text-[#C9A46A] font-mono whitespace-nowrap">{app.brand}</td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <span className="font-mono text-slate-200 font-bold">{app.creatorHandle}</span>
                        </td>
                        <td className="py-3 px-3 text-emerald-400 font-bold font-mono whitespace-nowrap">{app.rateQuote}</td>
                        <td className="py-3 px-3 text-slate-300 max-w-[220px]">
                          <p 
                            className="line-clamp-2 text-[11px] text-slate-300 leading-relaxed cursor-pointer hover:text-[#C9A46A] transition"
                            onClick={() => setViewingAppPitch(app)}
                            title="Click to view full pitch"
                          >
                            {app.pitchAngle || 'Standard portfolio submission.'}
                          </p>
                        </td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          {app.reelUrl ? (
                            <a
                              href={getSafeUrl(app.reelUrl)}
                              target="_blank"
                              rel="noreferrer"
                              className="text-cyan-400 hover:text-cyan-300 font-mono text-[11px] flex items-center gap-1 underline underline-offset-2"
                            >
                              <Play className="w-3 h-3 shrink-0" />
                              View Reel
                            </a>
                          ) : (
                            <span className="text-slate-500 font-mono text-[10px]">No link</span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-slate-400 font-mono whitespace-nowrap text-[11px]">{app.submittedAt}</td>
                        <td className="py-3 px-3 whitespace-nowrap">
                          <span className={`text-[10px] font-mono font-bold px-2.5 py-1 rounded-full ${
                            app.status === 'Approved' || app.status === 'Cast & Contracted'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : app.status === 'Shortlisted'
                              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                              : app.status === 'Declined'
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}>
                            {app.status === 'Submitted' ? 'Under Review' : app.status}
                          </span>
                        </td>

                        {/* Director Action Controls */}
                        {currentRole !== 'creator' && (
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              {app.status !== 'Approved' && (
                                <button
                                  onClick={() => handleApproveApplication(app)}
                                  className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold uppercase tracking-wider transition cursor-pointer flex items-center gap-1"
                                  title="Approve & Cast Creator"
                                >
                                  <Check className="w-3 h-3" />
                                  Approve
                                </button>
                              )}
                              {app.status !== 'Shortlisted' && app.status !== 'Approved' && (
                                <button
                                  onClick={() => handleShortlistApplication(app)}
                                  className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold uppercase tracking-wider transition cursor-pointer flex items-center gap-1"
                                  title="Shortlist Application"
                                >
                                  <Star className="w-3 h-3" />
                                  Shortlist
                                </button>
                              )}
                              {app.status !== 'Declined' && (
                                <button
                                  onClick={() => handleDeclineApplication(app)}
                                  className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 px-2 py-1 rounded-lg text-[11px] font-mono font-bold transition cursor-pointer flex items-center gap-1"
                                  title="Decline Application"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              )}
                              <button
                                onClick={() => setViewingAppPitch(app)}
                                className="bg-[#111E33] hover:bg-white/10 text-slate-300 border border-white/10 px-2 py-1 rounded-lg text-[11px] font-mono transition cursor-pointer"
                                title="View Full Pitch"
                              >
                                <Eye className="w-3 h-3" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Apply / Pitch Reel Modal */}
      {isApplying && selectedOpp && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl animate-scale-in">
            <div className="flex justify-between items-start border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] font-mono text-[#C9A46A] uppercase tracking-widest font-bold">
                  SUBMIT MARKETPLACE AUDITION PITCH
                </span>
                <h3 className="text-xl font-serif font-bold text-white mt-1">
                  {selectedOpp.title}
                </h3>
                <span className="text-xs text-slate-400 font-mono">Brand: {selectedOpp.brand} • Budget: {selectedOpp.budget}</span>
              </div>
              <button
                onClick={() => {
                  setIsApplying(false);
                  setSelectedOpp(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPitch} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                  Pitching Creator Handle
                </label>
                <select
                  value={pitchCreatorHandle}
                  onChange={(e) => setPitchCreatorHandle(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  {creators.map(c => (
                    <option key={c.id} value={c.handle}>{c.name} ({c.handle})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                    Rate Quote / Compensation
                  </label>
                  <input
                    type="text"
                    value={pitchRateQuote}
                    onChange={(e) => setPitchRateQuote(e.target.value)}
                    placeholder="$2,500"
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                    Portfolio / Demo Reel Link
                  </label>
                  <input
                    type="url"
                    value={pitchReelUrl}
                    onChange={(e) => setPitchReelUrl(e.target.value)}
                    placeholder="https://instagram.com/reel/..."
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                  Creative Angle &amp; Hook Proposal
                </label>
                <textarea
                  rows={3}
                  value={pitchAngle}
                  onChange={(e) => setPitchAngle(e.target.value)}
                  placeholder="Describe how you will hook viewers in the first 3 seconds and showcase the brand's key benefits..."
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="bg-[#111E33] p-3 rounded-xl border border-white/5 flex items-center gap-2 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Auditions are protected under Bloom Studio escrow terms upon acceptance.</span>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsApplying(false);
                    setSelectedOpp(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border border-white/10 text-slate-300 hover:bg-white/5 font-mono uppercase tracking-wider text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={pitchSubmitting}
                  className="bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] px-5 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider transition cursor-pointer shadow-lg flex items-center gap-2"
                >
                  {pitchSubmitting ? 'Submitting...' : 'Confirm Audition Pitch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create New Casting Call Modal */}
      {isCreatingPost && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl animate-scale-in">
            <div className="flex justify-between items-start border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] font-mono text-[#C9A46A] uppercase tracking-widest font-bold">
                  CREATE NEW CASTING CALL
                </span>
                <h3 className="text-xl font-serif font-bold text-white mt-1">
                  Publish to Open Marketplace
                </h3>
              </div>
              <button
                onClick={() => setIsCreatingPost(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                  Campaign Title
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Summer Skincare UGC Video Campaign"
                  required
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                    Brand Name
                  </label>
                  <input
                    type="text"
                    value={newBrand}
                    onChange={(e) => setNewBrand(e.target.value)}
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                    Niche Specialty
                  </label>
                  <select
                    value={newNiche}
                    onChange={(e) => setNewNiche(e.target.value as any)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="Beauty">Beauty &amp; Skincare</option>
                    <option value="Pets">Pets &amp; Animals</option>
                    <option value="Lifestyle">Lifestyle &amp; Wellness</option>
                    <option value="Tech">Tech &amp; Gaming</option>
                    <option value="Fashion">Fashion &amp; Apparel</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                    Platform
                  </label>
                  <select
                    value={newPlatform}
                    onChange={(e) => setNewPlatform(e.target.value as any)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="TikTok">TikTok</option>
                    <option value="Instagram">Instagram</option>
                    <option value="YouTube">YouTube</option>
                    <option value="Multi-Platform">Multi-Platform</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                    Budget Range
                  </label>
                  <input
                    type="text"
                    value={newBudget}
                    onChange={(e) => setNewBudget(e.target.value)}
                    placeholder="e.g. $2,500 - $4,500"
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                  Deliverables (comma-separated)
                </label>
                <input
                  type="text"
                  value={newDeliverables}
                  onChange={(e) => setNewDeliverables(e.target.value)}
                  placeholder="1x TikTok Reel (60s), 2x High-Res Photos, 30-Day Ad Rights"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-mono uppercase text-[10px] mb-1">
                  Requirements &amp; Guidelines
                </label>
                <textarea
                  rows={2}
                  value={newRequirements}
                  onChange={(e) => setNewRequirements(e.target.value)}
                  placeholder="Lighting specs, creator profile constraints, FTC guidelines..."
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingPost(false)}
                  className="px-4 py-2.5 rounded-xl border border-white/10 text-slate-300 hover:bg-white/5 font-mono uppercase tracking-wider text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] px-5 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider transition cursor-pointer shadow-lg flex items-center gap-2"
                >
                  Publish Casting Call
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Opportunity Details & Applicants Modal */}
      {selectedOppDetails && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl animate-scale-in max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2 py-0.5 rounded-full uppercase tracking-wider font-bold">
                    {selectedOppDetails.platform}
                  </span>
                  <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded-full uppercase font-bold">
                    {selectedOppDetails.niche}
                  </span>
                </div>
                <h3 className="text-xl font-serif font-bold text-white mt-1">
                  {selectedOppDetails.title}
                </h3>
                <span className="text-xs text-slate-400 font-mono">Brand: {selectedOppDetails.brand} • Compensation: {selectedOppDetails.budget}</span>
              </div>
              <button
                onClick={() => setSelectedOppDetails(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                  Campaign Description
                </span>
                <p className="text-slate-200 leading-relaxed bg-[#111E33] p-3 rounded-xl border border-white/5">
                  {selectedOppDetails.description}
                </p>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                  Requirements
                </span>
                <p className="text-slate-300 leading-relaxed bg-[#111E33] p-3 rounded-xl border border-white/5">
                  {selectedOppDetails.requirements}
                </p>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                  Deliverables
                </span>
                <div className="bg-[#111E33] p-3 rounded-xl border border-white/5 space-y-1.5">
                  {selectedOppDetails.deliverables.map((del, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-slate-200">
                      <Check className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
                      <span>{del}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Applicants for this Opportunity */}
              {currentRole !== 'creator' && (
                <div className="pt-2 border-t border-white/10 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-mono text-[#C9A46A] uppercase font-bold flex items-center gap-1.5">
                      <Users className="w-4 h-4" />
                      Audition Applicants for this Campaign ({applications.filter(a => a.oppId === selectedOppDetails.id).length})
                    </span>
                  </div>

                  {applications.filter(a => a.oppId === selectedOppDetails.id).length === 0 ? (
                    <div className="text-center py-4 bg-[#111E33] rounded-xl border border-white/5 text-slate-400 text-xs font-mono">
                      No creators have applied to this opportunity yet.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {applications.filter(a => a.oppId === selectedOppDetails.id).map(app => (
                        <div key={app.id} className="bg-[#111E33] p-3 rounded-xl border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white font-mono">{app.creatorHandle}</span>
                              <span className="text-emerald-400 font-bold font-mono">{app.rateQuote}</span>
                              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                                app.status === 'Approved' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-300'
                              }`}>
                                {app.status}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-300 line-clamp-1">{app.pitchAngle}</p>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {app.status !== 'Approved' && (
                              <button
                                onClick={() => handleApproveApplication(app)}
                                className="bg-emerald-500 hover:bg-emerald-600 text-slate-900 px-3 py-1 rounded-lg text-xs font-mono font-bold uppercase transition cursor-pointer flex items-center gap-1"
                              >
                                <Check className="w-3 h-3" />
                                Approve
                              </button>
                            )}
                            {app.status !== 'Shortlisted' && app.status !== 'Approved' && (
                              <button
                                onClick={() => handleShortlistApplication(app)}
                                className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition cursor-pointer"
                              >
                                Shortlist
                              </button>
                            )}
                            <button
                              onClick={() => setViewingAppPitch(app)}
                              className="bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded-lg text-xs font-mono transition cursor-pointer"
                            >
                              Pitch
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={() => setSelectedOppDetails(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs uppercase cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Application Pitch Modal */}
      {viewingAppPitch && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-scale-in">
            <div className="flex justify-between items-start border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] font-mono text-[#C9A46A] uppercase tracking-widest font-bold">
                  AUDITION PITCH DOSSIER
                </span>
                <h3 className="text-lg font-serif font-bold text-white mt-1">
                  {viewingAppPitch.creatorHandle} &bull; {viewingAppPitch.oppTitle}
                </h3>
                <span className="text-xs text-slate-400 font-mono">Brand: {viewingAppPitch.brand}</span>
              </div>
              <button
                onClick={() => setViewingAppPitch(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-[#111E33] p-3 rounded-xl border border-white/5">
                <div>
                  <span className="text-[10px] font-mono text-slate-400 uppercase block">Rate Quote</span>
                  <span className="text-base font-bold text-emerald-400 font-mono">{viewingAppPitch.rateQuote}</span>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-400 uppercase block">Status</span>
                  <span className="text-xs font-bold text-[#C9A46A] font-mono">{viewingAppPitch.status}</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                  Creative Angle &amp; Hook Pitch
                </span>
                <p className="text-slate-200 leading-relaxed bg-[#111E33] p-3 rounded-xl border border-white/5">
                  {viewingAppPitch.pitchAngle || 'Standard portfolio submission.'}
                </p>
              </div>

              {viewingAppPitch.reelUrl && (
                <div>
                  <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                    Demo Reel / Audition Video Link
                  </span>
                  <a
                    href={getSafeUrl(viewingAppPitch.reelUrl)}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-[#111E33] hover:bg-[#15233c] text-cyan-400 p-3 rounded-xl border border-white/5 flex items-center justify-between transition group"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Play className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span className="truncate font-mono">{viewingAppPitch.reelUrl}</span>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-white shrink-0" />
                  </a>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              {currentRole !== 'creator' ? (
                <div className="flex items-center gap-2">
                  {viewingAppPitch.status !== 'Approved' && (
                    <button
                      onClick={() => {
                        handleApproveApplication(viewingAppPitch);
                        setViewingAppPitch(null);
                      }}
                      className="bg-emerald-500 hover:bg-emerald-600 text-slate-900 px-4 py-2 rounded-xl font-mono text-xs font-bold uppercase transition cursor-pointer flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Approve &amp; Cast
                    </button>
                  )}
                  {viewingAppPitch.status !== 'Shortlisted' && (
                    <button
                      onClick={() => {
                        handleShortlistApplication(viewingAppPitch);
                        setViewingAppPitch(null);
                      }}
                      className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 px-3 py-2 rounded-xl font-mono text-xs font-bold transition cursor-pointer"
                    >
                      Shortlist
                    </button>
                  )}
                  {viewingAppPitch.status !== 'Declined' && (
                    <button
                      onClick={() => {
                        handleDeclineApplication(viewingAppPitch);
                        setViewingAppPitch(null);
                      }}
                      className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 px-3 py-2 rounded-xl font-mono text-xs font-bold transition cursor-pointer"
                    >
                      Decline
                    </button>
                  )}
                </div>
              ) : <div />}

              <button
                type="button"
                onClick={() => setViewingAppPitch(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs uppercase cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
