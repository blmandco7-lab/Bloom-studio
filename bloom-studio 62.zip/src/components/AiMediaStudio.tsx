import React, { useState } from 'react';
import { 
  Sparkles, Video, Clapperboard, Music, Film, CheckCircle2, 
  Layers, Download, Zap, Radio, ChevronRight
} from 'lucide-react';
import { VeoVideoAnimator } from './VeoVideoAnimator';
import { MusicGeneratorView } from './MusicGeneratorView';
import ShortFormVideoGenerator from './ShortFormVideoGenerator';

interface AiMediaStudioProps {
  currentUser?: any;
  currentRole?: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: string) => void;
}

export default function AiMediaStudio({
  currentUser,
  currentRole = 'director',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onAddActivityLog,
  triggerNotification
}: AiMediaStudioProps) {
  const [activeTab, setActiveTab] = useState<'veo-video' | 'animate-image' | 'music' | 'short-form'>('veo-video');

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                AI MEDIA &amp; GENERATIVE CREATIVE SUITE
              </span>
              <span className="text-xs text-purple-400 font-mono flex items-center gap-1">
                <Zap className="w-3 h-3 text-purple-400" />
                Veo 3.1 &amp; Lyria Engine Connected
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              AI Media Studio
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Consolidated generative AI workspace for text-to-video production, image animation, sound design, and UGC video compilation.
            </p>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('veo-video')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'veo-video'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Video className="w-4 h-4" />
          <span>Generate Video (Veo 3.1)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('animate-image')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'animate-image'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Clapperboard className="w-4 h-4" />
          <span>Animate Images into Video</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('music')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'music'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Music className="w-4 h-4" />
          <span>Generate Music (Lyria)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('short-form')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'short-form'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Film className="w-4 h-4" />
          <span>Short-Form Video Engine</span>
        </button>
      </div>

      {/* TAB CONTENT: Veo Video Text Mode */}
      {activeTab === 'veo-video' && (
        <VeoVideoAnimator
          creatorName={currentUser?.name || 'User'}
          creatorHandle={currentUser?.handle || '@user'}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onTriggerNotification={triggerNotification}
          onAddActivityLog={onAddActivityLog}
        />
      )}

      {/* TAB CONTENT: Animate Images Mode */}
      {activeTab === 'animate-image' && (
        <VeoVideoAnimator
          creatorName={currentUser?.name || 'User'}
          creatorHandle={currentUser?.handle || '@user'}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onTriggerNotification={triggerNotification}
          onAddActivityLog={onAddActivityLog}
        />
      )}

      {/* TAB CONTENT: Lyria Music Generator */}
      {activeTab === 'music' && (
        <MusicGeneratorView
          creatorName={currentUser?.name || 'User'}
          creatorHandle={currentUser?.handle || '@user'}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onTriggerNotification={triggerNotification}
          onAddActivityLog={onAddActivityLog}
        />
      )}

      {/* TAB CONTENT: Short-Form Video Generator */}
      {activeTab === 'short-form' && (
        <ShortFormVideoGenerator />
      )}
    </div>
  );
}
