import React, { useState, useMemo } from 'react';
import { 
  DollarSign, TrendingUp, Users, ShieldAlert, Award, Lock, 
  ArrowUpRight, CheckCircle2, PieChart, BarChart3, Landmark, 
  Layers, Download, Filter, Sparkles, ShieldCheck, RefreshCw,
  Wallet, FileText, ArrowDownRight, Briefcase
} from 'lucide-react';
import { UserProfile } from './RoleGuardedCampaignWorkspace';
import { Deal, Creator } from '../types';
import RevenueIntelligenceChart from './RevenueIntelligenceChart';

export interface CampaignSummaryRecord {
  id: string;
  brandName: string;
  campaignType: 'UGC' | 'Sourcing' | 'Whitelisting' | 'Ambassador';
  niche: 'Beauty' | 'Pets' | 'Lifestyle' | string;
  grossBrandContractValue: number;
  influencerPayout: number;
  managerCompensation: number;
  creatorHandle: string;
  isOwnerLocked: boolean;
}

interface OwnerFinancialSummaryProps {
  user: UserProfile;
  campaigns?: CampaignSummaryRecord[];
  deals?: Deal[];
  creators?: Creator[];
  invoices?: any[];
  contracts?: any[];
  primaryBrandColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'danger') => void;
}

export default function OwnerFinancialSummary({
  user,
  campaigns = [
    {
      id: "camp_1",
      brandName: "GlowLab Beauty",
      campaignType: "UGC",
      niche: "Beauty",
      grossBrandContractValue: 14500.00,
      influencerPayout: 6200.00,
      managerCompensation: 750.00,
      creatorHandle: "@glow_with_mia",
      isOwnerLocked: true
    },
    {
      id: "camp_2",
      brandName: "BarkHydrate Eco",
      campaignType: "Sourcing",
      niche: "Pets",
      grossBrandContractValue: 18000.00,
      influencerPayout: 8000.00,
      managerCompensation: 1000.00,
      creatorHandle: "@paws_and_palette",
      isOwnerLocked: true
    },
    {
      id: "camp_3",
      brandName: "Velvet Home Botanics",
      campaignType: "Whitelisting",
      niche: "Lifestyle",
      grossBrandContractValue: 9500.00,
      influencerPayout: 4200.00,
      managerCompensation: 500.00,
      creatorHandle: "@velvet_botanics",
      isOwnerLocked: true
    },
    {
      id: "camp_4",
      brandName: "NutriPaws Canine Superfood",
      campaignType: "Ambassador",
      niche: "Pets",
      grossBrandContractValue: 24000.00,
      influencerPayout: 11000.00,
      managerCompensation: 1400.00,
      creatorHandle: "@golden_chronicles",
      isOwnerLocked: true
    },
    {
      id: "camp_5",
      brandName: "AuraSilk Skincare",
      campaignType: "UGC",
      niche: "Beauty",
      grossBrandContractValue: 16500.00,
      influencerPayout: 7200.00,
      managerCompensation: 900.00,
      creatorHandle: "@elenarostova",
      isOwnerLocked: true
    }
  ],
  deals = [],
  creators = [],
  invoices = [],
  contracts = [],
  primaryBrandColor = '#C9A46A',
  onAddActivityLog,
  triggerNotification
}: OwnerFinancialSummaryProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'intelligence' | 'ledger'>('overview');
  const [selectedNiche, setSelectedNiche] = useState<string>('all');

  // Strict role check - fail closed if role is missing or unauthorized
  const normRole = (user?.role || '').toLowerCase();
  const isAuthorizedExecutive = Boolean(normRole) && [
    'owner', 'director', 'agency', 'admin', 'principal'
  ].includes(normRole);

  if (!isAuthorizedExecutive) {
    return (
      <div className="bg-[#0D1830] border border-red-500/30 rounded-3xl p-12 text-center max-w-lg mx-auto space-y-4 shadow-2xl">
        <div className="w-14 h-14 rounded-2xl bg-red-950/60 border border-red-500/40 text-red-400 flex items-center justify-center mx-auto">
          <Lock className="w-7 h-7" />
        </div>
        <h3 className="font-serif font-bold text-xl text-white">Executive Access Restricted</h3>
        <p className="text-xs text-[#7C8AA8]">
          This financial workspace is restricted to Agency Principal &amp; Director accounts.
        </p>
      </div>
    );
  }

  // Derive dynamic campaign records from live deals if present
  const effectiveCampaigns = useMemo(() => {
    if (deals && deals.length > 0) {
      return deals.map((d, idx) => {
        const budget = Number(d.budget) || 5000;
        const payout = Math.round(budget * 0.55);
        const mgrComp = Math.round(budget * 0.08);
        return {
          id: d.id || `live_camp_${idx}`,
          brandName: d.brand || 'Enterprise Partner',
          campaignType: (budget > 20000 ? 'Ambassador' : budget > 10000 ? 'UGC' : 'Sourcing') as any,
          niche: d.platform === 'TikTok' ? 'Beauty' : d.platform === 'Instagram' ? 'Lifestyle' : 'Pets',
          grossBrandContractValue: budget,
          influencerPayout: payout,
          managerCompensation: mgrComp,
          creatorHandle: d.creator || '@creator',
          isOwnerLocked: true
        };
      });
    }
    return campaigns;
  }, [deals, campaigns]);

  const filteredCampaigns = useMemo(() => {
    if (selectedNiche === 'all') return effectiveCampaigns;
    return effectiveCampaigns.filter(c => c.niche.toLowerCase() === selectedNiche.toLowerCase());
  }, [effectiveCampaigns, selectedNiche]);

  // Calculate Macro Revenue Aggregates
  const grossInboundRevenue = filteredCampaigns.reduce((acc, c) => acc + c.grossBrandContractValue, 0);
  const totalCreatorExpense = filteredCampaigns.reduce((acc, c) => acc + c.influencerPayout, 0);
  const totalManagerExpense = filteredCampaigns.reduce((acc, c) => acc + c.managerCompensation, 0);
  
  // True Net Agency Cashflow: Gross minus Creator Expense minus Manager Compensation
  const trueNetAgencyCashflow = grossInboundRevenue - totalCreatorExpense - totalManagerExpense;
  const netMarginPct = grossInboundRevenue > 0 ? ((trueNetAgencyCashflow / grossInboundRevenue) * 100).toFixed(1) : '0.0';

  const formatUSD = (val: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  return (
    <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-3xl p-6 md:p-8 shadow-2xl text-[#E6ECF8] space-y-8 max-w-7xl mx-auto">
      {/* Executive Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#111E33] border border-[#C9A46A]/30 px-3 py-1 rounded-full flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5" /> Director Executive Financial Suite
            </span>
            <span className="text-xs text-emerald-400 font-mono bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Unrestricted Principal Access
            </span>
          </div>
          <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-2">
            Bloom Studio Macro Cashflow &amp; Retained Earnings
          </h1>
          <p className="text-xs text-[#7C8AA8] mt-1">
            Real-time executive ledger tracking gross brand inflows, creator escrow disbursements, manager payouts, and net retained margins.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 bg-[#111E33] border border-white/10 p-1.5 rounded-2xl self-start md:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold font-mono uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-md'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            Overview
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('intelligence')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold font-mono uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'intelligence'
                ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-md'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            Revenue Intelligence
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ledger')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold font-mono uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'ledger'
                ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-md'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            Campaign Ledger ({filteredCampaigns.length})
          </button>
        </div>
      </div>

      {/* METRIC KPI TILES */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Gross Inbound Revenue */}
        <div className="bg-[#111E33] border border-white/10 hover:border-[#C9A46A]/40 rounded-2xl p-5 space-y-3 transition-all shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase font-mono tracking-wider text-[#7C8AA8]">
              Gross Inbound Invoicing
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#0D1830] border border-white/10 flex items-center justify-center text-[#C9A46A]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl lg:text-3xl font-bold font-mono text-white">
            {formatUSD(grossInboundRevenue)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-mono">
            <ArrowUpRight className="w-3.5 h-3.5" /> +18.4% vs last billing cycle
          </div>
        </div>

        {/* Card 2: Total Creator Escrow Expense */}
        <div className="bg-[#111E33] border border-white/10 hover:border-emerald-500/40 rounded-2xl p-5 space-y-3 transition-all shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase font-mono tracking-wider text-[#7C8AA8]">
              Creator Escrow Disbursements
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#0D1830] border border-white/10 flex items-center justify-center text-emerald-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl lg:text-3xl font-bold font-mono text-emerald-400">
            {formatUSD(totalCreatorExpense)}
          </div>
          <div className="text-[11px] text-[#7C8AA8] font-mono">
            {((totalCreatorExpense / (grossInboundRevenue || 1)) * 100).toFixed(0)}% of total brand budget
          </div>
        </div>

        {/* Card 3: Manager Commission Allocation */}
        <div className="bg-[#111E33] border border-white/10 hover:border-amber-500/40 rounded-2xl p-5 space-y-3 transition-all shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase font-mono tracking-wider text-[#7C8AA8]">
              Staff &amp; Coordinator Pay
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#0D1830] border border-white/10 flex items-center justify-center text-amber-400">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl lg:text-3xl font-bold font-mono text-amber-300">
            {formatUSD(totalManagerExpense)}
          </div>
          <div className="text-[11px] text-[#7C8AA8] font-mono">
            Performance commissions paid
          </div>
        </div>

        {/* Card 4: True Net Agency Retained Earnings */}
        <div className="bg-gradient-to-br from-[#111E33] to-[#1a2b47] border border-[#C9A46A]/60 rounded-2xl p-5 space-y-3 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase font-mono tracking-wider text-[#C9A46A] font-bold">
              Director Retained Net Profit
            </span>
            <div className="w-8 h-8 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A]">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl lg:text-3xl font-bold font-mono text-[#C9A46A]">
            {formatUSD(trueNetAgencyCashflow)}
          </div>
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 pt-1 border-t border-white/10">
            <span>Net Agency Margin:</span>
            <span className="text-emerald-400 font-bold">{netMarginPct}%</span>
          </div>
        </div>
      </div>

      {/* CONDITIONAL TAB VIEWS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Executive Breakdown Visual */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-[#111E33] border border-white/10 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-[#C9A46A]" /> Cashflow Split Architecture
                </h3>
                <span className="text-[11px] text-[#7C8AA8] font-mono">
                  Automated Settlement Engine
                </span>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
                    <span>Creator Direct Payouts ({((totalCreatorExpense / (grossInboundRevenue || 1)) * 100).toFixed(1)}%)</span>
                    <span className="text-emerald-400 font-bold">{formatUSD(totalCreatorExpense)}</span>
                  </div>
                  <div className="h-3 w-full bg-[#0D1830] rounded-full overflow-hidden border border-white/5">
                    <div 
                      className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, (totalCreatorExpense / (grossInboundRevenue || 1)) * 100)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
                    <span>Director / Agency Net Retained ({netMarginPct}%)</span>
                    <span className="text-[#C9A46A] font-bold">{formatUSD(trueNetAgencyCashflow)}</span>
                  </div>
                  <div className="h-3 w-full bg-[#0D1830] rounded-full overflow-hidden border border-white/5">
                    <div 
                      className="h-full bg-[#C9A46A] rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, (trueNetAgencyCashflow / (grossInboundRevenue || 1)) * 100)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-mono text-slate-300 mb-1.5">
                    <span>Agent &amp; Coordinator Performance Overhead ({((totalManagerExpense / (grossInboundRevenue || 1)) * 100).toFixed(1)}%)</span>
                    <span className="text-amber-300 font-bold">{formatUSD(totalManagerExpense)}</span>
                  </div>
                  <div className="h-3 w-full bg-[#0D1830] rounded-full overflow-hidden border border-white/5">
                    <div 
                      className="h-full bg-amber-400 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, (totalManagerExpense / (grossInboundRevenue || 1)) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="p-4 bg-[#0D1830] rounded-xl border border-white/5 text-xs text-[#7C8AA8] space-y-1">
                <span className="font-semibold text-white">Escrow Guard Compliance:</span>
                <p>
                  All creator disbursements are held in secure escrow until deliverable link validation, FTC disclosure verification, and brand sign-off are completed.
                </p>
              </div>
            </div>

            {/* Quick Executive Actions */}
            <div className="bg-[#111E33] border border-white/10 rounded-2xl p-6 space-y-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                <Wallet className="w-4 h-4 text-[#C9A46A]" /> Executive Quick Actions
              </h3>
              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => setActiveTab('ledger')}
                  className="w-full bg-[#0D1830] hover:bg-[#16243F] border border-white/10 hover:border-[#C9A46A]/40 p-3.5 rounded-xl text-xs font-medium text-left flex items-center justify-between transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-[#C9A46A]" />
                    <span>Audit Individual Campaign P&amp;L</span>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-[#7C8AA8]" />
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('intelligence')}
                  className="w-full bg-[#0D1830] hover:bg-[#16243F] border border-white/10 hover:border-[#C9A46A]/40 p-3.5 rounded-xl text-xs font-medium text-left flex items-center justify-between transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <PieChart className="w-4 h-4 text-emerald-400" />
                    <span>Open Revenue Intelligence Studio</span>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-[#7C8AA8]" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (triggerNotification) {
                      triggerNotification('Escrow Balanced', 'All creator escrow allocations synchronized with Stripe/ACH ledger.', 'success');
                    }
                  }}
                  className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold p-3.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg"
                >
                  <RefreshCw className="w-4 h-4" /> Run Instant Escrow Rebalance
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FULL REVENUE INTELLIGENCE STUDIO */}
      {activeTab === 'intelligence' && (
        <div className="space-y-4 animate-fade-in">
          <RevenueIntelligenceChart
            deals={deals.length > 0 ? deals : effectiveCampaigns.map(c => ({
              id: c.id,
              brand: c.brandName,
              creator: c.creatorHandle,
              budget: c.grossBrandContractValue,
              stage: 'Completed' as any,
              platform: c.niche === 'Beauty' ? 'TikTok' : 'Instagram',
              due: '2026-09-15',
              notes: `${c.campaignType} Campaign`
            }))}
            creators={creators}
            invoices={invoices}
            contracts={contracts}
            currentRole={user?.role || 'creator'}
            currentUser={user}
            primaryBrandColor={primaryBrandColor}
          />
        </div>
      )}

      {/* TAB 3: CAMPAIGN MARGIN ROSTER & LEDGER */}
      {activeTab === 'ledger' && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
                Director Campaign Ledger &amp; Margin Roster
              </h3>
              <span className="text-[10px] bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-mono px-2 py-0.5 rounded-md">
                Live Audited
              </span>
            </div>

            {/* Filter by Niche */}
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-[#7C8AA8]" />
              <select
                value={selectedNiche}
                onChange={e => setSelectedNiche(e.target.value)}
                className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white outline-none focus:border-[#C9A46A]"
              >
                <option value="all">All Campaign Niches</option>
                <option value="beauty">Beauty &amp; Skincare</option>
                <option value="pets">Pets &amp; Canine</option>
                <option value="lifestyle">Lifestyle &amp; Home</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto border border-white/10 rounded-2xl bg-[#111E33]/60">
            <table className="w-full text-left text-xs text-[#E6ECF8]">
              <thead className="bg-[#111E33] text-[11px] uppercase font-mono text-[#7C8AA8] border-b border-white/10">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Brand &amp; Campaign Type</th>
                  <th className="py-3.5 px-4 font-semibold">Talent Assigned</th>
                  <th className="py-3.5 px-4 font-semibold">Total Client Fee</th>
                  <th className="py-3.5 px-4 font-semibold">Talent Spend</th>
                  <th className="py-3.5 px-4 font-semibold">Coordinator Pay</th>
                  <th className="py-3.5 px-4 font-semibold">Director Retained Profit</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Escrow Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono">
                {filteredCampaigns.map((camp) => {
                  const profit = camp.grossBrandContractValue - camp.influencerPayout - camp.managerCompensation;
                  return (
                    <tr key={camp.id} className="hover:bg-[#111E33]/90 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-white font-sans">{camp.brandName}</div>
                        <div className="text-[10px] text-[#7C8AA8]">
                          {camp.campaignType} &bull; {camp.niche}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-[#C9A46A] font-semibold">
                        {camp.creatorHandle}
                      </td>
                      <td className="py-3.5 px-4 text-white">
                        {formatUSD(camp.grossBrandContractValue)}
                      </td>
                      <td className="py-3.5 px-4 text-emerald-400 font-semibold">
                        {formatUSD(camp.influencerPayout)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {formatUSD(camp.managerCompensation)}
                      </td>
                      <td className="py-3.5 px-4 text-[#C9A46A] font-bold">
                        {formatUSD(profit)}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <span className="inline-flex items-center gap-1 text-[10px] bg-[#0D1830] px-2.5 py-1 rounded-md border border-[#C9A46A]/30 text-[#C9A46A]">
                          <CheckCircle2 className="w-3 h-3 text-[#C9A46A]" />
                          Contract Finalized
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
