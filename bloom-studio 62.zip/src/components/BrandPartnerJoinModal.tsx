import React, { useState, useEffect } from 'react';
import { Building, ShieldCheck, Key, ArrowRight, X, CheckCircle2, Lock, AlertCircle, Link2 } from 'lucide-react';
import { ReviewItem } from '../types';

interface BrandPartnerJoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBrandPartnerLogin: (brandEmail: string, brandName: string, partnerCode?: string, activeDeliverableId?: string) => void;
  primaryBrandColor?: string;
  agencyName?: string;
  reviewsList?: ReviewItem[];
  initialToken?: string;
  initialLink?: string;
  initialBrandName?: string;
}

export default function BrandPartnerJoinModal({
  isOpen,
  onClose,
  onBrandPartnerLogin,
  primaryBrandColor = '#C9A46A',
  agencyName = 'Bloom Studio',
  reviewsList = [],
  initialToken = '',
  initialLink = '',
  initialBrandName = '',
}: BrandPartnerJoinModalProps) {
  const [activeTab, setActiveTab] = useState<'token' | 'account'>('token');
  
  // Token & Access Link Security Verification State
  const [inputAgencyName, setInputAgencyName] = useState('');
  const [accessLinkOrToken, setAccessLinkOrToken] = useState(initialToken || initialLink || '');
  const [partnerBrandName, setPartnerBrandName] = useState(initialBrandName || '');
  const [verificationError, setVerificationError] = useState<string | null>(null);

  // Account state
  const [brandEmail, setBrandEmail] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [contactName, setContactName] = useState('');

  useEffect(() => {
    if (initialToken || initialLink) {
      setAccessLinkOrToken(initialToken || initialLink);
    }
    if (initialBrandName) {
      setPartnerBrandName(initialBrandName);
    }
  }, [initialToken, initialLink, initialBrandName]);

  if (!isOpen) return null;

  // Helper function to extract token or deliverable ID from link or raw input
  const extractTokenAndDeliverable = (rawInput: string) => {
    const trimmed = rawInput.trim();
    let token = '';
    let deliverableId = '';

    if (trimmed.includes('?') || trimmed.includes('token=') || trimmed.includes('deliverable=')) {
      try {
        const urlObj = new URL(trimmed.startsWith('http') ? trimmed : `https://dummy.agency/${trimmed}`);
        token = urlObj.searchParams.get('token') || '';
        deliverableId = urlObj.searchParams.get('deliverable') || '';
      } catch {
        const tokenMatch = trimmed.match(/token=([^&]+)/i);
        if (tokenMatch) token = decodeURIComponent(tokenMatch[1]);
        const delMatch = trimmed.match(/deliverable=([^&]+)/i);
        if (delMatch) deliverableId = decodeURIComponent(delMatch[1]);
      }
    }

    if (!token && !deliverableId) {
      if (trimmed.toUpperCase().startsWith('ROOM-')) {
        token = trimmed.toUpperCase();
      } else {
        deliverableId = trimmed;
      }
    }

    return { token: token.toUpperCase(), deliverableId };
  };

  const handleSecurityVerification = (e: React.FormEvent) => {
    e.preventDefault();
    setVerificationError(null);

    const typedAgency = inputAgencyName.trim().toLowerCase();
    const activeAgencyLower = (agencyName || 'bloom studio').toLowerCase();

    // 1. Verify Agency Name matches
    const isAgencyMatch = 
      typedAgency.length > 0 &&
      (activeAgencyLower.includes(typedAgency) || 
       typedAgency.includes(activeAgencyLower) || 
       typedAgency.includes('bloom') || 
       activeAgencyLower.includes('bloom'));

    if (!typedAgency) {
      setVerificationError("Please enter your Agency Name to verify authorization.");
      return;
    }

    if (!isAgencyMatch) {
      setVerificationError(`Agency verification failed: "${inputAgencyName.trim()}" does not match the agency that generated this secure access link.`);
      return;
    }

    // 2. Extract and match Access Link / Token
    const rawInput = accessLinkOrToken.trim();
    if (!rawInput) {
      setVerificationError("Please enter your Access Link or Security Token.");
      return;
    }

    const { token, deliverableId } = extractTokenAndDeliverable(rawInput);

    // Look for matching review in available reviews
    const matchingReview = reviewsList.find(r => {
      const generatedToken = `ROOM-${r.id.substring(0, 8).toUpperCase()}`;
      const matchesToken = token && (generatedToken === token || r.id.toUpperCase() === token);
      const matchesDeliverable = deliverableId && (r.id === deliverableId || r.id.toLowerCase() === deliverableId.toLowerCase());
      const matchesRaw = r.id === rawInput || generatedToken === rawInput.toUpperCase();
      return matchesToken || matchesDeliverable || matchesRaw;
    });

    if (!matchingReview) {
      setVerificationError("Invalid Access Link / Security Token. No active deliverable was found matching this key for this agency.");
      return;
    }

    // Successfully verified!
    const verifiedBrand = matchingReview.brand || partnerBrandName.trim() || 'Partner Brand';
    const email = `${verifiedBrand.toLowerCase().replace(/[^a-z0-9]/g, '')}@partner.client`;
    const verifiedToken = token || `ROOM-${matchingReview.id.substring(0, 8).toUpperCase()}`;

    onBrandPartnerLogin(email, verifiedBrand, verifiedToken, matchingReview.id);
    onClose();
  };

  const handleAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandEmail.trim()) return;
    const bName = companyName.trim() || brandEmail.split('@')[0] || 'Partner Brand';
    onBrandPartnerLogin(brandEmail.trim(), bName);
    onClose();
  };

  return (
    <div
      id="brand-partner-join-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        id="brand-partner-join-modal"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-[#0A1322] border border-[#C9A46A]/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-150 text-slate-100 font-sans"
      >
        {/* Header */}
        <div className="p-5 border-b border-white/10 bg-[#0E1A30] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#C9A46A]/20 text-[#C9A46A] flex items-center justify-center border border-[#C9A46A]/30 shrink-0">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-serif font-bold text-white">Brand Partner Access</h3>
                <span className="text-[9px] font-mono uppercase px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold">
                  Secure Verification Gate
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Enter your Agency Name &amp; Access Link/Token to pull up your deliverables.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Strict Distinction Banner: Brands are NOT Staff */}
        <div className="px-5 py-3 bg-amber-500/10 border-b border-amber-500/20 flex items-start gap-2.5">
          <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-[11px] text-amber-200/90 leading-relaxed font-sans">
            <strong className="text-white font-semibold">Strict Client Isolation: </strong>
            Brand partner tokens only unlock your authorized campaign deliverables. Direct portal access is gated behind agency and token verification.
          </div>
        </div>

        {/* Tab Selection */}
        <div className="px-5 pt-4 flex gap-2 border-b border-white/5 bg-[#0D182A]">
          <button
            type="button"
            onClick={() => setActiveTab('token')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'token'
                ? 'border-[#C9A46A] text-[#C9A46A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5" /> Agency &amp; Token Verification
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('account')}
            className={`pb-2.5 px-3 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'account'
                ? 'border-[#C9A46A] text-[#C9A46A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" /> Brand Partner Sign-In
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4">
          {verificationError && (
            <div className="p-3 bg-rose-950/50 border border-rose-500/40 rounded-xl flex items-start gap-2.5 text-xs text-rose-200 animate-in fade-in duration-150">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold block text-rose-100">Verification Error</strong>
                <span>{verificationError}</span>
              </div>
            </div>
          )}

          {activeTab === 'token' ? (
            <form onSubmit={handleSecurityVerification} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Agency Name <span className="text-[#C9A46A]">*</span></span>
                  <span className="text-[10px] text-slate-500 font-normal">e.g., {agencyName || 'Bloom Studio'}</span>
                </label>
                <input
                  type="text"
                  required
                  value={inputAgencyName}
                  onChange={(e) => {
                    setInputAgencyName(e.target.value);
                    setVerificationError(null);
                  }}
                  placeholder="Type agency name (e.g., Bloom Studio)"
                  className="w-full bg-[#121F38] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Access Link or Security Token <span className="text-[#C9A46A]">*</span></span>
                  <span className="text-[10px] text-slate-500 font-normal">Token or full URL</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={accessLinkOrToken}
                    onChange={(e) => {
                      setAccessLinkOrToken(e.target.value);
                      setVerificationError(null);
                    }}
                    placeholder="e.g., ROOM-C780F74C or paste https://..."
                    className="w-full bg-[#121F38] border border-white/10 rounded-xl pl-9 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A] font-mono"
                  />
                  <Link2 className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                </div>
                <p className="text-[10px] text-slate-400">
                  Provided in your campaign email or review invitation link.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-[#C9A46A] hover:bg-[#b59157] text-[#0A1322] font-mono text-xs font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-[#C9A46A]/20"
                >
                  <ShieldCheck className="w-4 h-4" /> Verify &amp; Pull Up My Deliverables
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleAccountSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Brand Work Email <span className="text-[#C9A46A]">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={brandEmail}
                  onChange={(e) => setBrandEmail(e.target.value)}
                  placeholder="marketing@brand.com"
                  className="w-full bg-[#121F38] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Company / Organization Name
                </label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g., Red Bull North America"
                  className="w-full bg-[#121F38] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Primary Contact Person
                </label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="e.g., Sarah Chen, Brand Partnerships Lead"
                  className="w-full bg-[#121F38] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-[#C9A46A] hover:bg-[#b59157] text-[#0A1322] font-mono text-xs font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-[#C9A46A]/20"
                >
                  Sign In to Brand Partner Dashboard <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-[#080E1B] border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> End-to-end Encrypted Deliverable Review
          </span>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
