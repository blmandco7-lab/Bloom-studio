import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, doc, setDoc, deleteDoc, query, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Tag, Plus, CheckCircle, Clock, Search, Shield, User, Briefcase, DollarSign, Calendar } from 'lucide-react';
import { Creator, Deal } from '../types';

interface PartyDealAssignmentsProps {
  currentUser?: any;
  currentRole?: string;
  creators?: Creator[];
  deals?: Deal[];
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

export default function PartyDealAssignments({
  currentUser,
  currentRole = 'agent',
  creators = [],
  deals = [],
  onAddActivityLog,
  triggerNotification
}: PartyDealAssignmentsProps) {
  const [dbAssignments, setDbAssignments] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const roleLower = (currentRole || '').toLowerCase();
  const isDirector = roleLower === 'director' || roleLower === 'agency' || roleLower === 'platform_owner' || !!currentUser?.isPlatformOwner;
  const isStaff = ['agent', 'agentmgr', 'coordinator', 'director', 'agency'].includes(roleLower);

  useEffect(() => {
    const colRef = collection(db, 'studio-deal-assignments');
    const q = isDirector
      ? colRef
      : query(colRef, where('subagency', '==', currentUser?.subagency || 'pod_main'));

    const unsub = onSnapshot(q, (snap) => {
      const all = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setDbAssignments(all);
    }, (err) => {
      console.warn('Assignments snapshot notice:', err);
    });
    return () => unsub();
  }, [currentUser, isDirector]);

  // Combine deals and studio-deal-assignments to track every deal and assignment past and present
  const combinedAssignments = useMemo(() => {
    const list: any[] = [...dbAssignments];
    
    // Also map deals into assignment view if not already present
    deals.forEach(d => {
      if (!list.some(item => item.dealId === d.id || item.id === `deal-asg-${d.id}`)) {
        list.push({
          id: `deal-asg-${d.id}`,
          dealId: d.id,
          dealName: d.title || `${d.brand} x ${d.creator}`,
          brand: d.brand,
          creator: d.creator,
          creatorHandle: d.creatorHandle,
          agent: d.agent || currentUser?.name,
          assigneeName: d.agent || currentUser?.name,
          assigneeId: currentUser?.id,
          status: d.stage || 'Active',
          budget: d.budget || d.value || 0,
          due: d.due || '2026-Q3',
          deliverable: d.deliverable || 'Sponsored Campaign',
          subagency: d.subagency || currentUser?.subagency || 'pod_main',
          updatedAt: new Date().toISOString()
        });
      }
    });

    return list;
  }, [dbAssignments, deals, currentUser]);

  // Filtering based on role
  const filteredAssignments = useMemo(() => {
    let result = combinedAssignments;

    // If director, they see ALL staff deals and assignments in real time
    if (!isDirector) {
      // Agents, Agent Managers, Coordinators: ONLY see their own information no one else's
      const userName = (currentUser?.name || '').toLowerCase();
      const userHandle = (currentUser?.handle || '').toLowerCase();
      const userId = currentUser?.id;

      result = result.filter(item => {
        const itemAgent = (item.agent || '').toLowerCase();
        const itemAssignee = (item.assigneeName || '').toLowerCase();
        const itemAssigneeId = item.assigneeId;
        const itemCreator = (item.creator || '').toLowerCase();

        return (
          (userId && itemAssigneeId === userId) ||
          (userName && (itemAgent.includes(userName) || itemAssignee.includes(userName) || userName.includes(itemAgent))) ||
          (userHandle && itemAgent.includes(userHandle)) ||
          (userId && item.userId === userId)
        );
      });
    }

    // Search and status filters
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      result = result.filter(i => 
        (i.dealName || '').toLowerCase().includes(term) ||
        (i.brand || '').toLowerCase().includes(term) ||
        (i.creator || '').toLowerCase().includes(term) ||
        (i.agent || '').toLowerCase().includes(term)
      );
    }

    if (statusFilter !== 'all') {
      result = result.filter(i => (i.status || '').toLowerCase() === statusFilter.toLowerCase());
    }

    return result;
  }, [combinedAssignments, isDirector, currentUser, searchTerm, statusFilter]);

  const totalValue = filteredAssignments.reduce((acc, curr) => acc + Number(curr.budget || 0), 0);
  const activeCount = filteredAssignments.filter(i => (i.status || '').toLowerCase() !== 'completed' && (i.status || '').toLowerCase() !== 'closed').length;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0E1C38] via-[#142850] to-[#0A162B] border border-[#C9A46A]/20 rounded-3xl p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#C9A46A]/10 rounded-xl text-[#C9A46A]">
              <Tag className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white tracking-wide">
              {isDirector ? 'Real-Time Agency Staff Deal & Assignment Monitor' : 'My Deal Assignments & Historical Tracker'}
            </h1>
          </div>
          <p className="text-xs text-[#B8C0D4] max-w-2xl">
            {isDirector 
              ? 'Executive oversight tracking all staff deals, brand contracts, and active/past assignments across the agency in real time.'
              : 'Tracking every active and past deal assignment assigned to your roster. Fully scoped to your personal portfolio.'}
          </p>
        </div>

        {/* Live Metrics */}
        <div className="flex items-center gap-3 bg-[#0B1B3D] px-4 py-3 rounded-2xl border border-white/10 shrink-0">
          <Briefcase className="w-5 h-5 text-[#C9A46A]" />
          <div>
            <div className="text-[10px] font-mono text-slate-400 uppercase">Assigned Records</div>
            <div className="text-xs font-bold text-white">{filteredAssignments.length} Total ({activeCount} Active)</div>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#142850] border border-white/10 p-4 rounded-2xl shadow-xl">
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search deals, brands, creators..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 focus:border-[#C9A46A] outline-none"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:border-[#C9A46A] outline-none"
          >
            <option value="all">All Statuses (Active &amp; Past)</option>
            <option value="Active">Active Negotiation / Pitch</option>
            <option value="Signed">Signed &amp; Confirmed</option>
            <option value="Completed">Completed / Closed</option>
          </select>
        </div>
      </div>

      {/* Assignments Table */}
      <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 text-[10px] uppercase">
                <th className="py-3 px-3">Deal / Campaign</th>
                <th className="py-3 px-3">Brand</th>
                <th className="py-3 px-3">Creator</th>
                <th className="py-3 px-3">Assigned Staff / Agent</th>
                <th className="py-3 px-3">Budget / Value</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Due Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredAssignments.map((a: any) => (
                <tr key={a.id} className="hover:bg-white/[0.02] transition-all">
                  <td className="py-4 px-3">
                    <div className="font-bold text-white font-sans">{a.dealName || a.title || 'Brand Deal'}</div>
                    <span className="text-[10px] text-slate-400 font-mono">{a.deliverable || 'Sponsored Deliverable'}</span>
                  </td>
                  <td className="py-4 px-3 text-[#C9A46A] font-bold">
                    {a.brand || 'Direct Brand'}
                  </td>
                  <td className="py-4 px-3 text-slate-200">
                    {a.creator || a.creatorHandle || 'Assigned Creator'}
                  </td>
                  <td className="py-4 px-3 text-cyan-300">
                    <div className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{a.agent || a.assigneeName || currentUser?.name || 'Assigned Staff'}</span>
                    </div>
                  </td>
                  <td className="py-4 px-3 text-emerald-400 font-bold">
                    ${Number(a.budget || a.value || 0).toLocaleString()}
                  </td>
                  <td className="py-4 px-3">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      (a.status || '').toLowerCase().includes('completed') || (a.status || '').toLowerCase().includes('closed')
                        ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                        : 'bg-amber-500/10 border border-amber-500/20 text-amber-400'
                    }`}>
                      {(a.status || 'Active').toUpperCase()}
                    </span>
                  </td>
                  <td className="py-4 px-3 text-slate-300">
                    {a.due || 'TBD'}
                  </td>
                </tr>
              ))}
              {filteredAssignments.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 space-y-2">
                    <Briefcase className="w-8 h-8 text-slate-500 mx-auto" />
                    <p className="text-sm font-sans font-bold text-white">No deal assignments found</p>
                    <p className="text-xs text-slate-500">
                      {isDirector 
                        ? 'No staff deal assignments have been recorded across the agency yet.' 
                        : 'You currently have no active or historical deal assignments in your personal portfolio.'}
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
