import React, { useState, useMemo } from 'react';
import { 
  BookOpen, Search, Filter, Sparkles, FileText, CheckCircle2, 
  Bookmark, Share2, Copy, Check, Download, ArrowRight, ShieldCheck, 
  DollarSign, Video, Users, HelpCircle, ChevronRight, Tag
} from 'lucide-react';

export interface KBArticle {
  id: string;
  title: string;
  category: 'Creator Management' | 'Brand Deals & Pricing' | 'Escrow & Payouts' | 'FTC Compliance' | 'UGC Production SOPs' | 'Legal & Contracts';
  readTime: string;
  lastUpdated: string;
  tags: string[];
  summary: string;
  content: string;
  keyTakeaways: string[];
  templateSnippet?: string;
}

const KB_ARTICLES: KBArticle[] = [
  {
    id: 'kb-1',
    title: 'Standard Agency Creator Rate Card & Usage Rights Multipliers',
    category: 'Brand Deals & Pricing',
    readTime: '6 min read',
    lastUpdated: 'August 2026',
    tags: ['Pricing', 'Whitelisting', 'Buyouts', 'Spark Ads'],
    summary: 'Institutional pricing formulas for short-form UGC, whitelisted Spark Ads, organic organic retainers, and full commercial copyright buyouts.',
    keyTakeaways: [
      'Base UGC video deliverable: $500 - $2,500 depending on creator tier and production equipment.',
      '30-Day Paid Spark Ads Whitelisting: +30% to +50% over organic base rate.',
      'Perpetual Digital Usage Buyout: +100% to +150% surcharge on gross contract value.',
      'Category Exclusivity surcharge: +20% per month of active exclusivity.'
    ],
    templateSnippet: `PRICING CLAUSE TEMPLATE:
"Total Campaign Fee includes: (a) One (1) 60-second vertical 9:16 UGC video deliverable, and (b) 30-day paid media amplification rights via Meta/TikTok whitelist authorization. Any extension beyond thirty (30) days shall be billed at $500/month."`,
    content: `### 1. Base Compensation Structure
Every creator partnership must establish a transparent baseline fee covering script creation, filming, and one (1) round of minor edits.

- **Nano Tier (10k - 50k reach):** $400 - $800 per 9:16 deliverable.
- **Micro Tier (50k - 200k reach):** $800 - $2,000 per 9:16 deliverable.
- **Mid-Tier & Macro (200k+ reach):** $2,000 - $6,000+ per package.

### 2. Digital Whitelisting & Amplification (Spark Ads)
When a brand requests creator access codes for Spark Ads or Meta Partnership Ads:
- Always enforce an expiration term (e.g. 30, 60, or 90 days).
- Do not grant unrestricted, perpetual ad code usage without an explicit buyout fee.

### 3. Exclusivity Guidelines
If a beauty or pet nutrition brand demands that the creator cannot work with competing brands:
- Restrict exclusivity strictly to direct product competitors (e.g. "Acne spot treatment" rather than all "Skincare").
- Charge a minimum 20% premium per month.`
  },
  {
    id: 'kb-2',
    title: 'Escrow Settlement & Payout Timeline Protocols',
    category: 'Escrow & Payouts',
    readTime: '5 min read',
    lastUpdated: 'August 2026',
    tags: ['Escrow', 'Payouts', 'Net-30', 'Talent Bank'],
    summary: 'End-to-end SOP for client escrow deposits, deliverable sign-offs, and automated talent payout disbursements.',
    keyTakeaways: [
      'Brands deposit funds into Bloom Agency Escrow before creator begins production.',
      'Deliverable sign-off unlocks 100% of the creator allocated payout.',
      'Net-30 and Net-15 client terms are isolated from creator payout ledgers.'
    ],
    templateSnippet: `ESCROW TERMS:
"All talent fees are safeguarded in Agency Escrow. Creator disbursement is initiated within 24 business hours of final deliverable acceptance by the Brand Director."`,
    content: `### Escrow Verification Protocol
1. **Intake & Deposit Confirmation:** When a brand signs a deal brief, the client must deposit the full campaign balance or provide a verified Net-15 corporate credit card hold.
2. **Deliverable Submission:** The creator uploads the watermarked draft via the Bloom Content Portal.
3. **Director & Brand Approval:** The draft is reviewed for aesthetic quality and FTC tags. Once approved, the escrow lock turns green.
4. **Disbursement:** The payout is immediately queued for talent bank ACH or Stripe transfer.`
  },
  {
    id: 'kb-3',
    title: 'FTC Social Media Endorsement Compliance Checklist',
    category: 'FTC Compliance',
    readTime: '4 min read',
    lastUpdated: 'August 2026',
    tags: ['FTC', 'Disclosures', 'Legal', 'Ad Tagging'],
    summary: 'Mandatory guidelines to prevent regulatory warnings, brand penalties, and social platform shadowbans.',
    keyTakeaways: [
      'Prominently display #ad or #sponsored in the first three lines of the caption.',
      'For video formats, include high-contrast text overlay (#ad) on screen for at least 3 seconds.',
      'Never hide disclosure tags among strings of 30 hashtags.',
      'Creators must genuinely use and honestly review gifted or paid products.'
    ],
    templateSnippet: `MANDATORY CAPTION CLAUSE:
"Paid partnership with [Brand Name]. #ad #sponsored. Results may vary based on individual skin type."`,
    content: `### 1. Visual Disclosures
Text disclosures must be easily readable on mobile devices:
- High-contrast colors (e.g. white text with dark outline).
- Sized adequately to read on mobile screen without zooming.
- Placed above the social platform's UI icons (like, comment, share buttons).

### 2. Audio Disclosures
If a video contains spoken commentary about product benefits, the creator should verbally state the sponsorship (e.g. "Thanks to Aura Beauty for partnering on today's routine").`
  },
  {
    id: 'kb-4',
    title: 'High-Converting UGC Video Architecture & Hook Formula',
    category: 'UGC Production SOPs',
    readTime: '7 min read',
    lastUpdated: 'August 2026',
    tags: ['UGC', 'Video Hooks', 'Scripting', 'TikTok', 'Reels'],
    summary: 'The battle-tested 4-step framework for scripting 9:16 videos that stop the scroll and drive verified 3x+ ROAS.',
    keyTakeaways: [
      'Hook Phase (0-3s): Introduce a relatable friction point or surprising visual action.',
      'Agitation & Discovery (3-15s): Explain failed previous solutions and why this product is unique.',
      'Tactile Demonstration (15-45s): Close-up texture, swatches, unboxing, and real application.',
      'Call to Action (45-60s): Clear direction with discount code or whitelist bio link.'
    ],
    templateSnippet: `3-SECOND HOOK TEMPLATES:
1. "If you still struggle with [Problem], stop scrolling right now..."
2. "Why didn't anyone tell me this skincare hack 5 years ago?"
3. "My dog used to refuse every treat until I tested this..."`,
    content: `### 1. The 3-Second Scroll Stopper
Users make a stay-or-swipe decision in under 800 milliseconds. Open the video with immediate motion:
- Pouring or swatching the product directly on camera.
- Facial expression reacting to an unexpected sensation.
- Strong text hook overlay.

### 2. Authentic Pacing
Avoid over-edited corporate voiceovers. High-performing UGC sounds like a voice note sent to a close friend.`
  },
  {
    id: 'kb-5',
    title: 'Creator Onboarding & Contractual Safeguards',
    category: 'Creator Management',
    readTime: '5 min read',
    lastUpdated: 'August 2026',
    tags: ['Onboarding', 'Agreements', 'Representation', 'Roster'],
    summary: 'Standard agency representation procedures, communication channels, and milestone deadlines.',
    keyTakeaways: [
      'Complete W-9 / 1099 tax onboarding before contract execution.',
      'Establish a 48-hour turn-around window for sample delivery receipts.',
      'One mandatory revision round included per campaign brief.'
    ],
    templateSnippet: `REPRESENTATION MEMO:
"Bloom Studio represents talent for commercial brand deals. Talent agrees to maintain professional conduct, respect embargo dates, and submit deliverable drafts by the agreed calendar deadline."`,
    content: `### Onboarding Workflow
1. Creator signs the digital Master Services Agreement (MSA).
2. W-9 / W-8BEN tax documents are verified in the Talent Vault.
3. Creator is assigned a designated Talent Manager.
4. Active profile and sample shipping address are verified.`
  }
];

interface KnowledgeBaseProps {
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: string) => void;
}

export default function KnowledgeBase({
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}: KnowledgeBaseProps) {
  const [articles] = useState<KBArticle[]>(KB_ARTICLES);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeArticle, setActiveArticle] = useState<KBArticle>(KB_ARTICLES[0]);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('wl_kb_bookmarks');
    return saved ? JSON.parse(saved) : ['kb-1', 'kb-4'];
  });

  const categories = useMemo(() => {
    const set = new Set<string>(articles.map(a => a.category));
    return ['All', ...Array.from(set)];
  }, [articles]);

  const toggleBookmark = (id: string) => {
    const next = bookmarkedIds.includes(id) 
      ? bookmarkedIds.filter(b => b !== id) 
      : [...bookmarkedIds, id];
    setBookmarkedIds(next);
    localStorage.setItem('wl_kb_bookmarks', JSON.stringify(next));
    triggerNotification?.(
      bookmarkedIds.includes(id) ? 'Bookmark Removed' : 'Article Bookmarked',
      'Knowledge base quick access list updated.',
      'info'
    );
  };

  const handleCopySnippet = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(true);
    triggerNotification?.('Template Copied', 'Clause copied to your clipboard.', 'success');
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  const filteredArticles = useMemo(() => {
    return articles.filter(a => {
      if (selectedCategory !== 'All' && a.category !== selectedCategory) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const inTitle = a.title.toLowerCase().includes(q);
        const inSummary = a.summary.toLowerCase().includes(q);
        const inTags = a.tags.some(t => t.toLowerCase().includes(q));
        const inContent = a.content.toLowerCase().includes(q);
        if (!inTitle && !inSummary && !inTags && !inContent) return false;
      }
      return true;
    });
  }, [articles, selectedCategory, searchQuery]);

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      {/* Header Banner */}
      <div className="relative bg-[#0b1320] border-2 border-emerald-500/30 rounded-3xl p-6 md:p-8 overflow-hidden shadow-2xl">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-[0.2em] font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-1.5">
                <BookOpen className="w-3 h-3" /> Agency Knowledge Base & SOPs
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
              Standard Operating Procedures & Guidelines
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl">
              Comprehensive playbook for pricing formulas, FTC compliance, escrow release protocols, and high-converting UGC script architectures.
            </p>
          </div>

          <div className="bg-[#050d18] border border-blue-900/60 p-4 rounded-2xl flex items-center gap-3 shrink-0">
            <ShieldCheck className="w-8 h-8 text-emerald-400" />
            <div>
              <span className="text-[10px] text-slate-400 font-mono block uppercase">Institutional Playbook</span>
              <span className="text-xs font-bold text-white font-mono">Verified Version 4.2</span>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-[#0b1320] border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map(c => (
            <button
              key={c}
              onClick={() => setSelectedCategory(c)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer ${
                selectedCategory === c 
                  ? 'bg-emerald-600 text-white font-bold shadow-lg shadow-emerald-900/30' 
                  : 'bg-[#050e1a] text-slate-400 hover:text-white border border-white/5'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search protocols, terms, templates..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="bg-[#050e1a] border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 w-full sm:w-64"
          />
        </div>
      </div>

      {/* Two Column Layout: Article List + Reader */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Articles List */}
        <div className="lg:col-span-5 space-y-3">
          {filteredArticles.length === 0 ? (
            <div className="bg-[#0b1320] border border-white/10 rounded-2xl p-8 text-center space-y-2">
              <HelpCircle className="w-8 h-8 text-slate-500 mx-auto opacity-50" />
              <h4 className="text-xs font-bold text-white">No articles matched your search</h4>
              <p className="text-[11px] text-slate-400">Try broader terms or clearing category filters.</p>
            </div>
          ) : (
            filteredArticles.map(art => {
              const isActive = activeArticle.id === art.id;
              const isBookmarked = bookmarkedIds.includes(art.id);
              return (
                <button
                  key={art.id}
                  type="button"
                  onClick={() => setActiveArticle(art)}
                  className={`w-full text-left bg-[#0b1320] border rounded-2xl p-4 transition-all cursor-pointer hover:border-emerald-500/40 block ${
                    isActive ? 'border-emerald-500 bg-[#0c1a2e] shadow-xl' : 'border-white/10'
                  }`}
                  aria-label={`Read article: ${art.title}`}
                  aria-current={isActive ? 'true' : 'false'}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-mono font-bold text-emerald-400 uppercase px-2 py-0.5 bg-emerald-500/10 rounded-md border border-emerald-500/20">
                          {art.category}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">{art.readTime}</span>
                      </div>
                      <h3 className="text-xs font-bold text-white mt-1 leading-snug">{art.title}</h3>
                    </div>

                    <div 
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleBookmark(art.id);
                      }}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.stopPropagation(); toggleBookmark(art.id); } }}
                      className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                        isBookmarked 
                          ? 'bg-[#C9A46A]/20 text-[#C9A46A] border-[#C9A46A]/40' 
                          : 'text-slate-500 hover:text-white border-transparent'
                      }`}
                      aria-label={isBookmarked ? "Remove bookmark" : "Add bookmark"}
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {art.summary}
                  </p>

                  <div className="flex flex-wrap gap-1 mt-3">
                    {art.tags.map(t => (
                      <span key={t} className="text-[9px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded">
                        #{t}
                      </span>
                    ))}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Right Column: Article Reader */}
        <div className="lg:col-span-7">
          <div className="bg-[#0b1320] border border-white/10 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
            {/* Article Top Details */}
            <div className="border-b border-white/10 pb-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider bg-emerald-500/10 px-2.5 py-1 rounded-md border border-emerald-500/20">
                  {activeArticle.category}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Updated: {activeArticle.lastUpdated} • {activeArticle.readTime}</span>
              </div>

              <h2 className="text-lg md:text-xl font-bold text-white leading-snug">
                {activeArticle.title}
              </h2>

              <p className="text-xs text-slate-300 leading-relaxed bg-[#050e1a] p-3.5 rounded-xl border border-white/5">
                <strong className="text-white block mb-1">Executive Summary:</strong>
                {activeArticle.summary}
              </p>
            </div>

            {/* Key Takeaways Card */}
            <div className="bg-[#050e1a] border border-emerald-500/30 p-4 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold font-mono text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Core SOP Requirements & Takeaways
              </h4>
              <ul className="space-y-2 text-xs text-slate-200">
                {activeArticle.keyTakeaways.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold font-mono">0{idx + 1}.</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Article Body Content */}
            <div className="text-xs text-slate-300 space-y-4 leading-relaxed font-sans whitespace-pre-line border-t border-white/10 pt-5">
              {activeArticle.content}
            </div>

            {/* Copyable Template Snippet if available */}
            {activeArticle.templateSnippet && (
              <div className="bg-[#050e1a] border border-[#C9A46A]/30 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5" /> Ready-to-Use Contract / Caption Template
                  </h4>
                  <button
                    onClick={() => handleCopySnippet(activeArticle.templateSnippet || '')}
                    className="bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30 px-3 py-1 rounded-lg text-[10px] font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedSnippet ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copiedSnippet ? 'Copied' : 'Copy Template'}
                  </button>
                </div>

                <pre className="bg-[#020710] p-3 rounded-xl text-[11px] font-mono text-slate-300 overflow-x-auto whitespace-pre-wrap leading-relaxed border border-white/5">
                  {activeArticle.templateSnippet}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
