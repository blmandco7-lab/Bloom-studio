import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Mail, 
  Send, 
  ShieldCheck, 
  Sparkles, 
  X, 
  CheckCircle2, 
  ArrowRight,
  ExternalLink,
  DollarSign
} from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';
import { getAppCheckToken } from '../lib/firebase';

interface PortfolioContactFooterProps {
  creatorHandle?: string;
  creatorName?: string;
  defaultNiche?: string;
  className?: string;
}

export default function PortfolioContactFooter({
  creatorHandle = "@elenarostova",
  creatorName = "Elena Rostova",
  defaultNiche = "Beauty",
  className = ""
}: PortfolioContactFooterProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [brandName, setBrandName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [targetedVertical, setTargetedVertical] = useState(defaultNiche);
  const [budgetScope, setBudgetScope] = useState("$5,000 - $15,000");
  const [campaignNotes, setCampaignNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    const handleOpenModal = () => setIsModalOpen(true);
    window.addEventListener('open-booking-modal', handleOpenModal);
    return () => window.removeEventListener('open-booking-modal', handleOpenModal);
  }, []);

  const handleSubmitInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandName.trim() || !contactEmail.trim()) return;

    setIsSubmitting(true);
    
    // Retrieve App Check token for bot protection (Finding #102-AppCheck)
    const appCheckToken = await getAppCheckToken();

    const leadPayload = {
      brandName: brandName.trim(),
      contactEmail: contactEmail.trim(),
      targetedVertical,
      budgetScope,
      campaignNotes: campaignNotes.trim(),
      creatorHandle,
      creatorName,
      source: "PublicCreatorPortfolio",
      agency: "Bloom & Co."
    };

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (appCheckToken) {
        headers['X-Firebase-AppCheck'] = appCheckToken;
      }

      const response = await fetch('/api/submit-brand-inquiry', {
        method: 'POST',
        headers,
        body: JSON.stringify(leadPayload),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit inquiry');
      }
    } catch (err: any) {
      console.warn('[LeadCapture] API lead submission error, utilizing local fallback:', err);
      
      // safeStorage fallback for zero-loss lead record if API is unreachable
      try {
        const existing = JSON.parse(safeStorage.getItem('bloom_inbound_leads') || '[]');
        existing.unshift({ ...leadPayload, submittedAt: new Date().toISOString(), status: "Local Fallback" });
        safeStorage.setItem('bloom_inbound_leads', JSON.stringify(existing.slice(0, 100)));
      } catch (e) {
        // ignore
      }
    }

    setIsSubmitting(false);
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setIsModalOpen(false);
      setBrandName("");
      setContactEmail("");
      setCampaignNotes("");
    }, 2800);
  };

  return (
    <>
      <footer 
        id="portfolio-contact-footer"
        className={`w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 sm:p-8 md:p-12 text-agency-textLight relative overflow-hidden shadow-2xl mb-8 ${className}`}
      >
        {/* Ambient Top Light Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-[2px] bg-gradient-to-r from-transparent via-agency-gold to-transparent opacity-75" />

        <div className="w-full max-w-6xl mx-auto flex flex-col xl:flex-row items-start xl:items-center justify-between gap-6 sm:gap-8">
          {/* Representation Notice & Subtext */}
          <div className="w-full xl:max-w-2xl space-y-3 min-w-0 flex-1">
            <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest flex-wrap">
              <Building2 className="w-4 h-4 shrink-0" />
              <span>Agency Representation Registry</span>
            </div>
            
            <h3 className="text-xl sm:text-2xl md:text-3xl font-serif font-bold text-white tracking-wide leading-tight break-words">
              Commercial Representation &amp; Booking Management: Bloom &amp; Co.
            </h3>
            
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans break-words max-w-3xl">
              This creator is exclusively represented by Bloom &amp; Co. (Bloom Studio). For all premium campaign proposals, 
              usage rights licensing, and multi-platform talent bookings, contact our executive management desk below.
            </p>

            {/* Central Contact Email Link */}
            <div className="pt-2 flex items-center gap-2 text-xs font-mono flex-wrap">
              <Mail className="w-4 h-4 text-agency-gold shrink-0" />
              <span className="text-slate-400">Direct Executive Inquiries:</span>
              <a 
                href="mailto:partnerships@bloomstudio.com" 
                className="text-white hover:text-agency-gold font-bold underline transition duration-200 break-all"
              >
                partnerships@bloomstudio.com
              </a>
            </div>
          </div>

          {/* Primary Lead Capture CTA Actions */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full xl:w-auto shrink-0 pt-2 xl:pt-0">
            <button
              type="button"
              id="btn-submit-booking-inquiry"
              onClick={() => setIsModalOpen(true)}
              className="flex items-center justify-center gap-2.5 px-6 py-4 rounded-2xl bg-agency-gold text-agency-navy text-xs sm:text-sm font-mono font-bold uppercase tracking-wider hover:brightness-110 active:scale-[0.98] transition shadow-xl cursor-pointer shrink-0"
            >
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>Submit Booking Inquiry to Bloom &amp; Co.</span>
            </button>

            <a
              href="mailto:partnerships@bloomstudio.com"
              className="flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-agency-navy border border-white/20 text-slate-300 hover:text-white hover:border-agency-gold/60 text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer shrink-0"
            >
              <Mail className="w-3.5 h-3.5 text-agency-gold shrink-0" />
              <span>Email Talent Desk</span>
            </a>
          </div>
        </div>

        {/* Bottom Trust & Compliance Line */}
        <div className="max-w-6xl mx-auto mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono text-slate-400">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>100% FTC Compliance Endorsement Standard &bull; Universal Rights Clearance</span>
          </div>
          <div>
            &copy; {new Date().getFullYear()} Bloom &amp; Co. Global Talent Management. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Pop-up Booking Inquiry Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md animate-fadeIn overflow-y-auto">
          <div 
            className="bg-agency-navyLight border border-agency-gold/40 rounded-3xl p-5 sm:p-6 md:p-8 max-w-lg w-full shadow-2xl relative text-agency-textLight animate-scaleUp max-h-[90dvh] max-h-[90vh] overflow-y-auto my-auto flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 sm:top-5 sm:right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-agency-navy transition cursor-pointer z-10"
            >
              <X className="w-5 h-5" />
            </button>

            {isSubmitted ? (
              <div className="py-10 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                </div>
                <h4 className="text-2xl font-serif font-bold text-white">
                  Inquiry Dispatched
                </h4>
                <p className="text-xs text-slate-300 font-sans max-w-xs mx-auto">
                  Thank you. Bloom &amp; Co. executive management will review your campaign scope for {creatorName} and contact you within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitInquiry} className="space-y-4 flex-1 flex flex-col">
                <div className="space-y-1 pr-8">
                  <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
                    <Building2 className="w-4 h-4 shrink-0" />
                    <span>Bloom &amp; Co. Booking Desk</span>
                  </div>
                  <h4 className="text-lg sm:text-xl font-serif font-bold text-white">
                    Initiate Talent Booking Inquiry
                  </h4>
                  <p className="text-xs text-slate-300 font-mono break-words">
                    Target Creator: <span className="text-agency-gold font-bold">{creatorName} ({creatorHandle})</span>
                  </p>
                </div>

                <div className="space-y-3 pt-1 flex-1">
                  <div>
                    <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-300 mb-1">
                      Brand / Enterprise Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lumina Cosmetics LLC"
                      value={brandName}
                      onChange={(e) => setBrandName(e.target.value)}
                      className="w-full bg-agency-navy border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-agency-gold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-300 mb-1">
                      Corporate Contact Email *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="partnerships@brand.com"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      className="w-full bg-agency-navy border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-agency-gold"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-300 mb-1">
                        Targeted Vertical
                      </label>
                      <select
                        value={targetedVertical}
                        onChange={(e) => setTargetedVertical(e.target.value)}
                        className="w-full bg-agency-navy border border-white/15 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-agency-gold"
                      >
                        <option value="Beauty">Beauty &amp; Cosmetics</option>
                        <option value="Pets">Pet Wellness &amp; Care</option>
                        <option value="Lifestyle">High-Aesthetic Lifestyle</option>
                        <option value="Tech">Tech &amp; Hardware</option>
                        <option value="Fitness">Health &amp; Fitness</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-300 mb-1">
                        Budget Scope ($)
                      </label>
                      <select
                        value={budgetScope}
                        onChange={(e) => setBudgetScope(e.target.value)}
                        className="w-full bg-agency-navy border border-white/15 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-agency-gold"
                      >
                        <option value="$3,000 - $7,500">$3,000 - $7,500</option>
                        <option value="$7,500 - $15,000">$7,500 - $15,000</option>
                        <option value="$15,000 - $35,000">$15,000 - $35,000</option>
                        <option value="$35,000+ Enterprise">$35,000+ Enterprise</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-300 mb-1">
                      Campaign Deliverables / Notes
                    </label>
                    <textarea
                      rows={2}
                      placeholder="e.g. 2x 9:16 TikTok Reels + 30-day Meta ad whitelisting"
                      value={campaignNotes}
                      onChange={(e) => setCampaignNotes(e.target.value)}
                      className="w-full bg-agency-navy border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-agency-gold resize-none"
                    />
                  </div>
                </div>

                <div className="pt-2 sticky bottom-0 bg-agency-navyLight">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-agency-gold text-agency-navy text-xs font-mono font-bold uppercase tracking-wider hover:brightness-110 disabled:opacity-50 transition shadow-lg cursor-pointer"
                  >
                    {isSubmitting ? (
                      <span>Routing to Bloom &amp; Co. Desk...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Submit Booking Proposal</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
}
