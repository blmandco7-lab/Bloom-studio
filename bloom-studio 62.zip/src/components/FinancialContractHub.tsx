import React from 'react';
import { Lock, ShieldCheck, Landmark, FileText } from 'lucide-react';
import TalentRightsBuyoutManager from './TalentRightsBuyoutManager';
import BrandContractUpsellManifest from './BrandContractUpsellManifest';

interface FinancialContractHubProps {
  userRole?: string;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}

export default function FinancialContractHub({ 
  userRole = 'director',
  triggerNotification,
  onAddActivityLog
}: FinancialContractHubProps) {
  return (
    <div className="space-y-8 animate-fade-in text-slate-100">
      <div className="bg-[#0b1320] border-2 border-[#D4AF37]/30 rounded-2xl p-6 overflow-hidden shadow-2xl">
        <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
          Financial &amp; Contract Automation
        </h1>
        <p className="text-xs text-slate-400 mt-2 max-w-2xl">
          Complete control over budget allocations, brand contract updates, rights transfers, and escrow payroll staging.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Brand Contract Upsell & Update Manifest */}
        <div className="bg-[#050e1a] border border-white/5 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <FileText className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Brand Contract Update &amp; Upsell Manifest</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Select target brand, update contract details, and attach monetization rights add-ons.</p>
            </div>
          </div>
          
          <BrandContractUpsellManifest 
            userRole={userRole} 
            triggerNotification={triggerNotification}
            onAddActivityLog={onAddActivityLog}
          />
        </div>

        {/* Forced Manual Controls */}
        <div className="bg-[#050e1a] border border-white/5 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-rose-500/10 rounded-lg">
              <Lock className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Forced Manual Controls</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">System rules forcing compensation sections blank with a [MANUAL ENTRY REQUIRED] tag.</p>
            </div>
          </div>
          <div className="bg-[#111E33] p-4 rounded-lg border border-white/10 text-xs">
            <span className="text-rose-400 font-bold bg-rose-500/10 px-2 py-0.5 rounded mr-2 font-mono">[MANUAL ENTRY REQUIRED]</span>
            This policy is actively enforced across all new Deal creations in the Operation Board. Default fallback splits are disabled.
          </div>
        </div>

        {/* Dynamic Escrow Payroll */}
        <div className="bg-[#050e1a] border border-white/5 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-indigo-500/10 rounded-lg">
              <Landmark className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Dynamic Escrow Payroll</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Tied employee commissions and creator payments directly to the brand's payment timeline.</p>
            </div>
          </div>
          <div className="bg-[#111E33] p-4 rounded-lg border border-white/10 text-xs text-slate-300">
            <p className="mb-2">Escrow disbursement schedules are directly linked to Client Payment Terms (Upfront, Net 15, Net 30, Net 60) in the <strong>Global Payroll &amp; Escrow Schedule</strong> screen. This prevents out-of-pocket cash drain.</p>
          </div>
        </div>

        {/* Flat-Fee Copyright Buyouts */}
        <div className="bg-[#050e1a] border border-white/5 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-500/10 rounded-lg">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Flat-Fee Copyright Buyouts</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Replaced percentage sliders with flat dollar inputs for video ad rights.</p>
            </div>
          </div>
          
          <TalentRightsBuyoutManager userRole={userRole} />
        </div>
      </div>
    </div>
  );
}
