import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldCheck, AlertTriangle, CheckCircle2, RefreshCw, Play, Pause, 
  FileText, Lock, Clock, DollarSign, ArrowRight, Zap, Download, 
  ExternalLink, Check, AlertCircle, Info, Sparkles, Sliders
} from 'lucide-react';
import { Deal, Creator, ReviewItem, Contract, Invoice } from '../types';
import { evaluateFtcCompliance } from '../lib/ftcBot';
import { formatCsvRow, sanitizeCsvCell } from '../utils/security';

interface AuditToolLoopProps {
  deals: Deal[];
  creators: Creator[];
  reviews?: ReviewItem[];
  contracts?: Contract[];
  invoices?: Invoice[];
  currentRole?: string;
  currentUser?: any;
  tenantId?: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'danger') => void;
  onFixFinding?: (findingId: string, actionType: string) => void;
}

export interface AuditFinding {
  id: string;
  vector: 'Tax & W-9' | 'FTC Compliance' | 'Contract Vault' | 'Deliverable SLA' | 'Escrow & Invoicing' | 'Media Proof';
  severity: 'critical' | 'warning' | 'info' | 'pass';
  title: string;
  description: string;
  entityId: string;
  entityName: string;
  remediationAction: string;
  remediationLabel: string;
  isResolved?: boolean;
}

export default function AuditToolLoop({
  deals = [],
  creators = [],
  reviews = [],
  contracts = [],
  invoices = [],
  currentRole = 'director',
  currentUser,
  tenantId = 'bloom_studio_default',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onAddActivityLog,
  triggerNotification,
  onFixFinding
}: AuditToolLoopProps) {
  const [isLoopActive, setIsLoopActive] = useState(true);
  const [scanIntervalSec, setScanIntervalSec] = useState(30);
  const [lastScannedTime, setLastScannedTime] = useState<string>('Just now');
  const [isScanning, setIsScanning] = useState(false);
  const [selectedVector, setSelectedVector] = useState<string>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [resolvedFindingIds, setResolvedFindingIds] = useState<string[]>([]);
  const [scanCount, setScanCount] = useState(1);

  // Dynamic Audit Scanner Engine: analyzes real state
  const rawFindings = useMemo(() => {
    const findings: AuditFinding[] = [];

    // 1. Vector 1: Tax & W-9 Verification (IRS >$600 threshold)
    creators.forEach(creator => {
      const creatorDeals = deals.filter(d => 
        d.creator.toLowerCase() === creator.name.toLowerCase() ||
        d.creator.toLowerCase() === creator.handle.toLowerCase()
      );
      const totalEarnings = creatorDeals.reduce((sum, d) => sum + (Number(d.budget || d.value || 0)), 0);
      const hasW9 = creator.w9Status === 'Verified' || creator.w9Status === 'Received';

      if (totalEarnings >= 600 && !hasW9) {
        findings.push({
          id: `w9_${creator.id}`,
          vector: 'Tax & W-9',
          severity: 'critical',
          title: `Missing W-9 on ${creator.name} ($${totalEarnings.toLocaleString()} Volume)`,
          description: `${creator.name} (${creator.handle}) exceeds the $600 IRS 1099-NEC reporting threshold but has no verified W-9 on file. Payouts must be paused until signed.`,
          entityId: creator.id,
          entityName: creator.name,
          remediationAction: 'request_w9',
          remediationLabel: 'Dispatch W-9 Request'
        });
      }
    });

    // 2. Vector 2: FTC Compliance Verification
    reviews.forEach(rev => {
      const isMissingDisclosure = !rev.captionDraft?.toLowerCase().includes('#ad') && 
                                  !rev.captionDraft?.toLowerCase().includes('#sponsored') &&
                                  !rev.captionDraft?.toLowerCase().includes('paid partnership');
      if (isMissingDisclosure && rev.status !== 'Approved') {
        findings.push({
          id: `ftc_${rev.id}`,
          vector: 'FTC Compliance',
          severity: 'critical',
          title: `FTC Disclosure Missing: ${rev.brand} Draft (${rev.creator})`,
          description: `Content review draft for ${rev.brand} lacks required #ad or #sponsored disclosure tags under FTC Section 5 guidelines.`,
          entityId: rev.id,
          entityName: `${rev.brand} x ${rev.creator}`,
          remediationAction: 'flag_ftc',
          remediationLabel: 'Inject #ad Flag'
        });
      }
    });

    // 3. Vector 3: Contract Vault Integrity
    deals.forEach(deal => {
      if (deal.stage === 'Contracted' || deal.stage === 'Live') {
        const hasMatchingContract = contracts.some(c => 
          (c.name || '').toLowerCase().includes((deal.brand || '').toLowerCase()) ||
          (c.party || '').toLowerCase().includes((deal.creator || '').toLowerCase())
        );
        if (!hasMatchingContract && Number(deal.budget || deal.value || 0) > 1000) {
          findings.push({
            id: `contract_${deal.id}`,
            vector: 'Contract Vault',
            severity: 'warning',
            title: `Unsigned Master Agreement: ${deal.brand} ($${Number(deal.budget || deal.value || 0).toLocaleString()})`,
            description: `Deal is marked '${deal.stage}' but no counter-signed legal contract was located in the agency digital vault.`,
            entityId: deal.id,
            entityName: deal.brand,
            remediationAction: 'draft_contract',
            remediationLabel: 'Generate Contract'
          });
        }
      }
    });

    // 4. Vector 4: Deliverable SLA & Deadlines
    deals.forEach(deal => {
      if (deal.due && deal.stage !== 'Completed') {
        const dueDate = new Date(deal.due).getTime();
        const now = Date.now();
        const hoursRemaining = (dueDate - now) / (1000 * 60 * 60);

        if (hoursRemaining < 0) {
          findings.push({
            id: `sla_overdue_${deal.id}`,
            vector: 'Deliverable SLA',
            severity: 'critical',
            title: `Overdue Milestone: ${deal.brand} (${deal.creator})`,
            description: `Deliverable milestone due on ${deal.due} has passed without stage completion. Brand SLA is in breach.`,
            entityId: deal.id,
            entityName: deal.brand,
            remediationAction: 'escalate_agent',
            remediationLabel: 'Ping Manager SLA'
          });
        } else if (hoursRemaining < 48 && (deal.stage === 'Lead' || deal.stage === 'Pitched')) {
          findings.push({
            id: `sla_urgent_${deal.id}`,
            vector: 'Deliverable SLA',
            severity: 'warning',
            title: `Approaching Due Date (<48h): ${deal.brand}`,
            description: `Deliverable deadline is in ${Math.round(hoursRemaining)} hours, but deal is still in '${deal.stage}'.`,
            entityId: deal.id,
            entityName: deal.brand,
            remediationAction: 'fast_track',
            remediationLabel: 'Fast-Track Deal'
          });
        }
      }
    });

    // 5. Vector 5: Escrow & Invoicing Balance
    invoices.forEach(inv => {
      if (inv.status === 'Overdue' || (inv.status === 'Pending' && new Date(inv.due).getTime() < Date.now())) {
        findings.push({
          id: `inv_${inv.id}`,
          vector: 'Escrow & Invoicing',
          severity: 'warning',
          title: `Overdue Brand Invoice: ${inv.to} ($${inv.amount.toLocaleString()})`,
          description: `Invoice for ${inv.forWork} has been unpaid past due date ${inv.due}. Escrow payout held until settled.`,
          entityId: inv.id,
          entityName: inv.to,
          remediationAction: 'send_invoice_reminder',
          remediationLabel: 'Send Pay Reminder'
        });
      }
    });

    // 6. Vector 6: Media Proof Verification
    reviews.forEach(rev => {
      if (rev.status === 'Posted' && (!rev.mediaUrl || rev.mediaUrl.trim() === '')) {
        findings.push({
          id: `proof_${rev.id}`,
          vector: 'Media Proof',
          severity: 'info',
          title: `Missing Live Media URL: ${rev.brand} (${rev.creator})`,
          description: `Deliverable is marked 'Posted' but live TikTok/Reel verification URL link is empty.`,
          entityId: rev.id,
          entityName: rev.creator,
          remediationAction: 'request_proof_url',
          remediationLabel: 'Request URL'
        });
      }
    });

    return findings;
  }, [deals, creators, reviews, contracts, invoices]);

  // Filter findings
  const activeFindings = useMemo(() => {
    return rawFindings.map(f => ({
      ...f,
      isResolved: resolvedFindingIds.includes(f.id)
    })).filter(f => {
      if (selectedVector !== 'all' && f.vector !== selectedVector) return false;
      if (selectedSeverity !== 'all' && f.severity !== selectedSeverity) return false;
      return true;
    });
  }, [rawFindings, resolvedFindingIds, selectedVector, selectedSeverity]);

  // Overall Health Score (0-100%)
  const healthStats = useMemo(() => {
    const totalUnresolved = rawFindings.filter(f => !resolvedFindingIds.includes(f.id));
    const criticalCount = totalUnresolved.filter(f => f.severity === 'critical').length;
    const warningCount = totalUnresolved.filter(f => f.severity === 'warning').length;
    const infoCount = totalUnresolved.filter(f => f.severity === 'info').length;

    // Deduct 8 points per critical, 3 per warning, 1 per info
    const penalty = (criticalCount * 8) + (warningCount * 3) + (infoCount * 1);
    const score = Math.max(20, Math.min(100, 100 - penalty));

    return {
      score,
      criticalCount,
      warningCount,
      infoCount,
      totalFindings: totalUnresolved.length,
      resolvedCount: resolvedFindingIds.length
    };
  }, [rawFindings, resolvedFindingIds]);

  // Automated Scanning Loop Heartbeat
  useEffect(() => {
    if (!isLoopActive) return;

    const interval = setInterval(() => {
      setIsScanning(true);
      setTimeout(() => {
        setIsScanning(false);
        setLastScannedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        setScanCount(prev => prev + 1);
      }, 500);
    }, scanIntervalSec * 1000);

    return () => clearInterval(interval);
  }, [isLoopActive, scanIntervalSec]);

  // Manual Trigger Scan
  const handleManualScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setLastScannedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setScanCount(prev => prev + 1);
      triggerNotification?.('Audit Loop Completed', `Scanned 6 operational vectors across ${deals.length} deals & ${creators.length} creators.`, 'success');
      onAddActivityLog?.(currentUser?.name || 'User', currentRole, 'Executed manual agency compliance audit loop scan');
    }, 600);
  };

  // Instant Remediation Fix
  const handleApplyFix = (finding: AuditFinding) => {
    setResolvedFindingIds(prev => [...prev, finding.id]);
    
    if (onFixFinding) {
      onFixFinding(finding.id, finding.remediationAction);
    }

    triggerNotification?.(
      'Remediation Executed',
      `Applied automated resolution: "${finding.remediationLabel}" on ${finding.entityName}.`,
      'success'
    );
    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole,
      `Audit Auto-Fix: Resolved ${finding.vector} finding [${finding.title}]`
    );
  };

  // Resolve All Criticals in 1 Click
  const handleBatchFixAll = () => {
    const allIds = rawFindings.map(f => f.id);
    setResolvedFindingIds(allIds);

    triggerNotification?.(
      'Batch Audit Remediation Applied',
      `Auto-resolved ${rawFindings.length} compliance findings across all vectors.`,
      'success'
    );
    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole,
      `Batch resolved ${rawFindings.length} audit compliance findings in 1-click`
    );
  };

  // Export Formal Audit Report
  const handleExportAuditReport = () => {
    const headers = ['Vector', 'Severity', 'Title', 'Entity', 'Status', 'Remediation'];
    const rows = rawFindings.map(f => formatCsvRow([
      f.vector,
      f.severity.toUpperCase(),
      f.title,
      f.entityName,
      resolvedFindingIds.includes(f.id) ? 'RESOLVED' : 'UNRESOLVED',
      f.remediationLabel
    ]));

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.map(sanitizeCsvCell).join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bloom_agency_compliance_audit_report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    triggerNotification?.('Audit Report Exported', 'Compliance certificate & findings CSV downloaded.', 'success');
  };

  return (
    <div className="space-y-6 animate-fade-in" id="audit-tool-loop-root">
      
      {/* Header & Loop Control Deck */}
      <div className="bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 relative overflow-hidden" style={{ backgroundColor: cardBgColor }}>
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isLoopActive ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`}></span>
                {isLoopActive ? `CONTINUOUS AUDIT LOOP RUNNING (${scanIntervalSec}s)` : 'AUDIT LOOP PAUSED'}
              </span>
              <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/5">
                Scan #{scanCount} &bull; Last: <strong className="text-white">{lastScannedTime}</strong>
              </span>
            </div>
            <h1 className="font-serif text-2xl font-bold text-white flex items-center gap-2.5 mt-1">
              <ShieldCheck className="w-6 h-6" style={{ color: primaryBrandColor }} />
              Continuous Compliance &amp; Operational Audit Loop
            </h1>
            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Automated multi-vector watchdog scans IRS W-9 thresholds, FTC sponsorship disclosures, contract execution vaults, and deliverable SLAs.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Loop Toggle */}
            <button
              onClick={() => {
                setIsLoopActive(!isLoopActive);
                triggerNotification?.(
                  !isLoopActive ? 'Audit Loop Resumed' : 'Audit Loop Paused',
                  !isLoopActive ? `Background scanning active every ${scanIntervalSec}s.` : 'Automatic background scanning paused.',
                  'info'
                );
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                isLoopActive ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30' : 'bg-white/10 text-slate-300 hover:text-white'
              }`}
            >
              {isLoopActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isLoopActive ? 'Auto Loop: ON' : 'Auto Loop: OFF'}</span>
            </button>

            {/* Interval Selector */}
            <select
              value={scanIntervalSec}
              onChange={(e) => setScanIntervalSec(Number(e.target.value))}
              className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
            >
              <option value={15}>Loop: Every 15s</option>
              <option value={30}>Loop: Every 30s</option>
              <option value={60}>Loop: Every 60s</option>
              <option value={120}>Loop: Every 2m</option>
            </select>

            {/* Manual Run */}
            <button
              onClick={handleManualScan}
              disabled={isScanning}
              className="p-2.5 bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-slate-300 hover:text-white rounded-xl transition-colors cursor-pointer"
              title="Run on-demand scan now"
            >
              <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin text-[#C9A46A]' : ''}`} />
            </button>

            {/* Export CSV Report */}
            <button
              onClick={handleExportAuditReport}
              className="px-3.5 py-2 bg-[#111E33] hover:bg-[#16243F] border border-[#C9A46A]/30 text-[#C9A46A] hover:text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Audit Report</span>
            </button>
          </div>
        </div>

        {/* Health Score & Stats Summary Bar */}
        <div className="mt-6 pt-5 border-t border-white/5 grid grid-cols-2 sm:grid-cols-4 gap-4">
          
          <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold font-mono text-base ${
              healthStats.score >= 90 ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
              healthStats.score >= 70 ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
              'bg-rose-500/20 text-rose-400 border border-rose-500/30'
            }`}>
              {healthStats.score}%
            </div>
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-mono block uppercase">Studio Health Index</span>
              <strong className="text-white text-xs font-bold">
                {healthStats.score >= 90 ? 'Operational & Safe' : healthStats.score >= 70 ? 'Action Recommended' : 'Critical Risks'}
              </strong>
            </div>
          </div>

          <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 font-mono font-bold text-base">
              {healthStats.criticalCount}
            </div>
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-mono block uppercase">Critical Findings</span>
              <strong className="text-rose-300 text-xs font-bold">Tax &amp; FTC Blocks</strong>
            </div>
          </div>

          <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-mono font-bold text-base">
              {healthStats.warningCount}
            </div>
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-mono block uppercase">Warnings / SLAs</span>
              <strong className="text-amber-300 text-xs font-bold">Deadlines &amp; Invoices</strong>
            </div>
          </div>

          <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-mono font-bold text-base">
              {healthStats.resolvedCount}
            </div>
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-mono block uppercase">Auto-Remediated</span>
              <strong className="text-emerald-300 text-xs font-bold">Fixed via Loop</strong>
            </div>
          </div>

        </div>

        {/* Vector Filters & Batch Actions */}
        <div className="mt-4 pt-4 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] text-[#7C8AA8] font-mono">Vector:</span>
            {['all', 'Tax & W-9', 'FTC Compliance', 'Contract Vault', 'Deliverable SLA', 'Escrow & Invoicing', 'Media Proof'].map((v) => (
              <button
                key={v}
                onClick={() => setSelectedVector(v)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer ${
                  selectedVector === v 
                    ? 'bg-[#C9A46A] text-[#0A1220] font-bold' 
                    : 'bg-[#111E33] text-slate-400 hover:text-white border border-white/5'
                }`}
                style={selectedVector === v ? { backgroundColor: primaryBrandColor } : {}}
              >
                {v === 'all' ? 'All 6 Vectors' : v}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="bg-[#111E33] border border-white/10 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical Only</option>
              <option value="warning">Warnings Only</option>
              <option value="info">Info / Passed</option>
            </select>

            {rawFindings.length > 0 && (
              <button
                onClick={handleBatchFixAll}
                className="px-3 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>1-Click Auto-Fix All</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Findings List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs text-[#7C8AA8] px-1 font-mono">
          <span>Active Audit Findings ({activeFindings.length})</span>
          <span>Target Platform: IRS &bull; FTC &bull; Contract Vault</span>
        </div>

        {activeFindings.length === 0 ? (
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-12 text-center space-y-3" style={{ backgroundColor: cardBgColor }}>
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-white font-bold text-base">All 6 Operational Vectors Passed</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              No compliance bottlenecks, missing W-9s, FTC disclosure risks, or overdue deliverable milestones detected.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {activeFindings.map((finding) => {
              const isResolved = finding.isResolved;

              return (
                <div 
                  key={finding.id}
                  className={`bg-[#0D1830] border rounded-2xl p-4.5 transition-all shadow-md ${
                    isResolved 
                      ? 'border-emerald-500/30 opacity-70 bg-emerald-950/10' 
                      : finding.severity === 'critical'
                        ? 'border-rose-500/40 hover:border-rose-500/70'
                        : finding.severity === 'warning'
                          ? 'border-amber-500/40 hover:border-amber-500/70'
                          : 'border-white/10 hover:border-white/20'
                  }`}
                  style={{ backgroundColor: cardBgColor }}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    
                    {/* Left details */}
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-wider ${
                          isResolved 
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : finding.severity === 'critical'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : finding.severity === 'warning'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        }`}>
                          {isResolved ? 'RESOLVED' : finding.severity.toUpperCase()}
                        </span>

                        <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/5">
                          {finding.vector}
                        </span>

                        <span className="text-[11px] font-bold text-white font-mono">
                          {finding.entityName}
                        </span>
                      </div>

                      <h4 className="text-sm font-bold text-white leading-snug">
                        {finding.title}
                      </h4>

                      <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                        {finding.description}
                      </p>
                    </div>

                    {/* Right Action Button */}
                    <div className="sm:text-right shrink-0">
                      {isResolved ? (
                        <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono font-semibold py-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Remediated</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleApplyFix(finding)}
                          className="w-full sm:w-auto px-4 py-2 bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow cursor-pointer"
                          style={{ backgroundColor: primaryBrandColor }}
                        >
                          <Zap className="w-3.5 h-3.5" />
                          <span>{finding.remediationLabel}</span>
                        </button>
                      )}
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
