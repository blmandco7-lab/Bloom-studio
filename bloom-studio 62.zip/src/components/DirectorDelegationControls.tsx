import React, { useState, useEffect } from 'react';
import { 
  Sliders, Shield, CheckCircle2, Lock, Unlock, AlertTriangle, 
  Layers, Users, FileText, Info, Award, UserCheck, RefreshCw, Zap,
  Star, Search, Check, SlidersHorizontal, Share2, ExternalLink, Copy
} from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';
import { db, saveDirectorDelegationInFirestore } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

export interface DirectorDelegationSettings {
  agentManagerCanAddCampaigns: boolean; // default: false
  agentManagerCanAddToPortfolio: boolean; // default: false
  agentManagerCanDraftBriefs: boolean; // default: false
  agentMgrCanAnnounce: boolean; // default: false
  allowBrandMediaKitShare: boolean; // default: false
  staffCanViewInvoices: boolean; // default: false
  staffCanCreateInvoices: boolean; // default: false
}

interface DirectorDelegationControlsProps {
  settings?: DirectorDelegationSettings;
  onUpdateSettings?: (newSettings: DirectorDelegationSettings) => void;
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  primaryBrandColor?: string;
  cardBgColor?: string;
}

export const DEFAULT_DIRECTOR_DELEGATION: DirectorDelegationSettings = {
  agentManagerCanAddCampaigns: false,
  agentManagerCanAddToPortfolio: false,
  agentManagerCanDraftBriefs: false,
  agentMgrCanAnnounce: false,
  allowBrandMediaKitShare: false,
  staffCanViewInvoices: false,
  staffCanCreateInvoices: false,
};

/**
 * Reads delegation settings from the server-side tenant config.
 */
export const getDirectorDelegationFromFirestore = async (tenantId: string): Promise<DirectorDelegationSettings> => {
  try {
    const tid = tenantId || 'bloom_studio_default';
    const configRef = doc(db, 'tenants', tid, 'config', 'delegation');
    const snap = await getDoc(configRef);
    if (snap.exists()) {
      return { ...DEFAULT_DIRECTOR_DELEGATION, ...snap.data() } as DirectorDelegationSettings;
    }
    
    // Fallback to branding config where it might have been saved before
    const brandingRef = doc(db, 'tenants', tid, 'config', 'branding');
    const brandingSnap = await getDoc(brandingRef);
    if (brandingSnap.exists()) {
      return { ...DEFAULT_DIRECTOR_DELEGATION, ...brandingSnap.data() } as DirectorDelegationSettings;
    }
  } catch (e) {
    console.error('[getDirectorDelegationFromFirestore] Error:', e);
  }
  return DEFAULT_DIRECTOR_DELEGATION;
};

export const getStoredDirectorDelegation = (): DirectorDelegationSettings => {
  try {
    const saved = safeStorage.getItem('wl_director_delegation');
    if (saved) {
      return { ...DEFAULT_DIRECTOR_DELEGATION, ...JSON.parse(saved) };
    }
  } catch (e) {
    console.error('Error reading director delegation settings cache', e);
  }
  return DEFAULT_DIRECTOR_DELEGATION;
};

export const saveStoredDirectorDelegation = async (settings: DirectorDelegationSettings, userPod?: string) => {
  try {
    // 1. Update cache and dispatch event for instant UI update
    safeStorage.setItem('wl_director_delegation', JSON.stringify(settings));
    window.dispatchEvent(new CustomEvent('director_delegation_updated', { detail: settings }));
    
    const activePod = userPod || 'bloom_studio_default';

    if (db && activePod) {
      // 2. Save to the central tenant config (Secure delegation)
      await saveDirectorDelegationInFirestore(activePod, settings);
      console.log('[DirectorDelegationControls] Synchronized settings with Tenant Config for pod:', activePod);
    }
  } catch (e) {
    console.error('Error saving director delegation settings', e);
  }
};

export default function DirectorDelegationControls({
  settings: propSettings,
  onUpdateSettings,
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
}: DirectorDelegationControlsProps) {
  const [localSettings, setLocalSettings] = useState<DirectorDelegationSettings>(() => {
    return propSettings || DEFAULT_DIRECTOR_DELEGATION;
  });

  // Brand Share Curation State
  const [featuredBrandCreators, setFeaturedBrandCreators] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('wl_featured_brand_creators');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed === 'object' && parsed !== null) return parsed;
      }
    } catch (e) {}
    return {
      '@elenarostova': true,
      '@kai_lifestyle': true,
      '@golden_leo': true,
      '@marcus_vfx': true,
      '@sarah_fits': true
    };
  });

  const [rosterCreators, setRosterCreators] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('wl_public_portfolios');
      if (saved) {
        const parsed = JSON.parse(saved);
        return Object.values(parsed);
      }
    } catch (e) {}
    return [
      { name: 'Elena Rostova', handle: '@elenarostova', niche: 'Beauty & Luxury', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100' },
      { name: 'Kai Lifestyle', handle: '@kai_lifestyle', niche: 'Minimalist Design', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
      { name: 'Golden Leo', handle: '@golden_leo', niche: 'Fitness & Travel', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100' },
      { name: 'Marcus VFX', handle: '@marcus_vfx', niche: 'CGI & Motion', avatar: 'https://images.unsplash.com/photo-1620122303020-43ec4b6cf7f8?w=100' },
      { name: 'Sarah Fits', handle: '@sarah_fits', niche: 'UGC Wellness', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' }
    ];
  });

  const [curationSearch, setCurationSearch] = useState('');
  const [isCopiedBrandLink, setIsCopiedBrandLink] = useState(false);

  const handleCopyBrandShareLink = () => {
    const url = `${typeof window !== 'undefined' ? window.location.origin : ''}/#public-portfolio?brand=true`;
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).catch(() => {});
      } else {
        const ta = document.createElement('textarea');
        ta.value = url;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      }
      setIsCopiedBrandLink(true);
      setTimeout(() => setIsCopiedBrandLink(false), 2500);
      if (triggerNotification) {
        triggerNotification('Brand Portfolio Link Copied', 'The curated Brand Portfolio showcase link has been copied to your clipboard.', 'success');
      }
    } catch (e) {
      console.warn('Copy error:', e);
    }
  };

  const toggleFeaturedCreator = async (handle: string) => {
    const isNowFeatured = !featuredBrandCreators[handle];
    const updated = {
      ...featuredBrandCreators,
      [handle]: isNowFeatured
    };
    setFeaturedBrandCreators(updated);
    
    // Save to local storage
    localStorage.setItem('wl_featured_brand_creators', JSON.stringify(updated));
    
    // Dispatch event to sync PublicCreatorPortfolio in real-time
    window.dispatchEvent(new CustomEvent('wl_featured_brand_creators_updated', { detail: updated }));

    // Sync with Firestore
    try {
      const cleanDocId = handle.replace(/^@/, '');
      await setDoc(doc(db, 'studio-creators', cleanDocId), {
        featuredOnBrandLink: isNowFeatured,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore featured toggle write note:', err);
    }

    if (triggerNotification) {
      const cName = rosterCreators.find(c => c.handle === handle)?.name || handle;
      triggerNotification(
        'Portfolio Curation Updated',
        `${cName} is now ${isNowFeatured ? 'FEATURED on' : 'REMOVED from'} the Brand Portfolio Link.`,
        'success'
      );
    }
  };

  const handleCurateAll = () => {
    const updated: Record<string, boolean> = {};
    rosterCreators.forEach(c => {
      updated[c.handle] = true;
    });
    setFeaturedBrandCreators(updated);
    localStorage.setItem('wl_featured_brand_creators', JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent('wl_featured_brand_creators_updated', { detail: updated }));
    
    if (triggerNotification) {
      triggerNotification('Roster Curation Updated', 'All roster creators are now featured on the Brand Share Link.', 'success');
    }
  };

  useEffect(() => {
    // Keep local roster in sync if public portfolios change in localstorage
    const handleStorageChange = () => {
      try {
        const saved = localStorage.getItem('wl_public_portfolios');
        if (saved) {
          setRosterCreators(Object.values(JSON.parse(saved)));
        }
      } catch (e) {}
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
    if (propSettings) {
      setLocalSettings(propSettings);
    } else {
      // If no props, try to fetch from Firestore once
      const activePod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'bloom_studio_default';
      getDirectorDelegationFromFirestore(activePod).then(s => setLocalSettings(s));
    }
  }, [propSettings, currentUser]);

  const handleToggle = (key: keyof DirectorDelegationSettings, label: string) => {
    const updated = {
      ...localSettings,
      [key]: !localSettings[key],
    };
    setLocalSettings(updated);
    const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
    saveStoredDirectorDelegation(updated, userPod);
    if (onUpdateSettings) {
      onUpdateSettings(updated);
    }

    const stateStr = updated[key] ? 'ENABLED (Granted)' : 'DISABLED (Restricted)';
    if (triggerNotification) {
      triggerNotification(
        'Director Permission Updated',
        `Agent Manager permission for ${label} is now ${stateStr}.`,
        updated[key] ? 'success' : 'warning'
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'Creative Director',
        currentRole,
        `Updated Agent Manager permission: ${label} is now ${stateStr}`
      );
    }
  };

  const isDirector = currentRole.toLowerCase() === 'director' || currentRole.toLowerCase() === 'owner';

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-fade-in text-white">
      {/* Header Banner */}
      <div 
        className="border border-[#C9A46A]/30 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden"
        style={{ backgroundColor: cardBgColor }}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#0A1220] bg-[#C9A46A] px-3 py-0.5 rounded-full flex items-center gap-1.5 shadow-sm">
                <Award className="w-3.5 h-3.5" /> Executive Governance
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Active Director: <strong className="text-white">{currentUser?.name || 'User'}</strong>
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-2 flex items-center gap-2.5">
              <Sliders className="w-7 h-7 text-[#C9A46A]" />
              Director Delegation &amp; Staff Switches
            </h1>
            <p className="text-xs md:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Granular access controls governing operational permissions for the <strong>Agent Manager</strong> role across Campaigns, Deliverables, Public Portfolio, and Creative Briefs.
            </p>
          </div>

          <div className="p-3 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3 shrink-0">
            <Shield className="w-6 h-6 text-[#C9A46A]" />
            <div>
              <span className="text-[10px] uppercase font-mono text-slate-400 block">Security Policy</span>
              <span className="text-xs font-bold text-emerald-400 font-mono">Director-Gated Only</span>
            </div>
          </div>
        </div>

        {/* Global Overview Pill Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-5">
          <div className="bg-[#111E33] border border-white/10 p-3.5 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Layers className="w-4 h-4 text-[#C9A46A]" />
              <span className="text-xs text-slate-200">Campaign &amp; Deliverables</span>
            </div>
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
              localSettings.agentManagerCanAddCampaigns 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
            }`}>
              {localSettings.agentManagerCanAddCampaigns ? 'Authorized' : 'Locked'}
            </span>
          </div>

          <div className="bg-[#111E33] border border-white/10 p-3.5 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Users className="w-4 h-4 text-[#C9A46A]" />
              <span className="text-xs text-slate-200">Public Portfolio</span>
            </div>
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
              localSettings.agentManagerCanAddToPortfolio 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
            }`}>
              {localSettings.agentManagerCanAddToPortfolio ? 'Authorized' : 'Locked'}
            </span>
          </div>

          <div className="bg-[#111E33] border border-white/10 p-3.5 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <FileText className="w-4 h-4 text-[#C9A46A]" />
              <span className="text-xs text-slate-200">Creative Brief Drafting</span>
            </div>
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
              localSettings.agentManagerCanDraftBriefs 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
            }`}>
              {localSettings.agentManagerCanDraftBriefs ? 'Drafting Allowed' : 'Pass-Only (Locked)'}
            </span>
          </div>

          <div className="bg-[#111E33] border border-white/10 p-3.5 rounded-xl flex items-center justify-between sm:col-span-3 lg:col-span-1">
            <div className="flex items-center gap-2.5">
              <Zap className="w-4 h-4 text-[#C9A46A]" />
              <span className="text-xs text-slate-200">Team Announcements</span>
            </div>
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
              localSettings.agentMgrCanAnnounce 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
            }`}>
              {localSettings.agentMgrCanAnnounce ? 'Broadcasting Allowed' : 'Director-Only'}
            </span>
          </div>
        </div>
      </div>

      {/* Brand Portfolio Sharing & Curation Governance */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 border-b border-white/10 pb-2">
          <SlidersHorizontal className="w-5 h-5 text-[#C9A46A]" />
          <h2 className="text-sm uppercase font-mono font-bold text-[#C9A46A] tracking-wider">
            Brand Portfolio Sharing &amp; Curation Governance
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Card 1: Brand Portfolio Link Curation */}
          <div 
            className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all flex flex-col justify-between"
            style={{ backgroundColor: cardBgColor }}
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                  Portfolio Feature Curation
                </span>
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  {Object.values(featuredBrandCreators).filter(Boolean).length} Creators Featured
                </span>
              </div>

              <div className="space-y-1.5">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Star className="w-5 h-5 text-[#C9A46A]" />
                  Curate Featured Creators for Brand Portfolio
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Curate which creators (such as your 5 featured creators) appear on your agency's shared Brand Portfolio showcase link. Brands visiting the portfolio link will only see these featured creators.
                </p>
              </div>

              {/* Mini Search & Roster Toggle Grid */}
              <div className="space-y-2 pt-1">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search creators to curate..."
                    value={curationSearch}
                    onChange={(e) => setCurationSearch(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl py-2 pl-8 pr-4 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-[#C9A46A]/50"
                  />
                </div>

                <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                  {rosterCreators
                    .filter(c => {
                      const searchStr = curationSearch.toLowerCase();
                      return (c.name || '').toLowerCase().includes(searchStr) || (c.handle || '').toLowerCase().includes(searchStr);
                    })
                    .map(c => {
                      const isFeatured = featuredBrandCreators[c.handle];
                      return (
                        <div key={c.handle} className="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 transition">
                          <div className="flex items-center gap-2">
                            <img
                              src={c.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100"}
                              alt={c.name}
                              className="w-6 h-6 rounded-full object-cover border border-white/10"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <div className="text-xs font-bold text-white leading-tight">{c.name}</div>
                              <div className="text-[10px] text-slate-400 leading-none">{c.handle}</div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => toggleFeaturedCreator(c.handle)}
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center gap-1 transition ${
                              isFeatured 
                                ? 'bg-[#C9A46A] text-[#0A1220]' 
                                : 'bg-white/10 text-slate-300 hover:bg-white/20'
                            }`}
                          >
                            <Star className={`w-2.5 h-2.5 ${isFeatured ? 'fill-[#0A1220]' : ''}`} />
                            {isFeatured ? 'Featured' : 'Feature'}
                          </button>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between">
              <span className="text-[10px] text-slate-400">
                Changes persist automatically in real-time.
              </span>
              <button
                type="button"
                onClick={handleCurateAll}
                className="px-2.5 py-1 rounded bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 text-[#C9A46A] text-xs font-bold font-mono border border-[#C9A46A]/20 transition"
              >
                Curate Full Roster
              </button>
            </div>
          </div>

          {/* Card 2: Allow Agent & Talent Managers to Share Portfolio with Brands */}
          <div 
            className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all flex flex-col justify-between"
            style={{ backgroundColor: cardBgColor }}
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                  DIRECTOR CONTROL • BRAND PORTFOLIO SHARING POLICY
                </span>
                <span className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full border ${
                  localSettings.allowBrandMediaKitShare
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                }`}>
                  {localSettings.allowBrandMediaKitShare ? 'Staff Sharing Allowed' : 'Director Locked (Default)'}
                </span>
              </div>

              <div className="space-y-1.5">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#C9A46A]" />
                  Allow Agent &amp; Talent Managers to Share Portfolio with Brands
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Controls whether Talent Managers, Agent Managers, and Coordinators are permitted to copy and send this Brand Portfolio link to external brands. When locked, only the Creative Director can share the portfolio link.
                </p>

                {/* Director Brand Share Portfolio Link Action */}
                <div className="pt-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      id="director-copy-brand-share-link"
                      onClick={handleCopyBrandShareLink}
                      className="flex-1 py-2 px-3 rounded-xl bg-[#0F223D] border border-[#C9A46A]/40 text-[#C9A46A] hover:bg-[#C9A46A] hover:text-[#0B1528] text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-2 shadow-md"
                    >
                      {isCopiedBrandLink ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Portfolio Link Copied!</span>
                        </>
                      ) : (
                        <>
                          <Share2 className="w-3.5 h-3.5" />
                          <span>Share Portfolio With Brands</span>
                        </>
                      )}
                    </button>
                    <a
                      href={`${typeof window !== 'undefined' ? window.location.origin : ''}/#public-portfolio?brand=true`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl bg-[#111E33] border border-white/10 text-slate-300 hover:text-white hover:border-[#C9A46A]/50 transition cursor-pointer flex items-center justify-center"
                      title="Preview Brand Portfolio in New Tab"
                    >
                      <ExternalLink className="w-4 h-4 text-[#C9A46A]" />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-2 text-[10px] text-slate-400">
                <Info className="w-3.5 h-3.5 text-[#C9A46A]" />
                <span>
                  {localSettings.allowBrandMediaKitShare 
                    ? 'Staff is authorized to generate and share the Brand Portfolio link.' 
                    : 'Only Creative Director can share the Brand Portfolio link.'}
                </span>
              </div>

              {/* Big toggle switch at bottom right */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-slate-400">
                  {localSettings.allowBrandMediaKitShare ? 'Staff Sharing ON' : 'Director Locked'}
                </span>
                <button
                  type="button"
                  id="governance-director-brand-share"
                  onClick={() => handleToggle('allowBrandMediaKitShare', 'Staff Brand Portfolio Sharing')}
                  disabled={!isDirector}
                  className={`relative inline-flex h-7 w-14 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                    localSettings.allowBrandMediaKitShare ? 'bg-emerald-500' : 'bg-slate-700'
                  } ${!isDirector ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                      localSettings.allowBrandMediaKitShare ? 'translate-x-8' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* The Core Operational Switches */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center gap-2 border-b border-white/10 pb-2">
          <Sliders className="w-5 h-5 text-[#C9A46A]" />
          <h2 className="text-sm uppercase font-mono font-bold text-[#C9A46A] tracking-wider">
            Operational Staff Delegation Settings
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-5">
          {/* SWITCH 1: Campaign Workspace & Add Deliverables */}
          <div 
            className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all relative"
            style={{ backgroundColor: cardBgColor }}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                    Switch 1 &bull; Campaign Workspace Access
                  </span>
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                    localSettings.agentManagerCanAddCampaigns
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {localSettings.agentManagerCanAddCampaigns ? 'Permitted by Director' : 'Restricted (Default)'}
                  </span>
                </div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-[#C9A46A]" />
                  Agent Manager: Add Campaign &amp; Add Deliverables Switch
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Controls whether the Agent Manager has permission to create new direct campaigns in the Campaign Workspace and schedule new deliverables. 
                  <strong> When switched OFF, the "Add Deliverable" button will not show for the Agent Manager</strong>, reserving master P&amp;L and milestone commitments exclusively to the Director.
                </p>
              </div>

              {/* Toggle Switch */}
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs font-mono text-slate-400">
                  {localSettings.agentManagerCanAddCampaigns ? 'Active / Allowed' : 'Locked'}
                </span>
                <button
                  type="button"
                  id="switch-agentmgr-campaign-deliverables"
                  onClick={() => handleToggle('agentManagerCanAddCampaigns', 'Campaign & Deliverable Creation')}
                  disabled={!isDirector}
                  className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                    localSettings.agentManagerCanAddCampaigns ? 'bg-emerald-500' : 'bg-slate-700'
                  } ${!isDirector ? 'opacity-50 cursor-not-allowed' : ''}`}
                  title={isDirector ? 'Toggle Agent Manager campaign & deliverable permission' : 'Director only'}
                >
                  <span
                    className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                      localSettings.agentManagerCanAddCampaigns ? 'translate-x-9' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-400">
              <Info className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
              <span>
                {localSettings.agentManagerCanAddCampaigns
                  ? 'Agent Managers currently see "+ Add Campaign" and the "+ Add Deliverable" button on active deals.'
                  : 'Agent Managers currently cannot add campaigns and cannot see the "+ Add Deliverable" button.'}
              </span>
            </div>
          </div>

          {/* SWITCH 2: Public Portfolio Add Creator */}
          <div 
            className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all relative"
            style={{ backgroundColor: cardBgColor }}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                    Switch 2 &bull; Public Portfolio Access
                  </span>
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                    localSettings.agentManagerCanAddToPortfolio
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {localSettings.agentManagerCanAddToPortfolio ? 'Permitted by Director' : 'Restricted (Default)'}
                  </span>
                </div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#C9A46A]" />
                  Agent Manager: Add to Public Portfolio Switch
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Controls whether the Agent Manager can publish new creator profiles onto the agency's external Public Talent Showcase. 
                  <strong> When switched OFF, the "Add Creator" button will not show on the Public Portfolio for the Agent Manager</strong>, protecting agency portfolio branding and talent code anti-poaching safeguards.
                </p>
              </div>

              {/* Toggle Switch */}
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs font-mono text-slate-400">
                  {localSettings.agentManagerCanAddToPortfolio ? 'Active / Allowed' : 'Locked'}
                </span>
                <button
                  type="button"
                  id="switch-agentmgr-portfolio-add"
                  onClick={() => handleToggle('agentManagerCanAddToPortfolio', 'Public Portfolio Add Creator')}
                  disabled={!isDirector}
                  className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                    localSettings.agentManagerCanAddToPortfolio ? 'bg-emerald-500' : 'bg-slate-700'
                  } ${!isDirector ? 'opacity-50 cursor-not-allowed' : ''}`}
                  title={isDirector ? 'Toggle Agent Manager portfolio add permission' : 'Director only'}
                >
                  <span
                    className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                      localSettings.agentManagerCanAddToPortfolio ? 'translate-x-9' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-400">
              <Info className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
              <span>
                {localSettings.agentManagerCanAddToPortfolio
                  ? 'Agent Managers currently see "+ Add Creator" on the Public Creator Portfolio page.'
                  : 'The "+ Add Creator" button is hidden for Agent Managers on the Public Creator Portfolio.'}
              </span>
            </div>
          </div>

          {/* SWITCH 3: Creative Brief Drafting Access */}
          <div 
            className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all relative"
            style={{ backgroundColor: cardBgColor }}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                    Switch 3 &bull; Creative Brief Drafting Access
                  </span>
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                    localSettings.agentManagerCanDraftBriefs
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-amber-500/20 text-amber-300'
                  }`}>
                    {localSettings.agentManagerCanDraftBriefs ? 'Drafting Enabled' : 'View & Pass Only (Default)'}
                  </span>
                </div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-[#C9A46A]" />
                  Agent Manager: Creative Brief Drafting Switch
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Agent Managers do not control creative briefs by default. 
                  <strong> When switched OFF, all drafting and creating buttons are hidden from the Agent Manager</strong>, allowing them strictly to <strong>look at approved briefs and pass them to creators if they haven't received them yet</strong>.
                </p>
              </div>

              {/* Toggle Switch */}
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs font-mono text-slate-400">
                  {localSettings.agentManagerCanDraftBriefs ? 'Drafting Allowed' : 'Pass-Only (Locked)'}
                </span>
                <button
                  type="button"
                  id="switch-agentmgr-draft-briefs"
                  onClick={() => handleToggle('agentManagerCanDraftBriefs', 'Creative Brief Drafting')}
                  disabled={!isDirector}
                  className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                    localSettings.agentManagerCanDraftBriefs ? 'bg-emerald-500' : 'bg-slate-700'
                  } ${!isDirector ? 'opacity-50 cursor-not-allowed' : ''}`}
                  title={isDirector ? 'Toggle Agent Manager creative brief drafting access' : 'Director only'}
                >
                  <span
                    className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                      localSettings.agentManagerCanDraftBriefs ? 'translate-x-9' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-400">
              <Info className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
              <span>
                {localSettings.agentManagerCanDraftBriefs
                  ? 'Agent Managers have full compiler and brief drafting tools enabled.'
                  : 'Agent Managers can only inspect Director-approved briefs and click "Pass to Creator" if not yet received.'}
              </span>
            </div>
          </div>
        </div>

        {/* SWITCH 5: Staff Invoice & Billing Viewing */}
        <div 
          className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all relative"
          style={{ backgroundColor: cardBgColor }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                  Switch 5 &bull; Invoice &amp; Billing View Control
                </span>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                  localSettings.staffCanViewInvoices
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : 'bg-rose-500/20 text-rose-300'
                }`}>
                  {localSettings.staffCanViewInvoices ? 'Staff Viewing Allowed' : 'Director Locked (Default)'}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#C9A46A]" />
                Staff Invoice &amp; Billing Viewing Access (Agents &amp; Managers)
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                Controls whether Talent Agents and Agent Managers are permitted to view the Invoices &amp; Billing Workspace. 
                <strong> When switched OFF, staff cannot view invoices or billing data unless the Director authorizes them.</strong>
              </p>
            </div>

            {/* Toggle Switch */}
            <div className="flex items-center gap-3 shrink-0">
              <span className="text-xs font-mono text-slate-400">
                {localSettings.staffCanViewInvoices ? 'Staff Can View' : 'Director Locked'}
              </span>
              <button
                type="button"
                id="switch-director-invoice-view"
                onClick={() => handleToggle('staffCanViewInvoices', 'Staff Invoice & Billing Viewing')}
                disabled={!isDirector}
                className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                  localSettings.staffCanViewInvoices ? 'bg-emerald-500' : 'bg-slate-700'
                } ${!isDirector ? 'opacity-50 cursor-not-allowed' : ''}`}
                title={isDirector ? 'Toggle staff invoice viewing permission' : 'Director only'}
              >
                <span
                  className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                    localSettings.staffCanViewInvoices ? 'translate-x-9' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-400">
            <Info className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
            <span>
              {localSettings.staffCanViewInvoices
                ? 'Agents and Agent Managers are authorized to view the Invoice and Billing Workspace.'
                : 'Invoice viewing is hidden for staff members. Only the Creative Director can view invoices.'}
            </span>
          </div>
        </div>

        {/* SWITCH 6: Staff Invoice Creation */}
        <div 
          className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all relative"
          style={{ backgroundColor: cardBgColor }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                  Switch 6 &bull; Invoice Creation Control
                </span>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                  localSettings.staffCanCreateInvoices
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : 'bg-rose-500/20 text-rose-300'
                }`}>
                  {localSettings.staffCanCreateInvoices ? 'Staff Creation Allowed' : 'Director Locked (Default)'}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#C9A46A]" />
                Staff Invoice Creation &amp; Generation Access (Agents &amp; Managers)
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                Controls whether Talent Agents and Agent Managers are permitted to draft and send new invoices. 
                <strong> When switched OFF, staff cannot create, edit, or send invoices.</strong> Only the Creative Director has creation rights.
              </p>
            </div>

            {/* Toggle Switch */}
            <div className="flex items-center gap-3 shrink-0">
              <span className="text-xs font-mono text-slate-400">
                {localSettings.staffCanCreateInvoices ? 'Staff Can Create' : 'Director Locked'}
              </span>
              <button
                type="button"
                id="switch-director-invoice-create"
                onClick={() => handleToggle('staffCanCreateInvoices', 'Staff Invoice Creation')}
                disabled={!isDirector}
                className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                  localSettings.staffCanCreateInvoices ? 'bg-emerald-500' : 'bg-slate-700'
                } ${!isDirector ? 'opacity-50 cursor-not-allowed' : ''}`}
                title={isDirector ? 'Toggle staff invoice creation permission' : 'Director only'}
              >
                <span
                  className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                    localSettings.staffCanCreateInvoices ? 'translate-x-9' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 text-[11px] text-slate-400">
            <Info className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
            <span>
              {localSettings.staffCanCreateInvoices
                ? 'Agents and Agent Managers are authorized to draft and send new invoices to brands.'
                : 'Invoice creation tools are disabled for staff. Only the Creative Director can generate invoices.'}
            </span>
          </div>
        </div>

        {/* SWITCH 7: Announcements & Broadcasting */}
        <div 
          className="border border-white/10 rounded-2xl p-6 shadow-xl transition-all relative"
          style={{ backgroundColor: cardBgColor }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/30">
                  Switch 7 • Global Broadcast Authority
                </span>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                  localSettings.agentMgrCanAnnounce
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : 'bg-rose-500/20 text-rose-300'
                }`}>
                  {localSettings.agentMgrCanAnnounce ? 'Broadcasting Delegated' : 'Restricted to Director'}
                </span>
              </div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-[#C9A46A]" />
                Agent Manager: Team Announcements & Broadcasting Switch
              </h2>
              <p className="text-sm text-slate-400 leading-relaxed">
                When enabled, Agent Managers can send pod-wide announcements and broadcasts. When disabled, the announcement creation interface is hidden from Managers and restricted via server-side security rules.
              </p>
            </div>

            <div className="flex flex-col items-center gap-2">
              <button
                type="button"
                id="switch-director-announce"
                onClick={() => handleToggle('agentMgrCanAnnounce', 'Global Broadcasting')}
                disabled={!isDirector}
                className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                  localSettings.agentMgrCanAnnounce ? 'bg-emerald-500' : 'bg-slate-700'
                } ${!isDirector ? 'opacity-50 cursor-not-allowed' : ''}`}
                title={isDirector ? 'Toggle global broadcasting permission' : 'Director only'}
              >
                <span
                  className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${
                    localSettings.agentMgrCanAnnounce ? 'translate-x-9' : 'translate-x-1'
                  }`}
                />
              </button>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">
                {localSettings.agentMgrCanAnnounce ? 'Enabled' : 'Disabled'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
