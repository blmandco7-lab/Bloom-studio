import React, { useMemo } from 'react';
import { Layers, DollarSign, Users, CheckCircle, ArrowRight, Shield, Crown, Building2, TrendingUp, X } from 'lucide-react';
import { Creator, Deal } from '../types';

interface MultiPodExecutiveComparisonProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: string;
  currentUser: any;
  liveTenantsMap?: Record<string, any>;
  onSelectPod: (podId: string, podName: string) => void;
  campaigns?: any[];
  deals?: Deal[];
  invoices?: any[];
  creators?: Creator[];
  contentReviews?: any[];
  primaryBrandColor?: string;
}

interface PodMetrics {
  id: string;
  name: string;
  isCore: boolean;
  activeCampaignsCount: number;
  activeCampaignsValue: number;
  pendingRevenue: number;
  clearedRevenue: number;
  creatorCount: number;
  pendingReviewsCount: number;
  healthScore: number;
}

export default function MultiPodExecutiveComparison({
  isOpen,
  onClose,
  currentRole,
  currentUser,
  liveTenantsMap = {},
  onSelectPod,
  campaigns = [],
  deals = [],
  invoices = [],
  creators = [],
  contentReviews = [],
  primaryBrandColor = '#C9A46A',
}: MultiPodExecutiveComparisonProps) {
  const isDirector =
    (currentRole || '').toLowerCase() === 'director' ||
    currentUser?.isPlatformOwner ||
    currentUser?.role === 'director' ||
    currentUser?.role === 'owner';

  // Helper to match pod
  const matchesPod = (itemPod: any, targetPodId: string, targetPodName: string) => {
    if (!itemPod) return targetPodId === 'pod_main' || targetPodId === 'main';
    const str = String(itemPod).trim().toLowerCase();
    const tId = targetPodId.toLowerCase();
    const tName = targetPodName.toLowerCase();
    return str === tId || str === tName || (tId.includes('main') && (str.includes('main') || str.includes('bloom')));
  };

  // Build pods list from liveTenantsMap and defaults
  const podsList = useMemo(() => {
    const list = [
      { id: 'pod_main', name: 'Bloom & Co (HQ)', isMain: true },
      { id: 'pod_sports', name: 'Bloom Sports', isMain: false },
      { id: 'pod_viral', name: 'Viral Partners', isMain: false },
      { id: 'pod_creator_lab', name: 'Bloom Creator Lab', isMain: false },
      { id: 'pod_global', name: 'Bloom Global Media', isMain: false },
    ];

    if (liveTenantsMap) {
      Object.entries(liveTenantsMap).forEach(([tId, tData]: [string, any]) => {
        if (!list.some((p) => p.id.toLowerCase() === tId.toLowerCase())) {
          list.push({
            id: tId,
            name: tData.agencyName || tData.name || tId,
            isMain: false,
          });
        }
      });
    }

    return list;
  }, [liveTenantsMap]);

  // Aggregate metrics for each pod
  const podMetrics = useMemo<PodMetrics[]>(() => {
    return podsList.map((pod) => {
      // Campaigns in flight
      const podCampaigns = campaigns.filter((c: any) =>
        matchesPod(c.subagency || c.tenantId, pod.id, pod.name)
      );
      const activeCampaigns = podCampaigns.filter(
        (c: any) => c.stage && !['Completed', 'Cancelled', 'Archived'].includes(c.stage)
      );
      const activeCampaignsValue = activeCampaigns.reduce(
        (acc, c: any) => acc + (Number(c.value) || Number(c.budget) || 0),
        0
      );

      // Invoices
      const podInvoices = invoices.filter((inv: any) =>
        matchesPod(inv.subagency || inv.tenantId, pod.id, pod.name)
      );
      const pendingRevenue = podInvoices
        .filter((inv: any) => !['Paid', 'Cleared', 'Void'].includes(inv.status))
        .reduce((acc, inv: any) => acc + (Number(inv.amountDue ?? inv.amount) || 0), 0);

      const clearedRevenue = podInvoices
        .filter((inv: any) => ['Paid', 'Cleared'].includes(inv.status))
        .reduce((acc, inv: any) => acc + (Number(inv.amount) || 0), 0);

      // Deals in escrow
      const podDeals = deals.filter((d: any) =>
        matchesPod(d.subagency || d.tenantId, pod.id, pod.name)
      );
      const escrowDeals = podDeals.filter((d: any) =>
        ['In Escrow', 'Pending', 'In Review'].includes(d.status)
      );
      const escrowRevenue = escrowDeals.reduce((acc, d: any) => acc + (Number(d.value) || 0), 0);

      // Creators
      const podCreators = creators.filter((c: any) =>
        matchesPod(c.subagency || c.tenantId, pod.id, pod.name)
      );

      // Reviews
      const podReviews = contentReviews.filter(
        (r: any) =>
          matchesPod(r.subagency || r.tenantId, pod.id, pod.name) &&
          !['Approved', 'Rejected'].includes(r.status)
      );

      return {
        id: pod.id,
        name: pod.name,
        isCore: pod.isMain,
        activeCampaignsCount: activeCampaigns.length,
        activeCampaignsValue,
        pendingRevenue: pendingRevenue + escrowRevenue,
        clearedRevenue,
        creatorCount: podCreators.length,
        pendingReviewsCount: podReviews.length,
        healthScore: Math.min(100, 70 + activeCampaigns.length * 5 - podReviews.length * 2),
      };
    });
  }, [podsList, campaigns, invoices, deals, creators, contentReviews]);

  // Overall Network Totals
  const networkTotals = useMemo(() => {
    return podMetrics.reduce(
      (acc, m) => ({
        campaignsCount: acc.campaignsCount + m.activeCampaignsCount,
        pipelineValue: acc.pipelineValue + m.activeCampaignsValue,
        pendingRevenue: acc.pendingRevenue + m.pendingRevenue,
        clearedRevenue: acc.clearedRevenue + m.clearedRevenue,
        creators: acc.creators + m.creatorCount,
      }),
      { campaignsCount: 0, pipelineValue: 0, pendingRevenue: 0, clearedRevenue: 0, creators: 0 }
    );
  }, [podMetrics]);

  if (!isOpen) return null;

  // Strict multi-tenant security verification
  if (!isDirector) {
    return (
      <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
        <div className="bg-[#0D1830] border border-rose-500/40 rounded-2xl p-6 max-w-md w-full text-center space-y-4">
          <Shield className="w-12 h-12 text-rose-500 mx-auto" />
          <h3 className="text-lg font-bold text-white">Access Scoped to Pod</h3>
          <p className="text-xs text-slate-400">
            Multi-pod cross-network analytics is strictly restricted to Directors and Platform Owners. Non-director staff accounts are isolated to their explicit work pod.
          </p>
          <button
            type="button"
            onClick={onClose}
            className="w-full bg-white/10 hover:bg-white/20 text-white text-xs font-semibold py-2 rounded-xl transition-all"
          >
            Return
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      id="multi-pod-executive-comparison-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        id="multi-pod-executive-comparison-modal"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-5xl bg-[#0A1220] border border-[#C9A46A]/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="p-5 border-b border-white/10 bg-[#0E1B33] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2.5 rounded-2xl bg-[#C9A46A]/20 text-[#C9A46A] shrink-0 border border-[#C9A46A]/30">
              <Crown className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-serif font-bold text-white truncate">
                  Multi-Pod Executive Roll-Up
                </h2>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 shrink-0 font-semibold">
                  Director View
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate">
                Cross-tenant comparison and aggregate metrics across all active work desks.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-all cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Aggregate Network Roll-Up Banner */}
        <div className="p-5 bg-gradient-to-r from-[#111E33] to-[#0A1628] border-b border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] uppercase font-mono font-bold text-slate-400 block mb-1">
              Active Network Pipeline
            </span>
            <span className="text-xl font-mono font-bold text-white">
              ${networkTotals.pipelineValue.toLocaleString()}
            </span>
            <span className="text-[10px] text-emerald-400 block mt-0.5">
              {networkTotals.campaignsCount} live campaigns
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] uppercase font-mono font-bold text-slate-400 block mb-1">
              Pending Clearances (AR)
            </span>
            <span className="text-xl font-mono font-bold text-[#C9A46A]">
              ${networkTotals.pendingRevenue.toLocaleString()}
            </span>
            <span className="text-[10px] text-amber-300/80 block mt-0.5">
              Across all subagencies
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] uppercase font-mono font-bold text-slate-400 block mb-1">
              Cleared Revenue
            </span>
            <span className="text-xl font-mono font-bold text-emerald-400">
              ${networkTotals.clearedRevenue.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Settled invoices
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] uppercase font-mono font-bold text-slate-400 block mb-1">
              Network Talent Roster
            </span>
            <span className="text-xl font-mono font-bold text-cyan-300">
              {networkTotals.creators}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Signed creators
            </span>
          </div>
        </div>

        {/* Side-by-Side Pod Comparison Grid */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 custom-scrollbar">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {podMetrics.map((pod) => (
              <div
                key={pod.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                  pod.isCore
                    ? 'bg-[#111E33]/80 border-[#C9A46A]/50 shadow-md'
                    : 'bg-[#0E192C]/60 border-white/10 hover:border-white/20'
                }`}
              >
                <div>
                  {/* Pod Header */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="min-w-0">
                      <h4 className="text-sm font-bold text-white truncate flex items-center gap-1.5">
                        <Building2 className="w-4 h-4 text-[#C9A46A] shrink-0" />
                        {pod.name}
                      </h4>
                      <span className="text-[10px] font-mono text-slate-400">
                        {pod.id}
                      </span>
                    </div>
                    <span
                      className={`text-[9px] uppercase font-mono font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                        pod.isCore
                          ? 'bg-[#C9A46A]/20 text-[#C9A46A] border-[#C9A46A]/40'
                          : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                      }`}
                    >
                      {pod.isCore ? 'Core HQ' : 'Subagency'}
                    </span>
                  </div>

                  {/* Metrics Table */}
                  <div className="space-y-2 text-xs font-mono mb-4 bg-black/20 p-3 rounded-xl border border-white/5">
                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-[11px] text-slate-400">Active Pipeline:</span>
                      <span className="font-bold text-white">
                        ${pod.activeCampaignsValue.toLocaleString()} ({pod.activeCampaignsCount})
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-[11px] text-slate-400">Pending Receivables:</span>
                      <span className="font-bold text-[#C9A46A]">
                        ${pod.pendingRevenue.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-[11px] text-slate-400">Cleared Revenue:</span>
                      <span className="font-bold text-emerald-400">
                        ${pod.clearedRevenue.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-[11px] text-slate-400">Talent Capacity:</span>
                      <span className="font-bold text-cyan-300">
                        {pod.creatorCount} Creators
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-slate-300">
                      <span className="text-[11px] text-slate-400">Pending QA Approvals:</span>
                      <span
                        className={`font-bold ${
                          pod.pendingReviewsCount > 0 ? 'text-amber-300' : 'text-slate-400'
                        }`}
                      >
                        {pod.pendingReviewsCount}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Switch Desk Action */}
                <button
                  type="button"
                  onClick={() => {
                    onSelectPod(pod.id, pod.name);
                    onClose();
                  }}
                  className="w-full bg-white/5 hover:bg-[#C9A46A]/20 text-[#C9A46A] hover:text-white border border-[#C9A46A]/30 font-mono text-xs font-bold py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm"
                >
                  Switch to this Pod <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#091120] border-t border-white/10 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span className="flex items-center gap-1.5">
            <Shield className="w-4 h-4 text-[#C9A46A]" /> Director-Level Cross-Tenant Verification Active
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold cursor-pointer transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
