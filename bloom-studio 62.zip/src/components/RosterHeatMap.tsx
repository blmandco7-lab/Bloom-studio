import React, { useState } from 'react';
import { 
  Users, CheckCircle2, AlertTriangle, XCircle, Search, 
  ShieldCheck, Clock, FileText, Send, UserCheck, Activity, Award
} from 'lucide-react';
import { Creator, Role } from '../types';

interface RosterHeatMapProps {
  creators: Creator[];
  currentRole: Role;
  currentUser?: any;
  onboardingItems?: any[];
  contentSubmissions?: any[];
  deals?: any[];
  primaryBrandColor?: string;
  onUpdateCreatorStatus?: (creatorId: string, status: string) => void;
  onAssignAgent?: (creatorId: string) => void;
  onNavigateChat?: (creatorName: string) => void;
}

export const RosterHeatMap: React.FC<RosterHeatMapProps> = ({
  creators,
  currentRole,
  currentUser,
  onboardingItems = [],
  contentSubmissions = [],
  deals = [],
  primaryBrandColor = '#C9A46A',
  onUpdateCreatorStatus,
  onAssignAgent,
  onNavigateChat
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'green' | 'gold' | 'red'>('all');

  const role = (currentRole || 'none').toLowerCase();

  // 1. Role-based scoping of creators list
  const getScopedCreators = () => {
    if (role === 'director' || role === 'agentmgr') {
      return creators;
    } else if (role === 'agent') {
      const agentName = currentUser?.name || 'Tasha Reed';
      return creators.filter(c => 
        c.assignedAgent?.toLowerCase() === agentName.toLowerCase() ||
        c.assignedAgent?.toLowerCase() === currentUser?.handle.toLowerCase() ||
        c.assignedAgent === 'Tasha Reed'
      );
    } else if (role === 'subagency') {
      const subagencyName = currentUser?.subagency || currentUser?.name || 'Bloom & Co';
      const normSub = subagencyName.toLowerCase();
      return creators.filter(c => 
        (c.subagency && c.subagency.toLowerCase().includes(normSub)) ||
        (c.agency && c.agency.toLowerCase().includes(normSub)) ||
        (normSub.includes('bloom') && (c.subagency?.toLowerCase().includes('bloom') || c.agency?.toLowerCase().includes('bloom'))) ||
        (normSub.includes('viral') && (c.subagency?.toLowerCase().includes('viral') || c.agency?.toLowerCase().includes('viral')))
      );
    }
    return creators;
  };

  const scopedCreators = getScopedCreators();

  // 2. Health Calculation Engine per creator
  const calculateCreatorHealth = (creator: Creator) => {
    let score = 100;
    const flags: { type: 'green' | 'gold' | 'red'; text: string }[] = [];

    // Check onboarding
    const ob = onboardingItems.find(o => o.handle?.toLowerCase() === creator.handle?.toLowerCase() || o.name === creator.name);
    if (ob) {
      const totalSteps = ob.steps?.length || 0;
      const doneSteps = ob.steps?.filter((s: any) => s.done)?.length || 0;
      if (totalSteps > 0 && doneSteps < totalSteps) {
        score -= 20;
        flags.push({ type: 'gold', text: `Onboarding: ${doneSteps}/${totalSteps} complete` });
      }
    } else if (creator.status === 'Pending Onboarding') {
      score -= 25;
      flags.push({ type: 'gold', text: 'Pending Onboarding Checklist' });
    }

    // Check deliverable submissions
    const creatorSubs = contentSubmissions.filter(s => s.creatorHandle?.toLowerCase() === creator.handle?.toLowerCase());
    const pendingSubs = creatorSubs.filter(s => s.status?.includes('Pending') || s.status?.includes('Revision'));
    if (pendingSubs.length > 0) {
      score -= 15;
      flags.push({ type: 'gold', text: `${pendingSubs.length} deliverable(s) in review/revision` });
    }

    // Check status flag
    if (creator.status === 'Risk') {
      score -= 50;
      flags.push({ type: 'red', text: 'Flagged as High Risk / Deliverable Overdue' });
    } else if (creator.status === 'Active') {
      flags.push({ type: 'green', text: 'Active Roster Contract Verified' });
    }

    // Check active deals
    const activeCreatorDeals = deals.filter(d => d.creator?.toLowerCase() === creator.handle?.toLowerCase() || d.creatorName === creator.name);
    if (activeCreatorDeals.length > 0) {
      flags.push({ type: 'green', text: `${activeCreatorDeals.length} Active Brand Campaign(s)` });
    } else {
      score -= 10;
      flags.push({ type: 'gold', text: 'No active brand deals in pipeline' });
    }

    // Clamp score
    const finalScore = Math.max(10, Math.min(100, score));

    let statusCategory: 'green' | 'gold' | 'red' = 'green';
    if (finalScore >= 80 && creator.status !== 'Risk') {
      statusCategory = 'green';
    } else if (finalScore >= 50 && creator.status !== 'Risk') {
      statusCategory = 'gold';
    } else {
      statusCategory = 'red';
    }

    return { score: finalScore, category: statusCategory, flags };
  };

  const processedCreators = scopedCreators.map(creator => {
    const health = calculateCreatorHealth(creator);
    return { ...creator, health };
  });

  // Filtered creators
  const filteredCreators = processedCreators.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.handle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.niche.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || c.health.category === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Count summaries
  const greenCount = processedCreators.filter(c => c.health.category === 'green').length;
  const goldCount = processedCreators.filter(c => c.health.category === 'gold').length;
  const redCount = processedCreators.filter(c => c.health.category === 'red').length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Health Header / Summary Counters */}
      <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-400 animate-pulse" />
              <h2 className="text-lg font-serif font-bold text-white">Roster Performance & Risk Heat Map</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Real-time health telemetry evaluated by deliverable deadlines, W-9 compliance, and active contract pipeline ({scopedCreators.length} Total Talent).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer ${
                statusFilter === 'all' ? 'bg-white/20 text-white border border-white/40' : 'bg-[#111E33] text-slate-400 hover:text-white'
              }`}
            >
              All ({processedCreators.length})
            </button>
            <button
              onClick={() => setStatusFilter('green')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                statusFilter === 'green' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' : 'bg-emerald-950/30 text-emerald-400/70 hover:text-emerald-400'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>On Track ({greenCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('gold')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                statusFilter === 'gold' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50' : 'bg-amber-950/30 text-amber-400/70 hover:text-amber-400'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>Attention ({goldCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('red')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                statusFilter === 'red' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/50' : 'bg-rose-950/30 text-rose-400/70 hover:text-rose-400'
              }`}
            >
              <XCircle className="w-3.5 h-3.5 text-rose-400" />
              <span>At Risk ({redCount})</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search roster by creator name, handle, or niche..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Heat Map Grid */}
      {filteredCreators.length === 0 ? (
        <div className="p-12 text-center bg-[#0D1830] border border-white/5 rounded-2xl text-slate-400">
          <Users className="w-10 h-10 mx-auto text-slate-600 mb-2" />
          <p className="text-xs">No creators match the active filter or search term.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredCreators.map(c => {
            const { score, category, flags } = c.health;

            let borderStyle = 'border-emerald-500/40 bg-emerald-950/10 shadow-emerald-950/50';
            let badgeBg = 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
            let badgeText = '🟢 ON TRACK';

            if (category === 'gold') {
              borderStyle = 'border-amber-500/40 bg-amber-950/10 shadow-amber-950/50';
              badgeBg = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
              badgeText = '🟡 ATTENTION NEEDED';
            } else if (category === 'red') {
              borderStyle = 'border-rose-500/50 bg-rose-950/20 shadow-rose-950/50';
              badgeBg = 'bg-rose-500/20 text-rose-300 border-rose-500/40';
              badgeText = '🔴 AT RISK / OVERDUE';
            }

            return (
              <div
                key={c.id}
                className={`border rounded-2xl p-5 space-y-4 shadow-xl transition-all duration-300 hover:scale-[1.01] ${borderStyle}`}
              >
                {/* Top header row */}
                <div className="flex justify-between items-start gap-2">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-10 h-10 rounded-full font-bold text-xs flex items-center justify-center font-serif text-slate-950 shadow-md"
                      style={{ backgroundColor: primaryBrandColor }}
                    >
                      {c.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">{c.name}</h3>
                      <span className="text-xs font-mono text-amber-400 block">{c.handle}</span>
                    </div>
                  </div>

                  <span className={`text-[9px] font-mono font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider ${badgeBg}`}>
                    {badgeText}
                  </span>
                </div>

                {/* Score bar */}
                <div className="bg-[#0A1220] p-3 rounded-xl border border-white/5 space-y-1.5">
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-slate-400">HEALTH INDEX SCORE</span>
                    <span className={`font-bold ${category === 'green' ? 'text-emerald-400' : category === 'gold' ? 'text-amber-400' : 'text-rose-400'}`}>
                      {score}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-white/5">
                    <div
                      className={`h-full transition-all duration-500 ${
                        category === 'green' ? 'bg-emerald-400' : category === 'gold' ? 'bg-amber-400' : 'bg-rose-500'
                      }`}
                      style={{ width: `${score}%` }}
                    ></div>
                  </div>
                </div>

                {/* Key stats row */}
                <div className="grid grid-cols-3 gap-2 text-center font-mono">
                  <div className="p-2 bg-[#111E33] rounded-lg border border-white/5">
                    <span className="text-[9px] text-slate-400 block">FOLLOWERS</span>
                    <span className="text-xs font-bold text-white">{c.followers || '100K'}</span>
                  </div>
                  <div className="p-2 bg-[#111E33] rounded-lg border border-white/5">
                    <span className="text-[9px] text-slate-400 block">ENGAGEMENT</span>
                    <span className="text-xs font-bold text-emerald-400">{c.eng || '4.2%'}</span>
                  </div>
                  <div className="p-2 bg-[#111E33] rounded-lg border border-white/5">
                    <span className="text-[9px] text-slate-400 block">AGENT</span>
                    <span className="text-[10px] font-bold text-amber-300 truncate block">
                      {c.assignedAgent || 'Marcus Cole'}
                    </span>
                  </div>
                </div>

                {/* Drivers / Flags */}
                <div className="space-y-1.5">
                  <span className="text-[9px] font-mono uppercase text-slate-400 block">TELEMETRY DRIVERS:</span>
                  <div className="space-y-1">
                    {flags.map((f, idx) => (
                      <div
                        key={idx}
                        className={`text-[10px] p-2 rounded-lg border font-mono flex items-center gap-1.5 ${
                          f.type === 'green'
                            ? 'bg-emerald-950/30 text-emerald-300 border-emerald-500/20'
                            : f.type === 'gold'
                            ? 'bg-amber-950/30 text-amber-300 border-amber-500/20'
                            : 'bg-rose-950/40 text-rose-300 border-rose-500/20'
                        }`}
                      >
                        {f.type === 'green' && <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />}
                        {f.type === 'gold' && <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />}
                        {f.type === 'red' && <XCircle className="w-3 h-3 text-rose-400 shrink-0" />}
                        <span className="truncate">{f.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick actions per creator */}
                <div className="pt-2 border-t border-white/10 flex items-center gap-2 justify-between">
                  {onUpdateCreatorStatus && (
                    <button
                      onClick={() => {
                        const newStatus = c.status === 'Active' ? 'Risk' : 'Active';
                        onUpdateCreatorStatus(c.id, newStatus);
                      }}
                      className="text-[10px] font-mono px-2.5 py-1.5 rounded-lg bg-[#111E33] hover:bg-white/10 text-slate-300 border border-white/10 transition cursor-pointer"
                    >
                      Toggle Status ({c.status})
                    </button>
                  )}

                  {onNavigateChat && (
                    <button
                      onClick={() => onNavigateChat(c.name)}
                      className="text-[10px] font-mono px-2.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 transition cursor-pointer flex items-center gap-1"
                    >
                      <Send className="w-3 h-3" />
                      <span>Message</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
