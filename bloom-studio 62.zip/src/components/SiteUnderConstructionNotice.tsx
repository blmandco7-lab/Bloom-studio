import React, { useState } from 'react';
import { ShieldAlert, Wrench, Lock, RefreshCw, AlertTriangle, CheckCircle, Info, ExternalLink } from 'lucide-react';
import { MaintenanceConfig } from '../lib/maintenanceConfig';

interface SiteUnderConstructionNoticeProps {
  config: MaintenanceConfig;
  currentUser?: any;
  onDeactivateKillSwitch?: () => Promise<void> | void;
  onBypassToAdmin?: () => void;
}

export const SiteUnderConstructionNotice: React.FC<SiteUnderConstructionNoticeProps> = ({
  config,
  currentUser,
  onDeactivateKillSwitch,
  onBypassToAdmin,
}) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isDeactivating, setIsDeactivating] = useState(false);

  const isPlatformOwner = Boolean(
    currentUser?.isPlatformOwner ||
    currentUser?.email === 'lilbitnd06@gmail.com' ||
    currentUser?.role === 'owner'
  );

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      window.location.reload();
    }, 400);
  };

  const handleToggleOff = async () => {
    if (!onDeactivateKillSwitch) return;
    setIsDeactivating(true);
    try {
      await onDeactivateKillSwitch();
    } finally {
      setIsDeactivating(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070D18] text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8 relative selection:bg-[#C9A46A]/30">
      {/* Subtle architectural background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem] pointer-events-none" />

      {/* Header bar */}
      <header className="relative z-10 max-w-5xl mx-auto w-full flex items-center justify-between py-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-sm">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-[#C9A46A]">
              Bloom Studio Platform
            </div>
            <div className="text-sm font-semibold text-white">
              System Operations & Integrity Gate
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/10 border border-rose-500/30 text-rose-300">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            Lockdown Mode Active
          </span>
        </div>
      </header>

      {/* Main Notice Card */}
      <main className="relative z-10 max-w-3xl mx-auto w-full my-auto py-8">
        <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl p-6 sm:p-10 shadow-2xl space-y-8 relative overflow-hidden">
          {/* Top Amber Accent Line */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-rose-500 to-amber-500" />

          {/* Title Area */}
          <div className="space-y-3 text-center sm:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Platform Maintenance & Security Protocol</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
              This Site Is Currently Under Construction & Maintenance
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
              {config.reason ||
                'The system is temporarily suspended for scheduled platform upgrades, infrastructure maintenance, and security verifications. Public interactions and signing services are paused.'}
            </p>
          </div>

          {/* Impact Status Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
                <Lock className="w-4 h-4" />
                <span>Contract Signing Blocked</span>
              </div>
              <p className="text-xs text-slate-300 leading-normal">
                All digital contract signatures, e-sign links, and deal executions are temporarily locked to prevent unverified submissions or state conflicts.
              </p>
            </div>

            <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
                <ShieldAlert className="w-4 h-4" />
                <span>Data Safeguards Active</span>
              </div>
              <p className="text-xs text-slate-300 leading-normal">
                Your agency records, financial ledgers, creator rosters, and assets are securely quarantined and protected under immutable audit locks.
              </p>
            </div>
          </div>

          {/* Operational Details Box */}
          <div className="bg-[#080E1A] border border-white/10 rounded-xl p-4 text-xs space-y-2.5">
            <div className="flex items-center justify-between text-slate-400">
              <span className="font-mono">Security Advisory:</span>
              <span className="text-slate-200 font-semibold font-mono">SEC-LOCKDOWN-2026</span>
            </div>
            {config.activatedAt && (
              <div className="flex items-center justify-between text-slate-400">
                <span>Lockdown Activated:</span>
                <span className="text-slate-200 font-mono">
                  {new Date(config.activatedAt).toLocaleString()}
                </span>
              </div>
            )}
            <div className="flex items-center justify-between text-slate-400">
              <span>Status:</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Core Database Isolated & Safe
              </span>
            </div>
          </div>

          {/* Actions Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 border-t border-white/10">
            <p className="text-xs text-slate-400 text-center sm:text-left">
              If you have urgent questions, contact your Agency Director or system operations.
            </p>

            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
              <span>{isRefreshing ? 'Checking Status...' : 'Check If System Is Back Online'}</span>
            </button>
          </div>

          {/* Platform Owner Administrative Override Deck */}
          {isPlatformOwner && (
            <div className="mt-6 pt-6 border-t border-amber-500/20 bg-amber-500/5 rounded-xl p-4 border space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm">👑</span>
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                    Platform Owner Override Privilege
                  </span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  {currentUser?.email || 'Platform Superuser'}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                You are recognized as the Platform Owner. You can bypass the construction gate to perform administrative repairs, or deactivate the Emergency Kill Switch directly:
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  onClick={handleToggleOff}
                  disabled={isDeactivating}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer disabled:opacity-50"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>{isDeactivating ? 'Disabling Lockdown...' : 'Deactivate Kill Switch (Return Site Live)'}</span>
                </button>

                {onBypassToAdmin && (
                  <button
                    onClick={onBypassToAdmin}
                    className="px-4 py-2 rounded-xl bg-[#111E33] hover:bg-[#162742] border border-white/10 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span>Proceed into Director Administration</span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#C9A46A]" />
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 max-w-5xl mx-auto w-full py-4 text-center text-xs text-slate-500 border-t border-white/5">
        Bloom Studio Enterprise Network • Platform Emergency Kill Switch & Continuous Assurance System
      </footer>
    </div>
  );
};

export default SiteUnderConstructionNotice;
