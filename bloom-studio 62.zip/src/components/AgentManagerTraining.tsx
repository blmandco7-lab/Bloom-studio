
import React, { useState, useEffect } from 'react';
import { 
  Shield, ShieldCheck, Clock, Users, DollarSign, BookOpen, 
  Play, Pause, FileText, CheckCircle2, ChevronRight, RotateCcw, 
  AlertCircle, Loader2, Maximize2, Volume2, ArrowLeft
} from 'lucide-react';
import { AGENT_MANAGER_PHASES, TrainingPhase } from '../data/agentManagerTraining';
import ReactMarkdown from 'react-markdown';
import { safeStorage } from '../utils/safeStorage';

interface AgentManagerTrainingProps {
  currentUser?: any;
  onBack?: () => void;
  onCompletePhase?: (phaseId: string) => void;
}

export default function AgentManagerTraining({ currentUser, onBack, onCompletePhase }: AgentManagerTrainingProps) {
  
  const [activePhaseIndex, setActivePhaseIndex] = useState(0);
  const [viewMode, setViewMode] = useState<'video' | 'sheet'>('video');
  const [isPlaying, setIsPlaying] = useState(false);
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);
  
  // Custom video URLs state (simulating Director uploads)
  const [customVideos, setCustomVideos] = useState<Record<string, string>>(() => {
    try {
      const saved = safeStorage.getItem('wl_training_videos');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Watch progress tracking per phase
  const [watchProgress, setWatchProgress] = useState<Record<string, number>>(() => {
    try {
      const saved = safeStorage.getItem('wl_training_progress');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  
  // Track completed step sub-items
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>(() => {
    try {
      const saved = safeStorage.getItem('wl_training_completed_steps');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const toggleStepCompleted = (stepKey: string) => {
    setCompletedSteps(prev => {
      const updated = { ...prev, [stepKey]: !prev[stepKey] };
      safeStorage.setItem('wl_training_completed_steps', JSON.stringify(updated));
      return updated;
    });
  };

  const handleDownloadSopPdf = (title: string, content: string) => {
    const blob = new Blob([`OFFICIAL STUDIO STANDARD OPERATING PROCEDURE\n\nTopic: ${title}\nDate: ${new Date().toLocaleDateString()}\n\n${content}`], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SOP_${title.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  
  // Interactive Navigation Video states
  const [completedBy, setCompletedBy] = useState<Record<string, string[]>>(() => {
    try {
      return JSON.parse(safeStorage.getItem('wl_training_completed_by') || '{}');
    } catch {
      return {};
    }
  });
  const [isPlayingNav, setIsPlayingNav] = useState(false);
  const [navVideoUrl, setNavVideoUrl] = useState(() => {
    try {
      return safeStorage.getItem('wl_nav_video') || '';
    } catch {
      return '';
    }
  });
  const [navWatchProgress, setNavWatchProgress] = useState(() => {
    try {
      return parseInt(safeStorage.getItem('wl_nav_progress') || '0', 10);
    } catch {
      return 0;
    }
  });
  const [showNavUpload, setShowNavUpload] = useState(false);
  const [newNavVideoUrl, setNewNavVideoUrl] = useState('');
  
  useEffect(() => {
    safeStorage.setItem('wl_nav_video', navVideoUrl);
  }, [navVideoUrl]);

  useEffect(() => {
    safeStorage.setItem('wl_nav_progress', navWatchProgress.toString());
  }, [navWatchProgress]);

  // Simulate Nav Video progress
  useEffect(() => {
    let interval: any;
    if (isPlayingNav) {
      interval = setInterval(() => {
        setNavWatchProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            return 100;
          }
          const next = prev + 5;
          if (next >= 100 && currentUser?.email) {
            // First time hitting 100%
            setCompletedBy(curr => {
              const currentList = curr['interactive_nav'] || [];
              if(!currentList.includes(currentUser.email)) {
                return { ...curr, ['interactive_nav']: [...currentList, currentUser.email] };
              }
              return curr;
            });
          }
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlayingNav, currentUser]);

  const [showUploadMenu, setShowUploadMenu] = useState(false);
  const [newVideoUrl, setNewVideoUrl] = useState('');
  const isDirector = currentUser?.role === 'director' || currentUser?.role === 'admin';

  const activePhase = AGENT_MANAGER_PHASES[activePhaseIndex];
  const currentVideoUrl = customVideos[activePhase.id] || activePhase.videoUrl;
  const currentProgress = watchProgress[activePhase.id] || 0;
  
  // Has the current user (if not director) fully watched the video?
  const isVideoComplete = currentProgress >= 100;
  
  useEffect(() => {
    safeStorage.setItem('wl_training_videos', JSON.stringify(customVideos));
  }, [customVideos]);

  useEffect(() => {
    safeStorage.setItem('wl_training_progress', JSON.stringify(watchProgress));
  }, [watchProgress]);
  
  useEffect(() => {
    safeStorage.setItem('wl_training_completed_by', JSON.stringify(completedBy));
  }, [completedBy]);

  // Simulate video playback progress
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setWatchProgress(prev => {
          const current = prev[activePhase.id] || 0;
          if (current >= 100) {
            clearInterval(interval);
            return prev; // Already 100%
          }
          return {
            ...prev,
            [activePhase.id]: current + 5 // 5% per second (simulated 20s video for demo)
          };
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, activePhase.id]);


  const getPhaseIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shield': return <Shield className="w-5 h-5" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5" />;
      case 'Clock': return <Clock className="w-5 h-5" />;
      case 'Users': return <Users className="w-5 h-5" />;
      case 'DollarSign': return <DollarSign className="w-5 h-5" />;
      default: return <BookOpen className="w-5 h-5" />;
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 animate-fadeIn">
      {/* Header Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2.5 rounded-xl bg-[#0D1830] border border-white/10 text-slate-400 hover:text-white hover:border-[#C9A46A]/50 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-serif font-bold text-white flex items-center gap-2">
              <ShieldCheck className="text-[#C9A46A] w-7 h-7" />
              Agent Manager: Technical Procedures & SOPs
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1">
              Official training portal for platform security, compliance, and management protocols.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex flex-col items-end">
            <span className="text-[10px] font-mono text-[#C9A46A] font-bold uppercase tracking-widest">Training Progress</span>
            <span className="text-sm font-bold text-white font-mono">PHASE {activePhaseIndex + 1} / 5</span>
          </div>
          <div className="h-10 w-10 rounded-full border-2 border-[#C9A46A]/20 flex items-center justify-center p-1">
            <div className="w-full h-full rounded-full border-2 border-[#C9A46A] border-t-transparent animate-spin-slow"></div>
          </div>
        </div>
      </div>

      {/* Main Training Console */}
      <div className="bg-[#0D1830] border border-[#C9A46A]/20 rounded-3xl overflow-hidden shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          
          {/* Left Sidebar: Phased Curriculum */}
          <div className="lg:col-span-4 border-r border-white/5 bg-[#0A1220]/50 flex flex-col">
            <div className="p-6 border-b border-white/5">
              <h3 className="text-xs font-mono font-bold text-[#C9A46A] uppercase tracking-widest">Management Phases</h3>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              {AGENT_MANAGER_PHASES.map((phase, idx) => (
                <button
                  key={phase.id}
                  onClick={() => {
                    setActivePhaseIndex(idx);
                    setIsPlaying(false);
                    setPlayingVideo(null);
                  }}
                  className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-4 group ${
                    activePhaseIndex === idx
                      ? 'bg-[#16243F] border-[#C9A46A]/40 shadow-xl'
                      : 'bg-transparent border-transparent hover:bg-white/5 text-[#7C8AA8]'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                    activePhaseIndex === idx 
                      ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg shadow-amber-500/20 rotate-3' 
                      : 'bg-[#111E33] text-[#7C8AA8]'
                  }`}>
                    {getPhaseIcon(phase.icon)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold text-[#C9A46A]">0{phase.number}</span>
                      {activePhaseIndex > idx && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <h4 className={`text-sm font-bold truncate mt-0.5 ${activePhaseIndex === idx ? 'text-white' : 'group-hover:text-white'}`}>
                      {phase.title}
                    </h4>
                    <p className="text-[11px] text-[#5A6984] line-clamp-1 mt-1 leading-relaxed">
                      {phase.desc}
                    </p>
                  </div>
                </button>
              ))}
            </div>

            <div className="p-6 bg-black/20 border-t border-white/5">
              <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-2xl space-y-2">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[#C9A46A]" />
                  <h5 className="text-[10px] font-bold text-white uppercase tracking-widest">Security Notice</h5>
                </div>
                <p className="text-[10px] text-[#7C8AA8] leading-relaxed">
                  Phase completion marks are transmitted to the Director Console via encrypted user tokens [9hqWU2].
                </p>
              </div>
            </div>
          </div>

          {/* Right Content Area: Interactive Learning */}
          <div className="lg:col-span-8 flex flex-col min-h-[650px] bg-[#0A1220]/20">
            {/* Context Tab Bar */}
            <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between bg-black/20">
              <div className="flex items-center gap-2 p-1 bg-[#111E33] border border-white/5 rounded-xl">
                <button
                  onClick={() => setViewMode('video')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                    viewMode === 'video' ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg' : 'text-[#7C8AA8] hover:text-white'
                  }`}
                >
                  <Play className="w-3.5 h-3.5" />
                  Video Module
                </button>
                <button
                  onClick={() => setViewMode('sheet')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                    viewMode === 'sheet' ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg' : 'text-[#7C8AA8] hover:text-white'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  Procedure Sheet
                </button>
              </div>
              
              <div className="flex items-center gap-3">
                <span className="hidden sm:inline text-[10px] font-mono text-[#5A6984] uppercase tracking-widest">
                  Verifying: {activePhase.id.toUpperCase()}
                </span>
                <div className="h-6 w-px bg-white/10"></div>
                
                {activePhaseIndex < AGENT_MANAGER_PHASES.length - 1 && (
                  <button 
                    disabled={!isVideoComplete && !isDirector}
                    onClick={() => {
                      // Mark complete in tracker
                      if(currentUser?.email) {
                        setCompletedBy(prev => {
                          const currentList = prev[activePhase.id] || [];
                          if(!currentList.includes(currentUser.email)) {
                            return { ...prev, [activePhase.id]: [...currentList, currentUser.email] };
                          }
                          return prev;
                        });
                      }
                      setActivePhaseIndex(prev => prev + 1);
                      if (onCompletePhase) onCompletePhase(activePhase.id);
                    }}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-xl border text-xs font-bold transition-all group ${
                      (!isVideoComplete && !isDirector)
                        ? 'bg-white/5 border-white/5 text-white/30 cursor-not-allowed'
                        : 'bg-[#C9A46A]/10 text-[#C9A46A] border-[#C9A46A]/30 hover:bg-[#C9A46A] hover:text-[#0A1220]'
                    }`}
                    title={(!isVideoComplete && !isDirector) ? 'You must watch the full briefing video first' : ''}
                  >
                    {!isVideoComplete && !isDirector ? 'Watch Video to Unlock' : 'Complete Phase'}
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                  </button>
                )}

              </div>
            </div>

            {/* Content Display */}
            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
              {viewMode === 'video' ? (
                <div className="space-y-8 max-w-3xl mx-auto">
                  <div className="aspect-video bg-black rounded-3xl border border-white/5 overflow-hidden relative shadow-2xl group">
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-t from-black/90 via-black/20 to-black/60">
                      
                      {isPlaying && playingVideo === currentVideoUrl ? (
                        <div className="space-y-6 text-center p-10 bg-black/60 backdrop-blur-md rounded-3xl border border-white/10 w-full max-w-sm">
                          <div className="relative">
                            <Loader2 className="w-16 h-16 text-[#C9A46A] animate-spin mx-auto" />
                            <div className="absolute inset-0 flex items-center justify-center">
                              <span className="text-[10px] font-mono text-white">{Math.min(currentProgress, 100)}%</span>
                            </div>
                          </div>
                          <div>
                            <p className="text-sm font-bold text-white tracking-wide">Streaming Procedure Video...</p>
                            <div className="w-full h-1.5 bg-white/10 rounded-full mt-4 overflow-hidden">
                              <div className="h-full bg-[#C9A46A] transition-all duration-1000" style={{ width: `${Math.min(currentProgress, 100)}%` }} />
                            </div>
                            <p className="text-[10px] text-[#7C8AA8] mt-2 font-mono uppercase tracking-[0.2em]">
                              {activePhase.title}
                            </p>
                          </div>
                          <button 
                            onClick={() => setIsPlaying(false)}
                            className="w-full py-3 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl transition-all border border-white/10"
                          >
                            Pause Briefing
                          </button>
                        </div>
                      ) : (
                        <div className="text-center p-8 animate-scale-up w-full">
                          <button 
                            onClick={() => {
                              setPlayingVideo(currentVideoUrl);
                              setIsPlaying(true);
                            }}
                            className="w-24 h-24 rounded-full bg-[#C9A46A] text-[#0A1220] flex items-center justify-center shadow-2xl shadow-amber-500/40 hover:scale-110 active:scale-95 transition-all mb-8 mx-auto group"
                          >
                            <Play fill="#0A1220" className="w-12 h-12 ml-1.5 group-hover:scale-110 transition-transform" />
                          </button>
                          <h3 className="text-2xl font-serif font-bold text-white">{activePhase.title}</h3>
                          <p className="text-sm text-[#7C8AA8] mt-3 max-w-md mx-auto leading-relaxed">
                            Watch the required management briefing before accessing the technical procedure sheet for this phase.
                          </p>
                          {currentProgress > 0 && currentProgress < 100 && (
                             <div className="mt-4 inline-block px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] font-bold uppercase tracking-wider">
                               Video Incomplete: {currentProgress}% Watched
                             </div>
                          )}
                          {currentProgress >= 100 && (
                             <div className="mt-4 inline-block px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 justify-center mx-auto">
                               <CheckCircle2 className="w-3.5 h-3.5" /> Video Verified
                             </div>
                          )}
                          
                          {/* Director Upload Section */}
                          {isDirector && (
                            <div className="mt-8 p-4 bg-black/40 border border-white/10 rounded-2xl max-w-sm mx-auto text-left">
                               <div className="flex justify-between items-center mb-3">
                                 <span className="text-[10px] font-mono text-[#C9A46A] uppercase tracking-widest">Director Controls</span>
                                 <button onClick={() => setShowUploadMenu(!showUploadMenu)} className="text-[10px] text-white underline hover:text-[#C9A46A]">
                                   {showUploadMenu ? 'Cancel' : 'Replace Video'}
                                 </button>
                               </div>
                               {showUploadMenu && (
                                 <div className="space-y-3">
                                   <input 
                                     type="text"
                                     value={newVideoUrl}
                                     onChange={(e) => setNewVideoUrl(e.target.value)}
                                     placeholder="Enter new video URL (mp4, youtube, etc.)"
                                     className="w-full bg-[#050e1a] border border-blue-900 rounded-lg p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                                   />
                                   <button 
                                     onClick={() => {
                                       if(newVideoUrl) {
                                         setCustomVideos(prev => ({ ...prev, [activePhase.id]: newVideoUrl }));
                                         setShowUploadMenu(false);
                                         setNewVideoUrl('');
                                       }
                                     }}
                                     className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg transition-all"
                                   >
                                     Save New Video URL
                                   </button>
                                 </div>
                               )}
                            </div>
                          )}
                        </div>
                      )}

                    </div>
                  </div>
                </div>
              ) : (
                <div className="max-w-3xl mx-auto">
                  <div className="bg-[#111E33] border border-white/5 p-10 rounded-3xl shadow-inner relative overflow-hidden group">
                    {/* Decorative Background Element */}
                    <div className="absolute top-0 right-0 p-8 text-white/5 -rotate-12 group-hover:rotate-0 transition-transform duration-1000">
                      <FileText className="w-32 h-32" />
                    </div>
                    
                    <div className="relative prose prose-invert prose-sm max-w-none 
                      prose-headings:font-serif prose-headings:text-[#C9A46A] prose-headings:border-b prose-headings:border-white/10 prose-headings:pb-3
                      prose-strong:text-white prose-p:text-[#B8C0D4] prose-li:text-[#B8C0D4] 
                      prose-code:text-[#C9A46A] prose-code:bg-black/20 prose-code:px-1.5 prose-code:rounded">
                      <ReactMarkdown>{activePhase.sheetContent}</ReactMarkdown>
                    </div>
                    
                    <div className="mt-10 pt-10 border-t border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-5 h-5 text-emerald-400" />
                        <span className="text-[10px] font-mono text-[#7C8AA8] uppercase">Official Studio SOP Copy</span>
                      </div>
                      <button 
                        onClick={() => handleDownloadSopPdf(activePhase.title, activePhase.sheetContent || '')}
                        className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-bold text-white transition-all cursor-pointer"
                      >
                        Download Procedure PDF
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Sub-Actions Cards */}
            {viewMode === 'video' && (
              <div className="px-8 pb-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                {activePhase.steps.slice(0,3).map((step, idx) => {
                  const stepKey = `${activePhase.id}_step_${idx}`;
                  const isDone = !!completedSteps[stepKey];
                  return (
                    <div key={idx} className="p-4 bg-[#111E33] rounded-2xl border border-white/5 flex flex-col justify-between hover:border-white/10 transition-colors">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h5 className="text-[10px] font-bold text-white uppercase tracking-wider">{step.title}</h5>
                          {step.refCode && <span className="text-[9px] font-mono bg-white/5 text-[#7C8AA8] px-1.5 py-0.5 rounded border border-white/5">{step.refCode}</span>}
                        </div>
                        <p className="text-[11px] text-[#7C8AA8] leading-relaxed line-clamp-2">{step.desc}</p>
                      </div>
                      <button 
                        onClick={() => toggleStepCompleted(stepKey)}
                        className={`mt-4 text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                          isDone ? 'text-emerald-400' : 'text-[#C9A46A] hover:text-amber-300'
                        }`}
                      >
                        {isDone ? '✓ Completed' : 'Mark Complete'} <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Interactive Navigation Tutorial Block */}
            {viewMode === 'video' && (
              <div className="px-8 pb-8">
                <div className="bg-[#0A1220]/50 rounded-2xl border border-white/5 overflow-hidden">
                  <div className="p-4 border-b border-white/5 flex items-center justify-between">
                    <div>
                      <h4 className="text-[10px] font-mono text-[#C9A46A] uppercase tracking-widest">Interactive Navigation Tutorial</h4>
                      <h3 className="text-sm font-bold text-white mt-1">Walkthrough Video — Agent Manager Dashboard</h3>
                    </div>
                    <div className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full">
                      Video Active
                    </div>
                  </div>
                  <div className="aspect-[21/9] bg-black relative flex flex-col items-center justify-center border-b border-white/5">
                      {isPlayingNav ? (
                        <div className="space-y-4 text-center z-10 p-6 bg-black/60 backdrop-blur-md rounded-2xl border border-white/10">
                          <Loader2 className="w-10 h-10 text-[#C9A46A] animate-spin mx-auto" />
                          <div>
                            <p className="text-xs font-bold text-white">Streaming Walkthrough...</p>
                            <div className="w-48 h-1.5 bg-white/10 rounded-full mt-3 mx-auto overflow-hidden">
                              <div className="h-full bg-[#C9A46A] transition-all duration-1000" style={{ width: `${Math.min(navWatchProgress, 100)}%` }} />
                            </div>
                          </div>
                          <button 
                            onClick={() => setIsPlayingNav(false)}
                            className="px-6 py-2 bg-white/10 hover:bg-white/20 text-white text-[10px] font-bold rounded-lg transition-all"
                          >
                            Pause
                          </button>
                        </div>
                      ) : (
                        <div className="text-center p-6 z-10 animate-scale-up">
                          <button 
                            onClick={() => setIsPlayingNav(true)}
                            className="w-16 h-16 rounded-full bg-white/5 border border-white/10 text-white flex items-center justify-center shadow-2xl hover:bg-[#C9A46A] hover:text-[#0A1220] hover:scale-110 active:scale-95 transition-all mb-4 mx-auto group"
                          >
                            <Play className="w-8 h-8 ml-1 group-hover:scale-110 transition-transform" />
                          </button>
                          <h3 className="text-sm font-bold text-white">Interactive video tutorial ready</h3>
                          <p className="text-[10px] text-[#7C8AA8] mt-2 max-w-sm mx-auto">
                            Click below to load the step-by-step navigation video explaining where to find features on the agentmgr portal.
                          </p>
                          
                          {navWatchProgress >= 100 && (
                             <div className="mt-3 inline-block px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[9px] font-bold uppercase tracking-wider flex items-center gap-1.5 justify-center mx-auto">
                               <CheckCircle2 className="w-3 h-3" /> Walkthrough Verified
                             </div>
                          )}

                          {isDirector && (
                            <div className="mt-6 p-3 bg-black/40 border border-white/10 rounded-xl max-w-xs mx-auto text-left">
                               <div className="flex justify-between items-center mb-2">
                                 <span className="text-[9px] font-mono text-[#C9A46A] uppercase tracking-widest">Director Controls</span>
                                 <button onClick={() => setShowNavUpload(!showNavUpload)} className="text-[9px] text-white underline hover:text-[#C9A46A]">
                                   {showNavUpload ? 'Cancel' : 'Replace Video'}
                                 </button>
                               </div>
                               {showNavUpload && (
                                 <div className="space-y-2">
                                   <input 
                                     type="text"
                                     value={newNavVideoUrl}
                                     onChange={(e) => setNewNavVideoUrl(e.target.value)}
                                     placeholder="Enter custom Nav Video URL"
                                     className="w-full bg-[#050e1a] border border-blue-900 rounded-lg p-2 text-[10px] text-white focus:outline-none focus:border-amber-500"
                                   />
                                   <button 
                                     onClick={() => {
                                       if(newNavVideoUrl) {
                                         setNavVideoUrl(newNavVideoUrl);
                                         setShowNavUpload(false);
                                         setNewNavVideoUrl('');
                                       }
                                     }}
                                     className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold rounded-lg transition-all"
                                   >
                                     Save New Nav Video
                                   </button>
                                 </div>
                               )}
                            </div>
                          )}
                        </div>
                      )}
                  </div>
                </div>
              </div>
            )}
            
            {/* Footer Navigation */}

            <div className="p-6 border-t border-white/5 bg-black/20 flex items-center justify-between">
              <button
                disabled={activePhaseIndex === 0}
                onClick={() => {
                  setActivePhaseIndex(prev => prev - 1);
                  setIsPlaying(false);
                  setPlayingVideo(null);
                }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-[#7C8AA8] hover:text-white disabled:opacity-30 transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                Previous Phase
              </button>
              
              <div className="flex items-center gap-1.5">
                {AGENT_MANAGER_PHASES.map((_, i) => (
                  <div 
                    key={i} 
                    className={`h-1.5 rounded-full transition-all duration-500 ${
                      i === activePhaseIndex ? 'w-6 bg-[#C9A46A]' : i < activePhaseIndex ? 'w-2 bg-emerald-500' : 'w-2 bg-white/10'
                    }`}
                  />
                ))}
              </div>

              
              {activePhaseIndex === AGENT_MANAGER_PHASES.length - 1 ? (
                <button
                  disabled={!isVideoComplete && !isDirector}
                  onClick={() => {
                    if(currentUser?.email) {
                        setCompletedBy(prev => {
                          const currentList = prev[activePhase.id] || [];
                          if(!currentList.includes(currentUser.email)) {
                            return { ...prev, [activePhase.id]: [...currentList, currentUser.email] };
                          }
                          return prev;
                        });
                    }
                    if(onBack) onBack();
                  }}
                  className={`px-6 py-2.5 rounded-xl text-xs font-bold shadow-lg transition-all flex items-center gap-2 ${
                    (!isVideoComplete && !isDirector)
                      ? 'bg-white/5 text-white/30 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-500/20'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {!isVideoComplete && !isDirector ? 'Watch Video to Complete' : 'Complete All Training'}
                </button>
              ) : (
                <button
                  disabled={!isVideoComplete && !isDirector}
                  onClick={() => {
                    if(currentUser?.email) {
                        setCompletedBy(prev => {
                          const currentList = prev[activePhase.id] || [];
                          if(!currentList.includes(currentUser.email)) {
                            return { ...prev, [activePhase.id]: [...currentList, currentUser.email] };
                          }
                          return prev;
                        });
                    }
                    setActivePhaseIndex(prev => prev + 1);
                    setIsPlaying(false);
                    setPlayingVideo(null);
                  }}
                  className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold shadow-lg transition-all ${
                    (!isVideoComplete && !isDirector)
                      ? 'bg-white/5 text-white/30 cursor-not-allowed'
                      : 'bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] shadow-amber-500/20'
                  }`}
                >
                  {!isVideoComplete && !isDirector ? 'Video Required' : 'Next Module'}
                  <ChevronRight className="w-4 h-4" />
                </button>
              )}

            </div>
          </div>
        </div>
      </div>


      {/* Additional Resource Center */}
      {isDirector && (
        <div className="bg-[#0D1830] border border-blue-900/50 rounded-2xl p-6 space-y-4 mt-6">
          <div className="flex items-center justify-between border-b border-white/5 pb-4">
             <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Director Watch: Completion Tracking</h3>
             </div>
             <span className="text-[10px] bg-blue-500/10 text-blue-400 px-3 py-1 rounded-full border border-blue-500/20 font-bold">DIRECTOR ONLY</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div className="p-4 bg-black/30 rounded-xl border border-white/5 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500/50"></div>
              <h4 className="text-[10px] font-mono text-emerald-400 uppercase">Interactive Navigation</h4>
              <div className="mt-3 space-y-2">
                {completedBy['interactive_nav'] && completedBy['interactive_nav'].length > 0 ? (
                  completedBy['interactive_nav'].map((email, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-white">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      {email}
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-[#5A6984] italic">No completions yet.</p>
                )}
              </div>
            </div>
            
            {AGENT_MANAGER_PHASES.map(phase => {
               const completedUsers = completedBy[phase.id] || [];
               return (
                 <div key={phase.id} className="p-4 bg-black/30 rounded-xl border border-white/5 relative overflow-hidden">
                   <div className="absolute top-0 left-0 w-1 h-full bg-[#C9A46A]/50"></div>
                   <h4 className="text-[10px] font-mono text-[#C9A46A] uppercase">{phase.title}</h4>
                   <div className="mt-3 space-y-2">
                     {completedUsers.length > 0 ? (
                       completedUsers.map((email, i) => (
                         <div key={i} className="flex items-center gap-2 text-xs text-white">
                           <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                           {email}
                         </div>
                       ))
                     ) : (
                       <p className="text-xs text-[#5A6984] italic">No completions yet.</p>
                     )}
                   </div>
                 </div>
               )
            })}
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">

        <div className="md:col-span-2 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/5 pb-4">
            <BookOpen className="w-5 h-5 text-[#C9A46A]" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Supplemental Management Resources</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-black/20 rounded-2xl border border-white/5 hover:border-[#C9A46A]/30 transition-all cursor-pointer group">
              <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A]">Agency Policy Handbook v4.0</h4>
              <p className="text-[10px] text-[#7C8AA8] mt-1">Detailed breakdown of non-disclosure and financial boundaries.</p>
            </div>
            <div className="p-4 bg-black/20 rounded-2xl border border-white/5 hover:border-[#C9A46A]/30 transition-all cursor-pointer group">
              <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A]">Crisis Communication Scripts</h4>
              <p className="text-[10px] text-[#7C8AA8] mt-1">SOPs for handling talent disputes and brand escalations.</p>
            </div>
            <div className="p-4 bg-black/20 rounded-2xl border border-white/5 hover:border-[#C9A46A]/30 transition-all cursor-pointer group">
              <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A]">FTC Disclosure Scoreboard Guide</h4>
              <p className="text-[10px] text-[#7C8AA8] mt-1">How to use AI text scoreboards for compliance auditing.</p>
            </div>
            <div className="p-4 bg-black/20 rounded-2xl border border-white/5 hover:border-[#C9A46A]/30 transition-all cursor-pointer group">
              <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A]">Creator Contract Tiers</h4>
              <p className="text-[10px] text-[#7C8AA8] mt-1">Understanding Exclusive vs Non-Exclusive payout splits.</p>
            </div>
          </div>
        </div>

        <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-6 space-y-4 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <AlertCircle className="w-20 h-20 text-amber-500" />
          </div>
          <h3 className="text-sm font-bold text-amber-400 uppercase tracking-widest flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            Compliance Alert
          </h3>
          <p className="text-xs text-[#B8C0D4] leading-relaxed">
            All Agent Managers are required to complete these modules within 72 hours of initial provisioning.
          </p>
          <div className="p-4 bg-black/40 rounded-xl border border-white/5 space-y-2">
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-[#7C8AA8]">System Logs:</span>
              <span className="text-emerald-400 font-mono">ACTIVE</span>
            </div>
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-[#7C8AA8]">Director Watchdog:</span>
              <span className="text-emerald-400 font-mono">MONITORING</span>
            </div>
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-[#7C8AA8]">Session Token:</span>
              <span className="text-[#C9A46A] font-mono truncate ml-4">9hqWU2_PROCEDURE</span>
            </div>
          </div>
          <p className="text-[10px] text-[#5A6984] italic">
            Failure to complete training will result in restricted permissions on financial oversight panels.
          </p>
        </div>
      </div>
    </div>
  );
}
