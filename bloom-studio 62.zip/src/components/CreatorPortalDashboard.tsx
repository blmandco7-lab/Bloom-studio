import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Video, 
  Package, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  Truck, 
  FileSignature, 
  ShieldCheck, 
  UploadCloud, 
  ExternalLink,
  ChevronRight,
  Download,
  Share2,
  Copy,
  Image as ImageIcon,
  UserCheck,
  Film,
  Plus,
  FileText
} from 'lucide-react';
import CreatorSignaturePad from './CreatorSignaturePad';
import TalentRightsBuyoutManager from './TalentRightsBuyoutManager';
import { TaxComplianceManager } from './TaxComplianceManager';
import { subscribeToShippingDeliverySync, syncShippingDeliveryNodes } from '../utils/shippingTrackingSync';

interface CreatorPortalDashboardProps {
  creatorHandle?: string;
  creatorName?: string;
  onUploadDraft?: (missionId: string) => void;
}

interface MissionPipeline {
  id: string;
  campaignName: string;
  brandName: string;
  niche: 'Cosmetics' | 'Pet' | 'Lifestyle';
  stage: 'Hook Review' | 'Draft Video Upload' | 'Caption Disclosures' | 'Brand Review' | 'Live Scheduled' | 'Script / Hook Draft' | 'Sample In Transit';
  deadline: string;
  flatFeePayout: number;
  sampleStatus: 'Shipped' | 'Delivered' | 'In Transit';
  trackingNumber: string;
  carrier: string;
  packageDescription: string;
  isDeliveredConfirmed: boolean;
  signatureRecorded: boolean;
}

export default function CreatorPortalDashboard({
  creatorHandle = "@olivia.glows",
  creatorName = "Olivia Sterling",
  onUploadDraft
}: CreatorPortalDashboardProps) {
  const [activeTab, setActiveTab] = useState<'missions' | 'locker' | 'escrow' | 'referrals' | 'media' | 'tax'>('missions');

  // Referral Copy State
  const [copiedReferral, setCopiedReferral] = useState(false);
  const referralCode = creatorHandle.replace('@', '').toLowerCase() + '_bloom';
  const referralLink = `https://bloomstudio.agency/join?ref=${referralCode}`;

  // Media Control Upload State
  const [profileAvatarUrl, setProfileAvatarUrl] = useState("https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80");
  const [uploadedShowcaseVideos, setUploadedShowcaseVideos] = useState<Array<{ id: string; title: string; url: string }>>([
    { id: 'v1', title: 'Skincare Barrier Serum Morning Routine (9:16)', url: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-a-face-cream-41557-large.mp4' }
  ]);
  const [newVideoTitle, setNewVideoTitle] = useState('');

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedReferral(true);
    setTimeout(() => setCopiedReferral(false), 2500);
  };

  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfileAvatarUrl(URL.createObjectURL(file));
    }
  };

  const handleVideoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setUploadedShowcaseVideos(prev => [
        { id: 'v_' + Date.now(), title: newVideoTitle || file.name, url },
        ...prev
      ]);
      setNewVideoTitle('');
    }
  };

  const [missions, setMissions] = useState<MissionPipeline[]>([
    {
      id: 'miss_01',
      campaignName: 'Barrier Balance Serum Launch',
      brandName: 'Lumina Cosmetics',
      niche: 'Cosmetics',
      stage: 'Draft Video Upload',
      deadline: 'In 3 Days',
      flatFeePayout: 2500,
      sampleStatus: 'Delivered',
      trackingNumber: '1Z9999999999999999',
      carrier: 'UPS Express',
      packageDescription: 'Lumina Barrier Serum Box Set & Testing Swatches',
      isDeliveredConfirmed: true,
      signatureRecorded: true
    },
    {
      id: 'miss_02',
      campaignName: 'Organic Furball Wellness Chews',
      brandName: 'PawBotanics LLC',
      niche: 'Pet',
      stage: 'Hook Review',
      deadline: 'Next Week',
      flatFeePayout: 1800,
      sampleStatus: 'In Transit',
      trackingNumber: '9400100000000000000000',
      carrier: 'USPS Priority',
      packageDescription: 'PawBotanics 30-Day Canine Digestive Supplements (2 Jars)',
      isDeliveredConfirmed: false,
      signatureRecorded: false
    }
  ]);

  // Real-time Automated Background Shipping Sync Listener
  useEffect(() => {
    const unsubscribe = subscribeToShippingDeliverySync((syncResult) => {
      if (syncResult.updatedStatus === 'Sample Received') {
        setMissions(prev => prev.map(m => 
          (m.trackingNumber === syncResult.trackingNumber || m.id === syncResult.campaignId)
            ? { ...m, isDeliveredConfirmed: true, sampleStatus: 'Delivered', stage: m.stage === 'Sample In Transit' ? 'Script / Hook Draft' : m.stage }
            : m
        ));
      }
    });

    return () => unsubscribe();
  }, []);

  const confirmDelivery = async (missionId: string) => {
    const targetMission = missions.find(m => m.id === missionId);
    if (targetMission) {
      await syncShippingDeliveryNodes({
        trackingNumber: targetMission.trackingNumber,
        carrier: (targetMission.carrier?.includes('USPS') ? 'USPS' : 'UPS') as any,
        status: 'Delivered',
        campaignId: targetMission.id,
        creatorHandle: creatorHandle
      });
    }

    setMissions(prev => prev.map(m => m.id === missionId ? { ...m, isDeliveredConfirmed: true, sampleStatus: 'Delivered' } : m));
  };

  const totalUpcomingPayout = missions.reduce((sum, m) => sum + m.flatFeePayout, 0);
  const totalLifetimeEarned = 18400; // Masked creator personal figure

  return (
    <div className="w-full space-y-6 font-sans text-agency-textLight animate-fadeIn">
      {/* Header Profile Banner */}
      <div className="bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
            <Sparkles className="w-4 h-4" />
            <span>Bloom Studio Talent Hub</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-white">
            Creator Workspace: {creatorName}
          </h2>
          <p className="text-xs text-slate-300 font-mono">
            {creatorHandle} • Verified Active Representation
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 bg-agency-navy p-1.5 rounded-2xl border border-white/10 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('missions')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer ${
              activeTab === 'missions'
                ? 'bg-agency-gold text-agency-navy shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>Active Missions ({missions.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('locker')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer ${
              activeTab === 'locker'
                ? 'bg-agency-gold text-agency-navy shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Sample Locker</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('escrow')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer ${
              activeTab === 'escrow'
                ? 'bg-agency-gold text-agency-navy shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Earnings Escrow</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('referrals')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer ${
              activeTab === 'referrals'
                ? 'bg-agency-gold text-agency-navy shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>Refer a Creator</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('media')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer ${
              activeTab === 'media'
                ? 'bg-agency-gold text-agency-navy shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>Profile &amp; Media Control</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tax')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer ${
              activeTab === 'tax'
                ? 'bg-agency-gold text-agency-navy shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Tax &amp; Legal</span>
          </button>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB 1: ACTIVE MISSION HUB */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'missions' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="grid grid-cols-1 gap-5">
            {missions.map(mission => (
              <div
                key={mission.id}
                className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl space-y-6"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-white/10 gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-agency-gold/15 text-agency-gold border border-agency-gold/30">
                        {mission.niche} Vertical
                      </span>
                      <span className="text-xs text-slate-400 font-mono">Due: {mission.deadline}</span>
                    </div>
                    <h3 className="text-xl font-serif font-bold text-white mt-1">
                      {mission.campaignName}
                    </h3>
                    <p className="text-xs text-slate-300">
                      Brand Partner: <strong className="text-white">{mission.brandName}</strong>
                    </p>
                  </div>

                  <div className="p-3 bg-agency-navy rounded-2xl border border-white/5 text-right">
                    <span className="text-[10px] font-mono text-slate-400 uppercase">Fixed Contract Payout</span>
                    <div className="text-xl font-mono font-bold text-emerald-400">
                      ${mission.flatFeePayout.toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Step-by-Step Deliverable Pipeline */}
                <div className="space-y-2">
                  <div className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                    Deliverable Progression Matrix
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                    {[
                      { step: '1. Hook Selection', active: true, done: true },
                      { step: '2. 4K Draft Upload', active: mission.stage === 'Draft Video Upload', done: false },
                      { step: '3. FTC Review', active: false, done: false },
                      { step: '4. Brand Window (48h)', active: false, done: false },
                      { step: '5. Live & Settle', active: false, done: false }
                    ].map((st, i) => (
                      <div
                        key={i}
                        className={`p-3 rounded-2xl border text-center font-mono text-[11px] space-y-1 transition ${
                          st.done
                            ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400 font-bold'
                            : st.active
                            ? 'bg-agency-gold/15 border-agency-gold text-agency-gold font-bold shadow-md'
                            : 'bg-agency-navy border-white/5 text-slate-500'
                        }`}
                      >
                        <div>{st.done ? '✓ Completed' : st.active ? '● Current Step' : '○ Pending'}</div>
                        <div className="text-[10px] text-white/80">{st.step}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-2 gap-3">
                  <div className="flex items-center gap-2 text-xs text-slate-300">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>FTC #ad tagging required in first 3 lines of caption.</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onUploadDraft ? onUploadDraft(mission.id) : alert('Draft Upload Modal')}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider rounded-xl transition shadow-lg cursor-pointer"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>Upload 4K Draft Deliverable</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 2: PHYSICAL SAMPLE LOCKER */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'locker' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {missions.map(mission => (
              <div
                key={mission.id}
                className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl space-y-5"
              >
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2 text-agency-gold font-mono text-xs font-bold uppercase">
                    <Truck className="w-4 h-4" />
                    <span>Sample Logistics</span>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
                    mission.isDeliveredConfirmed
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                  }`}>
                    {mission.sampleStatus}
                  </span>
                </div>

                <div className="space-y-2">
                  <h4 className="text-base font-serif font-bold text-white">
                    {mission.packageDescription}
                  </h4>
                  <p className="text-xs text-slate-400">
                    Campaign: <span className="text-white">{mission.campaignName}</span> ({mission.brandName})
                  </p>
                </div>

                <div className="p-4 bg-agency-navy rounded-2xl border border-white/5 space-y-2 font-mono text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Carrier:</span>
                    <span className="text-white font-bold">{mission.carrier}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Tracking Number:</span>
                    <span className="text-agency-gold font-bold truncate max-w-[180px]">{mission.trackingNumber}</span>
                  </div>
                </div>

                {mission.isDeliveredConfirmed ? (
                  <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-xl flex items-center justify-center gap-2 text-emerald-400 text-xs font-mono font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Package Delivery Confirmed by Creator</span>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => confirmDelivery(mission.id)}
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider rounded-xl transition shadow-lg cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm Package Arrival</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 3: EARNINGS ESCROW LEDGER */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'escrow' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Macro Stat Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="p-6 bg-agency-navyLight border border-agency-gold/30 rounded-3xl space-y-2 shadow-xl">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Pending Escrow Releases (Upcoming Flights)
              </span>
              <div className="text-3xl font-mono font-bold text-agency-gold">
                ${totalUpcomingPayout.toLocaleString()}
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Disbursed instantly upon brand window completion and publication.
              </p>
            </div>

            <div className="p-6 bg-agency-navyLight border border-white/10 rounded-3xl space-y-2 shadow-xl">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Cumulative Lifetime Payouts (YTD)
              </span>
              <div className="text-3xl font-mono font-bold text-emerald-400">
                ${totalLifetimeEarned.toLocaleString()}
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Direct wire &amp; agency card disbursements settled 100% on time.
              </p>
            </div>
          </div>

          {/* Masked Rights Buyout Offer Example */}
          <TalentRightsBuyoutManager
            userRole="creator"
            campaignName="Barrier Balance Serum Launch"
            creatorHandle={creatorHandle}
            creatorLegalName={creatorName}
            brandName="Lumina Cosmetics LLC"
            initialCreatorPayout={1200}
          />

          {/* Quick Deliverable Digital Signature Vault */}
          <CreatorSignaturePad
            campaignName="Barrier Balance Serum Launch"
            initialSignature={creatorName}
            onExecuteSignature={(sigName, _timeStr, hashStr) => {
              console.log(`[E-SIGN RECORD] '${sigName}' signed with audit hash ${hashStr}`);
            }}
          />
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 4: REFER A CREATOR NETWORK HUB */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'referrals' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-white/10 gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
                  <Share2 className="w-4 h-4" />
                  <span>Creator Network Referral Program</span>
                </div>
                <h3 className="text-xl md:text-2xl font-serif font-bold text-white">
                  Refer a Creator to Bloom Studio Roster
                </h3>
                <p className="text-xs text-slate-300 max-w-xl">
                  Earn a 5% commission bonus on every brand deal signed by creators who join through your unique referral link.
                </p>
              </div>

              <div className="p-4 bg-agency-navy rounded-2xl border border-agency-gold/30 text-right shrink-0">
                <div className="text-[10px] font-mono text-slate-400 uppercase">Referral Code</div>
                <div className="text-lg font-mono font-bold text-agency-gold">{referralCode}</div>
              </div>
            </div>

            {/* Link Box */}
            <div className="p-5 bg-agency-navy rounded-2xl border border-white/10 space-y-3">
              <label className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                Your Unique Creator Referral Link
              </label>
              <div className="flex flex-col sm:flex-row items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={referralLink}
                  className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs font-mono text-agency-gold font-bold focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleCopyReferral}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer shrink-0 shadow-lg"
                >
                  {copiedReferral ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-agency-navy" />
                      <span>Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Link</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Referral Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-agency-navy rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] font-mono uppercase text-slate-400">Creators Invited</span>
                <div className="text-2xl font-mono font-bold text-white">4 Talent</div>
              </div>
              <div className="p-4 bg-agency-navy rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] font-mono uppercase text-slate-400">Roster Approved</span>
                <div className="text-2xl font-mono font-bold text-emerald-400">2 Active</div>
              </div>
              <div className="p-4 bg-agency-navy rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] font-mono uppercase text-slate-400">Bonus Earned</span>
                <div className="text-2xl font-mono font-bold text-agency-gold">$450.00</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 5: PROFILE & MEDIA UPLOAD CONTROL HUB */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'media' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
            <div className="border-b border-white/10 pb-4 space-y-1">
              <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
                <ImageIcon className="w-4 h-4" />
                <span>Media Control Desk</span>
              </div>
              <h3 className="text-xl md:text-2xl font-serif font-bold text-white">
                Manage Profile Photos &amp; Showcase Videos
              </h3>
              <p className="text-xs text-slate-300">
                Upload and control the headshot pictures and 9:16 sample videos displayed on your Bloom Studio talent page.
              </p>
            </div>

            {/* Profile Picture Control */}
            <div className="p-6 bg-agency-navy rounded-2xl border border-white/10 space-y-4">
              <h4 className="text-sm font-bold text-white font-serif flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-agency-gold" />
                Profile Headshot Picture Control
              </h4>
              <div className="flex flex-col sm:flex-row items-center gap-5">
                <img
                  src={profileAvatarUrl}
                  alt={creatorName}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-agency-gold shadow-lg"
                />
                <div className="space-y-2 text-center sm:text-left">
                  <p className="text-xs text-slate-300">
                    Upload a high-resolution, professionally lit portrait photo.
                  </p>
                  <label className="inline-flex items-center gap-2 px-4 py-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer transition shadow">
                    <UploadCloud className="w-4 h-4" />
                    <span>Upload New Profile Picture</span>
                    <input type="file" accept="image/*" onChange={handleAvatarFileUpload} className="hidden" />
                  </label>
                </div>
              </div>
            </div>

            {/* Showcase Video Upload Control */}
            <div className="p-6 bg-agency-navy rounded-2xl border border-white/10 space-y-4">
              <h4 className="text-sm font-bold text-white font-serif flex items-center gap-2">
                <Film className="w-4 h-4 text-agency-gold" />
                Showcase Portfolio Videos
              </h4>

              <div className="space-y-3 bg-agency-navyLight p-4 rounded-xl border border-white/5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">
                      Video Title / Hook Description
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Unboxing & Glow Demo 9:16"
                      value={newVideoTitle}
                      onChange={e => setNewVideoTitle(e.target.value)}
                      className="w-full bg-agency-navy border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-agency-gold"
                    />
                  </div>
                  <div className="flex items-end">
                    <label className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer transition shadow">
                      <Plus className="w-4 h-4" />
                      <span>Upload Sample Video File</span>
                      <input type="file" accept="video/*" onChange={handleVideoFileUpload} className="hidden" />
                    </label>
                  </div>
                </div>
              </div>

              {/* Uploaded Video List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                {uploadedShowcaseVideos.map(v => (
                  <div key={v.id} className="p-4 bg-agency-navyLight border border-white/10 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-white">
                      <span className="truncate">{v.title}</span>
                      <span className="text-[10px] font-mono text-emerald-400">● Active</span>
                    </div>
                    {v.url.startsWith("blob:") ? (
                      <video src={v.url} controls className="w-full h-32 object-cover rounded-lg" />
                    ) : (
                      <div className="p-3 bg-black/40 rounded-lg text-[11px] text-slate-400 font-mono">
                        {v.url}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'tax' && (
        <div className="animate-fadeIn">
          <TaxComplianceManager
            creatorHandle={creatorHandle}
            creatorName={creatorName}
            creatorId={creatorHandle.replace('@', '')}
            triggerNotification={(title, message) => {}}
            onAddActivityLog={(user, role, action) => {}}
            matchingCreator={null}
          />
        </div>
      )}
    </div>
  );
}
