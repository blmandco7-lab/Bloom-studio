import React, { useEffect, useState } from 'react';
import { Save, Trash2, CheckCircle } from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';

interface AutoSaveIndicatorProps {
  draftKey: string;
  formData: any;
  onRestoreDraft?: (savedData: any) => void;
  onClearDraft?: () => void;
  className?: string;
}

export const AutoSaveIndicator: React.FC<AutoSaveIndicatorProps> = ({
  draftKey,
  formData,
  onRestoreDraft,
  onClearDraft,
  className = ''
}) => {
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const [hasRestored, setHasRestored] = useState(false);

  // Load existing draft on mount or draftKey change
  useEffect(() => {
    if (!draftKey) return;
    try {
      const saved = safeStorage.getItem(`bloom_draft_${draftKey}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
          if (onRestoreDraft) {
            onRestoreDraft(parsed.data || parsed);
            setHasRestored(true);
            setLastSaved(parsed.savedAt || 'Recently');
          }
        }
      }
    } catch (e) {
      console.warn('Draft restore error:', e);
    }
  }, [draftKey]);

  // Save draft whenever formData changes (debounced slightly or as typed)
  useEffect(() => {
    if (!draftKey || !formData) return;
    const isHasContent = Object.values(formData).some(v => v !== '' && v !== null && v !== undefined && (Array.isArray(v) ? v.length > 0 : true));
    
    if (!isHasContent) return;

    const timer = setTimeout(() => {
      try {
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        safeStorage.setItem(`bloom_draft_${draftKey}`, JSON.stringify({
          data: formData,
          savedAt: timeStr
        }));
        setLastSaved(timeStr);
      } catch (e) {
        console.warn('Draft save error:', e);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [formData, draftKey]);

  const handleClear = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      safeStorage.removeItem(`bloom_draft_${draftKey}`);
      setLastSaved(null);
      setHasRestored(false);
      if (onClearDraft) onClearDraft();
    } catch (err) {
      console.warn('Draft clear error:', err);
    }
  };

  if (!lastSaved) return null;

  return (
    <div className={`inline-flex items-center gap-2 text-[10px] font-mono px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/25 text-amber-300 ${className}`}>
      {hasRestored ? (
        <span className="flex items-center gap-1">
          <CheckCircle className="w-3 h-3 text-emerald-400" />
          <span>Draft restored ({lastSaved})</span>
        </span>
      ) : (
        <span className="flex items-center gap-1 animate-pulse">
          <Save className="w-3 h-3 text-amber-400" />
          <span>Draft auto-saved ({lastSaved})</span>
        </span>
      )}
      
      <button
        onClick={handleClear}
        type="button"
        title="Discard saved draft"
        className="hover:text-rose-400 text-amber-400/70 ml-1 cursor-pointer transition-colors"
      >
        <Trash2 className="w-3 h-3" />
      </button>
    </div>
  );
};
