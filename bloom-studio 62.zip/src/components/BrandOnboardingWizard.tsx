import React, { useState } from 'react';
import { 
  Building2, 
  Sparkles, 
  Target, 
  DollarSign, 
  Calendar, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  FileText, 
  Send, 
  ShieldCheck,
  Zap,
  Users,
  Lock,
  ExternalLink
} from 'lucide-react';
import PrivacyPolicyModal from './PrivacyPolicyModal';

interface BrandOnboardingWizardProps {
  onComplete?: (data: BrandOnboardingData) => void;
  onCancel?: () => void;
}

export interface BrandOnboardingData {
  companyName: string;
  contactName: string;
  contactEmail: string;
  industryVertical: 'Pet' | 'Cosmetics & Beauty' | 'Luxury Lifestyle' | 'Multi-Vertical';
  targetAudience: string;
  campaignObjectives: string[];
  allocatedBudget: string;
  targetFlightDate: string;
  requiredDeliverables: string[];
  ftcStrictComplianceAcknowledged: boolean;
  privacyPolicyAcknowledged: boolean;
  whitelistingRequired: boolean;
  notes: string;
}

export default function BrandOnboardingWizard({ onComplete, onCancel }: BrandOnboardingWizardProps) {
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);

  const [formData, setFormData] = useState<BrandOnboardingData>({
    companyName: '',
    contactName: '',
    contactEmail: '',
    industryVertical: 'Cosmetics & Beauty',
    targetAudience: '',
    campaignObjectives: ['Brand Awareness', 'Direct Conversions (ROAS)'],
    allocatedBudget: '$15,000 - $35,000',
    targetFlightDate: 'Next 30 Days',
    requiredDeliverables: ['TikTok Dedicated Integration', 'Instagram Reels (9:16 4K)'],
    ftcStrictComplianceAcknowledged: true,
    privacyPolicyAcknowledged: false,
    whitelistingRequired: false,
    notes: ''
  });

  const updateField = (field: keyof BrandOnboardingData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleObjective = (obj: string) => {
    setFormData(prev => {
      const exists = prev.campaignObjectives.includes(obj);
      return {
        ...prev,
        campaignObjectives: exists 
          ? prev.campaignObjectives.filter(o => o !== obj)
          : [...prev.campaignObjectives, obj]
      };
    });
  };

  const toggleDeliverable = (deliv: string) => {
    setFormData(prev => {
      const exists = prev.requiredDeliverables.includes(deliv);
      return {
        ...prev,
        requiredDeliverables: exists 
          ? prev.requiredDeliverables.filter(d => d !== deliv)
          : [...prev.requiredDeliverables, deliv]
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.privacyPolicyAcknowledged) {
      alert('Please review and acknowledge Bloom Studio’s Master Privacy Policy & Data Protection Statement before submitting your intake brief.');
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      if (onComplete) {
        onComplete(formData);
      }
    }, 900);
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-agency-navy text-agency-textLight border border-agency-gold/30 rounded-3xl p-6 md:p-10 shadow-2xl space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-white/10 pb-6 gap-4">
        <div>
          <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
            <Sparkles className="w-4 h-4" />
            <span>Brand Client Intake Protocol</span>
          </div>
          <h2 className="text-2xl font-serif font-bold text-white mt-1">
            Brand Partnership Onboarding Wizard
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Deploy your enterprise campaign parameters into Bloom Studio's isolated roster network.
          </p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4].map(step => (
            <div
              key={step}
              className={`w-8 h-8 rounded-full flex items-center justify-center font-mono text-xs font-bold transition-all ${
                currentStep === step
                  ? 'bg-agency-gold text-agency-navy shadow-lg shadow-amber-500/20 scale-110'
                  : currentStep > step
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : 'bg-white/5 text-slate-500 border border-white/10'
              }`}
            >
              {currentStep > step ? '✓' : step}
            </div>
          ))}
        </div>
      </div>

      {isSuccess ? (
        <div className="py-12 px-6 text-center space-y-6 bg-emerald-950/30 border border-emerald-500/40 rounded-2xl">
          <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/50">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-serif font-bold text-white">Campaign Intake Dossier Activated!</h3>
            <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
              Your onboarding parameters have been ingested into Bloom Studio's secure casting CRM. Our Director &amp; Senior Agents are now isolating matching creators across your selected vertical.
            </p>
          </div>
          <div className="p-4 bg-agency-navyLight rounded-xl max-w-md mx-auto text-left text-xs font-mono space-y-1 text-slate-300 border border-white/10">
            <p><span className="text-slate-400 font-semibold">Account:</span> <span className="text-white">{formData.companyName}</span></p>
            <p><span className="text-slate-400 font-semibold">Vertical:</span> <span className="text-agency-gold">{formData.industryVertical}</span></p>
            <p><span className="text-slate-400 font-semibold">Budget Tier:</span> <span className="text-emerald-400">{formData.allocatedBudget}</span></p>
            <p><span className="text-slate-400 font-semibold">Casting Window:</span> <span className="text-slate-200">{formData.targetFlightDate}</span></p>
          </div>
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-2.5 bg-agency-gold text-agency-navy font-bold text-xs uppercase tracking-wider rounded-xl hover:bg-[#b89359] transition cursor-pointer"
            >
              Close &amp; Return to Overview
            </button>
          )}
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Step 1: Corporate Profile */}
          {currentStep === 1 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-white/5 pb-2">
                <h3 className="text-sm font-mono font-bold text-agency-gold uppercase tracking-wider">
                  Step 1 of 4: Corporate &amp; Contact Identification
                </h3>
                <p className="text-xs text-slate-400">Specify your corporate entity and primary campaign communications lead.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                    Brand / Corporation Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.companyName}
                    onChange={e => updateField('companyName', e.target.value)}
                    placeholder="e.g. Lumina Cosmetics LLC"
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold transition"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                    Marketing Lead Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.contactName}
                    onChange={e => updateField('contactName', e.target.value)}
                    placeholder="e.g. Eleanor Vance"
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold transition"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                    Direct Corporate Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.contactEmail}
                    onChange={e => updateField('contactEmail', e.target.value)}
                    placeholder="e.g. partnerships@luminabeauty.com"
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold transition"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                    Industry Vertical Focus *
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {(['Cosmetics & Beauty', 'Pet', 'Luxury Lifestyle', 'Multi-Vertical'] as const).map(vertical => (
                      <button
                        type="button"
                        key={vertical}
                        onClick={() => updateField('industryVertical', vertical)}
                        className={`p-3 rounded-xl border text-xs font-semibold text-center transition cursor-pointer ${
                          formData.industryVertical === vertical
                            ? 'bg-agency-gold/15 border-agency-gold text-agency-gold font-bold shadow-md'
                            : 'bg-agency-navyLight border-white/10 text-slate-300 hover:border-white/20'
                        }`}
                      >
                        {vertical === 'Pet' && '🐾 '}
                        {vertical === 'Cosmetics & Beauty' && '💄 '}
                        {vertical === 'Luxury Lifestyle' && '🌿 '}
                        {vertical === 'Multi-Vertical' && '✨ '}
                        {vertical}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Scope & Objectives */}
          {currentStep === 2 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-white/5 pb-2">
                <h3 className="text-sm font-mono font-bold text-agency-gold uppercase tracking-wider">
                  Step 2 of 4: Campaign Scope &amp; Target Demographic
                </h3>
                <p className="text-xs text-slate-400">Outline consumer demographics and core KPIs for creator matching.</p>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-2 font-mono">
                  Primary Campaign Objectives (Select all that apply)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {[
                    'Brand Awareness & Category Share',
                    'Direct Conversions (ROAS / Affiliate)',
                    'High-Volume Organic UGC Library Creation',
                    'Product Launch & Viral TikTok Hook Scaling',
                    'Paid Ads Whitelisting & Spark Ad Rights'
                  ].map(obj => {
                    const isSelected = formData.campaignObjectives.includes(obj);
                    return (
                      <button
                        type="button"
                        key={obj}
                        onClick={() => toggleObjective(obj)}
                        className={`p-3 rounded-xl border text-xs text-left transition flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'bg-agency-gold/15 border-agency-gold text-white font-semibold'
                            : 'bg-agency-navyLight border-white/10 text-slate-400 hover:border-white/20'
                        }`}
                      >
                        <span>{obj}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-agency-gold shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                  Target Audience Persona &amp; Key Demographics
                </label>
                <textarea
                  rows={3}
                  value={formData.targetAudience}
                  onChange={e => updateField('targetAudience', e.target.value)}
                  placeholder="e.g. Women 22-38 interested in clean vegan skincare, organic pet supplements, luxury urban wellness..."
                  className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold transition resize-none"
                />
              </div>
            </div>
          )}

          {/* Step 3: Deliverables & Budget Tier */}
          {currentStep === 3 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-white/5 pb-2">
                <h3 className="text-sm font-mono font-bold text-agency-gold uppercase tracking-wider">
                  Step 3 of 4: Content Deliverables &amp; Budget Parameters
                </h3>
                <p className="text-xs text-slate-400">Configure content formats and target commercial allocation.</p>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-2 font-mono">
                  Requested Asset Formats
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {[
                    'TikTok Dedicated Integration (60s+)',
                    'Instagram Reels (9:16 4K Video)',
                    'High-Resolution Product Flatlay / Carousel',
                    'YouTube Dedicated Segment / Vlog Integration',
                    'Raw 4K UGC Video B-Roll for Paid Whitelisting'
                  ].map(deliv => {
                    const isSelected = formData.requiredDeliverables.includes(deliv);
                    return (
                      <button
                        type="button"
                        key={deliv}
                        onClick={() => toggleDeliverable(deliv)}
                        className={`p-3 rounded-xl border text-xs text-left transition flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'bg-agency-gold/15 border-agency-gold text-white font-semibold'
                            : 'bg-agency-navyLight border-white/10 text-slate-400 hover:border-white/20'
                        }`}
                      >
                        <span>{deliv}</span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-agency-gold shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                    Allocated Budget Tier
                  </label>
                  <select
                    value={formData.allocatedBudget}
                    onChange={e => updateField('allocatedBudget', e.target.value)}
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-agency-gold transition cursor-pointer font-mono"
                  >
                    <option value="$5,000 - $15,000">$5,000 - $15,000 (Emerging Flight)</option>
                    <option value="$15,000 - $35,000">$15,000 - $35,000 (Growth Scaling)</option>
                    <option value="$35,000 - $75,000">$35,000 - $75,000 (Tier-1 Multi-Roster)</option>
                    <option value="$75,000+">$75,000+ (Enterprise Omnichannel)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                    Target Campaign Flight Date
                  </label>
                  <select
                    value={formData.targetFlightDate}
                    onChange={e => updateField('targetFlightDate', e.target.value)}
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-agency-gold transition cursor-pointer font-mono"
                  >
                    <option value="Immediate (Next 14 Days)">Immediate (Next 14 Days)</option>
                    <option value="Next 30 Days">Next 30 Days</option>
                    <option value="Upcoming Quarter (Q3/Q4)">Upcoming Quarter</option>
                    <option value="Annual Ongoing Retainer">Annual Ongoing Retainer</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Legal & Review */}
          {currentStep === 4 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-white/5 pb-2">
                <h3 className="text-sm font-mono font-bold text-agency-gold uppercase tracking-wider">
                  Step 4 of 4: Compliance &amp; Protocol Verification
                </h3>
                <p className="text-xs text-slate-400">Review agency governance and confirm intake deployment.</p>
              </div>

              {/* Compliance Badges */}
              <div className="bg-agency-navyLight border border-agency-gold/30 rounded-2xl p-5 space-y-4">
                <div className="flex items-center gap-2 text-agency-gold font-bold text-xs uppercase tracking-wider font-mono">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Bloom Studio Governance Guarantees</span>
                </div>
                <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed font-sans">
                  <p>
                    <strong className="text-white">● 100% Verified FTC Compliance:</strong> All creator caption scripts pass pre-broadcast scanning for unambiguous disclosures (#ad, #sponsored) placed at text origin.
                  </p>
                  <p>
                    <strong className="text-white">● Secure Sandbox Escrow:</strong> Brand funds are safeguarded under programmatic milestone release protocols until deliverable approval.
                  </p>
                  <p>
                    <strong className="text-white">● Data Silo Guarantee:</strong> Your proprietary campaign analytics and briefs are never aggregated, pooled, or resold to third-party data brokers.
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-1.5 font-mono">
                  Additional Notes or Specific Talent Requests
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={e => updateField('notes', e.target.value)}
                  placeholder="e.g. We would love talent from the Organic Pet Care roster with dogs under 25lbs..."
                  className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold transition resize-none"
                />
              </div>

              {/* Privacy Policy & GDPR/CCPA Compliance Box */}
              <div className="p-4 bg-agency-navyLight rounded-xl border border-agency-gold/30 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-agency-gold">
                    <ShieldCheck className="w-4 h-4 text-agency-gold" />
                    <span>Privacy Policy &amp; Data Safeguard Acknowledgment</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowPrivacyModal(true)}
                    className="text-[11px] font-mono text-agency-gold hover:underline bg-agency-gold/10 hover:bg-agency-gold/20 px-2.5 py-1 rounded-lg border border-agency-gold/30 flex items-center gap-1 cursor-pointer transition"
                  >
                    <span>Read Master Privacy Policy</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
                <label className="flex items-start gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.privacyPolicyAcknowledged}
                    onChange={e => updateField('privacyPolicyAcknowledged', e.target.checked)}
                    className="mt-0.5 rounded text-agency-gold focus:ring-agency-gold cursor-pointer"
                  />
                  <span className="text-xs text-slate-300 leading-relaxed">
                    I have reviewed, acknowledge, and agree to Bloom Studio’s <strong className="text-white">Master Privacy Policy &amp; Data Protection Statement</strong>. I acknowledge our data silo guarantees, programmatic escrow boundaries, and CCPA / GDPR rights.
                  </span>
                </label>
              </div>

              <label className="flex items-start gap-3 p-3.5 bg-agency-navyLight rounded-xl border border-white/10 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.ftcStrictComplianceAcknowledged}
                  onChange={e => updateField('ftcStrictComplianceAcknowledged', e.target.checked)}
                  className="mt-0.5 rounded text-agency-gold focus:ring-agency-gold"
                />
                <span className="text-xs text-slate-300 leading-relaxed">
                  I agree to Bloom Studio’s standardized Campaign Intake Protocol and authorize the Director to match our brief with verified roster creators.
                </span>
              </label>
            </div>
          )}

          {/* Navigation Controls */}
          <div className="flex items-center justify-between border-t border-white/10 pt-6">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={() => setCurrentStep(prev => (prev - 1) as any)}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-white/20 text-xs font-bold uppercase tracking-wider text-slate-300 hover:bg-white/5 transition cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
            ) : (
              onCancel ? (
                <button
                  type="button"
                  onClick={onCancel}
                  className="px-5 py-2.5 text-xs text-slate-400 hover:text-white transition font-mono uppercase tracking-wider cursor-pointer"
                >
                  Cancel
                </button>
              ) : <div />
            )}

            {currentStep < 4 ? (
              <button
                type="button"
                onClick={() => {
                  if (currentStep === 1 && (!formData.companyName || !formData.contactEmail)) {
                    alert('Please provide your Company Name and Contact Email.');
                    return;
                  }
                  setCurrentStep(prev => (prev + 1) as any);
                }}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-agency-gold text-agency-navy font-bold text-xs uppercase tracking-wider hover:bg-[#b89359] transition shadow-lg cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-agency-gold text-agency-navy font-bold text-xs uppercase tracking-widest hover:bg-[#b89359] transition shadow-xl cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Processing Intake...</span>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Submit &amp; Deploy Brief</span>
                  </>
                )}
              </button>
            )}
          </div>
        </form>
      )}
      {/* Privacy Policy Modal */}
      <PrivacyPolicyModal
        isOpen={showPrivacyModal}
        onClose={() => {
          setShowPrivacyModal(false);
          updateField('privacyPolicyAcknowledged', true);
        }}
      />
    </div>
  );
}
