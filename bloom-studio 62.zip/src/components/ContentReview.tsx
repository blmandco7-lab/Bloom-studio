import React, { useState, useEffect } from 'react';
import { CheckCircle, AlertTriangle, MessageSquare, ArrowRight, User, Eye, Send, FileCheck, Plus, Check, RefreshCw, Shield, Sparkles, Archive, DollarSign, Link2, Share2, Receipt } from 'lucide-react';
import { Creator, Deal, ReviewItem } from '../types';
import { evaluateFtcCompliance } from '../lib/ftcBot';
import { db } from '../lib/firebase';
import { doc, setDoc, collection, query, where, onSnapshot } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';
import { DEFAULT_CONTENT_REVIEWS } from '../data/defaultAgencyData';

function cleanForFirestore(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(cleanForFirestore);
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) out[k] = cleanForFirestore(v);
  }
  return out;
}

interface ContentReviewProps {
  creators: Creator[];
  deals: Deal[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentRole?: string;
  currentUser?: any;
  primaryBrandColor?: string;
  cardBgColor?: string;
  reviewsList?: ReviewItem[];
  onSaveReview?: (review: ReviewItem) => Promise<void> | void;
  onNavigate?: (screen: string) => void;
}

export default function ContentReview({ 
  creators, 
  deals, 
  onAddActivityLog, 
  triggerNotification,
  currentRole = 'director',
  currentUser,
  primaryBrandColor = '#c7a77d',
  cardBgColor = '#0D1830',
  reviewsList,
  onSaveReview,
  onNavigate
}: ContentReviewProps) {
  
  // Shared Persistent State for Content Reviews
  const [localReviews, setLocalReviews] = useState<ReviewItem[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_content_reviews');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_CONTENT_REVIEWS;
  });

  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);

  const userRole = (currentRole || 'none').toLowerCase();
  const isPlatformOwner = !!currentUser?.isPlatformOwner;

  // Real-time Firestore subscription fallback for studio-content-reviews
  useEffect(() => {
    if (reviewsList && reviewsList.length > 0) return;
    const colRef = collection(db, 'studio-content-reviews');
    const q = isPlatformOwner
      ? colRef
      : userRole === 'creator'
        ? query(colRef, where('creator', '==', currentUser?.handle || '@creator'))
        : query(colRef, where('subagency', '==', currentUser?.subagency || 'pod_main'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: ReviewItem[] = [];
        snapshot.forEach(docSnap => {
          items.push({ ...docSnap.data(), id: docSnap.id } as ReviewItem);
        });
        if (items.length > 0) {
          setLocalReviews(items);
          try {
            safeStorage.setItem('wl_content_reviews', JSON.stringify(items));
          } catch {}
        }
      },
      (err) => {
        console.warn('[studio-content-reviews] onSnapshot error in ContentReview:', err);
      }
    );
    return () => unsubscribe();
  }, [userRole, currentUser, reviewsList, isPlatformOwner]);

  const rawReviews = (reviewsList && reviewsList.length > 0) ? reviewsList : localReviews;
  const reviews = React.useMemo(() => {
    return rawReviews.map(r => {
      if (r.ftcOverrideBy) return r;
      const ftcEval = evaluateFtcCompliance(r.captionDraft, r.dealId, r.brand);
      return {
        ...r,
        ftcFlagged: ftcEval.ftcFlagged,
        ftcFlagReason: ftcEval.ftcFlagReason
      };
    });
  }, [rawReviews]);
  const [ftcOverrideNoteInput, setFtcOverrideNoteInput] = useState<string>('');

  const updateReviewInList = async (updater: (prev: ReviewItem[]) => ReviewItem[], changedItem?: ReviewItem) => {
    let itemToPersist = changedItem;
    setLocalReviews(prev => {
      const next = updater(prev);
      try {
        safeStorage.setItem('wl_content_reviews', JSON.stringify(next));
      } catch {}
      if (!itemToPersist && next.length > 0) {
        itemToPersist = next[0];
      }
      return next;
    });

    if (itemToPersist) {
      if (onSaveReview) {
        try {
          await onSaveReview(itemToPersist);
        } catch (e) {
          console.warn('onSaveReview failed:', e);
        }
      }
      try {
        const subagency = (itemToPersist as any).subagency || currentUser?.subagency || 'pod_main';
        await setDoc(doc(db, 'studio-content-reviews', itemToPersist.id), cleanForFirestore({
          ...itemToPersist,
          subagency
        }), { merge: true });

        // Also sync corresponding status to studio-content-submissions
        const subId = 'sub-' + itemToPersist.id.replace('rev_', '');
        const matchingStatus = itemToPersist.status === 'Approved' ? 'Approved' : itemToPersist.status === 'Revision Requested' ? 'Needs Changes' : 'Pending Internal Review';
        await setDoc(doc(db, 'studio-content-submissions', subId), cleanForFirestore({
          id: subId,
          status: matchingStatus,
          caption: itemToPersist.captionDraft,
          campaignTitle: itemToPersist.brand,
          creatorHandle: itemToPersist.creator,
          subagency
        }), { merge: true }).catch(() => {});
      } catch (err) {
        console.warn('Error saving review to Firestore in ContentReview:', err);
      }
    }
  };

  useEffect(() => {
    try {
      safeStorage.setItem('wl_content_reviews', JSON.stringify(localReviews));
    } catch {}
  }, [localReviews]);

  const creatorHandle = currentUser?.handle || creators?.[0]?.handle || '';

  const isCoordinator = userRole === 'coordinator';
  const isAgentMgr = userRole === 'agentmgr';
  const isAgent = userRole === 'agent';
  const coordinatorName = currentUser?.name || '';
  const coordinatorCampaigns = (deals || []).filter(d => (d as any).assignedCoordinator?.toLowerCase() === coordinatorName.toLowerCase());
  const coordinatorCreatorHandles = Array.from(new Set(coordinatorCampaigns.map(c => (c.creator || '').toLowerCase()).filter(Boolean)));
  const userName = (currentUser?.name || '').toLowerCase();
  const myCreators = (creators || []).filter(c => {
    if (!isAgentMgr && !isAgent && !isCoordinator) return true;
    const ag = (c.assignedAgent || (c as any).agent || '').toLowerCase();
    const mgr = (c.assignedManager || '').toLowerCase();
    const coord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
    return (
      ag.includes(userName) || userName.includes(ag) ||
      mgr.includes(userName) || userName.includes(mgr) ||
      coord.includes(userName) || userName.includes(coord) ||
      (userName.includes('alex') && ag.includes('alex')) ||
      (userName.includes('marcus') && (ag.includes('marcus') || mgr.includes('marcus')))
    );
  });

  const myHandles = Array.from(new Set(myCreators.flatMap(c => [
    c.handle.toLowerCase(),
    c.handle.toLowerCase().replace(/^@/, ''),
    '@' + c.handle.toLowerCase().replace(/^@/, '')
  ])));

  // Filter reviews based on roles: creators ONLY see their own submissions, coordinator sees assigned creators, subagency sees pod creators, agentmgr/agent sees assigned creators, director sees all
  const normSub = (currentUser?.subagency || currentUser?.name || 'Bloom & Co').toLowerCase();
  const subagencyHandles = (creators || []).filter(c => 
    (c.subagency && c.subagency.toLowerCase().includes(normSub)) ||
    (c.agency && c.agency.toLowerCase().includes(normSub))
  ).map(c => c.handle.toLowerCase());

  const filteredReviews = userRole === 'creator'
    ? reviews.filter(r => r.creator.toLowerCase() === creatorHandle.toLowerCase())
    : isCoordinator
      ? (coordinatorCreatorHandles.length > 0 ? reviews.filter(r => coordinatorCreatorHandles.includes(r.creator.toLowerCase())) : reviews)
      : userRole === 'subagency'
        ? (subagencyHandles.length > 0 ? reviews.filter(r => subagencyHandles.includes(r.creator.toLowerCase())) : reviews)
        : (isAgentMgr || isAgent)
          ? (myHandles.length > 0 ? reviews.filter(r => myHandles.includes(r.creator.toLowerCase())) : reviews)
          : reviews;

  const [queueSortBy, setQueueSortBy] = useState<'newest' | 'oldest' | 'priority' | 'type'>('newest');
  const [decisionFilter, setDecisionFilter] = useState<'all' | 'approved' | 'denied' | 'ftc' | 'pending'>('all');

  const approvedCount = filteredReviews.filter(r => r.status === 'Approved' || r.status === 'Approved with Warning').length;
  const deniedCount = filteredReviews.filter(r => r.status === 'Rejected' || r.status === 'Revision Requested').length;
  const ftcHoldCount = filteredReviews.filter(r => r.ftcFlagged).length;
  const pendingCount = filteredReviews.filter(r => r.status === 'Pending' || r.status === 'Pending Agent Review' || r.status === 'Pending Agent Manager Review').length;

  const decisionFilteredReviews = filteredReviews.filter(r => {
    if (decisionFilter === 'approved') return r.status === 'Approved' || r.status === 'Approved with Warning';
    if (decisionFilter === 'denied') return r.status === 'Rejected' || r.status === 'Revision Requested';
    if (decisionFilter === 'ftc') return r.ftcFlagged;
    if (decisionFilter === 'pending') return r.status === 'Pending' || r.status === 'Pending Agent Review' || r.status === 'Pending Agent Manager Review';
    return true;
  });

  const sortedReviews = [...decisionFilteredReviews].sort((a, b) => {
    if (queueSortBy === 'oldest') {
      return a.id.localeCompare(b.id);
    } else if (queueSortBy === 'priority') {
      const score = (status: string) => status === 'Pending' ? 3 : status === 'Revision Requested' ? 2 : 1;
      return score(b.status) - score(a.status);
    } else if (queueSortBy === 'type') {
      return (a.contentType || '').localeCompare(b.contentType || '');
    } else {
      return b.id.localeCompare(a.id);
    }
  });

  const [selectedReviewId, setSelectedReviewId] = useState<string>(() => {
    return sortedReviews[0]?.id || '';
  });

  // Keep selected ID valid when filters or items change
  useEffect(() => {
    if (sortedReviews.length > 0) {
      const exists = sortedReviews.some(r => r.id === selectedReviewId);
      if (!exists) {
        setSelectedReviewId(sortedReviews[0].id);
      }
    } else {
      setSelectedReviewId('');
    }
  }, [reviews, userRole, queueSortBy, decisionFilter]);

  const [commentInput, setCommentInput] = useState<string>('');
  const [customComment, setCustomComment] = useState<string>('');

  // Form states for Creator submitting new content review
  const [creatorSelectedDealId, setCreatorSelectedDealId] = useState<string>('');
  const [creatorContentType, setCreatorContentType] = useState<string>('Video Draft');
  const [creatorMediaUrl, setCreatorMediaUrl] = useState<string>('');
  const [creatorCaptionDraft, setCreatorCaptionDraft] = useState<string>('');
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState<boolean>(false);

  // Filter deals for the creator's form selector
  const creatorDeals = deals.filter(d => d.creator.toLowerCase() === creatorHandle.toLowerCase());

  useEffect(() => {
    if (creatorDeals.length > 0 && !creatorSelectedDealId) {
      setCreatorSelectedDealId(creatorDeals[0].id);
    }
  }, [deals, creatorHandle]);

  const activeReview = reviews.find(r => r.id === selectedReviewId) || sortedReviews[0];

  const handleUpdateStatus = async (id: string, newStatus: ReviewItem['status'], actionLabel?: string) => {
    if (!activeReview) return;
    const isDenial = newStatus === 'Rejected' || newStatus === 'Revision Requested';
    if (isDenial && !customComment.trim()) {
      triggerNotification(
        'Feedback Required for Denial',
        `Please specify what changes or corrections are needed in the feedback box before denying or requesting revisions on this content draft.`,
        'warning'
      );
      return;
    }

    const feedbackText = customComment.trim() || (newStatus === 'Approved' ? 'Content approved by management for brand delivery & cataloged into Content Vault.' : `${actionLabel || newStatus}`);

    const actorName = currentUser?.name || (isAgent ? 'Assigned Agent' : isAgentMgr ? 'Marcus Cole (Agent Manager)' : 'Agency Director');
    const actorRoleTitle = isAgent ? 'Agent' : isAgentMgr ? 'Agent Manager' : 'Director';

    const updatedComments = [...activeReview.comments];
    if (isDenial) {
      updatedComments.push(`${actorName} (${actorRoleTitle}) [DENIAL FEEDBACK - CHANGES REQUIRED]: ${feedbackText}`);
    } else {
      updatedComments.push(`${actorName} (${actorRoleTitle}) [${actionLabel || newStatus}]: ${feedbackText}`);
    }
    updatedComments.push(`System: Status changed to [${newStatus}] by ${actorName}`);
    
    const isBrandReviewStart = newStatus === 'Approved';
    const updatedItem: ReviewItem = { 
      ...activeReview, 
      status: newStatus, 
      comments: updatedComments,
      denialFeedback: isDenial ? feedbackText : activeReview.denialFeedback,
      denialFeedbackBy: isDenial ? actorName : activeReview.denialFeedbackBy,
      denialFeedbackAt: isDenial ? new Date().toISOString() : activeReview.denialFeedbackAt,
      brandReviewStartedAt: isBrandReviewStart ? new Date().toISOString() : activeReview.brandReviewStartedAt,
      brandReviewStatus: isBrandReviewStart ? 'Active' : activeReview.brandReviewStatus
    };

    updateReviewInList(prev => prev.map(r => r.id === id ? updatedItem : r), updatedItem);
    setCustomComment('');

    // Requirement 2: On approval, content moves automatically straight to the Content Vault & Library
    if (newStatus === 'Approved') {
      try {
        const subagency = activeReview.subagency || currentUser?.subagency || 'pod_main';
        const tenantId = (activeReview as any).tenantId || currentUser?.tenantId || 'pod_main';
        const newAssetId = `asset_${activeReview.id}`;
        const newAsset = {
          id: newAssetId,
          title: `${activeReview.brand} — ${activeReview.contentType}`,
          creator: activeReview.creator,
          brand: activeReview.brand,
          dealId: activeReview.dealId || '',
          platform: activeReview.platform || 'Instagram',
          type: activeReview.contentType.toLowerCase().includes('video') || activeReview.contentType.toLowerCase().includes('reel') ? 'video' : activeReview.contentType.toLowerCase().includes('carousel') ? 'carousel' : 'image',
          views: 0,
          engagement: '0.0%',
          status: 'Approved',
          thumbnailUrl: activeReview.mediaUrl || 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=60',
          mediaUrl: activeReview.mediaUrl || '',
          caption: activeReview.captionDraft || '',
          fileSize: '24.5 MB',
          approvedBy: actorName,
          approvedAt: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          subagency,
          tenantId
        };
        
        // Persist to studio-content-library and studio-content-vault collections
        await setDoc(doc(db, "studio-content-library", newAssetId), cleanForFirestore(newAsset));
        await setDoc(doc(db, "studio-content-vault", newAssetId), cleanForFirestore(newAsset));
        
        // Storage sync
        const existingLibRaw = safeStorage.getItem('wl_content_library_assets');
        const currentLib = existingLibRaw ? JSON.parse(existingLibRaw) : [];
        const updatedLib = [newAsset, ...currentLib.filter((a: any) => a.id !== newAssetId)];
        safeStorage.setItem('wl_content_library_assets', JSON.stringify(updatedLib));
        safeStorage.setItem('wl_content_vault_assets', JSON.stringify(updatedLib));

        // Real-time dispatch for active ContentLibrary view
        window.dispatchEvent(new CustomEvent('wl_content_vault_updated', { detail: newAsset }));

        triggerNotification(
          'Moved Straight to Content Vault & Library',
          `"${newAsset.title}" approved by ${actorName} and automatically cataloged into Content Vault & Creator Library.`,
          'success'
        );
      } catch (e) {
        console.warn('Failed to auto-add to Content Library:', e);
      }
    }

    // Requirement 3: On rejection, log it automatically to the Repurposing Log with the reason and who rejected it.
    if (newStatus === 'Rejected') {
      try {
        const rejectedEntryId = `rej_${Date.now()}`;
        const rejectedEntry = {
          id: rejectedEntryId,
          creator: activeReview.creator,
          brand: activeReview.brand,
          platform: activeReview.platform || 'Instagram',
          contentType: activeReview.contentType,
          mediaUrl: activeReview.mediaUrl,
          rejectedBy: actorName,
          reason: customComment.trim(),
          rejectedAt: new Date().toISOString(),
          subagency: (activeReview as any).subagency || currentUser?.subagency || 'pod_main',
          tenantId: (activeReview as any).tenantId || currentUser?.tenantId || 'bloom_studio_default'
        };

        // Persist to studio-repurposing-logs collection
        await setDoc(doc(db, "studio-repurposing-logs", rejectedEntryId), cleanForFirestore(rejectedEntry));

        // Legacy fallback
        const existingRejRaw = safeStorage.getItem('wl_rejected_content_log');
        const currentRej = existingRejRaw ? JSON.parse(existingRejRaw) : [];
        const updatedRej = [rejectedEntry, ...currentRej];
        safeStorage.setItem('wl_rejected_content_log', JSON.stringify(updatedRej));
      } catch (e) {
        console.warn('Failed to auto-log rejection:', e);
      }
    }

    setCustomComment('');

    const statusType: Record<string, 'success' | 'warning' | 'danger' | 'info'> = {
      'Approved': 'success',
      'Rejected': 'danger',
      'Revision Requested': 'warning',
      'Pending Agent Review': 'info',
      'Pending Agent Manager Review': 'info',
      'Approved with Warning': 'warning'
    };

    const statusLabel: Record<string, string> = {
      'Approved': 'Approved content draft and moved to Content Library',
      'Rejected': 'Rejected content draft and logged to Repurposing Log',
      'Revision Requested': 'Sent back to creator for revision',
      'Pending Agent Review': 'Sent to agent for review',
      'Pending Agent Manager Review': 'Sent to agent manager for review',
      'Approved with Warning': 'Approved content draft with warnings'
    };

    triggerNotification(
      `Draft ${actionLabel || newStatus}`,
      `Review status for ${activeReview.creator}'s draft for ${activeReview.brand} is now "${actionLabel || newStatus}".`,
      statusType[newStatus] || 'info'
    );

    onAddActivityLog(
      currentUser?.name || 'Agency Director',
      'director',
      `${statusLabel[newStatus] || newStatus} for ${activeReview.creator} (${activeReview.brand})`
    );
  };

  const handleOverrideFtcHold = (id: string) => {
    if (!activeReview) return;
    const actorName = currentUser?.name || (isAgent ? 'Assigned Agent' : isAgentMgr ? 'Agency Lead' : 'Agency Director');
    const note = ftcOverrideNoteInput.trim() || 'No note provided';
    const updatedComments = [...activeReview.comments, `System: FTC Compliance Hold overridden by ${actorName} — Note: ${note}`];

    const updatedItem: ReviewItem = {
      ...activeReview,
      ftcFlagged: false,
      ftcFlagReason: undefined,
      ftcOverrideBy: actorName,
      ftcOverrideAt: new Date().toISOString(),
      ftcOverrideNote: note,
      comments: updatedComments
    };

    updateReviewInList(prev => prev.map(r => r.id === id ? updatedItem : r), updatedItem);
    setFtcOverrideNoteInput('');
    triggerNotification('FTC Hold Overridden', `Compliance hold cleared by ${actorName}. Note: "${note}"`, 'success');
    onAddActivityLog(actorName, userRole, `Overrode FTC hold on ${activeReview.creator}'s ${activeReview.brand} draft`);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !activeReview) return;

    const senderName = userRole === 'creator' 
      ? `${currentUser?.name || 'Creator'} (Creator)` 
      : isAgentMgr 
        ? `${currentUser?.name || 'Agency Lead'} (Agent)` 
        : `${currentUser?.name || 'Agency Director'} (Director)`;
    const authorRole = userRole === 'creator' ? 'creator' : isAgentMgr ? 'agentmgr' : 'director';

    const updatedItem: ReviewItem = {
      ...activeReview,
      comments: [...activeReview.comments, `${senderName}: ${commentInput.trim()}`]
    };

    updateReviewInList(prev => prev.map(r => r.id === activeReview.id ? updatedItem : r), updatedItem);

    onAddActivityLog(currentUser?.name || 'User', authorRole, `Added feedback comment on ${activeReview.creator}'s ${activeReview.brand} draft`);
    setCommentInput('');
  };

  const handleCreatorSubmitDraft = (e: React.FormEvent) => {
    e.preventDefault();
    const activeDeal = creatorDeals.find(d => d.id === creatorSelectedDealId);
    if (!activeDeal) {
      triggerNotification('No Active Deal', 'Please select a valid assigned deal to turn in content.', 'danger');
      return;
    }

    const defaultMockUrls = [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=600&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=60'
    ];
    const finalMediaUrl = creatorMediaUrl.trim() || defaultMockUrls[Math.floor(Math.random() * defaultMockUrls.length)];

    const ftcEval = evaluateFtcCompliance(creatorCaptionDraft.trim(), activeDeal.id, activeDeal.brand);

    const newReview: ReviewItem = {
      id: 'rev_' + Date.now(),
      creator: creatorHandle,
      dealId: activeDeal.id,
      brand: activeDeal.brand,
      platform: activeDeal.platform,
      contentType: creatorContentType,
      mediaUrl: finalMediaUrl,
      captionDraft: creatorCaptionDraft.trim() || 'No caption drafted yet.',
      submittedAt: 'Just now',
      status: 'Pending',
      ftcFlagged: ftcEval.ftcFlagged,
      ftcFlagReason: ftcEval.ftcFlagReason,
      comments: [`System: Content draft turned in by creator ${currentUser?.name || 'Creator'}`]
    };

    updateReviewInList(prev => [newReview, ...prev], newReview);
    setIsSubmitModalOpen(false);

    // Reset Form
    setCreatorMediaUrl('');
    setCreatorCaptionDraft('');

    triggerNotification(
      'Draft Turned In',
      `Your draft for ${activeDeal.brand} was submitted successfully. The Director has been notified.`,
      'success'
    );

    onAddActivityLog(
      currentUser?.name || 'Creator',
      'creator',
      `Turned in content draft review for campaign: ${activeDeal.brand} (${creatorContentType})`
    );
  };

  const handleCreatorResubmitDraft = (reviewId: string) => {
    const originalReview = reviews.find(r => r.id === reviewId);
    if (!originalReview) return;

    const newCaption = prompt("Resubmit caption draft details:", originalReview.captionDraft);
    if (newCaption === null) return;

    const updatedItem: ReviewItem = {
      ...originalReview,
      status: 'Pending',
      captionDraft: newCaption || originalReview.captionDraft,
      submittedAt: 'Resubmitted just now',
      comments: [...originalReview.comments, `System: Creator resubmitted and updated caption draft copies.`]
    };

    updateReviewInList(prev => prev.map(r => r.id === reviewId ? updatedItem : r), updatedItem);

    triggerNotification('Content Resubmitted', 'Draft successfully updated and returned to Pending status.', 'success');
    onAddActivityLog(currentUser?.name || 'Creator', 'creator', `Resubmitted content draft review for ${originalReview.brand}`);
  };

  const handleCoordinatorLogDeliveryCheckoff = (id: string) => {
    if (!activeReview) return;
    const actorName = currentUser?.name || 'Campaign Coordinator';
    const updatedComments = [
      ...activeReview.comments,
      `Coordinator Delivery Check-Off: Milestone logged as complete by ${actorName} at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    ];
    const updatedItem: ReviewItem = { ...activeReview, comments: updatedComments };
    updateReviewInList(prev => prev.map(r => r.id === id ? updatedItem : r), updatedItem);
    triggerNotification(
      'Milestone Checked Off',
      `Delivery check-off recorded for ${activeReview.creator} × ${activeReview.brand}.`,
      'success'
    );
    onAddActivityLog(actorName, 'coordinator', `Logged delivery check-off for ${activeReview.creator} (${activeReview.brand})`);
  };

  const handleGenerateInvoiceFromReview = async (review: ReviewItem) => {
    try {
      const invNumber = `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const invId = `inv_auto_${Date.now()}`;
      const associatedDeal = deals.find(d => d.id === review.dealId || d.brand === review.brand || d.creator === review.creator);
      const amount = associatedDeal?.value || 3500;
      
      const newInvoice = {
        id: invId,
        number: invNumber,
        invoiceNumber: invNumber,
        client: review.brand || 'Brand Partner',
        brand: review.brand || 'Brand Partner',
        brandName: review.brand || 'Brand Partner',
        creator: review.creator,
        deliverable: `${review.brand} — ${review.contentType || 'Sponsored Post'}`,
        amount: amount,
        subtotal: amount,
        tax: 0,
        amountDue: 0,
        status: 'Paid',
        issueDate: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
        tenantId: (review as any).tenantId || currentUser?.subagency || 'pod_main',
        subagency: (review as any).subagency || currentUser?.subagency || 'pod_main',
        notes: `Auto-generated via Content Review Pipeline upon final deliverable sign-off for ${review.brand}.`,
        items: [
          {
            description: `${review.contentType || 'Deliverable'} (${review.platform || 'Social Post'})`,
            quantity: 1,
            rate: amount,
            total: amount,
          }
        ]
      };

      await setDoc(doc(db, "studio-invoices", invId), cleanForFirestore(newInvoice));
      triggerNotification(
        "Invoice Auto-Drafted",
        `Generated invoice ${invNumber} ($${amount.toLocaleString()}) for ${review.brand} deliverable clearance.`,
        "success"
      );
      if (onAddActivityLog) {
        onAddActivityLog(
          currentUser?.name || "Staff",
          currentRole,
          `Generated billing invoice ${invNumber} for approved content: ${review.brand}`
        );
      }
    } catch (err) {
      console.warn("Error auto-generating invoice:", err);
      triggerNotification("Invoice Notice", "Saved invoice reference to agency billing queue.", "info");
    }
  };

  const handleCopyBrandReviewRoomLink = (review: ReviewItem) => {
    if (!review) {
      if (triggerNotification) triggerNotification("Selection Required", "Please select a content item first.", "warning");
      return;
    }
    
    try {
      const brandParam = encodeURIComponent(review.brand || 'Client');
      const subagencyParam = encodeURIComponent(currentUser?.subagency || 'pod_main');
      const token = `ROOM-${review.id.substring(0, 8).toUpperCase()}`;
      
      // Use origin + pathname to strip query/hash
      const baseUrl = window.location.origin + window.location.pathname;
      const url = `${baseUrl}?brand-room=true&brand=${brandParam}&token=${token}&deliverable=${review.id}&subagency=${subagencyParam}`;
      
    const copyToClipboard = (text: string) => {
      // Try the modern API first (requires secure context)
      if (navigator?.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(() => {
          if (triggerNotification) {
            triggerNotification(
              "Partner Review Room Link Copied",
              `Secure token [${token}] generated for ${review.brand}. URL copied to clipboard for external sharing.`,
              "success"
            );
          }
        }).catch(() => {
          // If secure context fails or permission denied, use prompt
          window.prompt("Copy this URL manually:", text);
        });
        return;
      }
      
      // Fallback for non-secure contexts (iframes)
      try {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "-9999px";
        textArea.style.zIndex = "9999";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        const successful = document.execCommand('copy');
        textArea.remove();
        
        if (successful) {
          if (triggerNotification) {
            triggerNotification(
              "Partner Review Room Link Copied",
              `Secure token [${token}] generated for ${review.brand}. URL copied to clipboard for external sharing.`,
              "success"
            );
          }
        } else {
          window.prompt("Copy this URL manually:", text);
        }
      } catch (err) {
        window.prompt("Copy this URL manually:", text);
      }
    };

    copyToClipboard(url);
    } catch (err) {
      console.error('handleCopyBrandReviewRoomLink error:', err);
    }
  };

  const handleCoordinatorNudgeCreator = (id: string) => {
    if (!activeReview) return;
    const actorName = currentUser?.name || 'Campaign Coordinator';
    const updatedComments = [
      ...activeReview.comments,
      `System (Coordinator Nudge): ${actorName} sent an urgent reminder to ${activeReview.creator} to upload the revised draft.`
    ];
    const updatedItem: ReviewItem = { ...activeReview, comments: updatedComments };
    updateReviewInList(prev => prev.map(r => r.id === id ? updatedItem : r), updatedItem);
    triggerNotification(
      'Revision Reminder Dispatched',
      `Sent revision turn-in notice to ${activeReview.creator} for ${activeReview.brand}.`,
      'info'
    );
    onAddActivityLog(actorName, 'coordinator', `Dispatched revision turn-in notice to ${activeReview.creator}`);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden" style={{ borderColor: `${primaryBrandColor}20` }}>
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider" style={{ color: primaryBrandColor }}>
              {userRole === 'creator' ? 'Talent Content Gateway' : isCoordinator ? 'Deliverable Oversight' : 'Creative Operations'}
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              {userRole === 'creator' ? 'My Content Submissions' : isCoordinator ? 'Creator Deliverable Progress' : (userRole === 'agent' ? 'Submitted Content' : 'Content Review Dashboard')}
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
              {userRole === 'creator' 
                ? 'Turn in your video drafts, image packages, and caption copies securely to your coordinator for compliance pre-audits.'
                : (userRole === 'agent' 
                    ? 'Review creator drafts, videos, captions, and ensure FTC guidelines are followed before brand launch approval.' 
                    : (isCoordinator ? 'Track how far along your assigned creators are with their campaign deliverables, draft turn-ins, FTC disclosures, and completion status.' : 'Review creator drafts, videos, captions, and ensure FTC guidelines are followed before brand launch approval.'))}
            </p>
          </div>

          {userRole === 'creator' && (
            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4.5 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              style={{ backgroundColor: primaryBrandColor }}
            >
              <Plus className="w-4 h-4" /> Turn In My Content
            </button>
          )}
        </div>
      </div>

      {/* Creator Submit Content Modal */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative" style={{ backgroundColor: cardBgColor }}>
            <div className="flex justify-between items-center border-b border-white/5 pb-3">
              <h3 className="font-serif font-semibold text-lg text-white">Turn In Creative Content</h3>
              <button 
                onClick={() => setIsSubmitModalOpen(false)}
                className="text-[#7C8AA8] hover:text-white text-lg font-mono outline-none"
              >
                &times;
              </button>
            </div>

            {creatorDeals.length === 0 ? (
              <div className="py-6 text-center text-slate-400 space-y-3">
                <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
                <p className="text-xs">You currently do not have any active campaign deals assigned to turn in content for.</p>
              </div>
            ) : (
              <form onSubmit={handleCreatorSubmitDraft} className="space-y-4 text-xs">
                <div className="space-y-1.5">
                  <label className="text-[#7C8AA8] uppercase text-[10px] tracking-wider block">Assigned Brand Deal</label>
                  <select 
                    value={creatorSelectedDealId}
                    onChange={e => setCreatorSelectedDealId(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50"
                  >
                    {creatorDeals.map(d => (
                      <option key={d.id} value={d.id}>{d.brand} — Budget: ${d.budget.toLocaleString()} ({d.platform})</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[#7C8AA8] uppercase text-[10px] tracking-wider block">Content Type</label>
                    <select 
                      value={creatorContentType}
                      onChange={e => setCreatorContentType(e.target.value)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50"
                    >
                      <option value="Video Draft">Video Draft</option>
                      <option value="Reel/Video">Reel/Video</option>
                      <option value="Story Draft">Story Draft</option>
                      <option value="Carousel Images">Carousel Images</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[#7C8AA8] uppercase text-[10px] tracking-wider block">Mock Media URL (Optional)</label>
                    <input 
                      type="text"
                      placeholder="Leave empty for simulated default image"
                      value={creatorMediaUrl}
                      onChange={e => setCreatorMediaUrl(e.target.value)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50"
                    />
                  </div>
                </div>

                {/* File Upload Simulation Box */}
                <div className="border border-dashed border-white/10 rounded-xl p-4 text-center bg-[#111E33]/30 hover:bg-[#111E33]/50 transition-colors cursor-pointer space-y-1.5">
                  <FileCheck className="w-5 h-5 mx-auto text-[#C9A46A]" style={{ color: primaryBrandColor }} />
                  <span className="text-[11px] font-semibold text-white block">Drag and drop raw video or photo package here</span>
                  <span className="text-[9px] text-[#7C8AA8] block">Supports MP4, MOV, JPG (Max 500MB)</span>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[#7C8AA8] uppercase text-[10px] tracking-wider block">Caption Copy Draft</label>
                  <textarea 
                    rows={3}
                    placeholder="Provide your exact caption. Remember to include #ad or #sponsored as per compliance standards."
                    value={creatorCaptionDraft}
                    onChange={e => setCreatorCaptionDraft(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50 font-mono"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button 
                    type="button"
                    onClick={() => setIsSubmitModalOpen(false)}
                    className="px-4 py-2 border border-white/10 hover:border-white/20 rounded-xl font-semibold text-slate-300 transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-5 py-2 rounded-xl font-semibold text-[#0A1220]"
                    style={{ backgroundColor: primaryBrandColor }}
                  >
                    Submit Draft
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Review Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Draft Submissions List */}
        <div className="lg:col-span-5 bg-[#0D1830] border border-white/5 rounded-2xl p-4 flex flex-col min-h-[600px] lg:min-h-[calc(100vh-200px)] lg:h-[calc(100vh-200px)]" style={{ backgroundColor: cardBgColor }}>
          <div className="flex items-center justify-between mb-2.5 border-b border-white/5 pb-2">
            <h3 className="text-xs font-semibold text-[#7C8AA8] uppercase tracking-wider">
              {userRole === 'creator' ? 'My Turn-Ins & Feedback' : isCoordinator ? `Assigned Deliverables (${filteredReviews.length})` : `Submissions (${filteredReviews.length})`}
            </h3>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-[#7C8AA8] font-mono">Sort:</span>
              <select
                value={queueSortBy}
                onChange={(e) => setQueueSortBy(e.target.value as any)}
                className="bg-[#111E33] border border-white/10 rounded-lg px-2 py-0.5 text-[10px] font-mono text-amber-300 focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="priority">Priority Status</option>
                <option value="type">Content Type</option>
              </select>
            </div>
          </div>

          {/* Decision Status Filter Bar for Approvals, Denials, FTC Holds & In-Review */}
          <div className="flex items-center gap-1 mb-3 overflow-x-auto pb-1 font-mono text-[10px]">
            <button
              onClick={() => setDecisionFilter('all')}
              className={`px-2 py-1 rounded-lg transition-colors shrink-0 cursor-pointer font-semibold ${
                decisionFilter === 'all' ? 'bg-[#C9A46A] text-[#0A1220]' : 'bg-[#111E33] text-slate-400 hover:text-white'
              }`}
            >
              All ({filteredReviews.length})
            </button>
            <button
              onClick={() => setDecisionFilter('approved')}
              className={`px-2 py-1 rounded-lg transition-colors shrink-0 cursor-pointer flex items-center gap-1 font-semibold ${
                decisionFilter === 'approved' ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/60 border border-emerald-500/20'
              }`}
            >
              <span>✓ Approved</span>
              <span className="bg-emerald-900/80 text-emerald-200 px-1 rounded-full text-[9px]">{approvedCount}</span>
            </button>
            <button
              onClick={() => setDecisionFilter('denied')}
              className={`px-2 py-1 rounded-lg transition-colors shrink-0 cursor-pointer flex items-center gap-1 font-semibold ${
                decisionFilter === 'denied' ? 'bg-rose-500 text-slate-950 font-bold' : 'bg-rose-950/40 text-rose-300 hover:bg-rose-900/60 border border-rose-500/20'
              }`}
            >
              <span>✕ Denied/Revisions</span>
              <span className="bg-rose-900/80 text-rose-200 px-1 rounded-full text-[9px]">{deniedCount}</span>
            </button>
            <button
              onClick={() => setDecisionFilter('ftc')}
              className={`px-2 py-1 rounded-lg transition-colors shrink-0 cursor-pointer flex items-center gap-1 font-semibold ${
                decisionFilter === 'ftc' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-amber-950/40 text-amber-300 hover:bg-amber-900/60 border border-amber-500/20'
              }`}
            >
              <span>⚠️ FTC Holds</span>
              <span className="bg-amber-900/80 text-amber-200 px-1 rounded-full text-[9px]">{ftcHoldCount}</span>
            </button>
            <button
              onClick={() => setDecisionFilter('pending')}
              className={`px-2 py-1 rounded-lg transition-colors shrink-0 cursor-pointer flex items-center gap-1 font-semibold ${
                decisionFilter === 'pending' ? 'bg-sky-500 text-slate-950 font-bold' : 'bg-sky-950/40 text-sky-300 hover:bg-sky-900/60 border border-sky-500/20'
              }`}
            >
              <span>⏳ In Review</span>
              <span className="bg-sky-900/80 text-sky-200 px-1 rounded-full text-[9px]">{pendingCount}</span>
            </button>
          </div>
          
          {sortedReviews.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-3">
              <CheckCircle className="w-10 h-10 text-emerald-500/40" />
              <p className="text-xs font-semibold text-white">No submissions found</p>
              <p className="text-[10px] text-slate-400">Click "Turn In My Content" to submit your first deliverable draft.</p>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {sortedReviews.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setSelectedReviewId(item.id);
                    setCommentInput('');
                  }}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex gap-3.5 items-start ${
                    selectedReviewId === item.id
                      ? 'bg-[#16243F] border-[#C9A46A] shadow-md'
                      : 'bg-[#111E33]/60 border-white/5 hover:bg-[#16243F]/30'
                  }`}
                  style={selectedReviewId === item.id ? { borderColor: primaryBrandColor } : {}}
                >
                  <div className="w-10 h-10 rounded-lg bg-cover bg-center shrink-0 border border-white/10" style={{ backgroundImage: `url(${item.mediaUrl})` }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-xs text-white truncate">
                        {userRole === 'creator' ? item.brand : item.creator}
                      </span>
                      <span className="text-[9px] text-[#7C8AA8]">{item.submittedAt}</span>
                    </div>
                    <p className="text-[11px] text-white/90 font-medium mt-1 truncate">
                      {userRole === 'creator' ? item.contentType : `${item.brand} — ${item.contentType}`}
                    </p>
                    
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-[10px] text-[#7C8AA8]">{item.platform}</span>
                      <div className="flex items-center gap-1.5">
                        {item.ftcFlagged && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center gap-0.5" title={item.ftcFlagReason}>
                            ⚠️ FTC Hold
                          </span>
                        )}
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          item.status === 'Pending' ? 'bg-amber-950 text-amber-400 border border-amber-500/20' :
                          item.status === 'Approved' ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' :
                          item.status === 'Approved with Warning' ? 'bg-sky-950 text-sky-400 border border-sky-500/20' :
                          'bg-rose-950 text-rose-400 border border-rose-500/20'
                        }`}>
                          {item.status}
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Side: Active Draft Inspection Panel */}
        {activeReview ? (
          <div className="lg:col-span-7 bg-[#0D1830] border border-white/5 rounded-2xl p-5 flex flex-col min-h-[600px] lg:min-h-[calc(100vh-200px)] lg:h-[calc(100vh-200px)] overflow-hidden" style={{ backgroundColor: cardBgColor }}>
            <div className="flex justify-between items-center border-b border-white/5 pb-3">
              <div>
                <h3 className="font-serif font-medium text-lg text-white">
                  {userRole === 'creator' ? `My Deliverable for ${activeReview.brand}` : `Inspection: ${activeReview.creator} × ${activeReview.brand}`}
                </h3>
                <p className="text-[10px] text-[#7C8AA8]">Submitted: {activeReview.submittedAt} &middot; Type: {activeReview.contentType}</p>
              </div>
              <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                activeReview.status === 'Pending' ? 'bg-amber-950 text-amber-400 border border-amber-500/20' :
                activeReview.status === 'Approved' ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' :
                activeReview.status === 'Approved with Warning' ? 'bg-sky-950 text-sky-400 border border-sky-500/20' :
                'bg-rose-950 text-rose-400 border border-rose-500/20'
              }`}>
                {activeReview.status}
              </span>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
              {/* Media Preview & Info Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-[#7C8AA8] uppercase">Media Attachment Preview</span>
                  <div className="relative aspect-video rounded-xl bg-[#111E33] border border-white/5 overflow-hidden flex items-center justify-center">
                    <img src={activeReview.mediaUrl} alt="Draft preview" className="w-full h-full object-cover" />
                    <button 
                      onClick={() => setFullscreenImage(activeReview.mediaUrl)}
                      className="absolute bottom-2 right-2 bg-slate-900/80 hover:bg-slate-900 text-white p-1.5 rounded-lg text-xs flex items-center gap-1 border border-white/10 transition-colors cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" /> Fullscreen
                    </button>
                  </div>
                </div>

                <div className="space-y-3 flex flex-col justify-between">
                  <div className="bg-[#111E33]/50 p-3.5 rounded-xl border border-white/5 text-xs space-y-2.5">
                    <span className="font-semibold text-white block flex items-center justify-between">
                      <span>FTC Compliance Bot Engine</span>
                      <span className="text-[10px] text-[#C9A46A] font-mono uppercase">OCR / Text Scan</span>
                    </span>

                    {/* FTC HOLD BADGE */}
                    {activeReview.ftcFlagged ? (
                      <div className="bg-amber-500/15 border border-amber-500/40 p-3 rounded-xl text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-amber-300 flex items-center gap-1.5 text-[11px]">
                            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                            FTC COMPLIANCE HOLD: {activeReview.ftcFlagReason || 'Missing disclosure'}
                          </span>
                          <span className="bg-amber-500 text-black font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase">
                            Warning Badge
                          </span>
                        </div>
                        <p className="text-slate-300 text-[11px] leading-relaxed">
                          Caption is linked to a paid partnership ({activeReview.brand}) but lacks required FTC disclosure markers (#ad, #sponsored, #paidpartnership, etc.).
                        </p>
                      </div>
                    ) : activeReview.ftcOverrideBy ? (
                      <div className="bg-emerald-500/15 border border-emerald-500/30 p-2.5 rounded-xl text-[11px] text-emerald-300 space-y-1">
                        <div className="flex items-center gap-1.5 font-bold">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          FTC Hold Overridden by {activeReview.ftcOverrideBy}
                        </div>
                        <p className="text-slate-300 text-[10px]">
                          Note ({activeReview.ftcOverrideAt ? new Date(activeReview.ftcOverrideAt).toLocaleDateString() : 'Today'}): "{activeReview.ftcOverrideNote}"
                        </p>
                      </div>
                    ) : (
                      <div className="bg-emerald-500/10 border border-emerald-500/20 p-2.5 rounded-xl text-[11px] text-emerald-300 flex items-center gap-1.5 font-semibold">
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        FTC Compliance Passed (#ad / #sponsored detected or organic post)
                      </div>
                    )}

                    {/* STAFF OVERRIDE CONTROL */}
                    {activeReview.ftcFlagged && (
                      <div className="bg-[#0A1220]/70 border border-white/10 p-2.5 rounded-xl space-y-2">
                        <span className="text-[10px] font-bold uppercase text-[#7C8AA8] block">
                          Staff Compliance Override
                        </span>
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            placeholder="Reason for override (e.g. disclosure graphic in video)..."
                            value={ftcOverrideNoteInput}
                            onChange={e => setFtcOverrideNoteInput(e.target.value)}
                            className="flex-1 bg-[#111E33] border border-white/10 rounded-lg px-2.5 py-1 text-[11px] text-white outline-none focus:border-[#C9A46A]"
                          />
                          <button
                            type="button"
                            onClick={() => handleOverrideFtcHold(activeReview.id)}
                            disabled={!ftcOverrideNoteInput.trim()}
                            className="px-3 py-1 rounded-lg bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-[11px] disabled:opacity-40 transition-colors shrink-0"
                          >
                            Override
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="bg-amber-950/10 border border-amber-500/20 p-3 rounded-xl text-[11px] text-[#C9A46A]">
                    <p className="font-semibold flex items-center gap-1">
                      <FileCheck className="w-3.5 h-3.5 text-[#C9A46A]" style={{ color: primaryBrandColor }} /> 
                      {userRole === 'creator' ? 'Awaiting Director Sign-off' : isCoordinator ? 'Coordinator Milestone Tracking' : 'Director Command Gate'}
                    </p>
                    <p className="text-[#7C8AA8] mt-1">
                      {userRole === 'creator' 
                        ? 'Once approved by the agency director, your files will be auto-released to the active brand portal schedules.'
                        : isCoordinator
                        ? 'Monitor deliverable completion pacing. When the creator submits their draft, it is queued for executive director clearance.'
                        : 'Once approved, this content will be cleared to auto-publish on the creator\'s social schedules.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Coordinator Deliverable Progress Stepper */}
              {isCoordinator && (
                <div className="bg-[#111E33] border border-white/5 p-4 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white uppercase font-mono">Creator Deliverable Progress</span>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                      activeReview.status === 'Approved' ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/20' :
                      activeReview.status === 'Revision Requested' ? 'bg-amber-950/40 text-amber-300 border-amber-500/20' :
                      'bg-sky-950/40 text-sky-300 border-sky-500/20'
                    }`}>
                      {activeReview.status === 'Approved' ? 'Completed & Verified ✓' : activeReview.status === 'Revision Requested' ? 'Revision in Progress' : 'In Review / In Flight'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[10px]">
                    <div className="p-2 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold">
                      1. Draft Submitted ✓
                    </div>
                    <div className={`p-2 rounded-lg border font-bold ${
                      !activeReview.ftcFlagged ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' : 'bg-amber-500/20 border-amber-500/30 text-amber-300'
                    }`}>
                      2. FTC Verified {!activeReview.ftcFlagged ? '✓' : '⚠️'}
                    </div>
                    <div className={`p-2 rounded-lg border font-bold ${
                      activeReview.status === 'Approved' ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' : 'bg-sky-500/20 border-sky-500/30 text-sky-300'
                    }`}>
                      3. Director Approval {activeReview.status === 'Approved' ? '✓' : '⏳'}
                    </div>
                    <div className={`p-2 rounded-lg border font-bold ${
                      activeReview.status === 'Approved' ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' : 'bg-white/5 border-white/10 text-slate-500'
                    }`}>
                      4. Completed {activeReview.status === 'Approved' ? '✓' : '—'}
                    </div>
                  </div>
                </div>
              )}

              {/* Denial Feedback Banner */}
              {(activeReview.denialFeedback || activeReview.status === 'Revision Requested' || activeReview.status === 'Rejected') && (
                <div className="bg-rose-950/40 border border-rose-500/40 p-4 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-400 uppercase tracking-wider font-mono flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                      Feedback &amp; Required Changes (Denied / Revision Required)
                    </span>
                    {activeReview.denialFeedbackBy && (
                      <span className="text-[10px] text-rose-300 font-mono">
                        By: {activeReview.denialFeedbackBy}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-rose-100 bg-[#0A1220] p-3 rounded-lg border border-rose-500/20 font-mono leading-relaxed whitespace-pre-wrap">
                    {activeReview.denialFeedback || activeReview.comments.filter(c => c.includes('DENIAL FEEDBACK') || c.includes('Director') || c.includes('Agent Manager')).pop() || 'Revisions required by director. Check comments below for details.'}
                  </div>
                </div>
              )}

              {/* Caption Draft */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-bold text-[#7C8AA8] uppercase">Caption / Copy Draft</span>
                  {userRole === 'creator' && activeReview.status !== 'Approved' && (
                    <button 
                      onClick={() => handleCreatorResubmitDraft(activeReview.id)}
                      className="text-[10px] text-[#C9A46A] hover:underline flex items-center gap-1 font-semibold"
                      style={{ color: primaryBrandColor }}
                    >
                      <RefreshCw className="w-3 h-3" /> Edit Draft Copy
                    </button>
                  )}
                </div>
                <div className="bg-[#111E33] border border-white/5 p-3.5 rounded-xl text-xs font-mono text-slate-200 leading-relaxed break-words whitespace-pre-wrap">
                  {activeReview.captionDraft}
                </div>
              </div>

              {/* Feedback History log */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-[#7C8AA8] uppercase flex items-center gap-1">
                  <MessageSquare className="w-3 h-3 text-[#C9A46A]" style={{ color: primaryBrandColor }} /> Comments &amp; Feedback Trail
                </span>
                
                <div className="bg-[#111E33]/40 border border-white/5 rounded-xl p-3.5 space-y-2 max-h-[160px] overflow-y-auto">
                  {activeReview.comments.length === 0 ? (
                    <span className="text-xs text-[#7C8AA8] italic block">No feedback posted yet. Communication thread is active.</span>
                  ) : (
                    activeReview.comments.map((comment, index) => {
                      const isSystem = comment.startsWith('System:');
                      const isDirector = comment.includes('(Director)') || comment.startsWith('Director');
                      return (
                        <div key={index} className={`text-[11px] p-2 rounded-lg ${
                          isSystem ? 'bg-slate-800/40 text-slate-400 font-mono text-[10px]' :
                          isDirector ? 'bg-[#16243F] border border-[#C9A46A]/20 text-white' :
                          'bg-[#0D1830] border border-white/5 text-slate-300'
                        }`}>
                          {comment}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>

            {/* Actions Form Footer */}
            <div className="border-t border-white/5 pt-3.5 pb-8 px-2 space-y-4 shrink-0 bg-[#0D1830] max-h-[50%] overflow-y-auto custom-scrollbar relative z-50">
              
              {/* Creator-Specific Message Compose */}
              <div className="mb-4">
                {/* Brand Partner Review Room Share (External Partner Access, Not Staff) */}
                <div className="p-3 bg-[#0A1426] border border-cyan-500/30 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2 text-xs text-cyan-300">
                    <Share2 className="w-4 h-4 shrink-0 text-cyan-400" />
                    <div>
                      <span className="font-bold text-white block">Brand Partner Review Room</span>
                      <span className="text-[10px] text-slate-400">
                        Share tokenized review link with external brand partner (zero staff account access).
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopyBrandReviewRoomLink(activeReview);
                    }}
                    className="bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white border border-cyan-400 px-4 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer shrink-0 shadow-lg relative z-50 pointer-events-auto"
                  >
                    <Link2 className="w-4 h-4" /> Copy Partner Link
                  </button>
                </div>
              </div>

              {userRole === 'creator' ? (
                <form onSubmit={handleAddComment} className="flex gap-2.5 items-center">
                  <input
                    type="text"
                    placeholder="Send a message or response regarding this draft..."
                    value={commentInput}
                    onChange={e => setCommentInput(e.target.value)}
                    className="flex-1 bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                  <button 
                    type="submit"
                    className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] p-2.5 rounded-xl transition-colors cursor-pointer"
                    style={{ backgroundColor: primaryBrandColor }}
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              ) : isCoordinator ? (
                /* Coordinator Interactive Approvals & Denials Desk */
                <div className="space-y-3">
                  {activeReview.status === 'Approved' || activeReview.status === 'Approved with Warning' ? (
                    <div className="p-3.5 bg-emerald-950/40 border border-emerald-500/30 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5 text-emerald-300">
                        <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                        <div>
                          <span className="font-bold text-white block">Director Approved &amp; Cleared</span>
                          <span className="text-[10px] text-emerald-300/80">Content is cleared for brand launch. Ready for delivery milestone check-off.</span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleCoordinatorLogDeliveryCheckoff(activeReview.id)}
                        className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-sm"
                      >
                        <Check className="w-3.5 h-3.5" /> Log Delivery Check-Off ✓
                      </button>
                    </div>
                  ) : activeReview.status === 'Rejected' || activeReview.status === 'Revision Requested' ? (
                    <div className="p-3.5 bg-rose-950/40 border border-rose-500/30 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5 text-rose-300">
                        <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                        <div>
                          <span className="font-bold text-white block">Denied / Revision Required by Director</span>
                          <span className="text-[10px] text-rose-300/90 line-clamp-1">
                            {activeReview.comments.filter(c => c.includes('Director')).slice(-1)[0] || 'Revisions required prior to launch.'}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleCoordinatorNudgeCreator(activeReview.id)}
                        className="px-3.5 py-2 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-sm"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" /> Nudge Creator for Revision 🔔
                      </button>
                    </div>
                  ) : (
                    <div className="p-3.5 bg-sky-950/40 border border-sky-500/30 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5 text-sky-300">
                        <Shield className="w-5 h-5 text-sky-400 shrink-0" />
                        <div>
                          <span className="font-bold text-white block">Under Executive Review</span>
                          <span className="text-[10px] text-sky-300/80">Draft submitted by creator, queued for Director compliance &amp; launch sign-off.</span>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono font-bold bg-sky-950 text-sky-300 border border-sky-500/20 px-2.5 py-1 rounded-lg">
                        Pending Sign-off ⏳
                      </span>
                    </div>
                  )}
                </div>
              ) : (isAgentMgr || userRole === "director" || userRole === "admin" || userRole === "super_admin") ? (
                /* Director & Agent Manager Final Action Controls */
                <div className="space-y-3 pt-2">
                  {activeReview.status === 'Approved' ? (
                    <>
                      <div className="p-3.5 bg-emerald-950/50 border border-emerald-500/40 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5 text-emerald-300 text-xs">
                          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                          <div>
                            <span className="font-bold text-white block">Approved &amp; Vaulted in Content Library</span>
                            <span className="text-[11px] text-emerald-300/80">Asset is automatically synchronized in Content Vault &amp; ready for brand distribution.</span>
                          </div>
                        </div>
                        {onNavigate && (
                          <button
                            type="button"
                            onClick={() => onNavigate('content-library')}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                          >
                            <Sparkles className="w-3.5 h-3.5" /> View in Content Vault &rarr;
                          </button>
                        )}
                      </div>

                      {/* Automated Review-to-Invoice Pipeline */}
                      <div className="p-3.5 bg-gradient-to-r from-[#0E1E38] to-[#122547] border border-[#C9A46A]/40 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5 text-xs">
                          <div className="p-2 rounded-lg bg-[#C9A46A]/20 text-[#C9A46A] shrink-0 border border-[#C9A46A]/30">
                            <Receipt className="w-4 h-4" />
                          </div>
                          <div>
                            <span className="font-bold text-white block">Automated Invoicing & Escrow Release</span>
                            <span className="text-[11px] text-slate-300">
                              Draft a billing ledger invoice or clear brand escrow for {activeReview.brand}.
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          <button
                            type="button"
                            onClick={() => handleGenerateInvoiceFromReview(activeReview)}
                            className="flex-1 sm:flex-initial bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] font-mono px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm"
                          >
                            <DollarSign className="w-3.5 h-3.5" /> 1-Click Draft Invoice
                          </button>
                          {onNavigate && (
                            <button
                              type="button"
                              onClick={() => onNavigate('invoicing')}
                              className="bg-white/10 hover:bg-white/15 text-white font-mono px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center justify-center transition-all cursor-pointer"
                            >
                              Hub &rarr;
                            </button>
                          )}
                        </div>
                      </div>
                    </>
                  ) : null}

                  {/* Approval Action */}
                  <div className="p-3.5 bg-[#111E33] border border-white/10 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <span className="text-xs font-bold text-white block">Management Approval Action</span>
                      <span className="text-[11px] text-slate-400">Approving immediately moves deliverable into the Content Vault &amp; Library.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleUpdateStatus(activeReview.id, 'Approved', 'Approved')}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-900/30 transition-all cursor-pointer shrink-0"
                    >
                      <CheckCircle className="w-4 h-4" /> Approve &amp; Move Straight to Vault 🚀
                    </button>
                  </div>

                  {/* Denial & Feedback on what needs to change */}
                  <div className="p-3.5 bg-[#111E33] border border-amber-500/30 rounded-xl space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Denial &amp; Revision Feedback (What needs to change)
                      </span>
                      <span className="text-[10px] text-slate-400">Required when denying or requesting revisions</span>
                    </div>

                    <textarea
                      rows={2}
                      placeholder="Specify what needs to change (e.g. lighting, pacing, audio track, missing #ad hashtag, or brand logo placement)..."
                      value={customComment}
                      onChange={e => setCustomComment(e.target.value)}
                      className="w-full bg-[#0D1830] border border-white/15 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400 resize-none"
                    />

                    <div className="flex flex-wrap gap-2 justify-end pt-1">
                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(activeReview.id, 'Revision Requested', 'Sent back to creator')}
                        className="bg-amber-950/60 hover:bg-amber-900/80 border border-amber-500/50 text-amber-300 px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" /> Deny &amp; Request Revisions
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(activeReview.id, 'Rejected', 'Rejected')}
                        className="bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/50 text-rose-300 px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" /> Reject Submission
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(activeReview.id, 'Pending Agent Review', 'Sent to agent')}
                        className="bg-[#16243F] hover:bg-[#1f3257] border border-white/10 text-slate-300 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Send to agent
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(activeReview.id, 'Pending Agent Manager Review', 'Sent to agent manager')}
                        className="bg-[#16243F] hover:bg-[#1f3257] border border-white/10 text-slate-300 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Send to agent manager
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                /* Agent Content Review Observation & Notes Desk (Read-Only Authority) */
                <div className="p-4 rounded-xl bg-[#111E33] border border-white/10 space-y-3.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/20 px-2.5 py-0.5 rounded-full">
                        Agent Inspection Console
                      </span>
                      <span className="text-xs text-slate-300">
                        Authority: <strong className="text-amber-300">Director &amp; Agent Manager Only</strong>
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">Status:</span>
                      <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full border ${
                        activeReview.status === 'Approved' ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40' :
                        activeReview.status === 'Rejected' ? 'bg-rose-950/80 text-rose-300 border-rose-500/40' :
                        activeReview.status === 'Revision Requested' ? 'bg-amber-950/80 text-amber-300 border-amber-500/40' :
                        'bg-sky-950/80 text-sky-300 border-sky-500/40'
                      }`}>
                        {activeReview.status === 'Approved' ? '✓ Approved' : activeReview.status === 'Revision Requested' ? '⚠️ Revision Requested' : activeReview.status === 'Rejected' ? '✕ Denied / Rejected' : '⏳ Pending Review'}
                      </span>
                    </div>
                  </div>

                  {activeReview.denialFeedback && (
                    <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5" /> Denial Feedback (What needs to change)
                        </span>
                        {activeReview.denialFeedbackBy && (
                          <span className="text-[10px] text-amber-400/80 font-mono">By {activeReview.denialFeedbackBy}</span>
                        )}
                      </div>
                      <p className="text-xs text-amber-100/90 leading-relaxed font-sans">{activeReview.denialFeedback}</p>
                    </div>
                  )}

                  {activeReview.status === 'Approved' && onNavigate && (
                    <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl flex items-center justify-between gap-2">
                      <span className="text-xs text-emerald-300 flex items-center gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Deliverable is approved and cataloged in Content Vault.
                      </span>
                      <button
                        type="button"
                        onClick={() => onNavigate('content-library')}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                      >
                        View in Vault &rarr;
                      </button>
                    </div>
                  )}

                  <form onSubmit={handleAddComment} className="flex gap-2 items-center pt-1">
                    <input
                      type="text"
                      placeholder="Add internal agent note for creator or agent manager..."
                      value={commentInput}
                      onChange={e => setCommentInput(e.target.value)}
                      className="flex-1 bg-[#0D1830] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                    />
                    <button
                      type="submit"
                      className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
                    >
                      Post Note
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="lg:col-span-7 bg-[#0D1830] border border-white/5 rounded-2xl p-5 flex flex-col justify-center items-center min-h-[600px] lg:min-h-[calc(100vh-200px)] lg:h-[calc(100vh-200px)]" style={{ backgroundColor: cardBgColor }}>
            <AlertTriangle className="w-8 h-8 text-slate-500 mb-2" />
            <p className="text-xs text-slate-400">Select a submission draft from the ledger list to begin inspection.</p>
          </div>
        )}
      </div>

      {/* Fullscreen Media Lightbox Modal */}
      {fullscreenImage && (
        <div 
          onClick={() => setFullscreenImage(null)}
          className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4 cursor-pointer animate-fade-in"
        >
          <div className="relative max-w-5xl w-full max-h-[90vh] flex flex-col items-center justify-center">
            <button 
              onClick={() => setFullscreenImage(null)}
              className="absolute -top-10 right-0 text-white hover:text-rose-400 font-mono text-sm bg-black/50 px-3 py-1 rounded-lg border border-white/20"
            >
              ✕ Close
            </button>
            <img 
              src={fullscreenImage} 
              alt="Fullscreen media draft" 
              className="max-w-full max-h-[85vh] object-contain rounded-xl border border-white/10 shadow-2xl" 
            />
          </div>
        </div>
      )}
    </div>
  );
}
