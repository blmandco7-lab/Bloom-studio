import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Video, 
  Plus, 
  Layers, 
  Search, 
  Filter, 
  Upload, 
  ShieldCheck, 
  Lock,
  Calendar,
  Sparkles
} from 'lucide-react';
import { Creator } from '../types';

export interface CreatorRetainerQuota {
  id: string;
  creatorHandle: string;
  creatorName: string;
  avatar: string;
  brandCampaign: string;
  monthlyQuota: number; // e.g. 4 videos
  currentCompleted: number; // e.g. 2
  billingCycleMonth: string; // e.g. "August 2026"
  nextDeadline: string; // e.g. "2026-08-28"
  deliverables: Array<{
    id: string;
    title: string;
    submittedDate: string;
    status: 'Approved & Cleared' | 'Under Review' | 'Revision Requested';
    videoFormat: string;
  }>;
}

const INITIAL_QUOTAS: CreatorRetainerQuota[] = [
  {
    id: 'quota_01',
    creatorHandle: '@olivia.glows',
    creatorName: 'Olivia Sterling',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    brandCampaign: 'GlowLab Monthly Skincare Retainer',
    monthlyQuota: 4,
    currentCompleted: 3,
    billingCycleMonth: 'August 2026',
    nextDeadline: '2026-08-28',
    deliverables: [
      { id: 'del_1', title: 'Barrier Serum Morning Routine 4K', submittedDate: '2026-08-05', status: 'Approved & Cleared', videoFormat: '9:16 UGC Vertical' },
      { id: 'del_2', title: 'Night Cream Texture Closeup', submittedDate: '2026-08-12', status: 'Approved & Cleared', videoFormat: '9:16 UGC Vertical' },
      { id: 'del_3', title: '7-Day Hydration Test Voiceover', submittedDate: '2026-08-19', status: 'Under Review', videoFormat: '9:16 UGC Vertical' }
    ]
  },
  {
    id: 'quota_02',
    creatorHandle: '@alexjones',
    creatorName: 'Alex Jones',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    brandCampaign: 'BarkHydrate Canine Wellness Retainer',
    monthlyQuota: 4,
    currentCompleted: 2,
    billingCycleMonth: 'August 2026',
    nextDeadline: '2026-08-25',
    deliverables: [
      { id: 'del_4', title: 'Pet Electrolyte Unboxing & Dog Reaction', submittedDate: '2026-08-08', status: 'Approved & Cleared', videoFormat: '9:16 UGC Vertical' },
      { id: 'del_5', title: 'Summer Outdoor Park Workout & Hydration', submittedDate: '2026-08-15', status: 'Approved & Cleared', videoFormat: '9:16 UGC Vertical' }
    ]
  },
  {
    id: 'quota_03',
    creatorHandle: '@ava.style',
    creatorName: 'Ava Vance',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
    brandCampaign: 'Lumina Velvet Lip Tint Retainer',
    monthlyQuota: 3,
    currentCompleted: 1,
    billingCycleMonth: 'August 2026',
    nextDeadline: '2026-08-22',
    deliverables: [
      { id: 'del_6', title: 'All-Day Swatch & Wear Test', submittedDate: '2026-08-10', status: 'Approved & Cleared', videoFormat: '9:16 UGC Vertical' }
    ]
  }
];

interface MonthlyRetainerQuotaLedgersProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

export default function MonthlyRetainerQuotaLedgers({
  creators,
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}: MonthlyRetainerQuotaLedgersProps) {
  const [quotas, setQuotas] = useState<CreatorRetainerQuota[]>(INITIAL_QUOTAS);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedQuota, setSelectedQuota] = useState<CreatorRetainerQuota | null>(INITIAL_QUOTAS[0]);

  // Log new video submission
  const [newVideoTitle, setNewVideoTitle] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const handleLogUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedQuota || !newVideoTitle.trim()) return;

    const newDeliverable = {
      id: 'del_' + Date.now(),
      title: newVideoTitle,
      submittedDate: new Date().toISOString().split('T')[0],
      status: 'Under Review' as const,
      videoFormat: '9:16 UGC Vertical'
    };

    const updatedQuotas = quotas.map(q => {
      if (q.id === selectedQuota.id) {
        const nextCompleted = Math.min(q.monthlyQuota, q.currentCompleted + 1);
        return {
          ...q,
          currentCompleted: nextCompleted,
          deliverables: [newDeliverable, ...q.deliverables]
        };
      }
      return q;
    });

    setQuotas(updatedQuotas);
    setSelectedQuota({
      ...selectedQuota,
      currentCompleted: Math.min(selectedQuota.monthlyQuota, selectedQuota.currentCompleted + 1),
      deliverables: [newDeliverable, ...selectedQuota.deliverables]
    });

    if (triggerNotification) {
      triggerNotification('Retainer Video Logged', `Logged "${newVideoTitle}" for ${selectedQuota.creatorHandle}`, 'success');
    }

    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || 'Manager', currentRole, `Logged retainer video upload for ${selectedQuota.creatorHandle}`);
    }

    setNewVideoTitle('');
    setShowAddModal(false);
  };

  const isCreator = currentRole.toLowerCase() === 'creator';
  const myHandle = (currentUser?.handle || '').toLowerCase();
  const myName = (currentUser?.name || '').toLowerCase();

  const filteredQuotas = quotas.filter(q => {
    if (isCreator) {
      const qHandle = q.creatorHandle.toLowerCase();
      const qName = q.creatorName.toLowerCase();
      const matchMe = (myHandle && qHandle.includes(myHandle)) || (myName && qName.includes(myName)) || qHandle.includes('alexjones');
      if (!matchMe) return false;
    }
    return (
      q.creatorHandle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.creatorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.brandCampaign.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      {/* Header Banner */}
      <div className="bg-[#0b1320] border-2 border-emerald-500/30 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-0.5 rounded-full">
                {isCreator ? 'CREATOR RETAINER QUOTA' : 'DIRECTOR & MANAGER WORKFLOW SHEET'}
              </span>
              <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                <Lock className="w-3 h-3 text-amber-400" />
                {isCreator ? 'Direct Talent Payouts Only' : 'Brand Financials Masked'}
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5">
              {isCreator ? 'My Monthly Retainer Quota & Deliverables' : 'Monthly Retainer Quota Ledgers'}
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              {isCreator
                ? 'Track your monthly deliverable progress, upload verified video links, and review clearance status for your contracted brand retainers.'
                : 'Track talent monthly video contribution progress without exposing sensitive long-term brand billing data or contract pricing.'}
            </p>
          </div>

          <div className="bg-[#050e1a] border border-white/10 rounded-xl p-3 flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[9px] text-slate-400 uppercase font-mono block">Security Lock</span>
              <span className="text-xs font-bold text-white block">
                {isCreator ? 'Creator Escrow Connected' : 'Manager Isolation Layer Active'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Creator Retainer List */}
        <div className="bg-[#050e1a] border border-white/5 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Active Retainer Roster
            </h2>
            <span className="text-[10px] text-slate-400 font-mono">
              {filteredQuotas.length} Active
            </span>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input 
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Filter by creator or campaign..."
              className="w-full bg-[#0d1830] border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
            />
          </div>

          {/* Quota Cards */}
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {filteredQuotas.map((quota) => {
              const pct = Math.round((quota.currentCompleted / quota.monthlyQuota) * 100);
              const isSelected = selectedQuota?.id === quota.id;

              return (
                <button
                  key={quota.id}
                  type="button"
                  onClick={() => setSelectedQuota(quota)}
                  className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer space-y-3 block ${
                    isSelected
                      ? 'bg-[#0d1f38] border-emerald-500/60 shadow-lg shadow-emerald-500/5'
                      : 'bg-[#0a1424] border-white/5 hover:border-white/20'
                  }`}
                  aria-label={`Select ${quota.creatorName} retainer: ${quota.brandCampaign}`}
                  aria-current={isSelected ? 'true' : 'false'}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <img 
                        src={quota.avatar} 
                        alt={quota.creatorName}
                        className="w-9 h-9 rounded-full object-cover border border-emerald-500/30"
                      />
                      <div>
                        <h3 className="text-xs font-bold text-white">{quota.creatorName}</h3>
                        <span className="text-[10px] font-mono text-emerald-400">{quota.creatorHandle}</span>
                      </div>
                    </div>

                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                      pct === 100 
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                        : pct >= 50 
                        ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                        : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                    }`}>
                      {pct === 100 ? 'Quota Met' : `${quota.currentCompleted}/${quota.monthlyQuota} Videos`}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 font-medium">
                    {quota.brandCampaign}
                  </p>

                  {/* Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[9px] font-mono text-slate-400">
                      <span>Monthly Progress ({quota.billingCycleMonth})</span>
                      <span>{pct}%</span>
                    </div>
                    <div className="w-full bg-[#050e1a] h-2 rounded-full overflow-hidden border border-white/5">
                      <div 
                        className={`h-full transition-all duration-500 ${
                          pct === 100 ? 'bg-emerald-400' : 'bg-amber-400'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Quota Tracker & Video Upload Log */}
        {selectedQuota ? (
          <div className="lg:col-span-2 bg-[#050e1a] border border-white/5 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
              <div className="flex items-center gap-3">
                <img 
                  src={selectedQuota.avatar} 
                  alt={selectedQuota.creatorName}
                  className="w-12 h-12 rounded-full object-cover border-2 border-emerald-400"
                />
                <div>
                  <h2 className="text-lg font-bold text-white">{selectedQuota.creatorName}</h2>
                  <p className="text-xs text-emerald-400 font-mono">{selectedQuota.creatorHandle} &bull; {selectedQuota.brandCampaign}</p>
                </div>
              </div>

              <button
                onClick={() => setShowAddModal(true)}
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Log Video Upload</span>
              </button>
            </div>

            {/* Quota Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-[#0d1830] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Monthly Target Quota</span>
                <span className="text-xl font-mono font-bold text-white">{selectedQuota.monthlyQuota} UGC Videos / Mo</span>
              </div>

              <div className="p-4 bg-[#0d1830] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Uploaded Progress</span>
                <span className="text-xl font-mono font-bold text-emerald-400">
                  {selectedQuota.currentCompleted} / {selectedQuota.monthlyQuota} ({Math.round((selectedQuota.currentCompleted / selectedQuota.monthlyQuota) * 100)}%)
                </span>
              </div>

              <div className="p-4 bg-[#0d1830] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Next Deliverable Due</span>
                <span className="text-sm font-mono font-bold text-amber-400 flex items-center gap-1.5 mt-1">
                  <Calendar className="w-3.5 h-3.5" />
                  {selectedQuota.nextDeadline}
                </span>
              </div>
            </div>

            {/* Security Isolation Notice */}
            <div className="p-3 bg-[#0d1f38] border border-emerald-500/20 rounded-xl text-xs text-slate-300 flex items-center gap-3">
              <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Manager Privacy Shield:</strong> Creator retainer contribution counts are isolated from brand invoice totals and net agency margins.
              </span>
            </div>

            {/* Uploaded Deliverables History List */}
            <div className="space-y-4">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Video className="w-4 h-4 text-emerald-400" />
                Submitted Deliverables Ledger ({selectedQuota.deliverables.length})
              </h3>

              <div className="space-y-2">
                {selectedQuota.deliverables.map((item) => (
                  <div 
                    key={item.id}
                    className="p-3.5 bg-[#0a1424] border border-white/5 rounded-xl flex items-center justify-between gap-4 hover:border-white/10 transition"
                  >
                    <div className="space-y-0.5">
                      <h4 className="text-xs font-bold text-white">{item.title}</h4>
                      <p className="text-[10px] text-slate-400 font-mono">
                        Submitted: {item.submittedDate} &bull; {item.videoFormat}
                      </p>
                    </div>

                    <span className={`text-[10px] font-mono px-2.5 py-1 rounded-lg border font-bold ${
                      item.status === 'Approved & Cleared'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : null}
      </div>

      {/* Modal for logging video upload */}
      {showAddModal && selectedQuota && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b1320] border-2 border-emerald-500/40 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-fade-in">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-sm font-bold text-white uppercase font-mono">
                Log Retainer Video Contribution
              </h3>
              <button 
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-xs font-mono"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleExecuteLogUpload} className="space-y-4">
              <div>
                <label className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                  Creator &amp; Retainer Campaign
                </label>
                <input 
                  type="text" 
                  disabled 
                  value={`${selectedQuota.creatorHandle} - ${selectedQuota.brandCampaign}`} 
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-emerald-400 uppercase mb-1 font-bold">
                  Video Title / UGC Deliverable
                </label>
                <input 
                  type="text"
                  required
                  value={newVideoTitle}
                  onChange={(e) => setNewVideoTitle(e.target.value)}
                  placeholder="e.g. Summer Skincare Unboxing & Routine"
                  className="w-full bg-[#050e1a] border border-emerald-500/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 font-semibold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-300 bg-white/5 hover:bg-white/10 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition"
                >
                  Confirm &amp; Increment Quota
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );

  function handleExecuteLogUpload(e: React.FormEvent) {
    handleLogUpload(e);
  }
}
