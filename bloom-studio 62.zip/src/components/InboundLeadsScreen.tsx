import React, { useState } from 'react';
import { Inbox, Mail, Building, CheckCircle2, ArrowRight, ExternalLink, FileText, Sparkles, Trash2, ShieldCheck, Clock, Briefcase, ShieldAlert, Share2, Copy, Check } from 'lucide-react';
import { db } from '../lib/firebase';
import { doc, updateDoc, deleteDoc, setDoc, collection } from 'firebase/firestore';
import { cleanUndefinedForFirestore } from '../lib/firebase';
import { Deal } from '../types';
import { safeStorage } from '../utils/safeStorage';
import { addBrandToGlobalBlacklist } from '../lib/blacklistService';

interface InboundLeadsScreenProps {
  inboundLeads: any[];
  currentRole?: string;
  currentUser?: any;
  primaryBrandColor?: string;
  cardBgColor?: string;
  triggerNotification?: (title: string, message: string, type: 'success' | 'danger' | 'info' | 'warning') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  onNavigate?: (screen: string) => void;
}

export default function InboundLeadsScreen({
  inboundLeads = [],
  currentRole = 'director',
  currentUser,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  triggerNotification,
  onAddActivityLog,
  onNavigate
}: InboundLeadsScreenProps) {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isCopiedLink, setIsCopiedLink] = useState<boolean>(false);

  const handleCopyShareLink = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const shareUrl = `${origin}/#inbound-leads`;
    navigator.clipboard.writeText(shareUrl);
    setIsCopiedLink(true);
    triggerNotification?.("Link Copied", "Shareable Inbound Leads URL copied to clipboard.", "success");
    setTimeout(() => setIsCopiedLink(false), 2500);
  };

  const userRole = (currentRole || '').toLowerCase();
  const isDirectorOrOwner = Boolean(
    currentUser?.isPlatformOwner ||
    userRole === 'director' ||
    userRole === 'owner' ||
    userRole === 'super_admin' ||
    userRole === 'agency'
  );

  const sortedLeads = [...inboundLeads].sort((a, b) => {
    const timeA = new Date(a.submittedAt || a.createdAt || a.timestamp || 0).getTime();
    const timeB = new Date(b.submittedAt || b.createdAt || b.timestamp || 0).getTime();
    return timeB - timeA;
  });

  const filteredLeads = sortedLeads.filter(lead => {
    // If not director/owner (e.g. agentmgr, agent, coordinator), restrict to leads they are working with or reached out to
    if (!isDirectorOrOwner) {
      const myName = (currentUser?.name || '').toLowerCase();
      const myEmail = (currentUser?.email || '').toLowerCase();
      const myHandle = (currentUser?.handle || '').toLowerCase();
      const myId = (currentUser?.id || currentUser?.uid || '').toLowerCase();

      const leadAssigned = (
        lead.assignedAgentId || 
        lead.assignedTo || 
        lead.agentEmail || 
        lead.reachedOutBy || 
        lead.manager || 
        lead.agent ||
        ''
      ).toLowerCase();

      const isWorkingWithLead = 
        (leadAssigned && (
          (myId && leadAssigned.includes(myId)) ||
          (myName && leadAssigned.includes(myName)) ||
          (myEmail && leadAssigned.includes(myEmail)) ||
          (myHandle && leadAssigned.includes(myHandle))
        )) ||
        (lead.history && Array.isArray(lead.history) && lead.history.some((h: any) => 
          (h.user || h.author || '').toLowerCase().includes(myName) ||
          (h.user || h.author || '').toLowerCase().includes(myEmail)
        ));

      if (!isWorkingWithLead) return false;
    }

    const matchesStatus = filterStatus === 'all' || (lead.status || 'New').toLowerCase() === filterStatus.toLowerCase();
    const matchesSearch = 
      (lead.brandName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (lead.contactEmail || lead.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (lead.campaignNotes || lead.campaignGoals || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (lead.source || '').toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleMarkReviewed = async (lead: any) => {
    try {
      const colName = lead.source?.includes('Showcase') || lead.budgetScope || lead.budgetTier ? 'inboundLeads' : 'inbound-agency-leads';
      const docId = lead.id && !lead.id.startsWith('sample_') ? lead.id : `lead_${Date.now()}`;
      const docRef = doc(db, colName, docId);
      await setDoc(docRef, cleanUndefinedForFirestore({ ...lead, id: docId, status: 'Reviewed' }), { merge: true });

      try {
        const saved = safeStorage.getItem("wl_inbound_leads");
        if (saved) {
          const parsed = JSON.parse(saved);
          const updated = parsed.map((i: any) => i.id === lead.id ? { ...i, status: 'Reviewed' } : i);
          safeStorage.setItem("wl_inbound_leads", JSON.stringify(updated));
        }
      } catch (e) {}

      triggerNotification?.("Lead Updated", `Marked lead from ${lead.brandName || lead.title || 'Inquiry'} as Reviewed.`, "success");
      onAddActivityLog?.(currentUser?.name || "Staff", currentRole, `Marked inbound lead as Reviewed: ${lead.brandName || lead.title}`);
    } catch (e) {
      console.error("Failed to update lead status:", e);
      triggerNotification?.("Update Failed", "Could not update lead status.", "danger");
    }
  };

  const handleConvertToDeal = async (lead: any) => {
    const newDeal: Deal = {
      id: `deal_lead_${Date.now()}`,
      brand: lead.brandName || lead.title || "Inbound Partner",
      title: lead.campaignNotes ? lead.campaignNotes.slice(0, 50) + "..." : `Partnership with ${lead.brandName || 'Brand'}`,
      creator: "Unassigned Roster",
      budget: 15000,
      platform: lead.targetedVertical || "TikTok/Instagram",
      stage: "Lead",
      due: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      subagency: currentUser?.subagency || "pod_main",
      tenantId: currentUser?.tenantId || "bloom_studio_default",
      createdAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, "studio-deals", newDeal.id), cleanUndefinedForFirestore(newDeal));
      const colName = lead.source?.includes('Showcase') || lead.budgetScope || lead.budgetTier ? 'inboundLeads' : 'inbound-agency-leads';
      const docId = lead.id && !lead.id.startsWith('sample_') ? lead.id : `lead_${Date.now()}`;
      const docRef = doc(db, colName, docId);
      await setDoc(docRef, cleanUndefinedForFirestore({ ...lead, id: docId, status: 'Converted to Deal' }), { merge: true });
      
      triggerNotification?.("Deal Converted", `Successfully converted inquiry from ${lead.brandName || 'Brand'} into a live pipeline deal ($15,000).`, "success");
      onAddActivityLog?.(currentUser?.name || "Director", currentRole, `Converted inbound lead to deal: ${newDeal.brand}`);
    } catch (err) {
      console.error("Failed to convert lead to deal:", err);
      triggerNotification?.("Conversion Failed", "Could not write deal to Firestore.", "danger");
    }
  };

  const handleSyncToCrm = async (lead: any) => {
    try {
      let brands = [];
      try {
        const savedBrands = safeStorage.getItem("studio_brand_crm_brands");
        if (savedBrands) brands = JSON.parse(savedBrands);
      } catch (e) {}

      const brandName = lead.brandName || lead.title || "Partner Brand";
      
      // Check if brand already exists to prevent duplicate copies
      let existingBrand = brands.find((b: any) => b.name?.toLowerCase() === brandName.toLowerCase());
      let brandId = existingBrand ? existingBrand.id : `br_${Date.now()}`;

      if (!existingBrand) {
        const newBrand = {
          id: brandId,
          name: brandName,
          logo: lead.logo || "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=100&auto=format&fit=crop&q=80",
          industry: lead.targetedVertical || lead.nicheInterest || "Apparel & Lifestyle",
          ownerId: currentUser?.id || 'agent_01',
          status: 'Active Partner',
          escrowPreference: '100% Pre-funded Escrow',
          notes: lead.campaignNotes || lead.message || 'Synced from Inbound Lead Queue.'
        };
        brands.unshift(newBrand);
        safeStorage.setItem("studio_brand_crm_brands", JSON.stringify(brands));
      }

      let contacts = [];
      try {
        const savedContacts = safeStorage.getItem("studio_brand_crm_contacts");
        if (savedContacts) contacts = JSON.parse(savedContacts);
      } catch (e) {}

      const contactEmail = lead.contactEmail || lead.email || 'partner@brand.com';
      let existingContact = contacts.find((c: any) => c.email?.toLowerCase() === contactEmail.toLowerCase() || c.brandId === brandId);

      if (!existingContact) {
        const newContact = {
          id: `ct_${Date.now()}`,
          brandId: brandId,
          name: lead.contactName || contactEmail.split('@')[0] || 'Brand Representative',
          title: 'Partnerships Lead',
          email: contactEmail,
          phone: lead.contactPhone || lead.phone || '+1 (555) 000-0000'
        };
        contacts.unshift(newContact);
        safeStorage.setItem("studio_brand_crm_contacts", JSON.stringify(contacts));
      }

      const colName = lead.source?.includes('Showcase') || lead.budgetScope || lead.budgetTier ? 'inboundLeads' : 'inbound-agency-leads';
      const docId = lead.id && !lead.id.startsWith('sample_') ? lead.id : `lead_${Date.now()}`;
      const docRef = doc(db, colName, docId);
      try {
        await setDoc(docRef, cleanUndefinedForFirestore({ ...lead, id: docId, status: 'Synced to CRM', syncStatus: 'Synced' }), { merge: true });
      } catch (err) {
        console.warn("Firestore sync status write warning:", err);
      }

      triggerNotification?.("Synced to Brand CRM", `Successfully synced ${brandName} to Brand CRM.`, "success");
      onAddActivityLog?.(currentUser?.name || "Staff", currentRole, `Synced inbound lead to Brand CRM: ${brandName}`);

      // Navigate to Brand CRM page
      onNavigate?.('brand-crm');
    } catch (err) {
      console.error("Failed to sync lead to CRM:", err);
      try {
        const colName = lead.source?.includes('Showcase') || lead.budgetScope || lead.budgetTier ? 'inboundLeads' : 'inbound-agency-leads';
        const docRef = doc(db, colName, lead.id || `lead_${Date.now()}`);
        await setDoc(docRef, cleanUndefinedForFirestore({ ...lead, syncStatus: 'Failed' }), { merge: true });
      } catch (e) {}
      triggerNotification?.("CRM Sync Failed", "Could not create record in Brand CRM.", "danger");
    }
  };

  const handleDeleteLead = async (lead: any) => {
    try {
      if (lead.id && !lead.id.startsWith('sample_')) {
        const colName = lead.source?.includes('Showcase') || lead.budgetScope || lead.budgetTier ? 'inboundLeads' : 'inbound-agency-leads';
        await deleteDoc(doc(db, colName, lead.id));
      }
      try {
        const saved = safeStorage.getItem("wl_inbound_leads");
        if (saved) {
          const parsed = JSON.parse(saved);
          const filtered = parsed.filter((i: any) => i.id !== lead.id);
          safeStorage.setItem("wl_inbound_leads", JSON.stringify(filtered));
        }
      } catch (e) {}

      triggerNotification?.("Lead Deleted", "Inbound lead removed from queue.", "info");
      onAddActivityLog?.(currentUser?.name || "Staff", currentRole, `Deleted inbound lead: ${lead.brandName || lead.title}`);
    } catch (e) {
      console.error("Failed to delete lead:", e);
      triggerNotification?.("Delete Failed", "Could not remove lead.", "danger");
    }
  };

  const handleBlockAndBanLead = async (lead: any) => {
    const brandName = lead.brandName || lead.title || "Partner Brand";
    if (!window.confirm(`Are you sure you want to block and ban "${brandName}"? This will add the brand to the Agency Brand Blacklist and prohibit all future deals and contract dispatches.`)) {
      return;
    }

    try {
      await addBrandToGlobalBlacklist({
        brand: brandName,
        reason: lead.campaignNotes || lead.campaignGoals || lead.message || 'Blocked & banned directly from Inbound Leads Dashboard.',
        blockedBy: currentUser?.name || 'Agency Director',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        subagency: currentUser?.subagency || 'pod_main'
      });

      try {
        const savedBl = localStorage.getItem('wl_blacklistedBrands');
        const blArray = savedBl ? JSON.parse(savedBl) : [];
        const newBlRecord = {
          id: 'bl_' + Date.now(),
          brand: brandName,
          reason: lead.campaignNotes || lead.campaignGoals || lead.message || 'Blocked & banned directly from Inbound Leads Dashboard.',
          date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          blockedBy: currentUser?.name || 'Agency Director'
        };
        if (!blArray.some((b: any) => b.brand?.toLowerCase() === brandName.toLowerCase())) {
          localStorage.setItem('wl_blacklistedBrands', JSON.stringify([newBlRecord, ...blArray]));
        }
      } catch (e) {}

      const colName = lead.source?.includes('Showcase') || lead.budgetScope || lead.budgetTier ? 'inboundLeads' : 'inbound-agency-leads';
      const docId = lead.id && !lead.id.startsWith('sample_') ? lead.id : `lead_${Date.now()}`;
      const docRef = doc(db, colName, docId);
      await setDoc(docRef, cleanUndefinedForFirestore({ ...lead, id: docId, status: 'Blocked & Blacklisted' }), { merge: true });

      try {
        const saved = safeStorage.getItem("wl_inbound_leads");
        if (saved) {
          const parsed = JSON.parse(saved);
          const updated = parsed.map((i: any) => i.id === lead.id ? { ...i, status: 'Blocked & Blacklisted' } : i);
          safeStorage.setItem("wl_inbound_leads", JSON.stringify(updated));
        }
      } catch (e) {}

      triggerNotification?.("Brand Blacklisted", `Successfully added ${brandName} to the Agency Brand Blacklist. Deal creation is prohibited.`, "warning");
      onAddActivityLog?.(currentUser?.name || "Staff", currentRole, `Blocked & Blacklisted inbound lead brand: ${brandName}`);
    } catch (e) {
      console.error("Failed to block lead:", e);
      triggerNotification?.("Block Failed", "Could not add brand to blacklist.", "danger");
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 py-6 animate-fade-in font-sans text-white">
      {/* Top Director Hub & Share Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#091122] border border-white/10 p-3.5 rounded-2xl shadow-lg">
        <div className="flex items-center gap-2 flex-wrap text-xs font-mono">
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[11px] mr-1">Quick Hub Navigation:</span>
          <button
            onClick={() => onNavigate?.('briefing')}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-[#C9A46A]/20 hover:text-[#C9A46A] text-slate-300 border border-white/10 transition cursor-pointer flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5 text-[#C9A46A]" /> Daily Briefing
          </button>
          <button
            onClick={() => onNavigate?.('creator-match')}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-[#C9A46A]/20 hover:text-[#C9A46A] text-slate-300 border border-white/10 transition cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Match or Pass
          </button>
          <button
            onClick={() => onNavigate?.('public-portfolio')}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-[#C9A46A]/20 hover:text-[#C9A46A] text-slate-300 border border-white/10 transition cursor-pointer flex items-center gap-1.5"
          >
            <Briefcase className="w-3.5 h-3.5 text-emerald-400" /> Public Portfolio
          </button>
        </div>

        <button
          type="button"
          onClick={handleCopyShareLink}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0D1830] hover:bg-[#C9A46A] hover:text-[#070D18] border border-[#C9A46A]/50 text-[#C9A46A] text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer shadow-md"
        >
          {isCopiedLink ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400">Link Copied!</span>
            </>
          ) : (
            <>
              <Share2 className="w-4 h-4" />
              <span>Share Page Link</span>
            </>
          )}
        </button>
      </div>

      {/* Header Banner */}
      <div 
        style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}20` }}
        className="p-6 rounded-2xl border shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-amber-500/10 via-transparent to-transparent pointer-events-none" />
        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold uppercase tracking-wider">
              Inbound Pipeline
            </span>
            <span className="text-xs text-slate-400 font-mono">Real-Time Firestore Sync</span>
          </div>
          <h1 className="text-2xl font-serif font-bold text-white flex items-center gap-2">
            <Inbox className="w-7 h-7 text-[#C9A46A]" /> Inbound Brand Inquiries & Leads
          </h1>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Real-time submissions captured from Public Talent Showcases and Portfolio Contact Footers. Review inquiries, track budgets, and instantly convert sponsor leads into live agency deals.
          </p>
        </div>

        <div className="flex items-center gap-3 z-10">
          <button
            onClick={async () => {
              const testLead = {
                brandName: "Acme Luxury Co.",
                contactEmail: "partnerships@acmeluxury.com",
                targetedVertical: "Fashion & Lifestyle",
                budgetScope: "$25,000 - $50,000",
                campaignNotes: "Looking to partner with top creator talent for our upcoming Spring luxury drop campaign.",
                source: "Public Talent Showcase",
                status: "New",
                submittedAt: new Date().toISOString(),
                createdAt: new Date().toISOString()
              };
              try {
                await setDoc(doc(db, "inboundLeads", `lead_test_${Date.now()}`), cleanUndefinedForFirestore(testLead));
                triggerNotification?.("Test Lead Added", "Successfully created test brand inquiry in Firestore.", "success");
                onAddActivityLog?.(currentUser?.name || "Director", currentRole, `Created test brand inquiry for ${testLead.brandName}`);
              } catch (err) {
                console.error("Failed to add test lead:", err);
                triggerNotification?.("Error", "Could not create test lead in Firestore.", "danger");
              }
            }}
            className="px-3 py-2 bg-[#C9A46A]/20 hover:bg-[#C9A46A]/30 text-[#C9A46A] border border-[#C9A46A]/40 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" /> Send Test Inquiry
          </button>
          <div className="bg-black/30 px-4 py-2 rounded-xl border border-white/10 text-center">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Total Inbound</div>
            <div className="text-xl font-bold font-mono text-[#C9A46A]">{inboundLeads.length}</div>
          </div>
        </div>
      </div>

      {/* Controls & Filters */}
      <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 bg-[#0A1124] p-4 rounded-xl border border-white/10">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
          {['all', 'new', 'reviewed', 'converted to deal', 'blocked & blacklisted'].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold capitalize transition-all cursor-pointer ${
                filterStatus === status
                  ? 'bg-[#C9A46A] text-slate-950 shadow'
                  : 'bg-black/20 text-slate-300 hover:bg-black/40 border border-white/5'
              }`}
            >
              {status}
            </button>
          ))}
        </div>

        <div className="w-full sm:w-72">
          <input
            type="text"
            placeholder="Search brand, email, or notes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
          />
        </div>
      </div>

      {/* Leads List */}
      <div className="space-y-4">
        {filteredLeads.length === 0 ? (
          <div className="text-center py-16 bg-[#0A1124]/60 rounded-2xl border border-white/5 space-y-3">
            <Inbox className="w-12 h-12 text-slate-600 mx-auto animate-pulse" />
            <p className="text-sm font-semibold text-slate-300">No Inbound Leads Found</p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Inbound brand inquiries submitted through the Public Talent Showcase or Creator Portfolio footer will appear here instantly in real time.
            </p>
          </div>
        ) : (
          filteredLeads.map((lead, index) => {
            const leadStatus = lead.status || 'New';
            const isBlocked = leadStatus.toLowerCase().includes('blocked') || leadStatus.toLowerCase().includes('blacklisted');
            const statusColor = 
              leadStatus === 'Reviewed' ? 'bg-sky-500/10 text-sky-400 border-sky-500/20' :
              leadStatus.includes('Converted') ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
              isBlocked ? 'bg-rose-500/20 text-rose-400 border-rose-500/30' :
              'bg-amber-500/10 text-amber-400 border-amber-500/20';

            const isSynced = leadStatus === 'Synced to CRM' || leadStatus.includes('Synced');
            const syncStatusText = isSynced ? 'CRM: Synced' : lead.syncStatus === 'Failed' ? 'CRM: Failed' : 'CRM: Pending';
            const syncStatusColor = isSynced 
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
              : lead.syncStatus === 'Failed' 
                ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' 
                : 'bg-amber-500/10 text-amber-400 border-amber-500/20';

            return (
              <div
                key={lead.id || `lead_${index}`}
                style={{ backgroundColor: cardBgColor, borderColor: isBlocked ? '#f43f5e30' : `${primaryBrandColor}15` }}
                className="p-5 rounded-2xl border shadow-sm hover:border-[#C9A46A]/40 transition-all flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6"
              >
                <div className="space-y-2 flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border font-bold uppercase ${statusColor}`}>
                      {leadStatus}
                    </span>
                    <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border font-bold uppercase ${syncStatusColor}`}>
                      {syncStatusText}
                    </span>
                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20">
                      {lead.source || 'Public Showcase'}
                    </span>
                    <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(lead.submittedAt || lead.createdAt || lead.timestamp || Date.now()).toLocaleString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <h3 className="text-base font-serif font-bold text-white flex items-center gap-2">
                      <Building className="w-4 h-4 text-[#C9A46A]" /> {lead.brandName || lead.title || "Partner Brand"}
                    </h3>
                    {lead.budgetScope || lead.budgetTier ? (
                      <span className="text-xs font-mono font-bold text-[#C9A46A] bg-[#C9A46A]/10 px-2.5 py-0.5 rounded-lg border border-[#C9A46A]/20">
                        {lead.budgetScope || lead.budgetTier}
                      </span>
                    ) : null}
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
                    <span className="flex items-center gap-1.5 text-slate-200">
                      <Mail className="w-3.5 h-3.5 text-slate-400" />
                      <a href={`mailto:${lead.contactEmail || lead.email}`} className="hover:text-[#C9A46A] underline underline-offset-2">
                        {lead.contactEmail || lead.email || 'No email provided'}
                      </a>
                    </span>
                    {lead.targetedVertical || lead.nicheInterest ? (
                      <span className="text-slate-400">
                        Niche/Vertical: <strong className="text-slate-200">{lead.targetedVertical || lead.nicheInterest}</strong>
                      </span>
                    ) : null}
                  </div>

                  <p className="text-xs text-slate-300 bg-black/25 p-3 rounded-xl border border-white/5 leading-relaxed italic">
                    "{lead.campaignNotes || lead.campaignGoals || lead.message || 'No specific inquiry notes provided.'}"
                  </p>
                </div>

                <div className="flex items-center gap-2.5 shrink-0 self-end lg:self-center w-full lg:w-auto justify-end pt-3 lg:pt-0 border-t lg:border-t-0 border-white/5 flex-wrap">
                  {!isBlocked && leadStatus !== 'Reviewed' && leadStatus !== 'Converted to Deal' && (
                    <button
                      onClick={() => handleMarkReviewed(lead)}
                      className="px-3.5 py-2 bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border border-sky-500/30 rounded-xl text-xs font-mono font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Mark Reviewed
                    </button>
                  )}

                  {!isBlocked && (
                    <button
                      onClick={() => handleSyncToCrm(lead)}
                      className="px-3.5 py-2 bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-xl text-xs font-mono font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Briefcase className="w-3.5 h-3.5" /> Sync to CRM
                    </button>
                  )}

                  {!isBlocked && (
                    <button
                      onClick={() => handleConvertToDeal(lead)}
                      className="px-4 py-2 bg-[#C9A46A] hover:bg-[#D4B278] text-slate-950 rounded-xl text-xs font-mono font-bold transition-colors flex items-center gap-1.5 shadow cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" /> Convert to Deal <ArrowRight className="w-3 h-3" />
                    </button>
                  )}

                  {/* Block / Ban Button */}
                  {isBlocked ? (
                    <button
                      onClick={() => onNavigate?.('brand-blacklist')}
                      className="px-3.5 py-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-mono font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                      title="View in Agency Brand Blacklist"
                    >
                      <ShieldAlert className="w-3.5 h-3.5 text-rose-400" /> Blacklisted
                    </button>
                  ) : (
                    <button
                      onClick={() => handleBlockAndBanLead(lead)}
                      className="px-3.5 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-mono font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                      title="Block & Ban Brand from Agency Network"
                    >
                      <ShieldAlert className="w-3.5 h-3.5 text-rose-400" /> Block / Ban
                    </button>
                  )}

                  <button
                    onClick={() => handleDeleteLead(lead)}
                    title="Delete Lead"
                    className="p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-xl transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
