import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Search, X, Users, Layers, DollarSign, FileText, Compass, ArrowRight, CornerDownLeft } from 'lucide-react';
import { Creator, Deal } from '../types';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (screenId: string) => void;
  onSelectCreator?: (creator: Creator) => void;
  creators?: Creator[];
  campaigns?: any[];
  deals?: Deal[];
  invoices?: any[];
  currentRole?: string;
  primaryBrandColor?: string;
}

interface PaletteItem {
  id: string;
  type: 'navigation' | 'creator' | 'campaign' | 'deal' | 'invoice';
  title: string;
  subtitle?: string;
  badge?: string;
  action: () => void;
  keywords?: string;
}

export default function CommandPalette({
  isOpen,
  onClose,
  onNavigate,
  onSelectCreator,
  creators = [],
  campaigns = [],
  deals = [],
  invoices = [],
  currentRole = 'director',
  primaryBrandColor = '#C9A46A',
}: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Available Screens / Navigation Hubs
  const navigationItems = useMemo<PaletteItem[]>(() => {
    const screens = [
      { id: 'briefing', title: 'Daily Briefing', subtitle: 'Command & Operations Overview', badge: 'Hub' },
      { id: 'director-dash', title: 'Director Dashboard', subtitle: 'KPIs, Financials & Analytics', badge: 'Executive' },
      { id: 'roster', title: 'Creator Roster', subtitle: 'Manage Signed Talent & Metrics', badge: 'Talent' },
      { id: 'campaign-board', title: 'Campaign Board', subtitle: 'Pipeline & Deliverable Stages', badge: 'Campaigns' },
      { id: 'content-review', title: 'Content Review & QA', subtitle: 'Approve & Verify Brand Drafts', badge: 'Review' },
      { id: 'invoicing', title: 'Invoicing & Receivables', subtitle: 'Client Billing & Escrow Clearances', badge: 'Finance' },
      { id: 'media-kits', title: 'Dynamic Media Kits', subtitle: 'Creator Stats & Rate Cards', badge: 'Talent' },
      { id: 'public-portfolio', title: 'Public Creator Portfolio', subtitle: 'Shareable Creator Portfolio & Rate Cards', badge: 'Public' },
      { id: 'talent-showcase', title: 'Talent Showcase & Roster', subtitle: 'Interactive Public Creator Cards & Brand Discovery', badge: 'Public' },
      { id: 'agency-vsl-hero', title: 'Agency Pitch (VSL)', subtitle: 'Public Video Presentation & Brand Application', badge: 'Public' },
      { id: 'pod-invite-signup', title: 'Pod Application Page', subtitle: 'Public Talent Application & Creator Onboarding', badge: 'Public' },
      { id: 'open-marketplace', title: 'Open Marketplace', subtitle: 'Brand Casting & Sponsorship Briefs', badge: 'Marketplace' },
      { id: 'chat', title: 'Encrypted Studio Chat', subtitle: 'Staff & Creator Direct Comms', badge: 'Comms' },
      { id: 'brand-crm', title: 'Brand Partner CRM', subtitle: 'Client Directory & Deal Pipeline', badge: 'Partners' },
      { id: 'historical-vault', title: 'Historical Campaign Vault', subtitle: 'Archived Contracts & Past Deliverables', badge: 'Vault' },
      { id: 'system-audit-log', title: 'System Audit Log', subtitle: 'Security & Activity Monitoring', badge: 'Security' },
      { id: 'pod-configuration', title: 'Pod Configuration', subtitle: 'Multi-Tenant Desk Management', badge: 'System' },
    ];

    return screens.map((s) => ({
      id: `screen_${s.id}`,
      type: 'navigation',
      title: s.title,
      subtitle: s.subtitle,
      badge: s.badge,
      keywords: `${s.title} ${s.subtitle} screen page hub`,
      action: () => {
        onNavigate(s.id);
        onClose();
      },
    }));
  }, [onNavigate, onClose]);

  // Creator Items
  const creatorItems = useMemo<PaletteItem[]>(() => {
    return (creators || []).slice(0, 30).map((c) => ({
      id: `creator_${c.id}`,
      type: 'creator',
      title: c.name || c.handle,
      subtitle: `${c.handle} • ${c.niche || 'Creator'} • ${c.followers || '0'} followers`,
      badge: c.status || 'Active',
      keywords: `${c.name} ${c.handle} ${c.niche} creator talent`,
      action: () => {
        if (onSelectCreator) {
          onSelectCreator(c);
        } else {
          onNavigate('roster');
        }
        onClose();
      },
    }));
  }, [creators, onSelectCreator, onNavigate, onClose]);

  // Campaign Items
  const campaignItems = useMemo<PaletteItem[]>(() => {
    return (campaigns || []).slice(0, 20).map((camp: any) => ({
      id: `camp_${camp.id}`,
      type: 'campaign',
      title: camp.title || camp.name || 'Campaign',
      subtitle: `${camp.brand || 'Brand Partner'} • $${(camp.value || camp.budget || 0).toLocaleString()} • ${camp.stage || 'In Flight'}`,
      badge: camp.stage || 'Campaign',
      keywords: `${camp.title} ${camp.brand} ${camp.stage} campaign`,
      action: () => {
        onNavigate('campaign-board');
        onClose();
      },
    }));
  }, [campaigns, onNavigate, onClose]);

  // Invoice Items
  const invoiceItems = useMemo<PaletteItem[]>(() => {
    return (invoices || []).slice(0, 20).map((inv: any) => ({
      id: `inv_${inv.id}`,
      type: 'invoice',
      title: `${inv.number || 'INV'} • ${inv.client || inv.brand || 'Client'}`,
      subtitle: `$${(inv.amount || 0).toLocaleString()} • Status: ${inv.status || 'Pending'}`,
      badge: inv.status || 'Invoice',
      keywords: `${inv.number} ${inv.client} ${inv.brand} ${inv.status} invoice bill`,
      action: () => {
        onNavigate('invoicing');
        onClose();
      },
    }));
  }, [invoices, onNavigate, onClose]);

  // Combined and filtered results
  const filteredItems = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      // Default: Return key navigation hubs and recent items
      return [...navigationItems.slice(0, 6), ...creatorItems.slice(0, 4), ...campaignItems.slice(0, 3)];
    }

    const all = [...navigationItems, ...creatorItems, ...campaignItems, ...invoiceItems];
    return all
      .filter((item) => {
        const text = `${item.title} ${item.subtitle || ''} ${item.keywords || ''}`.toLowerCase();
        return text.includes(q);
      })
      .slice(0, 12);
  }, [query, navigationItems, creatorItems, campaignItems, invoiceItems]);

  // Keyboard navigation & focus
  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < filteredItems.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : filteredItems.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const current = filteredItems[selectedIndex];
      if (current) {
        current.action();
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  const getItemIcon = (type: PaletteItem['type']) => {
    switch (type) {
      case 'navigation':
        return <Compass className="w-4 h-4 text-[#C9A46A]" />;
      case 'creator':
        return <Users className="w-4 h-4 text-cyan-400" />;
      case 'campaign':
        return <Layers className="w-4 h-4 text-emerald-400" />;
      case 'invoice':
        return <DollarSign className="w-4 h-4 text-amber-400" />;
      default:
        return <FileText className="w-4 h-4 text-slate-400" />;
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="global-command-palette-backdrop"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-16 sm:pt-24 px-4 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        id="global-command-palette-modal"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
        className="w-full max-w-2xl bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-150"
      >
        {/* Search Input Header */}
        <div className="flex items-center px-4 py-3.5 border-b border-white/10 bg-[#111E33]/70 gap-3">
          <Search className="w-5 h-5 text-[#C9A46A] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            id="command-palette-input"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search hubs, creators, campaigns, invoices, or type a command..."
            className="flex-1 bg-transparent text-sm text-white placeholder-slate-400 focus:outline-none font-sans"
            autoComplete="off"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="text-slate-400 hover:text-white p-1 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/10 shrink-0 hidden sm:inline-block">
            ESC to close
          </span>
        </div>

        {/* Results List */}
        <div
          ref={listRef}
          className="max-h-[60vh] overflow-y-auto p-2 space-y-1 custom-scrollbar"
        >
          {filteredItems.length === 0 ? (
            <div className="py-10 text-center text-slate-400 text-xs">
              <Search className="w-8 h-8 mx-auto text-slate-600 mb-2 opacity-50" />
              No results found for <span className="text-white font-semibold">"{query}"</span>
            </div>
          ) : (
            filteredItems.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  id={`palette-item-${item.id}`}
                  onClick={item.action}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#C9A46A]/15 border border-[#C9A46A]/40 text-white shadow-sm'
                      : 'hover:bg-white/5 border border-transparent text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`p-2 rounded-lg shrink-0 ${
                        isSelected ? 'bg-[#C9A46A]/20' : 'bg-white/5'
                      }`}
                    >
                      {getItemIcon(item.type)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white truncate">
                          {item.title}
                        </span>
                        {item.badge && (
                          <span className="text-[9px] uppercase font-mono font-bold px-1.5 py-0.2 rounded bg-white/5 border border-white/10 text-slate-300 shrink-0">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      {item.subtitle && (
                        <p className="text-[11px] text-slate-400 truncate mt-0.5 font-sans">
                          {item.subtitle}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    {isSelected && (
                      <span className="text-[10px] font-mono text-[#C9A46A] flex items-center gap-1">
                        Select <CornerDownLeft className="w-3 h-3" />
                      </span>
                    )}
                    <ArrowRight
                      className={`w-4 h-4 transition-transform ${
                        isSelected ? 'text-[#C9A46A] translate-x-0.5' : 'text-slate-600'
                      }`}
                    />
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Footer Navigation Hints */}
        <div className="px-4 py-2.5 bg-[#091120] border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400 font-mono">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Open</span>
            <span>ESC Close</span>
          </div>
          <span className="text-[#C9A46A] font-semibold">Bloom Studio Quick Search</span>
        </div>
      </div>
    </div>
  );
}
