import React, { useState, useRef, useEffect } from 'react';
import { getSafeUrl } from '../utils/security';
import { 
  Building2, 
  Sparkles, 
  Download, 
  ShieldCheck, 
  CheckCircle2, 
  Play, 
  Video, 
  Layers, 
  Tag, 
  TrendingUp, 
  Users, 
  Eye, 
  Award,
  Instagram,
  Youtube,
  FileText,
  X,
  Upload,
  Plus,
  Lock
} from 'lucide-react';
import PortfolioContactFooter from './PortfolioContactFooter';
import { exportWhitePaperMediaKitPDF, WhitePaperMediaKitData } from '../utils/pdfExportUtils';

export interface CreatorPortfolioProfile {
  id: string;
  _realHandle?: string;
  name: string;
  handle: string;
  avatar: string;
  platform: 'Instagram' | 'TikTok' | 'YouTube' | string;
  niche: 'Beauty' | 'Pets' | 'Lifestyle' | string;
  totalReach: string;
  avgVelocity: string;
  engagementRate: string;
  bio: string;
  // Dynamic parameters by vertical
  nicheParameters: Array<{ label: string; value: string }>;
  topUgcShorts: Array<{
    id: string;
    title: string;
    views: string;
    format: string;
    thumbnail: string;
    videoUrl?: string;
    tags: string[];
  }>;
}

const DEFAULT_PROFILE: CreatorPortfolioProfile = {
  id: "creator_elena_01",
  name: "Elena Rostova",
  handle: "@elenarostova",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
  platform: "Instagram",
  niche: "Beauty",
  totalReach: "485,000",
  avgVelocity: "142,500",
  engagementRate: "5.8%",
  bio: "Luxury skincare and cosmetic efficacy creator specializing in high-definition macro texture demonstrations and dermatologist-vetted ingredient breakdowns.",
  nicheParameters: [
    { label: "Skin Matrix", value: "Combination / Sensitive (Fitzpatrick II)" },
    { label: "Hair Profile", value: "Type 2B Wavy / Color-Treated" },
    { label: "Content Aesthetic", value: "Natural Golden Hour (5600K Clean Lighting)" },
    { label: "Demographics", value: "84% Female • Ages 22-34 (US & UK Priority)" }
  ],
  topUgcShorts: [
    {
      id: "ugc_01",
      title: "Peptide Barrier Restoration 4K Routine",
      views: "385K views",
      format: "9:16 Vertical UHD",
      thumbnail: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=500&auto=format&fit=crop&q=80",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
      tags: ["Skincare Demo", "4K Macro", "FTC Cleared"]
    },
    {
      id: "ugc_02",
      title: "Hydrating Tinted Serum Wear Test & Efficacy",
      views: "294K views",
      format: "9:16 Vertical UHD",
      thumbnail: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&auto=format&fit=crop&q=80",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      tags: ["Cosmetic Efficacy", "Texture Shot", "Ad Whitelisted"]
    },
    {
      id: "ugc_03",
      title: "Ceramide Night Treatment Application & Review",
      views: "210K views",
      format: "9:16 Vertical UHD",
      thumbnail: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=500&auto=format&fit=crop&q=80",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
      tags: ["Night Routine", "Ingredient Breakdown", "UGC Asset"]
    }
  ]
};

interface DynamicCreatorMediaKitProps {
  key?: any;
  profile?: CreatorPortfolioProfile;
  className?: string;
  viewState?: 'Director' | 'Agent' | 'Public';
  currentRole?: string;
  isBrandShare?: boolean;
}

export default function DynamicCreatorMediaKit({
  profile: initialProfile = DEFAULT_PROFILE,
  className = "",
  viewState = 'Director',
  currentRole = 'Director',
  isBrandShare = false
}: DynamicCreatorMediaKitProps) {
  const [profile, setProfile] = useState<CreatorPortfolioProfile>(initialProfile);
  const [activeVideoModal, setActiveVideoModal] = useState<string | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const roleLower = (currentRole || '').toLowerCase();
  const isDirector = roleLower === 'director' || roleLower === 'owner' || roleLower === 'agency';
  const isCreator = roleLower === 'creator';
  const isStaff = ['agent', 'coordinator', 'agentmgr'].includes(roleLower);
  const isBrand = roleLower === 'brand' || isBrandShare;

  const canDownloadWhitePaper = (isDirector || isCreator) && !isBrandShare;
  const canUploadVideoReel = (isDirector || isCreator) && !isBrandShare;
  const canUploadAvatar = (isDirector || isCreator) && !isBrandShare;

  // Avatar upload
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setProfile(prev => ({ ...prev, avatar: url }));
  };

  // Video upload modal state
  const [isVideoUploadOpen, setIsVideoUploadOpen] = useState(false);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const [newVideoForm, setNewVideoForm] = useState({
    title: '',
    views: '150K views',
    tags: 'UGC Demo, Skincare',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&auto=format&fit=crop&q=80'
  });

  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setNewVideoForm(prev => ({ ...prev, videoUrl: url }));
  };

  const handleAddVideoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVideoForm.title.trim()) {
      alert('Please enter a video title.');
      return;
    }

    const createdVideo = {
      id: 'ugc_' + Date.now(),
      title: newVideoForm.title,
      views: newVideoForm.views,
      format: '9:16 Vertical UHD',
      thumbnail: newVideoForm.thumbnail,
      videoUrl: newVideoForm.videoUrl,
      tags: newVideoForm.tags.split(',').map(t => t.trim()).filter(Boolean)
    };

    setProfile(prev => ({
      ...prev,
      topUgcShorts: [createdVideo, ...prev.topUgcShorts]
    }));

    setIsVideoUploadOpen(false);
    setNewVideoForm({
      title: '',
      views: '150K views',
      tags: 'UGC Demo, Skincare',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      thumbnail: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&auto=format&fit=crop&q=80'
    });
  };

  const handleDownloadWhitePaperPDF = async () => {
    setIsExportingPdf(true);
    try {
      const exportData: WhitePaperMediaKitData = {
        creatorName: profile.name,
        creatorHandle: profile.handle,
        niche: profile.niche,
        totalReach: profile.totalReach,
        avgViews: profile.avgVelocity,
        engagementRate: profile.engagementRate,
        avatarUrl: profile.avatar,
        bio: profile.bio,
        agencyName: "CLOONEY & CO. TALENT MANAGEMENT",
        bookingEmail: "bookings@clooneyandco.com",
        nicheParams: profile.nicheParameters,
        topDeliverables: profile.topUgcShorts.map(s => ({
          title: s.title,
          views: s.views,
          format: s.format
        }))
      };

      await exportWhitePaperMediaKitPDF(exportData);
    } catch (err) {
      console.error('PDF export failed:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className={`w-full max-w-full overflow-x-hidden bg-agency-navy font-sans text-agency-textLight space-y-6 sm:space-y-10 animate-fadeIn ${className}`}>
      
      {/* 1. Executive Branding Header Card */}
      <div className="bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-5 sm:p-7 md:p-10 shadow-2xl relative overflow-hidden w-full max-w-full">
        {/* Subtle Ambient Gold Gradient */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-agency-gold/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 sm:gap-8 relative z-10 w-full">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 sm:gap-6 min-w-0 w-full lg:w-auto">
            <div className="relative group shrink-0">
              <img 
                src={profile.avatar} 
                alt={profile.name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 sm:w-28 sm:h-28 rounded-3xl object-cover border-2 border-agency-gold/60 shadow-xl"
              />
              <span className="absolute -bottom-2 -right-2 bg-agency-gold text-agency-navy text-[10px] font-mono font-bold px-2 py-0.5 rounded-full uppercase border border-agency-navy">
                Verified
              </span>

              {/* Upload Picture Overlay Button - Restricted to Director and Creator */}
              {canUploadAvatar && (
                <>
                  <input 
                    type="file" 
                    ref={avatarInputRef} 
                    onChange={handleAvatarFileChange} 
                    accept="image/*" 
                    className="hidden" 
                  />
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    className="absolute inset-0 rounded-3xl bg-black/60 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center gap-1 text-white text-[10px] font-mono font-bold cursor-pointer border-2 border-agency-gold"
                    title="Upload Profile Picture"
                  >
                    <Upload className="w-5 h-5 text-agency-gold" />
                    <span>Upload Pic</span>
                  </button>
                </>
              )}
            </div>

            <div className="space-y-2 min-w-0 w-full flex-1">
              {/* Permanent Gold Sub-Badge */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-agency-gold/15 border border-agency-gold text-agency-gold text-xs font-mono font-bold uppercase tracking-wider max-w-full">
                <Building2 className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Represented Exclusively by Bloom & Co.</span>
              </div>

              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-white tracking-wide break-normal whitespace-normal">
                {profile.name}
              </h1>

              <p className="text-xs sm:text-sm font-mono text-slate-300 flex items-center gap-2 flex-wrap">
                <span className="text-agency-gold font-bold">{profile.handle}</span>
                <span>•</span>
                <span className="bg-white/10 px-2 py-0.5 rounded-md text-[11px] text-white">
                  {profile.niche} Vertical
                </span>
                <span>•</span>
                <span className="text-slate-400">{profile.platform}</span>
              </p>

              <p className="text-xs text-slate-300 font-sans max-w-xl leading-relaxed pt-1 break-normal whitespace-normal">
                {profile.bio}
              </p>
            </div>
          </div>

          {/* White Paper PDF Export Trigger Button & Brand Share Button */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center gap-3 w-full lg:w-auto shrink-0">
            {canDownloadWhitePaper ? (
              <button
                type="button"
                id="btn-download-whitepaper-mediakit"
                onClick={handleDownloadWhitePaperPDF}
                disabled={isExportingPdf}
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-agency-gold text-agency-navy text-xs font-mono font-bold uppercase tracking-wider hover:brightness-110 active:scale-[0.98] transition shadow-xl cursor-pointer disabled:opacity-50 shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>{isExportingPdf ? "Compiling PDF..." : "Download White Paper Kit"}</span>
              </button>
            ) : isBrand ? (
              <div className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-slate-900/90 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold uppercase tracking-wider shadow-lg shrink-0">
                <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Preview Mode (Download Locked)</span>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-slate-900/90 border border-rose-500/40 text-rose-300 text-xs font-mono font-bold uppercase tracking-wider shadow-lg shrink-0">
                <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                <span>Download Restricted</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. Audience Analytics Grid (3 Columns) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 w-full">
        {/* Box 1: Total Reach */}
        <div className="bg-agency-navyLight border border-agency-gold/20 rounded-3xl p-5 sm:p-6 shadow-xl flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-slate-400 text-xs font-mono uppercase tracking-wider mb-2">
              <Users className="w-4 h-4 text-agency-gold" />
              <span>Total Verified Reach</span>
            </div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-white">
              {profile.totalReach}
            </div>
            <span className="text-[11px] font-mono text-slate-400 mt-1 block">
              Followers across prime platforms
            </span>
          </div>
        </div>

        {/* Box 2: Video View Velocity */}
        <div className="bg-agency-navyLight border border-agency-gold/20 rounded-3xl p-5 sm:p-6 shadow-xl flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-slate-400 text-xs font-mono uppercase tracking-wider mb-2">
              <Eye className="w-4 h-4 text-cyan-400" />
              <span>Video View Velocity</span>
            </div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-white">
              {profile.avgVelocity}
            </div>
            <span className="text-[11px] font-mono text-slate-400 mt-1 block">
              Average 30-day reel / video views
            </span>
          </div>
        </div>

        {/* Box 3: Audience Engagement Rate */}
        <div className="bg-agency-navyLight border border-agency-gold/20 rounded-3xl p-5 sm:p-6 shadow-xl flex items-center justify-between sm:col-span-2 lg:col-span-1">
          <div>
            <div className="flex items-center gap-2 text-slate-400 text-xs font-mono uppercase tracking-wider mb-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Audience Engagement Rate</span>
            </div>
            <div className="text-2xl sm:text-3xl font-mono font-bold text-emerald-400">
              {profile.engagementRate}
            </div>
            <span className="text-[11px] font-mono text-slate-400 mt-1 block">
              Audience interaction benchmark
            </span>
          </div>
        </div>
      </div>

      {/* 3. Niche Parameters Sheet & Trust Badges */}
      <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-5 sm:p-6 md:p-8 space-y-6 shadow-xl w-full max-w-full overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div>
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-agency-gold flex items-center gap-2">
              <Tag className="w-4 h-4" />
              <span>Niche Parameter Profile Matrix</span>
            </span>
            <h3 className="text-lg sm:text-xl font-serif font-bold text-white mt-0.5">
              Targeted Audience &amp; Aesthetic Benchmarks
            </h3>
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400 bg-agency-navy px-3 py-1.5 rounded-xl border border-white/10 shrink-0">
              Vertical: {profile.niche}
            </span>
          </div>
        </div>

        {/* Dynamic Tag Matrix Cloud */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 w-full">
          {profile.nicheParameters.map((param, index) => (
            <div 
              key={index}
              className="bg-agency-navy/90 border border-white/10 hover:border-agency-gold/40 transition rounded-2xl p-3.5 sm:p-4 space-y-1"
            >
              <span className="text-[10px] font-mono uppercase tracking-widest text-agency-gold block">
                {param.label}
              </span>
              <span className="text-xs font-semibold text-white block break-words">
                {param.value}
              </span>
            </div>
          ))}
        </div>

        {/* Trust Badges Bar */}
        <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl bg-agency-gold/15 border border-agency-gold shadow-sm">
              <ShieldCheck className="w-4 h-4 text-agency-gold shrink-0" />
              <span className="text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-agency-gold">
                100% FTC Compliance Registry Certified
              </span>
            </div>

            <div className="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl bg-emerald-500/15 border border-emerald-400 shadow-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="text-[11px] sm:text-xs font-mono font-bold uppercase tracking-wider text-emerald-300">
                Copyright Audio Secure & Whitelist Cleared
              </span>
            </div>
          </div>

          <span className="text-[11px] font-mono text-slate-400">
            Verified by Bloom Studio &amp; Bloom &amp; Co. Management
          </span>
        </div>
      </div>

      {/* 4. Vertical UGC Portfolio Grid (3 Columns) */}
      <div className="space-y-4 w-full">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-agency-gold flex items-center gap-2">
              <Video className="w-4 h-4" />
              <span>Production Portfolio Showcase</span>
            </span>
            <h3 className="text-lg sm:text-xl md:text-2xl font-serif font-bold text-white mt-0.5">
              Featured 9:16 Vertical UGC Deliverables
            </h3>
          </div>
          
          {canUploadVideoReel ? (
            <button
              type="button"
              onClick={() => setIsVideoUploadOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-mono font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-lg shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Upload Video Reel</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-slate-400 text-xs font-mono shrink-0">
              <Lock className="w-3.5 h-3.5 text-slate-500" />
              <span>Video Reel Uploads Restricted</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 w-full">
          {profile.topUgcShorts.map((short) => (
            <div 
              key={short.id}
              className="bg-agency-navyLight border border-agency-gold/20 hover:border-agency-gold/60 transition duration-300 rounded-3xl overflow-hidden shadow-2xl flex flex-col group"
            >
              {/* 9:16 Aspect Thumbnail Container */}
              <div className="relative aspect-[9/16] bg-black overflow-hidden">
                <img 
                  src={short.thumbnail} 
                  alt={short.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
                
                {/* Play Button Overlay */}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-90 group-hover:opacity-100 transition">
                  <button
                    type="button"
                    onClick={() => setActiveVideoModal(short.videoUrl || "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4")}
                    className="w-14 h-14 rounded-full bg-agency-gold text-agency-navy flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition cursor-pointer"
                  >
                    <Play className="w-6 h-6 fill-current ml-0.5" />
                  </button>
                </div>

                {/* Top Badge Overlay */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                  <span className="bg-agency-navy/90 text-agency-gold text-[10px] font-mono font-bold uppercase px-2.5 py-1 rounded-lg border border-agency-gold/30">
                    {short.format}
                  </span>
                  <span className="bg-black/80 text-white text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg">
                    {short.views}
                  </span>
                </div>
              </div>

              {/* Card Meta Description */}
              <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="text-sm font-serif font-bold text-white group-hover:text-agency-gold transition">
                    {short.title}
                  </h4>
                  <div className="flex flex-wrap gap-1.5 mt-2.5">
                    {short.tags.map((t, idx) => (
                      <span key={idx} className="bg-agency-navy text-slate-300 text-[10px] font-mono px-2 py-0.5 rounded-md border border-white/5">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span className="text-emerald-400 font-bold">✔ Whitelist Cleared</span>
                  <button
                    type="button"
                    onClick={() => setActiveVideoModal(short.videoUrl || "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4")}
                    className="text-agency-gold hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <span>Preview Reel</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Inbound Agency Call-To-Action Footer (Bloom & Co. Booking Desk) */}
      <PortfolioContactFooter 
        creatorHandle={profile.handle}
        creatorName={profile.name}
        defaultNiche={profile.niche}
      />

      {/* 9:16 Video Player Modal */}
      {activeVideoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
          <div 
            className="bg-agency-navyLight border border-agency-gold/40 rounded-3xl p-3 sm:p-4 max-w-xs sm:max-w-sm w-full shadow-2xl relative max-h-[90dvh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setActiveVideoModal(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/60 text-white hover:bg-black transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="aspect-[9/16] rounded-2xl overflow-hidden bg-black relative">
              <video 
                src={activeVideoModal}
                controls
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-3 text-center">
              <p className="text-xs font-mono text-agency-gold">
                4K Master UGC Showcase • Bloom & Co. Exclusivity
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Video Reel Upload Modal */}
      {isVideoUploadOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-[#0b1320] border border-agency-gold/40 rounded-3xl max-w-md w-full p-4 sm:p-6 space-y-4 shadow-2xl text-left max-h-[90dvh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base sm:text-lg font-serif font-bold text-white flex items-center gap-2">
                <Video className="w-5 h-5 text-agency-gold shrink-0" />
                <span>Upload Sample UGC Video Reel</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsVideoUploadOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddVideoSubmit} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Reel Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Morning Glow Serum Demo 4K"
                  value={newVideoForm.title}
                  onChange={e => setNewVideoForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-agency-gold"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Upload Video File (.MP4)</label>
                <input
                  type="file"
                  ref={videoInputRef}
                  onChange={handleVideoFileChange}
                  accept="video/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => videoInputRef.current?.click()}
                  className="w-full py-2.5 px-3 bg-agency-gold/15 hover:bg-agency-gold/25 border border-agency-gold/40 text-agency-gold rounded-xl font-mono text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-agency-gold" />
                  <span>Select Video File From Device</span>
                </button>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Or Video URL (.mp4)</label>
                <input
                  type="text"
                  value={newVideoForm.videoUrl}
                  onChange={e => setNewVideoForm(prev => ({ ...prev, videoUrl: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-agency-gold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Views Metric</label>
                  <input
                    type="text"
                    value={newVideoForm.views}
                    onChange={e => setNewVideoForm(prev => ({ ...prev, views: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-agency-gold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={newVideoForm.tags}
                    onChange={e => setNewVideoForm(prev => ({ ...prev, tags: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-agency-gold"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsVideoUploadOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg"
                >
                  Add Video To Portfolio
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
