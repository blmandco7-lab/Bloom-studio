import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  Send, 
  ShieldCheck, 
  Play, 
  Sparkles, 
  FileText,
  ThumbsUp,
  MessageSquare
} from 'lucide-react';

interface BrandReviewConsoleProps {
  campaignName?: string;
  creatorHandle?: string;
  draftVideoUrl?: string;
  captionDraft?: string;
  initialHoursRemaining?: number;
  onApprove?: () => void;
  onSubmitRevisions?: (feedback: BrandReviewFeedback) => void;
}

export interface BrandReviewFeedback {
  lightingAndStylingPass: boolean;
  ftcDisclosuresPass: boolean;
  timestampRevisions: string;
  additionalFeedback: string;
  submittedAt: string;
}

export default function BrandReviewConsole({
  campaignName = "Lumina Skin Barrier Serum Launch",
  creatorHandle = "@olivia.glows",
  draftVideoUrl,
  captionDraft = "Transforming my night routine with the new @LuminaBeauty Barrier Serum ✨ #ad #LuminaSkin #CleanBeauty (link in bio!)",
  initialHoursRemaining = 48,
  onApprove,
  onSubmitRevisions
}: BrandReviewConsoleProps) {
  // Video upload state: Timer ONLY starts when video is uploaded!
  const [currentVideoUrl, setCurrentVideoUrl] = useState<string | null>(draftVideoUrl || null);
  const [videoUploaded, setVideoUploaded] = useState<boolean>(Boolean(draftVideoUrl));
  const [videoFileName, setVideoFileName] = useState<string>(draftVideoUrl ? "creator_draft_deliverable.mp4" : "");

  // 48-Hour Countdown Timer State
  const [secondsRemaining, setSecondsRemaining] = useState(initialHoursRemaining * 3600);
  const [isApproved, setIsApproved] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    if (!videoUploaded) return; // Do NOT run timer if video is not uploaded yet!

    const interval = setInterval(() => {
      setSecondsRemaining(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [videoUploaded]);

  const hours = Math.floor(secondsRemaining / 3600);
  const minutes = Math.floor((secondsRemaining % 3600) / 60);
  const seconds = secondsRemaining % 60;

  const [lightingPass, setLightingPass] = useState(true);
  const [ftcPass, setFtcPass] = useState(true);
  const [timestampRevisions, setTimestampRevisions] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCurrentVideoUrl(url);
      setVideoFileName(file.name);
      setVideoUploaded(true);
      setSecondsRemaining(48 * 3600); // Reset / Start 48-hour timer on upload
    }
  };

  const handleSimulateVideoUpload = () => {
    setCurrentVideoUrl("https://assets.mixkit.co/videos/preview/mixkit-woman-applying-a-face-cream-41557-large.mp4");
    setVideoFileName("Lumina_Serum_UGC_Draft_v1.mp4");
    setVideoUploaded(true);
    setSecondsRemaining(48 * 3600);
  };

  const handleApprove = () => {
    setIsApproved(true);
    if (onApprove) onApprove();
  };

  const handleRevisions = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    if (onSubmitRevisions) {
      onSubmitRevisions({
        lightingAndStylingPass: lightingPass,
        ftcDisclosuresPass: ftcPass,
        timestampRevisions,
        additionalFeedback: additionalNotes,
        submittedAt: new Date().toISOString()
      });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 font-sans text-agency-textLight animate-fadeIn">
      {/* 2-Day Countdown Clock Banner */}
      <div className="bg-agency-navyLight border border-agency-gold/40 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-wider">
              <Clock className="w-4 h-4 animate-pulse" />
              <span>Active Review Window Remaining</span>
            </div>
            <h3 className="text-xl md:text-2xl font-serif font-bold text-white">
              Campaign Content Draft Review: {campaignName}
            </h3>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              In alignment with Bloom Studio policy, your brand has a strict 2-business-day window to request revisions before the content draft is locked for production schedules.
            </p>
          </div>

          {/* Clock Display */}
          <div className="bg-agency-navy border border-agency-gold/30 px-5 py-3 rounded-2xl text-center shrink-0">
            {videoUploaded ? (
              <>
                <div className="font-mono text-2xl md:text-3xl font-bold text-agency-gold tracking-widest">
                  {String(hours).padStart(2, '0')}:{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </div>
                <div className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest mt-0.5 flex items-center justify-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Active 48h Window
                </div>
              </>
            ) : (
              <>
                <div className="font-mono text-2xl md:text-3xl font-bold text-slate-400 tracking-widest">
                  48:00:00
                </div>
                <div className="text-[10px] font-mono text-amber-400 uppercase tracking-widest mt-0.5">
                  Awaiting Video Upload
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {isApproved ? (
        <div className="bg-emerald-950/40 border border-emerald-500/50 rounded-3xl p-8 text-center space-y-4 shadow-xl">
          <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h4 className="text-xl font-serif font-bold text-white">Draft Approved for Live Release!</h4>
          <p className="text-xs text-slate-300 max-w-md mx-auto">
            The creator ({creatorHandle}) and logistics manager have been notified. The content asset is locked and scheduled for live platform release.
          </p>
        </div>
      ) : isSubmitted ? (
        <div className="bg-agency-navyLight border border-agency-gold/40 rounded-3xl p-8 text-center space-y-4 shadow-xl">
          <div className="w-14 h-14 bg-agency-gold/20 text-agency-gold rounded-full flex items-center justify-center mx-auto border border-agency-gold/40">
            <Send className="w-7 h-7" />
          </div>
          <h4 className="text-xl font-serif font-bold text-white">Revision Request Dispatched</h4>
          <p className="text-xs text-slate-300 max-w-md mx-auto">
            Your detailed timestamps and notes have been delivered to Bloom Studio's Creative Agent &amp; {creatorHandle}. Creator revision turnaround is 24 hours.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Asset Preview & Caption Draft */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-5 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <span className="text-xs font-mono font-bold text-agency-gold uppercase">Talent Draft Asset</span>
                <span className="text-xs text-slate-300 font-medium">{creatorHandle}</span>
              </div>

              {/* Video Upload Control / Player */}
              {!videoUploaded ? (
                <div className="p-6 bg-agency-navy/90 border border-dashed border-agency-gold/40 rounded-2xl text-center space-y-3">
                  <div className="w-12 h-12 bg-agency-gold/10 text-agency-gold rounded-full flex items-center justify-center mx-auto border border-agency-gold/30">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="text-sm font-bold text-white font-serif">Upload Creator Video Deliverable</h5>
                    <p className="text-[11px] text-slate-400 mt-1">
                      The 48-hour brand review countdown timer will trigger as soon as a video file is attached.
                    </p>
                  </div>
                  
                  <div className="flex flex-col gap-2 pt-2">
                    <label className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs rounded-xl cursor-pointer transition">
                      <Send className="w-3.5 h-3.5" />
                      <span>Choose Video File</span>
                      <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" />
                    </label>

                    <button
                      type="button"
                      onClick={handleSimulateVideoUpload}
                      className="text-[11px] text-agency-gold/80 hover:text-agency-gold underline font-mono cursor-pointer"
                    >
                      Attach Demo Creator Draft Video
                    </button>
                  </div>
                </div>
              ) : (
                <div className="aspect-[9/16] max-h-[380px] bg-slate-900 rounded-2xl border border-white/10 relative overflow-hidden flex flex-col justify-between p-4 group">
                  <div className="flex justify-between items-center text-[10px] font-mono text-white/80 bg-black/40 px-2.5 py-1 rounded-lg backdrop-blur-sm self-start">
                    <span>9:16 4K UHD</span>
                    <span className="ml-2 text-emerald-400">● 48h Timer Active</span>
                  </div>

                  {currentVideoUrl && currentVideoUrl.startsWith("blob:") ? (
                    <video src={currentVideoUrl} controls className="w-full h-full object-cover rounded-xl" />
                  ) : (
                    <div className="text-center py-12">
                      <div className="w-14 h-14 bg-agency-gold/80 hover:bg-agency-gold text-agency-navy rounded-full flex items-center justify-center mx-auto shadow-xl transition cursor-pointer scale-100 group-hover:scale-105">
                        <Play className="w-6 h-6 ml-1 fill-agency-navy" />
                      </div>
                      <div className="text-xs text-white mt-3 font-semibold">Play Creator Draft ({videoFileName || "0:48"})</div>
                    </div>
                  )}

                  <div className="bg-black/60 backdrop-blur-md p-3 rounded-xl border border-white/10 text-left space-y-1">
                    <div className="text-[10px] font-mono text-agency-gold font-bold">Caption &amp; Hashtag Draft:</div>
                    <p className="text-xs text-slate-200 line-clamp-2 leading-relaxed">{captionDraft}</p>
                  </div>
                </div>
              )}

              {/* Compliance Marker */}
              <div className="p-3 bg-agency-navy rounded-xl border border-white/5 flex items-center gap-2.5 text-xs text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Pre-scanned for 100% FTC compliance disclosure at caption origin.</span>
              </div>
            </div>
          </div>

          {/* Right Column: Upgraded Feedback Survey Form */}
          <div className="lg:col-span-7 space-y-4">
            <form onSubmit={handleRevisions} className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl space-y-5">
              <div className="border-b border-white/10 pb-3">
                <h4 className="text-base font-serif font-bold text-white">Brand Quality &amp; Compliance Survey</h4>
                <p className="text-xs text-slate-400">Verify brand alignment or provide direct timestamp modifications.</p>
              </div>

              {/* Check 1: Lighting & Styling */}
              <div className="p-4 bg-agency-navy rounded-2xl border border-white/5 space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-bold text-white">
                    1. Visual &amp; Aesthetic Guidelines
                  </span>
                  <input
                    type="checkbox"
                    checked={lightingPass}
                    onChange={e => setLightingPass(e.target.checked)}
                    className="w-4 h-4 text-agency-gold rounded focus:ring-agency-gold cursor-pointer"
                  />
                </label>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  "Does the draft match your required lighting, tone, and product presentation styling (Beauty / Lifestyle / Pet)?"
                </p>
              </div>

              {/* Check 2: FTC Compliance */}
              <div className="p-4 bg-agency-navy rounded-2xl border border-white/5 space-y-2">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-xs font-bold text-white">
                    2. FTC &amp; Regulatory Disclosures
                  </span>
                  <input
                    type="checkbox"
                    checked={ftcPass}
                    onChange={e => setFtcPass(e.target.checked)}
                    className="w-4 h-4 text-agency-gold rounded focus:ring-agency-gold cursor-pointer"
                  />
                </label>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  "Are the caption disclosures (#ad, #sponsored) properly positioned before any text truncation?"
                </p>
              </div>

              {/* Timestamps & Revision Notes */}
              <div>
                <label className="block text-xs font-bold font-mono uppercase tracking-wider text-agency-gold mb-1.5">
                  Timestamp Notes &amp; Audio/Visual Revisions
                </label>
                <textarea
                  rows={3}
                  value={timestampRevisions}
                  onChange={e => setTimestampRevisions(e.target.value)}
                  placeholder="e.g. 0:12 - Please zoom in closer on the product application texture. 0:34 - Mention the 24-hour hydration claim clearly..."
                  className="w-full bg-agency-navy border border-white/10 rounded-2xl px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold transition resize-none font-sans"
                />
              </div>

              {/* Actions */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                <button
                  type="submit"
                  className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider transition shadow-lg cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Submit Revisions &amp; Request Edit</span>
                </button>

                <button
                  type="button"
                  onClick={handleApprove}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs uppercase tracking-wider transition shadow-lg cursor-pointer"
                >
                  <ThumbsUp className="w-4 h-4" />
                  <span>Approve Draft for Live Release</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
