import React, { useState, useMemo } from 'react';
import { 
  Users, Link as LinkIcon, DollarSign, Award, Plus, CheckCircle2, 
  Copy, Check, FileText, Send, Sparkles, X, ShieldCheck, Edit3, Save, 
  UserCheck, AlertCircle, Calendar, ArrowUpRight, HelpCircle
} from 'lucide-react';
import { Referral } from '../types';

interface CreatorReferralNetworkProps {
  currentRole?: string;
  currentUser?: any;
  referrals?: Referral[];
  onAddReferral?: (newRef: Referral) => void;
  onUpdateReferral?: (updatedRef: Referral) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}

const DEFAULT_SAMPLE_REFERRALS: Referral[] = [
  {
    id: 'ref_sample_01',
    referrer: '@elenarostova',
    referrerName: 'Elena Rostova',
    type: 'Creator',
    what: 'Beauty & Skincare',
    newclient: 'Chloe Bennett (@chloeglows)',
    referredCreatorName: 'Chloe Bennett',
    referredCreatorHandle: '@chloeglows',
    value: 500,
    reward: 'Roster Referral',
    date: '2026-08-14',
    status: 'Paid',
    notes: 'Referred Chloe for summer skincare campaigns. Onboarded & signed.'
  },
  {
    id: 'ref_sample_02',
    referrer: '@kai_lifestyle',
    referrerName: 'Kai Lindqvist',
    type: 'Creator',
    what: 'Fitness & Lifestyle',
    newclient: 'Marcus Brody (@brody_wellness)',
    referredCreatorName: 'Marcus Brody',
    referredCreatorHandle: '@brody_wellness',
    value: 750,
    reward: '$750.00 Director Bonus',
    date: '2026-08-20',
    status: 'Approved',
    notes: 'Referred Marcus for fitness roster. Director set $750 bonus.'
  },
  {
    id: 'ref_sample_03',
    referrer: '@golden_leo',
    referrerName: 'Leo & Chloe',
    type: 'Creator',
    what: 'Pets & Animals',
    newclient: 'Maya Lin (@maya_pets)',
    referredCreatorName: 'Maya Lin',
    referredCreatorHandle: '@maya_pets',
    value: 350,
    reward: '$350.00 Director Bonus',
    date: '2026-09-01',
    status: 'Pending review',
    notes: 'Inbound referral awaiting final director bonus allocation.'
  }
];

export default function CreatorReferralNetwork({
  currentRole,
  currentUser,
  referrals = [],
  onAddReferral,
  onUpdateReferral,
  triggerNotification = () => {},
  onAddActivityLog = () => {}
}: CreatorReferralNetworkProps) {
  const isCreatorRole = currentRole === 'creator' || currentUser?.role === 'creator' || currentUser?.isCreator === true;
  const creatorHandle = currentUser?.handle || '@elenarostova';
  const creatorName = currentUser?.name || 'Elena Rostova';

  // Merge external referrals or fallback to sample
  const activeReferralsList = useMemo(() => {
    if (referrals && referrals.length > 0) return referrals;
    return DEFAULT_SAMPLE_REFERRALS;
  }, [referrals]);

  // Filters and UI states
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Pending review' | 'Approved' | 'Paid'>('all');
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [editingBonusId, setEditingBonusId] = useState<string | null>(null);
  const [bonusAmountInput, setBonusAmountInput] = useState<number>(500);

  // Form state for logging a new referral
  const [applicantName, setApplicantName] = useState('');
  const [applicantHandle, setApplicantHandle] = useState('');
  const [applicantEmail, setApplicantEmail] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [applicantNiche, setApplicantNiche] = useState('Beauty & Skincare');
  const [applicantReferrer, setApplicantReferrer] = useState(isCreatorRole ? creatorHandle : '@elenarostova');
  const [initialBonusAmount, setInitialBonusAmount] = useState<number>(500);
  const [applicantNotes, setApplicantNotes] = useState('');

  const globalReferralUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/#referrals?ref=${(creatorHandle || 'agency').replace('@', '')}`
    : `https://bloomstudio.agency/apply?ref=${(creatorHandle || 'agency').replace('@', '')}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(globalReferralUrl);
    setCopiedLink(true);
    triggerNotification('Link Copied!', 'Creator referral link copied to clipboard.', 'success');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Director updates referral bonus amount or status
  const handleSaveBonus = (ref: Referral, newBonus: number, newStatus?: 'Pending review' | 'Approved' | 'Paid') => {
    const updatedStatus = newStatus || ref.status;
    const updatedRef: Referral = {
      ...ref,
      value: newBonus,
      reward: `$${newBonus.toLocaleString()}.00 Director Bonus`,
      status: updatedStatus
    };

    if (onUpdateReferral) {
      onUpdateReferral(updatedRef);
    }

    setEditingBonusId(null);
    triggerNotification(
      'Director Bonus Updated',
      `Set referral bonus for ${ref.newclient} to $${newBonus.toLocaleString()} USD (${updatedStatus}).`,
      'success'
    );
    onAddActivityLog(
      currentUser?.name || 'Director',
      currentRole || 'director',
      `Director set referral bonus for ${ref.newclient} to $${newBonus} (${updatedStatus})`
    );
  };

  // Handle Form Submit for New Referral
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName.trim() || !applicantHandle.trim()) return;

    let handleClean = applicantHandle.trim();
    if (!handleClean.startsWith('@')) handleClean = `@${handleClean}`;

    let referrerClean = applicantReferrer.trim();
    if (!referrerClean.startsWith('@') && referrerClean.length > 0) referrerClean = `@${referrerClean}`;

    const newRef: Referral = {
      id: `ref_${Date.now()}`,
      referrer: referrerClean || creatorHandle,
      referrerName: referrerClean === creatorHandle ? creatorName : referrerClean,
      type: 'Creator',
      what: applicantNiche,
      newclient: `${applicantName.trim()} (${handleClean})`,
      referredCreatorName: applicantName.trim(),
      referredCreatorHandle: handleClean,
      value: Number(initialBonusAmount) || 500,
      reward: `$${(Number(initialBonusAmount) || 500).toLocaleString()}.00 Director Bonus`,
      date: new Date().toISOString().split('T')[0],
      status: isCreatorRole ? 'Pending review' : 'Approved',
      notes: applicantNotes.trim() ? `Email: ${applicantEmail}. Notes: ${applicantNotes}` : `Email: ${applicantEmail}`
    };

    if (onAddReferral) {
      onAddReferral(newRef);
    }

    setIsApplyModalOpen(false);
    triggerNotification(
      'Creator Referral Logged',
      `Referral for ${newRef.newclient} submitted (Director Bonus: $${newRef.value}).`,
      'success'
    );

    // Reset
    setApplicantName('');
    setApplicantHandle('');
    setApplicantEmail('');
    setApplicantNotes('');
  };

  // Filtered referrals list based on search and status
  const filteredReferrals = useMemo(() => {
    let list = activeReferralsList;

    if (isCreatorRole) {
      // Creator only sees referrals where they are the referrer
      const hLower = (creatorHandle || '').toLowerCase().replace('@', '');
      const nLower = (creatorName || '').toLowerCase();
      list = list.filter(r => {
        const refLower = (r.referrer || '').toLowerCase().replace('@', '');
        return refLower.includes(hLower) || (nLower && refLower.includes(nLower));
      });
    }

    if (statusFilter !== 'all') {
      list = list.filter(r => r.status === statusFilter);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      list = list.filter(r =>
        (r.referrer || '').toLowerCase().includes(q) ||
        (r.newclient || '').toLowerCase().includes(q) ||
        (r.what || '').toLowerCase().includes(q)
      );
    }

    return list;
  }, [activeReferralsList, isCreatorRole, creatorHandle, creatorName, statusFilter, searchTerm]);

  // Find who referred the current logged in creator (for creator view)
  const myReferrerRecord = useMemo(() => {
    if (!isCreatorRole) return null;
    const hLower = (creatorHandle || '').toLowerCase().replace('@', '');
    const nLower = (creatorName || '').toLowerCase();

    return activeReferralsList.find(r => {
      const clientLower = (r.newclient || '').toLowerCase();
      return clientLower.includes(hLower) || (nLower && clientLower.includes(nLower));
    });
  }, [isCreatorRole, activeReferralsList, creatorHandle, creatorName]);

  // Summary stats
  const totalApprovedBonus = useMemo(() => {
    return activeReferralsList
      .filter(r => r.status === 'Approved' || r.status === 'Paid')
      .reduce((sum, r) => sum + (r.value || 500), 0);
  }, [activeReferralsList]);

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto pb-12">
      {/* Header Banner */}
      <div className="relative bg-[#0B1B3D] border-2 border-[#C9A46A]/40 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-[0.2em] font-mono bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-1 rounded-full">
                {isCreatorRole ? 'Creator Affiliate & Referral Program' : 'Director Referral Control Center'}
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                <span>Live Engine</span>
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-2">
              {isCreatorRole ? 'Your Creator Referral Hub' : 'Creator Referral & Affiliate Network'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1.5 max-w-2xl leading-relaxed">
              {isCreatorRole
                ? 'Track who referred you, see the talent you recommended, and view the official Director-set bonus money assigned for every signed creator.'
                : 'Monitor creator-to-creator referral connections, set exact Director bonus payouts ($ USD), and manage onboarding bounties across the agency.'}
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setIsApplyModalOpen(true)}
              className="bg-gradient-to-r from-[#C9A46A] to-[#D4AF37] hover:brightness-110 text-[#0A1220] font-mono font-bold text-xs px-5 py-3 rounded-2xl uppercase tracking-wider transition cursor-pointer flex items-center gap-2 shadow-xl hover:scale-[1.02]"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>{isCreatorRole ? 'Refer a Creator' : 'Log Creator Referral'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* CREATOR VIEW: Who Referred You Banner */}
      {isCreatorRole && (
        <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl p-5 sm:p-6 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] font-bold shrink-0">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase font-bold text-[#C9A46A]">
                Your Roster Referral Origin
              </span>
              <h3 className="text-base font-serif font-bold text-white mt-0.5">
                {myReferrerRecord ? (
                  <>Referred to Bloom Studio by <span className="text-[#C9A46A]">{myReferrerRecord.referrerName || myReferrerRecord.referrer}</span></>
                ) : (
                  <>Direct Application / Organic Roster Onboarding</>
                )}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5 font-mono">
                {myReferrerRecord ? (
                  <>Date Referred: <strong>{myReferrerRecord.date}</strong></>
                ) : (
                  <>Signed to Bloom &amp; Co. Exclusive Roster.</>
                )}
              </p>
            </div>
          </div>

          <div className="shrink-0 bg-[#111E33] px-4 py-2.5 rounded-xl border border-white/10 text-right">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">Status</span>
            <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Verified Roster Talent
            </span>
          </div>
        </div>
      )}

      {/* DIRECTOR METRICS BAR (Director View) */}
      {!isCreatorRole && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-2 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400 uppercase font-bold">Total Referrals</span>
              <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <h3 className="text-2xl font-serif font-bold text-white">{activeReferralsList.length}</h3>
            <p className="text-[11px] text-slate-400">Tracked creator-to-creator referrals</p>
          </div>

          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-2 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400 uppercase font-bold">Director Bonus Pool</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <h3 className="text-2xl font-serif font-bold text-emerald-400">${totalApprovedBonus.toLocaleString()}</h3>
            <p className="text-[11px] text-slate-400">Approved &amp; cleared referral payouts</p>
          </div>

          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-2 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400 uppercase font-bold">Pending Review</span>
              <div className="w-8 h-8 rounded-xl bg-[#C9A46A]/20 text-[#C9A46A] flex items-center justify-center">
                <Award className="w-4 h-4" />
              </div>
            </div>
            <h3 className="text-2xl font-serif font-bold text-[#C9A46A]">
              {activeReferralsList.filter(r => r.status === 'Pending review').length}
            </h3>
            <p className="text-[11px] text-slate-400">Awaiting Director bonus determination</p>
          </div>
        </div>
      )}

      {/* Referral Link Quick Copy Card */}
      <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-3 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold font-mono text-white uppercase flex items-center gap-2">
            <LinkIcon className="w-4 h-4 text-[#C9A46A]" />
            <span>{isCreatorRole ? 'Your Creator Referral Link' : 'Agency Talent Application Link'}</span>
          </h3>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
            Active Tracking URL
          </span>
        </div>
        <p className="text-xs text-slate-300">
          {isCreatorRole
            ? 'Share your custom link with creators you recommend. Submissions list you as referrer so the Director can credit your bonus.'
            : 'Send this link to prospective talent or recruiting agents. Inbound referrals automatically show who recommended them.'}
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            readOnly
            value={globalReferralUrl}
            className="flex-1 bg-[#091122] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-emerald-400 font-mono outline-none select-all"
          />
          <button
            type="button"
            onClick={handleCopyLink}
            className="bg-[#C9A46A] hover:bg-[#EBD287] text-[#0A1220] px-5 py-2.5 rounded-xl text-xs font-bold font-mono uppercase tracking-wider transition shrink-0 flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copiedLink ? 'Link Copied!' : 'Copy Referral Link'}</span>
          </button>
        </div>
      </div>

      {/* REFERRALS LEDGER & DIRECTOR BONUS CONTROL CENTER */}
      <div className="bg-[#0D1830] border border-white/10 rounded-2xl overflow-hidden shadow-2xl space-y-0">
        {/* Table Header & Toolbar */}
        <div className="p-5 border-b border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold font-mono text-white uppercase flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#C9A46A]" />
              <span>
                {isCreatorRole ? 'Creators You Have Referred & Bonus Status' : 'Creator Referrals Ledger & Director Bonus Allocation'}
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isCreatorRole
                ? 'Showing who referred who, submission date, and the exact bonus money set by the Director.'
                : 'Directly edit the bonus money ($ USD) each referring creator will receive.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e: any) => setStatusFilter(e.target.value)}
              className="bg-[#111E33] border border-white/10 text-xs font-mono text-white rounded-xl px-3 py-2 outline-none cursor-pointer"
            >
              <option value="all">All Statuses</option>
              <option value="Pending review">Pending Review</option>
              <option value="Approved">Approved</option>
              <option value="Paid">Paid</option>
            </select>
          </div>
        </div>

        {/* Referrals List / Table */}
        {filteredReferrals.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <AlertCircle className="w-8 h-8 text-slate-500 mx-auto" />
            <h4 className="text-sm font-bold text-white font-serif">No Creator Referrals Found</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              {isCreatorRole
                ? 'You have not referred any creators yet. Share your referral link above to earn Director bonuses.'
                : 'No creator referrals match the selected filters.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="bg-[#111E33] text-slate-400 border-b border-white/10 text-[10px] uppercase tracking-wider">
                  <th className="py-3.5 px-5">Who Referred</th>
                  <th className="py-3.5 px-5">Creator Referred</th>
                  <th className="py-3.5 px-5">Date Referred</th>
                  {!isCreatorRole && <th className="py-3.5 px-5">Director Bonus Money ($ USD)</th>}
                  <th className="py-3.5 px-5 text-right">Status &amp; Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredReferrals.map((ref) => {
                  const isEditing = editingBonusId === ref.id;

                  return (
                    <tr key={ref.id} className="hover:bg-white/[0.02] transition-colors">
                      {/* Who Referred */}
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-xl bg-[#091122] border border-white/10 flex items-center justify-center font-bold font-serif text-[#C9A46A] text-xs shrink-0">
                            {(ref.referrerName || ref.referrer || 'C')[0]}
                          </div>
                          <div>
                            <p className="font-bold text-white text-sm font-sans">{ref.referrerName || ref.referrer}</p>
                            <span className="text-[11px] text-[#C9A46A]">{ref.referrer}</span>
                          </div>
                        </div>
                      </td>

                      {/* Creator Referred */}
                      <td className="py-4 px-5">
                        <div>
                          <p className="font-bold text-white text-sm font-sans">{ref.referredCreatorName || ref.newclient}</p>
                          <span className="text-[11px] text-slate-400 block">{ref.what || 'Creator Roster'}</span>
                        </div>
                      </td>

                      {/* Date Referred */}
                      <td className="py-4 px-5 text-slate-300">
                        <div className="flex items-center gap-1.5 text-xs text-slate-300">
                          <Calendar className="w-3.5 h-3.5 text-slate-500" />
                          <span>{ref.date || 'Recent'}</span>
                        </div>
                      </td>

                      {/* Director Bonus Money Control (Director Only) */}
                      {!isCreatorRole && (
                        <td className="py-4 px-5">
                          {isEditing ? (
                            <div className="flex items-center gap-2">
                              <div className="relative w-32">
                                <span className="absolute left-2.5 top-2 text-xs text-emerald-400 font-bold">$</span>
                                <input
                                  type="number"
                                  min={0}
                                  step={50}
                                  value={bonusAmountInput}
                                  onChange={(e) => setBonusAmountInput(Number(e.target.value))}
                                  className="w-full bg-[#091122] border border-[#C9A46A] rounded-lg pl-6 pr-2 py-1.5 text-xs font-bold text-emerald-400 font-mono outline-none"
                                />
                              </div>
                              <button
                                type="button"
                                onClick={() => handleSaveBonus(ref, bonusAmountInput)}
                                className="px-2.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-[11px] rounded-lg cursor-pointer flex items-center gap-1"
                              >
                                <Save className="w-3 h-3" /> Save
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingBonusId(null)}
                                className="p-1.5 bg-white/5 hover:bg-white/10 text-slate-400 rounded-lg cursor-pointer"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1 font-bold text-emerald-400 text-sm font-mono bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg">
                                <DollarSign className="w-3.5 h-3.5 stroke-[3]" />
                                <span>{(ref.value || 500).toLocaleString()}.00 USD</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingBonusId(ref.id);
                                  setBonusAmountInput(ref.value || 500);
                                }}
                                className="p-1.5 bg-white/5 hover:bg-[#C9A46A]/20 hover:text-[#C9A46A] text-slate-400 rounded-lg transition cursor-pointer"
                                title="Director: Edit Bonus Money Amount"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                      )}

                      {/* Status & Director Actions */}
                      <td className="py-4 px-5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                            ref.status === 'Paid'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : ref.status === 'Approved'
                              ? 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                              : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                          }`}>
                            {ref.status === 'Paid' ? 'Paid' : ref.status === 'Approved' ? 'Approved' : 'Pending Review'}
                          </span>

                          {!isCreatorRole && (
                            <div className="flex items-center gap-1">
                              {ref.status !== 'Approved' && ref.status !== 'Paid' && (
                                <button
                                  type="button"
                                  onClick={() => handleSaveBonus(ref, ref.value || 500, 'Approved')}
                                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold rounded-lg cursor-pointer transition"
                                >
                                  Approve
                                </button>
                              )}
                              {ref.status !== 'Paid' && (
                                <button
                                  type="button"
                                  onClick={() => handleSaveBonus(ref, ref.value || 500, 'Paid')}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold rounded-lg cursor-pointer transition"
                                >
                                  Mark Paid
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL: Log New Creator Referral Application */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0D1830] border-2 border-[#C9A46A]/50 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl text-white space-y-5 animate-fade-in max-h-[90vh] overflow-y-auto my-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#C9A46A]" />
                  <h3 className="text-lg font-serif font-bold text-white">
                    {isCreatorRole ? 'Refer a Creator to Agency' : 'Log Creator Referral & Assign Bonus'}
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isCreatorRole ? 'Submit a creator referral directly to the Agency Director.' : 'Record creator referral details and set initial bonus allocation.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsApplyModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-xl bg-white/5 hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4 text-xs font-mono">
              <div className="space-y-1.5">
                <label className="text-[11px] text-slate-300 uppercase block">Referring Creator Handle / Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. @elenarostova"
                  value={applicantReferrer}
                  onChange={(e) => setApplicantReferrer(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-300 uppercase block">Referred Creator Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Chloe Bennett"
                    value={applicantName}
                    onChange={(e) => setApplicantName(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-300 uppercase block">Creator Social Handle *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. @chloeglows"
                    value={applicantHandle}
                    onChange={(e) => setApplicantHandle(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>
              </div>

              <div className={`grid grid-cols-1 ${!isCreatorRole ? 'sm:grid-cols-2' : ''} gap-3`}>
                <div className="space-y-1.5">
                  <label className="text-[11px] text-slate-300 uppercase block">Category / Niche</label>
                  <select
                    value={applicantNiche}
                    onChange={(e) => setApplicantNiche(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none cursor-pointer"
                  >
                    <option value="Beauty & Skincare">Beauty &amp; Skincare</option>
                    <option value="Pets & Animals">Pets &amp; Animals</option>
                    <option value="Fitness & Lifestyle">Fitness &amp; Lifestyle</option>
                    <option value="Tech & Gaming">Tech &amp; Gaming</option>
                    <option value="Fashion & Apparel">Fashion &amp; Apparel</option>
                    <option value="General Creator Roster">General Creator Roster</option>
                  </select>
                </div>

                {!isCreatorRole && (
                  <div className="space-y-1.5">
                    <label className="text-[11px] text-slate-300 uppercase block">Director Bonus Money ($ USD)</label>
                    <input
                      type="number"
                      min={100}
                      step={50}
                      required
                      value={initialBonusAmount}
                      onChange={(e) => setInitialBonusAmount(Number(e.target.value))}
                      className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-emerald-400 font-bold outline-none"
                    />
                  </div>
                )}
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] text-slate-300 uppercase block">Contact Email</label>
                <input
                  type="email"
                  placeholder="creator@example.com"
                  value={applicantEmail}
                  onChange={(e) => setApplicantEmail(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] text-slate-300 uppercase block">Recommendation Notes</label>
                <textarea
                  rows={2}
                  placeholder="Why this creator is recommended for Bloom Studio roster..."
                  value={applicantNotes}
                  onChange={(e) => setApplicantNotes(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl p-3 text-xs text-white outline-none resize-none"
                />
              </div>

              <div className="bg-[#111E33] border border-white/10 rounded-xl p-3 flex items-center gap-2 text-[11px] text-slate-300">
                <ShieldCheck className="w-4 h-4 text-[#C9A46A] shrink-0" />
                <span>Submissions sync directly with the Agency Director desk in real-time.</span>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-white/10 text-slate-300 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A46A] to-[#D4AF37] text-[#0A1220] font-bold uppercase tracking-wider hover:brightness-110 cursor-pointer shadow-lg flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Referral</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
