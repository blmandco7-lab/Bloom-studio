import React, { useState, useEffect, useMemo } from 'react';
import { 
  FileText, Shield, ShieldAlert, ArrowUpDown, ArrowUp, ArrowDown, 
  Search, Filter, Building2, User, Clock, Download, RefreshCw, 
  CheckCircle2, AlertTriangle, ChevronRight, Copy, Check, Activity, 
  Database, Eye, X, SlidersHorizontal, Terminal, ShieldCheck, Sparkles, Send
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, orderBy, limit, addDoc, where } from 'firebase/firestore';

interface SystemAuditLogViewProps {
  currentUser?: any;
  currentRole?: string;
  primaryBrandColor?: string;
  onNavigate?: (screenId: string) => void;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

export interface AuditRecord {
  id: string;
  user: string;
  role: string;
  action: string;
  timestamp: string;
  subagency?: string;
  tenantId?: string;
  operationType?: 'CREATE' | 'UPDATE' | 'DELETE' | 'SECURITY' | 'FINANCIAL' | 'COMPLIANCE' | 'GENERAL';
  collectionTarget?: string;
  details?: any;
  ipAddress?: string;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}

export default function SystemAuditLogView({
  currentUser,
  currentRole = 'director',
  primaryBrandColor = '#C9A46A',
  onNavigate,
  triggerNotification
}: SystemAuditLogViewProps) {
  // Enforce Platform Owner strictly
  const isPlatformOwner = Boolean(
    currentUser?.isPlatformOwner ||
    currentUser?.email === 'lilbitnd06@gmail.com' ||
    currentUser?.role === 'owner'
  );

  const [records, setRecords] = useState<AuditRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  // Sorting State
  const [sortField, setSortField] = useState<'timestamp' | 'user' | 'subagency' | 'action'>('timestamp');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Filtering State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubagency, setSelectedSubagency] = useState<string>('ALL');
  const [selectedOpType, setSelectedOpType] = useState<string>('ALL');
  const [timePreset, setTimePreset] = useState<'all' | '1h' | '24h' | '7d'>('all');

  // Inspector Modal State
  const [inspectingRecord, setInspectingRecord] = useState<AuditRecord | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Manual Audit Verification Dispatch
  const [isManualDispatching, setIsManualDispatching] = useState(false);
  const [manualNote, setManualNote] = useState('');
  const [showManualForm, setShowManualForm] = useState(false);

  // Derive operation type from action text
  const inferOperationType = (actionText: string = ''): 'CREATE' | 'UPDATE' | 'DELETE' | 'SECURITY' | 'FINANCIAL' | 'COMPLIANCE' | 'GENERAL' => {
    const lower = actionText.toLowerCase();
    if (lower.includes('delete') || lower.includes('remove') || lower.includes('trash') || lower.includes('revoke')) return 'DELETE';
    if (lower.includes('create') || lower.includes('add') || lower.includes('draft') || lower.includes('seed') || lower.includes('new ') || lower.includes('provision')) return 'CREATE';
    if (lower.includes('payment') || lower.includes('invoice') || lower.includes('escrow') || lower.includes('stripe') || lower.includes('wire') || lower.includes('payout') || lower.includes('fee')) return 'FINANCIAL';
    if (lower.includes('kill switch') || lower.includes('maintenance') || lower.includes('emergency') || lower.includes('lockdown') || lower.includes('auth') || lower.includes('key')) return 'SECURITY';
    if (lower.includes('update') || lower.includes('edit') || lower.includes('switch') || lower.includes('save') || lower.includes('toggle') || lower.includes('modified')) return 'UPDATE';
    if (lower.includes('gdpr') || lower.includes('compliance') || lower.includes('terms') || lower.includes('consent') || lower.includes('nda') || lower.includes('w9')) return 'COMPLIANCE';
    return 'GENERAL';
  };

  // Real-time Firestore sync
  useEffect(() => {
    // If not Platform Owner AND not Director/Agency, they shouldn't even be here usually,
    // but we enforce scoping based on the pod.
    const isExecutive = isPlatformOwner || ['director', 'agency'].includes(currentRole.toLowerCase());
    const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';

    setLoading(true);
    let unsubscribe = () => {};

    try {
      const colRef = collection(db, 'studio-activity-log');
      let q;
      
      if (isPlatformOwner) {
        // Platform Owner sees everything
        q = query(colRef, limit(300));
      } else if (isExecutive) {
        // Director/Agency sees entire pod
        q = query(colRef, where('subagency', '==', userPod), limit(300));
      } else {
        // Staff see people they are working with (same pod)
        q = query(colRef, where('subagency', '==', userPod), limit(300));
      }

      unsubscribe = onSnapshot(q, (snapshot) => {
        const list: AuditRecord[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          const actionText = data.action || data.description || 'Firestore write operation';
          list.push({
            id: docSnap.id,
            user: data.user || data.operatorName || data.author || data.creatorHandle || 'System Worker',
            role: data.role || (data.user?.includes('@') ? 'operator' : 'system'),
            action: actionText,
            timestamp: data.timestamp || data.createdAt || data.date || new Date().toISOString(),
            subagency: data.subagency || data.pod || 'pod_main',
            tenantId: data.tenantId || 'bloom_studio_default',
            operationType: data.operationType || inferOperationType(actionText),
            details: data.details || data.metadata || (data.updates ? { updates: data.updates } : undefined),
            status: data.status || 'SUCCESS'
          });
        });

        // Fallback default mock events if collection is completely fresh
        if (list.length === 0) {
          const initialSamples: AuditRecord[] = [
            {
              id: 'ACT-SYS-001',
              user: 'Platform Owner',
              role: 'owner',
              action: 'Configured Platform Emergency Kill Switch & Real-Time Sync',
              timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
              subagency: 'pod_main',
              tenantId: 'bloom_studio_default',
              operationType: 'SECURITY',
              status: 'SUCCESS'
            },
            {
              id: 'ACT-SYS-002',
              user: currentUser?.name || 'Executive Director',
              role: 'director',
              action: 'Drafted Studio Invoice INV-BLOOM-A1B2C for Brand UGC Campaign ($15,000.00)',
              timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
              subagency: currentUser?.subagency || 'pod_main',
              tenantId: 'bloom_studio_default',
              operationType: 'FINANCIAL',
              status: 'SUCCESS'
            },
            {
              id: 'ACT-SYS-003',
              user: 'Sarah Jenkins',
              role: 'agent',
              action: 'Submitted Brand Collaboration Deal to Talent Pipeline for Creator @sofia.lifestyle',
              timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
              subagency: 'pod_la',
              tenantId: 'bloom_la_studio',
              operationType: 'CREATE',
              status: 'SUCCESS'
            },
            {
              id: 'ACT-SYS-004',
              user: 'Marcus Vance',
              role: 'coordinator',
              action: 'Approved Deliverable Video Review v2 for Nike UGC Series',
              timestamp: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
              subagency: 'pod_nyc',
              tenantId: 'bloom_nyc_studio',
              operationType: 'UPDATE',
              status: 'SUCCESS'
            },
            {
              id: 'ACT-SYS-005',
              user: 'System Compliance Daemon',
              role: 'system',
              action: 'Rotated Vault Signature Keys and Re-indexed W-9 Compliance Records',
              timestamp: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
              subagency: 'pod_main',
              tenantId: 'bloom_studio_default',
              operationType: 'COMPLIANCE',
              status: 'SUCCESS'
            }
          ];
          setRecords(initialSamples);
        } else {
          setRecords(list);
        }
        setLoading(false);
      }, (err) => {
        console.warn("[SystemAuditLogView] Subscription notice:", err);
        setLoading(false);
      });
    } catch (e) {
      console.warn("Failed initializing audit listener:", e);
      setLoading(false);
    }

    return () => unsubscribe();
  }, [isPlatformOwner, refreshKey]);

  // Extract unique subagencies for filter dropdown
  const uniqueSubagencies = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => {
      if (r.subagency) set.add(r.subagency);
    });
    return Array.from(set).sort();
  }, [records]);

  // Filter & Sort Logic
  const processedRecords = useMemo(() => {
    let result = [...records];

    // Filter by Time Preset
    if (timePreset !== 'all') {
      const now = Date.now();
      const cutoffMap = {
        '1h': now - 1000 * 60 * 60,
        '24h': now - 1000 * 60 * 60 * 24,
        '7d': now - 1000 * 60 * 60 * 24 * 7,
      };
      const cutoff = cutoffMap[timePreset];
      result = result.filter(r => new Date(r.timestamp).getTime() >= cutoff);
    }

    // Filter by Subagency
    if (selectedSubagency !== 'ALL') {
      result = result.filter(r => r.subagency === selectedSubagency);
    }

    // Filter by Operation Type
    if (selectedOpType !== 'ALL') {
      result = result.filter(r => r.operationType === selectedOpType);
    }

    // Filter by Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(r => 
        (r.user && r.user.toLowerCase().includes(q)) ||
        (r.action && r.action.toLowerCase().includes(q)) ||
        (r.subagency && r.subagency.toLowerCase().includes(q)) ||
        (r.id && r.id.toLowerCase().includes(q)) ||
        (r.role && r.role.toLowerCase().includes(q))
      );
    }

    // Sorting
    result.sort((a, b) => {
      let valA: any;
      let valB: any;

      if (sortField === 'timestamp') {
        valA = new Date(a.timestamp).getTime();
        valB = new Date(b.timestamp).getTime();
      } else if (sortField === 'user') {
        valA = a.user.toLowerCase();
        valB = b.user.toLowerCase();
      } else if (sortField === 'subagency') {
        valA = (a.subagency || '').toLowerCase();
        valB = (b.subagency || '').toLowerCase();
      } else {
        valA = a.action.toLowerCase();
        valB = b.action.toLowerCase();
      }

      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [records, timePreset, selectedSubagency, selectedOpType, searchQuery, sortField, sortOrder]);

  // Aggregate Metrics
  const stats = useMemo(() => {
    const totalWrites = records.length;
    const subagencyCount = new Set(records.map(r => r.subagency).filter(Boolean)).size;
    const operatorCount = new Set(records.map(r => r.user).filter(Boolean)).size;
    
    // Today's writes
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const writesToday = records.filter(r => new Date(r.timestamp) >= startOfToday).length;

    return { totalWrites, subagencyCount, operatorCount, writesToday };
  }, [records]);

  // Export to CSV
  const handleExportCSV = () => {
    if (processedRecords.length === 0) return;
    const headers = ["Record ID", "Timestamp (UTC)", "Operator User", "Role", "Subagency Pod", "Tenant ID", "Operation Type", "Action Description"];
    const rows = processedRecords.map(r => [
      `"${r.id}"`,
      `"${new Date(r.timestamp).toISOString()}"`,
      `"${r.user.replace(/"/g, '""')}"`,
      `"${r.role}"`,
      `"${(r.subagency || '').replace(/"/g, '""')}"`,
      `"${(r.tenantId || '').replace(/"/g, '""')}"`,
      `"${r.operationType || 'GENERAL'}"`,
      `"${r.action.replace(/"/g, '""')}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `system_audit_log_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (triggerNotification) {
      triggerNotification("Audit Log Exported", "Master system audit log CSV downloaded successfully.", "success");
    }
  };

  // Export to JSON
  const handleExportJSON = () => {
    if (processedRecords.length === 0) return;
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(processedRecords, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `system_audit_log_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();

    if (triggerNotification) {
      triggerNotification("JSON Exported", "Complete Firestore activity schema downloaded.", "success");
    }
  };

  // Dispatch Manual Platform Owner Checkpoint Entry
  const handleManualCheckpoint = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualNote.trim()) return;

    setIsManualDispatching(true);
    try {
      const colRef = collection(db, 'studio-activity-log');
      await addDoc(colRef, {
        user: currentUser?.name || currentUser?.email || 'Platform Owner',
        role: 'owner',
        action: `[Owner Audit Checkpoint] ${manualNote.trim()}`,
        timestamp: new Date().toISOString(),
        subagency: currentUser?.subagency || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        operationType: 'SECURITY',
        isOwnerCheckpoint: true
      });

      setManualNote('');
      setShowManualForm(false);
      if (triggerNotification) {
        triggerNotification("Checkpoint Recorded", "Immutable audit verification recorded to Firestore.", "success");
      }
    } catch (err) {
      console.error("Failed recording checkpoint:", err);
      if (triggerNotification) {
        triggerNotification("Write Error", "Could not dispatch audit checkpoint to Firestore.", "danger");
      }
    } finally {
      setIsManualDispatching(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Guard: Authorization Check (Only Platform Owner, Director, Agency or authorized staff)
  const isExecutive = isPlatformOwner || ['director', 'agency'].includes(currentRole.toLowerCase());
  const canAccess = isExecutive || currentRole === 'agent' || currentRole === 'agentmgr' || currentRole === 'coordinator';

  if (!canAccess) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] p-8 text-center bg-[#0D1830]/80 border border-red-500/20 rounded-2xl animate-fade-in text-xs max-w-2xl mx-auto my-12">
        <div className="flex items-center justify-center w-14 h-14 rounded-full bg-red-500/10 text-red-500 mb-4 ring-8 ring-red-500/5">
          <ShieldAlert className="w-7 h-7 text-red-400" />
        </div>
        <h2 className="text-base font-semibold text-red-400 mb-2 font-serif">Unauthorized Access</h2>
        <p className="text-gray-400 mb-6 leading-relaxed max-w-md">
          The <strong>System Audit Log</strong> requires specific agency clearance levels. Your current role does not have permission to view this chronological ledger.
        </p>
        <div className="p-3 bg-white/5 border border-white/10 rounded-xl mb-6 text-left w-full max-w-md text-[11px] space-y-1">
          <div className="flex justify-between text-gray-400">
            <span>Caller Identity:</span>
            <span className="text-white font-mono">{currentUser?.email || currentUser?.name || 'Unauthenticated'}</span>
          </div>
          <div className="flex justify-between text-gray-400">
            <span>Assigned Role:</span>
            <span className="text-amber-300 font-mono capitalize">{currentRole}</span>
          </div>
          <div className="flex justify-between text-gray-400">
            <span>Platform Owner Status:</span>
            <span className="text-red-400 font-semibold">Denied (false)</span>
          </div>
        </div>
        {onNavigate && (
          <button
            onClick={() => onNavigate('briefing')}
            className="px-4 py-2 text-xs font-semibold text-[#111E33] bg-[#C9A46A] hover:bg-[#B89359] rounded-xl transition-all shadow-md"
          >
            Return to Authorized Dashboard
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto animate-fade-in text-white">
      {/* Top Header & Platform Owner Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-amber-400" />
              Platform Owner Exclusive
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <Activity className="w-3 h-3 animate-pulse text-emerald-400" />
              Live Firestore Telemetry
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-serif tracking-wide text-white flex items-center gap-2.5">
            <Database className="w-6 h-6 text-[#C9A46A]" />
            System Audit Log
          </h1>
          <p className="text-xs text-[#7C8AA8] mt-1 max-w-2xl leading-relaxed">
            Real-time chronological ledger of all Firestore write operations, operator identity tracking, and cross-subagency mutation audits from the <code className="text-amber-200 font-mono bg-white/5 px-1 py-0.5 rounded">studio-activity-log</code> collection.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setRefreshKey(k => k + 1)}
            className="px-3 py-2 bg-[#111E33] hover:bg-white/10 border border-white/10 rounded-xl text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 transition-all shadow-sm"
            title="Refresh Firestore Log Stream"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#C9A46A]" />
            <span>Sync</span>
          </button>

          <button
            onClick={() => setShowManualForm(!showManualForm)}
            className="px-3 py-2 bg-[#111E33] hover:bg-white/10 border border-amber-500/30 rounded-xl text-xs font-medium text-amber-300 flex items-center gap-1.5 transition-all shadow-sm"
            title="Log Owner Verification Checkpoint"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Checkpoint</span>
          </button>

          <div className="flex items-center gap-1 bg-[#111E33] border border-white/10 p-1 rounded-xl">
            <button
              onClick={handleExportCSV}
              className="px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white hover:bg-white/10 rounded-lg flex items-center gap-1 transition-all"
              title="Download CSV Spreadsheet"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>CSV</span>
            </button>
            <button
              onClick={handleExportJSON}
              className="px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white hover:bg-white/10 rounded-lg flex items-center gap-1 transition-all"
              title="Download JSON Payload"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>JSON</span>
            </button>
          </div>
        </div>
      </div>

      {/* Manual Checkpoint Drawer/Card */}
      {showManualForm && (
        <form onSubmit={handleManualCheckpoint} className="bg-[#111E33] border border-amber-500/40 rounded-2xl p-4 sm:p-5 animate-scale-in space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-semibold text-amber-200 uppercase tracking-wider">Record Platform Owner Audit Checkpoint</h3>
            </div>
            <button type="button" onClick={() => setShowManualForm(false)} className="text-gray-400 hover:text-white p-1">
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[11px] text-gray-400">
            Write an authoritative audit checkpoint event directly to <code className="text-amber-300 font-mono">studio-activity-log</code> tagged with your Platform Owner signature.
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              value={manualNote}
              onChange={(e) => setManualNote(e.target.value)}
              placeholder="e.g., Conducted quarterly tenant isolation & permission audit..."
              className="flex-1 bg-[#0A1220] border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
              required
            />
            <button
              type="submit"
              disabled={isManualDispatching || !manualNote.trim()}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-[#0A1220] font-semibold text-xs rounded-xl flex items-center gap-1.5 transition-all disabled:opacity-50 shadow-md cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isManualDispatching ? 'Recording...' : 'Record Entry'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Top Telemetry KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-[#0D1830]/90 border border-white/10 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-[#7C8AA8] mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Write Events</span>
            <Database className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tracking-tight">{stats.totalWrites}</div>
          <div className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1 font-medium">
            <Activity className="w-3 h-3" />
            <span>Active Collection Stream</span>
          </div>
        </div>

        <div className="bg-[#0D1830]/90 border border-white/10 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-[#7C8AA8] mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Subagencies Audited</span>
            <Building2 className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tracking-tight">{stats.subagencyCount}</div>
          <div className="text-[10px] text-gray-400 truncate mt-1">
            Across isolated pod partitions
          </div>
        </div>

        <div className="bg-[#0D1830]/90 border border-white/10 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-[#7C8AA8] mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Unique Operators</span>
            <User className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tracking-tight">{stats.operatorCount}</div>
          <div className="text-[10px] text-gray-400 truncate mt-1">
            Directors, staff, agents, daemons
          </div>
        </div>

        <div className="bg-[#0D1830]/90 border border-white/10 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-[#7C8AA8] mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Today's Velocity</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 tracking-tight">{stats.writesToday}</div>
          <div className="text-[10px] text-gray-400 truncate mt-1">
            Writes recorded in last 24h
          </div>
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="bg-[#0D1830]/80 border border-white/10 rounded-2xl p-4 space-y-3.5">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-[#7C8AA8] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by operator, action keyword, subagency pod, or ID..."
              className="w-full bg-[#0A1220] border border-white/15 rounded-xl pl-9 pr-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-[#C9A46A] transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Preset Filters */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Subagency Pod Filter */}
            <div className="flex items-center gap-1.5 bg-[#0A1220] border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-slate-300">
              <Building2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="text-gray-400 text-[11px]">Pod:</span>
              <select
                value={selectedSubagency}
                onChange={(e) => setSelectedSubagency(e.target.value)}
                className="bg-transparent text-xs text-white focus:outline-none cursor-pointer pr-1"
              >
                <option value="ALL" className="bg-[#0D1830] text-white">All Subagencies</option>
                {uniqueSubagencies.map(sub => (
                  <option key={sub} value={sub} className="bg-[#0D1830] text-white">{sub}</option>
                ))}
              </select>
            </div>

            {/* Operation Type Filter */}
            <div className="flex items-center gap-1.5 bg-[#0A1220] border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-slate-300">
              <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="text-gray-400 text-[11px]">Type:</span>
              <select
                value={selectedOpType}
                onChange={(e) => setSelectedOpType(e.target.value)}
                className="bg-transparent text-xs text-white focus:outline-none cursor-pointer pr-1"
              >
                <option value="ALL" className="bg-[#0D1830] text-white">All Operations</option>
                <option value="CREATE" className="bg-[#0D1830] text-emerald-300">Create / Insert</option>
                <option value="UPDATE" className="bg-[#0D1830] text-sky-300">Update / Patch</option>
                <option value="DELETE" className="bg-[#0D1830] text-rose-300">Delete / Revoke</option>
                <option value="FINANCIAL" className="bg-[#0D1830] text-amber-300">Financial / Billing</option>
                <option value="SECURITY" className="bg-[#0D1830] text-purple-300">Security / Lockdown</option>
                <option value="COMPLIANCE" className="bg-[#0D1830] text-indigo-300">Compliance / Legal</option>
              </select>
            </div>

            {/* Time Window Buttons */}
            <div className="flex items-center bg-[#0A1220] border border-white/15 p-1 rounded-xl text-[11px]">
              {(['all', '1h', '24h', '7d'] as const).map(preset => (
                <button
                  key={preset}
                  onClick={() => setTimePreset(preset)}
                  className={`px-2 py-0.5 rounded-lg font-medium transition-all ${
                    timePreset === preset
                      ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-sm'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {preset === 'all' ? 'All' : preset === '1h' ? '1h' : preset === '24h' ? '24h' : '7d'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Active Filter Indicators & Sorting Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5 text-[11px] text-gray-400">
          <div className="flex items-center gap-2">
            <span>Showing <strong className="text-white font-mono">{processedRecords.length}</strong> of <span className="font-mono">{records.length}</span> write entries</span>
            {(selectedSubagency !== 'ALL' || selectedOpType !== 'ALL' || timePreset !== 'all' || searchQuery) && (
              <button
                onClick={() => {
                  setSelectedSubagency('ALL');
                  setSelectedOpType('ALL');
                  setTimePreset('all');
                  setSearchQuery('');
                }}
                className="text-amber-400 hover:text-amber-300 hover:underline flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                <span>Reset Filters</span>
              </button>
            )}
          </div>

          {/* Sort Controller */}
          <div className="flex items-center gap-2">
            <span className="text-gray-500">Sort by:</span>
            <div className="flex items-center gap-1 bg-[#0A1220] border border-white/10 rounded-lg p-0.5">
              <button
                onClick={() => {
                  if (sortField === 'timestamp') setSortOrder(o => o === 'desc' ? 'asc' : 'desc');
                  else { setSortField('timestamp'); setSortOrder('desc'); }
                }}
                className={`px-2 py-0.5 rounded flex items-center gap-1 ${sortField === 'timestamp' ? 'bg-white/10 text-white font-medium' : 'text-gray-400 hover:text-white'}`}
              >
                <span>Time</span>
                {sortField === 'timestamp' && (sortOrder === 'desc' ? <ArrowDown className="w-3 h-3 text-amber-400" /> : <ArrowUp className="w-3 h-3 text-amber-400" />)}
              </button>
              <button
                onClick={() => {
                  if (sortField === 'user') setSortOrder(o => o === 'desc' ? 'asc' : 'desc');
                  else { setSortField('user'); setSortOrder('asc'); }
                }}
                className={`px-2 py-0.5 rounded flex items-center gap-1 ${sortField === 'user' ? 'bg-white/10 text-white font-medium' : 'text-gray-400 hover:text-white'}`}
              >
                <span>Operator</span>
                {sortField === 'user' && (sortOrder === 'desc' ? <ArrowDown className="w-3 h-3 text-amber-400" /> : <ArrowUp className="w-3 h-3 text-amber-400" />)}
              </button>
              <button
                onClick={() => {
                  if (sortField === 'subagency') setSortOrder(o => o === 'desc' ? 'asc' : 'desc');
                  else { setSortField('subagency'); setSortOrder('asc'); }
                }}
                className={`px-2 py-0.5 rounded flex items-center gap-1 ${sortField === 'subagency' ? 'bg-white/10 text-white font-medium' : 'text-gray-400 hover:text-white'}`}
              >
                <span>Subagency</span>
                {sortField === 'subagency' && (sortOrder === 'desc' ? <ArrowDown className="w-3 h-3 text-amber-400" /> : <ArrowUp className="w-3 h-3 text-amber-400" />)}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Table / Chronological List */}
      <div className="bg-[#0D1830]/90 border border-white/10 rounded-2xl overflow-hidden shadow-lg">
        {loading ? (
          <div className="p-12 text-center text-gray-400 space-y-3">
            <RefreshCw className="w-8 h-8 animate-spin text-[#C9A46A] mx-auto opacity-70" />
            <p className="text-xs font-mono">Streaming Firestore activity records across all partitions...</p>
          </div>
        ) : processedRecords.length === 0 ? (
          <div className="p-12 text-center text-gray-400 space-y-3">
            <Database className="w-10 h-10 text-gray-600 mx-auto" />
            <h3 className="text-sm font-semibold text-white">No Firestore Write Records Found</h3>
            <p className="text-xs max-w-md mx-auto text-gray-500">
              No activity logs matched your active search or filter criteria. Clear filters or initiate actions across any agency module.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 bg-[#0A1220]/70 text-[#7C8AA8] font-semibold text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Operator / User</th>
                  <th className="py-3 px-4">Subagency Pod</th>
                  <th className="py-3 px-4">Operation</th>
                  <th className="py-3 px-4">Action Summary</th>
                  <th className="py-3 px-4 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {processedRecords.map((r) => {
                  const dateObj = new Date(r.timestamp);
                  const isRecent = Date.now() - dateObj.getTime() < 1000 * 60 * 30; // 30 minutes

                  // Badge Colors
                  let opBadgeClass = "bg-gray-500/10 text-gray-300 border-gray-500/20";
                  if (r.operationType === 'CREATE') opBadgeClass = "bg-emerald-500/10 text-emerald-400 border-emerald-500/30";
                  else if (r.operationType === 'UPDATE') opBadgeClass = "bg-sky-500/10 text-sky-400 border-sky-500/30";
                  else if (r.operationType === 'DELETE') opBadgeClass = "bg-rose-500/10 text-rose-400 border-rose-500/30";
                  else if (r.operationType === 'FINANCIAL') opBadgeClass = "bg-amber-500/10 text-amber-300 border-amber-500/30";
                  else if (r.operationType === 'SECURITY') opBadgeClass = "bg-purple-500/10 text-purple-300 border-purple-500/30";
                  else if (r.operationType === 'COMPLIANCE') opBadgeClass = "bg-indigo-500/10 text-indigo-300 border-indigo-500/30";

                  return (
                    <tr 
                      key={r.id}
                      className="hover:bg-white/[0.03] transition-colors group cursor-pointer"
                      onClick={() => setInspectingRecord(r)}
                    >
                      {/* Timestamp */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 font-mono text-[11px] text-gray-300">
                          {isRecent && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>}
                          <span>{dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                        </div>
                        <div className="text-[10px] text-gray-500 font-mono">
                          {dateObj.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                        </div>
                      </td>

                      {/* Operator / User */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg bg-white/10 flex items-center justify-center text-[10px] font-bold text-[#C9A46A]">
                            {r.user.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-semibold text-white text-[11px] flex items-center gap-1">
                              {r.user}
                              {r.role === 'owner' && (
                                <span className="text-[9px] px-1 bg-amber-500/20 text-amber-300 rounded font-normal">Owner</span>
                              )}
                            </div>
                            <div className="text-[10px] text-gray-400 capitalize">
                              {r.role || 'Staff'}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Subagency Pod */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-mono font-medium bg-sky-950/50 text-sky-300 border border-sky-500/30">
                          <Building2 className="w-3 h-3 text-sky-400" />
                          {r.subagency || 'pod_main'}
                        </span>
                        {r.tenantId && r.tenantId !== r.subagency && (
                          <div className="text-[9px] text-gray-500 font-mono mt-0.5 truncate max-w-[120px]">
                            {r.tenantId}
                          </div>
                        )}
                      </td>

                      {/* Operation Type */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold border ${opBadgeClass}`}>
                          {r.operationType || 'GENERAL'}
                        </span>
                      </td>

                      {/* Action Summary */}
                      <td className="py-3 px-4 min-w-[280px]">
                        <p className="text-gray-200 text-xs line-clamp-2 leading-relaxed">
                          {r.action}
                        </p>
                        <div className="text-[9px] text-gray-500 font-mono mt-0.5">
                          ID: {r.id}
                        </div>
                      </td>

                      {/* Inspect Button */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setInspectingRecord(r);
                          }}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-all opacity-70 group-hover:opacity-100"
                          title="View Full Firestore Document Payload"
                        >
                          <Eye className="w-4 h-4 text-[#C9A46A]" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Record Inspector Modal */}
      {inspectingRecord && (
        <div 
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setInspectingRecord(null)}
        >
          <div 
            className="bg-[#0D1830] border border-white/20 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-black/20">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-400">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white font-serif">Firestore Write Audit Inspection</h3>
                  <p className="text-[10px] text-gray-400 font-mono">Collection: studio-activity-log / {inspectingRecord.id}</p>
                </div>
              </div>
              <button
                onClick={() => setInspectingRecord(null)}
                className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              {/* Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Initiating User</span>
                  <div className="font-semibold text-white truncate">{inspectingRecord.user}</div>
                  <span className="text-[10px] text-amber-300 font-mono capitalize">{inspectingRecord.role}</span>
                </div>

                <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Partition / Subagency</span>
                  <div className="font-semibold text-sky-300 font-mono truncate">{inspectingRecord.subagency || 'pod_main'}</div>
                  <span className="text-[10px] text-gray-400 font-mono truncate block">{inspectingRecord.tenantId}</span>
                </div>

                <div className="p-3 bg-white/5 border border-white/10 rounded-xl col-span-2 sm:col-span-1">
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Timestamp</span>
                  <div className="font-mono text-white text-[11px] truncate">{new Date(inspectingRecord.timestamp).toLocaleTimeString()}</div>
                  <span className="text-[10px] text-gray-400 font-mono block">{new Date(inspectingRecord.timestamp).toLocaleDateString()}</span>
                </div>
              </div>

              {/* Action Description */}
              <div className="p-3.5 bg-white/5 border border-white/10 rounded-xl space-y-1">
                <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Write Operation Description</span>
                <p className="text-white text-xs font-medium leading-relaxed">
                  {inspectingRecord.action}
                </p>
              </div>

              {/* Raw JSON Payload */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider flex items-center gap-1 font-mono">
                    <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                    Full Document Schema Payload (JSON)
                  </span>
                  <button
                    onClick={() => copyToClipboard(JSON.stringify(inspectingRecord, null, 2), inspectingRecord.id)}
                    className="text-[11px] text-[#C9A46A] hover:text-white flex items-center gap-1 py-0.5 px-2 rounded hover:bg-white/5 transition-all"
                  >
                    {copiedId === inspectingRecord.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy JSON</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="bg-[#050C18] border border-white/10 rounded-xl p-3.5 text-[11px] font-mono text-emerald-300 overflow-x-auto max-h-60 scrollbar-thin">
                  {JSON.stringify(inspectingRecord, null, 2)}
                </pre>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-white/10 bg-black/20 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[10px] text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verified Cross-Tenant Record via Platform Owner</span>
              </div>
              <button
                onClick={() => setInspectingRecord(null)}
                className="px-4 py-1.5 bg-white/10 hover:bg-white/20 text-white font-medium rounded-xl text-xs transition-colors"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
