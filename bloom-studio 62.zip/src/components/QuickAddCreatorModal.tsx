import React, { useState } from 'react';
import {
  X,
  UserPlus,
  Sparkles,
  Instagram,
  Video,
  Youtube,
  Globe,
  DollarSign,
  ShieldCheck,
  Mail,
  Phone,
  MapPin,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Creator } from '../types';
import { AutoSaveIndicator } from './AutoSaveIndicator';

interface QuickAddCreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddCreator: (creator: Creator) => void;
  defaultSubagency?: string;
}

export const QuickAddCreatorModal: React.FC<QuickAddCreatorModalProps> = ({
  isOpen,
  onClose,
  onAddCreator,
  defaultSubagency = ''
}) => {
  const [formData, setFormData] = useState({
    name: '',
    handle: '',
    email: '',
    phone: '',
    platform: 'TikTok',
    niche: 'Beauty & Skincare',
    followers: '150K',
    eng: '4.8%',
    agreement: 'Exclusive (80%)',
    agreementType: 'Exclusive' as const,
    exclusivityScope: 'Full Commercial & UGC',
    status: 'Active' as const,
    location: 'Los Angeles, CA',
    bio: '',
    assignedAgent: 'Main Agency Agent',
    tier: 'Tier 1 (Pro)',
    commissionSplit: '80/20 Agency Split',
    subagency: defaultSubagency
  });

  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name.trim()) {
      setError('Please provide the creator full legal/stage name.');
      return;
    }

    if (!formData.handle.trim()) {
      setError('Please provide the creator social handle (e.g. @handle).');
      return;
    }

    setIsSubmitting(true);

    try {
      const sanitizedHandle = formData.handle.startsWith('@') ? formData.handle : `@${formData.handle}`;
      const newCreatorId = `creator_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;

      const newCreator: Creator = {
        id: newCreatorId,
        name: formData.name.trim(),
        handle: sanitizedHandle.trim(),
        email: formData.email.trim() || `${formData.name.toLowerCase().replace(/\s+/g, '')}@talentbloom.agency`,
        phone: formData.phone.trim() || '+1 (555) 019-2834',
        platform: formData.platform,
        niche: formData.niche,
        followers: formData.followers.trim() || '100K',
        eng: formData.eng.trim() || '4.5%',
        agreement: formData.agreement,
        agreementType: formData.agreementType,
        exclusivityScope: formData.exclusivityScope,
        status: formData.status,
        location: formData.location.trim() || 'United States',
        bio: formData.bio.trim() || `Rising ${formData.niche} creator partnering with high-growth premium lifestyle brands.`,
        assignedAgent: formData.assignedAgent,
        tier: formData.tier,
        commissionSplit: formData.commissionSplit,
        subagency: formData.subagency || undefined,
        contractStatus: 'Active',
        contractStartDate: new Date().toISOString().split('T')[0],
        dateSigned: new Date().toISOString().split('T')[0],
        w9Status: 'Verified & Stored',
        w9Uploaded: true,
        taxIdStatus: 'Active W-9 On File',
        q1Availability: 'Available',
        q2Availability: 'Available',
        q3Availability: 'Available',
        q4Availability: 'Available',
        avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80`
      };

      onAddCreator(newCreator);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to add creator. Please verify inputs.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-[#0A1220] border border-[#D4AF37]/30 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#0F1C30] border-b border-white/10 p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white font-serif">Quick-Add Talent</h3>
                <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30 rounded-full">
                  ROSTER ONBOARDING
                </span>
              </div>
              <p className="text-xs text-slate-400">Instantly register verified creators with live contract & escrow tracking</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <AutoSaveIndicator 
              draftKey="quick_add_creator" 
              formData={formData} 
              onRestoreDraft={(saved) => setFormData(prev => ({ ...prev, ...saved }))} 
              onClearDraft={() => {}} 
            />
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-3 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
          {/* Basic Info Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Full Name / Creator Stage Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Sophia Martinez"
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37] transition"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Primary Social Handle *
              </label>
              <input
                type="text"
                required
                value={formData.handle}
                onChange={(e) => setFormData({ ...formData, handle: e.target.value })}
                placeholder="@sophia_creative"
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37] transition font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1 flex items-center gap-1">
                <Mail className="w-3 h-3 text-slate-400" /> Email Address
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="sophia@talentbloom.agency"
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37] transition"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1 flex items-center gap-1">
                <Phone className="w-3 h-3 text-slate-400" /> Phone Number (SMS-Ready)
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+1 (555) 019-2834"
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37] transition font-mono"
              />
            </div>
          </div>

          {/* Social Platform & Niche Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Primary Platform
              </label>
              <select
                value={formData.platform}
                onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#D4AF37] transition cursor-pointer"
              >
                <option value="TikTok">TikTok (Short Form)</option>
                <option value="Instagram">Instagram (Reels & Stories)</option>
                <option value="YouTube">YouTube (Longform & Shorts)</option>
                <option value="UGC Multi-Platform">UGC Multi-Platform</option>
                <option value="Twitch / Live Stream">Twitch / Live Stream</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Content Niche
              </label>
              <select
                value={formData.niche}
                onChange={(e) => setFormData({ ...formData, niche: e.target.value })}
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#D4AF37] transition cursor-pointer"
              >
                <option value="Beauty & Skincare">Beauty & Skincare</option>
                <option value="Fashion & Apparel">Fashion & Apparel</option>
                <option value="Health & Fitness">Health & Fitness</option>
                <option value="Lifestyle & Home">Lifestyle & Home</option>
                <option value="Tech & Gaming">Tech & Gaming</option>
                <option value="Food & Beverage">Food & Beverage</option>
                <option value="Travel & Hospitality">Travel & Hospitality</option>
                <option value="Finance & SaaS">Finance & SaaS</option>
              </select>
            </div>
          </div>

          {/* Follower & Engagement Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Audience / Followers
              </label>
              <input
                type="text"
                value={formData.followers}
                onChange={(e) => setFormData({ ...formData, followers: e.target.value })}
                placeholder="250K"
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#D4AF37] transition font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Avg Engagement Rate
              </label>
              <input
                type="text"
                value={formData.eng}
                onChange={(e) => setFormData({ ...formData, eng: e.target.value })}
                placeholder="5.2%"
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#D4AF37] transition font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Roster Tier
              </label>
              <select
                value={formData.tier}
                onChange={(e) => setFormData({ ...formData, tier: e.target.value })}
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#D4AF37] transition cursor-pointer"
              >
                <option value="Tier 1 (Pro)">Tier 1 (Pro / Key Talent)</option>
                <option value="Tier 2 (Emerging)">Tier 2 (Emerging / UGC)</option>
                <option value="Tier 3 (Rising)">Tier 3 (Rising Star)</option>
                <option value="VIP / Hero">VIP / Hero Talent</option>
              </select>
            </div>
          </div>

          {/* Representation Agreement & Split */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
                Agreement Structure
              </label>
              <select
                value={formData.agreement}
                onChange={(e) => {
                  const val = e.target.value;
                  const type = val.includes('Exclusive') && !val.includes('Non') 
                    ? 'Exclusive' 
                    : val.includes('Non-Exclusive') 
                    ? 'Non-Exclusive' 
                    : 'One-Time Deal';
                  setFormData({ 
                    ...formData, 
                    agreement: val,
                    agreementType: type as any
                  });
                }}
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#D4AF37] transition cursor-pointer"
              >
                <option value="Exclusive (80%)">Exclusive Representation (80% Talent / 20% Agency)</option>
                <option value="Non-Exclusive (70%)">Non-Exclusive Representation (70% / 30%)</option>
                <option value="One-Time Project / Single Deal">One-Time Project / Single Campaign</option>
                <option value="Monthly Retainer ($3,500/mo)">Monthly Brand Retainer ($3,500/mo)</option>
                <option value="Co-Representation (50%)">Co-Representation Agency Split (50/50)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-400" /> Primary Location
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="Los Angeles, CA"
                className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-[#D4AF37] transition"
              />
            </div>
          </div>

          {/* Creator Bio / Notes */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-200 uppercase tracking-wider mb-1">
              Creator Editorial Bio & Brand Pitch Tagline
            </label>
            <textarea
              rows={2}
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              placeholder="Short highlight on creative style, audience demographic, and key converted brand categories..."
              className="w-full bg-[#070D18] border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37] transition resize-none"
            />
          </div>

          {/* Features check badges */}
          <div className="p-3.5 bg-[#0F1C30]/50 border border-white/5 rounded-xl flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-emerald-400 font-mono text-[10px]">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Auto-generates verified W-9 file record</span>
            </div>
            <div className="flex items-center gap-2 text-[#D4AF37] font-mono text-[10px]">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>Instantly available in Casting & Brand Matching</span>
            </div>
          </div>
        </form>

        {/* Footer actions */}
        <div className="p-4 bg-[#09101D] border-t border-white/10 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/5 rounded-xl transition"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="px-5 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#B38E22] hover:from-[#c49f27] hover:to-[#9e7c1c] text-[#0A1220] font-bold text-xs rounded-xl shadow-lg hover:shadow-xl transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            {isSubmitting ? 'Registering Talent...' : 'Add Creator to Roster'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuickAddCreatorModal;
