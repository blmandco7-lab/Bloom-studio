import React, { useState } from 'react';
import { FileText, Download, X, Eye, ZoomIn, ZoomOut, RotateCw, ExternalLink, ShieldCheck, ChevronLeft, ChevronRight, File, Image as ImageIcon } from 'lucide-react';

export interface ViewableFile {
  name: string;
  url?: string;
  dataUrl?: string;
  size?: string;
  type?: string;
  category?: string;
  description?: string;
  signedDate?: string;
}

interface MultiFilePdfViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  files: ViewableFile[];
  initialIndex?: number;
  onDownload?: (file: ViewableFile) => void;
}

export default function MultiFilePdfViewerModal({
  isOpen,
  onClose,
  title = 'Document & Contract Inspection Vault',
  files = [],
  initialIndex = 0,
  onDownload
}: MultiFilePdfViewerModalProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [rotation, setRotation] = useState(0);

  if (!isOpen || files.length === 0) return null;

  const currentFile = files[Math.min(currentIndex, files.length - 1)] || files[0];
  const isPdf = (currentFile.name || '').toLowerCase().endsWith('.pdf') || currentFile.type?.includes('pdf');
  const isImage = (currentFile.name || '').match(/\.(jpg|jpeg|png|gif|webp)$/i) || currentFile.type?.includes('image');
  const fileSource = currentFile.url || currentFile.dataUrl || '';

  const handlePrev = () => {
    setCurrentIndex(prev => (prev > 0 ? prev - 1 : files.length - 1));
    setZoomLevel(100);
    setRotation(0);
  };

  const handleNext = () => {
    setCurrentIndex(prev => (prev < files.length - 1 ? prev + 1 : 0));
    setZoomLevel(100);
    setRotation(0);
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload(currentFile);
      return;
    }

    if (fileSource) {
      const link = document.createElement('a');
      link.href = fileSource;
      link.download = currentFile.name || 'document.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="bg-[#0B1528] border border-white/10 rounded-2xl w-full max-w-5xl h-[90vh] max-h-[920px] flex flex-col shadow-2xl overflow-hidden relative">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-[#0D1830]">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-[#C9A46A]/20 border border-[#C9A46A]/30 text-[#C9A46A] flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-serif font-bold text-white truncate">
                  {title}
                </h3>
                <span className="text-[10px] font-mono bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded font-bold shrink-0">
                  <ShieldCheck className="w-3 h-3 inline mr-1" /> SECURE PREVIEW
                </span>
              </div>
              <p className="text-[11px] text-[#7C8AA8] truncate">
                File {currentIndex + 1} of {files.length}: <strong className="text-slate-300">{currentFile.name}</strong> {currentFile.size ? `(${currentFile.size})` : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Download Button */}
            <button
              type="button"
              onClick={handleDownload}
              className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-slate-200 hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Download Current File"
            >
              <Download className="w-3.5 h-3.5 text-[#C9A46A]" />
              <span className="hidden sm:inline">Download</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
              title="Close Viewer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Multi-File Tab Selector (if multiple files) */}
        {files.length > 1 && (
          <div className="flex items-center gap-2 px-4 py-2 bg-[#091122] border-b border-white/5 overflow-x-auto text-xs">
            <span className="text-[10px] font-mono uppercase text-[#7C8AA8] shrink-0 mr-1">Files:</span>
            {files.map((file, idx) => (
              <button
                key={`${file.name}_${idx}`}
                type="button"
                onClick={() => {
                  setCurrentIndex(idx);
                  setZoomLevel(100);
                  setRotation(0);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                  idx === currentIndex
                    ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-md'
                    : 'bg-[#111E33] text-slate-300 hover:bg-[#16243F] hover:text-white border border-white/5'
                }`}
              >
                {file.name.toLowerCase().endsWith('.pdf') ? (
                  <FileText className="w-3.5 h-3.5" />
                ) : (
                  <ImageIcon className="w-3.5 h-3.5" />
                )}
                <span className="max-w-[160px] truncate">{file.name}</span>
                {file.size && <span className="opacity-70 text-[10px]">({file.size})</span>}
              </button>
            ))}
          </div>
        )}

        {/* Controls Ribbon (Zoom & Rotate) */}
        <div className="flex items-center justify-between px-4 py-2 bg-[#0C172E] border-b border-white/5 text-xs text-[#7C8AA8]">
          <div className="flex items-center gap-2">
            {files.length > 1 && (
              <div className="flex items-center gap-1 bg-[#111E33] border border-white/10 rounded-lg p-0.5">
                <button
                  type="button"
                  onClick={handlePrev}
                  className="p-1 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
                  title="Previous Document"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-[11px] font-mono px-2 text-slate-300">
                  {currentIndex + 1} / {files.length}
                </span>
                <button
                  type="button"
                  onClick={handleNext}
                  className="p-1 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
                  title="Next Document"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
            <span className="text-[11px] hidden sm:inline text-slate-400">
              Format: <strong className="text-slate-300 uppercase">{currentFile.type || (isPdf ? 'PDF Document' : isImage ? 'Image' : 'Document')}</strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setZoomLevel(prev => Math.max(50, prev - 15))}
              className="p-1.5 bg-[#111E33] hover:bg-[#16243F] border border-white/10 rounded-lg text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono text-[11px] text-slate-300 w-12 text-center">{zoomLevel}%</span>
            <button
              type="button"
              onClick={() => setZoomLevel(prev => Math.min(200, prev + 15))}
              className="p-1.5 bg-[#111E33] hover:bg-[#16243F] border border-white/10 rounded-lg text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setRotation(prev => (prev + 90) % 360)}
              className="p-1.5 bg-[#111E33] hover:bg-[#16243F] border border-white/10 rounded-lg text-slate-300 hover:text-white transition-colors cursor-pointer ml-1"
              title="Rotate 90°"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setZoomLevel(100);
                setRotation(0);
              }}
              className="px-2 py-1 bg-[#111E33] hover:bg-[#16243F] border border-white/10 rounded-lg text-[10px] text-slate-300 hover:text-white transition-colors cursor-pointer ml-1"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Document Content Viewport */}
        <div className="flex-1 bg-[#070D18] overflow-auto flex items-center justify-center p-4 relative">
          {fileSource ? (
            isPdf ? (
              <div 
                className="w-full h-full flex items-center justify-center transition-transform duration-200"
                style={{
                  transform: `scale(${zoomLevel / 100}) rotate(${rotation}deg)`,
                  transformOrigin: 'center center'
                }}
              >
                <object
                  data={`${fileSource}#toolbar=0&navpanes=0&scrollbar=1`}
                  type="application/pdf"
                  className="w-full h-full rounded-xl border border-white/10 shadow-2xl bg-white"
                >
                  <iframe
                    src={fileSource}
                    title={currentFile.name}
                    className="w-full h-full rounded-xl border border-white/10 bg-white"
                  />
                </object>
              </div>
            ) : isImage ? (
              <div 
                className="max-w-full max-h-full flex items-center justify-center transition-transform duration-200"
                style={{
                  transform: `scale(${zoomLevel / 100}) rotate(${rotation}deg)`,
                  transformOrigin: 'center center'
                }}
              >
                <img
                  src={fileSource}
                  alt={currentFile.name}
                  className="max-w-full max-h-[70vh] object-contain rounded-lg border border-white/10 shadow-2xl bg-[#0B1528]"
                  referrerPolicy="no-referrer"
                />
              </div>
            ) : (
              <div className="text-center p-8 bg-[#0D1830] border border-white/10 rounded-2xl max-w-md space-y-4 shadow-xl">
                <File className="w-12 h-12 text-[#C9A46A] mx-auto" />
                <div>
                  <h4 className="text-base font-bold text-white">{currentFile.name}</h4>
                  <p className="text-xs text-[#7C8AA8] mt-1">Binary document record stored in encrypted vault.</p>
                </div>
                <button
                  type="button"
                  onClick={handleDownload}
                  className="px-4 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold rounded-xl text-xs flex items-center gap-2 mx-auto cursor-pointer shadow-md"
                >
                  <Download className="w-4 h-4" /> Download File Directly
                </button>
              </div>
            )
          ) : (
            <div className="text-center p-8 bg-[#0D1830] border border-white/10 rounded-2xl max-w-md space-y-4 shadow-xl">
              <FileText className="w-12 h-12 text-[#C9A46A] mx-auto opacity-70" />
              <div>
                <h4 className="text-base font-bold text-white">{currentFile.name}</h4>
                <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
                  Electronic legal document record verified by Agency Lead.
                </p>
                {currentFile.description && (
                  <p className="text-[11px] text-slate-300 mt-2 bg-[#111E33] p-2.5 rounded-lg border border-white/5">
                    {currentFile.description}
                  </p>
                )}
              </div>
              <button
                type="button"
                onClick={handleDownload}
                className="px-4 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold rounded-xl text-xs flex items-center gap-2 mx-auto cursor-pointer shadow-md"
              >
                <Download className="w-4 h-4" /> Generate Printable PDF
              </button>
            </div>
          )}
        </div>

        {/* Footer Info */}
        <div className="px-5 py-2.5 bg-[#0D1830] border-t border-white/10 flex flex-wrap items-center justify-between text-[11px] text-[#7C8AA8]">
          <div className="flex items-center gap-2">
            <span>Security: <strong className="text-emerald-400 font-mono">AES-256 Encrypted</strong></span>
            <span>&bull;</span>
            <span>Access: <strong className="text-amber-300">Strict Role Scoped (ABAC)</strong></span>
          </div>
          <div className="font-mono text-[10px] text-slate-500">
            Confidential Document Inspection &bull; Bloom Agency Legal Vault
          </div>
        </div>
      </div>
    </div>
  );
}
