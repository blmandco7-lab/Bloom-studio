import React, { useState } from 'react';
import { UploadCloud, Music, AlertTriangle, CheckCircle2, ShieldCheck, Film, RefreshCw, Volume2, Flag } from 'lucide-react';

export interface ScanResult {
  fileName: string;
  fileSize: string;
  audioAnalysis: {
    status: 'Cleared' | 'Unlicensed Music Flagged';
    trackName?: string;
    artist?: string;
    details: string;
  };
  trademarkAnalysis: {
    status: 'Cleared' | 'Competitor Logo Detected';
    details: string;
  };
  overallSafety: 'Cleared for Paid Brand Usage' | 'Muted Audio Track Detected';
}

export default function CopyrightAudioScanner() {
  const [isDragging, setIsDragging] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);

  const simulateScan = (fileName: string) => {
    setIsScanning(true);
    setScanResult(null);

    setTimeout(() => {
      // Simulate realistic safety scan
      const isClean = !fileName.toLowerCase().includes('violation');

      setScanResult({
        fileName: fileName || 'raw_ugc_draft_v1.mp4',
        fileSize: '48.2 MB (4K 60fps)',
        audioAnalysis: isClean
          ? {
              status: 'Cleared',
              trackName: 'Bloom Studio Royalty-Free Commercial Library #84',
              artist: 'Licensed Sync Agreement',
              details: 'Zero unlicensed commercial audio fingerprints identified across Universal / Sony / Warner registry.'
            }
          : {
              status: 'Unlicensed Music Flagged',
              trackName: 'Top 40 Commercial Pop Track (Unlicensed)',
              artist: 'Major Label Copyright',
              details: 'Unlicensed commercial audio fingerprint detected at 00:14-00:45. Ineligible for paid ad whitelisting.'
            },
        trademarkAnalysis: isClean
          ? {
              status: 'Cleared',
              details: 'Zero unauthorized competitor logos or protected trademarked signage found in video frames.'
            }
          : {
              status: 'Competitor Logo Detected',
              details: 'Competitor beverage label visible on studio table background at frame 00:22.'
            },
        overallSafety: isClean ? 'Cleared for Paid Brand Usage' : 'Muted Audio Track Detected'
      });
      setIsScanning(false);
    }, 1800);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      simulateScan(e.dataTransfer.files[0].name);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      simulateScan(e.target.files[0].name);
    }
  };

  return (
    <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-2xl text-agency-textLight space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Digital Asset Protection
            </span>
            <span className="text-xs text-emerald-400 font-mono">
              Sync &amp; Trademark Engine
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white mt-1.5">
            Technical Copyright &amp; Audio Scanner
          </h2>
          <p className="text-xs text-slate-400">
            Verify raw video drafts for commercial sound clearances, whitelisting eligibility, and competitor trademark conflicts.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-300 bg-agency-navy px-3.5 py-1.5 rounded-xl border border-white/10">
          <ShieldCheck className="w-4 h-4 text-agency-gold" />
          <span>Meta &amp; TikTok Ad Sync</span>
        </div>
      </div>

      {/* Asset Upload Zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer ${
          isDragging
            ? 'border-agency-gold bg-agency-navy/80 scale-[1.01]'
            : 'border-white/15 bg-agency-navy/40 hover:border-agency-gold/50'
        }`}
      >
        <input
          type="file"
          id="video-draft-upload"
          accept=".mp4,.mov,.m4v"
          onChange={handleFileInput}
          className="hidden"
        />
        <label htmlFor="video-draft-upload" className="cursor-pointer block space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-agency-navyLight border border-white/10 text-agency-gold flex items-center justify-center mx-auto shadow-inner">
            <UploadCloud className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">
              Upload Raw Video Draft for Technical Copyright Scan (.mp4, .mov)
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Drag &amp; drop talent video submissions or click to browse local files
            </p>
          </div>
          <div className="inline-block text-[11px] font-mono text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-1 rounded-lg">
            Scan Audio Waveforms &bull; OCR Trademark Detection
          </div>
        </label>
      </div>

      {/* Quick Test Action */}
      {!isScanning && !scanResult && (
        <div className="flex items-center justify-center gap-3">
          <span className="text-xs text-slate-400">Quick Test Simulation:</span>
          <button
            type="button"
            onClick={() => simulateScan('ava_glowlab_ugc_final_cut.mp4')}
            className="text-xs font-mono bg-agency-navy border border-agency-gold/30 hover:border-agency-gold text-agency-gold px-3 py-1.5 rounded-xl transition-all cursor-pointer"
          >
            Simulate Clean UGC Asset
          </button>
          <button
            type="button"
            onClick={() => simulateScan('paws_unlicensed_audio_violation.mov')}
            className="text-xs font-mono bg-agency-navy border border-amber-500/30 hover:border-amber-500 text-amber-400 px-3 py-1.5 rounded-xl transition-all cursor-pointer"
          >
            Simulate Flagged Audio Draft
          </button>
        </div>
      )}

      {/* Scanning State */}
      {isScanning && (
        <div className="bg-agency-navy border border-agency-gold/30 rounded-2xl p-6 text-center space-y-3">
          <RefreshCw className="w-8 h-8 text-agency-gold animate-spin mx-auto" />
          <h4 className="text-sm font-bold text-white">
            Running Multi-Track Audio &amp; Frame Trademark Scanner...
          </h4>
          <p className="text-xs text-slate-400 font-mono">
            Extracting audio spectrograms &bull; Checking Meta &amp; ByteDance Commercial Whitelist Registries
          </p>
        </div>
      )}

      {/* Visual Verification Checklist */}
      {scanResult && !isScanning && (
        <div className="bg-agency-navy border border-white/10 rounded-2xl p-5 space-y-4 shadow-xl">
          {/* File Meta Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
            <div className="flex items-center gap-2.5">
              <Film className="w-5 h-5 text-agency-gold" />
              <div>
                <span className="text-xs font-bold text-white font-mono">{scanResult.fileName}</span>
                <span className="text-[11px] text-slate-400 block font-mono">{scanResult.fileSize}</span>
              </div>
            </div>

            {/* Overall Visual Safety Status */}
            <div>
              {scanResult.overallSafety === 'Cleared for Paid Brand Usage' ? (
                <span className="inline-flex items-center gap-1.5 text-xs font-bold font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 px-3.5 py-1.5 rounded-xl shadow-md">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  {scanResult.overallSafety}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-xs font-bold font-mono text-amber-400 bg-amber-950/60 border border-amber-500/40 px-3.5 py-1.5 rounded-xl shadow-md">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  {scanResult.overallSafety}
                </span>
              )}
            </div>
          </div>

          {/* Verification Items */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 1. Audio Track Analysis */}
            <div className="bg-agency-navyLight border border-white/10 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-agency-gold" /> Audio Track Analysis
                </span>
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${
                    scanResult.audioAnalysis.status === 'Cleared'
                      ? 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30'
                      : 'bg-amber-950/60 text-amber-400 border-amber-500/30'
                  }`}
                >
                  {scanResult.audioAnalysis.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                <strong>Track Identified:</strong> {scanResult.audioAnalysis.trackName} ({scanResult.audioAnalysis.artist})
              </p>
              <p className="text-[11px] text-slate-400">
                {scanResult.audioAnalysis.details}
              </p>
            </div>

            {/* 2. Logo & Trademark Flags */}
            <div className="bg-agency-navyLight border border-white/10 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <Flag className="w-4 h-4 text-agency-gold" /> Logo &amp; Trademark Flags
                </span>
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${
                    scanResult.trademarkAnalysis.status === 'Cleared'
                      ? 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30'
                      : 'bg-amber-950/60 text-amber-400 border-amber-500/30'
                  }`}
                >
                  {scanResult.trademarkAnalysis.status}
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                <strong>Visual Frame Scan:</strong> {scanResult.trademarkAnalysis.status === 'Cleared' ? 'Pass (0 Conflicts)' : '1 Unintended Mark Found'}
              </p>
              <p className="text-[11px] text-slate-400">
                {scanResult.trademarkAnalysis.details}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
