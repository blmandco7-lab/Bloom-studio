import React, { useState, useEffect } from 'react';
import { Users, Building, Plus, Mail, DollarSign, Briefcase, Search, CheckCircle, Edit3, Trash2, Shield, Phone, MessageSquare, Ticket, FileText, ExternalLink, Layers, UserCheck, Filter, Zap } from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';
import { addBrandToGlobalBlacklist, removeBrandFromGlobalBlacklist } from '../lib/blacklistService';

interface BrandCrmProps {
  currentUser?: any;
  currentRole?: string;
  deals?: any[];
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
  onNavigate?: (screen: string) => void;
}

export default function BrandCrm({
  currentUser,
  currentRole,
  deals = [],
  onAddActivityLog,
  triggerNotification,
  onNavigate
}: BrandCrmProps) {
  // 1. Brands (Brand Profile: Name, Logo, Industry, Owner_ID, status, escrowPreference, notes)
  const [brands, setBrands] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("studio_brand_crm_brands");
      if (saved !== null) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {}
    return [
      { id: 'br_nike', name: 'Nike Athletics', logo: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=100&auto=format&fit=crop&q=80', industry: 'Sportswear & Fitness', ownerId: currentUser?.id || 'agent_01', status: 'Active Partner', escrowPreference: '100% Pre-funded Escrow', notes: 'Primary corporate AP billing contact.' },
      { id: 'br_gymshark', name: 'Gymshark', logo: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=100&auto=format&fit=crop&q=80', industry: 'Apparel & Athleisure', ownerId: currentUser?.id || 'agent_01', status: 'Active Partner', escrowPreference: '100% Pre-funded Escrow', notes: 'Prefers TikTok & IG Reels bundles.' },
      { id: 'br_aloyoga', name: 'Alo Yoga', logo: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=100&auto=format&fit=crop&q=80', industry: 'Wellness & Lifestyle', ownerId: currentUser?.id || 'agent_01', status: 'Contracted', escrowPreference: '100% Pre-funded Escrow', notes: 'Monthly recurring retainers.' }
    ];
  });

  // 2. Contacts / Customers (Linked via brandId foreign key)
  const [contacts, setContacts] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("studio_brand_crm_contacts");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [
      { id: 'ct_1', brandId: 'br_nike', name: 'Sarah Lin', title: 'VP Partnerships', email: 'sarah.lin@nike.com', phone: '+1 (555) 234-5678' },
      { id: 'ct_2', brandId: 'br_nike', name: 'David Miller', title: 'Influencer Marketing Director', email: 'd.miller@nike.com', phone: '+1 (555) 345-6789' },
      { id: 'ct_3', brandId: 'br_gymshark', name: 'Alex Rivera', title: 'Global Campaign Lead', email: 'alex.rivera@gymshark.com', phone: '+1 (555) 890-1234' },
      { id: 'ct_4', brandId: 'br_aloyoga', name: 'Jessica Vance', title: 'Talent Coordinator', email: 'jessica@aloyoga.com', phone: '+1 (555) 456-7890' }
    ];
  });

  // 3. Communications / Activities (Linked to both customerId and brandId)
  const [communications, setCommunications] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("studio_brand_crm_comms");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [
      { id: 'comm_1', brandId: 'br_nike', customerId: 'ct_1', type: 'Email', summary: 'Q3 Creator roster pitch sent & approved', date: '2026-09-10' },
      { id: 'comm_2', brandId: 'br_nike', customerId: 'ct_2', type: 'Call', summary: 'Escrow funding verified for AirMax launch', date: '2026-09-12' },
      { id: 'comm_3', brandId: 'br_gymshark', customerId: 'ct_3', type: 'Meeting', summary: 'Reviewed deliverables for Black Friday campaign', date: '2026-09-11' }
    ];
  });

  // 4. Support Tickets (Filtered by brandId)
  const [tickets, setTickets] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("studio_brand_crm_tickets");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [
      { id: 'tkt_1', brandId: 'br_nike', subject: 'Invoice #402 Net-30 Wire Confirmation', status: 'Resolved', priority: 'High', date: '2026-09-08' },
      { id: 'tkt_2', brandId: 'br_nike', subject: 'Additional usage rights endorsement rider', status: 'In Progress', priority: 'Medium', date: '2026-09-13' },
      { id: 'tkt_3', brandId: 'br_gymshark', subject: 'Product sample fulfillment tracking check', status: 'Open', priority: 'Low', date: '2026-09-14' }
    ];
  });

  // 5. Activity Logs (Automatic recording of manual updates, email sends, system notifications)
  const [activityLogs, setActivityLogs] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("studio_brand_crm_activity_logs");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [
      { id: 'act_1', brandId: 'br_nike', type: 'Email Send', details: 'Sent Q3 Creator roster pitch & execution deck to Sarah Lin', timestamp: '2026-09-10 14:32', author: 'Sarah (Agent)' },
      { id: 'act_2', brandId: 'br_nike', type: 'Manual Update', details: 'Verified 100% pre-funded escrow wire transfer for AirMax campaign', timestamp: '2026-09-12 11:15', author: 'Director' },
      { id: 'act_3', brandId: 'br_gymshark', type: 'System Notification', details: 'Automated 30-day health check: Brand record updated successfully', timestamp: '2026-09-11 09:00', author: 'System' }
    ];
  });

  const recordBrandActivity = (brandId: string, type: 'Manual Update' | 'Email Send' | 'System Notification', details: string) => {
    const newEntry = {
      id: 'act_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      brandId,
      type,
      details,
      timestamp: new Date().toLocaleString(),
      author: currentUser?.name || currentRole || 'System Agent'
    };
    setActivityLogs(prev => {
      const updated = [newEntry, ...prev];
      try {
        safeStorage.setItem("studio_brand_crm_activity_logs", JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const [selectedBrandId, setSelectedBrandId] = useState<string>('br_nike');
  const [searchTerm, setSearchTerm] = useState('');
  const [crmFilter, setCrmFilter] = useState<'all' | 'active' | 'blocked'>('all');
  const [filterDateRange, setFilterDateRange] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterBudget, setFilterBudget] = useState<string>('all');
  const [showQuickAddBrandModal, setShowQuickAddBrandModal] = useState(false);
  const [quickBrandForm, setQuickBrandForm] = useState({
    name: '',
    industry: 'Apparel & Lifestyle',
    contactEmail: ''
  });

  const handleQuickAddBrand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickBrandForm.name) return;
    const brandId = `br_${Date.now()}`;
    const newBrand = {
      id: brandId,
      name: quickBrandForm.name,
      logo: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=100&auto=format&fit=crop&q=80',
      industry: quickBrandForm.industry,
      ownerId: currentUser?.id || 'agent_01',
      status: 'Active Partner',
      escrowPreference: '100% Pre-funded Escrow',
      notes: 'Quick-onboarded via Brand CRM Dashboard'
    };

    const updatedBrands = [newBrand, ...brands];
    setBrands(updatedBrands);
    safeStorage.setItem("studio_brand_crm_brands", JSON.stringify(updatedBrands));

    if (quickBrandForm.contactEmail) {
      const newContact = {
        id: `ct_${Date.now()}`,
        brandId: brandId,
        name: quickBrandForm.name + ' Representative',
        title: 'Partnerships Lead',
        email: quickBrandForm.contactEmail,
        phone: '+1 (555) 019-2834'
      };
      const updatedContacts = [newContact, ...contacts];
      setContacts(updatedContacts);
      safeStorage.setItem("studio_brand_crm_contacts", JSON.stringify(updatedContacts));
    }

    setSelectedBrandId(brandId);
    setShowQuickAddBrandModal(false);
    setQuickBrandForm({ name: '', industry: 'Apparel & Lifestyle', contactEmail: '' });

    if (triggerNotification) triggerNotification("Brand Quick Onboarded", `Successfully added ${newBrand.name} to CRM.`, "success");
    if (onAddActivityLog) onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Quick-added brand partner: ${newBrand.name}`);
    recordBrandActivity(brandId, 'Manual Update', `Quick brand onboarding for ${newBrand.name}`);
  };

  // 30-day brand inactivity check & reminder task generator for Daily Briefing
  useEffect(() => {
    const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    const inactiveTasks: any[] = [];
    let notified = false;

    brands.forEach(brand => {
      const brandComms = communications.filter(c => c.brandId === brand.id);
      let lastContactTime = brand.updatedAt ? new Date(brand.updatedAt).getTime() : 0;
      
      brandComms.forEach(c => {
        const cTime = c.date ? new Date(c.date).getTime() : 0;
        if (cTime > lastContactTime) lastContactTime = cTime;
      });

      if (lastContactTime === 0) {
        // If brand has no recent update/contact record, evaluate as >30 days inactive
        lastContactTime = now - (35 * 24 * 60 * 60 * 1000);
      }

      const elapsedMs = now - lastContactTime;
      if (elapsedMs > THIRTY_DAYS_MS) {
        const daysAgo = Math.floor(elapsedMs / (24 * 60 * 60 * 1000));
        inactiveTasks.push({
          id: `inactive_brand_${brand.id}`,
          text: `Follow up with inactive brand: ${brand.name} (No contact or update in ${daysAgo} days)`,
          badge: `${daysAgo}d Inactive`,
          badgeColor: 'amber',
          completed: false,
          relatedScreen: 'brand-crm'
        });

        if (triggerNotification && !notified) {
          triggerNotification(
            'Brand Inactivity Alert',
            `"${brand.name}" has not been updated or contacted in over 30 days (${daysAgo} days). Reminder task created in Daily Briefing.`,
            'warning'
          );
          notified = true;
        }
      }
    });

    try {
      safeStorage.setItem('bloom_brand_crm_inactive_tasks', JSON.stringify(inactiveTasks));
    } catch (e) {}
  }, [brands, communications]);
  
  // Modals state
  const [showAddBrandModal, setShowAddBrandModal] = useState(false);
  const [showAddContactModal, setShowAddContactModal] = useState(false);
  const [showAddCommModal, setShowAddCommModal] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any | null>(null);
  const [brandToDelete, setBrandToDelete] = useState<any | null>(null);

  // Form states with complete brand profile attributes + initial contact person
  const [brandForm, setBrandForm] = useState({
    name: '',
    logo: '',
    industry: 'Sportswear & Apparel',
    ownerId: currentUser?.id || 'agent_01',
    status: 'Active Partner',
    escrowPreference: '100% Pre-funded Escrow',
    notes: '',
    // Initial contact person info
    contactName: '',
    contactTitle: '',
    contactEmail: '',
    contactPhone: ''
  });

  const [contactForm, setContactForm] = useState({ name: '', title: '', email: '', phone: '' });
  const [commForm, setCommForm] = useState({ customerId: '', type: 'Email', summary: '' });

  const handleResolveTicket = (ticketId: string) => {
    const ticket = tickets.find(t => t.id === ticketId);
    const updated = tickets.map(t => t.id === ticketId ? { ...t, status: 'Resolved' } : t);
    setTickets(updated);
    safeStorage.setItem("studio_brand_crm_tickets", JSON.stringify(updated));
    setSelectedTicket(null);
    if (ticket) {
      recordBrandActivity(ticket.brandId, 'System Notification', `Support ticket resolved: ${ticket.subject}`);
    }
    if (triggerNotification) triggerNotification("Ticket Resolved", "Support ticket status updated to Resolved.", "success");
    if (onAddActivityLog) onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Resolved support ticket ID: ${ticketId}`);
  };

  const handleToggleBlockBrand = async (brandId: string) => {
    const brand = brands.find(b => b.id === brandId);
    if (!brand) return;
    const isCurrentlyBlocked = brand.status === 'Blocked' || brand.status === 'Do Not Work';
    const newStatus = isCurrentlyBlocked ? 'Active Partner' : 'Blocked';
    
    const updated = brands.map(b => b.id === brandId ? { ...b, status: newStatus } : b);
    setBrands(updated);
    safeStorage.setItem("studio_brand_crm_brands", JSON.stringify(updated));
    recordBrandActivity(brandId, 'System Notification', `Brand status changed to ${newStatus} (Blacklist sync updated)`);

    if (!isCurrentlyBlocked) {
      // Blocking the brand
      try {
        await addBrandToGlobalBlacklist({
          brand: brand.name,
          reason: brand.notes || 'Blocked via Brand CRM Relationship Matrix',
          blockedBy: currentUser?.name || 'Agency Director',
          tenantId: currentUser?.tenantId || 'bloom_studio_default'
        });
      } catch (e) {}
    } else {
      // Unblocking the brand: remove by brand name AND by ID from global blacklist
      try {
        await removeBrandFromGlobalBlacklist(brand.name);
      } catch (e) {}
      try {
        await removeBrandFromGlobalBlacklist(brand.id);
      } catch (e) {}

      // Clean inactive tasks storage
      try {
        const savedInactive = safeStorage.getItem('bloom_brand_crm_inactive_tasks');
        if (savedInactive) {
          const list = JSON.parse(savedInactive);
          const filtered = list.filter((item: any) => item.brand !== brand.name);
          safeStorage.setItem('bloom_brand_crm_inactive_tasks', JSON.stringify(filtered));
        }
      } catch (_) {}

      // Ensure brand is visible and selected after unblocking
      setCrmFilter('all');
      setSelectedBrandId(brandId);
    }
    
    if (triggerNotification) {
      triggerNotification(
        isCurrentlyBlocked ? "Brand Unblocked" : "Brand Blocked",
        `${brand.name} is now ${isCurrentlyBlocked ? 'an active partner and removed from agency blacklist' : 'blocked & blacklisted in CRM'}.`,
        isCurrentlyBlocked ? "success" : "danger"
      );
    }
    
    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'Agent',
        currentRole || 'agent',
        `${isCurrentlyBlocked ? 'Unblocked' : 'Blocked / banned'} brand partner: ${brand.name}`
      );
    }
  };

  const handleDeleteBrand = (brandId: string) => {
    const brand = brands.find(b => b.id === brandId);
    if (!brand) return;
    setBrandToDelete(brand);
  };

  const confirmDeleteBrand = () => {
    if (!brandToDelete) return;
    const brandId = brandToDelete.id;
    const brandName = brandToDelete.name;

    const updatedBrands = brands.filter(b => b.id !== brandId);
    setBrands(updatedBrands);
    safeStorage.setItem("studio_brand_crm_brands", JSON.stringify(updatedBrands));

    const updatedContacts = contacts.filter(c => c.brandId !== brandId);
    setContacts(updatedContacts);
    safeStorage.setItem("studio_brand_crm_contacts", JSON.stringify(updatedContacts));

    // Also clean up linked communications and tickets
    const updatedComms = communications.filter(comm => comm.brandId !== brandId);
    setCommunications(updatedComms);
    safeStorage.setItem("studio_brand_crm_comms", JSON.stringify(updatedComms));

    const updatedTickets = tickets.filter(t => t.brandId !== brandId);
    setTickets(updatedTickets);
    safeStorage.setItem("studio_brand_crm_tickets", JSON.stringify(updatedTickets));

    // Remove from blacklist if present
    removeBrandFromGlobalBlacklist(brandName).catch(() => {});

    if (selectedBrandId === brandId) {
      setSelectedBrandId(updatedBrands[0]?.id || '');
    }

    if (triggerNotification) triggerNotification("Brand Deleted", `Removed ${brandName} from CRM.`, "info");
    if (onAddActivityLog) onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Deleted brand profile: ${brandName}`);
    setBrandToDelete(null);
  };

  const handleDeleteContact = (contactId: string) => {
    const contact = contacts.find(c => c.id === contactId);
    if (!contact) return;
    const updated = contacts.filter(c => c.id !== contactId);
    setContacts(updated);
    safeStorage.setItem("studio_brand_crm_contacts", JSON.stringify(updated));
    if (triggerNotification) triggerNotification("Contact Removed", `Deleted contact ${contact.name}.`, "info");
  };

  const filteredBrands = brands.filter(b => {
    const isBlocked = b.status === 'Blocked' || b.status === 'Do Not Work';
    const matchesSearch = b.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          b.industry.toLowerCase().includes(searchTerm.toLowerCase());
    if (!matchesSearch) return false;
    if (crmFilter === 'active') return !isBlocked;
    if (crmFilter === 'blocked') return isBlocked;
    return true;
  });

  const activeBrand = brands.find(b => b.id === selectedBrandId) || filteredBrands[0] || brands[0];
  const brandContacts = contacts.filter(c => c.brandId === activeBrand?.id);
  const nowMs = Date.now();
  const parseTime = (dateStr: string) => {
    const t = new Date(dateStr).getTime();
    return isNaN(t) ? nowMs : t;
  };
  const brandDeals = deals.filter(d => (d.brand || '').toLowerCase().includes((activeBrand?.name || '').toLowerCase())).filter(d => {
    if (filterStatus !== 'all' && (d.stage || 'Active').toLowerCase() !== filterStatus.toLowerCase()) return false;
    const val = Number(d.budget || d.value || 0);
    if (filterBudget === 'under10k' && val >= 10000) return false;
    if (filterBudget === '10k_50k' && (val < 10000 || val > 50000)) return false;
    if (filterBudget === '50k_plus' && val <= 50000) return false;
    if (filterDateRange !== 'all') {
      const t = parseTime(d.date || d.createdAt || '2026-01-01');
      const diffDays = (nowMs - t) / (1000 * 60 * 60 * 24);
      if (filterDateRange === '7days' && diffDays > 7) return false;
      if (filterDateRange === '30days' && diffDays > 30) return false;
      if (filterDateRange === '90days' && diffDays > 90) return false;
    }
    return true;
  });
  const brandComms = communications.filter(c => c.brandId === activeBrand?.id);
  const brandTickets = tickets.filter(t => t.brandId === activeBrand?.id).filter(t => {
    if (filterStatus !== 'all' && (t.status || '').toLowerCase() !== filterStatus.toLowerCase()) return false;
    if (filterDateRange !== 'all') {
      const timeVal = parseTime(t.date || '2026-01-01');
      const diffDays = (nowMs - timeVal) / (1000 * 60 * 60 * 24);
      if (filterDateRange === '7days' && diffDays > 7) return false;
      if (filterDateRange === '30days' && diffDays > 30) return false;
      if (filterDateRange === '90days' && diffDays > 90) return false;
    }
    return true;
  });
  const brandActivityLogs = activityLogs.filter(a => a.brandId === activeBrand?.id);

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBrandForm(prev => ({ ...prev, logo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddBrand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandForm.name) return;
    const brandId = `br_${Date.now()}`;
    const newBrand = {
      id: brandId,
      name: brandForm.name,
      logo: brandForm.logo || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=100&auto=format&fit=crop&q=80',
      industry: brandForm.industry,
      ownerId: brandForm.ownerId || currentUser?.id || 'agent_01',
      status: brandForm.status,
      escrowPreference: brandForm.escrowPreference,
      notes: brandForm.notes
    };

    const updatedBrands = [newBrand, ...brands];
    setBrands(updatedBrands);
    safeStorage.setItem("studio_brand_crm_brands", JSON.stringify(updatedBrands));

    // If contact info was provided, create the initial customer contact record linked via brandId foreign key
    let updatedContacts = contacts;
    if (brandForm.contactName) {
      const newContact = {
        id: `ct_${Date.now()}`,
        brandId: brandId,
        name: brandForm.contactName,
        title: brandForm.contactTitle || 'Primary Contact',
        email: brandForm.contactEmail || '',
        phone: brandForm.contactPhone || ''
      };
      updatedContacts = [newContact, ...contacts];
      setContacts(updatedContacts);
      safeStorage.setItem("studio_brand_crm_contacts", JSON.stringify(updatedContacts));
    }

    setSelectedBrandId(brandId);
    setShowAddBrandModal(false);
    setBrandForm({
      name: '',
      logo: '',
      industry: 'Sportswear & Apparel',
      ownerId: currentUser?.id || 'agent_01',
      status: 'Active Partner',
      escrowPreference: '100% Pre-funded Escrow',
      notes: '',
      contactName: '',
      contactTitle: '',
      contactEmail: '',
      contactPhone: ''
    });

    if (triggerNotification) triggerNotification("Brand Created", `Added ${newBrand.name} and primary contact to CRM.`, "success");
    if (onAddActivityLog) onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Created new brand profile: ${newBrand.name}`);
    recordBrandActivity(brandId, 'Manual Update', `Created brand profile & primary contact for ${newBrand.name}`);
  };

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !selectedBrandId) return;
    const newContact = {
      id: `ct_${Date.now()}`,
      brandId: selectedBrandId,
      ...contactForm
    };
    const updated = [newContact, ...contacts];
    setContacts(updated);
    safeStorage.setItem("studio_brand_crm_contacts", JSON.stringify(updated));
    setShowAddContactModal(false);
    setContactForm({ name: '', title: '', email: '', phone: '' });
    if (triggerNotification) triggerNotification("Contact Added", `Linked contact ${newContact.name} to ${activeBrand?.name}.`, "success");
  };

  const handleAddComm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commForm.summary || !selectedBrandId) return;
    const newComm = {
      id: `comm_${Date.now()}`,
      brandId: selectedBrandId,
      customerId: commForm.customerId || brandContacts[0]?.id || 'ct_1',
      type: commForm.type,
      summary: commForm.summary,
      date: new Date().toISOString().split('T')[0]
    };
    const updated = [newComm, ...communications];
    setCommunications(updated);
    safeStorage.setItem("studio_brand_crm_comms", JSON.stringify(updated));
    setShowAddCommModal(false);
    setCommForm({ customerId: '', type: 'Email', summary: '' });
    if (triggerNotification) triggerNotification("Touchpoint Logged", `Recorded communication for ${activeBrand?.name}.`, "success");
    recordBrandActivity(selectedBrandId, commForm.type === 'Email' ? 'Email Send' : 'Manual Update', `Logged ${commForm.type}: ${commForm.summary}`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300" id="brandCrmMain">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#0E1C38] via-[#142850] to-[#0A162B] border border-[#C9A46A]/20 rounded-3xl p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#C9A46A]/10 rounded-xl text-[#C9A46A]">
              <Users className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white tracking-wide">Connected Brand CRM &amp; Relationship Matrix</h1>
          </div>
          <p className="text-xs text-[#B8C0D4]">Relational master ledger linking Brand Profiles, Contacts/Customers, Sales Data &amp; Deals, Communications, and Support Tickets.</p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap shrink-0">
          <button
            type="button"
            id="btn-quick-add-brand-header"
            onClick={() => setShowQuickAddBrandModal(true)}
            className="bg-cyan-500/20 hover:bg-cyan-500/35 text-cyan-300 border border-cyan-500/40 px-4 py-2.5 rounded-xl font-mono text-xs font-bold flex items-center gap-2 shadow-lg transition-all cursor-pointer"
          >
            <Zap className="w-4 h-4 text-cyan-400" /> Quick Add Brand
          </button>
          <button
            onClick={() => setShowAddBrandModal(true)}
            className="bg-[#C9A46A] hover:bg-[#b89358] text-[#0A1220] px-4 py-2.5 rounded-xl font-mono text-xs font-bold flex items-center gap-2 shadow-lg transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" /> Create Brand Profile
          </button>
        </div>
      </div>

      {/* Main Layout: Brand Selector Sidebar + Active Brand Relational Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Brand Selector List */}
        <div className="lg:col-span-4 bg-[#142850] border border-white/10 rounded-3xl p-5 shadow-2xl space-y-4">
          <div className="space-y-2">
            <h3 className="font-serif font-bold text-sm text-white flex items-center gap-2">
              <Building className="w-4 h-4 text-[#C9A46A]" /> Brand Accounts ({filteredBrands.length})
            </h3>
            
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search brands or industry..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white font-mono placeholder:text-slate-500"
              />
            </div>

            {/* Filter Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-[#0B1B3D] p-1 rounded-xl border border-white/5">
              <button
                onClick={() => setCrmFilter('all')}
                className={`text-[10px] font-mono py-1 rounded-lg transition-all font-bold cursor-pointer text-center ${
                  crmFilter === 'all' ? 'bg-[#1D3567] text-white shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setCrmFilter('active')}
                className={`text-[10px] font-mono py-1 rounded-lg transition-all font-bold cursor-pointer text-center ${
                  crmFilter === 'active' ? 'bg-emerald-500/20 text-emerald-300 shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Active
              </button>
              <button
                onClick={() => setCrmFilter('blocked')}
                className={`text-[10px] font-mono py-1 rounded-lg transition-all font-bold cursor-pointer text-center ${
                  crmFilter === 'blocked' ? 'bg-rose-500/20 text-rose-300 shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Blocked
              </button>
            </div>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredBrands.map(b => {
              const isSelected = b.id === selectedBrandId;
              const isBlocked = b.status === 'Blocked' || b.status === 'Do Not Work';
              return (
                <div
                  key={b.id}
                  onClick={() => setSelectedBrandId(b.id)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? isBlocked
                        ? 'bg-rose-950/40 border-rose-500/60 shadow-lg shadow-rose-950/20'
                        : 'bg-[#1D3567] border-[#C9A46A]/60 shadow-lg'
                      : isBlocked
                      ? 'bg-rose-950/15 border-rose-950/50 hover:border-rose-500/30'
                      : 'bg-[#0B1B3D] border-white/5 hover:border-white/15'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img src={b.logo} alt={b.name} className="w-10 h-10 rounded-xl object-cover border border-white/10 shrink-0" />
                    <div className="min-w-0">
                      <div className="font-sans font-bold text-white text-xs truncate">{b.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono truncate">{b.industry}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {isBlocked ? (
                      <button
                        type="button"
                        id={`btn-unblock-brand-${b.id}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleBlockBrand(b.id);
                        }}
                        className="px-2 py-0.5 rounded-md bg-emerald-500/20 hover:bg-emerald-500/35 text-emerald-300 border border-emerald-500/30 text-[9px] font-mono font-bold transition cursor-pointer"
                        title={`Unblock ${b.name}`}
                      >
                        Unblock
                      </button>
                    ) : (
                      <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full ${
                        b.status === 'Active Partner' 
                          ? 'bg-emerald-500/10 text-emerald-400' 
                          : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        {b.status}
                      </span>
                    )}
                    <button
                      type="button"
                      id={`btn-delete-brand-list-${b.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteBrand(b.id);
                      }}
                      className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition cursor-pointer"
                      title={`Delete ${b.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
            {filteredBrands.length === 0 && (
              <div className="text-center py-8 font-mono text-xs text-slate-400 bg-[#0B1B3D] rounded-2xl border border-white/5">
                No brand profiles found.
              </div>
            )}
          </div>
        </div>

        {/* Active Brand Relational Panels */}
        <div className="lg:col-span-8 space-y-6">
          {/* Brand Profile Banner */}
          {activeBrand ? (
            <div className={`bg-[#142850] border rounded-3xl p-6 shadow-2xl space-y-4 ${
              activeBrand.status === 'Blocked' || activeBrand.status === 'Do Not Work' 
                ? 'border-rose-500/30 bg-gradient-to-b from-[#142850] to-[#251016]' 
                : 'border-white/10'
            }`}>
              
              {/* Blocked Brand Warning Alert */}
              {(activeBrand.status === 'Blocked' || activeBrand.status === 'Do Not Work') && (
                <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-4 flex items-center gap-3 text-rose-300">
                  <Shield className="w-6 h-6 text-rose-400 shrink-0" />
                  <div className="text-xs font-mono">
                    <strong className="text-rose-400 block uppercase tracking-wider font-bold">🚫 DO NOT WORK LIST • RESTRICTED ACCESS</strong>
                    This brand has been explicitly blocked and added to our banned blacklist. Do not pitch creators, negotiate active contracts, or approve UGC milestone deliverables.
                  </div>
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div className="flex items-center gap-4">
                  <img src={activeBrand.logo} alt={activeBrand.name} className="w-14 h-14 rounded-2xl object-cover border border-white/20 shadow-md" />
                  <div>
                    <h2 className="text-xl font-serif font-bold text-white">{activeBrand.name}</h2>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono bg-[#C9A46A]/10 text-[#C9A46A] border border-[#C9A46A]/20">
                        {activeBrand.industry}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">Owner ID: {activeBrand.ownerId}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-bold ${
                        activeBrand.status === 'Blocked' || activeBrand.status === 'Do Not Work'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : activeBrand.status === 'Active Partner' 
                          ? 'bg-emerald-500/10 text-emerald-400' 
                          : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        {activeBrand.status}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => {
                      const newStatus = activeBrand.status === 'Contracted' ? 'Active Partner' : 'Contracted';
                      const updated = brands.map(b => b.id === activeBrand.id ? { ...b, status: newStatus } : b);
                      setBrands(updated);
                      safeStorage.setItem("studio_brand_crm_brands", JSON.stringify(updated));
                      recordBrandActivity(activeBrand.id, 'Manual Update', `Brand contracted status changed to: ${newStatus}`);
                      if (triggerNotification) triggerNotification("Status Updated", `${activeBrand.name} status updated to ${newStatus}.`, "success");
                    }}
                    className={`px-3 py-1.5 rounded-xl font-mono text-[10px] font-bold transition-all flex items-center gap-1 border cursor-pointer ${
                      activeBrand.status === 'Contracted'
                        ? 'bg-purple-500/20 hover:bg-purple-500/35 text-purple-300 border-purple-500/40'
                        : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/10'
                    }`}
                  >
                    {activeBrand.status === 'Contracted' ? '✓ Contracted' : 'Mark Contracted'}
                  </button>
                  <span className="text-xs font-mono text-slate-300 bg-[#0B1B3D] px-3 py-1.5 rounded-xl border border-white/10">
                    Escrow: <strong className="text-emerald-400">{activeBrand.escrowPreference}</strong>
                  </span>
                  <button
                    type="button"
                    id="btn-crm-toggle-block-brand"
                    onClick={() => handleToggleBlockBrand(activeBrand.id)}
                    className={`px-3 py-1.5 rounded-xl font-mono text-[10px] font-bold transition-all flex items-center gap-1 border cursor-pointer ${
                      activeBrand.status === 'Blocked' || activeBrand.status === 'Do Not Work'
                        ? 'bg-emerald-500/20 hover:bg-emerald-500/35 text-emerald-300 border-emerald-500/40 shadow'
                        : 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border-rose-500/20'
                    }`}
                  >
                    <Shield className="w-3.5 h-3.5" />
                    {activeBrand.status === 'Blocked' || activeBrand.status === 'Do Not Work' ? 'Unblock Brand' : 'Block / Ban Brand'}
                  </button>
                  <button
                    type="button"
                    id="btn-crm-delete-brand"
                    onClick={() => handleDeleteBrand(activeBrand.id)}
                    className="px-3 py-1.5 rounded-xl font-mono text-[10px] font-bold transition-all flex items-center gap-1 border bg-slate-800/80 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400 border-white/10 hover:border-rose-500/30 cursor-pointer shadow"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete Brand
                  </button>
                </div>
              </div>

              {activeBrand.notes && (
                <p className="text-xs text-slate-300 bg-[#0B1B3D] p-3 rounded-xl border border-white/5 font-mono">
                  <strong>Notes:</strong> {activeBrand.notes}
                </p>
              )}
            </div>
          ) : (
            <div className="bg-[#142850] border border-white/10 rounded-3xl p-10 text-center text-slate-400 font-mono text-xs">
              Select a brand account from the left sidebar to inspect and manage details.
            </div>
          )}

          {/* Brand Deal Inquiries & Analytics Filter Toolbar */}
          {activeBrand && (
            <div className="bg-[#142850] border border-white/10 rounded-3xl p-4 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-[#C9A46A]/10 rounded-xl text-[#C9A46A]">
                  <Filter className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-xs text-white">Deal Inquiries &amp; Pipeline Filter</h4>
                  <p className="text-[10px] text-slate-400 font-mono">Filter active inquiries, tickets &amp; deals by date, status &amp; budget.</p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Date Range Filter */}
                <div className="space-y-0.5">
                  <label className="text-[9px] font-mono text-slate-400 block">Date Range</label>
                  <select
                    value={filterDateRange}
                    onChange={e => setFilterDateRange(e.target.value)}
                    className="bg-[#0B1B3D] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                  >
                    <option value="all">All Time</option>
                    <option value="7days">Past 7 Days</option>
                    <option value="30days">Past 30 Days</option>
                    <option value="90days">Past 90 Days</option>
                  </select>
                </div>

                {/* Status Filter */}
                <div className="space-y-0.5">
                  <label className="text-[9px] font-mono text-slate-400 block">Status / Stage</label>
                  <select
                    value={filterStatus}
                    onChange={e => setFilterStatus(e.target.value)}
                    className="bg-[#0B1B3D] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                  >
                    <option value="all">All Statuses</option>
                    <option value="open">Open / Active</option>
                    <option value="in progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                  </select>
                </div>

                {/* Budget / Value Filter */}
                <div className="space-y-0.5">
                  <label className="text-[9px] font-mono text-slate-400 block">Budget Range</label>
                  <select
                    value={filterBudget}
                    onChange={e => setFilterBudget(e.target.value)}
                    className="bg-[#0B1B3D] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                  >
                    <option value="all">All Budgets</option>
                    <option value="under10k">&lt; $10k</option>
                    <option value="10k_50k">$10k - $50k</option>
                    <option value="50k_plus">$50k+</option>
                  </select>
                </div>

                {(filterDateRange !== 'all' || filterStatus !== 'all' || filterBudget !== 'all') && (
                  <button
                    onClick={() => {
                      setFilterDateRange('all');
                      setFilterStatus('all');
                      setFilterBudget('all');
                    }}
                    className="self-end px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-xl text-[10px] font-mono font-bold transition cursor-pointer mt-4"
                  >
                    Reset Filters
                  </button>
                )}
              </div>
            </div>
          )}

          {/* 1. Contacts / Customers Table (Linked via brandId foreign key) */}
          <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-serif font-bold text-sm text-white flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-cyan-400" /> Contacts &amp; Customers ({brandContacts.length})
              </h3>
              <button
                onClick={() => setShowAddContactModal(true)}
                className="bg-white/5 hover:bg-white/10 text-cyan-300 px-3 py-1.5 rounded-xl font-mono text-[11px] font-bold flex items-center gap-1.5 border border-cyan-500/20 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Link Contact
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-white/10 text-slate-400 text-[10px] uppercase">
                    <th className="py-2.5 px-2">Contact Name</th>
                    <th className="py-2.5 px-2">Title</th>
                    <th className="py-2.5 px-2">Email</th>
                    <th className="py-2.5 px-2">Phone</th>
                    <th className="py-2.5 px-2 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {brandContacts.map(c => (
                    <tr key={c.id} className="hover:bg-white/[0.02]">
                      <td className="py-3 px-2 font-bold text-white">{c.name}</td>
                      <td className="py-3 px-2 text-slate-300">{c.title}</td>
                      <td className="py-3 px-2 text-cyan-300">{c.email}</td>
                      <td className="py-3 px-2 text-slate-400">{c.phone || 'N/A'}</td>
                      <td className="py-3 px-2 text-right">
                        <button
                          onClick={() => handleDeleteContact(c.id)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 transition-all cursor-pointer inline-flex items-center gap-1 text-[10px]"
                          title="Delete Contact"
                        >
                          <Trash2 className="w-3 h-3" /> Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                  {brandContacts.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-500">No contacts linked to this brand yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* 2. Sales Data / Transactions / Deals (Filtered by brandId or name) */}
          <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-serif font-bold text-sm text-white flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" /> Sales Data, Deals &amp; Transactions ({brandDeals.length})
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-white/10 text-slate-400 text-[10px] uppercase">
                    <th className="py-2.5 px-2">Deal / Campaign</th>
                    <th className="py-2.5 px-2">Creator</th>
                    <th className="py-2.5 px-2">Value / Budget</th>
                    <th className="py-2.5 px-2">Stage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {brandDeals.map(d => (
                    <tr key={d.id} className="hover:bg-white/[0.02]">
                      <td className="py-3 px-2 font-bold text-white">{d.title || `${activeBrand?.name} Deal`}</td>
                      <td className="py-3 px-2 text-slate-300">{d.creator || d.creatorHandle || 'Assigned Talent'}</td>
                      <td className="py-3 px-2 text-emerald-400 font-bold">${Number(d.budget || d.value || 0).toLocaleString()}</td>
                      <td className="py-3 px-2">
                        <span className="px-2 py-0.5 rounded-full text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          {d.stage || 'Active'}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {brandDeals.length === 0 && (
                    <tr>
                      <td colSpan={4} className="py-6 text-center text-slate-500">No active deals recorded for this brand.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* 3. Communications & Touchpoints (Linked to both customerId and brandId) */}
          <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-serif font-bold text-sm text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#C9A46A]" /> Communications &amp; Activities ({brandComms.length})
              </h3>
              <button
                onClick={() => setShowAddCommModal(true)}
                className="bg-white/5 hover:bg-white/10 text-[#C9A46A] px-3 py-1.5 rounded-xl font-mono text-[11px] font-bold flex items-center gap-1.5 border border-[#C9A46A]/20 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Log Touchpoint
              </button>
            </div>

            <div className="space-y-2">
              {brandComms.map(c => {
                const contact = contacts.find(x => x.id === c.customerId);
                return (
                  <div key={c.id} className="bg-[#0B1B3D] border border-white/5 p-3.5 rounded-2xl flex items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">{c.type}</span>
                        <span className="text-xs font-bold text-white">{contact ? `${contact.name} (${contact.title})` : 'General Contact'}</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1">{c.summary}</p>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">{c.date}</span>
                  </div>
                );
              })}
              {brandComms.length === 0 && (
                <div className="py-6 text-center text-slate-500 text-xs font-mono">No communication logs recorded for this brand.</div>
              )}
            </div>
          </div>

          {/* 4. Support Tickets (Filtered by brandId) */}
          <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-serif font-bold text-sm text-white flex items-center gap-2">
                  <Ticket className="w-4 h-4 text-amber-400" /> Support Tickets Received ({brandTickets.length})
                </h3>
                <p className="text-[10px] text-slate-400 font-mono">Click any ticket to inspect details and mark as resolved.</p>
              </div>
            </div>

            <div className="space-y-2">
              {brandTickets.map(t => (
                <div
                  key={t.id}
                  onClick={() => setSelectedTicket(t)}
                  className="bg-[#0B1B3D] border border-white/5 p-4 rounded-2xl flex items-center justify-between gap-4 hover:border-[#C9A46A]/50 transition cursor-pointer group"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold ${
                        t.status === 'Resolved' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                      }`}>{t.status}</span>
                      <span className="text-xs font-bold text-white group-hover:text-[#C9A46A] transition">{t.subject}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-mono line-clamp-1">{t.description || 'No additional description provided.'}</p>
                    <span className="text-[10px] text-slate-400 font-mono block">Priority: <strong className="text-[#C9A46A]">{t.priority}</strong> • {t.date}</span>
                  </div>
                  <span className="text-xs font-mono text-cyan-300 bg-cyan-500/10 px-3 py-1 rounded-xl border border-cyan-500/20 shrink-0">
                    {t.status === 'Resolved' ? 'View' : 'Open & Resolve'}
                  </span>
                </div>
              ))}
              {brandTickets.length === 0 && (
                <div className="py-6 text-center text-slate-500 text-xs font-mono">No support tickets or inquiries received from this brand yet.</div>
              )}
            </div>
          </div>

          {/* 5. Activity Log & Audit Trail */}
          <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-serif font-bold text-sm text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-cyan-400" /> Activity Log &amp; Audit Trail ({brandActivityLogs.length})
                </h3>
                <p className="text-[10px] text-slate-400 font-mono">Automatic timestamps and details of manual updates, email sends, or system notifications.</p>
              </div>
            </div>

            <div className="space-y-2">
              {brandActivityLogs.map(act => (
                <div key={act.id} className="bg-[#0B1B3D] border border-white/5 p-3.5 rounded-2xl flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                        act.type === 'Email Send' ? 'bg-sky-500/15 text-sky-300 border border-sky-500/30' :
                        act.type === 'System Notification' ? 'bg-purple-500/15 text-purple-300 border border-purple-500/30' :
                        'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                      }`}>{act.type}</span>
                      <span className="text-xs text-white font-medium">{act.details}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono block">By: <strong className="text-slate-300">{act.author}</strong></span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 shrink-0">{act.timestamp}</span>
                </div>
              ))}
              {brandActivityLogs.length === 0 && (
                <div className="py-6 text-center text-slate-500 text-xs font-mono">No automatic activity logs recorded for this brand yet.</div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Comprehensive Create Brand Profile Modal */}
      {showAddBrandModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#142850] border border-white/10 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 my-8">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-serif font-bold text-base text-white">Create Complete Brand Profile</h3>
                <p className="text-[10px] text-slate-400 font-mono">Enter brand profile details, ownership, and initial primary contact.</p>
              </div>
              <button onClick={() => setShowAddBrandModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddBrand} className="space-y-3 text-xs font-mono max-h-[70vh] overflow-y-auto pr-2">
              <div>
                <label className="text-[10px] text-slate-300 block mb-1">Brand Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Adidas Athletics"
                  value={brandForm.name}
                  onChange={e => setBrandForm({ ...brandForm, name: e.target.value })}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-300 block mb-1">Industry</label>
                  <input
                    type="text"
                    placeholder="e.g. Sportswear"
                    value={brandForm.industry}
                    onChange={e => setBrandForm({ ...brandForm, industry: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-300 block mb-1">Owner ID</label>
                  <input
                    type="text"
                    placeholder="e.g. agent_01"
                    value={brandForm.ownerId}
                    onChange={e => setBrandForm({ ...brandForm, ownerId: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-300 block mb-1">Partnership Status</label>
                  <select
                    value={brandForm.status}
                    onChange={e => setBrandForm({ ...brandForm, status: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  >
                    <option value="Active Partner">Active Partner</option>
                    <option value="Contracted">Contracted</option>
                    <option value="Paused">Paused</option>
                    <option value="Prospect">Prospect</option>
                    <option value="Blocked">Blocked / Do Not Work</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-slate-300 block mb-1">Escrow Preference</label>
                  <select
                    value={brandForm.escrowPreference}
                    onChange={e => setBrandForm({ ...brandForm, escrowPreference: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  >
                    <option value="100% Pre-funded Escrow">100% Pre-funded Escrow</option>
                    <option value="Milestone Escrow">Milestone Escrow</option>
                    <option value="Net-30 Wire">Net-30 Wire</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-300 block mb-1">Logo Image URL or Upload Image</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="https://..."
                    value={brandForm.logo}
                    onChange={e => setBrandForm({ ...brandForm, logo: e.target.value })}
                    className="flex-1 bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2 text-white text-xs"
                  />
                  <label className="bg-white/5 hover:bg-white/10 text-cyan-300 px-3 py-2 rounded-xl text-xs font-mono border border-cyan-500/20 cursor-pointer flex items-center gap-1 shrink-0">
                    Upload
                    <input type="file" accept="image/*" onChange={handleLogoFileChange} className="hidden" />
                  </label>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-300 block mb-1">Relationship Notes</label>
                <textarea
                  placeholder="Corporate AP details, preferences, etc..."
                  value={brandForm.notes}
                  onChange={e => setBrandForm({ ...brandForm, notes: e.target.value })}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white resize-none"
                  rows={2}
                ></textarea>
              </div>

              <div className="border-t border-white/10 pt-3 mt-2">
                <h4 className="text-xs font-bold text-[#C9A46A] mb-2">Initial Contact / Customer (Optional)</h4>
                <div className="grid grid-cols-2 gap-3 mb-2">
                  <input
                    type="text"
                    placeholder="Contact Name"
                    value={brandForm.contactName}
                    onChange={e => setBrandForm({ ...brandForm, contactName: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  />
                  <input
                    type="text"
                    placeholder="Title (e.g. VP Marketing)"
                    value={brandForm.contactTitle}
                    onChange={e => setBrandForm({ ...brandForm, contactTitle: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={brandForm.contactEmail}
                    onChange={e => setBrandForm({ ...brandForm, contactEmail: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  />
                  <input
                    type="text"
                    placeholder="Phone Number"
                    value={brandForm.contactPhone}
                    onChange={e => setBrandForm({ ...brandForm, contactPhone: e.target.value })}
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
                <button type="button" onClick={() => setShowAddBrandModal(false)} className="px-4 py-2 bg-white/5 rounded-xl text-slate-300">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-[#C9A46A] text-[#0A1220] font-bold rounded-xl shadow-lg">Save Brand Profile</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAddContactModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#142850] border border-white/10 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-base text-white">Add Customer / Contact</h3>
              <button onClick={() => setShowAddContactModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleAddContact} className="space-y-3 text-xs font-mono">
              <input
                type="text"
                required
                placeholder="Contact Name"
                value={contactForm.name}
                onChange={e => setContactForm({ ...contactForm, name: e.target.value })}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
              />
              <input
                type="text"
                placeholder="Title (e.g. Marketing Manager)"
                value={contactForm.title}
                onChange={e => setContactForm({ ...contactForm, title: e.target.value })}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
              />
              <input
                type="email"
                placeholder="Email Address"
                value={contactForm.email}
                onChange={e => setContactForm({ ...contactForm, email: e.target.value })}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
              />
              <input
                type="text"
                placeholder="Phone Number"
                value={contactForm.phone}
                onChange={e => setContactForm({ ...contactForm, phone: e.target.value })}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
              />
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddContactModal(false)} className="px-4 py-2 bg-white/5 rounded-xl text-slate-300">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-[#C9A46A] text-[#0A1220] font-bold rounded-xl">Add Contact</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAddCommModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#142850] border border-white/10 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-base text-white">Log Communication Touchpoint</h3>
              <button onClick={() => setShowAddCommModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleAddComm} className="space-y-3 text-xs font-mono">
              <select
                value={commForm.customerId}
                onChange={e => setCommForm({ ...commForm, customerId: e.target.value })}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
              >
                <option value="">Select Contact</option>
                {brandContacts.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.title})</option>
                ))}
              </select>
              <select
                value={commForm.type}
                onChange={e => setCommForm({ ...commForm, type: e.target.value })}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
              >
                <option value="Email">Email</option>
                <option value="Call">Call</option>
                <option value="Meeting">Meeting</option>
                <option value="Slack">Slack / Chat</option>
              </select>
              <textarea
                required
                placeholder="Touchpoint summary..."
                value={commForm.summary}
                onChange={e => setCommForm({ ...commForm, summary: e.target.value })}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white resize-none"
                rows={3}
              ></textarea>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddCommModal(false)} className="px-4 py-2 bg-white/5 rounded-xl text-slate-300">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-[#C9A46A] text-[#0A1220] font-bold rounded-xl">Log Touchpoint</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selectedTicket && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#142850] border border-white/10 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-serif font-bold text-base text-white">Support Ticket Inspector</h3>
                <p className="text-[10px] text-slate-400 font-mono">Brand Inquiry • {selectedTicket.brandName || activeBrand?.name}</p>
              </div>
              <button onClick={() => setSelectedTicket(null)} className="text-slate-400 hover:text-white text-lg">✕</button>
            </div>

            <div className="space-y-3 font-mono text-xs bg-[#0B1B3D] p-4 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between">
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                  selectedTicket.status === 'Resolved' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                }`}>
                  Status: {selectedTicket.status}
                </span>
                <span className="text-[10px] text-slate-400">Date: {selectedTicket.date}</span>
              </div>
              <div className="text-sm font-sans font-bold text-white pt-1">{selectedTicket.subject}</div>
              <div className="text-xs text-slate-300 bg-white/5 p-3 rounded-xl border border-white/10">
                <strong>Description / Details:</strong>
                <p className="mt-1 text-slate-200">{selectedTicket.description || 'No detailed description provided by the brand partner.'}</p>
              </div>
              <div className="text-[10px] text-slate-400">Priority Level: <strong className="text-[#C9A46A]">{selectedTicket.priority}</strong></div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedTicket(null)}
                className="px-4 py-2.5 bg-white/5 hover:bg-white/10 rounded-xl text-slate-300 text-xs font-mono font-bold"
              >
                Close
              </button>
              {selectedTicket.status !== 'Resolved' && (
                <button
                  type="button"
                  onClick={() => handleResolveTicket(selectedTicket.id)}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-[#0A1220] font-bold rounded-xl text-xs font-mono uppercase tracking-wider shadow-lg transition cursor-pointer flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" /> Mark as Resolved
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Brand Delete Confirmation Modal */}
      {brandToDelete && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#142850] border border-rose-500/40 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-serif font-bold text-base text-white flex items-center gap-2">
                  <Trash2 className="w-4 h-4 text-rose-400" /> Confirm Brand Deletion
                </h3>
                <p className="text-[10px] text-slate-400 font-mono">This action will permanently remove this brand profile and linked contacts.</p>
              </div>
              <button 
                type="button" 
                onClick={() => setBrandToDelete(null)} 
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="text-xs font-mono text-slate-300 bg-[#0B1B3D] p-4 rounded-2xl border border-white/5 space-y-2">
              <p>Are you sure you want to delete <strong className="text-white">{brandToDelete.name}</strong>?</p>
              <p className="text-[10px] text-slate-400">All associated contacts, communications, and tickets will also be unlinked.</p>
            </div>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                id="btn-cancel-delete-brand"
                onClick={() => setBrandToDelete(null)}
                className="px-4 py-2.5 bg-white/5 hover:bg-white/10 rounded-xl text-slate-300 text-xs font-mono font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-delete-brand"
                onClick={confirmDeleteBrand}
                className="px-5 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl text-xs font-mono uppercase tracking-wider shadow-lg transition cursor-pointer flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" /> Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Add Brand Modal */}
      {showQuickAddBrandModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#142850] border border-cyan-500/30 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-cyan-500/15 rounded-lg text-cyan-300">
                  <Zap className="w-4 h-4" />
                </div>
                <h3 className="font-serif font-bold text-base text-white">Quick Add Brand</h3>
              </div>
              <button onClick={() => setShowQuickAddBrandModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleQuickAddBrand} className="space-y-3 text-xs font-mono">
              <div>
                <label className="text-[10px] text-slate-300 block mb-1">Brand Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alo Yoga, Gymshark, Nike"
                  value={quickBrandForm.name}
                  onChange={e => setQuickBrandForm({ ...quickBrandForm, name: e.target.value })}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-300 block mb-1">Industry</label>
                <input
                  type="text"
                  placeholder="e.g. Wellness & Apparel"
                  value={quickBrandForm.industry}
                  onChange={e => setQuickBrandForm({ ...quickBrandForm, industry: e.target.value })}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-300 block mb-1">Primary Contact Email (Optional)</label>
                <input
                  type="email"
                  placeholder="partner@brand.com"
                  value={quickBrandForm.contactEmail}
                  onChange={e => setQuickBrandForm({ ...quickBrandForm, contactEmail: e.target.value })}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-white"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
                <button type="button" onClick={() => setShowQuickAddBrandModal(false)} className="px-4 py-2 bg-white/5 rounded-xl text-slate-300">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-cyan-500 hover:bg-cyan-600 text-[#0A1220] font-bold rounded-xl shadow-lg transition">Quick Onboard</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
