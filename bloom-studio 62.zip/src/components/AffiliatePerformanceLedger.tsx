import React, { useState, useMemo } from 'react';
import {
  DollarSign,
  TrendingUp,
  Link2,
  ShoppingBag,
  Percent,
  ArrowUpRight,
  ExternalLink,
  Copy,
  Check,
  Filter,
  Search,
  Download,
  RefreshCw,
  Building2,
  Globe,
  Shield,
  Sparkles,
  Plus,
  CheckCircle2,
  ChevronRight,
  Layers,
  Lock,
  Sliders,
  BarChart3,
  AlertCircle,
  Tag,
  Share2
} from 'lucide-react';
import { Creator, AffiliateTransaction, AffiliateTrackingLink } from '../types';

interface AffiliatePerformanceLedgerProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

const INITIAL_TRACKING_LINKS: AffiliateTrackingLink[] = [
  {
    id: 'link-001',
    creatorId: 'c1',
    creatorName: 'Elena Rostova',
    creatorHandle: '@elenarostova',
    brandName: 'DripRoom Beauty',
    campaignTitle: 'Silk Velvet Lip Stain Launch',
    customUrl: 'bloom.studio/shop/elena-silk',
    discountCode: 'ELENA20',
    discountRate: '20% OFF',
    commissionRateCreator: 15,
    agencyBrandSplitAgencyPercent: 85,
    agencyBrandSplitBrandPercent: 15,
    tenantId: 'main',
    status: 'active',
    totalClicks: 4820,
    totalConversions: 342,
    grossSalesGenerated: 24650.00
  },
  {
    id: 'link-002',
    creatorId: 'c2',
    creatorName: 'Marcus Vance',
    creatorHandle: '@marcusvance',
    brandName: 'GymPulse Apparel',
    campaignTitle: 'Core Compression Fall Drop',
    customUrl: 'bloom.studio/shop/marcus-core',
    discountCode: 'MARCUS15',
    discountRate: '15% OFF',
    commissionRateCreator: 15,
    agencyBrandSplitAgencyPercent: 85,
    agencyBrandSplitBrandPercent: 15,
    tenantId: 'main',
    status: 'active',
    totalClicks: 3190,
    totalConversions: 215,
    grossSalesGenerated: 18420.00
  },
  {
    id: 'link-003',
    creatorId: 'c3',
    creatorName: 'Chloe Bennett',
    creatorHandle: '@chloebennett',
    brandName: 'GlowBar Botanicals',
    campaignTitle: 'Matcha Clarifying Toner',
    customUrl: 'bloom.studio/shop/chloe-glow',
    discountCode: 'PETS20',
    discountRate: '20% OFF',
    commissionRateCreator: 15,
    agencyBrandSplitAgencyPercent: 85,
    agencyBrandSplitBrandPercent: 15,
    tenantId: 'glowlab',
    status: 'active',
    totalClicks: 6240,
    totalConversions: 512,
    grossSalesGenerated: 39800.00
  }
];

const INITIAL_SALES_RECORDS: AffiliateTransaction[] = [
  {
    id: 'tx-881',
    orderId: 'ORD-SHP-99214',
    storefront: 'Shopify',
    timestamp: '2026-08-31 09:14',
    brandName: 'DripRoom Beauty',
    creatorId: 'c1',
    creatorHandle: '@elenarostova',
    creatorName: 'Elena Rostova',
    discountCodeUsed: 'ELENA20',
    trackingLinkUrl: 'bloom.studio/shop/elena-silk',
    customerCity: 'New York, NY',
    itemsCount: 3,
    grossAmount: 180.00,
    agencyGrossSplit: 153.00, // 85%
    brandGrossSplit: 27.00,   // 15%
    creatorCommissionAmount: 27.00, // 15% of gross
    tenantId: 'main',
    status: 'settled'
  },
  {
    id: 'tx-882',
    orderId: 'ORD-TTS-44109',
    storefront: 'TikTok Shop',
    timestamp: '2026-08-31 08:45',
    brandName: 'GlowBar Botanicals',
    creatorId: 'c3',
    creatorName: 'Chloe Bennett',
    creatorHandle: '@chloebennett',
    discountCodeUsed: 'PETS20',
    trackingLinkUrl: 'bloom.studio/shop/chloe-glow',
    customerCity: 'Austin, TX',
    itemsCount: 2,
    grossAmount: 95.00,
    agencyGrossSplit: 80.75, // 85%
    brandGrossSplit: 14.25,
    creatorCommissionAmount: 14.25, // 15%
    tenantId: 'glowlab',
    status: 'settled'
  },
  {
    id: 'tx-883',
    orderId: 'ORD-AMZ-77312',
    storefront: 'Amazon Storefront',
    timestamp: '2026-08-30 22:18',
    brandName: 'GymPulse Apparel',
    creatorId: 'c2',
    creatorName: 'Marcus Vance',
    creatorHandle: '@marcusvance',
    discountCodeUsed: 'MARCUS15',
    trackingLinkUrl: 'bloom.studio/shop/marcus-core',
    customerCity: 'Miami, FL',
    itemsCount: 4,
    grossAmount: 240.00,
    agencyGrossSplit: 204.00, // 85%
    brandGrossSplit: 36.00,
    creatorCommissionAmount: 36.00, // 15%
    tenantId: 'main',
    status: 'settled'
  },
  {
    id: 'tx-884',
    orderId: 'ORD-SHP-99215',
    storefront: 'Shopify',
    timestamp: '2026-08-30 19:30',
    brandName: 'DripRoom Beauty',
    creatorId: 'c1',
    creatorHandle: '@elenarostova',
    creatorName: 'Elena Rostova',
    discountCodeUsed: 'ELENA20',
    trackingLinkUrl: 'bloom.studio/shop/elena-silk',
    customerCity: 'Los Angeles, CA',
    itemsCount: 1,
    grossAmount: 65.00,
    agencyGrossSplit: 55.25,
    brandGrossSplit: 9.75,
    creatorCommissionAmount: 9.75,
    tenantId: 'main',
    status: 'settled'
  }
];

export const AffiliatePerformanceLedger: React.FC<AffiliatePerformanceLedgerProps> = ({
  creators = [],
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}) => {
  const role = (currentRole || '').toLowerCase();
  const isCreator = role === 'creator';
  // ABSOLUTE ADMINISTRATIVE FINANCIAL BLINDSPOTS:
  // If user.role matches Manager, Agent, Coordinator, or Creator, completely omit, mask, and delete
  // the fields tracking agencyGrossRetain and overall net agency margins from the DOM canvas.
  const isExecutiveDirector = role === 'director' || role === 'owner';

  const currentCreatorHandle = currentUser?.handle || '@elenarostova';

  const [masterTrackingUrl, setMasterTrackingUrl] = useState('https://bloom.studio/shop/vip-direct');
  const [customPromoCode, setCustomPromoCode] = useState('PETS20');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const [links, setLinks] = useState<AffiliateTrackingLink[]>(INITIAL_TRACKING_LINKS);
  const [transactions, setTransactions] = useState<AffiliateTransaction[]>(INITIAL_SALES_RECORDS);

  // Filter transactions based on Creator Isolation
  const visibleTransactions = useMemo(() => {
    if (isCreator) {
      return transactions.filter(
        (tx) => tx.creatorHandle.toLowerCase() === currentCreatorHandle.toLowerCase()
      );
    }
    return transactions;
  }, [transactions, isCreator, currentCreatorHandle]);

  // Creator Personal Performance Metrics
  const creatorStats = useMemo(() => {
    const creatorTx = transactions.filter(
      (tx) => tx.creatorHandle.toLowerCase() === currentCreatorHandle.toLowerCase()
    );
    const totalOrders = creatorTx.length;
    const grossRevenue = creatorTx.reduce((acc, curr) => acc + curr.grossAmount, 0);
    const individualCommissionPayout = creatorTx.reduce(
      (acc, curr) => acc + curr.creatorCommissionAmount,
      0
    );

    return {
      totalOrders,
      grossRevenue,
      individualCommissionPayout,
      effectiveRate: 15.0
    };
  }, [transactions, currentCreatorHandle]);

  // Macro Aggregate Metrics
  const macroStats = useMemo(() => {
    const totalGrossSales = transactions.reduce((acc, curr) => acc + curr.grossAmount, 0);
    const totalAgencyRetain = transactions.reduce((acc, curr) => acc + curr.agencyGrossSplit, 0);
    const totalCreatorPayouts = transactions.reduce(
      (acc, curr) => acc + curr.creatorCommissionAmount,
      0
    );
    const totalOrders = transactions.length;

    return {
      totalGrossSales,
      totalAgencyRetain,
      totalCreatorPayouts,
      totalOrders
    };
  }, [transactions]);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(text);
    triggerNotification?.('Copied to Clipboard', `${label}: ${text}`, 'success');
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleInjectOrder = () => {
    const gross = parseFloat((60 + Math.random() * 190).toFixed(2));
    const agencyCut = parseFloat((gross * 0.85).toFixed(2));
    const brandCut = parseFloat((gross * 0.15).toFixed(2));
    const creatorCut = parseFloat((gross * 0.15).toFixed(2));

    const newTx: AffiliateTransaction = {
      id: `tx-${Date.now().toString().slice(-4)}`,
      orderId: `ORD-LIVE-${Math.floor(10000 + Math.random() * 90000)}`,
      storefront: 'Shopify',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      brandName: 'DripRoom Beauty',
      creatorId: 'c1',
      creatorHandle: isCreator ? currentCreatorHandle : '@elenarostova',
      creatorName: 'Elena Rostova',
      discountCodeUsed: customPromoCode.toUpperCase(),
      trackingLinkUrl: masterTrackingUrl,
      customerCity: 'Chicago, IL',
      itemsCount: 2,
      grossAmount: gross,
      agencyGrossSplit: agencyCut,
      brandGrossSplit: brandCut,
      creatorCommissionAmount: creatorCut,
      tenantId: 'main',
      status: 'settled'
    };

    setTransactions((prev) => [newTx, ...prev]);

    triggerNotification?.(
      '⚡ Live Conversion Logged',
      `Order ${newTx.orderId} recorded: $${gross.toFixed(2)} via code ${newTx.discountCodeUsed}`,
      'success'
    );

    onAddActivityLog?.(
      currentUser?.name || 'CRM System',
      currentRole,
      `Affiliate conversion processed for ${newTx.discountCodeUsed}: $${gross.toFixed(2)}`
    );
  };

  return (
    <div id="affiliate-performance-ledger" className="min-h-screen bg-[#0B1B3D] text-slate-100 p-4 sm:p-6 lg:p-8 space-y-8 font-sans">
      {/* Top Title Banner */}
      <div className="bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-2xl text-[#D4AF37]">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-wide">
                  Affiliate Performance Ledger & Commission Engine
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 mt-1">
                  Real-time storefront sales attribution, individual creator commission escrow, and automated webhook ingestion.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleInjectOrder}
              className="px-4 py-2.5 bg-[#0B1B3D] hover:bg-[#1A3260] border border-[#D4AF37]/40 text-[#D4AF37] rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 shadow-md cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Simulate Real-Time Sale</span>
            </button>
            <div className="px-3.5 py-2 bg-[#0B1B3D] border border-white/10 rounded-xl text-xs font-mono text-slate-400">
              Role: <strong className="text-white capitalize">{currentRole}</strong>
            </div>
          </div>
        </div>
      </div>

      {/* CREATOR ESCROW COMMISSION VIEW (TALENT PORTAL VIEW) */}
      {isCreator && (
        <div className="bg-[#142850] border-2 border-[#D4AF37] rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="text-[10px] font-mono text-[#D4AF37] uppercase font-bold tracking-widest">
                Talent Portal Escrow View
              </span>
              <h2 className="text-xl font-serif font-bold text-white mt-0.5">
                My Personal Performance & Commission Escrow
              </h2>
              <p className="text-xs text-slate-300">
                Tracking affiliate sales attributed strictly to your handle ({currentCreatorHandle}).
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold">
              15.0% Guaranteed Cut
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-5 bg-[#0B1B3D] border border-white/10 rounded-2xl space-y-2">
              <span className="text-xs font-mono uppercase text-slate-400 font-bold">Total Orders Driven</span>
              <p className="text-3xl font-bold font-mono text-white">{creatorStats.totalOrders}</p>
              <span className="text-[11px] text-slate-400">Direct storefront transactions</span>
            </div>

            <div className="p-5 bg-[#0B1B3D] border border-white/10 rounded-2xl space-y-2">
              <span className="text-xs font-mono uppercase text-slate-400 font-bold">Gross Referral Revenue</span>
              <p className="text-3xl font-bold font-mono text-white">${creatorStats.grossRevenue.toFixed(2)}</p>
              <span className="text-[11px] text-emerald-400 font-mono">+100% verified conversions</span>
            </div>

            <div className="p-5 bg-[#0B1B3D] border border-[#D4AF37]/40 rounded-2xl space-y-2 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#D4AF37]/10 rounded-full blur-xl pointer-events-none" />
              <span className="text-xs font-mono uppercase text-[#D4AF37] font-bold">15% Individual Commission Payout</span>
              <p className="text-3xl font-bold font-mono text-[#D4AF37]">${creatorStats.individualCommissionPayout.toFixed(2)}</p>
              <span className="text-[11px] text-emerald-400 font-mono">Disbursed directly to card / wallet</span>
            </div>
          </div>
        </div>
      )}

      {/* INTERACTIVE AFFILIATE TRACKING MATRIX (MANAGER & BRAND VIEW) */}
      {!isCreator && (
        <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="flex items-center gap-2">
              <Tag className="w-5 h-5 text-[#D4AF37]" />
              <h2 className="text-base font-bold text-white uppercase tracking-wider text-xs font-mono">
                Interactive Affiliate Tracking Configuration
              </h2>
            </div>
            <span className="text-xs text-slate-400 font-mono">Campaign Attribution Matrix</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
                Master Affiliate Tracking URL
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={masterTrackingUrl}
                  onChange={(e) => setMasterTrackingUrl(e.target.value)}
                  placeholder="https://bloom.studio/shop/vip-direct"
                  className="flex-1 bg-[#0B1B3D] border border-white/15 rounded-2xl px-4 py-3 text-sm text-white font-mono focus:border-[#D4AF37] outline-none"
                />
                <button
                  type="button"
                  onClick={() => handleCopy(masterTrackingUrl, 'Master URL')}
                  className="px-4 py-3 bg-[#0B1B3D] hover:bg-white/10 border border-white/15 text-white rounded-2xl text-xs font-mono flex items-center gap-1.5"
                >
                  {copiedCode === masterTrackingUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-[#D4AF37]">
                Custom Promo Code String
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customPromoCode}
                  onChange={(e) => setCustomPromoCode(e.target.value)}
                  placeholder="e.g. PETS20"
                  className="flex-1 bg-[#0B1B3D] border border-white/15 rounded-2xl px-4 py-3 text-sm text-white font-mono uppercase focus:border-[#D4AF37] outline-none"
                />
                <button
                  type="button"
                  onClick={() => handleCopy(customPromoCode, 'Promo Code')}
                  className="px-4 py-3 bg-[#0B1B3D] hover:bg-white/10 border border-white/15 text-white rounded-2xl text-xs font-mono flex items-center gap-1.5"
                >
                  {copiedCode === customPromoCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* METRIC CARDS ROW WITH STRICT ADMINISTRATIVE FINANCIAL BLINDSPOTS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Metric 1: Total Gross Sales */}
        <div className="bg-[#142850] border border-white/10 rounded-2xl p-6 space-y-2 shadow-xl">
          <span className="text-xs uppercase font-mono text-slate-400 tracking-wider">Gross Sales (GMV)</span>
          <p className="text-3xl font-bold font-mono text-white">
            ${macroStats.totalGrossSales.toFixed(2)}
          </p>
          <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
            <span>{macroStats.totalOrders} total verified orders</span>
            <span className="text-emerald-400 font-semibold">+24.5% MoM</span>
          </div>
        </div>

        {/* Metric 2: Creator Commission Pool */}
        <div className="bg-[#142850] border border-white/10 rounded-2xl p-6 space-y-2 shadow-xl">
          <span className="text-xs uppercase font-mono text-emerald-400 tracking-wider">
            {isCreator ? 'My Commission Earnings' : 'Creator Payouts (15% Share)'}
          </span>
          <p className="text-3xl font-bold font-mono text-emerald-400">
            ${isCreator ? creatorStats.individualCommissionPayout.toFixed(2) : macroStats.totalCreatorPayouts.toFixed(2)}
          </p>
          <p className="text-xs text-slate-400 pt-1">Direct individual creator commission disbursements</p>
        </div>

        {/* Metric 3: PRIVILEGED EXECUTIVE ONLY CARD (agencyGrossRetain & net profit distributions) */}
        {isExecutiveDirector ? (
          <div className="bg-[#142850] border border-[#D4AF37]/40 rounded-2xl p-6 space-y-2 shadow-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-mono text-[#D4AF37] tracking-wider">Agency Retain (85% Pool)</span>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-[#D4AF37]/20 text-[#D4AF37] rounded-full">Director Only</span>
            </div>
            <p className="text-3xl font-bold font-mono text-[#D4AF37]">
              ${macroStats.totalAgencyRetain.toFixed(2)}
            </p>
            <p className="text-xs text-slate-400 pt-1">85/15 agency-to-owner corporate distribution</p>
          </div>
        ) : (
          <div className="bg-[#142850] border border-white/10 rounded-2xl p-6 space-y-2 shadow-xl">
            <span className="text-xs uppercase font-mono text-cyan-400 tracking-wider">Active Campaigns</span>
            <p className="text-3xl font-bold font-mono text-white">
              {links.length} Brand Tracks
            </p>
            <p className="text-xs text-slate-400 pt-1">Live promo codes tracking conversions</p>
          </div>
        )}
      </div>

      {/* READ-ONLY RESPONSIVE DATA GRID TRACKING LIVE SALES */}
      <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2 font-mono">
              <ShoppingBag className="w-5 h-5 text-emerald-400" />
              Live Sales Conversion Ledger
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Verified orders streaming from connected storefronts (Shopify, TikTok Shop, Amazon).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/30">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              Live Pipeline Sync
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-mono text-[10px] uppercase">
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Order ID & Channel</th>
                <th className="py-3 px-4">Associated Creator</th>
                <th className="py-3 px-4">Customer Gross ($)</th>
                {/* STRICT FINANCIAL BLINDSPOT: Only Director sees Agency 85% Cut */}
                {isExecutiveDirector && (
                  <th className="py-3 px-4 text-[#D4AF37]">Agency Retain (85%)</th>
                )}
                <th className="py-3 px-4 text-emerald-400">Creator 15% Cut</th>
                <th className="py-3 px-4 text-right">Order Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono">
              {visibleTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-white/[0.02] transition-all">
                  <td className="py-4 px-4 text-slate-400">{tx.timestamp}</td>
                  <td className="py-4 px-4">
                    <div className="font-bold text-white">{tx.orderId}</div>
                    <span className="text-[10px] text-slate-400 font-sans">{tx.storefront} • {tx.brandName}</span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="font-sans font-semibold text-white">{tx.creatorHandle}</div>
                    <span className="text-[10px] text-[#D4AF37] font-mono">{tx.discountCodeUsed}</span>
                  </td>
                  <td className="py-4 px-4 font-bold text-white text-sm">
                    ${tx.grossAmount.toFixed(2)}
                  </td>
                  {isExecutiveDirector && (
                    <td className="py-4 px-4 font-bold text-[#D4AF37] text-sm">
                      ${tx.agencyGrossSplit.toFixed(2)}
                    </td>
                  )}
                  <td className="py-4 px-4 font-bold text-emerald-400 text-sm">
                    ${tx.creatorCommissionAmount.toFixed(2)}
                  </td>
                  <td className="py-4 px-4 text-right">
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-[10px] font-bold text-emerald-400 uppercase">
                      {tx.status || 'Cleared'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AffiliatePerformanceLedger;
