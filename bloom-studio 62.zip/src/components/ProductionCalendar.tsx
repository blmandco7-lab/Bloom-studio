import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Video,
  FileText,
  CheckCircle,
  Clock,
  AlertTriangle,
  Filter,
  Eye,
  Trash2,
  Check,
  ShieldCheck,
  Radio,
  Sparkles,
  MapPin,
  Tag,
  Users,
  Search,
  ExternalLink,
  X
} from 'lucide-react';
import { Creator, Deal, Role } from '../types';

export interface ProductionEvent {
  id: string;
  title: string;
  creator: string;
  creatorHandle?: string;
  brand?: string;
  dealId?: string;
  date: string; // YYYY-MM-DD
  dayNum: number;
  month: number; // 0-11
  year: number;
  time?: string;
  type: 'shoot' | 'draft_due' | 'review' | 'director_approval' | 'live_post' | 'ftc_check' | 'availability' | 'work';
  format?: 'TikTok Video' | 'IG Reel' | 'YouTube Short' | 'IG Story Set' | 'YouTube Dedicated' | 'Carousel' | 'Live Stream' | string;
  stage: 'Scheduled' | 'In Production' | 'Draft Submitted' | 'Revisions' | 'Director Approved' | 'Live & Published' | 'Completed' | string;
  assignedCoordinator?: string;
  assignedAgent?: string;
  assignedManager?: string;
  assignedDirector?: string;
  notes?: string;
  location?: string;
  ftcStatus?: 'Verified' | 'Pending Check' | 'Exempt';
  budget?: number;
  isDeleted?: boolean;
}

interface ProductionCalendarProps {
  agencySchedules?: any[];
  setAgencySchedules?: React.Dispatch<React.SetStateAction<any[]>>;
  creators?: Creator[];
  deals?: Deal[];
  currentRole?: Role | string;
  currentUser?: any;
  isEmbeddedInDirectorDash?: boolean;
  onAddActivityLog?: (actorName: string, actorRole: string, actionDetail: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'info' | 'warning' | 'success' | 'danger') => void;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onNavigateToScreen?: (screenId: string) => void;
}

// Initial realistic default production events if none exist
export const INITIAL_PRODUCTION_EVENTS: ProductionEvent[] = [
  {
    id: 'pe_seed_1',
    title: '@alexjones x Gymshark • Performance Wear UGC Shoot',
    creator: '@alexjones',
    creatorHandle: '@alexjones',
    brand: 'Gymshark',
    date: `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-04`,
    dayNum: 4,
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
    time: '10:00 AM PST',
    type: 'shoot',
    format: 'TikTok Video',
    stage: 'In Production',
    assignedCoordinator: 'Sarah Jenkins',
    assignedAgent: 'Marcus Cole',
    location: 'Venice Beach Gym, CA',
    ftcStatus: 'Pending Check',
    notes: 'Filming 3x hook variations with seamless transitions.',
    budget: 8500
  },
  {
    id: 'pe_seed_2',
    title: '@sophiaglows x Sephora • Clean Beauty Draft Turn-In',
    creator: '@sophiaglows',
    creatorHandle: '@sophiaglows',
    brand: 'Sephora',
    date: `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-08`,
    dayNum: 8,
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
    time: '3:00 PM EST',
    type: 'draft_due',
    format: 'IG Reel',
    stage: 'Draft Submitted',
    assignedCoordinator: 'Sarah Jenkins',
    assignedAgent: 'Marcus Cole',
    location: 'Studio Glam Suite',
    ftcStatus: 'Verified',
    notes: 'Draft submitted with #SephoraPartner and #ad in opening frame.',
    budget: 12000
  },
  {
    id: 'pe_seed_3',
    title: '@marcusfitness x Red Bull • Directorial Sign-Off & FTC Review',
    creator: '@marcusfitness',
    creatorHandle: '@marcusfitness',
    brand: 'Red Bull',
    date: `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-13`,
    dayNum: 13,
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
    time: '1:00 PM EST',
    type: 'director_approval',
    format: 'YouTube Short',
    stage: 'Director Approved',
    assignedCoordinator: 'Sarah Jenkins',
    assignedAgent: 'Alex Rivera',
    location: 'Editing Lab',
    ftcStatus: 'Verified',
    notes: 'Audio mixing balanced and clear branding overlay.',
    budget: 15000
  },
  {
    id: 'pe_seed_4',
    title: '@elena_style x Prada • Live Campaign Publishing Milestone',
    creator: '@elena_style',
    creatorHandle: '@elena_style',
    brand: 'Prada',
    date: `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-17`,
    dayNum: 17,
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
    time: '9:00 AM PST',
    type: 'live_post',
    format: 'IG Story Set',
    stage: 'Live & Published',
    assignedCoordinator: 'Sarah Jenkins',
    assignedAgent: 'Marcus Cole',
    location: 'Paris, FR',
    ftcStatus: 'Verified',
    notes: 'Live link tracked and swipe-up UTM parameters confirmed.',
    budget: 22000
  },
  {
    id: 'pe_seed_5',
    title: '@kai_tech x Sony Alpha • 4K Hardware Review Draft Submission',
    creator: '@kai_tech',
    creatorHandle: '@kai_tech',
    brand: 'Sony',
    date: `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-21`,
    dayNum: 21,
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
    time: '4:30 PM CST',
    type: 'draft_due',
    format: 'YouTube Dedicated',
    stage: 'In Production',
    assignedCoordinator: 'Sarah Jenkins',
    assignedAgent: 'Alex Rivera',
    location: 'Austin Tech Studio',
    ftcStatus: 'Pending Check',
    notes: 'Awaiting B-roll render for low-light sensor test.',
    budget: 9500
  },
  {
    id: 'pe_seed_6',
    title: '@alexjones x Bloom Nutrition • Studio UGC Shoot',
    creator: '@alexjones',
    creatorHandle: '@alexjones',
    brand: 'Bloom Nutrition',
    date: `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-25`,
    dayNum: 25,
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
    time: '11:00 AM PST',
    type: 'shoot',
    format: 'TikTok Video',
    stage: 'Scheduled',
    assignedCoordinator: 'Sarah Jenkins',
    assignedAgent: 'Marcus Cole',
    location: 'LA Kitchen Studio',
    ftcStatus: 'Pending Check',
    notes: 'Greens powder mix demonstration with call-to-action.',
    budget: 6500
  }
];

export const ProductionCalendar: React.FC<ProductionCalendarProps> = ({
  agencySchedules = [],
  setAgencySchedules,
  creators = [],
  deals = [],
  currentRole = 'director',
  currentUser,
  isEmbeddedInDirectorDash = false,
  onAddActivityLog,
  triggerNotification,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onNavigateToScreen
}) => {
  // Calendar Navigation State
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [viewMode, setViewMode] = useState<'month' | 'agenda' | 'stages'>('month');
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  
  // Filter States
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modal State for adding/logging production events
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventCreator, setNewEventCreator] = useState(creators[0]?.handle || '@alexjones');
  const [newEventBrand, setNewEventBrand] = useState('Gymshark');
  const [newEventDate, setNewEventDate] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });
  const [newEventTime, setNewEventTime] = useState('11:00 AM PST');
  const [newEventType, setNewEventType] = useState<ProductionEvent['type']>('shoot');
  const [newEventFormat, setNewEventFormat] = useState('TikTok Video');
  const [newEventStage, setNewEventStage] = useState('Scheduled');
  const [newEventLocation, setNewEventLocation] = useState('Studio Production');
  const [newEventNotes, setNewEventNotes] = useState('');
  const [newEventFtc, setNewEventFtc] = useState<'Verified' | 'Pending Check' | 'Exempt'>('Pending Check');

  // Month & Day calculations
  const calendarMonthIndex = currentDate.getMonth();
  const calendarYear = currentDate.getFullYear();
  const calendarMonthName = currentDate.toLocaleString('default', { month: 'long' });
  const daysInMonth = new Date(calendarYear, calendarMonthIndex + 1, 0).getDate();
  const firstDayOfWeek = new Date(calendarYear, calendarMonthIndex, 1).getDay();

  // Combine parent schedules with default seeds and deals
  const allEvents: ProductionEvent[] = useMemo(() => {
    // 1. Existing schedules from state
    const customSchedules = (agencySchedules || []).filter(e => e.type !== 'availability' && e.type !== 'blockout');

    // 2. Active deals mapped into production milestones
    const dealMilestones: ProductionEvent[] = (deals || []).map((d, i) => {
      let dDay = ((i * 5 + 6) % daysInMonth) + 1;
      let dMonth = calendarMonthIndex;
      let dYear = calendarYear;
      if (d.dueDate || d.due) {
        const parsed = new Date(d.dueDate || d.due);
        if (!isNaN(parsed.getTime())) {
          dDay = parsed.getDate();
          dMonth = parsed.getMonth();
          dYear = parsed.getFullYear();
        }
      }
      return {
        id: `deal_prod_${d.id}`,
        title: `${d.creatorHandle || d.creator} x ${d.brand} • ${d.deliverable || 'Deliverable Submission'}`,
        creator: d.creatorHandle || d.creator,
        creatorHandle: d.creatorHandle || d.creator,
        brand: d.brand,
        dealId: d.id,
        date: `${dYear}-${String(dMonth + 1).padStart(2, '0')}-${String(dDay).padStart(2, '0')}`,
        dayNum: dDay,
        month: dMonth,
        year: dYear,
        time: '2:00 PM EST',
        type: (d.stage === 'Live' ? 'live_post' : d.stage === 'Contracted' ? 'shoot' : 'draft_due') as ProductionEvent['type'],
        format: (d.platform ? `${d.platform} Video` : 'TikTok Video') as any,
        stage: d.stage === 'Live' ? 'Live & Published' : d.stage === 'Completed' ? 'Completed' : 'In Production',
        assignedCoordinator: d.assignedCoordinator || d.coordinator || 'Sarah Jenkins',
        assignedAgent: d.assignedAgent || d.agent || 'Marcus Cole',
        location: 'Production Studio',
        ftcStatus: 'Pending Check',
        notes: d.notes || `Deal Value: $${(d.budget || d.amount || 5000).toLocaleString()}`,
        budget: d.budget || d.amount,
        isDeleted: false
      };
    });

    let combined = [...customSchedules, ...dealMilestones];
    if (combined.length === 0) {
      combined = [...INITIAL_PRODUCTION_EVENTS];
    }
    // Normalize format
    return combined.map((evt, idx) => {
      const dayNum = evt.dayNum !== undefined ? evt.dayNum : (evt.date ? parseInt(evt.date.split('-')[2], 10) : 1);
      const month = evt.month !== undefined ? evt.month : (evt.date ? parseInt(evt.date.split('-')[1], 10) - 1 : calendarMonthIndex);
      const year = evt.year !== undefined ? evt.year : (evt.date ? parseInt(evt.date.split('-')[0], 10) : calendarYear);
      
      return {
        id: evt.id || `pe_auto_${idx}_${Date.now()}`,
        title: evt.title || `${evt.creator || '@creator'} • Production Event`,
        creator: evt.creator || '@alexjones',
        creatorHandle: evt.creatorHandle || evt.creator || '@alexjones',
        brand: evt.brand || 'Agency Partner',
        dealId: evt.dealId,
        date: evt.date || `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`,
        dayNum,
        month,
        year,
        time: evt.time || '12:00 PM',
        type: (evt.type || 'shoot') as ProductionEvent['type'],
        format: evt.format || 'TikTok Video',
        stage: evt.stage || 'Scheduled',
        assignedCoordinator: evt.assignedCoordinator || 'Sarah Jenkins',
        assignedAgent: evt.assignedAgent || 'Marcus Cole',
        assignedManager: evt.assignedManager || 'Devon Brooks',
        assignedDirector: evt.assignedDirector || 'Unassigned',
        location: evt.location || 'Studio Set',
        ftcStatus: evt.ftcStatus || 'Pending Check',
        notes: evt.notes || '',
        budget: evt.budget,
        isDeleted: evt.isDeleted || false
      };
    }).filter(e => !e.isDeleted);
  }, [agencySchedules, deals, calendarMonthIndex, calendarYear, daysInMonth]);

  // Filter events for the current calendar view with strict role-based visibility
  const filteredEvents = useMemo(() => {
    return allEvents.filter(evt => {
      // Month & Year filter
      if (evt.month !== calendarMonthIndex || evt.year !== calendarYear) {
        return false;
      }

      // Role-Based Visibility Check:
      // - Director / Admin / Super Admin: sees everything across the entire agency.
      // - Creator: sees ONLY their own events (matching their handle or name).
      // - Agent / Agent Manager / Coordinator: sees only their assigned creators / roster and their own tasks.
      const isDirector = currentRole === 'director' || currentRole === 'admin' || currentRole === 'super_admin';
      if (!isDirector) {
        const userHandle = (currentUser?.handle || '').toLowerCase();
        const userName = (currentUser?.name || '').toLowerCase();
        const evtCreator = (evt.creator || evt.creatorHandle || '').toLowerCase();
        const assignedCoord = (evt.assignedCoordinator || '').toLowerCase();
        const assignedAg = (evt.assignedAgent || '').toLowerCase();

        if (currentRole === 'creator') {
          // Creator only sees their own events
          if (evtCreator !== userHandle && evtCreator !== userName && !evt.title.toLowerCase().includes(userHandle)) {
            return false;
          }
        } else if (currentRole === 'agent' || currentRole === 'agentmgr' || currentRole === 'coordinator') {
          // Agent / Agent Manager / Coordinator:
          // Check if event belongs to a creator in their assigned roster or is assigned to them
          const dynamicAssigned = (creators || []).filter(c => {
            const ag = (c.assignedAgent || (c as any).agent || '').toLowerCase();
            const mgr = (c.assignedManager || '').toLowerCase();
            const coord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
            return (
              ag.includes(userName) || userName.includes(ag) ||
              mgr.includes(userName) || userName.includes(mgr) ||
              coord.includes(userName) || userName.includes(coord) ||
              (userName.includes('alex') && ag.includes('alex')) ||
              (userName.includes('marcus') && (ag.includes('marcus') || mgr.includes('marcus')))
            );
          }).map(c => c.handle.toLowerCase());

          const assignedHandles: string[] = Array.from(new Set([
            ...(currentUser?.assignedCreators || currentUser?.assignedHandles || []).map((h: string) => h.toLowerCase()),
            ...dynamicAssigned
          ]));
          
          const isMyCreator = assignedHandles.some((h: string) => 
            evtCreator.includes(h) || 
            evtCreator.includes(h.replace('@', '')) || 
            evt.title.toLowerCase().includes(h) ||
            evt.title.toLowerCase().includes(h.replace('@', ''))
          );
          const isDirectlyAssigned = (assignedCoord && (assignedCoord.includes(userName) || userName.includes(assignedCoord))) ||
                                     (assignedAg && (assignedAg.includes(userName) || userName.includes(assignedAg)));
          const isSelfMentioned = userHandle && (evtCreator.includes(userHandle) || evt.title.toLowerCase().includes(userHandle));

          if (!isMyCreator && !isDirectlyAssigned && !isSelfMentioned && assignedHandles.length > 0) {
            return false;
          }
        }
      }

      // Type filter
      if (typeFilter !== 'all' && evt.type !== typeFilter) {
        return false;
      }
      // Creator filter
      if (creatorFilter !== 'all' && evt.creator.toLowerCase() !== creatorFilter.toLowerCase()) {
        return false;
      }
      // Stage filter
      if (stageFilter !== 'all' && evt.stage !== stageFilter) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = evt.title.toLowerCase().includes(q);
        const matchCreator = evt.creator.toLowerCase().includes(q);
        const matchBrand = (evt.brand || '').toLowerCase().includes(q);
        const matchNotes = (evt.notes || '').toLowerCase().includes(q);
        if (!matchTitle && !matchCreator && !matchBrand && !matchNotes) return false;
      }
      return true;
    });
  }, [allEvents, calendarMonthIndex, calendarYear, typeFilter, creatorFilter, stageFilter, searchQuery, currentRole, currentUser]);

  // Selected Day Events
  const selectedDayEvents = useMemo(() => {
    if (!selectedDay) return [];
    return filteredEvents.filter(e => e.dayNum === selectedDay);
  }, [filteredEvents, selectedDay]);

  // Summary Metrics
  const summaryMetrics = useMemo(() => {
    const monthEvents = allEvents.filter(e => e.month === calendarMonthIndex && e.year === calendarYear);
    const totalShoots = monthEvents.filter(e => e.type === 'shoot').length;
    const pendingApprovals = monthEvents.filter(e => e.stage === 'Draft Submitted' || e.type === 'director_approval').length;
    const livePosts = monthEvents.filter(e => e.type === 'live_post' || e.stage === 'Live & Published' || e.stage === 'Director Approved').length;
    const draftsDue = monthEvents.filter(e => e.type === 'draft_due').length;

    return {
      totalEvents: monthEvents.length,
      totalShoots,
      pendingApprovals,
      livePosts,
      draftsDue
    };
  }, [allEvents, calendarMonthIndex, calendarYear]);

  // Handler: Add new production event
  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim()) {
      triggerNotification?.('Missing Title', 'Please enter an event title.', 'warning');
      return;
    }

    const [y, m, d] = newEventDate.split('-').map(n => parseInt(n, 10));

    // Look up creator's assigned staff
    const matchedCreator = creators?.find(c => 
      c.handle?.toLowerCase() === newEventCreator.toLowerCase() ||
      c.name?.toLowerCase() === newEventCreator.toLowerCase()
    );

    const resolvedCoordinator = matchedCreator?.assignedCoordinator || matchedCreator?.coordinator || 'Sarah Jenkins';
    const resolvedAgent = matchedCreator?.assignedAgent || 'Marcus Cole';
    const resolvedManager = matchedCreator?.assignedManager || 'Devon Brooks';
    const resolvedDirector = 'Director';

    const newEvt: ProductionEvent = {
      id: `pe_${Date.now()}`,
      title: newEventTitle,
      creator: newEventCreator,
      creatorHandle: newEventCreator,
      brand: newEventBrand,
      date: newEventDate,
      dayNum: d || 1,
      month: m ? m - 1 : calendarMonthIndex,
      year: y || calendarYear,
      time: newEventTime,
      type: newEventType,
      format: newEventFormat,
      stage: newEventStage,
      assignedCoordinator: resolvedCoordinator,
      assignedAgent: resolvedAgent,
      assignedManager: resolvedManager,
      assignedDirector: resolvedDirector,
      location: newEventLocation,
      notes: newEventNotes,
      ftcStatus: newEventFtc
    };

    if (setAgencySchedules) {
      setAgencySchedules(prev => [...(prev || []), newEvt]);
    }

    triggerNotification?.(
      'Production Event Logged',
      `Successfully scheduled "${newEventTitle}" for ${calendarMonthName} ${d}.`,
      'success'
    );

    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Logged production calendar milestone: ${newEventTitle} on ${newEventDate}`
    );

    setIsAddModalOpen(false);
    setNewEventTitle('');
    setNewEventNotes('');
    setSelectedDay(d || 1);
  };

  // Handler: Update Stage (e.g. Director One-Click Approve, Coordinator Turn-in)
  const handleUpdateStage = (eventId: string, nextStage: string) => {
    if (setAgencySchedules) {
      setAgencySchedules(prev => {
        const existing = prev && prev.length > 0 ? prev : INITIAL_PRODUCTION_EVENTS;
        return existing.map(item => {
          if (item.id === eventId) {
            return { ...item, stage: nextStage };
          }
          return item;
        });
      });
    }

    triggerNotification?.(
      'Stage Advanced',
      `Updated milestone to "${nextStage}".`,
      'success'
    );

    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Updated production event (${eventId}) stage to ${nextStage}`
    );
  };

  // Handler: Delete Event
  const handleDeleteEvent = (eventId: string, title: string) => {
    if (setAgencySchedules) {
      setAgencySchedules(prev => {
        const existing = prev && prev.length > 0 ? prev : INITIAL_PRODUCTION_EVENTS;
        return existing.filter(item => item.id !== eventId);
      });
    }

    triggerNotification?.(
      'Event Removed',
      `Removed production event "${title}".`,
      'danger'
    );

    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Deleted production calendar event: ${title}`
    );
  };

  // Helper for type color
  const getTypeBadge = (type: ProductionEvent['type']) => {
    switch (type) {
      case 'shoot':
        return {
          bg: 'bg-amber-500/15',
          text: 'text-amber-300',
          border: 'border-amber-500/30',
          dot: 'bg-amber-400',
          label: '🎬 Shoot / Filming'
        };
      case 'draft_due':
        return {
          bg: 'bg-sky-500/15',
          text: 'text-sky-300',
          border: 'border-sky-500/30',
          dot: 'bg-sky-400',
          label: '📝 Draft Turn-In'
        };
      case 'director_approval':
        return {
          bg: 'bg-purple-500/15',
          text: 'text-purple-300',
          border: 'border-purple-500/30',
          dot: 'bg-purple-400',
          label: '👑 Director Sign-Off'
        };
      case 'live_post':
        return {
          bg: 'bg-emerald-500/15',
          text: 'text-emerald-300',
          border: 'border-emerald-500/30',
          dot: 'bg-emerald-400',
          label: '🚀 Live Publishing'
        };
      case 'ftc_check':
        return {
          bg: 'bg-cyan-500/15',
          text: 'text-cyan-300',
          border: 'border-cyan-500/30',
          dot: 'bg-cyan-400',
          label: '⚖️ FTC Audit'
        };
      case 'availability':
        return {
          bg: 'bg-rose-500/15',
          text: 'text-rose-300',
          border: 'border-rose-500/30',
          dot: 'bg-rose-400',
          label: '🚫 Blackout / Hold'
        };
      default:
        return {
          bg: 'bg-slate-800',
          text: 'text-slate-300',
          border: 'border-white/10',
          dot: 'bg-[#C9A46A]',
          label: '📌 Deliverable'
        };
    }
  };

  const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase());
  const isCoordinator = (currentRole || '').toLowerCase() === 'coordinator';

  return (
    <div className={`space-y-5 animate-fade-in ${isEmbeddedInDirectorDash ? 'mt-4' : ''}`}>
      {/* Calendar Header Card */}
      <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
        
        {/* Top Title Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#C9A46A]/10 text-[#C9A46A] border border-[#C9A46A]/20">
                Production Calendar
              </span>
              <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/50 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                Live &amp; Synchronized
              </span>
            </div>
            <h2 className="text-xl font-serif font-bold text-white flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-[#C9A46A]" style={{ color: primaryBrandColor }} />
              Production Calendar (Deliverables &amp; Deadlines)
            </h2>
            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Master timeline for scheduled brand shoots, video draft deadlines, FTC audits, and live posting milestones.
            </p>
          </div>

          {/* Action & Navigation Controls */}
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            {/* Switch to Availability Calendar */}
            <button
              type="button"
              onClick={() => {
                if (onNavigateToScreen) {
                  onNavigateToScreen('calendar-avail');
                } else {
                  const navEvt = new CustomEvent('navigate-app-screen', { detail: 'calendar-avail' });
                  window.dispatchEvent(navEvt);
                }
              }}
              className="bg-[#111E33] hover:bg-[#152640] border border-white/10 text-slate-300 hover:text-white px-3 py-2 rounded-xl text-xs font-mono font-medium transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="Open Creator Availability Calendar"
            >
              <span>📅 Creator Availability Calendar</span>
            </button>

            {/* Month Switcher */}
            <div className="flex items-center bg-[#111E33] border border-white/10 rounded-xl p-1 shadow-sm">
              <button
                onClick={() => setCurrentDate(new Date(calendarYear, calendarMonthIndex - 1, 1))}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                title="Previous Month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-mono text-xs font-bold text-[#C9A46A] px-3 select-none" style={{ color: primaryBrandColor }}>
                {calendarMonthName} {calendarYear}
              </span>
              <button
                onClick={() => {
                  setCurrentDate(new Date());
                  setSelectedDay(new Date().getDate());
                }}
                className="px-2 py-1 text-[10px] font-mono text-slate-400 hover:text-white border-x border-white/10 hover:bg-white/5 rounded transition-colors cursor-pointer"
              >
                Today
              </button>
              <button
                onClick={() => setCurrentDate(new Date(calendarYear, calendarMonthIndex + 1, 1))}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                title="Next Month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-[#111E33] border border-white/10 rounded-xl p-1">
              <button
                onClick={() => setViewMode('month')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  viewMode === 'month' ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Grid
              </button>
              <button
                onClick={() => setViewMode('agenda')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  viewMode === 'agenda' ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Agenda
              </button>
              <button
                onClick={() => setViewMode('stages')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  viewMode === 'stages' ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                Stages
              </button>
            </div>

            {/* Add Event Button */}
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow cursor-pointer font-mono"
            >
              <Plus className="w-4 h-4" /> Log Shoot / Milestone
            </button>
          </div>
        </div>

        {/* Executive Summary Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div className="bg-[#111E33] border border-white/5 p-3 rounded-xl">
            <span className="text-[9px] font-mono text-[#7C8AA8] uppercase block">Total Milestones</span>
            <span className="text-lg font-bold text-white font-mono mt-0.5 block">{summaryMetrics.totalEvents}</span>
            <span className="text-[10px] text-slate-400">in {calendarMonthName}</span>
          </div>
          <div className="bg-[#111E33] border border-white/5 p-3 rounded-xl">
            <span className="text-[9px] font-mono text-amber-400 uppercase block">🎬 Scheduled Shoots</span>
            <span className="text-lg font-bold text-amber-300 font-mono mt-0.5 block">{summaryMetrics.totalShoots}</span>
            <span className="text-[10px] text-slate-400">On-location &amp; Studio</span>
          </div>
          <div className="bg-[#111E33] border border-white/5 p-3 rounded-xl">
            <span className="text-[9px] font-mono text-sky-400 uppercase block">📝 Draft Turn-Ins</span>
            <span className="text-lg font-bold text-sky-300 font-mono mt-0.5 block">{summaryMetrics.draftsDue}</span>
            <span className="text-[10px] text-slate-400">Content Deliverables</span>
          </div>
          <div className="bg-[#111E33] border border-white/5 p-3 rounded-xl">
            <span className="text-[9px] font-mono text-purple-400 uppercase block">👑 Pending Approvals</span>
            <span className="text-lg font-bold text-purple-300 font-mono mt-0.5 block">{summaryMetrics.pendingApprovals}</span>
            <span className="text-[10px] text-slate-400">Director Sign-Off</span>
          </div>
          <div className="bg-[#111E33] border border-white/5 p-3 rounded-xl col-span-2 sm:col-span-1">
            <span className="text-[9px] font-mono text-emerald-400 uppercase block">🚀 Live Posts</span>
            <span className="text-lg font-bold text-emerald-300 font-mono mt-0.5 block">{summaryMetrics.livePosts}</span>
            <span className="text-[10px] text-slate-400">Publishing Ready</span>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111E33] p-2.5 rounded-xl border border-white/5">
          <div className="flex flex-wrap items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search shoot, creator, brand..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#0A1220] border border-white/10 text-white text-xs pl-8 pr-3 py-1.5 rounded-lg focus:outline-none focus:border-[#C9A46A] w-44 sm:w-56"
              />
            </div>

            {/* Type Filter */}
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="bg-[#0A1220] border border-white/10 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg focus:outline-none focus:border-[#C9A46A] cursor-pointer"
            >
              <option value="all">Filter: All Types</option>
              <option value="shoot">🎬 Shoots / Filming</option>
              <option value="draft_due">📝 Draft Turn-Ins</option>
              <option value="director_approval">👑 Director Sign-Offs</option>
              <option value="live_post">🚀 Live Posts</option>
              <option value="ftc_check">⚖️ FTC Verification</option>
              <option value="availability">🚫 Blackouts / Holds</option>
            </select>

            {/* Creator Filter */}
            <select
              value={creatorFilter}
              onChange={(e) => setCreatorFilter(e.target.value)}
              className="bg-[#0A1220] border border-white/10 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg focus:outline-none focus:border-[#C9A46A] cursor-pointer max-w-[160px]"
            >
              <option value="all">Talent: All Creators</option>
              {creators.map(c => (
                <option key={c.id} value={c.handle}>{c.handle} ({c.name})</option>
              ))}
            </select>

            {/* Stage Filter */}
            <select
              value={stageFilter}
              onChange={(e) => setStageFilter(e.target.value)}
              className="bg-[#0A1220] border border-white/10 text-slate-200 text-xs px-2.5 py-1.5 rounded-lg focus:outline-none focus:border-[#C9A46A] cursor-pointer"
            >
              <option value="all">Stage: All Stages</option>
              <option value="Scheduled">Scheduled</option>
              <option value="In Production">In Production</option>
              <option value="Draft Submitted">Draft Submitted</option>
              <option value="Director Approved">Director Approved</option>
              <option value="Live & Published">Live &amp; Published</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          <span className="text-[10px] font-mono text-[#7C8AA8]">
            Showing {filteredEvents.length} events
          </span>
        </div>

        {/* MAIN CALENDAR DISPLAY VIEW */}
        {viewMode === 'month' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* 7-Day Monthly Grid Column */}
            <div className={`${selectedDay ? 'lg:col-span-8' : 'lg:col-span-12'} space-y-3`}>
              {/* Day of week headers */}
              <div className="grid grid-cols-7 gap-1.5 text-center text-[10px] font-mono uppercase tracking-wider text-[#7C8AA8] font-bold pb-1 border-b border-white/5">
                <div>Sun</div>
                <div>Mon</div>
                <div>Tue</div>
                <div>Wed</div>
                <div>Thu</div>
                <div>Fri</div>
                <div>Sat</div>
              </div>

              {/* Day cells grid */}
              <div className="grid grid-cols-7 gap-2">
                {/* Empty padding cells for firstDayOfWeek */}
                {Array.from({ length: firstDayOfWeek }).map((_, idx) => (
                  <div
                    key={`pad-${idx}`}
                    className="min-h-[85px] sm:min-h-[105px] bg-white/[0.01] border border-dashed border-white/5 rounded-xl p-1.5 opacity-20 pointer-events-none"
                  />
                ))}

                {/* Actual day cells */}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = i + 1;
                  const dayEvents = filteredEvents.filter(e => e.dayNum === day);
                  const isSelected = selectedDay === day;
                  const isToday = new Date().getDate() === day && new Date().getMonth() === calendarMonthIndex && new Date().getFullYear() === calendarYear;

                  return (
                    <button
                      type="button"
                      key={`day-${day}`}
                      onClick={() => setSelectedDay(day)}
                      className={`min-h-[85px] sm:min-h-[105px] bg-[#111E33] border rounded-xl p-2 flex flex-col justify-between transition-all duration-200 cursor-pointer group hover:border-[#C9A46A]/60 text-left w-full ${
                        isSelected
                          ? 'ring-2 ring-[#C9A46A] border-[#C9A46A] bg-[#142642] shadow-lg'
                          : dayEvents.length > 0
                          ? 'border-white/15 bg-[#102038]'
                          : 'border-white/5 hover:bg-[#14233b]'
                      }`}
                      aria-label={`${calendarMonthName} ${day}, ${calendarYear}${dayEvents.length > 0 ? `, ${dayEvents.length} events` : ''}`}
                      aria-pressed={isSelected}
                    >
                      {/* Day Number and Event Badge Count */}
                      <div className="flex items-center justify-between pointer-events-none">
                        <span className={`text-xs font-mono font-bold ${
                          isToday
                            ? 'bg-[#C9A46A] text-[#0A1220] px-1.5 py-0.2 rounded font-black'
                            : isSelected
                            ? 'text-white'
                            : 'text-slate-300 group-hover:text-white'
                        }`}>
                          {day}
                        </span>

                        {dayEvents.length > 0 && (
                          <div className="flex items-center gap-1">
                            <span className="text-[9px] font-mono px-1.5 py-0.2 rounded-full font-bold bg-[#0D1830] text-[#C9A46A] border border-white/10">
                              {dayEvents.length}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Event Chips inside cell */}
                      <div className="mt-1 flex-1 flex flex-col gap-1 overflow-hidden pointer-events-none">
                        {dayEvents.slice(0, 2).map((evt) => {
                          const badge = getTypeBadge(evt.type);
                          return (
                            <div
                              key={evt.id}
                              title={`${evt.title} (${evt.stage})`}
                              className={`text-[9px] px-1.5 py-0.5 rounded truncate font-medium border flex items-center gap-1 ${badge.bg} ${badge.text} ${badge.border}`}
                            >
                              <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${badge.dot}`} />
                              <span className="truncate">{evt.creator} • {evt.brand || evt.title}</span>
                            </div>
                          );
                        })}

                        {dayEvents.length > 2 && (
                          <span className="text-[8px] font-mono text-[#7C8AA8] font-bold pl-1">
                            +{dayEvents.length - 2} more
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Day Agenda Side Panel */}
            {selectedDay && (
              <div className="lg:col-span-4 bg-[#111E33] border border-white/10 rounded-2xl p-4 flex flex-col justify-between gap-4 shadow-lg">
                <div className="space-y-3.5">
                  {/* Panel Header */}
                  <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider block" style={{ color: primaryBrandColor }}>
                        Day Agenda
                      </span>
                      <h4 className="text-sm font-bold text-white">
                        {calendarMonthName} {selectedDay}, {calendarYear}
                      </h4>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          const dateStr = `${calendarYear}-${String(calendarMonthIndex + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
                          setNewEventDate(dateStr);
                          setIsAddModalOpen(true);
                        }}
                        className="text-[10px] font-mono bg-[#C9A46A]/15 hover:bg-[#C9A46A]/25 text-[#C9A46A] border border-[#C9A46A]/30 px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Plus className="w-3 h-3" /> Add Event
                      </button>
                      <button
                        onClick={() => setSelectedDay(null)}
                        className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition"
                        title="Close day view and show full calendar grid"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Day Events List */}
                  <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                    {selectedDayEvents.length === 0 ? (
                      <div className="p-6 bg-[#0D1830] border border-dashed border-white/10 rounded-xl text-center space-y-2">
                        <CalendarIcon className="w-8 h-8 text-slate-500 mx-auto" />
                        <p className="text-xs text-slate-300 font-medium">No shoots or deliverables scheduled for this day.</p>
                        <button
                          onClick={() => {
                            const dateStr = `${calendarYear}-${String(calendarMonthIndex + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
                            setNewEventDate(dateStr);
                            setIsAddModalOpen(true);
                          }}
                          className="text-xs text-[#C9A46A] hover:underline font-bold inline-block"
                        >
                          + Log Production Shoot / Deadline
                        </button>
                      </div>
                    ) : (
                      selectedDayEvents.map((evt) => {
                        const badge = getTypeBadge(evt.type);
                        return (
                          <div
                            key={evt.id}
                            className="p-3.5 bg-[#0D1830] border border-white/10 hover:border-white/20 rounded-xl space-y-2.5 transition-all shadow-md group relative"
                          >
                            {/* Top Badge & Delete */}
                            <div className="flex items-start justify-between gap-2">
                              <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase border flex items-center gap-1 ${badge.bg} ${badge.text} ${badge.border}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                                {badge.label}
                              </span>
                              <button
                                onClick={() => handleDeleteEvent(evt.id, evt.title)}
                                className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                                title="Remove Event"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            {/* Event Title */}
                            <div>
                              <h5 className="text-xs font-bold text-white leading-snug group-hover:text-[#C9A46A] transition-colors">
                                {evt.title}
                              </h5>
                              <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 flex-wrap">
                                <span className="flex items-center gap-1 font-mono text-slate-300">
                                  <Clock className="w-3 h-3 text-[#C9A46A]" /> {evt.time}
                                </span>
                                {evt.location && (
                                  <span className="flex items-center gap-1 text-slate-400">
                                    <MapPin className="w-3 h-3 text-slate-500" /> {evt.location}
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Meta Grid */}
                            <div className="grid grid-cols-2 gap-2 text-[10px] bg-[#111E33] p-2.5 rounded-lg border border-white/5">
                              <div>
                                <span className="text-[9px] text-[#7C8AA8] uppercase font-mono block">Format</span>
                                <span className="font-semibold text-slate-200">{evt.format || 'TikTok Video'}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-[#7C8AA8] uppercase font-mono block">Stage</span>
                                <span className="font-semibold text-emerald-400">{evt.stage}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-[#7C8AA8] uppercase font-mono block">Coordinator</span>
                                <span className="font-medium text-slate-300 truncate block">{evt.assignedCoordinator || 'Sarah Jenkins'}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-[#7C8AA8] uppercase font-mono block">Agent</span>
                                <span className="font-medium text-slate-300 truncate block">{evt.assignedAgent || 'Marcus Cole'}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-[#7C8AA8] uppercase font-mono block">Agent Manager</span>
                                <span className="font-medium text-slate-300 truncate block">{evt.assignedManager || 'Devon Brooks'}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-[#7C8AA8] uppercase font-mono block">Director</span>
                                <span className="font-medium text-[#C9A46A] truncate block">{evt.assignedDirector || 'Unassigned'}</span>
                              </div>
                              <div className="col-span-2 border-t border-white/5 pt-1.5">
                                <span className="text-[9px] text-[#7C8AA8] uppercase font-mono block">FTC Disclosure</span>
                                <span className={`font-medium ${evt.ftcStatus === 'Verified' ? 'text-emerald-400' : 'text-amber-400'}`}>
                                  {evt.ftcStatus === 'Verified' ? '✓ Verified' : '⚠️ Pending Check'}
                                </span>
                              </div>
                            </div>

                            {/* Notes */}
                            {evt.notes && (
                              <p className="text-[10px] text-slate-400 italic bg-[#111E33]/60 p-2 rounded border border-white/5">
                                "{evt.notes}"
                              </p>
                            )}

                            {/* Stage Progression & Action Buttons */}
                            <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2 flex-wrap">
                              {/* Stage Selector */}
                              <div className="flex items-center gap-1.5 text-[10px]">
                                <span className="text-[#7C8AA8] font-mono">Stage:</span>
                                <select
                                  value={evt.stage}
                                  onChange={(e) => handleUpdateStage(evt.id, e.target.value)}
                                  className="bg-[#111E33] border border-white/10 text-white rounded px-2 py-0.5 text-[10px] font-semibold focus:outline-none focus:border-[#C9A46A] cursor-pointer"
                                >
                                  <option value="Scheduled">Scheduled</option>
                                  <option value="In Production">In Production</option>
                                  <option value="Draft Submitted">Draft Submitted</option>
                                  <option value="Revisions">Revisions</option>
                                  <option value="Director Approved">Director Approved</option>
                                  <option value="Live & Published">Live &amp; Published</option>
                                  <option value="Completed">Completed</option>
                                </select>
                              </div>

                              {/* Director Fast-Action Approve Button */}
                              {isDirector && evt.stage !== 'Director Approved' && evt.stage !== 'Live & Published' && evt.stage !== 'Completed' && (
                                <button
                                  onClick={() => handleUpdateStage(evt.id, 'Director Approved')}
                                  className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-1 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                                >
                                  <CheckCircle className="w-3 h-3" /> Approve Milestone
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* AGENDA LIST VIEW */}
        {viewMode === 'agenda' && (
          <div className="space-y-3">
            {filteredEvents.length === 0 ? (
              <div className="p-8 bg-[#111E33] border border-white/5 rounded-xl text-center space-y-2">
                <CalendarIcon className="w-10 h-10 text-slate-500 mx-auto" />
                <h4 className="text-sm font-bold text-white">No production milestones match your filters</h4>
                <p className="text-xs text-slate-400">Try adjusting the filter criteria or log a new event.</p>
              </div>
            ) : (
              <div className="divide-y divide-white/5 bg-[#111E33] rounded-2xl border border-white/5 overflow-hidden">
                {filteredEvents
                  .sort((a, b) => a.dayNum - b.dayNum)
                  .map((evt) => {
                    const badge = getTypeBadge(evt.type);
                    return (
                      <div
                        key={evt.id}
                        className="p-4 hover:bg-white/[0.02] transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div className="flex items-start gap-3.5">
                          {/* Date badge */}
                          <div className="w-12 h-12 rounded-xl bg-[#0D1830] border border-white/10 flex flex-col items-center justify-center shrink-0">
                            <span className="text-[9px] font-mono uppercase text-[#C9A46A] font-bold">{calendarMonthName.slice(0, 3)}</span>
                            <span className="text-base font-bold text-white font-mono leading-none">{evt.dayNum}</span>
                          </div>

                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase border ${badge.bg} ${badge.text} ${badge.border}`}>
                                {badge.label}
                              </span>
                              <span className="text-[10px] font-mono text-slate-400">{evt.time}</span>
                              <span className="text-[10px] font-mono text-slate-400">&bull; {evt.format}</span>
                            </div>
                            <h4 className="text-xs font-bold text-white">{evt.title}</h4>
                            <p className="text-[11px] text-[#7C8AA8]">
                              Assigned Talent: <span className="text-slate-200 font-semibold">{evt.creator}</span> &bull; Brand: <span className="text-slate-200 font-semibold">{evt.brand || 'General'}</span> &bull; Location: <span className="text-slate-300">{evt.location}</span>
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2.5 shrink-0">
                          {/* Stage selector */}
                          <select
                            value={evt.stage}
                            onChange={(e) => handleUpdateStage(evt.id, e.target.value)}
                            className="bg-[#0D1830] border border-white/10 text-white rounded-lg px-2.5 py-1 text-xs font-semibold focus:outline-none focus:border-[#C9A46A] cursor-pointer"
                          >
                            <option value="Scheduled">Scheduled</option>
                            <option value="In Production">In Production</option>
                            <option value="Draft Submitted">Draft Submitted</option>
                            <option value="Revisions">Revisions</option>
                            <option value="Director Approved">Director Approved</option>
                            <option value="Live & Published">Live &amp; Published</option>
                            <option value="Completed">Completed</option>
                          </select>

                          {isDirector && evt.stage !== 'Director Approved' && evt.stage !== 'Live & Published' && (
                            <button
                              onClick={() => handleUpdateStage(evt.id, 'Director Approved')}
                              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-xs font-bold px-3 py-1 rounded-lg transition-colors cursor-pointer"
                            >
                              Approve
                            </button>
                          )}

                          <button
                            onClick={() => handleDeleteEvent(evt.id, evt.title)}
                            className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                            title="Delete Event"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {/* STAGES KANBAN / PIPELINE VIEW */}
        {viewMode === 'stages' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {['Scheduled', 'In Production', 'Draft Submitted', 'Director Approved'].map((stageName) => {
              const stageEvents = filteredEvents.filter(e => e.stage === stageName || (stageName === 'Director Approved' && (e.stage === 'Live & Published' || e.stage === 'Completed')));
              return (
                <div key={stageName} className="bg-[#111E33] border border-white/5 rounded-2xl p-4 space-y-3 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b border-white/5 pb-2">
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-[#C9A46A]" />
                        {stageName}
                      </h4>
                      <span className="text-[10px] font-mono text-[#7C8AA8] bg-[#0D1830] px-2 py-0.5 rounded-full border border-white/5">
                        {stageEvents.length}
                      </span>
                    </div>

                    <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
                      {stageEvents.length === 0 ? (
                        <p className="text-[11px] text-slate-500 italic p-3 text-center">No events in this stage</p>
                      ) : (
                        stageEvents.map(evt => {
                          const badge = getTypeBadge(evt.type);
                          return (
                            <div
                              key={evt.id}
                              className="p-3 bg-[#0D1830] border border-white/10 hover:border-white/20 rounded-xl space-y-2 transition-all shadow"
                            >
                              <div className="flex items-start justify-between gap-1">
                                <span className={`text-[8px] font-mono font-bold px-1.5 py-0.2 rounded uppercase border ${badge.bg} ${badge.text} ${badge.border}`}>
                                  {evt.type}
                                </span>
                                <span className="text-[9px] font-mono text-slate-400">
                                  {calendarMonthName.slice(0, 3)} {evt.dayNum}
                                </span>
                              </div>
                              <h5 className="text-xs font-bold text-white line-clamp-2">{evt.title}</h5>
                              <div className="text-[10px] text-slate-400 flex items-center justify-between">
                                <span>{evt.creator}</span>
                                <span className="font-mono text-[#C9A46A]">{evt.format}</span>
                              </div>

                              <div className="pt-1.5 border-t border-white/5 flex items-center justify-between">
                                <select
                                  value={evt.stage}
                                  onChange={(e) => handleUpdateStage(evt.id, e.target.value)}
                                  className="bg-[#111E33] border border-white/10 text-white rounded px-2 py-0.5 text-[9px] font-semibold"
                                >
                                  <option value="Scheduled">Scheduled</option>
                                  <option value="In Production">In Production</option>
                                  <option value="Draft Submitted">Draft Submitted</option>
                                  <option value="Director Approved">Director Approved</option>
                                  <option value="Live & Published">Live &amp; Published</option>
                                </select>

                                {isDirector && stageName !== 'Director Approved' && (
                                  <button
                                    onClick={() => handleUpdateStage(evt.id, 'Director Approved')}
                                    className="text-[9px] font-bold text-emerald-400 hover:underline"
                                  >
                                    Approve →
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

      {/* ADD PRODUCTION EVENT MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-[#060B15]/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in">
          <div className="bg-[#0D1830] border border-white/15 rounded-2xl w-full max-w-lg p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="text-[10px] font-mono text-[#C9A46A] font-bold uppercase tracking-wider block">
                  Milestone Logging Desk
                </span>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5 text-[#C9A46A]" /> Schedule Shoot or Deliverable
                </h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="space-y-4 text-xs">
              {/* Title */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Event / Shoot Title <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. @alexjones • Gymshark Fall Line Shoot"
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              {/* Creator & Brand */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Assigned Talent (Creator)</label>
                  <select
                    value={newEventCreator}
                    onChange={(e) => setNewEventCreator(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    {creators.length === 0 ? (
                      <option value="@alexjones">@alexjones</option>
                    ) : (
                      creators.map(c => (
                        <option key={c.id} value={c.handle}>{c.handle} ({c.name})</option>
                      ))
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Brand / Campaign Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Sephora, Gymshark, Nike"
                    value={newEventBrand}
                    onChange={(e) => setNewEventBrand(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              {/* Date, Time & Event Type */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Event Date</label>
                  <input
                    type="date"
                    required
                    value={newEventDate}
                    onChange={(e) => setNewEventDate(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Time / Window</label>
                  <input
                    type="text"
                    placeholder="e.g. 10:00 AM PST"
                    value={newEventTime}
                    onChange={(e) => setNewEventTime(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Event Type</label>
                  <select
                    value={newEventType}
                    onChange={(e) => setNewEventType(e.target.value as any)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    <option value="shoot">🎬 Shoot / Filming</option>
                    <option value="draft_due">📝 Draft Turn-In</option>
                    <option value="director_approval">👑 Director Approval</option>
                    <option value="live_post">🚀 Live Publishing</option>
                    <option value="ftc_check">⚖️ FTC Verification</option>
                    <option value="availability">🚫 Blackout / Hold</option>
                  </select>
                </div>
              </div>

              {/* Deliverable Format & Stage */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Deliverable Format</label>
                  <select
                    value={newEventFormat}
                    onChange={(e) => setNewEventFormat(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    <option value="TikTok Video">TikTok Video</option>
                    <option value="IG Reel">IG Reel</option>
                    <option value="YouTube Short">YouTube Short</option>
                    <option value="IG Story Set">IG Story Set</option>
                    <option value="YouTube Dedicated">YouTube Dedicated</option>
                    <option value="Carousel">Carousel</option>
                    <option value="Live Stream">Live Stream</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Initial Stage</label>
                  <select
                    value={newEventStage}
                    onChange={(e) => setNewEventStage(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    <option value="Scheduled">Scheduled</option>
                    <option value="In Production">In Production</option>
                    <option value="Draft Submitted">Draft Submitted</option>
                    <option value="Director Approved">Director Approved</option>
                    <option value="Live & Published">Live &amp; Published</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">FTC Check</label>
                  <select
                    value={newEventFtc}
                    onChange={(e) => setNewEventFtc(e.target.value as any)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    <option value="Pending Check">⚠️ Pending Check</option>
                    <option value="Verified">✓ Verified</option>
                    <option value="Exempt">Exempt</option>
                  </select>
                </div>
              </div>

              {/* Location & Notes */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Location / Set</label>
                <input
                  type="text"
                  placeholder="e.g. Studio A - Los Angeles, Creator Home Studio"
                  value={newEventLocation}
                  onChange={(e) => setNewEventLocation(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Milestone Notes &amp; Instructions</label>
                <textarea
                  rows={2}
                  placeholder="Provide shooting directives, required brand assets, sound overlays, or revision notes..."
                  value={newEventNotes}
                  onChange={(e) => setNewEventNotes(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-white outline-none focus:border-[#C9A46A] resize-none"
                />
              </div>

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-5 py-2 rounded-xl transition-all shadow cursor-pointer font-mono"
                >
                  Save Milestone to Calendar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
