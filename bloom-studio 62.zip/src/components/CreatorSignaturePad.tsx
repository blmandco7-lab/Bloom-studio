import React, { useState } from 'react';
import { 
  FileSignature, 
  ShieldCheck, 
  CheckCircle2, 
  Lock, 
  AlertTriangle,
  Clock,
  Loader2,
  XCircle
} from 'lucide-react';
import { computeRealSha256, persistSignatureRecord } from '../lib/cryptoSignatures';
import { auth } from '../lib/firebase';
import { safeStorage } from '../utils/safeStorage';

interface CreatorSignaturePadProps {
  campaignName?: string;
  initialSignature?: string;
  initialSignedAt?: string;
  onExecuteSignature?: (signatureName: string, timestamp: string, hash: string) => void;
}

export default function CreatorSignaturePad({
  campaignName = "Lumina Skin Barrier Serum Launch",
  initialSignature = '',
  initialSignedAt = '',
  onExecuteSignature
}: CreatorSignaturePadProps) {
  const [legalName, setLegalName] = useState(initialSignature);
  const [isSigned, setIsSigned] = useState(Boolean(initialSignature));
  const [signedTimestamp, setSignedTimestamp] = useState(initialSignedAt);
  const [esignConsent, setEsignConsent] = useState(false);
  const [signatureHash, setSignatureHash] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleExecute = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const storedUser = (() => {
      try {
        const item = safeStorage.getItem('wl_currentUser');
        return item ? JSON.parse(item) : null;
      } catch {
        return null;
      }
    })();
    const user = auth.currentUser;
    const effectiveUid = user?.uid || storedUser?.id || storedUser?.uid;
    const effectiveEmail = user?.email || storedUser?.email;

    if (!user && !storedUser) {
      setError('You must be signed in to execute a digital signature.');
      return;
    }

    if (!legalName.trim() || !esignConsent) {
      setError('Please type your full legal name and accept the electronic records consent.');
      return;
    }

    setIsSubmitting(true);
    try {
      const timestamp = new Date().toISOString();
      // Identity tie-in: Include UID and verified Email in the payload string to prevent typed-name spoofing
      const payloadStr = `CREATOR_DELIVERABLE_SIGNATURE|CAMPAIGN:${campaignName}|SIGNER:${legalName.trim()}|UID:${effectiveUid || 'creator'}|EMAIL:${effectiveEmail || ''}|DATE:${timestamp}`;
      const generatedHash = await computeRealSha256(payloadStr);

      // Persist to secure server endpoint
      await persistSignatureRecord({
        id: `sig_creator_${effectiveUid || Date.now()}_${Date.now()}`,
        documentType: `Creator Deliverable (${campaignName})`,
        signerName: legalName.trim(),
        signerEmail: effectiveEmail || undefined,
        isoTimestamp: timestamp,
        formattedTimestamp: new Date().toLocaleString(),
        digest: generatedHash,
        payloadContent: payloadStr,
        metadata: { 
          campaignName,
          platformUid: effectiveUid,
          verifiedEmail: effectiveEmail
        }
      });

      // Update UI only AFTER successful persistence
      setIsSigned(true);
      setSignedTimestamp(timestamp);
      setSignatureHash(generatedHash);

      if (onExecuteSignature) {
        onExecuteSignature(legalName.trim(), timestamp, generatedHash);
      }
    } catch (err: any) {
      console.error('[CreatorSignaturePad] Signature execution failed:', err);
      setError(err.message || 'Failed to record your digital signature. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6 font-sans text-agency-textLight animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div className="flex items-center gap-2">
          <FileSignature className="w-5 h-5 text-agency-gold" />
          <h3 className="text-lg font-serif font-bold text-white">Digital Deliverable Signature Block</h3>
        </div>
        {isSigned && (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <Lock className="w-3 h-3" />
            <span>Signature Executed &amp; Timestamped</span>
          </span>
        )}
      </div>

      {error && (
        <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-start gap-3 animate-pulse">
          <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
          <div className="text-xs text-rose-200 font-medium leading-relaxed">
            {error}
          </div>
        </div>
      )}

      {isSigned ? (
        <div className="space-y-4">
          <div className="p-6 bg-agency-navy rounded-2xl border border-emerald-500/40 text-center space-y-3">
            <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs font-mono text-slate-400 uppercase tracking-widest">Digitally Signed Electronic Record</div>
              <div className="text-2xl font-serif italic font-bold text-white mt-1">
                {legalName}
              </div>
            </div>
            <div className="text-[11px] font-mono text-slate-400 flex items-center justify-center gap-1.5">
              <Clock className="w-3 h-3 text-agency-gold" />
              <span>Timestamp: {signedTimestamp || new Date().toLocaleString()}</span>
            </div>
            {signatureHash && (
              <div className="text-[10px] font-mono text-[#C9A46A] bg-[#0A1220] px-3 py-1.5 rounded-lg border border-[#C9A46A]/20 inline-block">
                {signatureHash}
              </div>
            )}
          </div>

          <p className="text-[11px] text-slate-400 text-center font-mono">
            Electronic signature executed with affirmative E-SIGN Act consent and logged to document records.
          </p>
        </div>
      ) : (
        <form onSubmit={handleExecute} className="space-y-5">
          <div>
            <label className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300 mb-2">
              Type Full Legal Name to Electronically Sign *
            </label>
            <input
              type="text"
              required
              value={legalName}
              onChange={e => setLegalName(e.target.value)}
              placeholder="e.g. Olivia Sterling"
              className="w-full bg-agency-navy border border-white/10 rounded-2xl px-4 py-3.5 text-sm font-serif italic text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold transition"
            />
          </div>

          {/* Legal Covenant Banner */}
          <div className="p-4 bg-agency-navy rounded-2xl border border-agency-gold/20 flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-agency-gold shrink-0 mt-0.5" />
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              "By typing your legal name and submitting this form, you confirm that you are the lawful owner or authorized representative of this asset and execute this electronic document for campaign '{campaignName}'."
            </p>
          </div>

          {/* Explicit E-SIGN Electronic Record Consent Checkbox */}
          <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300 pt-1">
            <input
              type="checkbox"
              required
              checked={esignConsent}
              onChange={(e) => setEsignConsent(e.target.checked)}
              className="mt-0.5 rounded border-white/20 text-agency-gold focus:ring-agency-gold bg-agency-navy"
            />
            <span className="leading-relaxed">
              <strong>E-SIGN Act Electronic Record Consent</strong>: I affirmatively consent to conduct transactions electronically, acknowledge that my typed legal name constitutes an electronic signature under applicable U.S. federal and state laws, and confirm I can receive and retain this electronic record.
            </span>
          </label>

          <button
            type="submit"
            disabled={!legalName.trim() || !esignConsent || isSubmitting}
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-agency-gold hover:bg-[#b89359] disabled:opacity-50 text-agency-navy font-bold text-xs uppercase tracking-widest rounded-2xl transition shadow-xl cursor-pointer"
          >
            {isSubmitting ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <ShieldCheck className="w-4 h-4" />
            )}
            <span>{isSubmitting ? 'Recording Secure Signature...' : 'Execute Electronic Signature'}</span>
          </button>
        </form>
      )}
    </div>
  );
}
