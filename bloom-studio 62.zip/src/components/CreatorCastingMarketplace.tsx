import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, where, doc, setDoc } from 'firebase/firestore';
import { Megaphone, Target, Film, CheckCircle, X, Send } from 'lucide-react';

interface CastingCall {
  id: string;
  title: string;
  brand: string;
  niche: string;
  budget: string;
  requirements: string;
  status: string;
}

export const CreatorCastingMarketplace: React.FC<{ currentUserHandle: string }> = ({ currentUserHandle }) => {
  const [activeCalls, setActiveCalls] = useState<CastingCall[]>([]);
  const [selectedCall, setSelectedCall] = useState<CastingCall | null>(null);
  const [reelUrl, setReelUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const q = query(collection(db, 'open-casting-calls'), where("status", "==", "Active"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const calls = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CastingCall));
      setActiveCalls(calls);
    }, (err) => {
      console.error("Firestore onSnapshot error:", err);
    });
    return unsubscribe;
  }, []);

  const handleApply = async () => {
    if (!selectedCall || !reelUrl) return;
    setSubmitting(true);
    try {
      const auditionRef = doc(db, 'open-casting-calls', selectedCall.id, 'auditions', currentUserHandle);
      await setDoc(auditionRef, {
        reelUrl,
        status: 'Under Review',
        submittedAt: new Date().toISOString()
      });
      alert('Application submitted successfully!');
      setSelectedCall(null);
      setReelUrl('');
    } catch (error) {
      console.error('Error submitting application:', error);
      alert('Failed to submit application.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-[#0A1220] min-h-screen text-slate-100">
      <div className="border-b border-white/10 pb-6">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Megaphone className="text-[#C9A46A]" /> Open Casting Marketplace
        </h1>
        <p className="text-sm text-slate-400 mt-2">Browse active brand campaigns and submit your audition reels.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeCalls.map((call) => (
          <div key={call.id} className="bg-[#111E33] border border-white/10 rounded-2xl p-6 space-y-4">
            <h2 className="text-lg font-bold text-white">{call.title}</h2>
            <p className="text-sm text-[#C9A46A]">{call.brand}</p>
            <div className="text-xs text-slate-300 space-y-1">
              <p><strong>Niche:</strong> {call.niche}</p>
              <p><strong>Payout:</strong> {call.budget}</p>
              <p className="line-clamp-2"><strong>Requirements:</strong> {call.requirements}</p>
            </div>
            <button
              onClick={() => setSelectedCall(call)}
              className="w-full bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] font-bold py-2 rounded-xl transition-colors cursor-pointer"
            >
              Apply to Campaign
            </button>
          </div>
        ))}
      </div>

      {selectedCall && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-white">Apply to {selectedCall.title}</h3>
            <input
              type="text"
              placeholder="Paste Audition Reel URL"
              value={reelUrl}
              onChange={(e) => setReelUrl(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white"
            />
            <div className="flex gap-3">
              <button onClick={() => setSelectedCall(null)} className="flex-1 py-2 rounded-xl bg-white/5 text-slate-300 cursor-pointer">Cancel</button>
              <button onClick={handleApply} disabled={submitting} className="flex-1 py-2 rounded-xl bg-[#C9A46A] text-[#0A1220] font-bold cursor-pointer">
                {submitting ? 'Submitting...' : 'Submit Audition'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
