import React, { useState, useMemo } from 'react';
import { DollarSign, Percent, Sparkles, ShieldCheck, HelpCircle, RefreshCw, CheckCircle2, ArrowRight } from 'lucide-react';

export interface CampaignFinancials {
  brandContractValue: number;
  influencerPayout: number;
  productRetailValue?: number;
  agencyNetRetained?: number;
}

interface ManualFinancialInputsProps {
  initialFinancials?: CampaignFinancials;
  campaignTitle?: string;
  creatorHandle?: string;
  onFinancialsChange?: (financials: CampaignFinancials) => void;
  className?: string;
}

export default function ManualFinancialInputs({
  initialFinancials = {
    brandContractValue: 10000.0,
    influencerPayout: 5000.0,
    productRetailValue: 450.0,
    agencyNetRetained: 5000.0
  },
  campaignTitle = "Summer Glow Campaign (Split Pricing)",
  creatorHandle = "@paws_and_palette",
  onFinancialsChange,
  className = ""
}: ManualFinancialInputsProps) {
  // Local state for manual input typing
  const [brandContractValue, setBrandContractValue] = useState<number | string>(
    initialFinancials.brandContractValue ?? 10000
  );
  const [influencerPayout, setInfluencerPayout] = useState<number | string>(
    initialFinancials.influencerPayout ?? 5000
  );
  const [productRetailValue, setProductRetailValue] = useState<number | string>(
    initialFinancials.productRetailValue ?? 450
  );
  const [isSaved, setIsSaved] = useState(false);

  // Safe numerical parsers
  const numBrandValue = useMemo(() => {
    const val = typeof brandContractValue === 'number' ? brandContractValue : parseFloat(brandContractValue);
    return isNaN(val) ? 0 : Math.max(0, val);
  }, [brandContractValue]);

  const numInfluencerPayout = useMemo(() => {
    const val = typeof influencerPayout === 'number' ? influencerPayout : parseFloat(influencerPayout);
    return isNaN(val) ? 0 : Math.max(0, val);
  }, [influencerPayout]);

  const numProductValue = useMemo(() => {
    const val = typeof productRetailValue === 'number' ? productRetailValue : parseFloat(productRetailValue);
    return isNaN(val) ? 0 : Math.max(0, val);
  }, [productRetailValue]);

  // Real-time Agency Margin calculation: Gross Brand Contract Value minus Net Influencer Payout
  const agencyMargin = useMemo(() => {
    return Math.max(0, numBrandValue - numInfluencerPayout);
  }, [numBrandValue, numInfluencerPayout]);

  // Real-time Agency Margin Percentage
  const agencyMarginPercent = useMemo(() => {
    if (numBrandValue <= 0) return 0;
    return Math.round((agencyMargin / numBrandValue) * 1000) / 10;
  }, [agencyMargin, numBrandValue]);

  // Real-time Total Creator Package Value (Payout + Gifting/Product)
  const totalCreatorPackage = useMemo(() => {
    return numInfluencerPayout + numProductValue;
  }, [numInfluencerPayout, numProductValue]);

  // Format currency
  const formatUSD = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: CampaignFinancials = {
      brandContractValue: numBrandValue,
      influencerPayout: numInfluencerPayout,
      productRetailValue: numProductValue,
      agencyNetRetained: agencyMargin
    };

    if (onFinancialsChange) {
      onFinancialsChange(updated);
    }

    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  const handleResetDefaults = () => {
    setBrandContractValue(10000);
    setInfluencerPayout(5000);
    setProductRetailValue(450);
  };

  return (
    <div
      className={`bg-[#0B1B3D] border border-[#D4AF37]/35 rounded-2xl p-5 md:p-6 shadow-2xl space-y-5 text-white relative overflow-hidden ${className}`}
      style={{
        boxShadow: '0 10px 30px -5px rgba(11, 27, 61, 0.7), 0 0 20px 0 rgba(212, 175, 55, 0.08)'
      }}
    >
      {/* Background ambient gold gradient glow */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4 relative z-10">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#D4AF37] bg-[#D4AF37]/15 border border-[#D4AF37]/30 px-2.5 py-0.5 rounded-full">
              Split Pricing Module
            </span>
            <span className="text-xs text-slate-300 font-mono flex items-center gap-1">
              Target Creator: <strong className="text-[#D4AF37]">{creatorHandle}</strong>
            </span>
          </div>
          <h3 className="font-serif font-bold text-lg md:text-xl text-white mt-1">
            Manual Financial Inputs &amp; Split Margin
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Safely input manual contract pricing where the gross brand deal differs from the creator's net payout.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="text-[11px] text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 px-2.5 py-1.5 rounded-lg border border-white/10 transition-colors flex items-center gap-1 cursor-pointer"
            title="Reset to $10,000 / $5,000 baseline"
          >
            <RefreshCw className="w-3 h-3" /> Reset Sample
          </button>
        </div>
      </div>

      {/* Dual Input Form Section */}
      <form onSubmit={handleApply} className="space-y-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Input 1: Gross Brand Contract Value ($) */}
          <div className="bg-[#112240] border border-[#D4AF37]/25 focus-within:border-[#D4AF37] rounded-xl p-3.5 space-y-1.5 transition-all shadow-inner">
            <div className="flex items-center justify-between">
              <label
                htmlFor="gross-brand-contract-val"
                className="text-xs font-semibold text-[#D4AF37] flex items-center gap-1.5"
              >
                <DollarSign className="w-3.5 h-3.5" /> Gross Brand Contract Value ($)
              </label>
              <span className="text-[10px] text-slate-400 font-mono">Brand Billing</span>
            </div>
            <div className="relative flex items-center">
              <span className="absolute left-3 text-slate-400 font-mono text-sm">$</span>
              <input
                id="gross-brand-contract-val"
                type="number"
                step="any"
                min="0"
                required
                value={brandContractValue}
                onChange={(e) => setBrandContractValue(e.target.value)}
                placeholder="10000.00"
                className="w-full bg-[#0B1B3D] border border-white/10 focus:border-[#D4AF37] rounded-lg pl-7 pr-3 py-2 text-white font-mono text-sm outline-none transition-colors"
              />
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              The full invoice amount billed to the sponsoring brand (saved under <code className="text-[#D4AF37]">financials.brandContractValue</code>).
            </p>
          </div>

          {/* Input 2: Net Influencer Payout ($) */}
          <div className="bg-[#112240] border border-[#D4AF37]/25 focus-within:border-[#D4AF37] rounded-xl p-3.5 space-y-1.5 transition-all shadow-inner">
            <div className="flex items-center justify-between">
              <label
                htmlFor="net-influencer-payout-val"
                className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5"
              >
                <DollarSign className="w-3.5 h-3.5" /> Net Influencer Payout ($)
              </label>
              <span className="text-[10px] text-slate-400 font-mono">Creator Escrow</span>
            </div>
            <div className="relative flex items-center">
              <span className="absolute left-3 text-slate-400 font-mono text-sm">$</span>
              <input
                id="net-influencer-payout-val"
                type="number"
                step="any"
                min="0"
                required
                value={influencerPayout}
                onChange={(e) => setInfluencerPayout(e.target.value)}
                placeholder="5000.00"
                className="w-full bg-[#0B1B3D] border border-white/10 focus:border-emerald-400 rounded-lg pl-7 pr-3 py-2 text-white font-mono text-sm outline-none transition-colors"
              />
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Direct compensation distributed to the talent (saved under <code className="text-emerald-400">financials.influencerPayout</code>).
            </p>
          </div>
        </div>

        {/* Optional Secondary Input: Product Retail Value ($) */}
        <div className="bg-[#112240]/70 border border-white/10 focus-within:border-[#D4AF37]/60 rounded-xl p-3.5 space-y-1.5 transition-all">
          <div className="flex items-center justify-between">
            <label
              htmlFor="product-retail-val"
              className="text-xs font-semibold text-slate-200 flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" /> Product Retail Value ($)
            </label>
            <span className="text-[10px] text-slate-400 font-mono">Gifting &amp; Merchandise</span>
          </div>
          <div className="relative flex items-center">
            <span className="absolute left-3 text-slate-400 font-mono text-sm">$</span>
            <input
              id="product-retail-val"
              type="number"
              step="any"
              min="0"
              value={productRetailValue}
              onChange={(e) => setProductRetailValue(e.target.value)}
              placeholder="450.00"
              className="w-full bg-[#0B1B3D] border border-white/10 focus:border-[#D4AF37] rounded-lg pl-7 pr-3 py-2 text-white font-mono text-sm outline-none transition-colors"
            />
          </div>
          <p className="text-[11px] text-slate-400 leading-tight">
            Fair market retail value of PR product package, skincare sets, or gear shipped to creator.
          </p>
        </div>

        {/* READ-ONLY AUTOMATIC CALCULATION BADGES (CRITICAL SAFETY REQUIREMENT) */}
        <div className="bg-[#0D1830] border border-[#D4AF37]/40 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-300 border-b border-white/5 pb-2">
            <span className="font-semibold flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" /> Real-Time Margin Breakdown
            </span>
            <span className="text-[11px] text-slate-400 font-mono">
              Auto-calculated: Brand ({formatUSD(numBrandValue)}) - Creator ({formatUSD(numInfluencerPayout)})
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Real-time Badge 1: Agency Margin ($) */}
            <div className="bg-[#112240] border border-[#D4AF37]/40 rounded-lg p-3 text-center sm:text-left space-y-0.5">
              <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                Agency Margin ($)
              </div>
              <div className="text-xl font-bold font-mono text-[#D4AF37]">
                {formatUSD(agencyMargin)}
              </div>
              <div className="text-[10px] text-emerald-400 font-mono">
                {agencyMarginPercent}% Net Retained
              </div>
            </div>

            {/* Real-time Badge 2: Influencer Compensation */}
            <div className="bg-[#112240] border border-emerald-500/30 rounded-lg p-3 text-center sm:text-left space-y-0.5">
              <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                Creator Payout
              </div>
              <div className="text-xl font-bold font-mono text-emerald-400">
                {formatUSD(numInfluencerPayout)}
              </div>
              <div className="text-[10px] text-slate-300 font-mono">
                {numBrandValue > 0 ? `${Math.round((numInfluencerPayout / numBrandValue) * 1000) / 10}% of Contract` : '0%'}
              </div>
            </div>

            {/* Real-time Badge 3: Total Creator Value (Payout + Product) */}
            <div className="bg-[#112240] border border-purple-500/30 rounded-lg p-3 text-center sm:text-left space-y-0.5">
              <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                Total Creator Value
              </div>
              <div className="text-xl font-bold font-mono text-purple-300">
                {formatUSD(totalCreatorPackage)}
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                Cash + {formatUSD(numProductValue)} Product
              </div>
            </div>
          </div>
        </div>

        {/* Action Button & Status */}
        <div className="flex items-center justify-between pt-1">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" /> Fully manual inputs. Safe for client-side evaluation.
          </span>

          <button
            type="submit"
            className="bg-[#D4AF37] hover:bg-[#b89359] text-[#0B1B3D] font-bold text-xs px-5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
          >
            {isSaved ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-900" />
                <span>Saved &amp; Updated!</span>
              </>
            ) : (
              <>
                <span>Apply Financial Split</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
