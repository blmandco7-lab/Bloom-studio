/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Upload, CheckCircle, Clock, AlertCircle, FileText, Video, Image, MessageSquare, Shield, RefreshCw, Send, XCircle } from 'lucide-react';
import { Role, Creator, Deal, ReviewItem } from '../types';
import { db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { evaluateFtcCompliance } from '../lib/ftcBot';

function cleanForFirestore(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(cleanForFirestore);
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) out[k] = cleanForFirestore(v);
  }
  return out;
}

export interface ContentSubmission {
  id: string;
  creatorHandle: string;
  creatorName: string;
  creatorId?: string;
  campaignTitle: string;
  mediaType: 'video' | 'image';
  fileUrl: string;
  fileName: string;
  caption: string;
  creatorNotes?: string;
  submittedAt: string;
  status: 'Pending Internal Review' | 'Approved' | 'Needs Changes';
  internalNotes?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  subagency?: string;
}

interface ContentUploadProps {
  currentRole: Role;
  currentUser: any;
  creators: Creator[];
  deals: Deal[];
  contentSubmissions: ContentSubmission[];
  setContentSubmissions: React.Dispatch<React.SetStateAction<ContentSubmission[]>>;
  triggerNotification: (title: string, detail: string, type: string) => void;
  handleAddActivityLog: (user: string, role: string, action: string) => void;
  primaryBrandColor: string;
  cardBgColor: string;
  activeScreen: string;
  setActiveScreen: (screen: string) => void;
}

export default function ContentUpload({
  currentRole,
  currentUser,
  creators,
  deals,
  contentSubmissions,
  setContentSubmissions,
  triggerNotification,
  handleAddActivityLog,
  primaryBrandColor,
  cardBgColor,
  activeScreen,
  setActiveScreen
}: ContentUploadProps) {
  // Creator form inputs
  const [campaignTitle, setCampaignTitle] = useState('');
  const [customCampaign, setCustomCampaign] = useState('');
  const [mediaType, setMediaType] = useState<'video' | 'image'>('video');
  const [caption, setCaption] = useState('');
  const [creatorNotes, setCreatorNotes] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);

  // Reviewer form inputs
  const [selectedSubmission, setSelectedSubmission] = useState<ContentSubmission | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);

  // Filter submissions based on role and user scope
  const myHandle = currentUser?.handle?.toLowerCase() || '@represented_creator';
  const myName = currentUser?.name || 'Creator';

  // Creator sees only their own submissions
  // Brand sees ONLY agency-approved content for their campaigns
  const userSubmissions = currentRole === 'creator'
    ? contentSubmissions.filter(s => s.creatorHandle.toLowerCase() === myHandle || s.creatorName.toLowerCase() === myName.toLowerCase())
    : currentRole === 'brand'
    ? contentSubmissions.filter(s => s.status === 'Approved' && (
        s.campaignTitle.toLowerCase().includes((currentUser?.name || 'DripRoom').toLowerCase()) ||
        s.campaignTitle.toLowerCase().includes('driproom') ||
        s.campaignTitle.toLowerCase().includes('glowlab') ||
        s.campaignTitle.toLowerCase().includes('skincare')
      ))
    : contentSubmissions;

  // Handle file select simulation / conversion
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      alert("File size too large! Please upload a draft under 15MB.");
      return;
    }

    setFileName(file.name);
    setIsUploading(true);

    const reader = new FileReader();
    reader.onload = (ev) => {
      setPreviewUrl(ev.target?.result as string);
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  // Preset sample media helpers
  const handleUseSampleVideo = () => {
    setFileName('summer_skincare_reel_draft.mp4');
    setMediaType('video');
    setPreviewUrl('https://assets.mixkit.co/videos/preview/mixkit-fashion-model-in-a-photoshoot-42821-large.mp4');
  };

  const handleUseSampleImage = () => {
    setFileName('driproom_summer_fit.jpg');
    setMediaType('image');
    setPreviewUrl('https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=800');
  };

  // Handle new submission by creator
  const handleSubmitContent = async (e: React.FormEvent) => {
    e.preventDefault();

    const finalCampaign = campaignTitle === 'Custom' ? customCampaign : campaignTitle || 'General Brand Campaign Draft';

    if (!finalCampaign.trim()) {
      alert("Please enter or select a campaign title.");
      return;
    }

    if (!caption.trim()) {
      alert("Please provide the proposed caption and hashtags.");
      return;
    }

    const finalFileUrl = previewUrl || (mediaType === 'video'
      ? 'https://assets.mixkit.co/videos/preview/mixkit-fashion-model-in-a-photoshoot-42821-large.mp4'
      : 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=800');

    const subagency = currentUser?.subagency || 'pod_main';
    const subId = 'sub-' + Date.now();

    const newSub: ContentSubmission = {
      id: subId,
      creatorHandle: currentUser?.handle || '@represented_creator',
      creatorName: currentUser?.name || 'Creator',
      creatorId: currentUser?.id || currentUser?.uid,
      campaignTitle: finalCampaign,
      mediaType,
      fileUrl: finalFileUrl,
      fileName: fileName || (mediaType === 'video' ? 'creator_draft_reel.mp4' : 'creator_draft_post.jpg'),
      caption,
      creatorNotes,
      submittedAt: new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      status: 'Pending Internal Review',
      subagency
    };

    setContentSubmissions(prev => [newSub, ...prev.filter(s => s.id !== newSub.id)]);

    // 1. Persist to Firestore studio-content-submissions
    try {
      await setDoc(doc(db, 'studio-content-submissions', newSub.id), cleanForFirestore(newSub), { merge: true });
    } catch (err) {
      console.warn('Error persisting content submission to Firestore:', err);
    }

    // 2. Evaluate FTC compliance and persist to studio-content-reviews for staff review queue
    const ftcEval = evaluateFtcCompliance(caption.trim(), newSub.id, finalCampaign);
    const revId = 'rev_' + subId.replace('sub-', '');
    const newReview: ReviewItem = {
      id: revId,
      creator: newSub.creatorHandle,
      dealId: newSub.id,
      brand: finalCampaign,
      platform: 'Instagram',
      contentType: mediaType === 'video' ? 'Video Draft' : 'Image Draft',
      mediaUrl: finalFileUrl,
      captionDraft: caption.trim(),
      submittedAt: newSub.submittedAt,
      status: 'Pending',
      ftcFlagged: ftcEval.ftcFlagged,
      ftcFlagReason: ftcEval.ftcFlagReason,
      comments: [
        `System: Content draft turned in by creator ${currentUser?.name || 'Creator'}`,
        `System: Compliance Check Status: ${!ftcEval.ftcFlagged ? '✅ PASSED (FTC Tags Verified)' : '⚠️ WARNING (Missing #ad or #sponsored)'}`
      ],
      subagency
    };

    try {
      await setDoc(doc(db, 'studio-content-reviews', revId), cleanForFirestore(newReview), { merge: true });
    } catch (err) {
      console.warn('Error syncing review item to studio-content-reviews:', err);
    }

    triggerNotification(
      "Content Submitted for Review",
      `Draft for "${finalCampaign}" was submitted! Sent to your assigned Agent, Manager, and Director for review.`,
      "success"
    );

    handleAddActivityLog(currentUser?.name || "Creator", currentRole, `Submitted content draft for campaign "${finalCampaign}" for internal review.`);

    // Reset form
    setCaption('');
    setCreatorNotes('');
    setPreviewUrl('');
    setFileName('');
    setCustomCampaign('');

    // Navigate to status view
    setActiveScreen('my-content');
  };

  // Staff Review Action: Approve
  const handleApproveSubmission = async (sub: ContentSubmission) => {
    const reviewerName = currentUser?.name || (currentRole === 'director' ? 'Director' : currentRole === 'agentmgr' ? 'Agent Manager' : 'Agent');

    const updatedSub: ContentSubmission = {
      ...sub,
      status: 'Approved',
      reviewedBy: `${reviewerName} (${currentRole.toUpperCase()})`,
      reviewedAt: new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      internalNotes: reviewNotes || 'Approved without changes. Ready for brand syndication.'
    };

    setContentSubmissions(prev => prev.map(s => s.id === sub.id ? updatedSub : s));

    try {
      await setDoc(doc(db, 'studio-content-submissions', sub.id), cleanForFirestore(updatedSub), { merge: true });
      const revId = 'rev_' + sub.id.replace('sub-', '');
      await setDoc(doc(db, 'studio-content-reviews', revId), {
        status: 'Approved',
        brandReviewStartedAt: new Date().toISOString(),
        brandReviewStatus: 'Active',
        comments: [`System: Approved by ${reviewerName} (${currentRole.toUpperCase()})`]
      }, { merge: true });
    } catch (err) {
      console.warn('Error updating content submission in Firestore:', err);
    }

    triggerNotification(
      "Content Draft Approved",
      `Approved content submission from ${sub.creatorHandle} for "${sub.campaignTitle}".`,
      "success"
    );

    handleAddActivityLog(reviewerName, currentRole, `Approved content draft from ${sub.creatorHandle} for "${sub.campaignTitle}".`);

    setIsReviewModalOpen(false);
    setSelectedSubmission(null);
    setReviewNotes('');
  };

  // Staff Review Action: Request Changes
  const handleRequestChanges = async (sub: ContentSubmission) => {
    if (!reviewNotes.trim()) {
      alert("Please enter revision guidelines explaining what the creator needs to fix.");
      return;
    }

    const reviewerName = currentUser?.name || (currentRole === 'director' ? 'Director' : currentRole === 'agentmgr' ? 'Agent Manager' : 'Agent');

    const updatedSub: ContentSubmission = {
      ...sub,
      status: 'Needs Changes',
      reviewedBy: `${reviewerName} (${currentRole.toUpperCase()})`,
      reviewedAt: new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      internalNotes: reviewNotes
    };

    setContentSubmissions(prev => prev.map(s => s.id === sub.id ? updatedSub : s));

    try {
      await setDoc(doc(db, 'studio-content-submissions', sub.id), cleanForFirestore(updatedSub), { merge: true });
      const revId = 'rev_' + sub.id.replace('sub-', '');
      await setDoc(doc(db, 'studio-content-reviews', revId), {
        status: 'Revision Requested',
        comments: [`System: Revision requested by ${reviewerName}: ${reviewNotes}`]
      }, { merge: true });
    } catch (err) {
      console.warn('Error updating content submission in Firestore:', err);
    }

    triggerNotification(
      "Revision Requested",
      `Sent revision request notes to ${sub.creatorHandle} for "${sub.campaignTitle}".`,
      "warning"
    );

    handleAddActivityLog(reviewerName, currentRole, `Requested changes on content draft from ${sub.creatorHandle}: ${reviewNotes}`);

    setIsReviewModalOpen(false);
    setSelectedSubmission(null);
    setReviewNotes('');
  };

  // My Deals list for campaign selector dropdown
  const myDeals = currentRole === 'creator'
    ? deals.filter(d => d.creator === currentUser?.handle || d.creator === currentUser?.name)
    : deals;

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden" style={{ borderColor: `${primaryBrandColor}20` }}>
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider block font-mono text-[#C9A46A]" style={{ color: primaryBrandColor }}>
              INTERNAL CONTENT REVIEW &amp; APPROVAL WORKFLOW
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              {activeScreen === 'submit-content' ? 'Upload Draft Content for Review' : 'Content Submissions & Review Queue'}
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
              {currentRole === 'creator'
                ? 'Upload your raw or edited video/image drafts and proposed captions. Your assigned Agent, Manager, and Director review drafts FIRST before brand release.'
                : 'Inspect creator deliverable drafts, approve for brand release, or request specific timeline/caption revisions.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveScreen('submit-content')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeScreen === 'submit-content'
                  ? 'bg-[#C9A46A] text-[#0A1220] font-bold'
                  : 'bg-[#16243F] border border-white/10 text-slate-300 hover:text-white'
              }`}
              style={activeScreen === 'submit-content' ? { backgroundColor: primaryBrandColor } : {}}
            >
              <Upload className="w-3.5 h-3.5" /> Submit New Draft
            </button>
            <button
              onClick={() => setActiveScreen('my-content')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeScreen === 'my-content' || activeScreen === 'content-review'
                  ? 'bg-[#C9A46A] text-[#0A1220] font-bold'
                  : 'bg-[#16243F] border border-white/10 text-slate-300 hover:text-white'
              }`}
              style={activeScreen === 'my-content' || activeScreen === 'content-review' ? { backgroundColor: primaryBrandColor } : {}}
            >
              <FileText className="w-3.5 h-3.5" /> Submissions Queue ({userSubmissions.length})
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {activeScreen === 'submit-content' ? (
        /* UPLOAD CONTENT FORM VIEW */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5" style={{ backgroundColor: cardBgColor }}>
            <div className="border-b border-white/5 pb-3">
              <h3 className="font-serif font-semibold text-lg text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-[#C9A46A]" style={{ color: primaryBrandColor }} />
                Submit Draft Content to Agency Team
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-1">
                Submissions go directly to your Assigned Agent ({creators.find(c => c.handle === currentUser?.handle)?.assignedAgent || "Marcus Cole"}), Agent Manager, and Director.
              </p>
            </div>

            <form onSubmit={handleSubmitContent} className="space-y-4 text-xs">
              
              {/* Campaign Title Select or Input */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-bold block">
                  Select Campaign / Deal
                </label>
                <select
                  value={campaignTitle}
                  onChange={(e) => setCampaignTitle(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#C9A46A]"
                >
                  <option value="">-- Choose active campaign assignment --</option>
                  {myDeals.map(d => (
                    <option key={d.id} value={`${d.brand} - ${d.platform}`}>
                      {d.brand} ({d.platform} - ${d.budget?.toLocaleString() || '0'})
                    </option>
                  ))}
                  <option value="DripRoom Summer Glow Skincare Reel">DripRoom - Summer Glow Skincare Reel ($2,500)</option>
                  <option value="FreshKicks Footwear Unboxing & Review">FreshKicks - Footwear Unboxing & Review ($1,800)</option>
                  <option value="Custom">+ Enter Custom Campaign Title</option>
                </select>
              </div>

              {campaignTitle === 'Custom' && (
                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-bold block">
                    Custom Campaign Name
                  </label>
                  <input
                    type="text"
                    value={customCampaign}
                    onChange={(e) => setCustomCampaign(e.target.value)}
                    placeholder="e.g. DripRoom Summer Outfit Reel"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              )}

              {/* Media Format Choice */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-bold block">
                  Media Format
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => { setMediaType('video'); setPreviewUrl(''); setFileName(''); }}
                    className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                      mediaType === 'video'
                        ? 'bg-[#16243F] border-[#C9A46A] text-[#C9A46A]'
                        : 'bg-[#111E33] border-white/5 text-slate-400'
                    }`}
                  >
                    <Video className="w-4 h-4" /> Short Video Reel (MP4)
                  </button>
                  <button
                    type="button"
                    onClick={() => { setMediaType('image'); setPreviewUrl(''); setFileName(''); }}
                    className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                      mediaType === 'image'
                        ? 'bg-[#16243F] border-[#C9A46A] text-[#C9A46A]'
                        : 'bg-[#111E33] border-white/5 text-slate-400'
                    }`}
                  >
                    <Image className="w-4 h-4" /> Static Carousel / Photo (JPG)
                  </button>
                </div>
              </div>

              {/* File Upload / Picker */}
              <div className="space-y-2">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-bold block">
                  Upload Media Draft File
                </label>
                <div className="border-2 border-dashed border-white/10 hover:border-[#C9A46A]/50 rounded-2xl p-5 text-center bg-[#111E33]/40 transition-colors relative">
                  <input
                    type="file"
                    accept={mediaType === 'video' ? 'video/*' : 'image/*'}
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <Upload className="w-8 h-8 text-[#C9A46A] mx-auto opacity-70 mb-2" style={{ color: primaryBrandColor }} />
                  {fileName ? (
                    <div className="space-y-1">
                      <span className="text-xs font-semibold text-emerald-400 block font-mono">✓ Selected: {fileName}</span>
                      <span className="text-[10px] text-slate-400">Click to swap file or test with preset samples below</span>
                    </div>
                  ) : (
                    <div>
                      <span className="text-xs font-medium text-white block">Drag and drop file or click to browse</span>
                      <span className="text-[10px] text-[#7C8AA8] block mt-1">Supports MP4, MOV, PNG, JPG up to 15MB</span>
                    </div>
                  )}
                </div>

                {/* Preset sample helpers */}
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[10px] text-slate-400 font-mono">Quick Test Samples:</span>
                  <button
                    type="button"
                    onClick={handleUseSampleVideo}
                    className="text-[10px] bg-[#111E33] hover:bg-[#16243F] border border-white/10 px-2.5 py-1 rounded-lg text-slate-300 transition-colors"
                  >
                    🎬 Load Sample Video Draft
                  </button>
                  <button
                    type="button"
                    onClick={handleUseSampleImage}
                    className="text-[10px] bg-[#111E33] hover:bg-[#16243F] border border-white/10 px-2.5 py-1 rounded-lg text-slate-300 transition-colors"
                  >
                    🖼️ Load Sample Photo Draft
                  </button>
                </div>
              </div>

              {/* Caption Input */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-bold block">
                  Proposed Social Media Caption &amp; Hashtags
                </label>
                <textarea
                  rows={3}
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder="e.g. Absolutely loving this new collection from @driproom! ✨ Link in bio to shop. #driproom #ad #style"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A] leading-relaxed"
                />
              </div>

              {/* Creator Notes to Team */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-bold block">
                  Creator Notes for Agent &amp; Director (Optional)
                </label>
                <input
                  type="text"
                  value={creatorNotes}
                  onChange={(e) => setCreatorNotes(e.target.value)}
                  placeholder="e.g. Video cuts at 00:12 can be trimmed if requested. Audio track licensed."
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg"
                style={{ backgroundColor: primaryBrandColor }}
              >
                <Send className="w-4 h-4" /> Submit Draft for Internal Review
              </button>
            </form>
          </div>

          {/* PREVIEW CONTAINER */}
          <div className="lg:col-span-5 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4 h-fit" style={{ backgroundColor: cardBgColor }}>
            <div className="border-b border-white/5 pb-2.5 flex justify-between items-center">
              <h3 className="font-serif font-semibold text-sm text-white uppercase tracking-wider">
                Live Draft Preview
              </h3>
              <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold" style={{ color: primaryBrandColor }}>
                {mediaType.toUpperCase()} MODE
              </span>
            </div>

            {previewUrl ? (
              <div className="space-y-3">
                <div className="bg-[#050e1a] border border-white/10 rounded-xl overflow-hidden relative aspect-video flex items-center justify-center">
                  {mediaType === 'video' ? (
                    <video src={previewUrl} controls className="w-full h-full object-cover" />
                  ) : (
                    <img src={previewUrl} alt="Draft preview" className="w-full h-full object-cover" />
                  )}
                </div>

                {caption && (
                  <div className="p-3 bg-[#111E33] border border-white/5 rounded-xl space-y-1">
                    <span className="text-[9px] font-mono text-slate-400 block uppercase font-bold">CAPTION PREVIEW:</span>
                    <p className="text-xs text-slate-200 leading-relaxed italic font-sans">{caption}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 border border-dashed border-white/10 rounded-xl text-center space-y-2">
                <Video className="w-10 h-10 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400">Select a file or click sample buttons to see the live media preview.</p>
              </div>
            )}

            <div className="p-3 bg-[#111E33] border border-amber-500/20 rounded-xl text-[10px] text-slate-300 leading-relaxed space-y-1">
              <span className="font-bold text-amber-400 flex items-center gap-1">
                <Shield className="w-3.5 h-3.5" /> Agency Gatekeeper Protection Active
              </span>
              <p className="text-slate-400">
                Drafts undergo internal compliance and quality review by your agency representative before being made visible to external brand sponsors.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* SUBMISSIONS QUEUE / MY CONTENT LIST VIEW */
        <div className="space-y-6">
          <div className="flex justify-between items-center border-b border-white/5 pb-3">
            <div>
              <h3 className="font-serif font-semibold text-lg text-white">
                {currentRole === 'creator' ? 'My Content Submissions & Review Status' : 'Agency Content Review Queue'}
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                {currentRole === 'creator'
                  ? 'Track approval status from your assigned agent, agent manager, and director.'
                  : 'Review drafts, authorize brand release, or request specific timeline/caption revisions.'}
              </p>
            </div>

            {currentRole === 'creator' && (
              <button
                onClick={() => setActiveScreen('submit-content')}
                className="bg-[#C9A46A] text-[#0A1220] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                style={{ backgroundColor: primaryBrandColor }}
              >
                <Upload className="w-3.5 h-3.5" /> Submit Another Draft
              </button>
            )}
          </div>

          {userSubmissions.length === 0 ? (
            <div className="p-12 bg-[#0D1830] border border-white/5 rounded-2xl text-center space-y-3">
              <FileText className="w-10 h-10 text-slate-500 mx-auto opacity-50" />
              <h4 className="text-sm font-semibold text-white">No content submissions found</h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                {currentRole === 'creator'
                  ? 'You have not submitted any draft videos or posts for review yet.'
                  : 'No creator draft submissions are currently waiting in the internal review queue.'}
              </p>
              {currentRole === 'creator' && (
                <button
                  onClick={() => setActiveScreen('submit-content')}
                  className="mt-2 bg-[#C9A46A] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  style={{ backgroundColor: primaryBrandColor }}
                >
                  <Upload className="w-3.5 h-3.5" /> Upload First Draft
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {userSubmissions.map((sub) => (
                <div
                  key={sub.id}
                  className="bg-[#0D1830] border border-white/10 hover:border-white/20 rounded-2xl p-5 space-y-4 transition-all"
                  style={{ backgroundColor: cardBgColor }}
                >
                  {/* Submission Header */}
                  <div className="flex justify-between items-start gap-3 border-b border-white/5 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-[#C9A46A] font-bold" style={{ color: primaryBrandColor }}>
                          {sub.creatorHandle}
                        </span>
                        <span className="text-[9px] text-slate-500">• {sub.submittedAt}</span>
                      </div>
                      <h4 className="text-sm font-bold text-white mt-1">{sub.campaignTitle}</h4>
                    </div>

                    {/* Status Badge */}
                    <span className={`text-[10px] font-mono font-bold px-3 py-1 rounded-full border ${
                      sub.status === 'Approved'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                        : sub.status === 'Needs Changes'
                        ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                        : 'bg-amber-500/10 border-amber-500/30 text-amber-400 animate-pulse'
                    }`}>
                      {sub.status === 'Approved' && '✓ APPROVED FOR BRAND'}
                      {sub.status === 'Needs Changes' && '❌ REVISION REQUESTED'}
                      {sub.status === 'Pending Internal Review' && '⏳ PENDING REVIEW'}
                    </span>
                  </div>

                  {/* Media Preview & Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
                    <div className="sm:col-span-5 bg-[#050e1a] border border-white/10 rounded-xl overflow-hidden aspect-video relative flex items-center justify-center">
                      {sub.mediaType === 'video' ? (
                        <video src={sub.fileUrl} controls className="w-full h-full object-cover" />
                      ) : (
                        <img src={sub.fileUrl} alt="Submission" className="w-full h-full object-cover" />
                      )}
                    </div>

                    <div className="sm:col-span-7 space-y-2 text-xs">
                      <div>
                        <span className="text-[9px] font-mono text-slate-400 block uppercase font-bold">CAPTION &amp; HASHTAGS:</span>
                        <p className="text-slate-200 line-clamp-3 text-[11px] leading-relaxed italic bg-[#111E33] p-2.5 rounded-lg border border-white/5 mt-1">
                          "{sub.caption}"
                        </p>
                      </div>

                      {sub.creatorNotes && (
                        <p className="text-[10px] text-slate-400">
                          <strong className="text-slate-300">Creator Note:</strong> {sub.creatorNotes}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Review Feedback Section */}
                  {sub.status === 'Needs Changes' && (
                    <div className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs space-y-1">
                      <div className="flex justify-between items-center text-rose-400 font-bold font-mono text-[10px]">
                        <span className="flex items-center gap-1"><XCircle className="w-3.5 h-3.5" /> REVISION INSTRUCTIONS FROM AGENCY:</span>
                        <span>{sub.reviewedBy}</span>
                      </div>
                      <p className="text-slate-200 text-[11px] leading-relaxed mt-1 font-sans">
                        "{sub.internalNotes}"
                      </p>
                      {currentRole === 'creator' && (
                        <button
                          onClick={() => setActiveScreen('submit-content')}
                          className="mt-2 text-[10px] bg-rose-500 hover:bg-rose-400 text-slate-950 font-bold px-3 py-1 rounded-lg transition-colors cursor-pointer"
                        >
                          🔄 Upload Revised Draft
                        </button>
                      )}
                    </div>
                  )}

                  {sub.status === 'Approved' && (
                    <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs flex justify-between items-center text-emerald-400 font-mono text-[10px]">
                      <span>✓ Approved by {sub.reviewedBy || 'Agency Director'} ({sub.reviewedAt})</span>
                      <span className="bg-emerald-950/60 border border-emerald-500/40 px-2 py-0.5 rounded text-emerald-300">
                        Ready for Brand Release
                      </span>
                    </div>
                  )}

                  {/* Staff Review Action Button vs Brand Feedback Button */}
                  {currentRole !== 'creator' && currentRole !== 'brand' && (
                    <div className="pt-2 border-t border-white/5 flex justify-end gap-2">
                      <button
                        onClick={() => {
                          setSelectedSubmission(sub);
                          setReviewNotes(sub.internalNotes || '');
                          setIsReviewModalOpen(true);
                        }}
                        className="bg-[#16243F] hover:bg-[#1f3050] text-[#C9A46A] border border-[#C9A46A]/30 text-xs font-semibold px-4 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                        style={{ color: primaryBrandColor }}
                      >
                        <Shield className="w-3.5 h-3.5" /> Review &amp; Update Status
                      </button>
                    </div>
                  )}

                  {currentRole === 'brand' && (
                    <div className="pt-2 border-t border-white/5 flex justify-between items-center gap-2">
                      <span className="text-[10px] text-slate-400 italic">
                        Verified Agency-Approved Deliverable
                      </span>
                      <button
                        onClick={() => {
                          const comment = prompt("Enter timestamped feedback or approval notes for the Agency Director (e.g., '00:12 - Love the product placement!'):");
                          if (comment) {
                            triggerNotification("Brand Feedback Submitted", `Sent notes on "${sub.campaignTitle}" to Agency Director.`, "success");
                            handleAddActivityLog(currentUser?.name || "Brand", "brand", `Left feedback on approved draft "${sub.campaignTitle}": ${comment}`);
                          }
                        }}
                        className="bg-[#C9A46A] text-[#0A1220] text-xs font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                        style={{ backgroundColor: primaryBrandColor }}
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Leave Timestamped Feedback
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* STAFF REVIEW MODAL */}
      {isReviewModalOpen && selectedSubmission && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-[#0D1830] border-2 border-[#C9A46A] rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl animate-scale-up" style={{ borderColor: primaryBrandColor }}>
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase" style={{ color: primaryBrandColor }}>
                  AGENCY COMPLIANCE REVIEW NODE
                </span>
                <h3 className="text-base font-bold text-white mt-0.5">
                  Reviewing: {selectedSubmission.campaignTitle}
                </h3>
              </div>
              <button
                onClick={() => setIsReviewModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#111E33] rounded-xl border border-white/5 space-y-1">
                <p className="text-slate-300"><strong className="text-white">Creator:</strong> {selectedSubmission.creatorName} ({selectedSubmission.creatorHandle})</p>
                <p className="text-slate-300"><strong className="text-white">Submitted at:</strong> {selectedSubmission.submittedAt}</p>
                <p className="text-slate-300 italic"><strong className="text-white">Caption:</strong> "{selectedSubmission.caption}"</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-bold block">
                  Reviewer Feedback / Revision Notes
                </label>
                <textarea
                  rows={3}
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Enter specific instructions if requesting changes (e.g. adjust lighting, fix hashtag, trim opening clip)..."
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A] leading-relaxed"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => handleApproveSubmission(selectedSubmission)}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <CheckCircle className="w-4 h-4" /> Approve Draft for Brand
                </button>
                <button
                  type="button"
                  onClick={() => handleRequestChanges(selectedSubmission)}
                  className="flex-1 bg-rose-600 hover:bg-rose-500 text-white font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <XCircle className="w-4 h-4" /> Request Revisions
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
