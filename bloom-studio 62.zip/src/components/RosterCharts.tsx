import React, { useState } from 'react';
import { 
  PieChart, BarChart2, Users, TrendingUp, Lock, Award, 
  Flame, Sparkles, Tag, ShieldCheck, CheckCircle2, AlertTriangle, Layers
} from 'lucide-react';
import { parseFollowerCount, parseEngagementRate, getSmartEngagementInfo, getNicheBadge } from './CreatorRosterManager';

interface RosterChartsProps {
  creators: any[];
  currentRole: string;
  currentUser: any;
  primaryBrandColor?: string;
}

export default function RosterCharts({
  creators = [],
  currentRole = 'director',
  currentUser,
  primaryBrandColor = '#C9A46A'
}: RosterChartsProps) {
  const [activeChartTab, setActiveChartTab] = useState<'all' | 'niches' | 'engagement' | 'platforms'>('all');

  // 1. Compute Platform Distribution
  const platformCounts: Record<string, number> = {};
  creators.forEach(c => {
    const p = c.platform || 'Other';
    platformCounts[p] = (platformCounts[p] || 0) + 1;
  });

  const totalCreators = creators.length || 1;
  const platformColors: Record<string, string> = {
    'Instagram': '#E1306C',
    'TikTok': '#00F2FE',
    'YouTube': '#FF0000',
    'Twitch': '#9146FF',
    'Twitter/X': '#1DA1F2',
    'Other': '#C9A46A'
  };
  const platformEntries = Object.entries(platformCounts).sort((a, b) => b[1] - a[1]);

  // Donut SVG slices calculation
  let cumulativePercent = 0;
  const getCoordinatesForPercent = (percent: number) => {
    const x = Math.cos(2 * Math.PI * percent);
    const y = Math.sin(2 * Math.PI * percent);
    return [x, y];
  };

  // 2. Compute Niche Breakdown (Core: Pets, Beauty, Lifestyle, etc.)
  const nicheCounts: Record<string, number> = {};
  creators.forEach(c => {
    const n = c.niche || 'Lifestyle';
    nicheCounts[n] = (nicheCounts[n] || 0) + 1;
  });
  const nicheEntries = Object.entries(nicheCounts).sort((a, b) => b[1] - a[1]);

  // 3. Compute Smart Engagement Tier Breakdown
  const smartEngTiers = {
    viral: { label: 'Viral Tier (>6.0%)', count: 0, color: '#F59E0B', icon: '🔥' },
    high: { label: 'High Performer (4.0-6.0%)', count: 0, color: '#10B981', icon: '⭐' },
    standard: { label: 'Solid Standard (2.5-4.0%)', count: 0, color: '#38BDF8', icon: '⚡' },
    low: { label: 'Underperforming (<2.5%)', count: 0, color: '#F43F5E', icon: '⚠️' }
  };

  creators.forEach(c => {
    const rate = parseEngagementRate(c.eng);
    const { tier } = getSmartEngagementInfo(rate);
    smartEngTiers[tier].count++;
  });

  // 4. Compute Representation Distribution
  const agreementCounts: Record<string, number> = {};
  creators.forEach(c => {
    const ag = c.agreement || 'Exclusive (80%)';
    const cleanAg = ag.includes('Exclusive') ? 'Exclusive' : ag.includes('Non-Exclusive') ? 'Non-Exclusive' : 'Co-Representation / Standard';
    agreementCounts[cleanAg] = (agreementCounts[cleanAg] || 0) + 1;
  });

  // 5. Follower Reach Leaderboard
  const topCreators = [...creators]
    .sort((a, b) => parseFollowerCount(b.followers) - parseFollowerCount(a.followers))
    .slice(0, 5);

  const maxFollowersRaw = Math.max(
    ...topCreators.map(c => parseFollowerCount(c.followers)),
    1
  );

  const scopeLabel = (() => {
    if (currentRole === 'director') return 'ALL PODS & ROSTER (DIRECTOR)';
    if (currentRole === 'subagency' || currentRole === 'agency') {
      const podName = currentUser?.subagencyName || currentUser?.subagency || currentUser?.agency || currentUser?.pod || currentUser?.name || 'Sub-Agency';
      return `POD: ${podName.toUpperCase()}`;
    }
    if (currentRole === 'agent' || currentRole === 'agentmgr') return 'ASSIGNED ROSTER ONLY';
    return currentRole.toUpperCase();
  })();

  return (
    <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-6 shadow-xl font-sans">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 inline-flex items-center gap-1.5 uppercase">
              <Lock className="w-3 h-3" />
              SCOPED TO: {scopeLabel}
            </span>
          </div>
          <h3 className="text-base font-semibold text-white flex items-center gap-2 mt-1">
            <PieChart className="w-4 h-4 text-[#C9A46A]" />
            Roster Visual Analytics &amp; KPI Charts
          </h3>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="text-right">
            <span className="text-[10px] text-[#7C8AA8] block font-mono uppercase">Visible Roster</span>
            <span className="text-lg font-bold text-white font-serif">{creators.length} Creators</span>
          </div>
        </div>
      </div>

      {/* Grid of KPI Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Card 1: Niche Distribution (Pets, Beauty, Lifestyle, etc.) */}
        <div className="bg-[#111E33] border border-white/5 rounded-xl p-5 space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-white flex items-center gap-1.5 uppercase tracking-wider text-[#C9A46A]">
              <Tag className="w-3.5 h-3.5" />
              Niche Breakdown
            </h4>
            <span className="text-[10px] font-mono text-[#7C8AA8]">Pets / Beauty / Lifestyle</span>
          </div>

          <div className="space-y-2.5 py-1">
            {nicheEntries.slice(0, 5).map(([niche, count]) => {
              const meta = getNicheBadge(niche);
              const percent = Math.round((count / totalCreators) * 100);
              return (
                <div key={niche} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span>{meta.icon}</span>
                      <span className="font-semibold text-slate-200">{niche}</span>
                    </div>
                    <div className="flex items-center gap-2 font-mono text-[11px]">
                      <span className="text-white font-bold">{count}</span>
                      <span className="text-slate-400">({percent}%)</span>
                    </div>
                  </div>
                  <div className="w-full bg-[#0A1220] h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500 bg-amber-400"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between border-t border-white/5 pt-2">
            <span>Primary Focus: Pets, Beauty, Lifestyle</span>
            <span className="text-amber-300 font-semibold">{nicheEntries.length} Niches Active</span>
          </div>
        </div>

        {/* Card 2: Smart Engagement Tier Distribution */}
        <div className="bg-[#111E33] border border-white/5 rounded-xl p-5 space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-white flex items-center gap-1.5 uppercase tracking-wider text-[#C9A46A]">
              <Sparkles className="w-3.5 h-3.5" />
              Smart Engagement Tiers
            </h4>
            <span className="text-[10px] font-mono text-[#7C8AA8]">Benchmarked @ 3.5%</span>
          </div>

          <div className="space-y-2.5 py-1">
            {Object.entries(smartEngTiers).map(([key, item]) => {
              const percent = Math.round((item.count / totalCreators) * 100);
              return (
                <div key={key} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span>{item.icon}</span>
                      <span className="font-semibold text-slate-200">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-2 font-mono text-[11px]">
                      <span className="text-white font-bold">{item.count}</span>
                      <span className="text-slate-400">({percent}%)</span>
                    </div>
                  </div>
                  <div className="w-full bg-[#0A1220] h-2 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${percent}%`, backgroundColor: item.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between border-t border-white/5 pt-2">
            <span>Healthy Target: &gt;4.0%</span>
            <span className="text-emerald-400 font-semibold">{smartEngTiers.viral.count + smartEngTiers.high.count} High Performers</span>
          </div>
        </div>

        {/* Card 3: Platform Share Donut & Breakdown */}
        <div className="bg-[#111E33] border border-white/5 rounded-xl p-5 space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-white flex items-center gap-1.5 uppercase tracking-wider text-[#C9A46A]">
              <PieChart className="w-3.5 h-3.5" />
              Platform Share
            </h4>
            <span className="text-[10px] font-mono text-[#7C8AA8]">Distribution</span>
          </div>

          <div className="flex items-center gap-4 justify-center py-1">
            {/* SVG Donut */}
            <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
              <svg viewBox="-1 -1 2 2" className="w-full h-full -rotate-90">
                {platformEntries.map(([platform, count]) => {
                  const percent = count / totalCreators;
                  const [startX, startY] = getCoordinatesForPercent(cumulativePercent);
                  cumulativePercent += percent;
                  const [endX, endY] = getCoordinatesForPercent(cumulativePercent);
                  const largeArcFlag = percent > 0.5 ? 1 : 0;
                  const pathData = percent === 1
                    ? `M 1 0 A 1 1 0 1 1 -1 0 A 1 1 0 1 1 1 0`
                    : `M ${startX} ${startY} A 1 1 0 ${largeArcFlag} 1 ${endX} ${endY} L 0 0`;
                  const color = platformColors[platform] || platformColors['Other'];

                  return (
                    <path
                      key={platform}
                      d={pathData}
                      fill={color}
                      className="hover:opacity-85 transition-opacity cursor-pointer"
                    >
                      <title>{`${platform}: ${count} (${Math.round(percent * 100)}%)`}</title>
                    </path>
                  );
                })}
                <circle cx="0" cy="0" r="0.6" fill="#111E33" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                <span className="text-sm font-bold text-white">{creators.length}</span>
                <span className="text-[8px] text-[#7C8AA8] uppercase">Talents</span>
              </div>
            </div>

            {/* Platform Legend */}
            <div className="flex-1 space-y-1.5 w-full">
              {platformEntries.map(([platform, count]) => {
                const percent = Math.round((count / totalCreators) * 100);
                const color = platformColors[platform] || platformColors['Other'];
                return (
                  <div key={platform} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: color }} />
                      <span className="text-slate-200 font-medium text-[11px]">{platform}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono text-[11px]">
                      <span className="text-white font-semibold">{count}</span>
                      <span className="text-[#7C8AA8]">({percent}%)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between border-t border-white/5 pt-2">
            <span>Primary Reach Channel</span>
            <span className="text-cyan-300 font-semibold">{platformEntries[0]?.[0] || 'TikTok'} Top</span>
          </div>
        </div>
      </div>

      {/* Leaderboard Row: Top Follower Reach Scale */}
      <div className="bg-[#111E33] border border-white/5 rounded-xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-semibold text-white flex items-center gap-1.5 uppercase tracking-wider text-[#C9A46A]">
            <BarChart2 className="w-3.5 h-3.5" />
            Top Follower Reach &amp; Smart Engagement Leaderboard
          </h4>
          <span className="text-[10px] font-mono text-[#7C8AA8]">Ranked by total audience size</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 pt-1">
          {topCreators.map((c, idx) => {
            const rawFollowers = parseFollowerCount(c.followers);
            const rate = parseEngagementRate(c.eng);
            const smartInfo = getSmartEngagementInfo(rate);
            const barPercent = Math.max(15, Math.min(100, Math.round((rawFollowers / maxFollowersRaw) * 100)));

            return (
              <div key={c.id || idx} className="bg-[#0D1830] border border-white/5 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white truncate">{c.name}</span>
                  <span className="text-[10px] font-mono text-amber-300 font-bold">{c.followers}</span>
                </div>
                <div className="text-[11px] text-[#7C8AA8] font-mono truncate">{c.handle}</div>
                <div className="w-full bg-[#0A1220] h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full" 
                    style={{ width: `${barPercent}%` }} 
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] pt-1">
                  <span className="text-slate-400">{getNicheBadge(c.niche).icon} {c.niche}</span>
                  <span className={`px-1.5 py-0.2 rounded font-mono font-bold ${smartInfo.badgeClass}`}>
                    {smartInfo.icon} {c.eng}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
