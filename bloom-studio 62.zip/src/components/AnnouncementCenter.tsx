import React, { useState, useMemo } from 'react';
import { 
  Bell, Megaphone, Users, User, Search, Plus, Trash2, CheckCircle2, 
  Clock, MessageSquare, ShieldCheck, Filter, Send, Radio, Sparkles, X, ChevronRight
} from 'lucide-react';
import { Role, Creator } from '../types';
import { AnnouncementItem } from './AnnouncementsModal';

interface AnnouncementCenterProps {
  announcements: AnnouncementItem[];
  setAnnouncements: React.Dispatch<React.SetStateAction<AnnouncementItem[]>>;
  currentRole: Role;
  currentUser: any;
  creators: Creator[];
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  agentMgrCanAnnounce?: boolean;
}

export default function AnnouncementCenter({
  announcements,
  setAnnouncements,
  currentRole = 'director',
  currentUser,
  creators = [],
  triggerNotification,
  onAddActivityLog,
  agentMgrCanAnnounce = false
}: AnnouncementCenterProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'staff' | 'talent'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isComposing, setIsComposing] = useState(false);

  // Compose form state
  const [newTitle, setNewTitle] = useState('');
  const [newText, setNewText] = useState('');
  const [newAudience, setNewAudience] = useState<'Everyone' | 'Staff Only' | 'Creators Only'>('Everyone');
  const [newPriority, setNewPriority] = useState<'normal' | 'important' | 'urgent'>('normal');

  const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase());
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const roleName = (currentRole || 'none').toLowerCase();

  // Filtered by Audience Tab & Search
  const filteredAnnouncements = useMemo(() => {
    return announcements.filter(item => {
      // Tab filter
      const aud = (item.audience || '').toLowerCase();
      if (activeTab === 'staff') {
        const isStaffAud = aud.includes('staff') || aud.includes('agent') || aud.includes('team') || aud.includes('everyone') || aud.includes('all');
        if (!isStaffAud) return false;
      } else if (activeTab === 'talent') {
        const isTalentAud = aud.includes('creator') || aud.includes('talent') || aud.includes('everyone') || aud.includes('all');
        if (!isTalentAud) return false;
      }

      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return item.title.toLowerCase().includes(q) || item.text.toLowerCase().includes(q) || item.author.toLowerCase().includes(q);
      }
      return true;
    });
  }, [announcements, activeTab, searchQuery]);

  const canPost = isDirector || (isAgentMgr && agentMgrCanAnnounce);

  const handlePostAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canPost) return;
    if (!newTitle.trim() || !newText.trim()) return;

    const newItem: AnnouncementItem = {
      id: 'ann_' + Date.now(),
      title: newTitle.trim(),
      text: newText.trim(),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      createdAt: new Date().toISOString(),
      author: currentUser?.name || (isDirector ? 'Director' : 'Lead Manager'),
      authorRole: currentRole,
      audience: newAudience,
      priority: newPriority,
      readBy: [currentUser?.name || 'User']
    };

    setAnnouncements(prev => [newItem, ...prev]);
    setIsComposing(false);
    setNewTitle('');
    setNewText('');

    if (triggerNotification) {
      triggerNotification("Broadcast Dispatched", `Published announcement to ${newAudience}`, "success");
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "User", currentRole, `Broadcasted announcement: "${newTitle.trim()}" to ${newAudience}`);
    }
  };

  const handleDelete = (id: string, title: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== id));
    if (triggerNotification) {
      triggerNotification("Announcement Removed", `Deleted "${title}"`, "info");
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "User", currentRole, `Deleted announcement: "${title}"`);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-6xl mx-auto">
      {/* Top Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <Megaphone className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                UNIFIED ANNOUNCEMENT CENTER
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <Radio className="w-3 h-3 animate-pulse text-emerald-400" />
                Live Studio Broadcast
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              Announcements
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Consolidated communications hub broadcasting studio updates across All, Staff, and Talent channels.
            </p>
          </div>
        </div>

        {canPost && (
          <button
            type="button"
            onClick={() => setIsComposing(true)}
            className="inline-flex items-center gap-2 bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] font-bold text-xs px-5 py-3 rounded-xl shadow-lg transition-all cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Create Announcement</span>
          </button>
        )}
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#0D1830] border border-white/10 rounded-xl p-3">
        {/* Audience Segment Tabs */}
        <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/5 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'all'
                ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>All Announcements</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">
              {announcements.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('staff')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'staff'
                ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Staff &amp; Agents Only</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">
              {announcements.filter(a => (a.audience || '').toLowerCase().includes('staff') || (a.audience || '').toLowerCase().includes('agent') || (a.audience || '').toLowerCase().includes('everyone')).length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('talent')}
            className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'talent'
                ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Talent / Creators Only</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-black/20">
              {announcements.filter(a => (a.audience || '').toLowerCase().includes('creator') || (a.audience || '').toLowerCase().includes('talent') || (a.audience || '').toLowerCase().includes('everyone')).length}
            </span>
          </button>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search broadcasts..."
            className="w-full bg-black/30 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
          />
        </div>
      </div>

      {/* Announcements Feed */}
      <div className="space-y-3">
        {filteredAnnouncements.length === 0 ? (
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-12 text-center space-y-3">
            <Megaphone className="w-10 h-10 text-slate-500 mx-auto opacity-50" />
            <h3 className="text-sm font-bold text-white">No Announcements Found</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              No bulletins match your current audience filter or search query. Click "Create Announcement" to broadcast a message.
            </p>
          </div>
        ) : (
          filteredAnnouncements.map((ann) => {
            const isUrgent = ann.priority === 'urgent';
            const isImportant = ann.priority === 'important';

            return (
              <div 
                key={ann.id}
                className={`bg-[#0D1830] border rounded-2xl p-5 space-y-3 transition-all hover:border-[#C9A46A]/40 shadow-lg relative ${
                  isUrgent 
                    ? 'border-rose-500/50 bg-rose-950/10' 
                    : isImportant 
                    ? 'border-amber-500/40' 
                    : 'border-white/10'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border bg-white/5 border-white/10 text-slate-300">
                      Target: {ann.audience || 'Everyone'}
                    </span>

                    {isUrgent && (
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />
                        Urgent
                      </span>
                    )}

                    {isImportant && (
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        Priority
                      </span>
                    )}

                    <span className="text-[11px] font-mono text-slate-400">
                      &bull; {ann.date || 'Today'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 font-mono">
                      By <strong className="text-white">{ann.author}</strong>
                    </span>

                    {canPost && (
                      <button
                        type="button"
                        onClick={() => handleDelete(ann.id, ann.title)}
                        className="text-slate-500 hover:text-rose-400 p-1.5 rounded-lg hover:bg-rose-500/10 transition cursor-pointer"
                        title="Delete Announcement"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="space-y-1">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Bell className="w-4 h-4 text-[#C9A46A]" />
                    {ann.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line pt-1">
                    {ann.text}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Compose Modal */}
      {isComposing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2 text-[#C9A46A] text-xs font-mono font-bold uppercase">
                <Megaphone className="w-4 h-4" />
                <span>Broadcast New Announcement</span>
              </div>
              <button 
                onClick={() => setIsComposing(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePostAnnouncement} className="space-y-4 font-mono text-xs">
              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Target Audience Channel</label>
                <select
                  value={newAudience}
                  onChange={(e: any) => setNewAudience(e.target.value)}
                  className="w-full bg-[#16243F] border border-white/10 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Everyone">Studio-Wide (All Staff &amp; Creators)</option>
                  <option value="Staff Only">Staff &amp; Agent Managers Only</option>
                  <option value="Creators Only">Creators &amp; Talent Only</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Priority Level</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['normal', 'important', 'urgent'] as const).map(p => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setNewPriority(p)}
                      className={`py-2 rounded-xl border text-center capitalize text-xs font-bold transition cursor-pointer ${
                        newPriority === p
                          ? p === 'urgent'
                            ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                            : p === 'important'
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                            : 'bg-[#C9A46A]/20 border-[#C9A46A] text-[#C9A46A]'
                          : 'bg-white/5 border-white/10 text-slate-400'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Announcement Headline</label>
                <input
                  type="text"
                  placeholder="e.g. Q3 Brand Gifting Pipeline Kickoff"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-[#16243F] border border-white/10 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Announcement Message Body</label>
                <textarea
                  rows={4}
                  placeholder="Type message content..."
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  className="w-full bg-[#16243F] border border-white/10 rounded-xl p-3 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsComposing(false)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] font-bold text-xs uppercase tracking-wider shadow-lg transition cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Broadcast Now</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
