import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, X, Sparkles, Image as ImageIcon, Upload, Eye, Check, ShieldCheck, 
  Share2, Copy, Mail, Plus, Trash2, Filter, Search, Download, ArrowUpRight,
  TrendingUp, Users, DollarSign, Calendar, Layers, Smartphone, RefreshCw,
  Edit3, Sliders, CheckCircle2, MessageSquare, AlertCircle, FileText, Lock
} from 'lucide-react';
import { Creator, Deal, BrandSwipeRecord } from '../types';
import { db } from '../lib/firebase';
import { doc, deleteDoc } from 'firebase/firestore';
import { moveToTrash } from '../lib/trashService';
import { safeStorage } from '../utils/safeStorage';
import { checkBrandBlacklist } from '../lib/blacklistService';

interface DirectorMatchDeckManagerProps {
  creators: Creator[];
  setCreators?: React.Dispatch<React.SetStateAction<Creator[]>>;
  deals?: Deal[];
  onAddDeal?: (deal: Deal) => void;
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentUser?: any;
  currentRole?: string;
  onOpenSneakPeekModal?: () => void;
}

// Initial seed brand swipes to demonstrate live brand activity
const INITIAL_SEED_SWIPES: BrandSwipeRecord[] = [
  {
    id: 'swipe_1',
    brandName: 'Nike Global Partnerships',
    brandContactName: 'Elena Rostova',
    brandContactEmail: 'partnerships@nike.com',
    creatorId: 'c1',
    creatorHandle: '@LunaTheHusky',
    creatorName: 'Luna & Family',
    creatorNumber: 'Creator #101',
    creatorNiche: 'Pets',
    creatorAvatar: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80',
    action: 'match',
    timestamp: Date.now() - 1000 * 60 * 18, // 18 mins ago
    dateStr: 'Today at ' + new Date(Date.now() - 1000 * 60 * 18).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    timeAgo: '18m ago',
    proposedBudget: 4500,
    platform: 'TikTok',
    deliverables: '1x 60s Dedicated Pet Lifestyle Reel + 30-day Spark Ads',
    notes: 'Looking for a hero dog for our Spring Activewear & Running Pup campaign.',
    dealCreated: false
  },
  {
    id: 'swipe_2',
    brandName: 'Glossier Brand Team',
    brandContactName: 'Chloe Bennett',
    brandContactEmail: 'talent@glossier.com',
    creatorId: 'c2',
    creatorHandle: '@BellaGlow',
    creatorName: 'Bella Vance',
    creatorNumber: 'Creator #102',
    creatorNiche: 'Beauty',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    action: 'match',
    timestamp: Date.now() - 1000 * 60 * 55, // 55 mins ago
    dateStr: 'Today at ' + new Date(Date.now() - 1000 * 60 * 55).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    timeAgo: '55m ago',
    proposedBudget: 6000,
    platform: 'Instagram',
    deliverables: '2x IG Reels + 1x Carousel Post on Dewy Skin Routine',
    notes: 'Perfect aesthetic for our new Cloud Paint expansion.',
    dealCreated: true,
    dealId: 'deal_glossier_01'
  },
  {
    id: 'swipe_3',
    brandName: 'Alo Yoga Marketing',
    brandContactName: 'Marcus Shaw',
    brandContactEmail: 'creators@aloyoga.com',
    creatorId: 'c3',
    creatorHandle: '@MarcusVibe',
    creatorName: 'Marcus Cole',
    creatorNumber: 'Creator #103',
    creatorNiche: 'Lifestyle',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80',
    action: 'match',
    timestamp: Date.now() - 1000 * 60 * 140, // 2.3 hrs ago
    dateStr: 'Today at ' + new Date(Date.now() - 1000 * 60 * 140).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    timeAgo: '2h ago',
    proposedBudget: 3500,
    platform: 'TikTok',
    deliverables: '1x TikTok "Morning Reset & Yoga Routine" + Organic Sound',
    notes: 'Wants creator to feature Men’s Warrior Mat & Bamboo hoodie.',
    dealCreated: false
  },
  {
    id: 'swipe_4',
    brandName: 'Gymshark Partnerships',
    brandContactName: 'Dave Miller',
    brandContactEmail: 'talent@gymshark.com',
    creatorId: 'c4',
    creatorHandle: '@MiloFluff',
    creatorName: 'Milo the Golden',
    creatorNumber: 'Creator #104',
    creatorNiche: 'Pets',
    creatorAvatar: 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=800&auto=format&fit=crop&q=80',
    action: 'pass',
    timestamp: Date.now() - 1000 * 60 * 210, // 3.5 hrs ago
    dateStr: 'Today at ' + new Date(Date.now() - 1000 * 60 * 210).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    timeAgo: '3h ago',
    notes: 'Niche mismatch: Looking strictly for bodybuilding/fitness athletes.'
  },
  {
    id: 'swipe_5',
    brandName: 'Sephora Talent Desk',
    brandContactName: 'Samantha Wu',
    brandContactEmail: 'swu@sephora.com',
    creatorId: 'c2',
    creatorHandle: '@BellaGlow',
    creatorName: 'Bella Vance',
    creatorNumber: 'Creator #102',
    creatorNiche: 'Beauty',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    action: 'match',
    timestamp: Date.now() - 1000 * 60 * 360, // 6 hrs ago
    dateStr: 'Today at ' + new Date(Date.now() - 1000 * 60 * 360).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    timeAgo: '6h ago',
    proposedBudget: 7500,
    platform: 'YouTube',
    deliverables: '1x Dedicated 8-10 min YouTube Haul & Swatch Video',
    notes: 'Spring Savings Event Hero Placement.',
    dealCreated: false
  },
  {
    id: 'swipe_6',
    brandName: 'HelloFresh Influencer Ops',
    brandContactName: 'Jordan Reed',
    brandContactEmail: 'influencers@hellofresh.com',
    creatorId: 'c3',
    creatorHandle: '@MarcusVibe',
    creatorName: 'Marcus Cole',
    creatorNumber: 'Creator #103',
    creatorNiche: 'Lifestyle',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80',
    action: 'pass',
    timestamp: Date.now() - 1000 * 60 * 500,
    dateStr: 'Yesterday',
    timeAgo: '8h ago',
    notes: 'Passed: Target audience demographic skewing too young for kitchen subscription.'
  }
];

export default function DirectorMatchDeckManager({
  creators,
  setCreators,
  deals = [],
  onAddDeal,
  onAddActivityLog,
  triggerNotification,
  currentUser,
  currentRole = 'director',
  onOpenSneakPeekModal
}: DirectorMatchDeckManagerProps) {
  const [activeTab, setActiveTab] = useState<'brand_swipes' | 'deck_manager' | 'talent_mapping' | 'niche_settings'>('talent_mapping');
  const [swipeFilter, setSwipeFilter] = useState<'all' | 'match' | 'pass'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [nicheFilter, setNicheFilter] = useState<string>('all');

  // Stored brand swipes feed
  const [brandSwipes, setBrandSwipes] = useState<BrandSwipeRecord[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_brand_swipe_feed');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return INITIAL_SEED_SWIPES;
  });

  // Sync brand swipes
  useEffect(() => {
    try {
      safeStorage.setItem('wl_brand_swipe_feed', JSON.stringify(brandSwipes));
    } catch (e) {}
  }, [brandSwipes]);

  // Listen for storage events (e.g. if brand swipes in another tab/view)
  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'wl_brand_swipe_feed' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed)) setBrandSwipes(parsed);
        } catch (err) {}
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Image Upload / Card Editor Modal State
  const [editingCreator, setEditingCreator] = useState<Creator | null>(null);
  const [editorPhotoUrl, setEditorPhotoUrl] = useState<string>('');
  const [editorTagline, setEditorTagline] = useState<string>('');
  const [editorFeaturedNiche, setEditorFeaturedNiche] = useState<string>('Pets');
  const [editorHighlights, setEditorHighlights] = useState<string>('');
  const [editorCarouselPhotos, setEditorCarouselPhotos] = useState<string[]>([]);
  const [previewCardCreator, setPreviewCardCreator] = useState<Creator | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Add Creator Modal State
  const [isAddCreatorOpen, setIsAddCreatorOpen] = useState(false);
  const [newCreatorForm, setNewCreatorForm] = useState({
    name: '',
    handle: '',
    niche: 'Beauty',
    followers: '350K',
    engagementRate: '5.8%',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    bio: 'Lifestyle & UGC content creator.'
  });

  const handleDeleteCreator = async (creatorId: string, creatorName: string) => {
    const creatorItem = creators.find(c => c.id === creatorId || c.handle === creatorId) || {
      id: creatorId,
      name: creatorName,
      handle: creatorId
    };

    try {
      await moveToTrash('studio-creators', creatorItem, 'creator', currentUser);
    } catch (err) {
      console.error(`Error moving creator to trash:`, err);
    }

    if (setCreators) {
      setCreators(prev => prev.filter(c => c.id !== creatorId && c.handle?.toLowerCase() !== creatorId.toLowerCase()));
    }

    try {
      const savedCustomCreators = safeStorage.getItem('wl_custom_deck_creators');
      if (savedCustomCreators) {
        const map = JSON.parse(savedCustomCreators);
        delete map[creatorId];
        safeStorage.setItem('wl_custom_deck_creators', JSON.stringify(map));
      }
    } catch (e) {}

    triggerNotification('Creator Moved to Trash', `${creatorName} archived to Recoup Trash (30-day recovery window active).`, 'info');
    onAddActivityLog(currentUser?.name || 'User', currentRole, `Moved creator ${creatorName} to 30-day trash bin`);
  };

  const handleDismissSwipe = (swipeId: string) => {
    setBrandSwipes(prev => prev.filter(s => s.id !== swipeId));
    try {
      const saved = safeStorage.getItem('wl_brand_swipes_live');
      if (saved) {
        const parsed = JSON.parse(saved);
        const updated = parsed.filter((s: any) => s.id !== swipeId);
        safeStorage.setItem('wl_brand_swipes_live', JSON.stringify(updated));
      }
    } catch (e) {}
    triggerNotification('Swipe Dismissed', 'Brand swipe record removed from active match feed.', 'info');
  };

  const handleSelectExistingCreatorForDeck = (handle: string) => {
    const selected = creators.find(c => c.handle === handle || c.id === handle);
    if (selected) {
      setNewCreatorForm({
        name: selected.name,
        handle: selected.handle,
        niche: selected.niche || 'Beauty',
        followers: selected.followers || '300K',
        engagementRate: selected.eng || '5.5%',
        avatar: selected.matchOrPassPrimaryPhoto || selected.avatar || '',
        bio: selected.bio || 'Lifestyle UGC Creator'
      });
    }
  };

  const handleAddNewCreatorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCreatorForm.name.trim() || !newCreatorForm.handle.trim()) {
      alert('Please fill out creator name and handle.');
      return;
    }

    const created: Creator = {
      id: 'cr_' + Date.now(),
      name: newCreatorForm.name,
      handle: newCreatorForm.handle.startsWith('@') ? newCreatorForm.handle : `@${newCreatorForm.handle}`,
      avatar: newCreatorForm.avatar,
      matchOrPassPrimaryPhoto: newCreatorForm.avatar,
      niche: newCreatorForm.niche as any,
      matchOrPassFeaturedNiche: newCreatorForm.niche,
      followers: newCreatorForm.followers,
      eng: newCreatorForm.engagementRate,
      platform: 'TikTok',
      agreement: 'Non-Exclusive (70%)',
      bio: newCreatorForm.bio,
      location: 'USA',
      email: `${newCreatorForm.handle.replace('@', '')}@creator.com`,
      phone: '+1 555-0192',
      status: 'Active',
      matchOrPassActive: true
    };

    if (setCreators) {
      setCreators(prev => [created, ...prev]);
    }

    setIsAddCreatorOpen(false);
    triggerNotification('Creator Added', `${created.name} (${created.handle}) is now active in the deck!`, 'success');
    onAddActivityLog(currentUser?.name || 'User', currentRole, `Added ${created.handle} to Match or Pass Deck`);

    // Reset form
    setNewCreatorForm({
      name: '',
      handle: '',
      niche: 'Beauty',
      followers: '350K',
      engagementRate: '5.8%',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
      bio: 'Lifestyle & UGC content creator.'
    });
  };

  // Stats calculation
  const totalSwipes = brandSwipes.length;
  const totalMatches = brandSwipes.filter(s => s.action === 'match').length;
  const totalPasses = brandSwipes.filter(s => s.action === 'pass').length;
  const matchRate = totalSwipes > 0 ? Math.round((totalMatches / totalSwipes) * 100) : 0;
  const activeDeckCreatorsCount = creators.filter(c => c.matchOrPassActive !== false && c.status === 'Active').length;

  // Filtered Swipes Feed
  const filteredSwipes = useMemo(() => {
    return brandSwipes.filter(swipe => {
      if (swipeFilter === 'match' && swipe.action !== 'match') return false;
      if (swipeFilter === 'pass' && swipe.action !== 'pass') return false;
      if (nicheFilter !== 'all' && swipe.creatorNiche?.toLowerCase() !== nicheFilter.toLowerCase()) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const b = swipe.brandName.toLowerCase();
        const c = (swipe.creatorName || '').toLowerCase() + (swipe.creatorHandle || '').toLowerCase() + (swipe.creatorNumber || '').toLowerCase();
        return b.includes(q) || c.includes(q);
      }
      return true;
    });
  }, [brandSwipes, swipeFilter, nicheFilter, searchQuery]);

  // Open Edit Modal for a Creator
  const handleOpenPhotoEditor = (creator: Creator) => {
    setEditingCreator(creator);
    setEditorPhotoUrl(creator.matchOrPassPrimaryPhoto || creator.avatar || '');
    setEditorTagline(creator.matchOrPassTagline || `${creator.niche} Creator • ${creator.followers} Followers`);
    setEditorFeaturedNiche(creator.matchOrPassFeaturedNiche || creator.niche || 'Pets');
    setEditorHighlights((creator.matchOrPassHighlights || ['High Engagement', 'Top UGC ROI', 'Fast Turnaround']).join(', '));
    setEditorCarouselPhotos(creator.matchOrPassImages && creator.matchOrPassImages.length > 0 
      ? [...creator.matchOrPassImages] 
      : [creator.avatar || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80']
    );
  };

  // Handle local file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      triggerNotification('Invalid File', 'Please upload a valid image file (PNG, JPG, WebP).', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        setEditorPhotoUrl(base64);
        setEditorCarouselPhotos(prev => [base64, ...prev.filter(p => p !== base64)]);
        triggerNotification('Photo Loaded', 'Image ready for Match or Pass card deck.', 'success');
      }
    };
    reader.readAsDataURL(file);
  };

  // Save creator card details
  const handleSaveCreatorCard = () => {
    if (!editingCreator) return;

    const highlightsArray = editorHighlights
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    const updatedCreator: Creator = {
      ...editingCreator,
      avatar: editorPhotoUrl || editingCreator.avatar,
      matchOrPassPrimaryPhoto: editorPhotoUrl || editingCreator.avatar,
      matchOrPassImages: editorCarouselPhotos.length > 0 ? editorCarouselPhotos : [editorPhotoUrl],
      matchOrPassTagline: editorTagline,
      matchOrPassFeaturedNiche: editorFeaturedNiche,
      matchOrPassHighlights: highlightsArray,
      matchOrPassActive: true
    };

    if (setCreators) {
      setCreators(prev => prev.map(c => c.id === editingCreator.id ? updatedCreator : c));
    }

    // Save to local storage for persistent testing
    try {
      const savedCustomCreators = safeStorage.getItem('wl_custom_deck_creators');
      const map = savedCustomCreators ? JSON.parse(savedCustomCreators) : {};
      map[editingCreator.id] = updatedCreator;
      safeStorage.setItem('wl_custom_deck_creators', JSON.stringify(map));
    } catch (e) {}

    onAddActivityLog(
      currentUser?.name || 'User',
      currentRole,
      `Updated Match or Pass card visual & deck assets for ${editingCreator.name} (${editingCreator.handle})`
    );

    triggerNotification(
      'Deck Photo Updated',
      `Brand-facing Match or Pass photo updated for ${editingCreator.name}.`,
      'success'
    );

    setEditingCreator(null);
  };

  // Toggle Creator active in deck
  const handleToggleDeckActive = (creatorId: string, currentActive: boolean) => {
    const newActive = !currentActive;
    if (setCreators) {
      setCreators(prev => prev.map(c => c.id === creatorId ? { ...c, matchOrPassActive: newActive } : c));
    }
    triggerNotification(
      'Deck Visibility Updated',
      `Creator ${newActive ? 'enabled in' : 'hidden from'} brand Match or Pass deck.`,
      newActive ? 'success' : 'info'
    );
  };

  // Convert Brand Match to Active Deal Pipeline
  const handleConvertToDeal = async (swipe: BrandSwipeRecord) => {
    if (swipe.dealCreated) {
      triggerNotification('Already Converted', 'A deal was already initiated for this match.', 'info');
      return;
    }

    const cleanBrand = (swipe.brandName || '').trim();
    if (cleanBrand) {
      const blCheck = await checkBrandBlacklist(cleanBrand, currentUser?.tenantId);
      if (blCheck.isBlacklisted) {
        triggerNotification(
          'Deal Conversion Blocked',
          `Brand '${blCheck.matchedBrand || cleanBrand}' is on the Global Blacklist (${blCheck.reason}). Deal and contract initiation is prohibited.`,
          'danger'
        );
        return;
      }
    }

    const newDeal: Deal = {
      id: 'deal_match_' + Date.now(),
      brand: swipe.brandName,
      title: `Match or Pass Booking: ${swipe.creatorNumber} × ${swipe.brandName}`,
      creator: swipe.creatorHandle || swipe.creatorName,
      creatorHandle: swipe.creatorHandle,
      budget: swipe.proposedBudget || 4500,
      value: swipe.proposedBudget || 4500,
      amount: swipe.proposedBudget || 4500,
      platform: swipe.platform || 'TikTok',
      stage: 'Negotiating',
      due: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      type: 'Brand Matchmaking Lead',
      coordinator: 'Marcus Cole',
      assignedAgent: 'Marcus Cole'
    };

    if (onAddDeal) {
      onAddDeal(newDeal);
    }

    // Update swipe record
    setBrandSwipes(prev => prev.map(s => s.id === swipe.id ? { ...s, dealCreated: true, dealId: newDeal.id } : s));

    onAddActivityLog(
      currentUser?.name || 'User',
      currentRole,
      `Converted brand match (${swipe.brandName} × ${swipe.creatorNumber}) into Deal Pipeline ($${(swipe.proposedBudget || 4500).toLocaleString()})`
    );

    triggerNotification(
      'Deal Created from Brand Match',
      `Deal added to pipeline with ${swipe.brandName} for $${(swipe.proposedBudget || 4500).toLocaleString()}.`,
      'success'
    );
  };

  // Clear or reset sample swipes
  const handleResetFeed = () => {
    setBrandSwipes(INITIAL_SEED_SWIPES);
    try {
      safeStorage.setItem('wl_brand_swipe_feed', JSON.stringify(INITIAL_SEED_SWIPES));
    } catch (e) {}
    triggerNotification('Feed Synced', 'Brand match/pass audit feed reset to baseline.', 'info');
  };

  return (
    <div className="space-y-6 w-full max-w-7xl mx-auto">
      {/* Top Header & Director Control Notice */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#081222] border border-blue-900/40 p-6 rounded-3xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#C9A46A]/15 text-[#C9A46A] border border-[#C9A46A]/30 uppercase tracking-wider">
              Director Master Control
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Live Brand Telemetry Active
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-serif tracking-tight">
            Match or Pass Deck Oversight &amp; Brand Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl font-sans mt-1">
            Directors manage deck photos, control talent visibility, and monitor what enterprise brands have matched or passed on in real time.
          </p>
        </div>

        {/* Action Buttons for Director */}
        <div className="flex items-center gap-3 shrink-0 flex-wrap">
          {onOpenSneakPeekModal && (
            <button
              onClick={onOpenSneakPeekModal}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0D1830] hover:bg-[#132347] border border-blue-900/50 hover:border-[#C9A46A]/50 text-slate-200 hover:text-white text-xs font-mono font-semibold transition cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-[#C9A46A]" />
              <span>Sneak Peek Strategy Kit</span>
            </button>
          )}

          <button
            onClick={() => {
              const active = creators.find(c => c.status === 'Active') || creators[0];
              if (active) setPreviewCardCreator(active);
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#b89359] text-[#070D18] text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer shadow-lg shadow-[#C9A46A]/20"
          >
            <Smartphone className="w-4 h-4" />
            <span>Preview Brand Deck</span>
          </button>
        </div>
      </div>

      {/* Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="bg-[#0D1830] border border-blue-900/40 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider block">Total Brand Swipes</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-white font-mono">{totalSwipes}</span>
            <span className="text-[10px] text-slate-400 font-mono">logged</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-emerald-900/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-mono uppercase text-emerald-400 tracking-wider block">Brand Matches (Likes)</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-emerald-400 font-mono">{totalMatches}</span>
            <span className="text-[10px] text-emerald-500/80 font-mono">❤️ right swipes</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-rose-900/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-mono uppercase text-rose-400 tracking-wider block">Brand Passes</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-rose-400 font-mono">{totalPasses}</span>
            <span className="text-[10px] text-rose-500/80 font-mono">❌ left swipes</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-mono uppercase text-[#C9A46A] tracking-wider block">Match Conversion</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-[#C9A46A] font-mono">{matchRate}%</span>
            <span className="text-[10px] text-[#C9A46A]/80 font-mono">win rate</span>
          </div>
        </div>

        <div className="bg-[#0D1830] border border-blue-900/40 rounded-2xl p-4 space-y-1 col-span-2 sm:col-span-1">
          <span className="text-[10px] font-mono uppercase text-blue-400 tracking-wider block">Active in Deck</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-white font-mono">{activeDeckCreatorsCount}</span>
            <span className="text-[10px] text-slate-400 font-mono">of {creators.length} roster</span>
          </div>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-2 border-b border-blue-900/40 pb-3 overflow-x-auto">
        <button
          onClick={() => setActiveTab('brand_swipes')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === 'brand_swipes'
              ? 'bg-[#C9A46A] text-[#070D18]'
              : 'bg-[#0D1830] text-slate-300 hover:text-white border border-blue-900/40'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Brand Swipes &amp; Matches Feed ({brandSwipes.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('deck_manager')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === 'deck_manager'
              ? 'bg-[#C9A46A] text-[#070D18]'
              : 'bg-[#0D1830] text-slate-300 hover:text-white border border-blue-900/40'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>Upload Deck Photos &amp; Creator Cards ({creators.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('talent_mapping')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === 'talent_mapping'
              ? 'bg-[#C9A46A] text-[#070D18]'
              : 'bg-[#0D1830] text-slate-300 hover:text-white border border-blue-900/40'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Creator # Mapping Directory ({creators.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('niche_settings')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === 'niche_settings'
              ? 'bg-[#C9A46A] text-[#070D18]'
              : 'bg-[#0D1830] text-slate-300 hover:text-white border border-blue-900/40'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Deck Niches &amp; Security Ledger</span>
        </button>
      </div>

      {/* TAB 1: LIVE BRAND SWIPES FEED */}
      {activeTab === 'brand_swipes' && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-[#081222] p-4 rounded-2xl border border-blue-900/40">
            <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search brand, creator #..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-[#0D1830] border border-blue-900/40 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              {/* Action Filter Pills */}
              <div className="flex items-center bg-[#0D1830] p-1 rounded-xl border border-blue-900/40">
                <button
                  onClick={() => setSwipeFilter('all')}
                  className={`px-3 py-1 rounded-lg text-[11px] font-mono transition cursor-pointer ${swipeFilter === 'all' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
                >
                  All ({brandSwipes.length})
                </button>
                <button
                  onClick={() => setSwipeFilter('match')}
                  className={`px-3 py-1 rounded-lg text-[11px] font-mono transition cursor-pointer flex items-center gap-1 ${swipeFilter === 'match' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-emerald-400'}`}
                >
                  <Heart className="w-3 h-3 fill-current" />
                  Matches ({totalMatches})
                </button>
                <button
                  onClick={() => setSwipeFilter('pass')}
                  className={`px-3 py-1 rounded-lg text-[11px] font-mono transition cursor-pointer flex items-center gap-1 ${swipeFilter === 'pass' ? 'bg-rose-700 text-white font-bold' : 'text-slate-400 hover:text-rose-400'}`}
                >
                  <X className="w-3 h-3" />
                  Passes ({totalPasses})
                </button>
              </div>

              {/* Niche selector */}
              <select
                value={nicheFilter}
                onChange={e => setNicheFilter(e.target.value)}
                className="bg-[#0D1830] border border-blue-900/40 rounded-xl px-3 py-1.5 text-xs text-slate-300 focus:outline-none cursor-pointer"
              >
                <option value="all">All Niches</option>
                <option value="pets">Pets</option>
                <option value="beauty">Beauty</option>
                <option value="lifestyle">Lifestyle</option>
              </select>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                onClick={handleResetFeed}
                title="Reset sample feed"
                className="p-2 rounded-xl bg-[#0D1830] hover:bg-[#132347] border border-blue-900/40 text-slate-400 hover:text-white text-xs font-mono transition cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Sync Telemetry</span>
              </button>
            </div>
          </div>

          {/* Swipes Feed List */}
          <div className="space-y-3">
            {filteredSwipes.length === 0 ? (
              <div className="bg-[#081222] border border-dashed border-blue-900/40 rounded-3xl p-12 text-center space-y-2">
                <Filter className="w-8 h-8 text-slate-500 mx-auto" />
                <h3 className="text-sm font-bold text-white">No Swipes Found</h3>
                <p className="text-xs text-slate-400">No brand swipe actions match the selected filter criteria.</p>
              </div>
            ) : (
              filteredSwipes.map((swipe) => {
                const isMatch = swipe.action === 'match';
                return (
                  <div
                    key={swipe.id}
                    className={`bg-[#081222] border rounded-2xl p-4 sm:p-5 transition hover:border-slate-600 ${
                      isMatch 
                        ? 'border-emerald-500/30 bg-gradient-to-r from-[#081222] via-[#09182a] to-[#081222]' 
                        : 'border-blue-900/40 opacity-80'
                    }`}
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      {/* Left: Brand info & Creator match */}
                      <div className="flex items-start gap-3 sm:gap-4">
                        {/* Creator Mini Thumbnail */}
                        <div className="relative w-12 h-14 sm:w-14 sm:h-16 rounded-xl overflow-hidden bg-slate-900 border border-white/10 shrink-0">
                          <img
                            src={swipe.creatorAvatar || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80'}
                            alt={`Profile photo of ${swipe.creatorName}`}
                            className="w-full h-full object-cover"
                          />
                          <div className={`absolute bottom-0 inset-x-0 py-0.5 text-center text-[9px] font-mono font-bold uppercase ${isMatch ? 'bg-emerald-500 text-black' : 'bg-slate-700 text-white'}`}>
                            {isMatch ? 'MATCH' : 'PASS'}
                          </div>
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm sm:text-base font-bold text-white font-sans">
                              {swipe.brandName}
                            </span>
                            {isMatch ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                                <Heart className="w-3 h-3 fill-current" />
                                LIKED &amp; MATCHED
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 text-slate-400 border border-white/5">
                                <X className="w-3 h-3" />
                                PASSED
                              </span>
                            )}
                            <span className="text-[10px] font-mono text-slate-500">
                              {swipe.timeAgo || swipe.dateStr}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-xs text-slate-300 font-sans flex-wrap">
                            <span className="font-mono text-[#C9A46A] font-bold">{swipe.creatorNumber}</span>
                            <span className="text-slate-500">•</span>
                            <span className="font-medium text-slate-200">{swipe.creatorName} ({swipe.creatorHandle})</span>
                            <span className="text-slate-500">•</span>
                            <span className="px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-300 text-[10px] font-mono">
                              {swipe.creatorNiche}
                            </span>
                          </div>

                          {/* Notes / Deliverables / Booking Details */}
                          {swipe.deliverables && (
                            <p className="text-xs text-slate-300 bg-[#0D1830] border border-blue-900/40 p-2.5 rounded-xl font-mono mt-2">
                              <span className="text-[#C9A46A] font-bold">Campaign Request: </span>
                              {swipe.deliverables}
                            </p>
                          )}
                          {swipe.notes && !swipe.deliverables && (
                            <p className="text-xs text-slate-400 italic">
                              "{swipe.notes}"
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Right: Budget & Action CTAs */}
                      <div className="flex items-center justify-between lg:justify-end gap-3 pt-3 lg:pt-0 border-t lg:border-t-0 border-white/5 shrink-0">
                        {isMatch && swipe.proposedBudget && (
                          <div className="text-left lg:text-right pr-2">
                            <span className="text-[10px] font-mono text-slate-400 uppercase block">Brand Budget</span>
                            <span className="text-base sm:text-lg font-black text-emerald-400 font-mono">
                              ${swipe.proposedBudget.toLocaleString()}
                            </span>
                          </div>
                        )}

                        <div className="flex items-center gap-2">
                          {isMatch && (
                            <>
                              {swipe.dealCreated ? (
                                <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>In Deal Pipeline</span>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleConvertToDeal(swipe)}
                                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-[#070D18] text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer shadow-md shadow-emerald-500/20"
                                >
                                  <ArrowUpRight className="w-3.5 h-3.5" />
                                  <span>Convert to Deal</span>
                                </button>
                              )}
                            </>
                          )}

                          <button
                            type="button"
                            onClick={() => handleDismissSwipe(swipe.id)}
                            title="Dismiss swipe record from feed"
                            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#0D1830] hover:bg-rose-950/60 border border-blue-900/40 hover:border-rose-500/40 text-slate-400 hover:text-rose-300 text-xs font-mono transition cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Dismiss</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 2: CREATOR CARD DECK & MEDIA MANAGER (DIRECTOR UPLOADS PHOTOS) */}
      {activeTab === 'deck_manager' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-[#081222] p-5 rounded-2xl border border-blue-900/40">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#C9A46A]" />
                Brand-Facing Match or Pass Deck Gallery
              </h3>
              <p className="text-xs text-slate-400">
                Upload vertical 9:16 card images, customize taglines, add or delete creators, and toggle talent visibility.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsAddCreatorOpen(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer shadow-lg shadow-emerald-500/20"
              >
                <Plus className="w-4 h-4" />
                <span>Add Creator</span>
              </button>

              <div className="text-xs font-mono text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/20 px-3 py-1.5 rounded-xl hidden md:block">
                Anti-Poaching Protection: Cards show "Creator #ID"
              </div>
            </div>
          </div>

          {/* Creators Grid with Photo Upload & Delete triggers */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {creators.map((creator, index) => {
              const isActiveInDeck = creator.matchOrPassActive !== false;
              const photo = creator.matchOrPassPrimaryPhoto || creator.avatar || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80';
              const cardTagline = creator.matchOrPassTagline || `${creator.niche} Specialist • ${creator.followers} Followers`;
              const displayNiche = creator.matchOrPassFeaturedNiche || creator.niche || 'Pets';

              return (
                <div 
                  key={creator.id}
                  className={`bg-[#081222] border rounded-3xl overflow-hidden transition-all flex flex-col ${
                    isActiveInDeck ? 'border-blue-900/50 hover:border-[#C9A46A]/60' : 'border-slate-800 opacity-60'
                  }`}
                >
                  {/* Card Visual Header with 9:16 aspect preview */}
                  <div className="relative aspect-[4/5] w-full bg-slate-950 overflow-hidden group">
                    <img
                      src={photo}
                      alt={`Full size card photo for ${creator.name}`}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#081222] via-black/30 to-transparent" />

                    {/* Top Badges */}
                    <div className="absolute top-3 inset-x-3 flex items-center justify-between">
                      <span className="px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-[#C9A46A] font-mono text-[10px] font-bold border border-[#C9A46A]/40">
                        Creator #{100 + index + 1}
                      </span>
                      <span className="px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/30">
                        {displayNiche}
                      </span>
                    </div>

                    {/* Bottom Info on Card */}
                    <div className="absolute bottom-3 inset-x-3 space-y-1">
                      <div className="flex items-center justify-between">
                        <h4 className="text-base font-bold text-white truncate font-sans">
                          {creator.name} <span className="text-xs text-slate-400 font-normal font-mono">({creator.handle})</span>
                        </h4>
                      </div>
                      <p className="text-xs text-slate-200 line-clamp-1 font-mono">
                        {cardTagline}
                      </p>
                    </div>
                  </div>

                  {/* Body Details & Director Upload Trigger */}
                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-slate-400">Deck Status:</span>
                        <button
                          onClick={() => handleToggleDeckActive(creator.id, isActiveInDeck)}
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase transition cursor-pointer flex items-center gap-1 ${
                            isActiveInDeck 
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                              : 'bg-slate-800 text-slate-400 border border-white/5'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isActiveInDeck ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
                          <span>{isActiveInDeck ? 'Active in Deck' : 'Hidden from Brands'}</span>
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                        <span>Followers: <strong className="text-white">{creator.followers}</strong></span>
                        <span>Engagement: <strong className="text-emerald-400">{creator.eng}</strong></span>
                      </div>
                    </div>

                    {/* Action buttons including Delete */}
                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/5">
                      <button
                        type="button"
                        onClick={() => handleOpenPhotoEditor(creator)}
                        className="flex items-center justify-center gap-1 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-[11px] font-mono font-bold transition cursor-pointer"
                        title="Upload Photo"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPreviewCardCreator(creator)}
                        className="flex items-center justify-center gap-1 py-2 rounded-xl bg-[#0D1830] hover:bg-[#132347] text-slate-300 hover:text-white border border-blue-900/40 text-[11px] font-mono transition cursor-pointer"
                        title="Preview Card"
                      >
                        <Eye className="w-3.5 h-3.5 text-[#C9A46A]" />
                        <span>Preview</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteCreator(creator.id, creator.name)}
                        className="flex items-center justify-center gap-1 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 text-[11px] font-mono font-bold transition cursor-pointer"
                        title="Delete Creator Card"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB: CREATOR NUMBER & IDENTITY MAPPING DIRECTORY (DIRECTOR ONLY) */}
      {activeTab === 'talent_mapping' && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-[#081222] p-5 rounded-2xl border border-blue-900/40">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-base font-bold text-white">
                  Director Panel &bull; Creator Number Identity Directory
                </h3>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Lookup which anonymous <strong>Creator #ID</strong> (e.g. Creator #101) belongs to each talent member, with real identity, platform handle, audience stats, and deck controls.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const url = `${window.location.origin}/#sneak-peek`;
                  navigator.clipboard.writeText(url);
                  triggerNotification('Link Copied', 'Anonymous brand sneak peek link copied to clipboard.', 'success');
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-300 hover:text-white cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 text-[#C9A46A]" />
                <span>Copy Sneak Peek Link</span>
              </button>
              <button
                type="button"
                onClick={() => setIsAddCreatorOpen(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer shadow-lg shadow-emerald-500/20"
              >
                <Plus className="w-4 h-4" />
                <span>Add Creator</span>
              </button>
            </div>
          </div>

          {/* Search bar */}
          <div className="bg-[#081222] p-3 rounded-xl border border-blue-900/40">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search creator number, real name, handle, or niche..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-[#0D1830] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
            </div>
          </div>

          {/* Table Directory */}
          <div className="overflow-x-auto rounded-2xl border border-blue-900/40 bg-[#081222]">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0D1830] text-slate-300 border-b border-blue-900/40">
                <tr>
                  <th className="p-3.5 text-[#C9A46A]">Creator #</th>
                  <th className="p-3.5">Real Name &amp; Photo</th>
                  <th className="p-3.5">Handle &amp; Platform</th>
                  <th className="p-3.5">Vertical Niche</th>
                  <th className="p-3.5">Audience &amp; Velocity</th>
                  <th className="p-3.5">Deck Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {creators
                  .filter(c => {
                    if (!searchQuery.trim()) return true;
                    const q = searchQuery.toLowerCase();
                    const code = `Creator #${100 + creators.indexOf(c) + 1}`.toLowerCase();
                    return (
                      code.includes(q) ||
                      (c.name || '').toLowerCase().includes(q) ||
                      (c.handle || '').toLowerCase().includes(q) ||
                      (c.niche || '').toLowerCase().includes(q)
                    );
                  })
                  .map((creator) => {
                    const originalIdx = creators.findIndex(c => c.id === creator.id);
                    const creatorNumber = `Creator #${100 + originalIdx + 1}`;
                    const isActiveInDeck = creator.matchOrPassActive !== false;
                    const photo = creator.matchOrPassPrimaryPhoto || creator.avatar;

                    return (
                      <tr key={creator.id} className="hover:bg-white/5 transition">
                        <td className="p-3.5 whitespace-nowrap">
                          <span className="px-3 py-1 rounded-lg bg-[#C9A46A]/10 border border-[#C9A46A]/40 text-[#C9A46A] font-bold">
                            {creatorNumber}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <div className="flex items-center gap-3">
                            <img
                              src={photo}
                              alt={`Thumbnail of ${creator.name}`}
                              className="w-9 h-9 rounded-full object-cover border border-white/10"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <span className="font-bold text-white block text-sm">{creator.name}</span>
                              <span className="text-[10px] text-slate-400 font-sans">{creator.bio?.slice(0, 40)}...</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5">
                          <span className="text-slate-200 font-bold block">{creator.handle}</span>
                          <span className="text-[10px] text-slate-400">{creator.platform || 'TikTok'}</span>
                        </td>
                        <td className="p-3.5">
                          <span className="px-2.5 py-1 rounded-md bg-white/5 text-emerald-300 border border-emerald-500/20">
                            {creator.matchOrPassFeaturedNiche || creator.niche || 'Pets'}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <span className="text-white font-bold block">{creator.followers}</span>
                          <span className="text-[10px] text-emerald-400">{creator.eng} eng</span>
                        </td>
                        <td className="p-3.5">
                          <button
                            type="button"
                            onClick={() => handleToggleDeckActive(creator.id, isActiveInDeck)}
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase transition cursor-pointer flex items-center gap-1.5 ${
                              isActiveInDeck 
                                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                                : 'bg-slate-800 text-slate-400 border border-white/5'
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${isActiveInDeck ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
                            <span>{isActiveInDeck ? 'Active' : 'Hidden'}</span>
                          </button>
                        </td>
                        <td className="p-3.5 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => handleOpenPhotoEditor(creator)}
                              className="p-1.5 rounded-lg bg-blue-600/20 text-blue-300 hover:bg-blue-600/40 transition cursor-pointer"
                              title="Edit Deck Card"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setPreviewCardCreator(creator)}
                              className="p-1.5 rounded-lg bg-white/5 text-slate-300 hover:text-white transition cursor-pointer"
                              title="Preview Brand Card"
                            >
                              <Eye className="w-3.5 h-3.5 text-[#C9A46A]" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteCreator(creator.id, creator.name)}
                              className="p-1.5 rounded-lg bg-rose-500/15 text-rose-400 hover:bg-rose-500/30 transition cursor-pointer"
                              title="Delete Creator"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: NICHE SETTINGS & SECURITY LEDGER */}
      {activeTab === 'niche_settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Niche Deck Strategy */}
          <div className="bg-[#081222] border border-blue-900/40 rounded-3xl p-6 space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider block">
                Brand Discovery Focus
              </span>
              <h3 className="text-lg font-bold text-white">Active Discovery Niches</h3>
              <p className="text-xs text-slate-400">
                The agency currently isolates the brand matchmaking pool strictly to three core high-conversion verticals.
              </p>
            </div>

            <div className="space-y-2">
              {['Pets', 'Beauty', 'Lifestyle'].map((niche) => {
                const count = creators.filter(c => (c.niche || '').toLowerCase().includes(niche.toLowerCase().slice(0, 3))).length;
                return (
                  <div key={niche} className="flex items-center justify-between p-3.5 rounded-xl bg-[#0D1830] border border-blue-900/40">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                      <span className="text-sm font-bold text-white">{niche} Vertical</span>
                    </div>
                    <span className="text-xs font-mono text-[#C9A46A]">{count} Creators in Deck</span>
                  </div>
                );
              })}
            </div>

            <div className="p-4 rounded-xl bg-blue-950/30 border border-blue-800/40 text-xs text-slate-300 space-y-2">
              <div className="flex items-center gap-2 font-bold text-blue-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Non-Circumvention Protection Active</span>
              </div>
              <p className="text-slate-400">
                When brand clients view this deck, talent real names and direct contact channels are strictly masked. All inquiries route exclusively through your director dashboard.
              </p>
            </div>
          </div>

          {/* Quick Legal Terms Status */}
          <div className="bg-[#081222] border border-blue-900/40 rounded-3xl p-6 space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                Mandatory Brand Gate
              </span>
              <h3 className="text-lg font-bold text-white">Platform Rules &amp; Non-Circumvention</h3>
              <p className="text-xs text-slate-400">
                Every brand is required to review and electronically sign the 4-clause agreement before entering the Match or Pass dashboard.
              </p>
            </div>

            <div className="space-y-2 font-mono text-xs">
              <div className="p-3 bg-[#0D1830] rounded-xl border border-white/5 space-y-1">
                <div className="flex items-center justify-between text-emerald-400 font-bold">
                  <span>1. Non-Circumvention Rule</span>
                  <span>$5,000 / 30% Penalty</span>
                </div>
                <p className="text-[11px] text-slate-400">24-month anti-poaching lock on all introduced talent.</p>
              </div>

              <div className="p-3 bg-[#0D1830] rounded-xl border border-white/5 space-y-1">
                <div className="flex items-center justify-between text-blue-400 font-bold">
                  <span>2. Proprietary App Architecture</span>
                  <span>IP Protected</span>
                </div>
                <p className="text-[11px] text-slate-400">No reverse engineering or UI scraping allowed.</p>
              </div>

              <div className="p-3 bg-[#0D1830] rounded-xl border border-white/5 space-y-1">
                <div className="flex items-center justify-between text-purple-400 font-bold">
                  <span>3. Security &amp; Organization Login</span>
                  <span>Access Control</span>
                </div>
                <p className="text-[11px] text-slate-400">Logins limited strictly to authorized brand team members.</p>
              </div>

              <div className="p-3 bg-[#0D1830] rounded-xl border border-white/5 space-y-1">
                <div className="flex items-center justify-between text-[#C9A46A] font-bold">
                  <span>4. Direct Messaging &amp; Audit</span>
                  <span>Bloom Studio Master Access</span>
                </div>
                <p className="text-[11px] text-slate-400">Comms preserved in-app with compliance monitoring.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: DIRECTOR PHOTO UPLOAD & CARD EDITOR */}
      {editingCreator && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#081222] border border-blue-900/60 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider block">
                  Deck Visuals Studio
                </span>
                <h3 className="text-xl font-bold text-white">
                  Upload Card Picture for {editingCreator.name}
                </h3>
              </div>
              <button
                onClick={() => setEditingCreator(null)}
                className="p-2 rounded-full bg-[#0D1830] text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Photo Preview & Dropzone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Vertical Card Preview */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-slate-400 block">
                  Live Vertical Card Preview (9:16)
                </label>
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-black border-2 border-[#C9A46A]/50 shadow-lg">
                  {editorPhotoUrl ? (
                    <img
                      src={editorPhotoUrl}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-slate-500 space-y-2">
                      <ImageIcon className="w-10 h-10" />
                      <span className="text-xs font-mono">No Image Uploaded</span>
                    </div>
                  )}

                  {/* Card overlay simulation */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />
                  <div className="absolute top-2.5 left-2.5">
                    <span className="px-2 py-0.5 rounded-full bg-black/60 text-[#C9A46A] font-mono text-[9px] font-bold">
                      Creator #10X
                    </span>
                  </div>
                  <div className="absolute bottom-2.5 inset-x-2.5 space-y-0.5">
                    <h5 className="text-xs font-bold text-white">{editingCreator.name}</h5>
                    <p className="text-[10px] text-slate-300 font-mono truncate">{editorTagline}</p>
                  </div>
                </div>
              </div>

              {/* Upload Controls */}
              <div className="space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <label className="text-xs font-mono text-slate-400 block">
                    Upload from Computer (Local Image)
                  </label>
                  
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept="image/*"
                    className="hidden"
                  />

                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-blue-800 hover:border-[#C9A46A] rounded-2xl p-6 text-center cursor-pointer transition bg-[#0D1830] hover:bg-[#132347] space-y-2 group"
                  >
                    <Upload className="w-8 h-8 text-blue-400 group-hover:text-[#C9A46A] mx-auto transition" />
                    <span className="text-xs font-bold text-white block">Click to Select Local File</span>
                    <span className="text-[10px] text-slate-400 block">Supports JPG, PNG, WEBP high-res</span>
                  </div>

                  <div className="space-y-1.5 pt-2">
                    <label className="text-xs font-mono text-slate-400 block">
                      Or Direct Image URL
                    </label>
                    <input
                      type="text"
                      value={editorPhotoUrl}
                      onChange={e => setEditorPhotoUrl(e.target.value)}
                      placeholder="https://..."
                      className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  {/* Preset High-Aesthetic Photo Options */}
                  <div className="space-y-1.5 pt-1">
                    <label className="text-[10px] font-mono text-slate-500 block">
                      Quick Curated Agency Presets:
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setEditorPhotoUrl('https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80')}
                        className="text-[10px] font-mono px-2 py-1 rounded-lg bg-[#0D1830] hover:bg-[#132347] text-slate-300 border border-white/5 cursor-pointer"
                      >
                        Pet Hero 🐶
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditorPhotoUrl('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80')}
                        className="text-[10px] font-mono px-2 py-1 rounded-lg bg-[#0D1830] hover:bg-[#132347] text-slate-300 border border-white/5 cursor-pointer"
                      >
                        Beauty Glow ✨
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditorPhotoUrl('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&auto=format&fit=crop&q=80')}
                        className="text-[10px] font-mono px-2 py-1 rounded-lg bg-[#0D1830] hover:bg-[#132347] text-slate-300 border border-white/5 cursor-pointer"
                      >
                        Lifestyle 🌿
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tagline and Niche configuration */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-white/10">
              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1">
                  Card Subtitle / Tagline
                </label>
                <input
                  type="text"
                  value={editorTagline}
                  onChange={e => setEditorTagline(e.target.value)}
                  placeholder="e.g. Viral Pet Creator • 1.2M TikTok"
                  className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1">
                  Matchmaking Niche Vertical
                </label>
                <select
                  value={editorFeaturedNiche}
                  onChange={e => setEditorFeaturedNiche(e.target.value)}
                  className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A] cursor-pointer"
                >
                  <option value="Pets">Pets Vertical</option>
                  <option value="Beauty">Beauty Vertical</option>
                  <option value="Lifestyle">Lifestyle Vertical</option>
                </select>
              </div>
            </div>

            {/* Highlights */}
            <div>
              <label className="text-xs font-mono text-slate-400 block mb-1">
                Deck Highlight Tags (Comma separated)
              </label>
              <input
                type="text"
                value={editorHighlights}
                onChange={e => setEditorHighlights(e.target.value)}
                placeholder="High Engagement, Top UGC ROI, Fast Turnaround"
                className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            {/* Save Actions */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setEditingCreator(null)}
                className="px-4 py-2.5 rounded-xl bg-[#0D1830] hover:bg-[#132347] text-slate-400 hover:text-white text-xs font-mono transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveCreatorCard}
                className="px-6 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#b89359] text-[#070D18] font-mono font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-lg shadow-[#C9A46A]/20"
              >
                Save &amp; Push to Brand Deck
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* MODAL 2: LIVE SIMULATOR / PREVIEW AS BRAND */}
      {previewCardCreator && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#081222] border border-blue-900/60 rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl relative"
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                Brand View Simulator
              </span>
              <button
                onClick={() => setPreviewCardCreator(null)}
                className="p-1 rounded-full bg-[#0D1830] text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Phone Card Frame */}
            <div className="relative aspect-[3/4] rounded-3xl overflow-hidden bg-black border-2 border-white/10 shadow-2xl">
              <img
                src={previewCardCreator.matchOrPassPrimaryPhoto || previewCardCreator.avatar || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80'}
                alt={previewCardCreator.name}
                className="w-full h-full object-cover"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-[#081222] via-transparent to-black/40" />

              {/* Anti-Poaching Creator Number Badge */}
              <div className="absolute top-3 left-3">
                <span className="px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-[#C9A46A] font-mono text-[10px] font-bold border border-[#C9A46A]/40">
                  Creator #{100 + creators.findIndex(c => c.id === previewCardCreator.id) + 1}
                </span>
              </div>

              {/* Brand card info */}
              <div className="absolute bottom-3 inset-x-3 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-base font-bold text-white">
                    {previewCardCreator.name}
                  </span>
                  <span className="text-xs font-mono text-emerald-400 font-bold">
                    {previewCardCreator.eng}
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-mono">
                  {previewCardCreator.matchOrPassTagline || `${previewCardCreator.niche} • ${previewCardCreator.followers}`}
                </p>
                <div className="text-[10px] font-mono text-slate-400 bg-black/50 p-1.5 rounded-lg border border-white/5">
                  🛡️ Contact details shared only through agency once matched.
                </div>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 font-mono text-center">
              Brands swipe left to pass, right to work with talent.
            </p>
          </motion.div>
        </div>
      )}

      {/* MODAL 3: ADD CREATOR TO DECK */}
      {isAddCreatorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0b1320] border border-emerald-500/40 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                Add Custom Creator to Match Deck
              </h3>
              <button
                type="button"
                onClick={() => setIsAddCreatorOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Dropdown to Select Existing Creator from Agency Roster */}
            <div className="bg-[#0D1830] border border-emerald-500/30 rounded-xl p-3 space-y-1.5 font-mono text-xs">
              <label className="block text-[10px] font-bold uppercase text-emerald-400">
                Select Existing Creator from Roster:
              </label>
              <select
                onChange={e => e.target.value && handleSelectExistingCreatorForDeck(e.target.value)}
                defaultValue=""
                className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                <option value="">-- Choose from {creators.length} Creators in Agency Roster --</option>
                {creators.map(c => (
                  <option key={c.id || c.handle} value={c.handle}>
                    {c.name} ({c.handle}) • {c.niche} ({c.followers})
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-slate-400">Selecting an existing creator automatically populates their info below.</p>
            </div>

            <form onSubmit={handleAddNewCreatorSubmit} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Creator Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Maya Lin"
                  value={newCreatorForm.name}
                  onChange={e => setNewCreatorForm(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Social Handle</label>
                  <input
                    type="text"
                    required
                    placeholder="@mayalin"
                    value={newCreatorForm.handle}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, handle: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Niche Category</label>
                  <select
                    value={newCreatorForm.niche}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, niche: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                  >
                    <option value="Beauty">Beauty</option>
                    <option value="Lifestyle">Lifestyle</option>
                    <option value="Pets">Pets</option>
                    <option value="Tech">Tech</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Fitness">Fitness</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Followers Reach</label>
                  <input
                    type="text"
                    placeholder="e.g. 450K"
                    value={newCreatorForm.followers}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, followers: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Engagement Rate</label>
                  <input
                    type="text"
                    placeholder="e.g. 6.8%"
                    value={newCreatorForm.engagementRate}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, engagementRate: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Card Photo URL</label>
                <input
                  type="text"
                  value={newCreatorForm.avatar}
                  onChange={e => setNewCreatorForm(prev => ({ ...prev, avatar: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Short Bio</label>
                <textarea
                  rows={2}
                  value={newCreatorForm.bio}
                  onChange={e => setNewCreatorForm(prev => ({ ...prev, bio: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsAddCreatorOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg"
                >
                  Add Creator To Deck
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
