import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { Copy, Truck, Gift, Calendar, CheckCircle2 } from 'lucide-react';

interface CreatorProductSamplesInventoryProps {
  currentCreatorHandle: string;
  triggerNotification?: (title: string, message: string, type?: string) => void;
}

export default function CreatorProductSamplesInventory({
  currentCreatorHandle = '@elenarostova',
  triggerNotification
}: CreatorProductSamplesInventoryProps) {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const effectiveHandle = currentCreatorHandle || '@elenarostova';

  useEffect(() => {
    const handleValue = effectiveHandle.trim();
    const handleWithoutAt = handleValue.startsWith('@') ? handleValue.substring(1) : handleValue;
    const handleWithAt = handleValue.startsWith('@') ? handleValue : `@${handleValue}`;

    const defaultGifts = [
      {
        id: 'gift_default_1',
        productName: 'Botanical Firming Serum Gold Set',
        niche: 'Beauty & Skincare',
        shippingStage: 'In Transit',
        status: 'Transit',
        carrier: 'FedEx Luxury Air',
        trackingNumber: 'FX-394829104-US',
        giftingType: 'PR GIFT PACKAGE',
        retailValue: '$250',
        estDelivery: 'August 28, 2026',
        creatorHandle: effectiveHandle
      },
      {
        id: 'gift_default_2',
        productName: 'Eco-Vegan Hemp Cleanser Duet',
        niche: 'Skincare',
        shippingStage: 'Delivered',
        status: 'Delivered',
        carrier: 'UPS Ground',
        trackingNumber: '1Z999AA10123456784',
        giftingType: 'CAMPAIGN MERCH GIFTING',
        retailValue: '$110',
        estDelivery: 'August 25, 2026',
        creatorHandle: effectiveHandle
      },
      {
        id: 'gift_default_3',
        productName: 'Silk Pillowcase & Eye Mask Set',
        niche: 'Lifestyle',
        shippingStage: 'Preparing Shipment',
        status: 'Preparing',
        carrier: 'DHL Express',
        trackingNumber: 'DHL-8849201-US',
        giftingType: 'VIP PR PACKAGE',
        retailValue: '$180',
        estDelivery: 'September 02, 2026',
        creatorHandle: effectiveHandle
      }
    ];

    // Establish real-time Firestore listener mapping directly to global shipping tracking data
    const colRef = collection(db, 'studio-fulfillment');
    const q = query(
      colRef, 
      where('creatorHandle', 'in', [handleValue, handleWithoutAt, handleWithAt])
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() });
      });

      // Seed fallback mock items if no items exist in Firestore for this creator
      if (list.length === 0) {
        const defaults = [
          {
            id: 'gift_default_1',
            productName: 'Botanical Firming Serum Gold Set',
            niche: 'Beauty',
            shippingStage: 'In Transit',
            status: 'Transit',
            carrier: 'FedEx',
            trackingNumber: 'FX-394829104-US',
            giftingType: 'PR GIFT PACKAGE',
            retailValue: '$250',
            estDelivery: 'August 28, 2026',
            creatorHandle: currentCreatorHandle
          },
          {
            id: 'gift_default_2',
            productName: 'Eco-Vegan Hemp Cleanser Duet',
            niche: 'Skincare',
            shippingStage: 'Shipped',
            status: 'Shipped',
            carrier: 'UPS',
            trackingNumber: '1Z999AA10123456784',
            giftingType: 'CAMPAIGN MERCH GIFTING',
            retailValue: '$110',
            estDelivery: 'August 25, 2026',
            creatorHandle: currentCreatorHandle
          }
        ];
        setItems(defaults);
      } else {
        setItems(list);
      }
      setLoading(false);
    }, (error) => {
      console.warn("Firestore Gifting Inventory Stream Error: ", error);
      // Fallback in case of lack of credentials or offline state
      const defaults = [
        {
          id: 'gift_default_1',
          productName: 'Botanical Firming Serum Gold Set',
          niche: 'Beauty',
          shippingStage: 'In Transit',
          status: 'Transit',
          carrier: 'FedEx',
          trackingNumber: 'FX-394829104-US',
          giftingType: 'PR GIFT PACKAGE',
          retailValue: '$250',
          estDelivery: 'August 28, 2026',
          creatorHandle: currentCreatorHandle
        },
        {
          id: 'gift_default_2',
          productName: 'Eco-Vegan Hemp Cleanser Duet',
          niche: 'Skincare',
          shippingStage: 'Shipped',
          status: 'Shipped',
          carrier: 'UPS',
          trackingNumber: '1Z999AA10123456784',
          giftingType: 'CAMPAIGN MERCH GIFTING',
          retailValue: '$110',
          estDelivery: 'August 25, 2026',
          creatorHandle: currentCreatorHandle
        }
      ];
      setItems(defaults);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentCreatorHandle]);

  const handleCopyTracking = (code: string) => {
    if (!code) return;
    navigator.clipboard.writeText(code);
    if (triggerNotification) {
      triggerNotification('✓ Copied Tracking Number', 'Tracking number saved to your clipboard.', 'success');
    }
  };

  const getStagePercent = (stage: string) => {
    const s = (stage || '').toLowerCase();
    if (s.includes('received') || s.includes('arrived') || s === 'received') return 100;
    if (s.includes('transit')) return 75;
    if (s.includes('shipped')) return 50;
    return 25; // Ordered
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-10 bg-[#0B1B3D] border border-[#D4AF37]/30 rounded-2xl">
        <div className="animate-pulse text-xs text-[#D4AF37] font-mono">Syncing My Gifting Page...</div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {items.map((item) => {
        const percent = getStagePercent(item.shippingStage || item.status);
        const isArrived = percent >= 100;

        return (
          <div 
            key={item.id} 
            id={`gifting-card-${item.id}`}
            className="bg-agency-navyLight bg-[#0B1B3D] border border-agency-gold/30 border-[#D4AF37]/30 rounded-2xl p-6 space-y-5 hover:border-[#D4AF37]/60 transition-all shadow-xl relative overflow-hidden group text-agency-textLight text-slate-100"
          >
            {/* PR Package Header */}
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3 py-1 rounded-full flex items-center gap-1.5">
                <Gift className="w-3 h-3 text-[#D4AF37]" />
                {item.giftingType || 'PR GIFT PACKAGE'}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {item.niche || 'Beauty & Lifestyle'}
              </span>
            </div>

            {/* Title & Retail Value Label */}
            <div className="space-y-1.5">
              <h3 className="font-serif font-bold text-xl text-white tracking-wide pr-12 line-clamp-1">
                {item.productName}
              </h3>
              <div className="flex items-center gap-1.5 pt-1">
                <span className="text-slate-400 font-mono text-[11px] uppercase">Retail Value:</span>
                <strong className="text-[#D4AF37] text-lg font-mono font-extrabold tracking-wide">
                  {item.retailValue || item.value || '$250'}
                </strong>
              </div>
            </div>

            {/* Delivery Timeline Progress Bar */}
            <div className="space-y-2.5 border-t border-b border-white/5 py-4 my-2">
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
                <span>Shipping Milestone:</span>
                <span className={`font-bold uppercase ${isArrived ? 'text-emerald-400' : 'text-[#D4AF37]'}`}>
                  {item.shippingStage || item.status || 'Ordered'}
                </span>
              </div>
              
              {/* Horizontal Stepper Progress Indicator */}
              <div className="relative w-full h-1.5 bg-black/30 rounded-full border border-white/5 overflow-hidden">
                <div 
                  className="h-full rounded-full bg-gradient-to-r from-amber-500 to-[#D4AF37] transition-all duration-700"
                  style={{ width: `${percent}%` }}
                />
              </div>
              <div className="flex justify-between text-[9px] text-slate-400 font-mono tracking-tight px-0.5">
                <span className={percent >= 25 ? 'text-[#D4AF37] font-bold' : ''}>Ordered</span>
                <span className={percent >= 50 ? 'text-[#D4AF37] font-bold' : ''}>➔ Shipped</span>
                <span className={percent >= 75 ? 'text-[#D4AF37] font-bold' : ''}>➔ Transit</span>
                <span className={percent >= 100 ? 'text-[#D4AF37] font-bold' : ''}>➔ Arrived</span>
              </div>
            </div>

            {/* Shipping Meta Details */}
            <div className="grid grid-cols-2 gap-4 text-xs font-mono text-slate-300">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase block tracking-wider">Carrier Channel</span>
                <span className="text-slate-200 font-semibold flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#D4AF37]" />
                  {item.carrier || 'FedEx'}
                </span>
              </div>
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase block tracking-wider">Est. Delivery Window</span>
                <span className="text-slate-200 font-semibold flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
                  {item.estDelivery || 'August 28, 2026'}
                </span>
              </div>
            </div>

            {/* Tracking ID Node with clipboard action */}
            <div className="bg-black/30 border border-[#D4AF37]/15 rounded-xl p-3.5 flex items-center justify-between text-xs font-mono text-slate-300">
              <span className="truncate pr-4 text-[11px]">
                Tracking: <strong className="text-white">{item.trackingNumber || 'Pending'}</strong>
              </span>
              {item.trackingNumber && (
                <button 
                  type="button"
                  onClick={() => handleCopyTracking(item.trackingNumber)}
                  className="text-[#D4AF37] hover:text-[#f3d06b] hover:underline cursor-pointer flex items-center gap-1 shrink-0 font-bold uppercase text-[10px] tracking-wider focus:outline-none"
                >
                  [Copy]
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
