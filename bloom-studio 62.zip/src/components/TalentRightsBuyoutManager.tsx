import React, { useState, useMemo } from 'react';
import { 
  DollarSign, 
  ShieldCheck, 
  CheckCircle2, 
  Lock, 
  FileCheck, 
  ArrowRight,
  Sparkles,
  Download,
  EyeOff,
  UserCheck,
  Send,
  FileText
} from 'lucide-react';
import { downloadCopyrightClearancePDF } from '../utils/pdfExportUtils';
import { formatTimestamp } from '../utils/dateUtils';

interface TalentRightsBuyoutManagerProps {
  userRole?: string; // 'director' | 'creator' | 'agent' | etc.
  campaignName?: string;
  creatorHandle?: string;
  creatorLegalName?: string;
  brandName?: string;
  initialGrossCharge?: number;
  initialCreatorPayout?: number;
  availableCreators?: Array<{ id: string; name: string; handle: string; legalName?: string }>;
  onDirectorSave?: (grossCharge: number, creatorPayout: number, selectedCreatorHandle?: string) => void;
  onCreatorAuthorize?: (signatureName: string) => void;
}

const DEFAULT_CREATOR_LIST = [
  { id: '1', name: 'Olivia Sterling', handle: '@olivia.glows', legalName: 'Olivia Sterling' },
  { id: '2', name: 'Marcus Chen', handle: '@marcus.fits', legalName: 'Marcus Chen' },
  { id: '3', name: 'Sophia Miller', handle: '@sophia.creates', legalName: 'Sophia Miller' },
  { id: '4', name: 'Liam Vance', handle: '@liam.tech', legalName: 'Liam Vance' },
  { id: '5', name: 'Zoe Martinez', handle: '@zoe.wellness', legalName: 'Zoe Martinez' }
];

export default function TalentRightsBuyoutManager({
  userRole = 'director',
  campaignName = "Lumina Skin Barrier Serum Launch",
  creatorHandle = "@olivia.glows",
  creatorLegalName = "Olivia Sterling",
  brandName = "Lumina Cosmetics LLC",
  initialGrossCharge = 3500,
  initialCreatorPayout = 1500,
  availableCreators = DEFAULT_CREATOR_LIST,
  onDirectorSave,
  onCreatorAuthorize
}: TalentRightsBuyoutManagerProps) {
  const isDirector = userRole.toLowerCase() === 'director' || userRole.toLowerCase() === 'owner' || userRole.toLowerCase() === 'agency';
  const isCreator = userRole.toLowerCase() === 'creator';
  const isAgentMgr = userRole.toLowerCase() === 'agentmgr' || userRole.toLowerCase() === 'agent manager';

  // Target Creator Selection
  const [selectedCreator, setSelectedCreator] = useState<string>(creatorHandle);
  
  const currentTargetObj = useMemo(() => {
    return availableCreators.find(c => c.handle === selectedCreator) || {
      id: 'custom',
      name: creatorLegalName,
      handle: selectedCreator,
      legalName: creatorLegalName
    };
  }, [selectedCreator, availableCreators, creatorLegalName]);

  // Section 1: Brand Paid logging (Confidential to Director)
  const [grossCharge, setGrossCharge] = useState<number>(initialGrossCharge);
  const [brandContractRef, setBrandContractRef] = useState<string>('BRD-BUYOUT-2026-088');

  // Section 2: Director-to-Creator Negotiation Logging
  const [myInitialOffer, setMyInitialOffer] = useState<number>(1200);
  const [creatorProposedMin, setCreatorProposedMin] = useState<number>(1500);
  const [creatorPayout, setCreatorPayout] = useState<number>(initialCreatorPayout);
  const [negotiationNotes, setNegotiationNotes] = useState<string>('Agreed on $1,500 flat for perpetuity digital paid ad rights.');

  // Save / Dispatch states
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [buyoutLogs, setBuyoutLogs] = useState<any[]>(() => {
    const saved = localStorage.getItem('buyoutLogs');
    return saved ? JSON.parse(saved) : [];
  });

  // Creator View States
  const [creatorAgreed, setCreatorAgreed] = useState(false);
  const [creatorSigName, setCreatorSigName] = useState(currentTargetObj.legalName || creatorLegalName);
  const [isAuthorizedByCreator, setIsAuthorizedByCreator] = useState(false);
  const [authorizationTimestamp, setAuthorizationTimestamp] = useState<string | null>(null);

  // Director Real-time Flat Math: Net Agency Profit = Gross minus Creator Payout
  const netAgencyProfit = Math.max(0, grossCharge - creatorPayout);

  const handleSaveDirectorConfig = () => {
    if (onDirectorSave) {
      onDirectorSave(grossCharge, creatorPayout, selectedCreator);
    }
    
    // Add to logs
    const newLog = {
      id: Date.now(),
      campaignName,
      brandName,
      creator: currentTargetObj.name,
      grossCharge,
      creatorPayout,
      timestamp: formatTimestamp(new Date())
    };
    
    const updatedLogs = [...buyoutLogs, newLog];
    setBuyoutLogs(updatedLogs);
    localStorage.setItem('buyoutLogs', JSON.stringify(updatedLogs));

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleExecuteCreatorConsent = () => {
    if (!creatorAgreed || !creatorSigName.trim()) {
      alert('Please check the authorization box and type your legal name.');
      return;
    }
    setIsAuthorizedByCreator(true);
    setAuthorizationTimestamp(formatTimestamp(new Date()));
    if (onCreatorAuthorize) {
      onCreatorAuthorize(creatorSigName);
    }
  };

  const handleDownloadWhitePaper = async () => {
    await downloadCopyrightClearancePDF({
      campaignName,
      brandName: isCreator ? 'Agency Commercial Partner' : brandName,
      creatorHandle,
      creatorLegalName: creatorSigName || creatorLegalName,
      creatorRightsPayout: creatorPayout,
      creatorSignature: creatorSigName,
      signedAt: new Date().toLocaleDateString('en-US')
    });
  };

  // -------------------------------------------------------------
  // VIEW 0: VIEW-ONLY EXECUTION LOG (Agent Manager / Campaign Workflow View)
  // Only Brand Managers / Directors can create buyouts.
  // Sold dollar amounts are strictly masked; only what was sold, date, and time are visible.
  // -------------------------------------------------------------
  const isWorkflowView = userRole.toLowerCase() === 'workflow' || userRole.toLowerCase() === 'campaign';
  if (isAgentMgr || isWorkflowView) {
    return (
      <div className="w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6 font-sans text-agency-textLight animate-fadeIn">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-white/10 gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
              <EyeOff className="w-4 h-4" />
              <span>View-Only Commercial Rights &amp; Buyout Ledger</span>
            </div>
            <h3 className="text-xl md:text-2xl font-serif font-bold text-white">
              Talent Rights Buyout Registry
            </h3>
            <p className="text-xs text-slate-400">
              Only Brand Managers and Agency Directors can initiate or configure buyout agreements with creators.
            </p>
          </div>

          <span className="text-xs font-mono text-amber-300 bg-amber-950/60 border border-amber-500/40 px-3.5 py-2 rounded-xl flex items-center gap-2">
            <Lock className="w-3.5 h-3.5" /> View Only &bull; Financial Values Masked
          </span>
        </div>

        <div className="p-4 bg-agency-navy/90 rounded-2xl border border-white/10 space-y-2 text-xs text-slate-300">
          <p className="font-semibold text-white font-mono flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-agency-gold" /> Rights Clearance Policy Notice
          </p>
          <p className="text-slate-300 leading-relaxed text-[11px]">
            Agent Managers and Workflow Coordinators can verify active commercial usage rights, licensed assets, date, and timestamp of authorization. Exact gross sales prices and creator payout amounts remain confidential to Brand Management &amp; Director clearance.
          </p>
        </div>

        {/* View-Only Executed Buyouts Table */}
        <div className="overflow-x-auto border border-white/10 rounded-2xl bg-[#091322]">
          <table className="w-full text-left text-xs font-mono text-slate-300">
            <thead className="bg-[#0f1b2e] text-[#C9A46A] uppercase tracking-wider text-[10px] border-b border-white/10">
              <tr>
                <th className="p-3.5">Asset &amp; Campaign Sold</th>
                <th className="p-3.5">Creator</th>
                <th className="p-3.5">Date Sold</th>
                <th className="p-3.5">Time Sold</th>
                <th className="p-3.5">Sold Amount</th>
                <th className="p-3.5">Rights Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              <tr className="hover:bg-white/5 transition">
                <td className="p-3.5 font-bold text-white">
                  Lumina Skin Barrier Serum Launch - 60s Reel &amp; Paid Ad Rights
                </td>
                <td className="p-3.5 text-agency-gold">@olivia.glows (Olivia Sterling)</td>
                <td className="p-3.5 text-slate-300">2026-08-24</td>
                <td className="p-3.5 text-slate-400">14:32:05 EST</td>
                <td className="p-3.5 font-bold text-slate-400">
                  <span className="bg-rose-500/10 text-rose-300 border border-rose-500/20 px-2 py-0.5 rounded text-[10px]">
                    🔒 Masked (Director Clearance)
                  </span>
                </td>
                <td className="p-3.5">
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-lg text-[10px] font-bold">
                    Executed &amp; Active
                  </span>
                </td>
              </tr>
              <tr className="hover:bg-white/5 transition">
                <td className="p-3.5 font-bold text-white">
                  Glow-Up Hydration Campaign - Perpetual Usage License
                </td>
                <td className="p-3.5 text-agency-gold">@marcus.fits (Marcus Chen)</td>
                <td className="p-3.5 text-slate-300">2026-08-22</td>
                <td className="p-3.5 text-slate-400">11:15:30 EST</td>
                <td className="p-3.5 font-bold text-slate-400">
                  <span className="bg-rose-500/10 text-rose-300 border border-rose-500/20 px-2 py-0.5 rounded text-[10px]">
                    🔒 Masked (Director Clearance)
                  </span>
                </td>
                <td className="p-3.5">
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-lg text-[10px] font-bold">
                    Executed &amp; Active
                  </span>
                </td>
              </tr>
              <tr className="hover:bg-white/5 transition">
                <td className="p-3.5 font-bold text-white">
                  Summer Wellness Reel - Whitelisting &amp; Commercial Usage
                </td>
                <td className="p-3.5 text-agency-gold">@zoe.wellness (Zoe Martinez)</td>
                <td className="p-3.5 text-slate-300">2026-08-19</td>
                <td className="p-3.5 text-slate-400">09:45:12 EST</td>
                <td className="p-3.5 font-bold text-slate-400">
                  <span className="bg-rose-500/10 text-rose-300 border border-rose-500/20 px-2 py-0.5 rounded text-[10px]">
                    🔒 Masked (Director Clearance)
                  </span>
                </td>
                <td className="p-3.5">
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-lg text-[10px] font-bold">
                    Executed &amp; Active
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW 1: DIRECTOR / OWNER CONTROL CONSOLE (Strict 3-Section Division)
  // -------------------------------------------------------------
  if (isDirector) {
    return (
      <div className="w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6 font-sans text-agency-textLight animate-fadeIn">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-white/10 gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
              <Lock className="w-4 h-4" />
              <span>Director Private Console • Talent Rights &amp; Buyouts</span>
            </div>
            <h3 className="text-xl md:text-2xl font-serif font-bold text-white">
              Talent Rights Buyout Management
            </h3>
            <p className="text-xs text-slate-400">
              Strictly segregated workflow. Brand pricing is logged in Section 1 and completely hidden from creator.
            </p>
          </div>

          {/* Read-Only Net Margin Badge */}
          <div className="p-4 bg-agency-navy rounded-2xl border border-agency-gold/30 text-right shrink-0">
            <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Retained Agency Margin</div>
            <div className="text-2xl font-mono font-bold text-emerald-400">
              ${netAgencyProfit.toLocaleString()}
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              Brand Paid (${grossCharge.toLocaleString()}) - Creator Buyout (${creatorPayout.toLocaleString()})
            </div>
          </div>
        </div>

        {/* Creator Selection Dropdown */}
        <div className="p-4 bg-agency-navy/80 rounded-2xl border border-agency-gold/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <label className="text-xs font-mono font-bold uppercase tracking-wider text-agency-gold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-agency-gold" />
              Select Target Creator for Rights Agreement
            </label>
            <p className="text-[11px] text-slate-400">
              All buyout parameters will be tailored specifically for this talent.
            </p>
          </div>
          <select
            value={selectedCreator}
            onChange={e => setSelectedCreator(e.target.value)}
            className="bg-agency-navyLight border border-white/10 rounded-xl px-4 py-2 text-xs font-mono text-white font-bold focus:outline-none focus:border-agency-gold cursor-pointer"
          >
            {availableCreators.map(c => (
              <option key={c.id || c.handle} value={c.handle}>
                {c.name} ({c.handle})
              </option>
            ))}
          </select>
        </div>

        {/* Agent Manager Notice */}
        {isAgentMgr && (
          <div className="p-4 bg-agency-navyLight border border-agency-gold/30 rounded-2xl text-xs font-mono text-agency-gold">
            🔒 Agent Manager View: You can view creator deliverables and commercial usage terms. Exact sales pricing (what it was sold for) is confidential to Director clearance.
          </div>
        )}

        {/* ==================================================================== */}
        {/* SECTION 1: WHAT THE BRAND PAID (CONFIDENTIAL - HIDDEN FROM CREATOR & AGENT MGR) */}
        {/* ==================================================================== */}
        {!isAgentMgr && (
          <div className="p-5 bg-[#091322] rounded-2xl border-2 border-indigo-500/30 space-y-4 relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center text-xs font-bold font-mono">1</span>
                <div>
                  <h4 className="text-sm font-bold text-white font-serif flex items-center gap-2">
                    Brand Commercial License &amp; Revenue Log
                    <span className="text-[9px] font-mono uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2 py-0.5 rounded flex items-center gap-1">
                      <EyeOff className="w-3 h-3" /> Confidential to Director
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400">Log total commercial buyout fee charged directly to the brand client.</p>
                </div>
              </div>
              <span className="text-xs font-mono text-indigo-300 font-bold bg-indigo-950/60 px-3 py-1 rounded-xl border border-indigo-500/30">
                Brand: {brandName}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                  What Brand Paid ($ Gross)
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-agency-gold font-bold">$</span>
                  <input
                    type="number"
                    value={grossCharge}
                    onChange={e => {
                      setGrossCharge(Number(e.target.value) || 0);
                      setSavedSuccess(false);
                    }}
                    className="w-full bg-agency-navy border border-white/10 rounded-xl px-3.5 py-2 text-sm font-mono text-white font-bold focus:outline-none focus:border-agency-gold"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                  Invoice / Contract Ref ID
                </label>
                <input
                  type="text"
                  value={brandContractRef}
                  onChange={e => setBrandContractRef(e.target.value)}
                  className="w-full bg-agency-navy border border-white/10 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-agency-gold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                  Retained Agency Margin
                </label>
                <div className="w-full bg-agency-navy border border-emerald-500/20 rounded-xl px-3.5 py-2 text-sm font-mono font-bold text-emerald-400">
                  ${netAgencyProfit.toLocaleString()} ({(grossCharge > 0 ? Math.round((netAgencyProfit / grossCharge) * 100) : 0)}%)
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================================== */}
        {/* SECTION 2: WHAT I OFFERED / NEGOTIATION WORKSPACE */}
        {/* ==================================================================== */}
        <div className="p-5 bg-[#091322] rounded-2xl border-2 border-amber-500/30 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center text-xs font-bold font-mono">2</span>
              <div>
                <h4 className="text-sm font-bold text-white font-serif">
                  Director-to-Creator Negotiation Log
                </h4>
                <p className="text-[11px] text-slate-400">Track your initial offer, talent proposed minimum, and agreed terms.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                What I Offered Talent ($)
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-amber-400 font-bold">$</span>
                <input
                  type="number"
                  value={myInitialOffer}
                  onChange={e => setMyInitialOffer(Number(e.target.value) || 0)}
                  className="w-full bg-agency-navy border border-white/10 rounded-xl px-3.5 py-2 text-sm font-mono text-amber-400 font-bold focus:outline-none focus:border-agency-gold"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                Creator Proposed Min ($)
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400 font-bold">$</span>
                <input
                  type="number"
                  value={creatorProposedMin}
                  onChange={e => setCreatorProposedMin(Number(e.target.value) || 0)}
                  className="w-full bg-agency-navy border border-white/10 rounded-xl px-3.5 py-2 text-sm font-mono text-white font-bold focus:outline-none focus:border-agency-gold"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">
                Final Agreed Buyout Fee ($)
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400 font-bold">$</span>
                <input
                  type="number"
                  value={creatorPayout}
                  onChange={e => {
                    setCreatorPayout(Number(e.target.value) || 0);
                    setSavedSuccess(false);
                  }}
                  className="w-full bg-agency-navy border border-emerald-500/30 rounded-xl px-3.5 py-2 text-sm font-mono text-emerald-400 font-bold focus:outline-none focus:border-agency-gold"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-slate-400 mb-1">Director Internal Negotiation Notes:</label>
            <input
              type="text"
              value={negotiationNotes}
              onChange={e => setNegotiationNotes(e.target.value)}
              className="w-full bg-agency-navy border border-white/10 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-agency-gold"
            />
          </div>
        </div>

        {/* ==================================================================== */}
        {/* SECTION 3: CREATOR BUYOUT OFFER (ZERO BRAND INFORMATION INCLUDED)    */}
        {/* ==================================================================== */}
        <div className="p-5 bg-agency-navy rounded-2xl border-2 border-emerald-500/40 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-xs font-bold font-mono">3</span>
              <div>
                <h4 className="text-sm font-bold text-white font-serif flex items-center gap-2">
                  Creator Buyout Offer (Talent-Facing Document)
                  <span className="text-[9px] font-mono uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> Zero Brand Info Leaked
                  </span>
                </h4>
                <p className="text-[11px] text-slate-400">This clean offer is what the creator sees in their portal to sign and accept.</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Clean Offer Amount</span>
              <span className="text-lg font-mono font-bold text-emerald-400">${creatorPayout.toLocaleString()}</span>
            </div>
          </div>

          <div className="bg-black/30 border border-white/10 rounded-xl p-4 space-y-2 text-xs font-mono text-slate-300">
            <div className="flex justify-between">
              <span>Talent Recipient:</span>
              <strong className="text-white">{currentTargetObj.name} ({selectedCreator})</strong>
            </div>
            <div className="flex justify-between">
              <span>Rights Transferred:</span>
              <span className="text-slate-200">Perpetual Commercial Usage &amp; Digital Advertising Rights</span>
            </div>
            <div className="flex justify-between">
              <span>Direct Compensation:</span>
              <strong className="text-emerald-400">${creatorPayout.toLocaleString()} USD</strong>
            </div>
            <div className="flex justify-between border-t border-white/5 pt-2 text-[10px] text-slate-500">
              <span>Brand Details Status:</span>
              <span className="text-emerald-400">● 100% Masked / Excluded</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between pt-2 gap-3">
            <button
              type="button"
              onClick={handleDownloadWhitePaper}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-agency-navyLight border border-agency-gold/30 hover:border-agency-gold rounded-xl text-xs font-mono font-bold text-agency-gold transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export Clearance Certificate</span>
            </button>

            <button
              type="button"
              onClick={handleSaveDirectorConfig}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider transition shadow-xl cursor-pointer"
            >
              {savedSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Buyout Offer Deployed to Talent!</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Send Buyout Offer to Creator</span>
                </>
              )}
            </button>
          </div>

          {/* Buyout Logs Section */}
          {buyoutLogs.length > 0 && (
            <div className="mt-8 border-t border-white/10 pt-6">
              <h4 className="text-sm font-bold text-white font-serif mb-4">Execution History</h4>
              <div className="space-y-2">
                {buyoutLogs.map(log => (
                  <div key={log.id} className="bg-black/20 p-3 rounded-xl border border-white/5 text-[10px] font-mono text-slate-400 flex items-center justify-between">
                    <span>{log.timestamp} - {log.campaignName} ({log.brandName})</span>
                    <span className="text-emerald-400 font-bold">Sold: ${log.grossCharge} / Payout: ${log.creatorPayout}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW 2: CREATOR CONSENT VIEW (Strictly Section 3 Only - Zero Brand Info)
  // -------------------------------------------------------------
  return (
    <div className="w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6 font-sans text-agency-textLight animate-fadeIn">
      {/* Masked Offer Card */}
      <div className="border-b border-white/10 pb-4">
        <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
          <Sparkles className="w-4 h-4" />
          <span>Talent Commercial Asset Agreement</span>
        </div>
        <h3 className="text-xl md:text-2xl font-serif font-bold text-white mt-1">
          Commercial Usage &amp; Copyright Buyout Offer
        </h3>
        <p className="text-xs text-slate-300 mt-1">
          Exclusive representation offer between Bloom Studio and <strong className="text-white">{creatorLegalName}</strong>.
        </p>
      </div>

      {isAuthorizedByCreator ? (
        <div className="p-6 bg-emerald-950/40 border border-emerald-500/50 rounded-2xl text-center space-y-3 shadow-lg">
          <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-serif font-bold text-white">Commercial Rights Transfer Authorized</h4>
          <p className="text-xs text-slate-300 max-w-md mx-auto">
            Thank you, {creatorSigName}. Your flat fee compensation of <strong className="text-emerald-400">${creatorPayout.toLocaleString()}</strong> has been credited to your Escrow Ledger.
          </p>
          <div className="text-[10px] text-slate-400 font-mono mt-4 space-y-1 bg-black/20 p-3 rounded-lg border border-emerald-500/20 max-w-sm mx-auto text-left">
            <p>Digitally Signed By: <span className="text-white font-bold">{creatorSigName}</span></p>
            <p>Legal Timestamp: <span className="text-emerald-400">{authorizationTimestamp}</span></p>
            <p>Auth Status: <span className="text-emerald-400">Verified &amp; Executed</span></p>
          </div>
          <button
            type="button"
            onClick={handleDownloadWhitePaper}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-agency-gold text-agency-navy font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Signed White Paper Certificate</span>
          </button>
        </div>
      ) : (
        <div className="space-y-5">
          {/* Static Dollar Offer Notice */}
          <div className="p-5 bg-agency-navy rounded-2xl border border-agency-gold/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
                Offered Creator Buyout Compensation
              </span>
              <p className="text-xs text-slate-200">
                Permanent Commercial Usage &amp; Copyright Buyout
              </p>
            </div>
            <div className="text-2xl md:text-3xl font-mono font-bold text-emerald-400">
              ${creatorPayout.toLocaleString()}
            </div>
          </div>

          <div className="p-4 bg-black/20 rounded-xl border border-white/10 space-y-2 text-xs text-slate-300">
            <p className="font-semibold text-white">Terms of Rights Clearance:</p>
            <ul className="list-disc list-inside space-y-1 text-slate-300">
              <li>Full commercial advertising and paid media distribution rights.</li>
              <li>Perpetual digital clearance across social platforms and web.</li>
              <li>Guaranteed flat payout of ${creatorPayout.toLocaleString()} upon digital execution.</li>
            </ul>
          </div>

          {/* Electronic Signature Block */}
          <div className="p-5 bg-agency-navy rounded-2xl border border-white/10 space-y-4">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={creatorAgreed}
                onChange={e => setCreatorAgreed(e.target.checked)}
                className="mt-1 w-4 h-4 text-agency-gold rounded focus:ring-agency-gold cursor-pointer"
              />
              <span className="text-xs text-slate-300 leading-relaxed">
                I, <strong className="text-white">{creatorLegalName}</strong>, agree to transfer the specified commercial usage rights for the agreed flat payout of <strong className="text-emerald-400">${creatorPayout.toLocaleString()}</strong>.
              </span>
            </label>

            <div>
              <label className="block text-[10px] font-mono uppercase text-slate-400 mb-1">
                Type Legal Full Name for Digital Signature:
              </label>
              <input
                type="text"
                value={creatorSigName}
                onChange={e => setCreatorSigName(e.target.value)}
                placeholder="Full Legal Name"
                className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-2.5 text-sm font-mono text-white focus:outline-none focus:border-agency-gold"
              />
            </div>

            <button
              type="button"
              disabled={!creatorAgreed || !creatorSigName.trim()}
              onClick={handleExecuteCreatorConsent}
              className="w-full py-3 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider transition shadow-xl disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center justify-center gap-2"
            >
              <FileCheck className="w-4 h-4" />
              <span>Accept Buyout &amp; Sign Agreement</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
