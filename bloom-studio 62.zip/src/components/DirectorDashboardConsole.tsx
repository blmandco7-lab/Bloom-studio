import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  DollarSign,
  Receipt,
  Landmark,
  ArrowUpRight,
  Cpu,
  Building2,
  Layers,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  TrendingUp,
  Clock,
  ChevronRight,
  Info,
  Check,
  Users,
  EyeOff
} from 'lucide-react';
import { Creator, Deal } from '../types';

interface DirectorDashboardConsoleProps {
  currentUser?: any;
  currentRole?: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onNavigateToScreen: (screenId: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  creators?: Creator[];
  deals?: Deal[];
  agencyName?: string;
}

export const DirectorDashboardConsole: React.FC<DirectorDashboardConsoleProps> = ({
  currentUser,
  currentRole = 'director',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onNavigateToScreen,
  triggerNotification,
  onAddActivityLog,
  creators = [],
  deals = [],
  agencyName = 'Bloom & Co. Studio'
}) => {
  const [activeTab, setActiveTab] = useState<'pay_system_guide' | 'campaign_revenue' | 'creator_payouts'>('pay_system_guide');

  // Compute live metrics from passed deals & creators
  const financialMetrics = useMemo(() => {
    let totalGrossContracted = 0;
    let totalEscrowSecured = 0;
    let totalCreatorAllocations = 0;
    let totalAgencyMargin = 0;

    if (deals.length > 0) {
      deals.forEach((deal) => {
        const val = Number(deal.budget || deal.value || deal.amount || 0);
        totalGrossContracted += val;
        // In a typical 80/20 agency model:
        const creatorCut = val * 0.8;
        const agencyCut = val * 0.2;
        totalCreatorAllocations += creatorCut;
        totalAgencyMargin += agencyCut;

        if (deal.stage === 'Contracted' || deal.stage === 'Live' || deal.stage === 'Negotiating') {
          totalEscrowSecured += val;
        }
      });
    } else {
      // Fallback sensible defaults if deals list is empty
      totalGrossContracted = 145000;
      totalEscrowSecured = 68500;
      totalCreatorAllocations = 116000;
      totalAgencyMargin = 29000;
    }

    return {
      totalGrossContracted,
      totalEscrowSecured,
      totalCreatorAllocations,
      totalAgencyMargin
    };
  }, [deals]);

  return (
    <div className="space-y-8 animate-fade-in" id="directorDashboardConsole">
      {/* 1. Header & Lean Agency Model Banner */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[10px] font-mono uppercase tracking-widest font-bold px-2.5 py-1 rounded-full border text-[#C9A46A] border-[#C9A46A]/30 bg-[#C9A46A]/10 flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-[#C9A46A]" />
                Director Financial Command
              </span>
              <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                Lean Agency Model (0% Overhead)
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-serif font-bold text-white tracking-tight flex items-center gap-3">
              <span>Agency Revenue &amp; Pay Command</span>
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl mt-1">
              Direct administrative console for {agencyName}&apos;s brand revenue, Stripe escrow deposits, and creator payouts.
            </p>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 bg-[#081020] p-1.5 rounded-2xl border border-white/10 shrink-0 shadow-inner">
            <button
              type="button"
              onClick={() => setActiveTab('pay_system_guide')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                activeTab === 'pay_system_guide'
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md font-extrabold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Pay System Guide
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('campaign_revenue')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                activeTab === 'campaign_revenue'
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md font-extrabold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              Campaign Revenue &amp; Escrow
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('creator_payouts')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                activeTab === 'creator_payouts'
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md font-extrabold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Creator Payouts Roster
            </button>
          </div>
        </div>

        {/* 2. LEAN MODEL STATUS BANNER (EXPLICIT DIRECTIVE RESPONSE) */}
        <div className="bg-gradient-to-r from-emerald-950/40 via-[#0B1A2E] to-[#081020] border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shrink-0 mt-0.5 sm:mt-0">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono uppercase tracking-widest font-extrabold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Zero Operational Expense Model Active
                </span>
                <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                  <EyeOff className="w-3 h-3 text-slate-400" /> Corporate Debt &amp; Expense Cards Disabled
                </span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed max-w-3xl">
                Your agency operates on a <strong>direct escrow-to-talent payout model</strong>. Because you carry zero operational expenses or corporate card overhead, <strong>100% of brand deal revenue is split purely between Creator Payouts (80%) and Agency Net Profit (20%)</strong>.
              </p>
            </div>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <button
              type="button"
              onClick={() => onNavigateToScreen('invoices')}
              className="text-xs bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2.5 rounded-xl font-mono font-bold flex items-center gap-1.5 transition-all shadow-md"
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Bill a Brand</span>
            </button>
          </div>
        </div>

        {/* 3. FOUR TOP FINANCIAL KPIS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#0b162c] border border-white/10 rounded-2xl p-5 space-y-2">
            <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold tracking-wider flex items-center justify-between">
              <span>Gross Contracted Revenue</span>
              <Receipt className="w-3.5 h-3.5 text-blue-400" />
            </span>
            <p className="text-2xl font-serif font-bold text-white">
              ${financialMetrics.totalGrossContracted.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <span className="text-[10px] text-slate-400 font-mono">
              Total brand campaigns contracted
            </span>
          </div>

          <div className="bg-[#0b162c] border border-white/10 rounded-2xl p-5 space-y-2">
            <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold tracking-wider flex items-center justify-between">
              <span>Funds Secured in Escrow</span>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            </span>
            <p className="text-2xl font-serif font-bold text-emerald-400">
              ${financialMetrics.totalEscrowSecured.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <span className="text-[10px] text-emerald-400/80 font-mono flex items-center gap-1">
              <Check className="w-3 h-3" /> 100% Upfront Brand Escrow
            </span>
          </div>

          <div className="bg-[#0b162c] border border-white/10 rounded-2xl p-5 space-y-2">
            <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold tracking-wider flex items-center justify-between">
              <span>Creator Payout Allocations</span>
              <Landmark className="w-3.5 h-3.5 text-amber-400" />
            </span>
            <p className="text-2xl font-serif font-bold text-amber-300">
              ${financialMetrics.totalCreatorAllocations.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <span className="text-[10px] text-slate-400 font-mono">
              Disbursed via Direct Deposit (ACH)
            </span>
          </div>

          <div className="bg-[#0b162c] border border-[#C9A46A]/30 rounded-2xl p-5 space-y-2 bg-gradient-to-br from-[#0B162C] to-[#122340]">
            <span className="text-[10px] font-mono uppercase text-[#C9A46A] font-semibold tracking-wider flex items-center justify-between">
              <span>Agency Net Profit (100% Margin)</span>
              <DollarSign className="w-3.5 h-3.5 text-[#C9A46A]" />
            </span>
            <p className="text-2xl font-serif font-bold text-[#D4AF37]">
              ${financialMetrics.totalAgencyMargin.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <span className="text-[10px] text-emerald-400 font-mono">
              Pure profit (zero operational overhead)
            </span>
          </div>
        </div>
      </div>

      {/* TAB 1: THE SIMPLIFIED 2-PAGE PAY SYSTEM GUIDE */}
      {activeTab === 'pay_system_guide' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-[#0b162c] border border-[#C9A46A]/30 rounded-2xl p-6 sm:p-7 space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
              <div>
                <h2 className="text-xl font-serif font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#C9A46A]" />
                  <span>The Streamlined Pay System: Exactly What Pages to Use</span>
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  Since your agency does not carry operational expenses or corporate debt, your payment system is simple: <strong>Money In from Brands</strong>, and <strong>Money Out to Creators</strong>.
                </p>
              </div>
              <div className="px-3.5 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs font-mono text-slate-300 shrink-0">
                Total Core Pages Needed: <strong className="text-emerald-400">Just 2</strong>
              </div>
            </div>

            {/* THE TWO CORE PAGES */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Core Page 1: Brand Invoicing */}
              <div className="bg-[#070e1c] border-2 border-blue-500/40 hover:border-blue-400 rounded-2xl p-6 flex flex-col justify-between space-y-5 transition-all shadow-xl group">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono uppercase font-extrabold text-blue-300 bg-blue-500/20 px-3 py-1 rounded-full border border-blue-500/30 flex items-center gap-1.5">
                      <Receipt className="w-3.5 h-3.5" />
                      Core Page 1 &bull; Money IN
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">Screen: &apos;invoices&apos;</span>
                  </div>
                  <h3 className="text-xl font-serif font-bold text-white group-hover:text-blue-300 transition-colors">
                    Invoices &amp; Billing Workspace
                  </h3>
                  <div className="p-3 bg-blue-950/30 rounded-xl border border-blue-500/20 space-y-1">
                    <span className="text-[11px] font-mono font-bold text-blue-200 uppercase tracking-wider block">
                      When to use this:
                    </span>
                    <p className="text-xs text-slate-200 leading-relaxed">
                      Whenever you book a brand deal. Generate a professional Stripe invoice or payment link and send it to the brand contact.
                    </p>
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                    <li>Collects 100% upfront campaign fees from the brand.</li>
                    <li>Funds are locked securely in Stripe Escrow before filming begins.</li>
                    <li>Guarantees payment safety with net-0 credit risk.</li>
                  </ul>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigateToScreen('invoices')}
                  className="w-full text-xs bg-blue-600 hover:bg-blue-500 text-white font-mono font-bold py-3 px-4 rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>Open Invoices &amp; Billing Workspace</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>

              {/* Core Page 2: Global Payroll & Escrow Hub */}
              <div className="bg-[#070e1c] border-2 border-emerald-500/40 hover:border-emerald-400 rounded-2xl p-6 flex flex-col justify-between space-y-5 transition-all shadow-xl group">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono uppercase font-extrabold text-emerald-300 bg-emerald-500/20 px-3 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1.5">
                      <DollarSign className="w-3.5 h-3.5" />
                      Core Page 2 &bull; Money OUT
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">Screen: &apos;payroll-schedule&apos;</span>
                  </div>
                  <h3 className="text-xl font-serif font-bold text-white group-hover:text-emerald-300 transition-colors">
                    Global Payroll &amp; Escrow Hub
                  </h3>
                  <div className="p-3 bg-emerald-950/30 rounded-xl border border-emerald-500/20 space-y-1">
                    <span className="text-[11px] font-mono font-bold text-emerald-200 uppercase tracking-wider block">
                      When to use this:
                    </span>
                    <p className="text-xs text-slate-200 leading-relaxed">
                      When video deliverables are approved. Click &quot;Disburse Payouts&quot; to unlock funds from Escrow directly into the creator&apos;s bank account.
                    </p>
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                    <li>Releases creator compensation via Direct Deposit (ACH) or PayPal.</li>
                    <li>Calculates your agency retained profit (e.g. 20%) automatically.</li>
                    <li>No corporate debit cards or manual receipts required.</li>
                  </ul>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigateToScreen('payroll-schedule')}
                  className="w-full text-xs bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-mono font-extrabold py-3 px-4 rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>Open Global Payroll &amp; Escrow Hub</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* SUPPORTING PAGES SUMMARY */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <h4 className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-4 h-4 text-[#C9A46A]" />
                Supporting Pages (For Setup &amp; Tax Compliance Only)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-[#070e1c] border border-white/10 rounded-xl p-4 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[10px] font-mono text-purple-400 uppercase font-semibold">1. Creator Bank Setup</span>
                    <h5 className="text-sm font-bold text-white mt-1">Creator Roster / Media Kit</h5>
                    <p className="text-[11px] text-slate-300 mt-1">
                      Where creators add their ACH checking/savings routing and account numbers under &quot;Payout &amp; Payment Method&quot;.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigateToScreen('roster')}
                    className="text-xs text-[#C9A46A] hover:underline font-mono font-semibold flex items-center gap-1 cursor-pointer pt-2"
                  >
                    <span>View Creator Roster</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="bg-[#070e1c] border border-white/10 rounded-xl p-4 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[10px] font-mono text-amber-400 uppercase font-semibold">2. IRS Tax Compliance</span>
                    <h5 className="text-sm font-bold text-white mt-1">Tax &amp; W-9 Vault</h5>
                    <p className="text-[11px] text-slate-300 mt-1">
                      Where creator Form W-9s are stored to ensure compliance before payouts cross the $600 1099-NEC annual threshold.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigateToScreen('irs-tax-vault')}
                    className="text-xs text-amber-300 hover:underline font-mono font-semibold flex items-center gap-1 cursor-pointer pt-2"
                  >
                    <span>Open Tax Vault</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="bg-[#070e1c] border border-white/10 rounded-xl p-4 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[10px] font-mono text-emerald-400 uppercase font-semibold">3. High-Level Pipeline</span>
                    <h5 className="text-sm font-bold text-white mt-1">Deals &amp; Revenue Hub</h5>
                    <p className="text-[11px] text-slate-300 mt-1">
                      Bird&apos;s-eye view of all contracted deals across your entire agency and total commission splits.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigateToScreen('deals-revenue-hub')}
                    className="text-xs text-emerald-300 hover:underline font-mono font-semibold flex items-center gap-1 cursor-pointer pt-2"
                  >
                    <span>View Deals Hub</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>

            {/* WHAT HAS BEEN HIDDEN & EXCLUDED */}
            <div className="bg-[#060B14] border border-white/5 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-400">
              <EyeOff className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-300 block">Deactivated Pages (Not in Your Workflow):</strong>
                <span>
                  Corporate credit cards, JIT shoot debit cards, and corporate expense ledgers have been removed from your active navigation. You operate a clean, high-margin talent management model with zero overhead.
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CAMPAIGN REVENUE & ESCROW BREAKDOWN */}
      {activeTab === 'campaign_revenue' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-[#0b162c] border border-white/10 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#C9A46A]" />
                  Campaign Revenue &amp; Escrow Status
                </h3>
                <p className="text-xs text-slate-300">
                  Tracking active brand contracts, upfront escrow balances, and net agency revenue.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onNavigateToScreen('invoices')}
                  className="text-xs bg-[#13223d] hover:bg-[#1a3057] text-[#C9A46A] px-3.5 py-2 rounded-xl font-mono font-semibold border border-white/10 flex items-center gap-1.5 transition-all"
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>Create Invoice</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigateToScreen('payroll-schedule')}
                  className="text-xs bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3.5 py-2 rounded-xl font-mono font-bold flex items-center gap-1.5 transition-all shadow-md"
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Disburse Payouts</span>
                </button>
              </div>
            </div>

            {/* Deals & Campaigns Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead>
                  <tr className="border-b border-white/10 font-mono text-[10px] uppercase text-slate-400">
                    <th className="py-3 px-3">Brand &amp; Campaign</th>
                    <th className="py-3 px-3">Creator</th>
                    <th className="py-3 px-3">Escrow Status</th>
                    <th className="py-3 px-3 text-right">Brand Gross</th>
                    <th className="py-3 px-3 text-right">Creator Payout (80%)</th>
                    <th className="py-3 px-3 text-right">Agency Net (20%)</th>
                    <th className="py-3 px-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {deals.length > 0 ? (
                    deals.map((deal) => {
                      const amount = Number(deal.budget || deal.value || deal.amount || 5000);
                      const creatorCut = amount * 0.8;
                      const agencyCut = amount * 0.2;
                      return (
                        <tr key={deal.id} className="hover:bg-white/5 transition-colors">
                          <td className="py-3.5 px-3">
                            <span className="font-bold text-white block">{deal.brand}</span>
                            <span className="text-[11px] text-slate-400 font-mono">{deal.deliverable || deal.title || 'Brand UGC Campaign'}</span>
                          </td>
                          <td className="py-3.5 px-3 font-mono text-emerald-400">
                            {deal.creatorHandle || deal.creator || '@talent'}
                          </td>
                          <td className="py-3.5 px-3">
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              {deal.stage === 'Completed' ? 'Released / Disbursed' : 'Secured in Escrow'}
                            </span>
                          </td>
                          <td className="py-3.5 px-3 text-right font-mono font-bold text-white">
                            ${amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-3.5 px-3 text-right font-mono text-amber-300">
                            ${creatorCut.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-3.5 px-3 text-right font-mono font-bold text-[#D4AF37]">
                            ${agencyCut.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-3.5 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => onNavigateToScreen('payroll-schedule')}
                              className="text-[11px] font-mono text-[#C9A46A] hover:underline"
                            >
                              Manage Escrow
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <>
                      <tr className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-3">
                          <span className="font-bold text-white block">GlowLab Beauty</span>
                          <span className="text-[11px] text-slate-400 font-mono">Summer Botanical Serum UGC</span>
                        </td>
                        <td className="py-3.5 px-3 font-mono text-emerald-400">@ava_glow</td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            Secured in Escrow
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-white">$12,000.00</td>
                        <td className="py-3.5 px-3 text-right font-mono text-amber-300">$9,600.00</td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-[#D4AF37]">$2,400.00</td>
                        <td className="py-3.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => onNavigateToScreen('payroll-schedule')}
                            className="text-[11px] font-mono text-[#C9A46A] hover:underline"
                          >
                            Release
                          </button>
                        </td>
                      </tr>
                      <tr className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-3">
                          <span className="font-bold text-white block">BarkHydrate Eco</span>
                          <span className="text-[11px] text-slate-400 font-mono">Pet Shampoo Launch</span>
                        </td>
                        <td className="py-3.5 px-3 font-mono text-emerald-400">@paws_and_palette</td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                            Invoice Sent
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-white">$8,500.00</td>
                        <td className="py-3.5 px-3 text-right font-mono text-amber-300">$6,800.00</td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-[#D4AF37]">$1,700.00</td>
                        <td className="py-3.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => onNavigateToScreen('invoices')}
                            className="text-[11px] font-mono text-blue-300 hover:underline"
                          >
                            View Invoice
                          </button>
                        </td>
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CREATOR PAYOUT ROSTER & BANK VERIFICATION */}
      {activeTab === 'creator_payouts' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-[#0b162c] border border-white/10 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                  <Landmark className="w-5 h-5 text-emerald-400" />
                  Creator Payout Accounts &amp; Tax Compliance
                </h3>
                <p className="text-xs text-slate-300">
                  Direct Deposit (ACH) banking details and IRS Form W-9 verification for talent payouts.
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateToScreen('roster')}
                className="text-xs bg-[#13223d] hover:bg-[#1a3057] text-[#C9A46A] px-3.5 py-2 rounded-xl font-mono font-semibold border border-white/10 flex items-center gap-1.5 transition-all"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Open Full Roster</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead>
                  <tr className="border-b border-white/10 font-mono text-[10px] uppercase text-slate-400">
                    <th className="py-3 px-3">Creator Name &amp; Handle</th>
                    <th className="py-3 px-3">Payout Method</th>
                    <th className="py-3 px-3">Bank Details (ACH)</th>
                    <th className="py-3 px-3">IRS W-9 Status</th>
                    <th className="py-3 px-3 text-right">Contract Split</th>
                    <th className="py-3 px-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {creators.length > 0 ? (
                    creators.map((c) => (
                      <tr key={c.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-3">
                          <span className="font-bold text-white block">{c.name}</span>
                          <span className="text-[11px] text-slate-400 font-mono">{c.handle}</span>
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            {c.paymentMethod || 'Direct Deposit (ACH)'}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 font-mono text-slate-300">
                          {c.bankName ? `${c.bankName} (•••• ${c.accountNumber ? c.accountNumber.slice(-4) : '••••'})` : c.paymentDetails || 'Direct Deposit Configured'}
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                            {c.w9Status || (c.w9Uploaded ? 'W-9 Verified' : 'IRS W-9 on File')}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-400">
                          {c.commissionSplit || '80% Talent / 20% Agency'}
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => onNavigateToScreen('roster')}
                            className="text-[11px] font-mono text-[#C9A46A] hover:underline"
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <>
                      <tr className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-3">
                          <span className="font-bold text-white block">Ava Sinclair</span>
                          <span className="text-[11px] text-slate-400 font-mono">@ava_glow</span>
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            Direct Deposit (ACH)
                          </span>
                        </td>
                        <td className="py-3.5 px-3 font-mono text-slate-300">
                          JPMorgan Chase (•••• 8912)
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                            W-9 Verified
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-400">
                          80% Talent / 20% Agency
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => onNavigateToScreen('roster')}
                            className="text-[11px] font-mono text-[#C9A46A] hover:underline"
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                      <tr className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-3">
                          <span className="font-bold text-white block">Marcus Vance</span>
                          <span className="text-[11px] text-slate-400 font-mono">@paws_and_palette</span>
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            Direct Deposit (ACH)
                          </span>
                        </td>
                        <td className="py-3.5 px-3 font-mono text-slate-300">
                          Wells Fargo (•••• 4120)
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                            W-9 Verified
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold text-emerald-400">
                          80% Talent / 20% Agency
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => onNavigateToScreen('roster')}
                            className="text-[11px] font-mono text-[#C9A46A] hover:underline"
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DirectorDashboardConsole;
