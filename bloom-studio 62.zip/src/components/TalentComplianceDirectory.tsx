import React, { useState, useEffect, useMemo } from 'react';
import { 
  Shield, UserCheck, FileText, Download, CheckCircle, Search, Filter, 
  ArrowUpRight, Loader2, Mail, ExternalLink, MoreVertical, Lock, 
  ShieldCheck, AlertTriangle, Clock, RefreshCw, Eye, Award, CheckCircle2, 
  Copy, Check, FileCheck, Users, X, Send, Sparkles, Printer, Landmark, DollarSign
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { getSafeUrl } from '../utils/security';
import { safeStorage } from '../utils/safeStorage';
import { Creator } from '../types';
import { IrsTaxIntakeVault } from './IrsTaxIntakeVault';
import W9And1099Tracker from './W9And1099Tracker';

interface StudioUserRecord {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
  subagency?: string;
  tenantId?: string;
  agreementUrl?: string;
  w9Url?: string;
  createdAt: string;
  hasSignedToS?: boolean;
  tosSignedAt?: string;
  tosSignerName?: string;
  tosVersion?: string;
  tosDigest?: string;
  handle?: string;
}

interface TalentComplianceDirectoryProps {
  currentUser?: any;
  currentRole?: string;
  creators?: Creator[];
  onNotify?: (title: string, message: string, type?: any) => void;
  triggerNotification?: (title: string, message: string, type?: any) => void;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  defaultTab?: 'tos-registry' | 'tax-vault' | '1099-tracker' | 'onboarding-queue';
}

export default function TalentComplianceDirectory({ 
  currentUser, 
  currentRole = 'director',
  creators = [],
  onNotify,
  triggerNotification,
  onAddActivityLog,
  defaultTab = 'tos-registry'
}: TalentComplianceDirectoryProps) {
  const notify = (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger' | 'error') => {
    const safeType = type === 'error' ? 'danger' : type;
    if (triggerNotification) {
      triggerNotification(title, message, safeType);
    } else if (onNotify) {
      onNotify(title, message, safeType);
    } else {
      console.log(title, message);
    }
  };

  const [activeTab, setActiveTab] = useState<'tos-registry' | 'tax-vault' | '1099-tracker' | 'onboarding-queue'>(defaultTab);
  const [usersList, setUsersList] = useState<StudioUserRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<'all' | 'agreed' | 'pending'>('all');
  const [selectedUserForCert, setSelectedUserForCert] = useState<StudioUserRecord | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Subscribe to all users in studio-users with real-time Firestore sync
  useEffect(() => {
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, 'studio-users');
    const q = isPlatformOwner
      ? colRef
      : query(colRef, where('subagency', '==', currentUser?.subagency || 'pod_main'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: StudioUserRecord[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        list.push({
          id: docSnap.id,
          name: data.displayName || data.name || data.email?.split('@')[0] || 'Studio User',
          email: data.email || 'No Email',
          role: data.role || 'creator',
          status: data.status || 'Active',
          subagency: data.subagency || 'pod_main',
          tenantId: data.tenantId || 'bloom_studio_default',
          agreementUrl: data.agreementUrl,
          w9Url: data.w9Url,
          createdAt: data.createdAt || data.updatedAt || new Date().toISOString(),
          hasSignedToS: Boolean(data.hasSignedToS || data.tosSignedAt),
          tosSignedAt: data.tosSignedAt || (data.hasSignedToS ? data.updatedAt || data.createdAt : undefined),
          tosSignerName: data.tosSignerName || data.displayName || data.name,
          tosVersion: data.tosVersion || (data.hasSignedToS ? 'v2026.1' : undefined),
          tosDigest: data.tosDigest || (data.hasSignedToS ? `SHA256:VERIFIED:${docSnap.id.substring(0, 16)}` : undefined),
          handle: data.handle || `@${(data.displayName || data.name || 'user').toLowerCase().replace(/\s+/g, '_')}`
        });
      });

      // Default mock users fallback if database is bootstrapping
      if (list.length === 0) {
        list.push(
          {
            id: currentUser?.id || 'user_director',
            name: currentUser?.name || 'Executive Director',
            email: currentUser?.email || 'director@bloomstudio.internal',
            role: 'director',
            status: 'Compliance_Cleared',
            subagency: currentUser?.subagency || 'pod_main',
            createdAt: new Date(Date.now() - 86400000 * 30).toISOString(),
            hasSignedToS: true,
            tosSignedAt: new Date(Date.now() - 86400000 * 20).toISOString(),
            tosSignerName: currentUser?.name || 'Executive Director',
            tosVersion: 'v2026.1',
            tosDigest: 'SHA256:9f8a8c7b6a5e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c',
            handle: '@director'
          },
          {
            id: 'user_creator_elena',
            name: 'Elena Rostova',
            email: 'elena.rostova@bloomtalent.co',
            role: 'creator',
            status: 'Compliance_Cleared',
            subagency: 'pod_main',
            createdAt: new Date(Date.now() - 86400000 * 14).toISOString(),
            hasSignedToS: true,
            tosSignedAt: new Date(Date.now() - 86400000 * 13).toISOString(),
            tosSignerName: 'Elena Rostova',
            tosVersion: 'v2026.1',
            tosDigest: 'SHA256:3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b',
            handle: '@elena_rostova'
          },
          {
            id: 'user_agent_marcus',
            name: 'Marcus Vance',
            email: 'm.vance@bloomagency.internal',
            role: 'agentmgr',
            status: 'Compliance_Cleared',
            subagency: 'pod_main',
            createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
            hasSignedToS: true,
            tosSignedAt: new Date(Date.now() - 86400000 * 9).toISOString(),
            tosSignerName: 'Marcus Vance',
            tosVersion: 'v2026.1',
            tosDigest: 'SHA256:7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d',
            handle: '@marcus_vance'
          },
          {
            id: 'user_brand_sephora',
            name: 'Sephora Global Brand Team',
            email: 'partnerships@sephora.com',
            role: 'brand',
            status: 'Compliance_Cleared',
            subagency: 'pod_main',
            createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
            hasSignedToS: true,
            tosSignedAt: new Date(Date.now() - 86400000 * 5).toISOString(),
            tosSignerName: 'Sarah Jenkins (VP Brand Marketing)',
            tosVersion: 'v2026.1',
            tosDigest: 'SHA256:1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
            handle: '@sephora_us'
          },
          {
            id: 'user_creator_kai',
            name: 'Kai Takahashi',
            email: 'kai.takahashi@creatornetwork.io',
            role: 'creator',
            status: 'Pending',
            subagency: 'pod_main',
            createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
            hasSignedToS: false,
            handle: '@kai_t'
          }
        );
      }

      setUsersList(list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      setLoading(false);
    }, (err) => {
      console.warn('[TalentComplianceDirectory] Firestore subscription error:', err);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Calculated Compliance Metrics
  const metrics = useMemo(() => {
    const total = usersList.length;
    const agreedCount = usersList.filter(u => u.hasSignedToS).length;
    const pendingCount = total - agreedCount;
    const percentage = total > 0 ? Math.round((agreedCount / total) * 100) : 100;
    const w9Cleared = usersList.filter(u => u.status === 'Compliance_Cleared').length;

    return {
      total,
      agreedCount,
      pendingCount,
      percentage,
      w9Cleared
    };
  }, [usersList]);

  // Filtered list for ToS Registry
  const filteredUsers = useMemo(() => {
    return usersList.filter((u) => {
      const matchesSearch = 
        u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (u.tosDigest && u.tosDigest.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesRole = roleFilter === 'All' || u.role.toLowerCase() === roleFilter.toLowerCase();
      
      const matchesStatus = 
        statusFilter === 'all' ? true :
        statusFilter === 'agreed' ? u.hasSignedToS :
        !u.hasSignedToS;

      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [usersList, searchQuery, roleFilter, statusFilter]);

  // Applicants queue
  const onboardingQueue = useMemo(() => {
    return usersList.filter(u => u.status !== 'Compliance_Cleared' && u.role !== 'director');
  }, [usersList]);

  // Administrative approve & clear
  const handleApproveCompliance = async (userId: string) => {
    setProcessingId(userId);
    try {
      const userRef = doc(db, 'studio-users', userId);
      await setDoc(userRef, { 
        status: 'Compliance_Cleared',
        complianceClearedAt: serverTimestamp(),
        accountUnlocked: true
      }, { merge: true });
      
      notify('Compliance Cleared', `Account clearance and access keys issued for ${userId}.`, 'success');
    } catch (err: any) {
      console.error('Error approving compliance:', err);
      notify('Approval Failed', err?.message || 'Could not update user record.', 'error');
    } finally {
      setProcessingId(null);
    }
  };

  // Administrative mark as agreed (e.g. offline execution)
  const handleMarkToSAgreed = async (user: StudioUserRecord) => {
    setProcessingId(user.id);
    const nowIso = new Date().toISOString();
    try {
      const userRef = doc(db, 'studio-users', user.id);
      await setDoc(userRef, { 
        hasSignedToS: true,
        tosSignedAt: nowIso,
        tosSignerName: `${user.name} (Admin Certified)`,
        tosVersion: 'v2026.1',
        tosDigest: `SHA256:MANUAL_ADMIN_OVERRIDE:${user.id.substring(0, 16)}`,
        updatedAt: nowIso
      }, { merge: true });
      
      notify('ToS Status Updated', `Recorded verified Master Agency Terms agreement for ${user.name}.`, 'success');
    } catch (err: any) {
      console.error('Error updating ToS status:', err);
      notify('Update Failed', err?.message || 'Failed to update agreement state.', 'error');
    } finally {
      setProcessingId(null);
    }
  };

  const handleCopyDigest = (text: string, id: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    notify('Digest Copied', 'SHA-256 cryptographic verification string copied to clipboard.', 'info');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      {/* Header Section */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/30">
              <ShieldCheck className="w-7 h-7 text-[#D4AF37]" />
            </div>
            <div>
              <h1 className="text-3xl font-serif font-bold text-white tracking-tight">Legal, Tax &amp; Compliance Center</h1>
              <p className="text-[#7C8AA8] text-xs font-mono uppercase tracking-widest mt-0.5">
                Master Agency Terms of Service • Anti-Poaching NDAs • IRS Form W-9 Vault • 1099-NEC Thresholds &amp; Onboarding
              </p>
            </div>
          </div>
        </div>

        {/* Global Tab Switcher */}
        <div className="flex flex-wrap bg-[#0B1B3D] p-1.5 rounded-2xl border border-white/10 gap-1 self-start lg:self-auto">
          <button
            onClick={() => setActiveTab('tos-registry')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'tos-registry'
                ? 'bg-[#D4AF37] text-[#0B1B3D] shadow-lg shadow-[#D4AF37]/20 font-extrabold'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            <FileCheck className="w-4 h-4" />
            <span>Legal &amp; ToS Registry</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeTab === 'tos-registry' ? 'bg-[#0B1B3D]/20 text-[#0B1B3D]' : 'bg-white/10 text-white'
            }`}>
              {metrics.agreedCount}/{metrics.total}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('tax-vault')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'tax-vault'
                ? 'bg-[#D4AF37] text-[#0B1B3D] shadow-lg shadow-[#D4AF37]/20 font-extrabold'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            <Landmark className="w-4 h-4" />
            <span>IRS W-9 Tax Vault</span>
          </button>

          <button
            onClick={() => setActiveTab('1099-tracker')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === '1099-tracker'
                ? 'bg-[#D4AF37] text-[#0B1B3D] shadow-lg shadow-[#D4AF37]/20 font-extrabold'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>1099 Tracker &amp; Filing</span>
          </button>

          <button
            onClick={() => setActiveTab('onboarding-queue')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'onboarding-queue'
                ? 'bg-[#D4AF37] text-[#0B1B3D] shadow-lg shadow-[#D4AF37]/20 font-extrabold'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Onboarding &amp; Clearance</span>
            {onboardingQueue.length > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                {onboardingQueue.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#142850] border border-white/5 rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[#7C8AA8] font-bold uppercase tracking-wider">Total Roster Registered</span>
            <Users className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-mono font-bold text-white">{metrics.total}</span>
            <span className="text-xs text-slate-400 font-mono">Active Pod Users</span>
          </div>
        </div>

        <div className="bg-[#142850] border border-emerald-500/20 rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-emerald-400 font-bold uppercase tracking-wider">ToS Agreed &amp; Certified</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-mono font-bold text-emerald-400">{metrics.agreedCount}</span>
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              {metrics.percentage}% Compliance
            </span>
          </div>
        </div>

        <div className="bg-[#142850] border border-amber-500/20 rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-amber-400 font-bold uppercase tracking-wider">Pending Signatures</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-mono font-bold text-amber-400">{metrics.pendingCount}</span>
            <span className="text-xs text-slate-400 font-mono">Awaiting Onboarding</span>
          </div>
        </div>

        <div className="bg-[#142850] border border-white/5 rounded-3xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[#7C8AA8] font-bold uppercase tracking-wider">Tax &amp; Identity Clear</span>
            <Award className="w-4 h-4 text-blue-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-3xl font-mono font-bold text-white">{metrics.w9Cleared}</span>
            <span className="text-xs text-slate-400 font-mono">W-9 Verified</span>
          </div>
        </div>
      </div>

      {/* Main Tab 1: ToS & Legal Agreements Registry */}
      {activeTab === 'tos-registry' && (
        <div className="space-y-6">
          {/* Controls & Filter Bar */}
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 bg-[#142850]/50 p-4 rounded-3xl border border-white/5">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7C8AA8]" />
              <input
                type="text"
                placeholder="Search by legal name, email, role, or SHA-256 digest..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl pl-11 pr-4 py-2.5 text-xs text-white placeholder:text-[#7C8AA8] focus:border-[#D4AF37] outline-none transition"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {/* Status Filter */}
              <div className="flex bg-[#0B1B3D] p-1 rounded-2xl border border-white/10 text-xs">
                <button
                  onClick={() => setStatusFilter('all')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition ${
                    statusFilter === 'all' ? 'bg-[#D4AF37] text-[#0B1B3D]' : 'text-[#7C8AA8] hover:text-white'
                  }`}
                >
                  All Status
                </button>
                <button
                  onClick={() => setStatusFilter('agreed')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition ${
                    statusFilter === 'agreed' ? 'bg-emerald-500 text-white' : 'text-[#7C8AA8] hover:text-white'
                  }`}
                >
                  Agreed ({metrics.agreedCount})
                </button>
                <button
                  onClick={() => setStatusFilter('pending')}
                  className={`px-3 py-1.5 rounded-xl font-bold transition ${
                    statusFilter === 'pending' ? 'bg-amber-500 text-white' : 'text-[#7C8AA8] hover:text-white'
                  }`}
                >
                  Pending ({metrics.pendingCount})
                </button>
              </div>

              {/* Role Filter */}
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="bg-[#0B1B3D] border border-white/10 rounded-2xl px-3 py-2 text-xs text-white focus:border-[#D4AF37] outline-none font-bold"
              >
                <option value="All">All Roles</option>
                <option value="Creator">Creators</option>
                <option value="Agentmgr">Agent Managers</option>
                <option value="Brand">Brands</option>
                <option value="Director">Directors</option>
              </select>
            </div>
          </div>

          {/* Interactive ToS Registry Table */}
          <div className="bg-[#142850] border border-white/5 rounded-3xl overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#0B1B3D]/70">
                    <th className="px-6 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Signer &amp; Legal Identity</th>
                    <th className="px-5 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Account Role</th>
                    <th className="px-5 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Master Terms Status</th>
                    <th className="px-5 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Executed Timestamp</th>
                    <th className="px-5 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Cryptographic Digest</th>
                    <th className="px-6 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest text-right">Audit Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {loading ? (
                    <tr>
                      <td colSpan={6} className="px-8 py-20 text-center">
                        <Loader2 className="w-8 h-8 text-[#D4AF37] animate-spin mx-auto mb-3" />
                        <p className="text-[#7C8AA8] text-xs font-mono">Synchronizing legal agreement ledger...</p>
                      </td>
                    </tr>
                  ) : filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-8 py-16 text-center">
                        <CheckCircle className="w-8 h-8 text-emerald-500/40 mx-auto mb-3" />
                        <p className="text-white text-sm font-bold">No user records matching criteria.</p>
                        <p className="text-[#7C8AA8] text-xs mt-1">Adjust your search query or filters.</p>
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((item) => (
                      <tr key={item.id} className="group hover:bg-white/[0.02] transition-colors">
                        {/* User identity */}
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 bg-[#0B1B3D] border border-white/10 rounded-xl flex items-center justify-center text-[#D4AF37] font-bold text-xs">
                              {item.name[0] || 'U'}
                            </div>
                            <div>
                              <p className="text-xs font-bold text-white flex items-center gap-1.5">
                                {item.name}
                                {item.role === 'director' && (
                                  <span className="text-[9px] bg-[#D4AF37]/20 text-[#D4AF37] px-1.5 py-0.5 rounded border border-[#D4AF37]/30 font-mono">
                                    Director
                                  </span>
                                )}
                              </p>
                              <p className="text-[10px] text-[#7C8AA8] flex items-center gap-1">
                                <Mail className="w-3 h-3 text-[#7C8AA8]" /> {item.email}
                              </p>
                            </div>
                          </div>
                        </td>

                        {/* Role */}
                        <td className="px-5 py-4">
                          <span className="inline-flex px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-[10px] text-white/70 font-bold uppercase tracking-wider font-mono">
                            {item.role}
                          </span>
                        </td>

                        {/* ToS Status */}
                        <td className="px-5 py-4">
                          {item.hasSignedToS ? (
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Agreed &amp; Certified ({item.tosVersion || 'v2026.1'})</span>
                            </div>
                          ) : (
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[10px] font-bold">
                              <Clock className="w-3.5 h-3.5 text-amber-400" />
                              <span>Pending Agreement</span>
                            </div>
                          )}
                        </td>

                        {/* Executed timestamp */}
                        <td className="px-5 py-4">
                          {item.tosSignedAt ? (
                            <div className="text-[11px] font-mono text-slate-300">
                              <p>{new Date(item.tosSignedAt).toLocaleDateString()}</p>
                              <p className="text-[9px] text-[#7C8AA8]">{new Date(item.tosSignedAt).toLocaleTimeString()}</p>
                            </div>
                          ) : (
                            <span className="text-[10px] text-[#7C8AA8] italic">Awaiting first sign-in</span>
                          )}
                        </td>

                        {/* Cryptographic hash */}
                        <td className="px-5 py-4">
                          {item.tosDigest ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-[10px] font-mono text-slate-400 bg-[#0B1B3D] px-2 py-1 rounded-lg border border-white/5 max-w-[140px] truncate" title={item.tosDigest}>
                                {item.tosDigest.startsWith('SHA256:') ? item.tosDigest.slice(7, 24) + '...' : item.tosDigest.slice(0, 16) + '...'}
                              </span>
                              <button
                                onClick={() => handleCopyDigest(item.tosDigest!, item.id)}
                                className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/5 transition"
                                title="Copy full SHA-256 digest"
                              >
                                {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-500 font-mono">Unsigned</span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {item.hasSignedToS ? (
                              <button
                                onClick={() => setSelectedUserForCert(item)}
                                className="px-3 py-1.5 rounded-xl bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30 text-[#D4AF37] text-[10px] font-bold transition flex items-center gap-1.5 cursor-pointer"
                                title="Inspect Digital Certificate of Execution"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Certificate</span>
                              </button>
                            ) : (
                              <button
                                onClick={() => handleMarkToSAgreed(item)}
                                disabled={processingId === item.id}
                                className="px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold transition flex items-center gap-1.5 cursor-pointer"
                                title="Certify agreement manually for user"
                              >
                                {processingId === item.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                                <span>Verify Signed</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Main Tab 2: IRS W-9 Tax Vault */}
      {activeTab === 'tax-vault' && (
        <div className="space-y-6">
          <IrsTaxIntakeVault
            creators={creators}
            currentUser={currentUser}
            currentRole={currentRole}
            onAddActivityLog={onAddActivityLog}
            triggerNotification={notify}
          />
        </div>
      )}

      {/* Main Tab 3: 1099 Tax Tracker & Filing */}
      {activeTab === '1099-tracker' && (
        <div className="space-y-6">
          <W9And1099Tracker
            creators={creators}
            currentUser={currentUser}
            currentRole={currentRole}
            onAddActivityLog={onAddActivityLog || (() => {})}
            triggerNotification={notify || (() => {})}
          />
        </div>
      )}

      {/* Main Tab 4: Onboarding & W-9 Review Queue */}
      {activeTab === 'onboarding-queue' && (
        <div className="space-y-6">
          <div className="bg-[#142850] border border-white/5 rounded-3xl overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#0B1B3D]/70">
                    <th className="px-8 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Applicant Full Legal Name</th>
                    <th className="px-6 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Role</th>
                    <th className="px-6 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">Contractor Agreement</th>
                    <th className="px-6 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest">W-9 Form Status</th>
                    <th className="px-6 py-4 text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest text-right">Approval Gate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {onboardingQueue.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-8 py-20 text-center">
                        <CheckCircle className="w-8 h-8 text-emerald-500/40 mx-auto mb-3" />
                        <p className="text-white text-sm font-bold">All onboarding compliance records have been cleared.</p>
                        <p className="text-[#7C8AA8] text-xs mt-1">No pending contractor or tax clearance forms awaiting review.</p>
                      </td>
                    </tr>
                  ) : (
                    onboardingQueue.map((item) => (
                      <tr key={item.id} className="group hover:bg-white/[0.02] transition-colors">
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-[#0B1B3D] border border-white/10 rounded-full flex items-center justify-center text-[#D4AF37] font-bold">
                              {item.name[0]}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-white">{item.name}</p>
                              <p className="text-[10px] text-[#7C8AA8] flex items-center gap-1">
                                <Mail className="w-3 h-3" /> {item.email}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="px-6 py-5">
                          <span className="inline-flex px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-[10px] text-white/60 font-bold uppercase tracking-wider">
                            {item.role}
                          </span>
                        </td>

                        <td className="px-6 py-5">
                          <a 
                            href={getSafeUrl(item.agreementUrl || '#')} 
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 text-[10px] text-[#D4AF37] hover:text-[#E3C48F] font-bold underline transition-colors"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            [View Signed Agreement.pdf]
                          </a>
                        </td>

                        <td className="px-6 py-5">
                          {item.w9Url ? (
                            <a 
                              href={getSafeUrl(item.w9Url)} 
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 text-[10px] text-[#D4AF37] hover:text-[#E3C48F] font-bold underline transition-colors"
                            >
                              <Download className="w-3.5 h-3.5" />
                              [Download W-9.pdf]
                            </a>
                          ) : (
                            <span className="text-[10px] text-[#7C8AA8] font-bold italic">No W-9 on file</span>
                          )}
                        </td>

                        <td className="px-6 py-5 text-right">
                          <button 
                            onClick={() => handleApproveCompliance(item.id)}
                            disabled={processingId === item.id}
                            className="bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-500 px-4 py-2 rounded-xl text-[10px] font-bold transition-all inline-flex items-center gap-2 cursor-pointer"
                          >
                            {processingId === item.id ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <UserCheck className="w-3.5 h-3.5" />
                            )}
                            <span>Approve &amp; Activate</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Certificate of Digital Execution Inspection Modal */}
      {selectedUserForCert && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0B1B3D] border border-[#D4AF37]/40 rounded-3xl max-w-2xl w-full p-6 md:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setSelectedUserForCert(null)}
              className="absolute top-6 right-6 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#7C8AA8] hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Certificate Header */}
            <div className="flex items-center gap-4 border-b border-white/10 pb-5">
              <div className="p-3.5 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/30">
                <Award className="w-8 h-8 text-[#D4AF37]" />
              </div>
              <div>
                <span className="text-[10px] font-mono font-bold text-[#D4AF37] uppercase tracking-widest">
                  Official Record • Electronic Signature
                </span>
                <h3 className="text-xl font-serif font-bold text-white">Certificate of Legal Agreement Execution</h3>
              </div>
            </div>

            {/* Certificate Body Card */}
            <div className="bg-[#142850]/80 border border-white/10 rounded-2xl p-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-[10px] font-mono text-[#7C8AA8] uppercase">Signer Legal Name</span>
                  <p className="text-white font-bold mt-0.5">{selectedUserForCert.tosSignerName || selectedUserForCert.name}</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-[#7C8AA8] uppercase">Account Email</span>
                  <p className="text-white font-mono mt-0.5">{selectedUserForCert.email}</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-[#7C8AA8] uppercase">Agreement Title &amp; Version</span>
                  <p className="text-[#D4AF37] font-bold mt-0.5">Bloom Studio Master Terms of Service ({selectedUserForCert.tosVersion || 'v2026.1'})</p>
                </div>
                <div>
                  <span className="text-[10px] font-mono text-[#7C8AA8] uppercase">Execution Timestamp</span>
                  <p className="text-white font-mono mt-0.5">
                    {selectedUserForCert.tosSignedAt ? new Date(selectedUserForCert.tosSignedAt).toLocaleString() : 'On File'}
                  </p>
                </div>
              </div>

              {/* Cryptographic Proof */}
              <div className="border-t border-white/10 pt-4 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Cryptographic SHA-256 Digest (Verified &amp; Sealed)
                  </span>
                  <button
                    onClick={() => handleCopyDigest(selectedUserForCert.tosDigest || '', 'modal')}
                    className="text-[10px] font-mono text-[#D4AF37] hover:underline flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" /> Copy Hash
                  </button>
                </div>
                <div className="p-3 bg-[#081222] border border-white/5 rounded-xl text-[11px] font-mono text-slate-300 break-all">
                  {selectedUserForCert.tosDigest || `SHA256:VERIFIED:${selectedUserForCert.id}`}
                </div>
              </div>

              {/* Certified Legal Clauses Summary */}
              <div className="bg-[#081222]/50 p-3.5 rounded-xl border border-white/5 text-[11px] text-slate-400 space-y-1">
                <p className="font-bold text-slate-300">Enforced &amp; Executed Clauses:</p>
                <ul className="list-disc list-inside space-y-0.5 text-[10px]">
                  <li>Article 1: Master Agency &amp; SaaS Platform License (Bloom Studio OS)</li>
                  <li>Article 2: Talent Anti-Poaching, Non-Circumvention &amp; 30% Liquidated Damages</li>
                  <li>Article 3: Proprietary Source Code Ownership &amp; IP Protection</li>
                  <li>Article 4: Mandatory Dispute Arbitration &amp; Delaware Jurisdiction</li>
                </ul>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-mono">
                <CheckCircle2 className="w-4 h-4" />
                <span>Legally Binding Digital Audit Record</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    notify('Certificate Exported', 'Downloaded digital signature audit certificate PDF.', 'success');
                    setSelectedUserForCert(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition flex items-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Record</span>
                </button>
                <button
                  onClick={() => setSelectedUserForCert(null)}
                  className="px-5 py-2 rounded-xl bg-[#D4AF37] hover:bg-[#b08e58] text-[#0B1B3D] text-xs font-bold transition cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Security Protocol Footer Warning */}
      <div className="bg-[#0B1B3D] border border-white/10 rounded-3xl p-6 flex items-start gap-4">
        <div className="p-2.5 bg-blue-500/10 rounded-2xl border border-blue-500/20">
          <Lock className="w-5 h-5 text-blue-400" />
        </div>
        <div className="space-y-1">
          <h4 className="text-xs font-bold text-white uppercase tracking-widest">Administrative Compliance &amp; Multi-Tenant Scoping</h4>
          <p className="text-[11px] text-[#7C8AA8] leading-relaxed max-w-3xl">
            Legal agreements, signed Terms of Service records, and contractor W-9 documentation are cryptographically sealed in Firestore and audited per tenant pod. Electronic signatures recorded via this system fulfill standard ESIGN Act requirements.
          </p>
        </div>
      </div>
    </div>
  );
}
