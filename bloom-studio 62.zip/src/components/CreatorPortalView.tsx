import { OneTimeCreatorPortal } from "./OneTimeCreatorPortal";
import CreatorReferralTracker from './CreatorReferralTracker';
import React, { useState, useEffect, useRef } from 'react';
import { CreatorCastingMarketplace } from './CreatorCastingMarketplace';
import { 
  User, Mail, Phone, Tag, Link, Share2, Eye, EyeOff, Award, Shield, DollarSign, 
  MessageSquare, Save, CheckCircle, AlertCircle, Sparkles, Check, Globe,
  CreditCard, Wallet, Zap, Lock, CheckCircle2, Copy, ShieldCheck, Landmark,
  FileText, Download, Upload, FileCheck, ExternalLink, Package, Truck,
  Target, History, Megaphone, BookOpen, Briefcase, Bell, Clock, Play, Film, Star, X, Search, Filter, Edit3,
  Smartphone, TrendingUp, Users, Instagram, Camera, Layers, Video as VideoIcon, Youtube, ArrowUpRight
} from 'lucide-react';
import { Creator, RosterProfileSubmission, Mission, Referral } from '../types';
import { db } from '../lib/firebase';
import { doc, setDoc, collection, onSnapshot } from 'firebase/firestore';
import { useAgencyNiches } from '../lib/nicheConfig';
import { AgencyDebitCard } from './AgencyDebitCard';
import { generateOfficialW9Pdf, generateOfficial1099NecPdf } from '../lib/w9PdfGenerator';
import CreatorSampleFulfillmentTracker from './CreatorSampleFulfillmentTracker';
import CreatorProductSamplesInventory from './CreatorProductSamplesInventory';
import SubmitContent from './SubmitContent';
import PublicCreatorPortfolio from './PublicCreatorPortfolio';
import CreatorAssignedMissionsView from './CreatorAssignedMissionsView';
import CreatorDealBriefsView from './CreatorDealBriefsView';
import { Deal, ReviewItem } from '../types';
import { safeStorage } from '../utils/safeStorage';

interface CreatorPortalViewProps {
  currentUser: any;
  creators: Creator[];
  setCreators: (updater: any) => void;
  setActiveScreen: (screen: string) => void;
  triggerNotification: (title: string, message: string, type?: string) => void;
  onAddActivityLog: (user: string, role: string, action: string) => void;
  primaryBrandColor: string;
  cardBgColor: string;
  agencySchedules?: any[];
  setAgencySchedules?: React.Dispatch<React.SetStateAction<any[]>>;
  onRosterProfileSubmitted?: (submission: RosterProfileSubmission) => void;
  initialAnchor?: string;
  deals?: Deal[];
  missions?: Mission[];
  referrals?: Referral[];
  onAddReferral?: (ref: Referral) => void;
  onUpdateReferral?: (updatedRef: Referral) => Promise<void> | void;
  contentReviewsList?: ReviewItem[];
  onSaveReview?: (review: ReviewItem) => Promise<void> | void;
}

export const CreatorPortalView: React.FC<CreatorPortalViewProps> = ({
  currentUser,
  creators,
  setCreators,
  setActiveScreen,
  triggerNotification,
  onAddActivityLog,
  primaryBrandColor,
  cardBgColor,
  agencySchedules = [],
  setAgencySchedules,
  onRosterProfileSubmitted,
  initialAnchor,
  deals = [],
  missions = [],
  referrals = [],
  onAddReferral,
  onUpdateReferral,
  contentReviewsList = [],
  onSaveReview
}) => {
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (initialAnchor === 'creator-payouts' || initialAnchor === 'escrow' || initialAnchor === 'payouts' || initialAnchor === 'earnings') return 'escrow';
    if (initialAnchor === 'creator-deals' || initialAnchor === 'deals' || initialAnchor === 'my-deals') return 'deals';
    if (initialAnchor === 'creator-briefs') return 'briefs';
    if (initialAnchor === 'creator-inventory') return 'gifting';
    if (initialAnchor === 'creator-delivery') return 'fulfillment';
    if (initialAnchor === 'creator-financials') return 'profile';
    if (initialAnchor === 'submit-content') return 'submit-content';
    if (initialAnchor === 'my-content' || initialAnchor === 'content-library') return 'content-library';
    if (initialAnchor === 'my-portfolio' || initialAnchor === 'mediakit' || initialAnchor === 'media-kits') return 'my-portfolio';
    return 'profile';
  });

  React.useEffect(() => {
    if (initialAnchor === 'creator-payouts' || initialAnchor === 'escrow' || initialAnchor === 'payouts' || initialAnchor === 'earnings') setActiveTab('escrow');
    else if (initialAnchor === 'creator-deals' || initialAnchor === 'deals' || initialAnchor === 'my-deals') setActiveTab('deals');
    else if (initialAnchor === 'creator-briefs') setActiveTab('briefs');
    else if (initialAnchor === 'creator-inventory') setActiveTab('gifting');
    else if (initialAnchor === 'creator-delivery') setActiveTab('fulfillment');
    else if (initialAnchor === 'creator-dash' || initialAnchor === 'creator-financials') setActiveTab('profile');
    else if (initialAnchor === 'submit-content') setActiveTab('submit-content');
    else if (initialAnchor === 'my-content' || initialAnchor === 'content-library') setActiveTab('content-library');
    else if (initialAnchor === 'my-portfolio' || initialAnchor === 'mediakit' || initialAnchor === 'media-kits') setActiveTab('my-portfolio');
  }, [initialAnchor]);
  // Find matching creator record or fallback to currentUser values
  const myHandle = currentUser?.handle || '';
  const matchingCreator = creators.find(
    c => (myHandle && c.handle?.toLowerCase() === myHandle.toLowerCase()) ||
         c.id === currentUser?.id ||
         c.id === currentUser?.uid ||
         (currentUser?.email && c.email?.toLowerCase() === currentUser?.email?.toLowerCase())
  ) || creators[0] || {} as Creator;

  const { activeNiches, strictCoreOnly } = useAgencyNiches();

  // Normalize initial niche to core agency specialties (Pets, Beauty, Lifestyle)
  const getInitialNiche = (rawNiche?: string): string => {
    if (!rawNiche) return 'Pets';
    const lower = rawNiche.toLowerCase();
    if (lower.includes('pet') || lower.includes('animal') || lower.includes('dog') || lower.includes('cat')) return 'Pets';
    if (lower.includes('beauty') || lower.includes('skin') || lower.includes('cosmetic') || lower.includes('makeup')) return 'Beauty';
    if (lower.includes('life') || lower.includes('vlog') || lower.includes('fashion')) return 'Lifestyle';
    return strictCoreOnly ? 'Pets' : rawNiche;
  };

  // Editable Profile State - allowing email to be freely edited or cleared
  const [handle, setHandle] = useState(matchingCreator?.handle || currentUser?.handle || '');
  const [name, setName] = useState(matchingCreator?.name || currentUser?.name || 'My Profile');
  const [email, setEmail] = useState(matchingCreator?.email || '');
  const [phone, setPhone] = useState(matchingCreator?.phone || '');
  const [niche, setNiche] = useState(getInitialNiche(matchingCreator?.niche));
  const [secondaryInterests, setSecondaryInterests] = useState(matchingCreator?.secondaryInterests || 'Pet Wellness, Skincare, Lifestyle');
  const [tiktok, setTiktok] = useState(matchingCreator?.tiktok || '');
  const [instagram, setInstagram] = useState(matchingCreator?.instagram || '');
  const [youtube, setYoutube] = useState(matchingCreator?.youtube || '');
  const [bio, setBio] = useState(matchingCreator?.bio || 'Creator specializing in Pets, Beauty & Skincare, and Lifestyle.');

  // Phone/SMS Notification Signup & Toggle Config State
  const [showPhoneMessagesAlert, setShowPhoneMessagesAlert] = useState<boolean>(() => {
    return safeStorage.getItem('wl_show_phone_messages_alert') === 'true';
  });
  const [smsPhoneInput, setSmsPhoneInput] = useState<string>(phone || matchingCreator?.phone || '');
  const [smsCarrier, setSmsCarrier] = useState<string>('Verizon');
  const [isSmsSubscribed, setIsSmsSubscribed] = useState<boolean>(() => {
    return safeStorage.getItem(`wl_sms_registered_${handle || 'creator'}`) === 'true';
  });

  // Local Announcements State loaded from safeStorage
  const [creatorAnnouncements, setCreatorAnnouncements] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_announcements");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn("Failed to parse safeStorage announcements in CreatorPortalView", e);
    }
    return [
      {
        id: "an_default_1",
        title: "Q3 Brand Partnership Bonus Program Announced",
        content: "Creators completing 3+ UGC campaigns this month receive a 5% bonus on net payouts.",
        timestamp: "Today at 10:00 AM",
        category: "Executive Memo",
        sender: "Director & Leadership"
      },
      {
        id: "an_default_2",
        title: "FTC Mandatory Disclosure Updates for 2026",
        content: "Ensure all sponsored reels display #ad clearly in the first 3 caption lines before publishing.",
        timestamp: "Yesterday",
        category: "Compliance SOP",
        sender: "Legal Department"
      }
    ];
  });
  // Content Library & My Portfolio Interactive State
  const [previewVideoModal, setPreviewVideoModal] = useState<any | null>(null);
  const [editPortfolioModal, setEditPortfolioModal] = useState<boolean>(false);
  const [contentSearchQuery, setContentSearchQuery] = useState<string>('');
  const [contentPlatformFilter, setContentPlatformFilter] = useState<string>('All');

  // Rates & Social Stats state
  const [rateSingleReel, setRateSingleReel] = useState<string>('$1,500');
  const [rateBundle3, setRateBundle3] = useState<string>('$4,000');
  const [rateStorySet, setRateStorySet] = useState<string>('$1,500');
  const [rateSparkAds, setRateSparkAds] = useState<string>('$800');

  const [tiktokFollowers, setTiktokFollowers] = useState<string>(matchingCreator?.followers || '185K');
  const [instagramFollowers, setInstagramFollowers] = useState<string>('92K');
  const [youtubeSubscribers, setYoutubeSubscribers] = useState<string>('45K');
  const [engagementRate, setEngagementRate] = useState<string>(matchingCreator?.eng || '8.4%');
  const [avgVelocityViews, setAvgVelocityViews] = useState<string>('142.5K');

  // Avatar & Photo Upload
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const [avatarUrl, setAvatarUrl] = useState<string>(() => {
    return matchingCreator?.avatar || 
           safeStorage.getItem(`wl_avatar_${handle || 'creator'}`) ||
           'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80';
  });

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setAvatarUrl(dataUrl);
      safeStorage.setItem(`wl_avatar_${handle || 'creator'}`, dataUrl);
      triggerNotification('Profile Photo Updated', 'Your creator profile overview photo has been refreshed.', 'success');
      onAddActivityLog(name, 'creator', 'Updated creator profile photo');
    };
    reader.readAsDataURL(file);
  };

  // Dynamic Niche Matrix Parameters (Client-facing profile overview metadata matching CreatorProfileSummaryCard)
  const [skinTypeMatrix, setSkinTypeMatrix] = useState<string>(matchingCreator?.skinTypeMatrix || "Combination / Sensitive");
  const [skinTone, setSkinTone] = useState<string>(matchingCreator?.skinTone || "Neutral Cool (Fitzpatrick II)");
  const [hairMatrix, setHairMatrix] = useState<string>(matchingCreator?.hairMatrix || "Type 2B Wavy / Color-Treated");

  const [petBreedMetrics, setPetBreedMetrics] = useState<string>(matchingCreator?.petBreedMetrics || "Golden Retriever / Purebred");
  const [petAgeWeight, setPetAgeWeight] = useState<string>(matchingCreator?.petAgeWeight || "3.5 Years • 64 lbs");
  const [petDietCategory, setPetDietCategory] = useState<string>(matchingCreator?.petDietCategory || "Organic Raw / Grain-Free");

  const [aestheticMatrix, setAestheticMatrix] = useState<string>(matchingCreator?.aestheticMatrix || "Warm Minimalist / Nordic");
  const [lightingStyle, setLightingStyle] = useState<string>(matchingCreator?.lightingStyle || "Natural Golden Hour (5600K)");
  const [colorStory, setColorStory] = useState<string>(matchingCreator?.colorStory || "Earthy Terracotta & Cream");

  const [profileViewMode, setProfileViewMode] = useState<'card' | 'edit'>('card');


  // Tax & Legal Documents (W-9 & 1099-NEC) State
  const initialW9Records = (() => {
    try {
      const saved = safeStorage.getItem('wl_w9_records');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  })();
  const existingW9 = initialW9Records.find((r: any) => (r.creator || '').toLowerCase() === handle.toLowerCase() || (r.realName || '').toLowerCase() === name.toLowerCase());

  const [w9Uploaded, setW9Uploaded] = useState<boolean>(
    Boolean(matchingCreator?.w9Uploaded || matchingCreator?.w9Status === 'Verified' || matchingCreator?.w9Status === 'Submitted' || existingW9)
  );
  const [w9FileName, setW9FileName] = useState<string>(
    matchingCreator?.w9FileName || existingW9?.fileName || 'IRS_Form_W9_Signed.pdf'
  );
  const [w9FileSize, setW9FileSize] = useState<string>(
    matchingCreator?.w9FileSize || existingW9?.fileSize || '148 KB'
  );
  const [w9Status, setW9Status] = useState<string>(
    matchingCreator?.w9Status || existingW9?.w9Status || 'Verified'
  );
  const [taxIdStatus, setTaxIdStatus] = useState<string>(
    matchingCreator?.taxIdStatus || existingW9?.taxIdStatus || 'Verified'
  );
  const [w9FileData, setW9FileData] = useState<string>(
    matchingCreator?.w9FileUrl || existingW9?.fileData || ''
  );

  // Synchronize W-9 compliance document in real-time from Firestore
  useEffect(() => {
    if (!db || !handle) return;
    const cleanHandle = handle.replace(/[@.]/g, '_');
    const w9DocId = `w9_${cleanHandle}`;
    const unsub = onSnapshot(doc(db, 'studio-w9-forms', w9DocId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.w9Status) setW9Status(data.w9Status);
        if (data.fileName) setW9FileName(data.fileName);
        if (data.fileSize) setW9FileSize(data.fileSize);
        if (data.fileData) setW9FileData(data.fileData);
        if (data.taxIdStatus) setTaxIdStatus(data.taxIdStatus);
        if (data.w9Status === 'Verified' || data.w9Status === 'Submitted') {
          setW9Uploaded(true);
        }
      }
    }, (err) => {
      console.warn('W-9 doc subscription notice:', err);
    });
    return () => unsub();
  }, [handle]);

  const [tax1099Uploaded, setTax1099Uploaded] = useState<boolean>(
    Boolean(matchingCreator?.tax1099Uploaded || matchingCreator?.status1099 === 'Filed & Sent' || matchingCreator?.status1099 === 'Ready to File')
  );
  const [tax1099FileName, setTax1099FileName] = useState<string>(
    matchingCreator?.tax1099FileName || 'Form_1099_NEC_Annual_Statement.pdf'
  );
  const [tax1099FileSize, setTax1099FileSize] = useState<string>(
    matchingCreator?.tax1099FileSize || '94 KB'
  );
  const [tax1099Status, setTax1099Status] = useState<string>(
    matchingCreator?.status1099 || 'Filed & Sent'
  );
  
  // Content & Brand Preferences State
  const [preferredBrands, setPreferredBrands] = useState(matchingCreator?.preferredBrands || 'Petco, Sephora, Glossier, Chewy, Luxury Pet & Skincare Brands');
  const [excludedBrands, setExcludedBrands] = useState(matchingCreator?.excludedBrands || 'Gambling, Tobacco, Fast Fashion, Pay-day Loans, Unverified Crypto');
  const [contentPreferences, setContentPreferences] = useState(matchingCreator?.contentPreferences || 'TikTok Shorts, IG Reels, Dedicated YouTube Integrations, Story Carousels');

  // Payout & Payment Method State (Direct Deposit ACH, Agency Debit Card, PayPal)
  const initialMethod = matchingCreator?.paymentMethod === 'Zelle' ? 'Agency Debit Card' : (matchingCreator?.paymentMethod || 'Direct Deposit');
  const [paymentMethod, setPaymentMethod] = useState<string>(initialMethod);
  const [paymentDetails, setPaymentDetails] = useState(matchingCreator?.paymentDetails || matchingCreator?.email || 'alex@bloom.co');
  const [paymentNote, setPaymentNote] = useState(matchingCreator?.paymentNote || '');

  // Direct Deposit ACH States
  const [bankName, setBankName] = useState(matchingCreator?.bankName || 'JPMorgan Chase');
  const [routingNumber, setRoutingNumber] = useState(matchingCreator?.routingNumber || '122105155');
  const [accountNumber, setAccountNumber] = useState(matchingCreator?.accountNumber || '8849201934');
  const [accountType, setAccountType] = useState<'Checking' | 'Savings'>(matchingCreator?.accountType || 'Checking');
  const [showAccountMask, setShowAccountMask] = useState(true);

  // Stripe Agency Debit Card States
  const [stripeCardLast4, setStripeCardLast4] = useState(matchingCreator?.stripeCardLast4 || '4242');
  const [stripeCardStatus, setStripeCardStatus] = useState(matchingCreator?.stripeCardStatus || 'Active');
  const [stripeCardBrand, setStripeCardBrand] = useState(matchingCreator?.stripeCardBrand || 'Visa');
  const [stripeCardExpiry, setStripeCardExpiry] = useState(matchingCreator?.stripeCardExpiry || '08/29');
  const [stripeCardType, setStripeCardType] = useState(matchingCreator?.stripeCardType || 'Virtual & Physical');
  const [cardholderLegalName, setCardholderLegalName] = useState(matchingCreator?.name || currentUser?.name || 'Alex Jones');

  // Derive overall availability status and quarterly availability from the availability calendar
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const myAvailEvents = (agencySchedules || []).filter(evt =>
    (evt.type === 'availability' || !evt.type) &&
    (
      (evt.creator && evt.creator.toLowerCase() === myHandle.toLowerCase()) ||
      (evt.title && evt.title.toLowerCase().includes(myHandle.toLowerCase())) ||
      (!evt.creator && !evt.title?.includes('@'))
    )
  );

  // Helper: check months for quarter
  const getQuarterStatus = (qIndex: number): 'Available' | 'Limited' | 'Booked' => {
    const months = qIndex === 1 ? [0, 1, 2] : qIndex === 2 ? [3, 4, 5] : qIndex === 3 ? [6, 7, 8] : [9, 10, 11];
    const qEvents = myAvailEvents.filter(evt => {
      const evtM = evt.month !== undefined ? evt.month : currentMonth;
      const evtY = evt.year !== undefined ? evt.year : currentYear;
      return evtY === currentYear && months.includes(evtM);
    });
    if (qEvents.some(e => e.status === 'Booked' || e.title?.toLowerCase().includes('booked'))) {
      return 'Booked';
    }
    if (qEvents.some(e => e.status === 'Limited' || e.title?.toLowerCase().includes('limited') || e.title?.toLowerCase().includes('busy'))) {
      return 'Limited';
    }
    const savedQ = qIndex === 1 ? matchingCreator?.q1Availability :
                   qIndex === 2 ? matchingCreator?.q2Availability :
                   qIndex === 3 ? matchingCreator?.q3Availability :
                   matchingCreator?.q4Availability;
    return savedQ || 'Available';
  };

  const q1Status = getQuarterStatus(1);
  const q2Status = getQuarterStatus(2);
  const q3Status = getQuarterStatus(3);
  const q4Status = getQuarterStatus(4);

  // Current Overall Status reads from calendar for current quarter
  const currentQuarterIndex = Math.floor(currentMonth / 3) + 1;
  const currentQStatus = getQuarterStatus(currentQuarterIndex);
  const derivedAvailabilityStatus = currentQStatus === 'Booked' ? 'Booked' :
                                    currentQStatus === 'Limited' ? 'Limited Availability' :
                                    'Available Now';

  const handleSetQuarterAvailability = (qNum: 1 | 2 | 3 | 4, newStatus: 'Available' | 'Limited' | 'Booked') => {
    // 1. Update creator profile record
    const fieldName = qNum === 1 ? 'q1Availability' : qNum === 2 ? 'q2Availability' : qNum === 3 ? 'q3Availability' : 'q4Availability';
    setCreators((prev: Creator[]) => prev.map(c => 
      (c.handle?.toLowerCase() === myHandle.toLowerCase() || c.id === matchingCreator?.id)
        ? { ...c, [fieldName]: newStatus }
        : c
    ));

    // 2. Sync with Availability Calendar
    if (setAgencySchedules) {
      const months = qNum === 1 ? [0, 1, 2] : qNum === 2 ? [3, 4, 5] : qNum === 3 ? [6, 7, 8] : [9, 10, 11];
      setAgencySchedules(prev => {
        // Filter out existing quarter entries for this creator in these months
        const filtered = prev.filter(e => {
          const m = e.month !== undefined ? e.month : currentMonth;
          const y = e.year !== undefined ? e.year : currentYear;
          const isMyEntry = (e.creator?.toLowerCase() === myHandle.toLowerCase()) || (e.title?.toLowerCase().includes(myHandle.toLowerCase()));
          return !(isMyEntry && y === currentYear && months.includes(m) && e.type === 'availability');
        });

        if (newStatus === 'Available') {
          return filtered;
        }

        // Add calendar entries for those months
        const newEntries = months.map(m => ({
          id: 'avail_q' + qNum + '_' + m + '_' + Date.now() + Math.random().toString(36).substring(2, 6),
          title: `${myHandle} (${newStatus})`,
          type: 'availability',
          month: m,
          year: currentYear,
          dayNum: 1,
          status: newStatus,
          creator: myHandle,
          subagency: matchingCreator?.subagency || 'Main Agency'
        }));

        return [...filtered, ...newEntries];
      });
    }

    triggerNotification('Quarterly Availability Synced', `Updated Q${qNum} availability to "${newStatus}" and synced with Availability Calendar.`, 'success');
    onAddActivityLog(name, 'creator', `Updated Q${qNum} quarterly availability to ${newStatus}`);
  };

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // 1099 & W-9 Paper Fill Out & Turn In State
  const [showTaxPaperModal, setShowTaxPaperModal] = useState(false);
  const [taxPaperForm, setTaxPaperForm] = useState({
    legalName: matchingCreator?.name || currentUser?.name || 'Alex Jones',
    businessName: `${matchingCreator?.name || 'Alex Jones'} Productions`,
    taxClassification: 'Individual / Sole Proprietor',
    tinType: 'SSN' as 'SSN' | 'EIN',
    tinNumber: '123-45-6789',
    address: '9420 Wilshire Blvd, Suite 800',
    cityStateZip: 'Beverly Hills, CA 90212',
    taxYear: currentYear.toString(),
    signatureName: matchingCreator?.name || currentUser?.name || 'Alex Jones',
    confirmPerjury: true
  });
  const [isSubmittingTaxPaper, setIsSubmittingTaxPaper] = useState(false);

  // Real-time synchronization of tax compliance documents from Firestore studio-w9-forms
  useEffect(() => {
    if (!db) return;
    const cleanHandle = handle.replace(/[@.]/g, '_');
    const w9DocId = `w9_${cleanHandle}`;
    const unsub = onSnapshot(doc(db, 'studio-w9-forms', w9DocId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.w9Status) setW9Status(data.w9Status);
        if (data.taxIdStatus) setTaxIdStatus(data.taxIdStatus);
        if (data.fileName) setW9FileName(data.fileName);
        if (data.fileSize) setW9FileSize(data.fileSize);
        if (data.w9Status === 'Verified' || data.w9Status === 'Submitted') setW9Uploaded(true);
        if (data.status1099) setTax1099Status(data.status1099);
      }
    }, (err) => {
      console.warn('Could not listen to creator w9 status:', err);
    });
    return () => unsub();
  }, [handle]);

  // Read-only agency-set fields
  const assignedCoordinator = matchingCreator?.assignedAgent || 'Marcus Cole';
  const tier = matchingCreator?.tier || 'Gold Certified Tier';
  const commissionSplit = matchingCreator?.commissionSplit || '80/20 Creator/Agency Split';

  // Submit & Turn In Tax Paper to Agency Accounting
  const handleSubmitTaxPaper = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingTaxPaper(true);

    try {
      // 1. Generate filled official vector PDF
      const pdfResult = await generateOfficialW9Pdf({
        legalName: taxPaperForm.legalName,
        businessName: taxPaperForm.businessName,
        taxClassification: taxPaperForm.taxClassification,
        address: taxPaperForm.address,
        cityStateZip: taxPaperForm.cityStateZip,
        tinType: taxPaperForm.tinType,
        tinNumber: taxPaperForm.tinNumber,
        signatureName: taxPaperForm.signatureName,
        dateSigned: new Date().toISOString().split('T')[0],
        creatorHandle: handle
      });

      const fileName = `IRS_Tax_Form_${taxPaperForm.tinType}_${handle.replace('@', '')}_Signed.pdf`;
      const sizeStr = '164 KB';

      setW9Uploaded(true);
      setW9FileName(fileName);
      setW9FileSize(sizeStr);
      setW9FileData(pdfResult.dataUrl);
      setW9Status('Submitted');
      setTaxIdStatus('Submitted for Review');

      setTax1099Uploaded(true);
      setTax1099FileName(`Form_1099_Tax_Intake_${handle.replace('@', '')}.pdf`);
      setTax1099FileSize('112 KB');
      setTax1099Status('Turned In & On File');

      // 2. Persist safe metadata to localStorage records (never unencrypted raw SSN or file payload)
      const record = {
        id: `tax_${handle.replace(/[@.]/g, '_')}_${Date.now()}`,
        creator: handle,
        realName: taxPaperForm.legalName,
        businessName: taxPaperForm.businessName,
        taxClassification: taxPaperForm.taxClassification,
        tinType: taxPaperForm.tinType,
        tinNumberMasked: taxPaperForm.tinNumber.replace(/\d(?=\d{4})/g, "*"),
        address: taxPaperForm.address,
        cityStateZip: taxPaperForm.cityStateZip,
        signatureName: taxPaperForm.signatureName,
        taxIdStatus: 'Submitted for Review',
        w9Status: 'Submitted',
        status1099: 'Turned In & On File',
        fileName: fileName,
        fileSize: sizeStr,
        submittedAt: new Date().toISOString(),
        auditStatus: 'Turned In to Agency Accounting'
      };

      try {
        const existing = JSON.parse(safeStorage.getItem('wl_w9_records') || '[]');
        const filtered = existing.filter((item: any) => (item.creator || '').toLowerCase() !== handle.toLowerCase());
        safeStorage.setItem('wl_w9_records', JSON.stringify([record, ...filtered]));

        const existing1099 = JSON.parse(safeStorage.getItem('wl_1099_records') || '[]');
        const filtered1099 = existing1099.filter((item: any) => (item.creator || '').toLowerCase() !== handle.toLowerCase());
        safeStorage.setItem('wl_1099_records', JSON.stringify([record, ...filtered1099]));
      } catch (err) {
        console.warn('safeStorage error', err);
      }

      // 3. Write to PII-protected studio-w9-forms and studio-creators in Firestore
      try {
        const cleanHandle = handle.replace(/[@.]/g, '_');
        const docId = matchingCreator?.id || 'creator_' + cleanHandle;
        const w9DocId = `w9_${cleanHandle}`;

        // Save formal W-9 tax record to protected collection
        await setDoc(doc(db, 'studio-w9-forms', w9DocId), {
          id: w9DocId,
          creator: handle,
          creatorId: docId,
          creatorHandle: handle,
          realName: taxPaperForm.legalName,
          businessName: taxPaperForm.businessName,
          taxClassification: taxPaperForm.taxClassification,
          tinType: taxPaperForm.tinType,
          tinNumberMasked: taxPaperForm.tinNumber.replace(/\d(?=\d{4})/g, "*"),
          address: taxPaperForm.address,
          cityStateZip: taxPaperForm.cityStateZip,
          signatureName: taxPaperForm.signatureName,
          taxIdStatus: 'Submitted for Review',
          w9Status: 'Submitted',
          status1099: 'Pending Filing',
          fileName: fileName,
          fileSize: sizeStr,
          fileData: pdfResult.dataUrl,
          fileUrl: pdfResult.dataUrl,
          storageUrl: pdfResult.dataUrl,
          documentType: 'W-9',
          submittedAt: new Date().toISOString(),
          uploadedAt: new Date().toISOString(),
          auditStatus: 'Submitted for Agency Accounting Review'
        }, { merge: true });

        // Update creator document metadata
        const docRef = doc(db, 'studio-creators', docId);
        await setDoc(docRef, {
          w9Uploaded: true,
          w9Status: 'Submitted',
          taxIdStatus: 'Submitted for Review',
          w9FileName: fileName,
          w9FileSize: sizeStr,
          w9FileUrl: pdfResult.dataUrl,
          tax1099Uploaded: true,
          status1099: 'Pending Filing',
          taxPaperTurnedInAt: new Date().toISOString(),
          taxPaperLegalName: taxPaperForm.legalName,
          taxPaperClassification: taxPaperForm.taxClassification
        }, { merge: true });
      } catch (err) {
        console.warn('Firestore write warning:', err);
      }

      setIsSubmittingTaxPaper(false);
      setShowTaxPaperModal(false);

      triggerNotification(
        '✓ Tax Paper Turned In Successfully',
        `Your signed tax paperwork for ${taxPaperForm.legalName} has been turned in to Bloom & Co. Agency Accounting.`,
        'success'
      );

      onAddActivityLog(
        name,
        'creator',
        `Filled out and turned in signed 1099 / W-9 Tax Certification Paperwork to Agency Accounting`
      );
    } catch (err) {
      console.error('Error submitting tax paper:', err);
      setIsSubmittingTaxPaper(false);
      triggerNotification('Submission Issue', 'Paperwork submitted locally. Downloading copy for your records.', 'info');
      setShowTaxPaperModal(false);
    }
  };

  // Download blank official IRS Form W-9
  const handleDownloadBlankW9 = () => {
    window.open('https://www.irs.gov/pub/irs-pdf/fw9.pdf', '_blank', 'noopener,noreferrer');
    triggerNotification('Downloading Form W-9', 'Opening official IRS Form W-9 from IRS.gov', 'info');
  };

  // Download blank official IRS Form 1099-NEC
  const handleDownloadBlank1099 = () => {
    window.open('https://www.irs.gov/pub/irs-pdf/f1099nec.pdf', '_blank', 'noopener,noreferrer');
    triggerNotification('Downloading Form 1099-NEC', 'Opening official IRS Form 1099-NEC from IRS.gov', 'info');
  };

  // Generate & Download pre-filled W-9 PDF
  const handleGenerateFilledW9 = async () => {
    try {
      await generateOfficialW9Pdf({
        legalName: name || 'Creator Name',
        businessName: `${name} Productions`,
        taxClassification: 'Individual / Sole Proprietor',
        address: '123 Creator Blvd',
        cityStateZip: 'Los Angeles, CA 90028',
        tinType: 'SSN',
        tinNumber: '***-**-6789',
        signatureName: name || 'Creator Name',
        dateSigned: new Date().toISOString().split('T')[0],
        creatorHandle: handle
      });
      triggerNotification('Form W-9 Generated', `Pre-filled Form W-9 generated for ${name}`, 'success');
      onAddActivityLog(name, 'creator', 'Generated and downloaded pre-filled IRS Form W-9');
    } catch (e) {
      console.error(e);
      window.open('https://www.irs.gov/pub/irs-pdf/fw9.pdf', '_blank');
    }
  };

  // Generate & Download pre-filled 1099-NEC PDF
  const handleGenerateFilled1099 = async () => {
    try {
      await generateOfficial1099NecPdf({
        payerName: 'Bloom & Co. Talent Agency LLC',
        payerTin: '88-9281749',
        payerAddress: '9000 Sunset Blvd, Suite 1400',
        payerCityStateZip: 'West Hollywood, CA 90069',
        recipientName: name || 'Creator Name',
        recipientHandle: handle,
        recipientTin: '***-**-6789',
        recipientAddress: '123 Creator Blvd',
        recipientCityStateZip: 'Los Angeles, CA 90028',
        nonemployeeCompensation: matchingCreator?.totalEarned || 18500,
        federalTaxWithheld: 0,
        taxYear: currentYear
      });
      triggerNotification('1099-NEC Generated', `Form 1099-NEC statement generated for ${name}`, 'success');
      onAddActivityLog(name, 'creator', 'Generated and downloaded Form 1099-NEC annual tax statement');
    } catch (e) {
      console.error(e);
      window.open('https://www.irs.gov/pub/irs-pdf/f1099nec.pdf', '_blank');
    }
  };

  // Upload W-9 file handler
  const handleW9FileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      const sizeStr = `${(file.size / 1024).toFixed(1)} KB`;
      setW9Uploaded(true);
      setW9FileName(file.name);
      setW9FileSize(sizeStr);
      setW9FileData(dataUrl);
      setW9Status('Submitted');
      setTaxIdStatus('Submitted for Review');

      const cleanHandle = handle.replace(/[@.]/g, '_');
      const w9DocId = `w9_${cleanHandle}`;
      const docId = matchingCreator?.id || 'creator_' + cleanHandle;

      // 1. Write full tax document to PII-protected studio-w9-forms collection in Firestore
      try {
        await setDoc(doc(db, 'studio-w9-forms', w9DocId), {
          id: w9DocId,
          creator: handle,
          creatorId: docId,
          creatorHandle: handle,
          realName: name,
          taxIdStatus: 'Submitted for Review',
          w9Status: 'Submitted',
          earnings1099: matchingCreator?.totalEarned || 0,
          status1099: 'Pending Filing',
          fileName: file.name,
          fileSize: sizeStr,
          fileData: dataUrl,
          documentType: 'W-9',
          uploadedAt: new Date().toISOString(),
          auditStatus: 'Submitted for Agency Compliance Verification'
        }, { merge: true });
      } catch (err) {
        console.warn('Firestore studio-w9-forms write warning:', err);
      }

      // 2. Safe metadata-only cache in localStorage (NEVER raw fileData/PII in localStorage)
      const w9RecordMeta = {
        id: w9DocId,
        creator: handle,
        realName: name,
        taxIdStatus: 'Submitted for Review',
        w9Status: 'Submitted',
        earnings1099: matchingCreator?.totalEarned || 0,
        status1099: 'Pending Filing',
        fileName: file.name,
        fileSize: sizeStr,
        uploadedAt: new Date().toISOString()
      };
      try {
        const existing = JSON.parse(safeStorage.getItem('wl_w9_records') || '[]');
        const filtered = existing.filter((item: any) => (item.creator || '').toLowerCase() !== handle.toLowerCase());
        safeStorage.setItem('wl_w9_records', JSON.stringify([w9RecordMeta, ...filtered]));
      } catch (err) {
        console.warn('safeStorage error', err);
      }

      // 3. Update creator document metadata
      try {
        const docRef = doc(db, 'studio-creators', docId);
        await setDoc(docRef, {
          w9Uploaded: true,
          w9Status: 'Submitted',
          taxIdStatus: 'Submitted for Review',
          w9FileName: file.name,
          w9FileSize: sizeStr,
          w9UploadedAt: new Date().toISOString()
        }, { merge: true });
      } catch (err) {
        console.warn('Firestore write warning:', err);
      }

      triggerNotification('W-9 Uploaded Successfully', `${file.name} uploaded and submitted for agency compliance verification.`, 'success');
      onAddActivityLog(name, 'creator', `Uploaded signed Form W-9 tax document: ${file.name}`);
    };
    reader.readAsDataURL(file);
  };

  // Upload 1099 file handler
  const handle1099FileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      const sizeStr = `${(file.size / 1024).toFixed(1)} KB`;
      setTax1099Uploaded(true);
      setTax1099FileName(file.name);
      setTax1099FileSize(sizeStr);
      setTax1099Status('Filed & Sent');

      const cleanHandle = handle.replace(/[@.]/g, '_');
      const docId1099 = `1099_${cleanHandle}`;
      const docId = matchingCreator?.id || 'creator_' + cleanHandle;

      // 1. Write document to PII-protected studio-w9-forms in Firestore
      try {
        await setDoc(doc(db, 'studio-w9-forms', docId1099), {
          id: docId1099,
          creator: handle,
          creatorId: docId,
          creatorHandle: handle,
          realName: name,
          status1099: 'Filed & Sent',
          documentType: '1099-NEC',
          fileName: file.name,
          fileSize: sizeStr,
          fileData: dataUrl,
          uploadedAt: new Date().toISOString(),
          auditStatus: 'Filed & Sent to Talent'
        }, { merge: true });
      } catch (err) {
        console.warn('Firestore studio-w9-forms write warning:', err);
      }

      // 2. Safe metadata-only cache in localStorage (NEVER raw fileData in localStorage)
      const record1099Meta = {
        id: docId1099,
        creator: handle,
        realName: name,
        status1099: 'Filed & Sent',
        fileName: file.name,
        fileSize: sizeStr,
        uploadedAt: new Date().toISOString()
      };
      try {
        const existing = JSON.parse(safeStorage.getItem('wl_1099_records') || '[]');
        const filtered = existing.filter((item: any) => (item.creator || '').toLowerCase() !== handle.toLowerCase());
        safeStorage.setItem('wl_1099_records', JSON.stringify([record1099Meta, ...filtered]));
      } catch (err) {
        console.warn('safeStorage error', err);
      }

      // 3. Update creator document metadata
      try {
        const docRef = doc(db, 'studio-creators', docId);
        await setDoc(docRef, {
          tax1099Uploaded: true,
          status1099: 'Filed & Sent',
          tax1099FileName: file.name,
          tax1099FileSize: sizeStr,
          tax1099UploadedAt: new Date().toISOString()
        }, { merge: true });
      } catch (err) {
        console.warn('Firestore write warning:', err);
      }

      triggerNotification('1099 Document Uploaded', `${file.name} uploaded and archived in tax records.`, 'success');
      onAddActivityLog(name, 'creator', `Uploaded Form 1099-NEC tax statement: ${file.name}`);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);

    const computedPaymentDetails = paymentMethod === 'Direct Deposit'
      ? `${bankName || 'Direct Deposit'} (Routing: •••••${routingNumber.slice(-4) || '••••'}, Acct: ••••${accountNumber.slice(-4) || '••••'})`
      : paymentMethod === 'Agency Debit Card'
      ? `Agency Visa Debit (•••• ${stripeCardLast4}) - Stripe Issuing`
      : paymentMethod === 'Other'
      ? 'Contact agency directly'
      : paymentDetails;

    const updatedData: Creator = {
      ...matchingCreator,
      handle,
      name,
      email: email || '',
      phone,
      niche,
      secondaryInterests,
      tiktok,
      instagram,
      youtube,
      bio,
      avatar: avatarUrl,
      followers: tiktokFollowers,
      eng: engagementRate,
      skinTypeMatrix,
      skinTone,
      hairMatrix,
      petBreedMetrics,
      petAgeWeight,
      petDietCategory,
      aestheticMatrix,
      lightingStyle,
      colorStory,
      ftcComplianceVerified: true,
      copyrightClearanceActive: true,
      preferredBrands,
      excludedBrands,
      contentPreferences,
      availability: derivedAvailabilityStatus,
      paymentMethod,
      paymentDetails: computedPaymentDetails,
      paymentNote,
      bankName,
      routingNumber,
      accountNumber,
      accountType,
      stripeCardholderId: matchingCreator?.stripeCardholderId || `ich_${handle.replace('@', '')}_card`,
      stripeCardId: matchingCreator?.stripeCardId || `ic_${handle.replace('@', '')}_01`,
      stripeCardLast4,
      stripeCardStatus,
      stripeCardBrand,
      stripeCardExpiry,
      stripeCardType,
      w9Uploaded,
      w9Status,
      taxIdStatus,
      w9FileName,
      w9FileSize,
      tax1099Uploaded,
      status1099: tax1099Status,
      tax1099FileName,
      tax1099FileSize
    };

    const submissionId = 'sub_' + (matchingCreator?.id || handle.replace('@', '')) + '_' + Date.now();
    const nowIso = new Date().toISOString();
    const submissionRecord: RosterProfileSubmission = {
      id: submissionId,
      creatorId: matchingCreator?.id || 'creator_' + handle.replace('@', ''),
      creatorName: name,
      creatorHandle: handle,
      email,
      phone,
      platform: matchingCreator?.platform || 'TikTok & IG',
      niche,
      secondaryInterests,
      bio,
      tiktok,
      instagram,
      youtube,
      preferredBrands,
      excludedBrands,
      contentPreferences,
      availability: derivedAvailabilityStatus,
      paymentMethod,
      paymentDetails: computedPaymentDetails,
      cardholderLegalName,
      stripeCardLast4,
      stripeCardStatus,
      stripeCardExpiry,
      paymentNote,
      tier,
      assignedAgent: assignedCoordinator,
      assignedCoordinator,
      assignedManager: matchingCreator?.assignedManager || 'Senior Agent Manager',
      submittedAt: `Today at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      timestamp: Date.now(),
      status: 'Pending Review',
      targetAudience: 'Director, Agent & Agent Managers'
    };

    // 1. Update local creator record
    if (setCreators && matchingCreator?.id) {
      setCreators((prev: Creator[]) =>
        prev.map(c => c.id === matchingCreator.id ? { ...c, ...updatedData } : c)
      );
    }

    // 2. Persist Roster Profile Submission to safeStorage
    try {
      const existingSaved = safeStorage.getItem('wl_roster_profile_submissions');
      const existingList: RosterProfileSubmission[] = existingSaved ? JSON.parse(existingSaved) : [];
      const updatedList = [
        submissionRecord,
        ...existingList.filter(s => s.creatorHandle.toLowerCase() !== handle.toLowerCase())
      ];
      safeStorage.setItem('wl_roster_profile_submissions', JSON.stringify(updatedList));
    } catch (e) {
      console.warn('Failed to save to wl_roster_profile_submissions safeStorage:', e);
    }

    // 3. Save to Firestore (both studio-creators and studio-roster-submissions)
    try {
      const docId = matchingCreator?.id || 'creator_' + handle.replace('@', '');
      const docRef = doc(db, 'studio-creators', docId);
      await setDoc(docRef, updatedData, { merge: true });

      const subRef = doc(db, 'studio-roster-submissions', submissionId);
      await setDoc(subRef, submissionRecord, { merge: true });
    } catch (err) {
      console.error("Firestore write failed (expected while security rules are staff-only):", err);
    }

    if (onRosterProfileSubmitted) {
      onRosterProfileSubmitted(submissionRecord);
    }

    setIsSaving(false);
    setSaveSuccess(true);

    // Multi-role notification dispatch to Director, Agent & Agent Managers
    triggerNotification(
      '📋 Profile Dispatched to Leadership',
      `Your profile & brand collaboration preferences for ${name} (${handle}) have been delivered to the Director, assigned Agent (${assignedCoordinator}), and Agent Managers.`,
      'success'
    );

    onAddActivityLog(
      name,
      'creator',
      `Submitted updated creator profile & brand preferences (Dispatched to Director, Agent & Agent Managers for roster review)`
    );

    setTimeout(() => {
      setSaveSuccess(false);
    }, 5000);
  };

  const renderNicheMatrixCards = () => {
    const nicheLower = (niche || '').toLowerCase();

    if (nicheLower.includes('beauty') || nicheLower.includes('cosmetic')) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Skin Type Matrix
            </span>
            <span className="text-sm font-semibold text-white block">
              {skinTypeMatrix}
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">Sensitivity &amp; Hydration Profile</span>
          </div>
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Tone &amp; Undertone
            </span>
            <span className="text-sm font-semibold text-white block">
              {skinTone}
            </span>
            <span className="text-[10px] text-[#C9A46A] font-mono">Camera Lighting Baseline</span>
          </div>
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Hair Matrix
            </span>
            <span className="text-sm font-semibold text-white block">
              {hairMatrix}
            </span>
            <span className="text-[10px] text-purple-400 font-mono">Texture &amp; Treatment Profile</span>
          </div>
        </div>
      );
    }

    if (nicheLower.includes('pet') || nicheLower.includes('dog') || nicheLower.includes('cat')) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Pet Breed Metrics
            </span>
            <span className="text-sm font-semibold text-white block">
              {petBreedMetrics}
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">Verified Companion Spec</span>
          </div>
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Age &amp; Weight Matrix
            </span>
            <span className="text-sm font-semibold text-white block">
              {petAgeWeight}
            </span>
            <span className="text-[10px] text-[#C9A46A] font-mono">Sizing &amp; Life Stage</span>
          </div>
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Dietary Profile
            </span>
            <span className="text-sm font-semibold text-white block">
              {petDietCategory}
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">Treat &amp; Nutrition Compatibility</span>
          </div>
        </div>
      );
    }

    // Default Lifestyle Matrix
    return (
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
            Aesthetic Matrix
          </span>
          <span className="text-sm font-semibold text-white block">
            {aestheticMatrix}
          </span>
          <span className="text-[10px] text-cyan-400 font-mono">Interior &amp; Wardrobe Tone</span>
        </div>
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
            Lighting Style
          </span>
          <span className="text-sm font-semibold text-white block">
            {lightingStyle}
          </span>
          <span className="text-[10px] text-[#C9A46A] font-mono">Color Temperature Baseline</span>
        </div>
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-1">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
            Color Palette
          </span>
          <span className="text-sm font-semibold text-white block">
            {colorStory}
          </span>
          <span className="text-[10px] text-purple-400 font-mono">Production Color Harmony</span>
        </div>
      </div>
    );
  };
  
  // 2. NON-EXCLUSIVE ROSTER CONSTANTS: BYPASS STANDARD DASHBOARD
  if (currentUser?.rosterType === "Non_Exclusive") {
    return (
      <OneTimeCreatorPortal
        currentUser={currentUser}
        currentRole="creator"
        onAddActivityLog={onAddActivityLog}
        triggerNotification={triggerNotification}
      />
    );
  }

return (
    <div className="space-y-6 animate-fade-in bg-[#0A1220] text-slate-100 min-h-screen">
      {/* Sub-Navigation Tab Bar */}
      <div className="bg-[#111E33] border border-white/10 rounded-2xl p-2.5 flex flex-wrap items-center gap-2 shadow-xl">
        <button
          type="button"
          onClick={() => setActiveTab('profile')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'profile' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <User className="w-4 h-4" /> Profile Overview
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('submit-content')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'submit-content'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'submit-content' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Upload className="w-4 h-4" /> Submit Content
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('content-library')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'content-library' || activeTab === 'my-content'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'content-library' || activeTab === 'my-content' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Film className="w-4 h-4" /> Content Library
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('briefs')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'briefs'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'briefs' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <FileText className="w-4 h-4" /> Creator Briefs
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fulfillment')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'fulfillment' || activeTab === 'gifting' || activeTab === 'creator-delivery'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'fulfillment' || activeTab === 'gifting' || activeTab === 'creator-delivery' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Package className="w-4 h-4" /> Samples &amp; Delivery
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('marketplace')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'marketplace'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'marketplace' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Target className="w-4 h-4" /> Marketplace
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('missions')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'missions'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'missions' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Target className="w-4 h-4" /> My Active Missions
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('escrow')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'escrow'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'escrow' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <History className="w-4 h-4" /> Escrow Ledger
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('announcements')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'announcements'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'announcements' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Megaphone className="w-4 h-4" /> Announcements
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('training')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'training'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'training' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <BookOpen className="w-4 h-4" /> Training &amp; KB
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('my-portfolio')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'my-portfolio' || activeTab === 'mediakit'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'my-portfolio' || activeTab === 'mediakit' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Briefcase className="w-4 h-4" /> My Portfolio
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('notifications')}
          className={`flex-1 min-w-[140px] py-3 px-3 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'notifications'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
              : 'bg-white/5 text-slate-300 hover:bg-white/10'
          }`}
          style={activeTab === 'notifications' ? { backgroundColor: primaryBrandColor || '#C9A46A' } : {}}
        >
          <Bell className="w-4 h-4" /> Notifications
        </button>
      </div>

      {/* CASE 1: PROFILE OVERVIEW */}
      {activeTab === 'profile' && (
        <div className="space-y-6 animate-fade-in">
        {currentUser?.rosterType === "Exclusive" && (
          <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-[#111E33] border border-[#D4AF37]/30 rounded-xl p-6 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#D4AF37]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white font-serif flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-[#D4AF37]" /> Stripe Production Card
                  </h3>
                  <p className="text-sm text-slate-400 mt-1">Exclusive roster expense controller</p>
                </div>
                <span className="px-2 py-1 rounded bg-[#D4AF37]/20 text-[#D4AF37] text-xs font-mono">ACTIVE</span>
              </div>
              <div className="bg-[#0A1220] rounded-lg p-4 font-mono text-slate-300 flex justify-between items-center border border-white/5">
                <span>**** **** **** 4242</span>
                <span className="text-emerald-400 font-bold">$2,500.00 <span className="text-slate-500 font-sans font-normal text-xs uppercase">Limit</span></span>
              </div>
                            <button type="button" onClick={() => setActiveScreen("waitlist")} className="w-full mt-4 bg-white/5 hover:bg-white/10 text-white py-2 rounded border border-white/10 transition-colors text-sm cursor-pointer">
                Request Expense Authorization
              </button>
            </div>
            
            <div className="bg-[#111E33] border border-[#00C2FF]/30 rounded-xl p-6 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#00C2FF]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white font-serif flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#00C2FF]" /> Creator AI Twin Toggle
                  </h3>
                  <p className="text-sm text-slate-400 mt-1">Manage your synthetic clone</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" defaultChecked />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00C2FF]"></div>
                </label>
              </div>
              <p className="text-sm text-slate-300 mb-4 leading-relaxed">
                Your AI twin is currently authorized to represent you in pre-approved synthetic media casting missions.
              </p>
              <button onClick={() => setActiveScreen("creator-ai-twin")} className="w-full bg-[#00C2FF]/20 hover:bg-[#00C2FF]/30 text-[#00C2FF] font-bold py-2 rounded transition-colors text-sm">
                Configure AI Twin Settings
              </button>
            </div>
          </div>
        )}




          {/* Master Profile Overview Card (Matching CreatorProfileSummaryCard & Media Kit) */}
          <div className="bg-gradient-to-br from-[#111E33] via-[#0D1830] to-[#132240] border border-[#C9A46A]/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-slate-100 space-y-6">
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#C9A46A]/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

            {/* Top Row: Avatar with change photo, Name, Niche, Reach, Quick Actions */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-white/10 relative z-10">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
                {/* Creator Avatar with platform badge and hover edit */}
                <div className="relative group shrink-0">
                  <img 
                    src={avatarUrl} 
                    alt={name}
                    referrerPolicy="no-referrer"
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-[#C9A46A] shadow-xl"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-[#0A1220] p-1.5 rounded-full border border-white/20 shadow-md">
                    {matchingCreator?.platform?.toLowerCase().includes('instagram') ? (
                      <Instagram className="w-4 h-4 text-pink-400" />
                    ) : matchingCreator?.platform?.toLowerCase().includes('youtube') ? (
                      <Youtube className="w-4 h-4 text-red-400" />
                    ) : (
                      <VideoIcon className="w-4 h-4 text-cyan-400" />
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-semibold transition-opacity duration-200 cursor-pointer p-1 text-center"
                    title="Change Profile Photo"
                  >
                    <Camera className="w-5 h-5 mb-1 text-[#C9A46A]" />
                    <span>Change Photo</span>
                  </button>
                  <input
                    type="file"
                    ref={avatarInputRef}
                    onChange={handleAvatarUpload}
                    accept="image/*"
                    className="hidden"
                  />
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                      Verified Creator Profile
                    </span>
                    <span className="bg-[#C9A46A]/20 text-[#C9A46A] text-[10px] font-mono uppercase font-bold px-2 py-0.5 rounded-md border border-[#C9A46A]/40">
                      {niche} Vertical
                    </span>
                    <span className="text-xs bg-[#16243F] border border-[#C9A46A]/30 text-[#C9A46A] font-semibold px-2.5 py-0.5 rounded-xl flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" /> {tier}
                    </span>
                    <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-xl border ${
                      derivedAvailabilityStatus === 'Booked'
                        ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                        : derivedAvailabilityStatus === 'Limited Availability'
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                        : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                    }`}>
                      {derivedAvailabilityStatus}
                    </span>
                  </div>

                  <h1 className="font-serif font-bold text-2xl sm:text-3xl text-white mt-1.5 flex items-center gap-2">
                    {name}
                  </h1>
                  <p className="text-xs font-mono text-slate-300 flex items-center gap-2 mt-0.5">
                    <span className="text-[#C9A46A] font-semibold">{handle}</span>
                    <span>•</span>
                    <span className="text-slate-400">{matchingCreator?.platform || 'TikTok & Instagram'} Talent</span>
                    <span>•</span>
                    <span className="text-emerald-400 font-sans font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Active Roster Contract
                    </span>
                  </p>
                  <p className="text-xs text-slate-300 mt-2 max-w-2xl line-clamp-2 leading-relaxed">
                    {bio}
                  </p>

                  {/* Verified Payout Method & Escrow Status Ribbon */}
                  <div className="flex flex-wrap items-center gap-2 mt-3">
                    <button
                      type="button"
                      onClick={() => {
                        const el = document.getElementById('creatorPayoutSection');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-[#111E33] hover:bg-[#182946] border border-white/10 hover:border-[#C9A46A]/50 text-slate-300 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                      title="Click to view or edit payout setup"
                    >
                      <CreditCard className="w-3.5 h-3.5 text-[#C9A46A]" />
                      <span>Payout Setup: <strong className="text-white">{paymentMethod === 'Direct Deposit' ? `ACH (${bankName || 'Bank'} ••••${accountNumber.slice(-4)})` : paymentMethod === 'Agency Debit Card' ? `Agency Visa (•••• ${stripeCardLast4})` : paymentMethod}</strong></span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('escrow')}
                      className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-300 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
                      title="Click to view personal escrow payouts"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Escrow: <strong className="text-emerald-300">100% Net-0 Backed</strong></span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveScreen('irs-tax-vault')}
                      className={`text-[11px] font-mono px-2.5 py-1 rounded-lg border transition-all flex items-center gap-1.5 cursor-pointer shadow-sm ${
                        w9Uploaded || w9Status === 'Verified'
                          ? 'bg-emerald-500/10 hover:bg-emerald-500/20 border-emerald-500/20 text-emerald-300'
                          : 'bg-amber-500/10 hover:bg-amber-500/20 border-amber-500/30 text-amber-300'
                      }`}
                      title="IRS W-9 Tax Certification"
                    >
                      <Landmark className="w-3.5 h-3.5" />
                      <span>Tax Vault: <strong className={w9Uploaded || w9Status === 'Verified' ? 'text-emerald-300' : 'text-amber-300'}>{w9Uploaded || w9Status === 'Verified' ? 'W-9 Certified' : 'W-9 Intake Needed'}</strong></span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Action Buttons & Verified Reach Pill */}
              <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end gap-3 shrink-0">
                <div className="bg-[#0A1220]/90 border border-[#C9A46A]/40 rounded-2xl px-5 py-3 flex items-center gap-5 shadow-lg w-full sm:w-auto">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block">
                      Verified Total Reach
                    </span>
                    <span className="text-xl font-mono font-bold text-[#C9A46A]">
                      {tiktokFollowers || matchingCreator?.followers || '185,000'}
                    </span>
                  </div>
                  <div className="text-right pl-4 border-l border-white/10">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block">
                      Avg Velocity
                    </span>
                    <span className="text-sm font-mono font-bold text-emerald-400">
                      {avgVelocityViews} views
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      const cleanHandle = (handle || matchingCreator?.handle || 'creator').replace('@', '');
                      const shareUrl = `${window.location.origin}/creator/@${cleanHandle}`;
                      navigator.clipboard.writeText(shareUrl);
                      triggerNotification('Share Link Copied', `Direct profile link copied: ${shareUrl}`, 'success');
                    }}
                    className="text-xs bg-[#16243F] hover:bg-[#1f3050] border border-white/10 text-slate-200 hover:text-white font-semibold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                    title="Copy Direct Shareable Profile Link"
                  >
                    <Copy className="w-3.5 h-3.5 text-[#C9A46A]" /> Share Profile
                  </button>

                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    className="text-xs bg-[#16243F] hover:bg-[#1f3050] border border-white/10 text-slate-200 hover:text-white font-semibold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                  >
                    <Camera className="w-3.5 h-3.5 text-cyan-400" /> Photo
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setProfileViewMode(profileViewMode === 'card' ? 'edit' : 'card');
                      const formElem = document.getElementById('creator-profile-edit-form');
                      if (formElem) formElem.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="text-xs bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{profileViewMode === 'edit' ? 'View Card Mode' : 'Edit Information'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Core Stats Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 relative z-10">
              <div className="bg-[#111E33]/90 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-cyan-400" /> Total Followers
                </span>
                <span className="text-xl font-bold text-white block">{tiktokFollowers || '185K'}</span>
                <span className="text-[10px] text-emerald-400 font-semibold font-mono">Verified Aggregate</span>
              </div>

              <div className="bg-[#111E33]/90 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-[#C9A46A]" /> Engagement Rate
                </span>
                <span className="text-xl font-bold text-white block">{engagementRate || '8.4%'}</span>
                <span className="text-[10px] text-emerald-400 font-semibold font-mono">1.8x Industry Baseline</span>
              </div>

              <div className="bg-[#111E33]/90 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono flex items-center gap-1">
                  <VideoIcon className="w-3.5 h-3.5 text-pink-400" /> Avg Video Velocity
                </span>
                <span className="text-xl font-bold text-white block">{avgVelocityViews}</span>
                <span className="text-[10px] text-slate-400 font-semibold font-mono">Organic Impression Median</span>
              </div>

              <div className="bg-[#111E33]/90 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-purple-400" /> Primary Channel
                </span>
                <span className="text-xl font-bold text-white block">{matchingCreator?.platform || 'TikTok & IG'}</span>
                <span className="text-[10px] text-purple-300 font-semibold font-mono">Active Representation</span>
              </div>
            </div>

            {/* Niche Parameter Matrix Section */}
            <div className="py-2 space-y-3 relative z-10 border-t border-white/10 pt-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#C9A46A] flex items-center gap-2">
                  <Tag className="w-4 h-4 text-[#C9A46A]" />
                  <span>Niche Parameter Matrix ({niche})</span>
                </span>
                <span className="text-[11px] font-mono text-slate-400">
                  Client-Facing Sponsor Casting Specs • Dynamic Agency Matrix
                </span>
              </div>
              
              {/* Dynamic render based on niche */}
              {renderNicheMatrixCards()}
            </div>

            {/* Legal / Safety Badges (Stamps) */}
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center gap-3 relative z-10">
              <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#C9A46A]/10 border-2 border-[#C9A46A] shadow-sm">
                <ShieldCheck className="w-4 h-4 text-[#C9A46A] shrink-0" />
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#C9A46A]">
                  FTC Compliance Registry Verified
                </span>
              </div>

              <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-500/10 border-2 border-emerald-400/80 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-300">
                  Copyright Clearance Active
                </span>
              </div>

              <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-purple-500/10 border border-purple-500/40 shadow-sm">
                <Shield className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-purple-300">
                  100% Escrow Net-0 Protected
                </span>
              </div>
            </div>

            {/* Audience Demographics & Deliverable Rate Card Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-4 border-t border-white/10 relative z-10">
              {/* Deliverable Rate Card & Commercial Sponsorship Packages */}
              <div className="lg:col-span-7 bg-[#111E33]/90 border border-white/5 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-3">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-[#C9A46A]" />
                    <h3 className="font-serif font-bold text-sm text-white">Commercial Rate Card &amp; Sponsorships</h3>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Live Escrow Rates
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3 bg-[#0D1830] border border-white/5 rounded-xl space-y-1">
                    <span className="text-[11px] text-slate-400 font-medium block">TikTok Dedicated</span>
                    <span className="font-bold text-emerald-400 font-mono text-sm block">{rateSingleReel}</span>
                    <span className="text-[9px] text-slate-500 font-mono">1x 9:16 Video</span>
                  </div>

                  <div className="p-3 bg-[#0D1830] border border-white/5 rounded-xl space-y-1">
                    <span className="text-[11px] text-slate-400 font-medium block">Instagram Reel</span>
                    <span className="font-bold text-emerald-400 font-mono text-sm block">{rateStorySet}</span>
                    <span className="text-[9px] text-slate-500 font-mono">1x 60s Reel</span>
                  </div>

                  <div className="p-3 bg-[#0D1830] border border-white/5 rounded-xl space-y-1">
                    <span className="text-[11px] text-slate-400 font-medium block">3-Reel Campaign</span>
                    <span className="font-bold text-emerald-400 font-mono text-sm block">{rateBundle3}</span>
                    <span className="text-[9px] text-[#C9A46A] font-mono">Bundle Discount</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-1 text-slate-400 font-mono">
                  <span>Spark Ads Paid Usage (30 Days): <strong className="text-white">{rateSparkAds}</strong></span>
                  <span className="text-[10px] text-[#C9A46A]">Exclusivity Negotiated Separately</span>
                </div>
              </div>

              {/* Audience Demographics */}
              <div className="lg:col-span-5 bg-[#111E33]/90 border border-white/5 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-3">
                  <h3 className="font-serif font-bold text-sm text-white">Audience Demographics</h3>
                  <span className="text-[10px] font-mono text-slate-400">Verified Platform Analytics</span>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-[11px] font-mono text-slate-300">
                    <span>Female 72%</span>
                    <span>Male 28%</span>
                  </div>
                  <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden flex text-[9px] font-bold text-white">
                    <div className="bg-[#C9A46A] h-full flex items-center justify-center" style={{ width: '72%' }} />
                    <div className="bg-sky-500 h-full flex items-center justify-center" style={{ width: '28%' }} />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div className="bg-[#0D1830] p-2 rounded-xl border border-white/5">
                    <span className="text-[9px] font-mono uppercase text-slate-400 block">Age 18-24</span>
                    <span className="text-xs font-bold text-white font-mono">55%</span>
                  </div>
                  <div className="bg-[#0D1830] p-2 rounded-xl border border-white/5">
                    <span className="text-[9px] font-mono uppercase text-slate-400 block">Age 25-34</span>
                    <span className="text-xs font-bold text-white font-mono">35%</span>
                  </div>
                  <div className="bg-[#0D1830] p-2 rounded-xl border border-white/5">
                    <span className="text-[9px] font-mono uppercase text-slate-400 block">Top Geo</span>
                    <span className="text-xs font-bold text-emerald-400 font-mono">USA (65%)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Read-Only Agency-Set Fields Bar */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Tier Card */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 flex items-center justify-between" style={{ backgroundColor: cardBgColor }}>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Agency Tier (Read-Only)</span>
                <span className="text-base font-bold text-white mt-1 block">{tier}</span>
                <span className="text-[10px] text-[#C9A46A] mt-0.5 block">Managed by Agency Staff</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[#16243F] border border-white/10 flex items-center justify-center text-[#C9A46A]">
                <Award className="w-5 h-5" />
              </div>
            </div>

            {/* Assigned Coordinator Card */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 flex items-center justify-between" style={{ backgroundColor: cardBgColor }}>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Assigned Coordinator (Read-Only)</span>
                <span className="text-base font-bold text-white mt-1 block">{assignedCoordinator}</span>
                <button
                  type="button"
                  onClick={() => {
                    setActiveScreen('chat-system');
                    onAddActivityLog(name, 'creator', 'Opened chat thread with Assigned Coordinator');
                  }}
                  className="text-[11px] text-[#C9A46A] hover:underline flex items-center gap-1 mt-1 font-semibold cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" /> Message Coordinator &rarr;
                </button>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[#16243F] border border-white/10 flex items-center justify-center text-emerald-400">
                <User className="w-5 h-5" />
              </div>
            </div>

            {/* Commission Split Card */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 flex items-center justify-between" style={{ backgroundColor: cardBgColor }}>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Commission Split (Read-Only)</span>
                <span className="text-base font-bold text-emerald-400 mt-1 block">{commissionSplit}</span>
                <span className="text-[10px] text-slate-400 mt-0.5 block">Agency locked escrow term</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[#16243F] border border-white/10 flex items-center justify-center text-[#C9A46A]">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* SMS / Phone Messages Signup Notice (Controlled by showPhoneMessagesAlert Toggle) */}
          {showPhoneMessagesAlert && (
            <div className="bg-gradient-to-r from-[#111E33] via-[#0D1830] to-[#16243F] border border-[#C9A46A]/40 rounded-2xl p-5 shadow-xl space-y-4 relative overflow-hidden">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#C9A46A]/10 border border-[#C9A46A]/30 flex items-center justify-center text-[#C9A46A] shrink-0">
                    <Smartphone className="w-5 h-5" style={{ color: primaryBrandColor }} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.5 rounded-full border border-[#C9A46A]/20">
                        SMS Campaign Alerts
                      </span>
                      {isSmsSubscribed ? (
                        <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                          <CheckCircle2 className="w-3 h-3" /> Subscribed & Verified
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-amber-300 flex items-center gap-1 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                          <Clock className="w-3 h-3" /> Action Recommended
                        </span>
                      )}
                    </div>
                    <h3 className="font-serif font-bold text-base text-white mt-1">
                      Sign Up for Instant Mobile &amp; Phone Message Alerts
                    </h3>
                    <p className="text-xs text-[#7C8AA8]">
                      Receive real-time SMS notifications whenever high-paying brand campaign briefs, casting calls, or escrow payouts require your attention.
                    </p>
                  </div>
                </div>
              </div>

              {!isSmsSubscribed ? (
                <div className="bg-[#0A1220]/80 border border-white/10 rounded-xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                  <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block mb-1">Mobile Phone Number</label>
                      <input
                        type="tel"
                        value={smsPhoneInput}
                        onChange={(e) => setSmsPhoneInput(e.target.value)}
                        placeholder="e.g. +1 (555) 019-2834"
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white placeholder-slate-500 outline-none focus:border-[#C9A46A]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block mb-1">Mobile Carrier</label>
                      <select
                        value={smsCarrier}
                        onChange={(e) => setSmsCarrier(e.target.value)}
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                      >
                        <option value="Verizon">Verizon Wireless</option>
                        <option value="AT&T">AT&T Mobility</option>
                        <option value="T-Mobile">T-Mobile US</option>
                        <option value="Rogers">Rogers / Fido Canada</option>
                        <option value="Vodafone">Vodafone International</option>
                        <option value="Other">Other Carrier / Unlisted</option>
                      </select>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!smsPhoneInput.trim()) {
                        triggerNotification('Phone Required', 'Please enter a valid mobile number to enable SMS alerts.', 'warning');
                        return;
                      }
                      setPhone(smsPhoneInput);
                      safeStorage.setItem(`wl_sms_registered_${handle || 'creator'}`, 'true');
                      setIsSmsSubscribed(true);
                      triggerNotification('SMS Alerts Activated', `Mobile notifications enabled for ${smsPhoneInput}.`, 'success');
                      onAddActivityLog(name, 'creator', `Signed up for mobile SMS notifications (${smsCarrier})`);
                    }}
                    className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs px-5 py-2.5 rounded-xl transition-all shadow-md shrink-0 cursor-pointer flex items-center justify-center gap-2 self-end md:self-auto"
                    style={{ backgroundColor: primaryBrandColor }}
                  >
                    <Bell className="w-4 h-4" /> Enable Phone Notifications
                  </button>
                </div>
              ) : (
                <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-3 flex items-center justify-between text-xs text-emerald-300">
                  <span className="flex items-center gap-2 font-mono">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Active Mobile Phone Dispatch: <strong>{phone || smsPhoneInput}</strong> ({smsCarrier})
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      safeStorage.removeItem(`wl_sms_registered_${handle || 'creator'}`);
                      setIsSmsSubscribed(false);
                      triggerNotification('SMS Opt-Out', 'Mobile alerts turned off.', 'info');
                    }}
                    className="text-[11px] text-slate-400 hover:text-rose-300 underline cursor-pointer"
                  >
                    Opt-Out
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Executive Announcements Feed Widget */}
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4 shadow-xl" style={{ backgroundColor: cardBgColor }}>
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-[#C9A46A]" style={{ color: primaryBrandColor }} />
                <h3 className="font-serif font-bold text-base text-white">Agency Broadcasts &amp; Announcements</h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('announcements')}
                className="text-xs text-[#C9A46A] hover:underline font-mono font-semibold cursor-pointer"
              >
                View All Memos &rarr;
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {creatorAnnouncements.slice(0, 2).map((item: any) => (
                <div key={item.id} className="bg-[#111E33] border border-white/10 rounded-xl p-4 space-y-2 border-l-4 border-l-[#C9A46A] hover:border-white/20 transition-all">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-[#C9A46A] font-mono font-bold uppercase">{item.category || 'Executive Memo'}</span>
                    <span className="text-slate-400 font-mono">{item.timestamp || 'Recent'}</span>
                  </div>
                  <h4 className="font-bold text-white text-sm">{item.title}</h4>
                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{item.content}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Talent Media Kit Access Bar */}
          <div className="bg-gradient-to-r from-[#111E33] to-[#16243F] border border-[#C9A46A]/30 rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#C9A46A] bg-[#0A1220] px-2.5 py-0.5 rounded-full border border-[#C9A46A]/30">
                  Active Sponsor Pitch Card
                </span>
                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse"></span>
                  Live &amp; Verified
                </span>
              </div>
              <h3 className="font-serif font-semibold text-lg text-white">
                Talent Media Kit &amp; Verified Portfolio
              </h3>
              <p className="text-xs text-[#7C8AA8]">
                Your agency-managed media kit displays verified demographic splits, campaign highlights, and video portfolio reels (View Only).
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setActiveScreen('media-kits');
                onAddActivityLog(name, 'creator', 'Opened Talent Media Kit from Creator Portal');
              }}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs px-5 py-2.5 rounded-xl flex items-center gap-2 transition-colors shrink-0 shadow-md cursor-pointer"
            >
              <Eye className="w-4 h-4" />
              <span>View Talent Media Kit &rarr;</span>
            </button>
          </div>

          {/* 5-Pillar Representation Suite & Debit Card */}
          <div className="bg-[#0b1628] border border-[#C9A46A]/40 rounded-3xl p-6 space-y-6 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-[#C9A46A]/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/10 pb-4 relative z-10">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                    5-Pillar Representation Suite
                  </span>
                  <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Full Agency Coverage Active
                  </span>
                </div>
                <h2 className="font-serif font-bold text-xl md:text-2xl text-white mt-1">
                  Agency Benefits &amp; $5,000 Production Line Breakdown
                </h2>
                <p className="text-xs text-[#7C8AA8] mt-0.5">
                  Comprehensive breakdown of all perks, dedicated agent representation, escrow guarantees, and instant production card funding provided to Bloom &amp; Co. roster creators.
                </p>
              </div>
              <span className="text-xs bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 px-3.5 py-1.5 rounded-xl font-mono font-semibold shrink-0 flex items-center gap-1.5 self-start md:self-auto">
                <Zap className="w-3.5 h-3.5 text-emerald-400" /> Instant Escrow Liquidity
              </span>
            </div>

            {/* 5 Representation Pillars Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10">
              <div className="bg-[#111E33] border border-[#C9A46A]/40 rounded-2xl p-4.5 space-y-3 relative group hover:border-[#C9A46A] transition-all shadow-md">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#C9A46A]">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2.5 py-0.5 rounded-full">
                    100% Escrow Backed
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">1. Guaranteed Escrow &amp; Direct ACH Payouts</h3>
                  <p className="text-[11px] text-[#7C8AA8] mt-1 leading-relaxed">
                    100% upfront brand funding locked in Stripe Escrow before filming begins. Direct Deposit (ACH) bank releases upon deliverable approval with zero payment delays or out-of-pocket costs.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 font-mono">Disbursal: <strong className="text-emerald-400">Direct ACH</strong></span>
                  <span className="text-[#C9A46A] font-semibold">Stripe Payouts</span>
                </div>
              </div>

              <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4.5 space-y-3 relative group hover:border-emerald-500/50 transition-all shadow-md">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <User className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2.5 py-0.5 rounded-full">
                    Assigned: {assignedCoordinator}
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">2. Dedicated Talent Representation</h3>
                  <p className="text-[11px] text-[#7C8AA8] mt-1 leading-relaxed">
                    Direct representation negotiating high-ticket 4-to-5 figure brand sponsorships, paid usage terms, and exclusivity agreements with Fortune 500 &amp; DTC brands in Pets, Beauty, and Lifestyle.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 font-mono">Commission: <strong className="text-white">{commissionSplit.split(' ')[0]}</strong></span>
                  <button
                    type="button"
                    onClick={() => setActiveScreen('chat-system')}
                    className="text-[#C9A46A] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    Chat Agent &rarr;
                  </button>
                </div>
              </div>

              <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4.5 space-y-3 relative group hover:border-purple-500/50 transition-all shadow-md">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                    <Shield className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 px-2.5 py-0.5 rounded-full">
                    100% Escrow
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">3. Escrow Net-0 Payment Protection</h3>
                  <p className="text-[11px] text-[#7C8AA8] mt-1 leading-relaxed">
                    Brands must deposit 100% of sponsorship fees into Stripe Escrow before you film. Zero payment defaults, no 60-90 day waiting periods, and instant payouts upon deliverable approval.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 font-mono">Default Risk: <strong className="text-emerald-400">0.00%</strong></span>
                  <span className="text-purple-300 font-semibold">Stripe Protected</span>
                </div>
              </div>

              <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4.5 space-y-3 relative group hover:border-blue-500/50 transition-all shadow-md">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40 px-2.5 py-0.5 rounded-full">
                    Legal Vetted
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">4. FTC Legal &amp; Rights Protection</h3>
                  <p className="text-[11px] text-[#7C8AA8] mt-1 leading-relaxed">
                    In-house legal vetting for every brand agreement, protecting your perpetual likeness, preventing predatory exclusivity locks, and guaranteeing full FTC disclosure compliance.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 font-mono">Contract Shield: <strong className="text-blue-300">Active</strong></span>
                  <span className="text-blue-300 font-semibold">SAG/AFTRA Aligned</span>
                </div>
              </div>

              <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4.5 space-y-3 relative group hover:border-rose-500/50 transition-all shadow-md lg:col-span-2">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 px-2.5 py-0.5 rounded-full">
                    Studio AI Suite
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">5. Creative AI Suite &amp; Verified Media Kit</h3>
                  <p className="text-[11px] text-[#7C8AA8] mt-1 leading-relaxed">
                    Automated live media kits with verified demographic statistics, AI-powered reel generation, soundtrack licensing clearing, and real-time deal performance tracking dashboards.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 font-mono">Portfolio Status: <strong className="text-emerald-400">Verified Active</strong></span>
                  <button
                    type="button"
                    onClick={() => setActiveScreen('media-kits')}
                    className="text-[#C9A46A] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    Open Media Kit &rarr;
                  </button>
                </div>
              </div>
            </div>

            {/* Embedded Interactive Agency Debit Card */}
            <div className="pt-2 relative z-10 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 font-serif">
                  <CreditCard className="w-4 h-4 text-[#C9A46A]" /> Your Agency Debit &amp; Production Card
                </h3>
                <span className="text-[11px] text-[#7C8AA8] font-mono">Stripe Issuing Instant Provisioning</span>
              </div>
              <AgencyDebitCard 
                creator={matchingCreator}
                creatorName={cardholderLegalName || name}
                creatorHandle={handle}
                agencyName="Bloom & Co."
                primaryColor={primaryBrandColor || "#C9A46A"}
                cardLast4={stripeCardLast4}
                cardExpiry={stripeCardExpiry}
                balance={matchingCreator?.totalEarned ? Math.round(matchingCreator.totalEarned * 0.45) : 8450}
                onTriggerNotification={triggerNotification}
                onAddActivityLog={onAddActivityLog}
              />
            </div>
          </div>

      {/* Main Profile Form */}
      <form id="creator-profile-edit-form" onSubmit={handleSaveProfile} className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-6" style={{ backgroundColor: cardBgColor }}>
        <div className="border-b border-white/5 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-serif font-semibold text-lg text-white">Profile Information &amp; Preferences</h2>
            <p className="text-xs text-[#7C8AA8] mt-0.5">
              Keep your contact details, social links, and brand collaboration criteria up to date.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="submit"
              disabled={isSaving}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-5 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-colors shrink-0 shadow-md cursor-pointer"
              style={{ backgroundColor: primaryBrandColor }}
            >
              {isSaving ? (
                <span className="flex items-center gap-1.5">Transmitting to Leadership...</span>
              ) : (
                <>
                  <Save className="w-4 h-4" /> Save &amp; Dispatch to Leadership
                </>
              )}
            </button>
          </div>
        </div>

        {/* Agency Leadership Routing Notice */}
        <div className="bg-gradient-to-r from-[#111E33] to-[#16243F] border border-[#C9A46A]/25 rounded-xl p-4 flex items-start gap-3 text-xs">
          <ShieldCheck className="w-5 h-5 text-[#C9A46A] shrink-0 mt-0.5" style={{ color: primaryBrandColor }} />
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white">Agency Leadership Synchronization</span>
              <span className="text-[9px] font-mono uppercase bg-[#C9A46A]/15 text-[#C9A46A] border border-[#C9A46A]/30 px-2 py-0.5 rounded-full font-bold">
                Director • Agent • Agent Managers
              </span>
            </div>
            <p className="text-[#B8C0D4] leading-relaxed">
              When you submit or update this profile, your brand whitelist/blacklist, social follower reaches, contact coordinates, and quarterly calendar availability automatically route to the <strong className="text-white">Agency Director</strong>, your <strong className="text-white">Assigned Talent Agent ({assignedCoordinator})</strong>, and <strong className="text-white">Agent Managers</strong> in the Roster Profile Review Section.
            </p>
          </div>
        </div>

        {saveSuccess && (
          <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2.5 animate-fade-in shadow-inner">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <span className="font-bold text-white block">Roster Profile Transmitted Successfully!</span>
              <span className="text-[11px] text-emerald-300">
                Your profile update has been recorded and broadcast to the Director Dashboard, Agent Desk, and Agent Managers.
              </span>
            </div>
          </div>
        )}

        {/* Section 1: Basic Identity */}
        <div className="space-y-4">
          <h3 className="text-xs uppercase font-mono font-bold text-[#C9A46A] tracking-wider border-b border-white/5 pb-2">
            1. Personal &amp; Contact Details
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Creator Handle</label>
              <input
                type="text"
                value={handle}
                onChange={e => setHandle(e.target.value)}
                placeholder="@handle"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Real Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Full Name"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                required
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-semibold text-slate-300">Email Address</label>
                {email && (
                  <button
                    type="button"
                    onClick={() => setEmail('')}
                    className="text-[10px] text-slate-400 hover:text-rose-400 font-mono transition-colors"
                  >
                    Clear email
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="email@example.com"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A] pr-8"
                />
                {email && (
                  <button
                    type="button"
                    onClick={() => setEmail('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs w-5 h-5 flex items-center justify-center rounded-full hover:bg-white/10"
                    title="Erase email"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Niches & Bio */}
        <div className="space-y-4 pt-2">
          <h3 className="text-xs uppercase font-mono font-bold text-[#C9A46A] tracking-wider border-b border-white/5 pb-2">
            2. Niche, Category &amp; Bio
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-semibold text-slate-300">Primary Niche / Category</label>
                {strictCoreOnly && (
                  <span className="text-[9px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-1.5 py-0.5 rounded">
                    Core Specialization Active
                  </span>
                )}
              </div>
              <select
                value={niche}
                onChange={e => setNiche(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                {activeNiches.map(n => (
                  <option key={n.value} value={n.value} className="bg-[#0D1830] text-white">
                    {n.emoji} {n.label}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-slate-400 font-mono">
                {strictCoreOnly ? 'Bloom Studio specialization: Pets • Beauty • Lifestyle' : 'Custom niche categories active'}
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Secondary Interests &amp; Specialties</label>
              <input
                type="text"
                value={secondaryInterests}
                onChange={e => setSecondaryInterests(e.target.value)}
                placeholder="e.g. Pet Nutrition, Clean Skincare, Daily Lifestyle"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-slate-300">Bio</label>
            <textarea
              rows={3}
              value={bio}
              onChange={e => setBio(e.target.value)}
              placeholder="Tell brands about your background, voice, and audience..."
              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
            />
          </div>

          {/* Dynamic Niche Parameter Matrix Configuration */}
          <div className="bg-[#111E33] border border-[#C9A46A]/30 rounded-2xl p-4.5 space-y-3.5">
            <div className="flex items-center justify-between border-b border-white/5 pb-2">
              <span className="text-xs font-mono font-bold text-[#C9A46A] uppercase flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5" />
                <span>Niche Parameter Matrix ({niche})</span>
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                Directly feeds into your live Profile Overview &amp; Media Kit
              </span>
            </div>

            {niche.toLowerCase().includes('beauty') || niche.toLowerCase().includes('cosmetic') ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Skin Type Matrix</label>
                  <input
                    type="text"
                    value={skinTypeMatrix}
                    onChange={e => setSkinTypeMatrix(e.target.value)}
                    placeholder="e.g. Combination / Sensitive"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Tone &amp; Undertone</label>
                  <input
                    type="text"
                    value={skinTone}
                    onChange={e => setSkinTone(e.target.value)}
                    placeholder="e.g. Neutral-Cool / Olive"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Hair Matrix</label>
                  <input
                    type="text"
                    value={hairMatrix}
                    onChange={e => setHairMatrix(e.target.value)}
                    placeholder="e.g. Wavy 2B / Balayage"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>
            ) : niche.toLowerCase().includes('pet') || niche.toLowerCase().includes('dog') || niche.toLowerCase().includes('cat') ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Pet Breed Metrics</label>
                  <input
                    type="text"
                    value={petBreedMetrics}
                    onChange={e => setPetBreedMetrics(e.target.value)}
                    placeholder="e.g. Golden Retriever / Purebred"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Age &amp; Weight Matrix</label>
                  <input
                    type="text"
                    value={petAgeWeight}
                    onChange={e => setPetAgeWeight(e.target.value)}
                    placeholder="e.g. 3.5 Years • 64 lbs"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Dietary Profile</label>
                  <input
                    type="text"
                    value={petDietCategory}
                    onChange={e => setPetDietCategory(e.target.value)}
                    placeholder="e.g. Organic Raw / Grain-Free"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Aesthetic Matrix</label>
                  <input
                    type="text"
                    value={aestheticMatrix}
                    onChange={e => setAestheticMatrix(e.target.value)}
                    placeholder="e.g. Warm Minimalist / Nordic"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Lighting Style</label>
                  <input
                    type="text"
                    value={lightingStyle}
                    onChange={e => setLightingStyle(e.target.value)}
                    placeholder="e.g. Natural Golden Hour (5600K)"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase text-slate-400">Color Palette</label>
                  <input
                    type="text"
                    value={colorStory}
                    onChange={e => setColorStory(e.target.value)}
                    placeholder="e.g. Earthy Terracotta & Cream"
                    className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Section 3: Platforms & Links */}
        <div className="space-y-4 pt-2">
          <h3 className="text-xs uppercase font-mono font-bold text-[#C9A46A] tracking-wider border-b border-white/5 pb-2">
            3. Social Platforms &amp; Links
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">TikTok Handle / Link</label>
              <input
                type="text"
                value={tiktok}
                onChange={e => setTiktok(e.target.value)}
                placeholder="@handle"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Instagram Handle / Link</label>
              <input
                type="text"
                value={instagram}
                onChange={e => setInstagram(e.target.value)}
                placeholder="@handle"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">YouTube Channel</label>
              <input
                type="text"
                value={youtube}
                onChange={e => setYoutube(e.target.value)}
                placeholder="https://youtube.com/@Channel"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Content Preferences & Brand Compatibility */}
        <div className="space-y-4 pt-2">
          <h3 className="text-xs uppercase font-mono font-bold text-[#C9A46A] tracking-wider border-b border-white/5 pb-2">
            4. Content Preferences &amp; Brand Categories
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-emerald-400">
                Brand Categories You WILL Work With
              </label>
              <input
                type="text"
                value={preferredBrands}
                onChange={e => setPreferredBrands(e.target.value)}
                placeholder="e.g. Luxury Fashion, Organic Skincare, Fitness Apparel"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
              <p className="text-[10px] text-slate-400">
                Brands and industries you actively want to partner with.
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-rose-400">
                Excluded Categories (Won&apos;t Work With)
              </label>
              <input
                type="text"
                value={excludedBrands}
                onChange={e => setExcludedBrands(e.target.value)}
                placeholder="e.g. Gambling, Tobacco, Fast Fashion"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
              <p className="text-[10px] text-slate-400">
                Industries excluded from campaign matchmaking.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Content Formats &amp; Preferences</label>
              <input
                type="text"
                value={contentPreferences}
                onChange={e => setContentPreferences(e.target.value)}
                placeholder="e.g. TikTok Shorts, IG Reels, Dedicated YouTube Integrations"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            {/* Quarterly Availability (Q1, Q2, Q3, Q4) synced with Availability Calendar */}
            <div className="bg-[#0D1830] border border-white/10 rounded-xl p-4 space-y-3">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-white/5 pb-2.5">
                <div>
                  <label className="text-[11px] font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <span>📅 Quarterly Availability ({currentYear})</span>
                  </label>
                  <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                    Syncs automatically with the Availability Calendar. Setting a quarter marks those months; day-level entries on the calendar update the quarter&apos;s status.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400">Current Status:</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase border ${
                    derivedAvailabilityStatus === 'Booked'
                      ? 'bg-rose-950 border-rose-500/30 text-rose-300'
                      : derivedAvailabilityStatus === 'Limited Availability'
                      ? 'bg-amber-950 border-amber-500/30 text-amber-300'
                      : 'bg-emerald-950 border-emerald-500/30 text-emerald-300'
                  }`}>
                    {derivedAvailabilityStatus}
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveScreen('calendar-avail')}
                    className="text-[10px] bg-white/5 hover:bg-white/10 text-[#C9A46A] px-2 py-1 rounded border border-white/10 font-mono transition"
                  >
                    Open Calendar →
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { q: 1, name: 'Q1 (Jan–Mar)', status: q1Status },
                  { q: 2, name: 'Q2 (Apr–Jun)', status: q2Status },
                  { q: 3, name: 'Q3 (Jul–Sep)', status: q3Status },
                  { q: 4, name: 'Q4 (Oct–Dec)', status: q4Status },
                ].map((item) => (
                  <div key={item.q} className="bg-[#111E33] border border-white/10 rounded-lg p-3 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-mono text-xs font-bold text-[#C9A46A]">{item.name}</span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                        item.status === 'Booked'
                          ? 'bg-rose-950 text-rose-300'
                          : item.status === 'Limited'
                          ? 'bg-amber-950 text-amber-300'
                          : 'bg-emerald-950 text-emerald-300'
                      }`}>
                        {item.status}
                      </span>
                    </div>
                    <select
                      value={item.status}
                      onChange={(e) => handleSetQuarterAvailability(item.q as 1|2|3|4, e.target.value as any)}
                      className="w-full bg-[#0D1830] border border-white/10 rounded text-[11px] text-white p-1.5 outline-none focus:border-[#C9A46A]"
                    >
                      <option value="Available">Available</option>
                      <option value="Limited">Limited</option>
                      <option value="Booked">Booked</option>
                    </select>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Agency Representation & Compensation Terms Section (Fixed by Agency Policy) */}
        <div className="border-t border-white/10 pt-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#C9A46A]" /> Agency Representation &amp; Compensation Terms
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Official contract terms and take-rates set by Bloom &amp; Co. Agency Leadership.
              </p>
            </div>
            <span className="text-xs bg-purple-950/80 text-purple-300 border border-purple-500/30 px-3 py-1 rounded-xl font-mono font-semibold shrink-0 flex items-center gap-1.5">
              <Lock className="w-3 h-3 text-purple-400" /> Agency-Managed Split Terms
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="bg-[#111E33] border border-white/5 rounded-xl p-3.5 space-y-1.5">
              <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Representation Model</span>
              <div className="font-bold text-white text-sm">
                {matchingCreator?.agreement || matchingCreator?.agreementType || 'Exclusive Representation'}
              </div>
              <span className="text-[10px] text-amber-300 font-mono block">
                {matchingCreator?.tier || 'Tier 1 Talent Management'}
              </span>
            </div>

            <div className="bg-[#111E33] border border-white/5 rounded-xl p-3.5 space-y-1.5">
              <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Contractual Split Rate</span>
              <div className="font-bold text-emerald-400 font-mono text-sm">
                {matchingCreator?.commissionSplit || '80% Talent / 20% Agency Cut'}
              </div>
              <span className="text-[10px] text-slate-400 block">
                Net payout automatically held in Stripe Escrow
              </span>
            </div>

            <div className="bg-[#111E33] border border-white/5 rounded-xl p-3.5 space-y-1.5">
              <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Split Authority Policy</span>
              <div className="font-bold text-purple-300 text-xs flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span>Fixed by Agency Management</span>
              </div>
              <span className="text-[10px] text-slate-400 block">
                Splits are administered by Agency Directors
              </span>
            </div>
          </div>

          <div className="p-3 bg-purple-950/20 border border-purple-500/20 rounded-xl flex items-start gap-2.5 text-xs text-purple-200">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Talent Compensation Notice:</strong> All commercial splits, take-rates, and deal pricing are established and administered by Bloom &amp; Co. Agency Leadership. Talent does not choose custom splits. All campaign disbursements are guaranteed via 100% Stripe Escrow backing.
            </p>
          </div>
        </div>

        {/* Payout & Payment Method Section */}
        <div id="creatorPayoutSection" className="border-t border-white/10 pt-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#C9A46A]" /> Payout &amp; Payment Method (How You Get Paid)
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Set where agency leadership routes your campaign milestone payouts and cleared escrow releases.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-xl font-mono font-semibold shrink-0 flex items-center gap-1.5">
                <Zap className="w-3 h-3 text-emerald-400" /> Stripe Payouts Active
              </span>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Choose Payout Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="Direct Deposit">Direct Deposit / ACH Bank Transfer (Stripe Payouts Rails - Recommended)</option>
                <option value="PayPal">PayPal</option>
                <option value="Wire Transfer">Bank Wire Transfer</option>
                <option value="Other">Other (Contact Agency Leadership)</option>
              </select>
            </div>

            {/* DIRECT DEPOSIT ACH FORM */}
            {paymentMethod === 'Direct Deposit' && (
              <div className="p-4 rounded-xl bg-[#091222] border border-[#C9A46A]/30 space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <div className="flex items-center gap-2">
                    <Landmark className="w-4 h-4 text-[#C9A46A]" />
                    <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                      US Checking / Savings Direct Deposit Details
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    256-bit Bank Vault Encrypted
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Bank / Financial Institution Name</label>
                    <input
                      type="text"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      placeholder="e.g. JPMorgan Chase, Bank of America, Wells Fargo"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Account Type</label>
                    <select
                      value={accountType}
                      onChange={(e) => setAccountType(e.target.value as any)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                    >
                      <option value="Checking">Personal / Business Checking</option>
                      <option value="Savings">Savings Account</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Routing Transit Number (9 Digits)</label>
                    <input
                      type="text"
                      maxLength={9}
                      value={routingNumber}
                      onChange={(e) => setRoutingNumber(e.target.value.replace(/\D/g, ''))}
                      placeholder="9-digit ACH routing number"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                    <p className="text-[10px] text-slate-400">
                      Routing number found at the bottom left of your paper check.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-semibold text-slate-300">Account Number</label>
                      <button
                        type="button"
                        onClick={() => setShowAccountMask(!showAccountMask)}
                        className="text-[10px] font-mono text-[#C9A46A] hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        {showAccountMask ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                        <span>{showAccountMask ? 'Reveal' : 'Mask'}</span>
                      </button>
                    </div>
                    <input
                      type={showAccountMask ? "password" : "text"}
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ''))}
                      placeholder="Account number"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs font-mono text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                    <p className="text-[10px] text-slate-400">
                      Standard ACH transfer clears directly into this account within 24-48 hours of escrow release.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* AGENCY DEBIT CARD OPTION */}
            {paymentMethod === 'Agency Debit Card' && (
              <div className="p-4 rounded-xl bg-[#091222] border border-[#C9A46A]/30 space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#C9A46A]" />
                    <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                      Stripe Issuing Agency Visa Debit Card
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Instant Zero-Wait Payouts
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Cardholder Legal Name</label>
                    <input
                      type="text"
                      value={cardholderLegalName}
                      onChange={(e) => setCardholderLegalName(e.target.value)}
                      placeholder="Legal name as on government ID"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Issued Card Profile</label>
                    <div className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white flex items-center justify-between font-mono">
                      <span>Visa •••• {stripeCardLast4}</span>
                      <span className="text-emerald-400 font-bold">{stripeCardStatus} ({stripeCardType})</span>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed bg-[#111E33]/60 p-3 rounded-xl border border-white/5">
                  ⚡ <strong>Instant Escrow Clearing:</strong> When Agency Leadership approves your campaign deliverables, your funds disburse immediately onto this Agency Visa card with zero ACH waiting period.
                </p>
              </div>
            )}

            {paymentMethod === 'PayPal' && (
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300">PayPal Email or Phone</label>
                <input
                  type="text"
                  value={paymentDetails}
                  onChange={(e) => setPaymentDetails(e.target.value)}
                  placeholder="e.g. name@paypal.com or +1 (555) 000-0000"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                />
                <p className="text-[10px] text-[#7C8AA8]">
                  Payouts will be routed to this verified PayPal account.
                </p>
              </div>
            )}

            {paymentMethod === 'Other' && (
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-slate-300">Manual Arrangement</label>
                <div className="w-full bg-[#111E33]/90 border border-amber-500/40 rounded-xl px-3.5 py-2.5 text-xs text-amber-300">
                  Please contact the agency directly (via your agent or portal messaging) to arrange payouts.
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Optional Note for Agency Treasury</label>
              <input
                type="text"
                value={paymentNote}
                onChange={(e) => setPaymentNote(e.target.value)}
                placeholder="Optional: preferred payout dates, physical card mailing address, or secondary notes"
                className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            {/* MANDATORY TAX COMPLIANCE CALLOUT */}
            <div className="bg-gradient-to-r from-purple-950/40 to-[#0A1528] border border-purple-500/30 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500/10 text-purple-300 rounded-lg shrink-0">
                  <Landmark className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white font-serif">
                    IRS Form W-9 Required for Payout Release
                  </h4>
                  <p className="text-[11px] text-slate-300">
                    Federal law requires certified Taxpayer Identification (SSN or EIN) before disbursements exceed $600.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveScreen('irs-tax-vault')}
                className="text-xs bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-400/40 px-3.5 py-2 rounded-xl font-mono font-bold shrink-0 flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              >
                <span>{w9Uploaded || w9Status === 'Verified' ? 'View W-9 Vault' : 'Complete Form W-9'}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Section 5: Tax & Legal Documentation (W-9 & 1099-NEC) */}
        <div className="border-t border-white/10 pt-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-[#C9A46A]" /> 5. Tax Paperwork &amp; 1099 Intake Forms (Fill Out &amp; Turn In)
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Fill out and turn in your official IRS Form W-9 / 1099 Taxpayer Intake paper online, or upload completed signed physical documents to Agency Accounting.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowTaxPaperModal(true)}
                className="bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
              >
                <FileText className="w-3.5 h-3.5" /> Fill Out &amp; Turn In Tax Paper
              </button>
              <span className="text-xs bg-purple-950/80 text-purple-300 border border-purple-500/30 px-3 py-1 rounded-xl font-mono font-semibold shrink-0 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-purple-400" /> IRS &amp; Agency Verified
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Form W-9 / 1099 Intake Paper Card */}
            <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4.5 space-y-3.5 shadow-md">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#C9A46A]">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">IRS Form W-9 &amp; 1099 Intake Paper</h4>
                    <p className="text-[11px] text-slate-400">Taxpayer Identification &amp; Certification Paperwork</p>
                  </div>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border ${
                  w9Uploaded 
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' 
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                }`}>
                  {w9Uploaded ? (w9Status === 'Verified' ? '✓ Paperwork Turned In & Verified' : '✓ Paperwork Turned In') : 'Turn-In Required'}
                </span>
              </div>

              {w9Uploaded ? (
                <div className="p-3 bg-[#0A1220] rounded-xl border border-white/5 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300 font-medium truncate">{w9FileName}</span>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] text-slate-500 font-mono">{w9FileSize}</span>
                      {w9FileData && (
                        <button
                          type="button"
                          onClick={() => {
                            const a = document.createElement('a');
                            a.href = w9FileData;
                            a.download = w9FileName || 'IRS_Form_W9.pdf';
                            a.click();
                          }}
                          className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 text-[#C9A46A] hover:text-white text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                          title="Download & View Paperwork"
                        >
                          <Eye className="w-3 h-3" /> View
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-white/5">
                    <span>Tax ID (SSN/EIN): <strong className="text-emerald-400 font-mono">{taxIdStatus}</strong></span>
                    <span className="text-[#C9A46A] font-semibold">Turned In to Accounting</span>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 leading-relaxed">
                  Required by IRS regulations. Complete and turn in your tax paper so agency accounting can disburse brand sponsorship funds and issue your 1099.
                </p>
              )}

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowTaxPaperModal(true)}
                  className="bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] rounded-xl py-2 px-3 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Fill &amp; Turn In Online</span>
                </button>

                <label className="flex-1 min-w-[130px] bg-[#16243F] hover:bg-[#1E3156] border border-white/10 text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5 text-[#C9A46A]" />
                  <span>{w9Uploaded ? 'Upload New Paper' : 'Upload Signed Paper'}</span>
                  <input
                    type="file"
                    accept=".pdf,image/*"
                    onChange={handleW9FileUpload}
                    className="hidden"
                  />
                </label>

                <button
                  type="button"
                  onClick={handleGenerateFilledW9}
                  className="bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/30 text-emerald-300 rounded-xl py-2 px-2.5 text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  title="Generate pre-filled W-9 PDF"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>PDF</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadBlankW9}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                  title="Download blank IRS Form W-9 from IRS.gov"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Form 1099-NEC Annual Statement Card */}
            <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4.5 space-y-3.5 shadow-md">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                    <FileCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">Form 1099-NEC Statement</h4>
                    <p className="text-[11px] text-slate-400">Annual Nonemployee Compensation Report</p>
                  </div>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border ${
                  tax1099Uploaded 
                    ? 'bg-purple-500/15 text-purple-300 border-purple-500/30' 
                    : 'bg-slate-500/15 text-slate-300 border-slate-500/30'
                }`}>
                  {tax1099Uploaded ? `✓ ${tax1099Status}` : 'Annual Filing Ready'}
                </span>
              </div>

              {tax1099Uploaded ? (
                <div className="p-3 bg-[#0A1220] rounded-xl border border-white/5 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-300 font-medium truncate">{tax1099FileName}</span>
                    <span className="text-[10px] text-slate-500 font-mono shrink-0">{tax1099FileSize}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-white/5">
                    <span>Tax Year: <strong className="text-purple-300 font-mono">{currentYear}</strong></span>
                    <span className="text-emerald-400 font-semibold">Compensation Logged</span>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-400 leading-relaxed">
                  Issued by Bloom &amp; Co. Agency Accounting every January reflecting total net nonemployee compensation paid.
                </p>
              )}

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <label className="flex-1 min-w-[130px] bg-[#16243F] hover:bg-[#1E3156] border border-white/10 text-white rounded-xl py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5 text-purple-400" />
                  <span>{tax1099Uploaded ? 'Upload 1099 Copy' : 'Upload 1099 Paper'}</span>
                  <input
                    type="file"
                    accept=".pdf,image/*"
                    onChange={handle1099FileUpload}
                    className="hidden"
                  />
                </label>

                <button
                  type="button"
                  onClick={handleGenerateFilled1099}
                  className="bg-purple-950/60 hover:bg-purple-900/80 border border-purple-500/30 text-purple-300 rounded-xl py-2 px-3 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  title="Generate annual 1099-NEC PDF"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download 1099</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadBlank1099}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                  title="Download blank IRS Form 1099-NEC from IRS.gov"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/5 pt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[11px] text-slate-400">
            Changes save directly to your creator record in Firestore.
          </p>
          <button
            type="submit"
            disabled={isSaving}
            className="w-full sm:w-auto bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-6 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-colors shadow-md cursor-pointer"
            style={{ backgroundColor: primaryBrandColor }}
          >
            {isSaving ? 'Saving Profile...' : 'Save Profile Changes'}
          </button>
        </div>
      </form>

      {/* Creator Referral Tracker */}
      <CreatorReferralTracker
        creatorHandle={handle}
        creatorName={name}
        referrals={referrals}
        onAddReferral={onAddReferral}
        triggerNotification={triggerNotification}
        onAddActivityLog={onAddActivityLog}
        primaryBrandColor={primaryBrandColor}
      />
    </div>
  )}

      {activeTab === 'briefs' && (
        <CreatorDealBriefsView
          deals={deals}
          currentUser={currentUser}
          currentRole="creator"
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onNavigateToSubmit={() => setActiveTab('submit-content')}
          onNavigateToMarketplace={() => setActiveTab('marketplace')}
          triggerNotification={triggerNotification}
        />
      )}

      {activeTab === 'marketplace' && (
        <CreatorCastingMarketplace currentUserHandle={currentUser?.handle || ''} />
      )}

      {activeTab === 'missions' && (
        <CreatorAssignedMissionsView
          missions={missions}
          currentUser={currentUser}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onNavigateToSubmit={() => setActiveTab('submit-content')}
          triggerNotification={triggerNotification}
        />
      )}

      {activeTab === 'escrow' && (
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-6 animate-fade-in shadow-xl" style={{ backgroundColor: cardBgColor }}>
          <div className="border-b border-white/10 pb-4">
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
              Personal Historical Payouts Only
            </span>
            <h2 className="font-serif font-bold text-xl text-white mt-1">Escrow Ledger & Payout History</h2>
            <p className="text-xs text-[#7C8AA8] mt-1">
              Review your historical earnings, cleared escrow disbursements, Stripe direct deposits, and downloadable tax receipts.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-4">
              <span className="text-[10px] uppercase font-mono text-[#7C8AA8]">Cleared & Paid Out</span>
              <p className="text-2xl font-bold font-mono text-emerald-400 mt-1">${(matchingCreator?.totalEarned || 18750).toLocaleString()}</p>
            </div>
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-4">
              <span className="text-[10px] uppercase font-mono text-[#7C8AA8]">In Escrow (Active)</span>
              <p className="text-2xl font-bold font-mono text-amber-300 mt-1">$3,400</p>
            </div>
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-4">
              <span className="text-[10px] uppercase font-mono text-[#7C8AA8]">Next Payout Window</span>
              <p className="text-lg font-bold text-white mt-1">Every Friday (Stripe)</p>
            </div>
          </div>
          <div className="space-y-3">
            <h3 className="text-xs uppercase font-mono tracking-wider text-[#C9A46A]">Recent Payout Transactions</h3>
            <div className="bg-[#111E33] border border-white/10 rounded-xl divide-y divide-white/5 text-xs">
              <div className="p-3.5 flex items-center justify-between">
                <div>
                  <p className="font-bold text-white">Campaign #882 - Sephora Glow</p>
                  <span className="text-[10px] text-slate-400 font-mono">Disbursed via Stripe • Aug 18, 2026</span>
                </div>
                <span className="font-mono font-bold text-emerald-400 text-sm">+$2,450.00</span>
              </div>
              <div className="p-3.5 flex items-center justify-between">
                <div>
                  <p className="font-bold text-white">Campaign #840 - Chewy VIP Box</p>
                  <span className="text-[10px] text-slate-400 font-mono">Disbursed via Stripe • Aug 11, 2026</span>
                </div>
                <span className="font-mono font-bold text-emerald-400 text-sm">+$1,850.00</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'gifting' && (
        <CreatorProductSamplesInventory
          currentCreatorHandle={handle || currentUser?.handle || '@elenarostova'}
          triggerNotification={triggerNotification}
        />
      )}

      {activeTab === 'fulfillment' && (
        <CreatorSampleFulfillmentTracker
          currentCreatorHandle={handle || currentUser?.handle || '@elenarostova'}
          triggerNotification={triggerNotification}
        />
      )}

      {activeTab === 'submit-content' && (
        <SubmitContent currentUser={currentUser} triggerNotification={triggerNotification} onAddActivityLog={onAddActivityLog} creators={creators || []} deals={deals || []} currentRole="creator" />
      )}

            {(activeTab === 'content-library' || activeTab === 'my-content') && (
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-6 animate-fade-in shadow-xl" style={{ backgroundColor: cardBgColor }}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 w-max">
                <Film className="w-3 h-3" /> Completed &amp; Delivered Deliverables Vault
              </span>
              <h2 className="font-serif font-bold text-2xl text-white mt-1.5">Content Library</h2>
              <p className="text-xs text-[#7C8AA8] mt-1">
                All approved video drafts, finished campaign deliverables, and published clips — automatically organized by approval date with full HD download and Spark Ad access.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3.5 py-2 rounded-xl shrink-0 self-start sm:self-auto flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" /> Auto-Vaulted Deliverables (Newest First)
            </span>
          </div>

          {/* Quick Stats Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-3.5">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Finished Videos</span>
              <span className="text-lg font-bold text-white font-mono mt-0.5 block">8 Completed</span>
              <span className="text-[10px] text-emerald-400 font-mono">✓ 100% On-Time</span>
            </div>
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-3.5">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Total Views</span>
              <span className="text-lg font-bold text-[#C9A46A] font-mono mt-0.5 block">468.9K Views</span>
              <span className="text-[10px] text-slate-400 font-mono">Organic &amp; Spark Ads</span>
            </div>
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-3.5">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Avg Engagement</span>
              <span className="text-lg font-bold text-emerald-400 font-mono mt-0.5 block">8.4%</span>
              <span className="text-[10px] text-slate-400 font-mono">+2.1% Industry Avg</span>
            </div>
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-3.5">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Brand Satisfaction</span>
              <span className="text-lg font-bold text-amber-300 font-mono mt-0.5 block">5.0 ★★★★★</span>
              <span className="text-[10px] text-slate-400 font-mono">0 Re-shoots Requested</span>
            </div>
          </div>

          {/* Search & Platform Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#111E33] border border-white/10 rounded-xl p-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by brand or video title..."
                value={contentSearchQuery}
                onChange={(e) => setContentSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-[#080E1A] border border-white/10 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              {['All', 'TikTok', 'Instagram', 'YouTube', 'Commercial'].map((plat) => (
                <button
                  key={plat}
                  onClick={() => setContentPlatformFilter(plat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                    contentPlatformFilter === plat
                      ? 'bg-[#C9A46A] text-[#0A1220]'
                      : 'bg-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  {plat}
                </button>
              ))}
            </div>
          </div>

          {/* Finished Deliverables Grid */}
          {(() => {
            const defaultDeliverables = [
              {
                id: 'lib_1',
                title: 'Glossier You Solid Fragrance Lifestyle Vlog',
                brand: 'Glossier',
                platform: 'TikTok (Spark Ads)',
                duration: '0:45',
                approvedDate: '2026-08-27',
                status: 'Approved & Finished',
                fileSize: '48.2 MB',
                videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-skincare-cream-41527-large.mp4',
                thumbnail: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80',
                sparkCode: 'SPARK-GLOSSIER-2026-X89',
                views: '210,000',
                likes: '18.4K',
                engagement: '9.2%'
              },
              {
                id: 'lib_2',
                title: 'Dyson Airwrap Multi-Styler Hair Tutorial Reel',
                brand: 'Dyson Beauty',
                platform: 'Instagram Reel',
                duration: '0:58',
                approvedDate: '2026-08-22',
                status: 'Approved & Finished',
                fileSize: '62.1 MB',
                videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-young-woman-touching-her-hair-41528-large.mp4',
                thumbnail: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&auto=format&fit=crop&q=80',
                sparkCode: 'N/A (Organic Reel)',
                views: '124,500',
                likes: '11.2K',
                engagement: '8.4%'
              },
              {
                id: 'lib_3',
                title: 'Summer Fridays Lip Butter Balm ASMR Unboxing',
                brand: 'Summer Fridays',
                platform: 'TikTok Video',
                duration: '0:32',
                approvedDate: '2026-08-18',
                status: 'Approved & Finished',
                fileSize: '32.1 MB',
                videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hand-holding-a-beauty-product-bottle-41530-large.mp4',
                thumbnail: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&auto=format&fit=crop&q=80',
                sparkCode: 'SPARK-SUMMER-BALM-902',
                views: '89,200',
                likes: '8.7K',
                engagement: '9.1%'
              },
              {
                id: 'lib_4',
                title: 'Botanical Firming Serum Morning Routine',
                brand: 'Glow Recipe',
                platform: 'YouTube Shorts',
                duration: '0:40',
                approvedDate: '2026-08-10',
                status: 'Approved & Finished',
                fileSize: '29.4 MB',
                videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-smiling-with-natural-makeup-41529-large.mp4',
                thumbnail: 'https://images.unsplash.com/photo-1608248597261-e4d0450cbf13?w=800&auto=format&fit=crop&q=80',
                sparkCode: 'N/A',
                views: '45,200',
                likes: '3.9K',
                engagement: '6.8%'
              },
              {
                id: 'lib_5',
                title: 'Flush Balm Cream Blush First Impressions',
                brand: 'Merit Beauty',
                platform: 'Instagram Reel',
                duration: '0:35',
                approvedDate: '2026-08-02',
                status: 'Approved & Finished',
                fileSize: '38.6 MB',
                videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-makeup-41527-large.mp4',
                thumbnail: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=800&auto=format&fit=crop&q=80',
                sparkCode: 'N/A',
                views: '98,400',
                likes: '7.8K',
                engagement: '8.1%'
              }
            ];

            const creatorHandle = (currentUser?.handle || '').toLowerCase().replace('@', '');
            const creatorName = (currentUser?.name || '').toLowerCase();

            // 1. Dynamic approved items from reviews list
            const approvedFromReviews = (contentReviewsList || [])
              .filter(r => {
                const rCreator = (r.creator || '').toLowerCase().replace('@', '');
                const isMyContent = !creatorHandle || rCreator === creatorHandle || rCreator === creatorName;
                return r.status === 'Approved' && isMyContent;
              })
              .map(r => ({
                id: r.id,
                title: `${r.brand} — ${r.contentType}`,
                brand: r.brand,
                platform: r.platform || 'Instagram',
                duration: '0:45',
                approvedDate: r.submittedAt || new Date().toISOString().split('T')[0],
                status: 'Approved & Finished',
                fileSize: '24.5 MB',
                videoUrl: r.mediaUrl || 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-skincare-cream-41527-large.mp4',
                thumbnail: r.mediaUrl || 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80',
                sparkCode: `SPARK-${r.brand.toUpperCase().replace(/\s+/g, '')}-2026`,
                views: '15,200',
                likes: '1.5K',
                engagement: '8.8%'
              }));

            // 2. Dynamic approved items from Content Vault storage
            let vaultAssets: any[] = [];
            try {
              const raw = safeStorage.getItem('wl_content_library_assets') || safeStorage.getItem('wl_content_vault_assets');
              if (raw) {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed)) {
                  vaultAssets = parsed
                    .filter((a: any) => {
                      const aCreator = (a.creator || '').toLowerCase().replace('@', '');
                      const isMyContent = !creatorHandle || aCreator === creatorHandle || aCreator === creatorName;
                      return a.status === 'Approved' && isMyContent;
                    })
                    .map((a: any) => ({
                      id: a.id,
                      title: a.title || `${a.brand} Deliverable`,
                      brand: a.brand || 'Campaign Brand',
                      platform: a.platform || 'TikTok',
                      duration: a.duration || '0:45',
                      approvedDate: a.approvedAt ? a.approvedAt.split('T')[0] : '2026-09-14',
                      status: 'Approved & Finished',
                      fileSize: a.fileSize || '24.5 MB',
                      videoUrl: a.mediaUrl || a.videoUrl || 'https://assets.mixkit.co/videos/preview/mixkit-woman-applying-skincare-cream-41527-large.mp4',
                      thumbnail: a.thumbnailUrl || a.thumbnail || 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80',
                      sparkCode: `SPARK-${(a.brand || 'UGC').toUpperCase().replace(/\s+/g, '')}-2026`,
                      views: a.views ? `${a.views}` : '18,500',
                      likes: '1.8K',
                      engagement: a.engagement || '9.1%'
                    }));
                }
              }
            } catch {}

            // Combine approved deliverables first, followed by default templates
            const seenIds = new Set<string>();
            const libraryDeliverables: any[] = [];
            [...approvedFromReviews, ...vaultAssets, ...defaultDeliverables].forEach(item => {
              if (!seenIds.has(item.id)) {
                seenIds.add(item.id);
                libraryDeliverables.push(item);
              }
            });

            const filtered = libraryDeliverables.filter(item => {
              const matchesSearch = item.title.toLowerCase().includes(contentSearchQuery.toLowerCase()) ||
                                    item.brand.toLowerCase().includes(contentSearchQuery.toLowerCase());
              const matchesPlatform = contentPlatformFilter === 'All' || item.platform.toLowerCase().includes(contentPlatformFilter.toLowerCase());
              return matchesSearch && matchesPlatform;
            });

            return (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filtered.map((item) => (
                  <div key={item.id} className="bg-[#111E33] border border-white/10 rounded-2xl overflow-hidden space-y-0 hover:border-[#C9A46A]/50 transition-all shadow-md group">
                    {/* Card Media Preview Header */}
                    <button
                      type="button"
                      className="relative h-44 bg-slate-900 overflow-hidden cursor-pointer w-full text-left border-none p-0 block group-hover:scale-[1.01] transition-transform"
                      onClick={() => setPreviewVideoModal(item)}
                      aria-label={`Preview video for ${item.brand}: ${item.title}`}
                    >
                      <img src={item.thumbnail} alt={`Thumbnail for ${item.brand} content`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-80" />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0D1830] via-black/20 to-transparent" />
                      
                      {/* Play overlay button */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 rounded-full bg-[#C9A46A] text-[#0A1220] flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                          <Play className="w-6 h-6 fill-current ml-0.5" />
                        </div>
                      </div>

                      <div className="absolute top-3 left-3 flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold font-mono bg-black/60 backdrop-blur-md text-[#C9A46A] border border-[#C9A46A]/30">
                          {item.brand}
                        </span>
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold font-mono bg-black/60 backdrop-blur-md text-slate-200 border border-white/20">
                          {item.platform}
                        </span>
                      </div>

                      <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-md bg-black/70 text-[10px] font-mono text-white flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {item.duration}
                      </div>
                    </button>

                    {/* Card Content Body */}
                    <div className="p-4 space-y-3">
                      <div>
                        <h4 className="font-bold text-white text-sm leading-snug">{item.title}</h4>
                        <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2 font-mono">
                          <span>Finished: {item.approvedDate}</span>
                          <span>•</span>
                          <span>{item.fileSize}</span>
                        </p>
                      </div>

                      {/* Performance Bar */}
                      <div className="grid grid-cols-3 gap-2 bg-[#080E1A] border border-white/5 rounded-xl p-2.5 text-center font-mono">
                        <div>
                          <span className="text-[9px] text-slate-500 block uppercase">Views</span>
                          <strong className="text-emerald-400 text-xs">{item.views}</strong>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-500 block uppercase">Likes</span>
                          <strong className="text-amber-300 text-xs">{item.likes}</strong>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-500 block uppercase">Engagement</span>
                          <strong className="text-[#C9A46A] text-xs">{item.engagement}</strong>
                        </div>
                      </div>

                      {/* Spark Ads Code if present */}
                      {item.sparkCode && item.sparkCode !== 'N/A' && (
                        <div className="flex items-center justify-between bg-[#081326] border border-[#C9A46A]/20 rounded-lg p-2 text-xs font-mono">
                          <span className="text-[10px] text-slate-400">Spark Code: <strong className="text-[#C9A46A]">{item.sparkCode}</strong></span>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(item.sparkCode);
                              triggerNotification('Spark Code Copied', `Copied ${item.sparkCode} to clipboard!`, 'success');
                            }}
                            className="px-2 py-1 bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 text-[#C9A46A] rounded text-[10px] font-bold cursor-pointer"
                          >
                            Copy Code
                          </button>
                        </div>
                      )}

                      {/* Action Bar */}
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setPreviewVideoModal(item)}
                          className="flex-1 py-2 bg-white/5 hover:bg-white/10 text-slate-200 rounded-xl text-xs font-bold font-mono flex items-center justify-center gap-1.5 cursor-pointer transition"
                        >
                          <Play className="w-3.5 h-3.5 text-[#C9A46A]" /> Watch Preview
                        </button>

                        <button
                          type="button"
                          onClick={() => triggerNotification('Download Started', `Downloading HD MP4 for ${item.title}...`, 'success')}
                          className="flex-1 py-2 bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] rounded-xl text-xs font-bold font-mono flex items-center justify-center gap-1.5 cursor-pointer transition shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> Download HD
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>
      )}

      {activeTab === 'announcements' && (
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-6 animate-fade-in shadow-xl" style={{ backgroundColor: cardBgColor }}>
          <div className="border-b border-white/10 pb-4">
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
              Agency Broadcasts & Memos
            </span>
            <h2 className="font-serif font-bold text-xl text-white mt-1">Creator Announcements</h2>
            <p className="text-xs text-[#7C8AA8] mt-1">Important updates from executive leadership and management.</p>
          </div>
          <div className="bg-[#111E33] border border-white/10 rounded-xl p-5 space-y-2 border-l-4 border-l-[#C9A46A]">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#C9A46A] font-mono font-bold uppercase">Executive Memo</span>
              <span className="text-slate-400">August 20, 2026</span>
            </div>
            <h3 className="font-bold text-white text-base">Q3 Brand Partnership Bonus Program Announced</h3>
            <p className="text-xs text-slate-300">Creators completing 3+ UGC campaigns this month receive a 5% bonus on net payouts.</p>
          </div>
        </div>
      )}

      {activeTab === 'training' && (
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-6 animate-fade-in shadow-xl" style={{ backgroundColor: cardBgColor }}>
          <div className="border-b border-white/10 pb-4">
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
              Academy & Knowledge Base
            </span>
            <h2 className="font-serif font-bold text-xl text-white mt-1">Creator Training & SOPs</h2>
            <p className="text-xs text-[#7C8AA8] mt-1">Master filming lighting, FTC disclosures, and hook optimization for maximum sponsorship renewal.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-4 space-y-2">
              <span className="text-[10px] text-[#C9A46A] font-mono font-bold uppercase">SOP #101</span>
              <h4 className="font-bold text-white text-sm">FTC Disclosure Guidelines for UGC Videos</h4>
              <p className="text-slate-300">Learn how to place #ad or #sponsored in the first 3 lines of video captions to ensure 100% compliance.</p>
            </div>
          </div>
        </div>
      )}

      {(activeTab === 'my-portfolio' || activeTab === 'mediakit') && (
        <div className="space-y-6">
          <PublicCreatorPortfolio
            initialCreatorHandle={handle || currentUser?.handle || '@elenarostova'}
            onNavigateHome={() => setActiveTab('profile')}
            currentRole="creator"
          />
        </div>
      )}
    </div>
  );

      {/* Video Preview Modal */}
      {previewVideoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl relative">
            <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#111E33]">
              <div>
                <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold">{previewVideoModal.brand} • {previewVideoModal.platform}</span>
                <h3 className="font-bold text-white text-base">{previewVideoModal.title}</h3>
              </div>
              <button onClick={() => setPreviewVideoModal(null)} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-4">
              <div className="relative aspect-video bg-black rounded-xl overflow-hidden flex items-center justify-center border border-white/10">
                <video src={previewVideoModal.videoUrl} controls autoPlay className="w-full h-full object-contain" />
              </div>

              <div className="grid grid-cols-3 gap-2 bg-[#080E1A] p-3 rounded-xl text-center text-xs font-mono">
                <div>
                  <span className="text-[9px] text-slate-500 uppercase block">Total Views</span>
                  <strong className="text-emerald-400">{previewVideoModal.views}</strong>
                </div>
                <div>
                  <span className="text-[9px] text-slate-500 uppercase block">Likes</span>
                  <strong className="text-amber-300">{previewVideoModal.likes || '12.4K'}</strong>
                </div>
                <div>
                  <span className="text-[9px] text-slate-500 uppercase block">Engagement</span>
                  <strong className="text-[#C9A46A]">{previewVideoModal.engagement}</strong>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => triggerNotification('Download HD Asset', `Downloading HD Video file for ${previewVideoModal.title}...`, 'success')}
                  className="px-4 py-2 bg-[#C9A46A] text-[#0A1220] font-bold text-xs rounded-xl hover:bg-[#b89359] cursor-pointer flex items-center gap-2"
                >
                  <Download className="w-4 h-4" /> Download HD Video File
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Portfolio Modal */}
      {editPortfolioModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-[#C9A46A]" /> Edit My Personal Portfolio
              </h3>
              <button onClick={() => setEditPortfolioModal(false)} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs max-h-[70vh] overflow-y-auto pr-1">
              <div>
                <label className="block text-slate-400 font-mono mb-1">Display Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-[#111E33] border border-white/10 rounded-xl text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">Primary Niche / Specialties</label>
                <input
                  type="text"
                  value={niche}
                  onChange={(e) => setNiche(e.target.value)}
                  className="w-full p-2.5 bg-[#111E33] border border-white/10 rounded-xl text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">Bio / Creator Statement</label>
                <textarea
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full p-2.5 bg-[#111E33] border border-white/10 rounded-xl text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-mono mb-1">TikTok Followers</label>
                  <input
                    type="text"
                    value={tiktokFollowers}
                    onChange={(e) => setTiktokFollowers(e.target.value)}
                    className="w-full p-2.5 bg-[#111E33] border border-white/10 rounded-xl text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">Instagram Followers</label>
                  <input
                    type="text"
                    value={instagramFollowers}
                    onChange={(e) => setInstagramFollowers(e.target.value)}
                    className="w-full p-2.5 bg-[#111E33] border border-white/10 rounded-xl text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-mono mb-1">Single UGC Video Rate</label>
                  <input
                    type="text"
                    value={rateSingleReel}
                    onChange={(e) => setRateSingleReel(e.target.value)}
                    className="w-full p-2.5 bg-[#111E33] border border-white/10 rounded-xl text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">3-Video Bundle Rate</label>
                  <input
                    type="text"
                    value={rateBundle3}
                    onChange={(e) => setRateBundle3(e.target.value)}
                    className="w-full p-2.5 bg-[#111E33] border border-white/10 rounded-xl text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
              <button onClick={() => setEditPortfolioModal(false)} className="px-4 py-2 bg-white/5 text-slate-300 font-mono text-xs rounded-xl hover:bg-white/10 cursor-pointer">
                Cancel
              </button>
              <button
                onClick={() => {
                  setEditPortfolioModal(false);
                  triggerNotification('Portfolio Updated', 'Your creator portfolio & rate card changes have been saved!', 'success');
                }}
                className="px-5 py-2 bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] font-bold font-mono text-xs rounded-xl cursor-pointer shadow-md"
              >
                Save Portfolio
              </button>
            </div>
          </div>
        </div>
      )}

};
