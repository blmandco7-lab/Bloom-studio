import React, { useState, useEffect } from 'react';
import { 
  Users, Bot, ShieldAlert, Sparkles, Calendar, Scale, TrendingUp, UserPlus, Briefcase, 
  Settings, Key, Layers, Ban, Volume2, Award, Download, ClipboardList, Send, Plus, 
  Trash2, Mail, Check, AlertCircle, Play, Pause, RefreshCw, Star, DollarSign, FileText,
  Activity, Heart, ArrowUpRight, CheckCircle, HelpCircle, BookOpen, Clock, Lock, FileCheck,
  Upload, CheckCircle2, Building2, Search, Filter, Edit, Eye, EyeOff, X, ChevronDown, CheckSquare,
  FolderGit2, FilePlus, ExternalLink, Shield, FileSignature, User,
  Calculator, Sliders, Percent, Gift, Copy, Printer, Zap, CheckCheck, Settings2, ShieldCheck,
  Smartphone, Bell, Share2, Globe, Radio, ChevronLeft, ChevronRight, ToggleLeft, ToggleRight,
  Link2, CheckCircle as CheckCircleIcon, Wifi, WifiOff, ArrowRight, CalendarDays, Database
} from 'lucide-react';
import { doc, setDoc, deleteDoc, collection, addDoc, getDocs, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Creator, Deal, Invoice, Role } from '../types';
import { formatCsvRow, sanitizeCsvCell } from '../utils/security';
import { 
  subscribeTenantUsers, 
  setUserRoleInFirestore, 
  saveTenantConfigInFirestore, 
  getAuthHeaders,
  subscribeInviteApplications,
  approveInviteApplicationInFirestore,
  deleteInviteApplicationInFirestore,
  subscribeInviteCodes,
  saveInviteCodeInFirestore
} from '../lib/firebase';
import DeleteConfirmationModal, { DeleteConfirmConfig } from './DeleteConfirmationModal';
import DaysUntilExpiryBadge from './DaysUntilExpiryBadge';
import { UnifiedCalendarHub } from './UnifiedCalendarHub';
import { generateSecureInviteCode } from '../utils/cryptoUtils';
import { safeStorage } from '../utils/safeStorage';
import { EmergencyKillSwitchPanel } from './EmergencyKillSwitchControls';
import { MaintenanceConfig, getStoredMaintenanceConfig, subscribeMaintenanceConfig } from '../lib/maintenanceConfig';
import { 
  addBrandToGlobalBlacklist, 
  removeBrandFromGlobalBlacklist, 
  checkBrandBlacklist, 
  isBrandBlacklistedSync,
  BlacklistEntry 
} from '../lib/blacklistService';
const localStorage = safeStorage;

function cleanForFirestore(obj: any): any {
  return JSON.parse(JSON.stringify(obj));
}

interface OperationBoardProps {
  tenantId?: string;
  activeScreen: string;
  creators: Creator[];
  deals: Deal[];
  invoices: Invoice[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  agencyName?: string;
  setAgencyName?: (val: string) => void;
  legalEntityName?: string;
  setLegalEntityName?: (val: string) => void;
  primaryBrandColor?: string;
  setPrimaryBrandColor?: (val: string) => void;
  sidebarBgColor?: string;
  setSidebarBgColor?: (val: string) => void;
  mainDashboardBg?: string;
  setMainDashboardBg?: (val: string) => void;
  cardBgColor?: string;
  setCardBgColor?: (val: string) => void;
  textMainColor?: string;
  setTextMainColor?: (val: string) => void;
  textMutedColor?: string;
  setTextMutedColor?: (val: string) => void;
  navCategoriesState?: any[];
  setNavCategoriesState?: (val: any[]) => void;
  interceptedMails?: any[];
  setInterceptedMails?: React.Dispatch<React.SetStateAction<any[]>>;
  currentUser?: any;
  currentRole?: string;
  setCreators?: React.Dispatch<React.SetStateAction<Creator[]>>;
  directorName?: string;
  setDirectorName?: (val: string) => void;
  systemLogo?: string;
  setSystemLogo?: (val: string) => void;
  vslVideoUrl?: string;
  setVslVideoUrl?: (val: string) => void;
  activityLogs?: any[];
  setActivityLogs?: React.Dispatch<React.SetStateAction<any[]>>;
  actionQueue?: any[];
  setActionQueue?: React.Dispatch<React.SetStateAction<any[]>>;
  talentApplications?: any[];
  setTalentApplications?: React.Dispatch<React.SetStateAction<any[]>>;
  onboardingItems?: any[];
  setOnboardingItems?: React.Dispatch<React.SetStateAction<any[]>>;
  agencySchedules?: any[];
  setAgencySchedules?: React.Dispatch<React.SetStateAction<any[]>>;
  setDeals?: React.Dispatch<React.SetStateAction<any[]>>;
  setActiveScreen?: (val: string) => void;
  onRequestRoleSwitch?: (targetRole: Role, customUser?: any) => void;
  missions?: any[];
  setMissions?: React.Dispatch<React.SetStateAction<any[]>>;
  announcements?: any[];
  setAnnouncements?: React.Dispatch<React.SetStateAction<any[]>>;
  onPurgeSeedData?: () => Promise<void>;
  onMigrateCreatorsToStudio?: () => Promise<void>;
  onRunSubagencyBackfill?: () => Promise<void>;
  agentMgrCanAnnounce?: boolean;
  setAgentMgrCanAnnounce?: (val: boolean) => void;
  agentManagerCanAddCampaigns?: boolean;
  agentManagerCanAddToPortfolio?: boolean;
  agentManagerCanDraftBriefs?: boolean;
  onSendMassBroadcast?: (payload: any, options: any) => Promise<void>;
  onOpenMassBroadcast?: () => void;
}

export default function OperationBoard({ 
  activeScreen, 
  setActiveScreen,
  onRequestRoleSwitch,
  creators, 
  deals, 
  setDeals,
  invoices,
  onAddActivityLog, 
  triggerNotification,
  agencyName = 'Bloom Studio',
  setAgencyName,
  legalEntityName = 'Bloom & Co',
  setLegalEntityName,
  primaryBrandColor = '#c7a77d',
  setPrimaryBrandColor,
  sidebarBgColor = '#0f1a2c',
  setSidebarBgColor,
  mainDashboardBg = '#0b1424',
  setMainDashboardBg,
  cardBgColor = '#152238',
  setCardBgColor,
  textMainColor = '#ffffff',
  setTextMainColor,
  textMutedColor = '#6b7c96',
  setTextMutedColor,
  navCategoriesState = [],
  setNavCategoriesState,
  interceptedMails = [],
  setInterceptedMails,
  currentUser,
  currentRole,
  setCreators,
  directorName = 'Director',
  setDirectorName,
  systemLogo = '',
  setSystemLogo,
  vslVideoUrl = '',
  setVslVideoUrl,
  activityLogs = [],
  setActivityLogs,
  actionQueue = [],
  setActionQueue,
  talentApplications = [],
  setTalentApplications,
  onboardingItems: propOnboardingItems = [],
  setOnboardingItems: propSetOnboardingItems,
  agencySchedules: propAgencySchedules = [],
  setAgencySchedules: propSetAgencySchedules,
  missions = [],
  setMissions,
  announcements: propAnnouncements,
  setAnnouncements: propSetAnnouncements,
  tenantId,
  onPurgeSeedData,
  onMigrateCreatorsToStudio,
  onRunSubagencyBackfill,
  agentMgrCanAnnounce = false,
  setAgentMgrCanAnnounce,
  agentManagerCanAddCampaigns = false,
  agentManagerCanAddToPortfolio = false,
  agentManagerCanDraftBriefs = false,
  onSendMassBroadcast,
  onOpenMassBroadcast
}: OperationBoardProps) {

  const activeTenantId = tenantId || 'bloom_studio_default';

  const [maintenanceConfig, setMaintenanceConfig] = useState<MaintenanceConfig>(getStoredMaintenanceConfig);
  const [showPhoneMessagesAlert, setShowPhoneMessagesAlert] = useState<boolean>(() => {
    return safeStorage.getItem('wl_show_phone_messages_alert') === 'true';
  });

  useEffect(() => {
    const unsub = subscribeMaintenanceConfig((cfg) => {
      setMaintenanceConfig(cfg);
    });
    return () => unsub();
  }, []);

  const onNavigate = (screen: string) => {
    if (setActiveScreen) setActiveScreen(screen);
  };

  const handleRequestRoleSwitch = (targetRole: Role, customUser?: any) => {
    if (onRequestRoleSwitch) {
      onRequestRoleSwitch(targetRole, customUser);
    } else if (setActiveScreen) {
      setActiveScreen(targetRole === 'creator' ? 'creator-dash' : 'agent-dash');
    }
  };

  const handleRunWatchdogScan = () => {
    if (!scanInputText.trim()) {
      triggerNotification('Validation Error', 'Please paste some outreach copy or direct email text to scan.', 'warning');
      return;
    }
    
    const text = scanInputText.toLowerCase();
    const brand = scanSenderBrand.trim() || 'Unknown Brand Scout';
    
    let score = 0;
    const keywords: string[] = [];
    
    // Check various violation vectors
    if (text.includes('bypass') || text.includes('cut out') || text.includes('middlemen') || text.includes('directly') || text.includes('bypass agency')) {
      score += 35;
      keywords.push('BYPASS_CIRCUMVENTION');
    }
    if (text.includes('venmo') || text.includes('paypal') || text.includes('cash') || text.includes('under the table') || text.includes('wire') || text.includes('bitcoin') || text.includes('zelle') || text.includes('personal bank') || text.includes('private deal')) {
      score += 35;
      keywords.push('OFF_PLATFORM_PAYMENT');
    }
    if (text.includes('agency fee') || text.includes('markup') || text.includes('commission') || text.includes('cut') || text.includes('charge') || text.includes('fee avoidance')) {
      score += 20;
      keywords.push('FEE_AVOIDANCE');
    }
    if (text.includes('personal email') || text.includes('gmail.com') || text.includes('@') || text.includes('direct email') || text.includes('phone') || text.includes('whatsapp') || text.includes('text me')) {
      score += 15;
      keywords.push('CONTACT_STEALING');
    }
    if (text.includes('exclusive') || text.includes('non-exclusive') || text.includes('contract') || text.includes('agreement') || text.includes('break') || text.includes('steal')) {
      score += 10;
      keywords.push('CONTRACT_POACHING');
    }
    
    // Cap score at 100
    const finalScore = Math.min(score, 100);
    
    let rating: 'None' | 'Low Risk' | 'Medium Risk' | 'High Risk' | 'Critical Bypass Attempt' = 'None';
    let status = 'CLEARED_COMMUNICATION';
    let explainer = 'The message looks standard and does not appear to contain any patterns of solicitation bypass, off-platform payment routing, or anti-circumvention violations.';
    
    if (finalScore >= 70) {
      rating = 'Critical Bypass Attempt';
      status = 'INTERCEPT_REQUIRED';
      explainer = 'CRITICAL: High confidence circumvention attempt detected! The brand is explicitly attempting to bypass agency escrow, proposing off-platform payments (e.g. Venmo/cash), or asking to take communications offline to steal the creator relation.';
    } else if (finalScore >= 45) {
      rating = 'High Risk';
      status = 'REVIEW_RECOMMENDED';
      explainer = 'HIGH RISK: Suspected poaching behavior. Language patterns suggest off-platform contact redirection or agency fee avoidance tactics. Keep creator communications strictly locked in-portal.';
    } else if (finalScore >= 20) {
      rating = 'Medium Risk';
      status = 'MONITORING_ACTIVE';
      explainer = 'MEDIUM RISK: Mild solicitation indicators. The brand is requesting direct contact variables or referencing platform commissions. Monitor closely.';
    } else if (finalScore > 0) {
      rating = 'Low Risk';
      status = 'FLAGGED_PREVENTATIVE';
      explainer = 'LOW RISK: Minor match of trigger terms, likely standard discussion of contact points. Standard security filtering active.';
    }
    
    setScanResults({
      scanned: true,
      threatScore: finalScore,
      flaggedKeywords: keywords,
      riskRating: rating,
      status,
      explainer
    });

    if (finalScore >= 45) {
      const newIntercept = {
        id: "int_" + Date.now(),
        brandId: brand,
        sender: brand,
        creatorId: scanTargetCreator,
        receiver: scanTargetCreator,
        reason: keywords[0] || "BYPASS_ATTEMPT",
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
        flaggedContent: scanInputText
      };
      const updated = [newIntercept, ...localIntercepts];
      setLocalIntercepts(updated);
      localStorage.setItem('wl_intercepted_mails', JSON.stringify(updated));
      
      triggerNotification(
        '⚠️ Solicitation Intercepted', 
        `Security filters successfully blocked a circumvention attempt from ${brand} targeting ${scanTargetCreator}.`, 
        'danger'
      );
    } else {
      triggerNotification(
        '✓ Scan Completed', 
        `Bloom Security Watchdog cleared the scan with a ${finalScore}% threat score.`, 
        'success'
      );
    }
  };

  // --- CORE INTEGRATED STATES ---
  const [botsActive, setBotsActive] = useState(true);
  const [brandingTab, setBrandingTab] = useState<'visual' | 'security'>('visual');
  const [simulationResponse, setSimulationResponse] = useState<{ status: 'idle' | 'success' | 'error'; message: string; code?: string } | null>(null);
  const [podApprovalSort, setPodApprovalSort] = useState<'newest' | 'oldest' | 'role' | 'status'>('newest');
  const [deleteConfirmConfig, setDeleteConfirmConfig] = useState<DeleteConfirmConfig | null>(null);

  // --- BRAND SOLICITATION WATCHDOG STATES ---
  const [localIntercepts, setLocalIntercepts] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_intercepted_mails');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: "int_1",
        brandId: "FashionNova Campaign Manager",
        sender: "FashionNova Outreach Team",
        creatorId: "@elena_style",
        receiver: "@elena_style",
        reason: "DIRECT_POACHING_ATTEMPT",
        timestamp: "2026-09-14 14:32:05",
        flaggedContent: "Hey Elena, we saw your Bloom Studio contract is active but we would love to bypass your agency managers and wire you $4,000 on Venmo directly. We can send clothing directly to your personal address if you send it to fashionnova-pr-direct@gmail.com."
      },
      {
        id: "int_2",
        brandId: "Gymshark Talent Scout",
        sender: "Gymshark Sponsor Rep",
        creatorId: "@alex_fitness",
        receiver: "@alex_fitness",
        reason: "BYPASS_AGENCY_FEE",
        timestamp: "2026-09-13 09:12:44",
        flaggedContent: "Alex, love the fitness posts. Gymshark has a spot on our roster but we notice Bloom Studio charges a 20% agency markup. If you work with us under the table without registering it in your agency portal, we can pay you $2,500 cash."
      },
      {
        id: "int_3",
        brandId: "Prime Hydration Promo Team",
        sender: "Prime Influencer Outreach",
        creatorId: "@sophiarose",
        receiver: "@sophiarose",
        reason: "OFF_PLATFORM_CONTRACT",
        timestamp: "2026-09-12 18:22:10",
        flaggedContent: "Hey Sophia, we have an exclusive package for you. Don't reply here, email our direct PR at prime-outreach-bypass@gmail.com. Let's do a non-exclusive deal and cut out the middlemen at Bloom & Co!"
      }
    ];
  });

  const [scanInputText, setScanInputText] = useState('');
  const [scanTargetCreator, setScanTargetCreator] = useState('@elena_style');
  const [scanSenderBrand, setScanSenderBrand] = useState('');
  const [scanResults, setScanResults] = useState<{
    scanned: boolean;
    threatScore: number;
    flaggedKeywords: string[];
    riskRating: 'None' | 'Low Risk' | 'Medium Risk' | 'High Risk' | 'Critical Bypass Attempt';
    status: string;
    explainer: string;
  } | null>(null);

  // Creative Campaign Brief Builder States
  const [briefCreatorHandle, setBriefCreatorHandle] = useState('');
  const [briefBrandName, setBriefBrandName] = useState('Bloom Botanical Skincare');
  const [briefTitle, setBriefTitle] = useState('Summer Botanical Serum UGC Brief');
  const [briefDeliverables, setBriefDeliverables] = useState('1x 9:16 Short-Form Video + Paid Usage Rights');
  const [briefContent, setBriefContent] = useState('Create a high-energy 15-30 second TikTok/Reel demonstrating the Summer Botanical Serum application. Focus on natural sunlight skin glow and cold-pressed botanical extract benefits.');
  const [briefHooks, setBriefHooks] = useState('"Stop using water-diluted serum in 2026..."\n"Here is why cold-pressed botanical oil transformed my morning routine..."');
  const [briefPayout, setBriefPayout] = useState('$3,500 Escrow Payout');

  // User Accounts & Invite Codes States with Real-Time Firestore Synchronization
  const [userAccounts, setUserAccounts] = useState<any[]>(() => {
    const defaultAccounts = [
      { id: "u1", name: "Agency Director", email: "director@bloomstudio.com", role: "director", status: "Active", handle: "@director", pod: "Bloom & Co", joined: "2026-01-01" },
      { id: "u2", name: "Agency Lead", email: "lead@bloomstudio.com", role: "agentmgr", status: "Active", handle: "@agency_lead", pod: "Bloom & Co", joined: "2026-02-10" }
    ];
    const saved = localStorage.getItem('wl_user_accounts');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const filtered = parsed.filter((p: any) => p.name !== "Sarah Jenkins" && p.name !== "David Beckham Jr" && p.name !== "David Sterling");
          const missing = defaultAccounts.filter(def => !filtered.some((p: any) => p.id === def.id || p.email === def.email));
          return [...filtered, ...missing];
        }
      } catch(e) { console.error(e); }
    }
    return defaultAccounts;
  });

  const [rawFirestoreUsers, setRawFirestoreUsers] = useState<any[]>([]);
  const [inviteApplications, setInviteApplications] = useState<any[]>([]);

  // 1. Real-time subscription to registered tenant users in Firestore
  useEffect(() => {
    const unsub = subscribeTenantUsers(activeTenantId, (users) => {
      if (users && users.length > 0) {
        setRawFirestoreUsers(users);
      }
    });
    return () => unsub();
  }, [activeTenantId]);

  // 2. Real-time subscription to durable invite applications across all devices
  useEffect(() => {
    const unsub = subscribeInviteApplications((apps) => {
      if (apps) {
        setInviteApplications(apps);
      }
    });
    return () => unsub();
  }, []);

  // 3. Merging logic: combines registered users and pending invite applications into unified real-time roster
  useEffect(() => {
    const mergedMap = new Map<string, any>();

    const defaultAccounts = [
      { id: "u1", name: "Agency Director", email: "director@bloomstudio.com", role: "director", status: "Active", handle: "@director", pod: "Bloom & Co", joined: "2026-01-01" },
      { id: "u2", name: "Agency Lead", email: "lead@bloomstudio.com", role: "agentmgr", status: "Active", handle: "@agency_lead", pod: "Bloom & Co", joined: "2026-02-10" }
    ];
    defaultAccounts.forEach(def => {
      mergedMap.set(def.email.toLowerCase(), def);
    });

    // Merge registered Firestore users
    rawFirestoreUsers.forEach(u => {
      const key = (u.email || u.id || u.uid || '').toLowerCase();
      if (key) {
        mergedMap.set(key, { ...u, id: u.id || u.uid });
      }
    });

    // Merge shared invite applications
    inviteApplications.forEach(app => {
      const emailKey = (app.email || '').toLowerCase();
      const existing = mergedMap.get(emailKey);
      if (existing) {
        mergedMap.set(emailKey, {
          ...existing,
          bio: app.bio || existing.bio,
          invitedByCode: app.invitedByCode || existing.invitedByCode,
          w9Status: app.w9Status || existing.w9Status,
          w9FileName: app.w9FileName || existing.w9FileName,
          requestedRole: app.requestedRole || existing.requestedRole || 'creator',
          pod: app.pod || existing.pod || 'Main Agency',
          applicationId: app.id,
          status: existing.role === 'none' ? (app.status || 'Pending Approval') : existing.status
        });
      } else {
        const appKey = emailKey || app.id;
        mergedMap.set(appKey, {
          id: app.id,
          uid: app.uid || app.id,
          name: app.name,
          email: app.email,
          handle: app.handle,
          role: app.role || 'none',
          requestedRole: app.requestedRole || 'creator',
          pod: app.pod || 'Main Agency',
          subagency: app.subagency || app.pod || 'pod_main',
          status: app.status || 'Pending Approval',
          bio: app.bio,
          invitedByCode: app.invitedByCode,
          w9Status: app.w9Status,
          w9FileName: app.w9FileName,
          joined: app.joined || (app.createdAt ? app.createdAt.split('T')[0] : new Date().toISOString().split('T')[0]),
          isApplication: true,
          applicationId: app.id
        });
      }
    });

    if (mergedMap.size > 0) {
      setUserAccounts(Array.from(mergedMap.values()));
    }
  }, [rawFirestoreUsers, inviteApplications]);

  useEffect(() => {
    localStorage.setItem('wl_user_accounts', JSON.stringify(userAccounts));
  }, [userAccounts]);

  const [inviteCodes, setInviteCodes] = useState(() => {
    const saved = localStorage.getItem('wl_access_codes');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) { console.error(e); }
    }
    return [
      { code: "BLOOM_MAIN_MGR", role: "agentmgr", pod: "Main Agency", maxUses: 10, used: 0, expiry: "2027-12-31", status: "Active", purpose: "Main Agency Manager Invite" },
      { code: "BLOOM_MAIN_AGENT", role: "agent", pod: "Main Agency", maxUses: 20, used: 0, expiry: "2027-12-31", status: "Active", purpose: "Main Agency Agent Invite" },
      { code: "BLOOM_MAIN_CREATOR", role: "creator", pod: "Main Agency", maxUses: 50, used: 0, expiry: "2027-12-31", status: "Active", purpose: "Main Agency Creator Invite" }
    ];
  });

  // Real-time synchronization for shared invite codes
  useEffect(() => {
    const unsub = subscribeInviteCodes((codes) => {
      if (codes && codes.length > 0) {
        setInviteCodes((prev: any[]) => {
          const map = new Map<string, any>();
          prev.forEach(c => map.set(c.code, c));
          codes.forEach(c => map.set(c.code, { ...(map.get(c.code) || {}), ...c }));
          return Array.from(map.values());
        });
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    localStorage.setItem('wl_access_codes', JSON.stringify(inviteCodes));
    // Persist all active codes to Firestore so applicants can use them on other devices
    inviteCodes.forEach((c: any) => {
      saveInviteCodeInFirestore(c);
    });
  }, [inviteCodes]);

  // Sub-Agency Pods & Owners State (Director-Only)
  const [subagencyPods, setSubagencyPods] = useState<any[]>(() => {
    const defaultPods = [
      { id: "pod_main", name: "Bloom & Co", ownerName: "Agency Director", ownerEmail: "director@bloomstudio.com", ownerHandle: "@director", created: "2026-01-01", status: "Active", description: "Core Agency Roster", inviteCode: "BLOOM_MAIN_MGR", w9Status: "Verified" },
      { id: "pod_sports", name: "Bloom Sports Network", ownerName: "Sarah Jenkins", ownerEmail: "sarah@bloomsports.com", ownerHandle: "@sarah_sports", created: "2026-02-10", status: "Active", description: "Athletes & Sports Endorsements", inviteCode: "SPORTS_MGR_2026", w9Status: "Verified" },
      { id: "pod_viral", name: "Viral Partners Agency", ownerName: "Liam Sterling", ownerEmail: "liam@viralpartners.com", ownerHandle: "@liam_viral", created: "2026-03-01", status: "Active", description: "Short-Form TikTok & IG Viral Roster", inviteCode: "VIRAL_MGR_2026", w9Status: "Pending W-9" }
    ];
    const saved = localStorage.getItem('wl_subagency_pods');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch(e) { console.error(e); }
    }
    return defaultPods;
  });

  useEffect(() => {
    localStorage.setItem('wl_subagency_pods', JSON.stringify(subagencyPods));
  }, [subagencyPods]);

  const [isCreatePodModalOpen, setIsCreatePodModalOpen] = useState(false);
  const [newPodForm, setNewPodForm] = useState({
    name: '',
    description: '',
    ownerMode: 'invite' as 'invite' | 'assign',
    ownerEmail: '',
    ownerName: '',
    assignedUserId: ''
  });

  const [podToDelete, setPodToDelete] = useState<any | null>(null);
  const [podDeleteAction, setPodDeleteAction] = useState<'delete_members' | 'reassign_main'>('delete_members');

  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [isAddCodeModalOpen, setIsAddCodeModalOpen] = useState(false);

  const [newUserForm, setNewUserForm] = useState({ name: '', email: '', role: 'agent', handle: '', password: '' });
  const [newCodeForm, setNewCodeForm] = useState({ code: '', role: 'creator', maxUses: '5', expiry: '2026-12-31', purpose: '' });

  const [auditFilterText, setAuditFilterText] = useState('');
  const [auditFilterRole, setAuditFilterRole] = useState('All');

  // Dynamic Calendar State (defaults to current month and year, rolls over dynamically)
  const [calendarDate, setCalendarDate] = useState(() => new Date());
  const calendarMonthIndex = calendarDate.getMonth();
  const calendarYear = calendarDate.getFullYear();
  const calendarMonthName = calendarDate.toLocaleString('default', { month: 'long' });
  const daysInMonth = new Date(calendarYear, calendarMonthIndex + 1, 0).getDate();
  const firstDayOfWeek = new Date(calendarYear, calendarMonthIndex, 1).getDay();

  
  // Scouting & Waitlist
  const [scrapedTalents, setScrapedTalents] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_scrapedTalents');
    return saved ? JSON.parse(saved) : [];
  });
  const [waitlistCreators, setWaitlistCreators] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_waitlistCreators');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('wl_waitlistCreators', JSON.stringify(waitlistCreators));
  }, [waitlistCreators]);

  // Real-time Firestore sync for studio_waitlist
  useEffect(() => {
    try {
      const isPlatformOwner = !!currentUser?.isPlatformOwner;
      const colRef = collection(db, 'studio_waitlist');
      const q = isPlatformOwner
        ? colRef
        : query(colRef, where('subagency', '==', currentUser?.subagency || activeTenantId || 'pod_main'));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteList: any[] = [];
            snapshot.forEach((docSnap) => {
              remoteList.push({ id: docSnap.id, ...docSnap.data() });
            });
            setWaitlistCreators((prev) => {
              const map = new Map<string, any>();
              remoteList.forEach((item) => map.set(item.id, item));
              prev.forEach((item) => {
                if (!map.has(item.id)) map.set(item.id, item);
              });
              return Array.from(map.values());
            });
          }
        },
        (err) => {
          console.warn('[OperationBoard] studio_waitlist listener:', err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn('[OperationBoard] Failed to listen to studio_waitlist:', e);
    }
  }, [currentUser?.subagency, currentUser?.isPlatformOwner, activeTenantId]);

  // Crisis & Blacklists
  const [isScanningSentiment, setIsScanningSentiment] = useState(false);
  const [sentimentResult, setSentimentResult] = useState<any>(null);
  const [selectedCreatorForCrisisScan, setSelectedCreatorForCrisisScan] = useState<string>('');

  const [crisisEvents, setCrisisEvents] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_crisisEvents');
    return saved ? JSON.parse(saved) : [];
  });
  const [blacklistedBrands, setBlacklistedBrands] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_blacklistedBrands');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('wl_crisisEvents', JSON.stringify(crisisEvents));
  }, [crisisEvents]);

  useEffect(() => {
    localStorage.setItem('wl_blacklistedBrands', JSON.stringify(blacklistedBrands));
  }, [blacklistedBrands]);

  // Real-time Firestore sync for studio-crisis-events
  useEffect(() => {
    try {
      const isPlatformOwner = !!currentUser?.isPlatformOwner;
      const colRef = collection(db, 'studio-crisis-events');
      const q = isPlatformOwner
        ? colRef
        : query(colRef, where('subagency', '==', currentUser?.subagency || activeTenantId || 'pod_main'));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteList: any[] = [];
            snapshot.forEach((docSnap) => {
              remoteList.push({ id: docSnap.id, ...docSnap.data() });
            });
            setCrisisEvents((prev) => {
              const map = new Map<string, any>();
              remoteList.forEach((item) => map.set(item.id, item));
              prev.forEach((item) => {
                if (!map.has(item.id)) map.set(item.id, item);
              });
              return Array.from(map.values());
            });
          }
        },
        (err) => {
          console.warn('[OperationBoard] studio-crisis-events listener:', err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn('[OperationBoard] Failed to listen to studio-crisis-events:', e);
    }
  }, [currentUser?.subagency, currentUser?.isPlatformOwner, activeTenantId]);

  // Real-time Firestore sync for global-blacklist collection
  useEffect(() => {
    try {
      const isPlatformOwner = !!currentUser?.isPlatformOwner;
      const colRef = collection(db, 'global-blacklist');
      const q = isPlatformOwner
        ? colRef
        : query(colRef, where('subagency', '==', currentUser?.subagency || activeTenantId || 'pod_main'));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteList: any[] = [];
            snapshot.forEach((docSnap) => {
              remoteList.push({ id: docSnap.id, ...docSnap.data() });
            });
            setBlacklistedBrands((prev) => {
              const map = new Map<string, any>();
              remoteList.forEach((item) => map.set(item.id, item));
              prev.forEach((item) => {
                if (!map.has(item.id)) map.set(item.id, item);
              });
              return Array.from(map.values());
            });
          }
        },
        (err) => {
          console.warn('[OperationBoard] global-blacklist listener:', err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn('[OperationBoard] Failed to listen to global-blacklist:', e);
    }
  }, [currentUser?.subagency, currentUser?.isPlatformOwner, activeTenantId]);

  // Real-time Firestore sync for Autopilot Bot status
  useEffect(() => {
    try {
      const tenantDocId = `${currentUser?.tenantId || activeTenantId || 'bloom_studio_default'}_bot_status`;
      const docRef = doc(db, 'studio-agency-settings', tenantDocId);
      const unsubscribe = onSnapshot(
        docRef,
        (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data();
            if (typeof data.botsActive === 'boolean') {
              setBotsActive(data.botsActive);
            }
          }
        },
        (err) => {
          console.warn('[OperationBoard] Bot status listener:', err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn('[OperationBoard] Failed to listen to bot status:', e);
    }
  }, [currentUser?.tenantId, activeTenantId]);

  // Genuine Escrow and Payment Safety Hold Engine
  const isMatchingDealCreator = (d: any, handleOrName: string) => {
    const target = (handleOrName || '').toLowerCase().replace(/^@/, '').trim();
    if (!target) return false;
    const dHandle = (d.creatorHandle || '').toLowerCase().replace(/^@/, '').trim();
    const dCreator = (d.creator || '').toLowerCase().replace(/^@/, '').trim();
    const dName = (d.creatorName || '').toLowerCase().replace(/^@/, '').trim();
    return dHandle === target || dCreator === target || dName === target;
  };

  const lockEscrowForCreator = async (creatorHandle: string, reason: string) => {
    const matchedDeals = (deals || []).filter(d => isMatchingDealCreator(d, creatorHandle));
    const nowIso = new Date().toISOString();

    if (setDeals && matchedDeals.length > 0) {
      setDeals((prev: any[]) => prev.map(d => isMatchingDealCreator(d, creatorHandle) ? {
        ...d,
        escrowLocked: true,
        paymentSafetyHold: true,
        status: 'Escrow Frozen',
        escrowHoldReason: reason,
        paymentHoldReason: reason,
        escrowLockedAt: nowIso,
        paymentHoldDate: nowIso
      } : d));
    }

    // Persist real escrow freeze and payment safety hold across matching deals in Firestore studio-deals
    const lockedIds: string[] = [];
    for (const deal of matchedDeals) {
      try {
        await setDoc(doc(db, 'studio-deals', deal.id), {
          escrowLocked: true,
          paymentSafetyHold: true,
          status: 'Escrow Frozen',
          escrowHoldReason: reason,
          paymentHoldReason: reason,
          escrowLockedAt: nowIso,
          paymentHoldDate: nowIso,
          updatedAt: nowIso
        }, { merge: true });
        lockedIds.push(deal.id);
      } catch (err) {
        console.warn('[Payment Safety Engine] Failed to lock deal in Firestore:', deal.id, err);
      }
    }

    // Trigger payment-safety hold on Creator card / payout account
    const cleanTarget = (creatorHandle || '').toLowerCase().replace(/^@/, '').trim();
    if (setCreators && cleanTarget) {
      setCreators((prev: any[]) => prev.map(c => {
        const cHandle = (c.handle || '').toLowerCase().replace(/^@/, '').trim();
        const cName = (c.name || '').toLowerCase().trim();
        if (cHandle === cleanTarget || cName === cleanTarget) {
          return {
            ...c,
            paymentSafetyHold: true,
            cardStatus: 'frozen',
            payoutHoldReason: reason,
            payoutHoldDate: nowIso
          };
        }
        return c;
      }));
    }

    // Persist card freeze and payment safety hold in Firestore studio-creators
    try {
      const matchedCreators = (creators || []).filter(c => {
        const cHandle = (c.handle || '').toLowerCase().replace(/^@/, '').trim();
        const cName = (c.name || '').toLowerCase().trim();
        return cHandle === cleanTarget || cName === cleanTarget;
      });
      for (const creator of matchedCreators) {
        if (creator.id) {
          await setDoc(doc(db, 'studio-creators', creator.id), {
            paymentSafetyHold: true,
            cardStatus: 'frozen',
            payoutHoldReason: reason,
            payoutHoldDate: nowIso,
            updatedAt: nowIso
          }, { merge: true });
        }
      }
    } catch (err) {
      console.warn('[Payment Safety Engine] Failed to lock creator cards in Firestore:', err);
    }

    // Write payment safety hold log document
    try {
      const holdDocId = 'hold_' + Date.now();
      await setDoc(doc(db, 'studio-payment-holds', holdDocId), {
        id: holdDocId,
        creator: creatorHandle,
        reason,
        status: 'active',
        lockedDealIds: lockedIds,
        lockedCards: true,
        appliedBy: currentUser?.name || 'Director',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        createdAt: nowIso
      }, { merge: true });
    } catch (holdErr) {
      console.warn('[Payment Safety Engine] Failed to log safety hold record:', holdErr);
    }

    return lockedIds;
  };

  const unlockEscrowForCreator = async (creatorHandle: string) => {
    const matchedDeals = (deals || []).filter(d => isMatchingDealCreator(d, creatorHandle));
    const nowIso = new Date().toISOString();

    if (setDeals && matchedDeals.length > 0) {
      setDeals((prev: any[]) => prev.map(d => isMatchingDealCreator(d, creatorHandle) ? {
        ...d,
        escrowLocked: false,
        paymentSafetyHold: false,
        status: d.status === 'Escrow Frozen' ? 'In Progress' : d.status,
        escrowUnlockedAt: nowIso,
        paymentHoldReason: null
      } : d));
    }

    const unlockedIds: string[] = [];
    for (const deal of matchedDeals) {
      try {
        await setDoc(doc(db, 'studio-deals', deal.id), {
          escrowLocked: false,
          paymentSafetyHold: false,
          status: deal.status === 'Escrow Frozen' ? 'In Progress' : deal.status,
          escrowUnlockedAt: nowIso,
          paymentHoldReason: null,
          updatedAt: nowIso
        }, { merge: true });
        unlockedIds.push(deal.id);
      } catch (err) {
        console.warn('[Payment Safety Engine] Failed to unlock deal in Firestore:', deal.id, err);
      }
    }

    // Unlock Creator card / payout account
    const cleanTarget = (creatorHandle || '').toLowerCase().replace(/^@/, '').trim();
    if (setCreators && cleanTarget) {
      setCreators((prev: any[]) => prev.map(c => {
        const cHandle = (c.handle || '').toLowerCase().replace(/^@/, '').trim();
        const cName = (c.name || '').toLowerCase().trim();
        if (cHandle === cleanTarget || cName === cleanTarget) {
          return {
            ...c,
            paymentSafetyHold: false,
            cardStatus: 'active',
            payoutHoldReason: null,
            payoutHoldDate: null
          };
        }
        return c;
      }));
    }

    // Persist card unfreeze in Firestore studio-creators
    try {
      const matchedCreators = (creators || []).filter(c => {
        const cHandle = (c.handle || '').toLowerCase().replace(/^@/, '').trim();
        const cName = (c.name || '').toLowerCase().trim();
        return cHandle === cleanTarget || cName === cleanTarget;
      });
      for (const creator of matchedCreators) {
        if (creator.id) {
          await setDoc(doc(db, 'studio-creators', creator.id), {
            paymentSafetyHold: false,
            cardStatus: 'active',
            payoutHoldReason: null,
            payoutHoldDate: null,
            updatedAt: nowIso
          }, { merge: true });
        }
      }
    } catch (err) {
      console.warn('[Payment Safety Engine] Failed to unlock creator cards in Firestore:', err);
    }

    return unlockedIds;
  };

  const handleRunSentimentCrisisScanner = async (targetHandleOverride?: string) => {
    setIsScanningSentiment(true);
    const targetHandle = targetHandleOverride || selectedCreatorForCrisisScan || inputTitle || (creators && creators[0] ? creators[0].handle : '@elenarostova');
    const cleanHandle = targetHandle.startsWith('@') ? targetHandle : `@${targetHandle}`;

    try {
      const authHeaders = await getAuthHeaders();
      const res = await fetch('/api/sentiment-crisis-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({
          creatorHandle: cleanHandle,
          recentComments: [
            `This latest sponsored batch from ${cleanHandle} arrived damaged and the pump is broken!`,
            "Product formula feels completely separated, customer service isn't responding.",
            "Really love the creator, but this brand's quality control is unacceptable.",
            "Defective packaging on arrival, requesting a refund immediately."
          ]
        })
      });
      const data = await res.json();
      if (data.success) {
        setSentimentResult(data.analysis);
        if (data.analysis.hasCrisis) {
          const crisisId = 'c_' + Date.now();
          const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;
          
          let lockedDealIds: string[] = [];
          if (isDirector) {
            lockedDealIds = await lockEscrowForCreator(cleanHandle, data.analysis.recommendedAction || 'AI Sentiment Crisis Spike');
          }

          const crisisRecord = {
            id: crisisId,
            creator: cleanHandle,
            brand: 'Under Evaluation',
            issue: `Project Shield Sentiment Alert: ${data.analysis.detectedPhrases?.join(', ') || 'Negative sentiment spike'}`,
            severity: data.analysis.severity || 'High',
            status: isDirector ? 'Payment Safety Hold Active' : 'Routed to Director',
            paymentSafetyHold: isDirector,
            escrowLocked: isDirector,
            lockedCards: isDirector,
            lockedDealIds,
            reportedBy: 'Project Shield AI',
            subagency: currentUser?.subagency || activeTenantId || 'pod_main',
            tenantId: currentUser?.tenantId || 'bloom_studio_default',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };

          setCrisisEvents(prev => [crisisRecord, ...prev.filter(x => x.id !== crisisId)]);

          try {
            await setDoc(doc(db, 'studio-crisis-events', crisisId), crisisRecord, { merge: true });
          } catch (err) {
            console.warn('[Project Shield] Failed to persist crisis event to Firestore:', err);
          }

          if (setActionQueue) {
            const queueId = 'aq_sentiment_' + Date.now();
            const queueItem = {
              id: queueId,
              tag: 'PROJECT SHIELD CRISIS',
              tagColor: '#ef4444',
              title: `Sentiment Crisis Spike detected for ${cleanHandle} (${data.analysis.severity} Severity)`,
              timestamp: 'Just now',
              isCompleted: false,
              createdByAgent: 'Project Shield AI',
              subagency: currentUser?.subagency || activeTenantId || 'pod_main',
              tenantId: currentUser?.tenantId || 'bloom_studio_default',
              createdAt: new Date().toISOString()
            };
            setActionQueue(prev => [...prev.filter(x => x.id !== queueId), queueItem]);

            try {
              await setDoc(doc(db, 'studio-action-queue', queueId), queueItem, { merge: true });
            } catch (err) {
              console.warn('[Project Shield] Failed to persist action item to Firestore:', err);
            }
          }

          try {
            const notifRef = collection(db, 'studio-notifications');
            await addDoc(notifRef, {
              title: `🚨 Project Shield Alert: ${cleanHandle}`,
              message: `${data.analysis.severity} severity sentiment crisis detected. ${isDirector ? `Payment safety hold active on ${lockedDealIds.length} deal(s) & corporate cards.` : 'Incident routed to Director.'}`,
              severity: 'danger',
              role: 'director',
              subagency: currentUser?.subagency || activeTenantId || 'pod_main',
              tenantId: currentUser?.tenantId || 'bloom_studio_default',
              createdAt: new Date().toISOString()
            });
          } catch (notifErr) {
            console.warn('[Project Shield] Notification write warning:', notifErr);
          }

          triggerNotification(
            '🚨 Project Shield Crisis Alert',
            isDirector 
              ? `Payment safety hold placed on ${lockedDealIds.length} deal(s) & corporate cards for ${cleanHandle}. ${data.analysis.recommendedAction}`
              : `Incident for ${cleanHandle} routed to Director for payment safety hold evaluation.`,
            'danger'
          );
          onAddActivityLog('Project Shield AI', 'system', `Detected sentiment crisis for ${cleanHandle} (Severity: ${data.analysis.severity})`);
        } else {
          triggerNotification('✅ Sentiment Scan Clean', `No customer service red flags detected in comment feeds for ${cleanHandle}.`, 'success');
        }
      }
    } catch (err) {
      console.error("Sentiment scan error:", err);
      triggerNotification('Sentiment Scan Error', 'Could not complete NLP sentiment analysis.', 'warning');
    } finally {
      setIsScanningSentiment(false);
    }
  };

  // Broadcasts
  const [internalAnnouncements, setInternalAnnouncements] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_announcements');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: 'an_clean_1',
        title: 'Agency Operations & Compliance Guidance',
        text: 'All creator deliverables must ensure clear FTC disclosure tags (#ad or #sponsored) are positioned within the top lines of campaign captions.',
        date: 'Today',
        createdAt: new Date().toISOString(),
        author: 'Agency Director',
        audience: 'All Agency',
        readBy: []
      }
    ];
  });

  const announcements = propAnnouncements || internalAnnouncements;
  const setAnnouncements = propSetAnnouncements || setInternalAnnouncements;

  useEffect(() => {
    localStorage.setItem('wl_announcements', JSON.stringify(announcements));
  }, [announcements]);

  // Real-time Firestore sync for studio-announcements
  useEffect(() => {
    try {
      const isPlatformOwner = !!currentUser?.isPlatformOwner;
      const colRef = collection(db, 'studio-announcements');
      const q = isPlatformOwner
        ? colRef
        : query(colRef, where('subagency', '==', currentUser?.subagency || activeTenantId || 'pod_main'));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteList: any[] = [];
            snapshot.forEach((docSnap) => {
              const data = docSnap.data();
              remoteList.push({ id: docSnap.id, ...data });
            });
            remoteList.sort((a, b) => {
              const tA = new Date(a.createdAt || 0).getTime();
              const tB = new Date(b.createdAt || 0).getTime();
              return tB - tA;
            });
            setInternalAnnouncements(remoteList);
            if (propSetAnnouncements) {
              propSetAnnouncements((prev) => {
                const map = new Map<string, any>();
                remoteList.forEach(item => map.set(item.id, item));
                prev.forEach(item => { if (!map.has(item.id)) map.set(item.id, item); });
                return Array.from(map.values()).sort((a, b) => {
                  const tA = new Date(a.createdAt || 0).getTime();
                  const tB = new Date(b.createdAt || 0).getTime();
                  return tB - tA;
                });
              });
            }
          }
        },
        (err) => {
          console.warn('[OperationBoard] studio-announcements listener warning:', err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn('[OperationBoard] Failed to listen to studio-announcements:', e);
    }
  }, [currentUser?.subagency, currentUser?.isPlatformOwner, activeTenantId]);

  useEffect(() => {
    if (activeScreen === 'creator-announcements' || activeScreen === 'team-announcements') {
      const isDir = ['director', 'agency'].includes((currentRole || '').toLowerCase());
      if (!isDir) {
        const viewerName = currentUser?.handle || currentUser?.name || (currentRole === 'creator' ? '@alexjones' : 'Marcus Cole');
        setAnnouncements(prev => {
          let changed = false;
          const updated = prev.map(ann => {
            const readList = ann.readBy || [];
            if (!readList.includes(viewerName)) {
              changed = true;
              return { ...ann, readBy: [...readList, viewerName] };
            }
            return ann;
          });
          return changed ? updated : prev;
        });
      }
    }
  }, [activeScreen, currentRole, currentUser]);

  // Agency Deliverable & Availability Schedules State
  const DEFAULT_INITIAL_SCHEDULES = [
    { id: 'sc_avail_1', title: '@alexjones: Available for UGC & Commercial Shoots', creator: '@alexjones', dayNum: 14, month: new Date().getMonth(), year: new Date().getFullYear(), type: 'availability', status: 'available', timeWindow: 'All Day', location: 'Los Angeles, CA', notes: 'Open for fitness & fashion shoots' },
    { id: 'sc_avail_2', title: '@sophiaglows: On-Set Miami Beauty Shoot', creator: '@sophiaglows', dayNum: 16, month: new Date().getMonth(), year: new Date().getFullYear(), type: 'availability', status: 'onset', timeWindow: '9:00 AM - 6:00 PM EST', location: 'Miami Beach, FL', notes: 'Filming Sephora Campaign' },
    { id: 'sc_avail_3', title: '@marcusfitness: Busy - In Post-Production', creator: '@marcusfitness', dayNum: 18, month: new Date().getMonth(), year: new Date().getFullYear(), type: 'availability', status: 'busy', timeWindow: 'Afternoon', location: 'Studio Lab', notes: 'Editing Gymshark VOD' },
    { id: 'sc_avail_4', title: '@elena_style: Blockout - Paris Fashion Week', creator: '@elena_style', dayNum: 22, month: new Date().getMonth(), year: new Date().getFullYear(), type: 'availability', status: 'blockout', timeWindow: 'Full Day', location: 'Paris, FR', notes: 'Personal blockout / runway attendance' },
    { id: 'sc_avail_5', title: '@kai_tech: Available for Tech Reviews', creator: '@kai_tech', dayNum: 25, month: new Date().getMonth(), year: new Date().getFullYear(), type: 'availability', status: 'available', timeWindow: '10:00 AM - 4:00 PM PST', location: 'Austin, TX', notes: 'Open for consumer electronics sponsorships' }
  ];

  const [localAgencySchedules, setLocalAgencySchedules] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_agency_schedules');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return DEFAULT_INITIAL_SCHEDULES;
  });

  const agencySchedules = propSetAgencySchedules ? propAgencySchedules : localAgencySchedules;
  const setAgencySchedules = propSetAgencySchedules || setLocalAgencySchedules;

  useEffect(() => {
    localStorage.setItem('wl_agency_schedules', JSON.stringify(agencySchedules));
  }, [agencySchedules]);

  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [availabilityCreatorFilter, setAvailabilityCreatorFilter] = useState<string>('all');
  const [availabilityStatusFilter, setAvailabilityStatusFilter] = useState<string>('all');
  const [isAddAvailabilityModalOpen, setIsAddAvailabilityModalOpen] = useState(false);
  const [newAvailabilityForm, setNewAvailabilityForm] = useState({
    creator: '@alexjones',
    title: '',
    dayNum: new Date().getDate(),
    status: 'available' as 'available' | 'busy' | 'onset' | 'blockout' | 'tentative',
    timeWindow: 'All Day',
    location: 'Los Angeles, CA',
    notes: ''
  });

  // External Service Integrations (Live Connected Tools Manager)
  const DEFAULT_EXTERNAL_INTEGRATIONS = [
    { 
      id: 'yt', 
      name: 'YouTube Creator API', 
      category: 'Social & Video', 
      desc: 'Sync view counts, Shorts analytics, subscriber growth, and syndications.', 
      status: 'Connected & Active', 
      connected: true, 
      icon: '▶️', 
      connectedAccount: 'bloom_studio_channel_sync',
      lastSync: '2 minutes ago',
      fields: { apiKey: 'AIzaSyD-••••••••••••••••39A1', channelId: 'UC_BloomMediaAgency' } 
    },
    { 
      id: 'meta', 
      name: 'Meta / Instagram Graph API', 
      category: 'Social & Video', 
      desc: 'Real-time Instagram Reels metrics, story reach, and audience demographics.', 
      status: 'Connected & Active', 
      connected: true, 
      icon: '📸', 
      connectedAccount: '@bloom.creators.official',
      lastSync: '10 minutes ago',
      fields: { accessToken: 'EAA7••••••••••••••••K99', igBusinessId: '1784140582910293' } 
    },
    { 
      id: 'stripe', 
      name: 'Stripe Connect & Billing', 
      category: 'Finance & Payments', 
      desc: 'Automated escrow settlement, creator payouts, and tax form compliance.', 
      status: 'Connected & Active', 
      connected: true, 
      icon: '💳', 
      connectedAccount: 'acct_1N9xBloomEscrow',
      lastSync: 'Just now',
      fields: { publishableKey: 'pk_live_51N9••••••••••••8819', secretKey: 'sk_live_51N9••••••••••••4102' } 
    },
    { 
      id: 'slack', 
      name: 'Slack Agency Alert Bot', 
      category: 'Communication', 
      desc: 'Push Director announcements, crisis alerts, and deal approvals to channels.', 
      status: 'Not Connected', 
      connected: false, 
      icon: '💬', 
      connectedAccount: '',
      lastSync: 'Never',
      fields: { webhookUrl: '', channel: '#agency-alerts' } 
    },
    { 
      id: 'zoho', 
      name: 'Zoho / HubSpot CRM Sync', 
      category: 'CRM & Sales', 
      desc: 'Bi-directional sync of brand inquiries, contacts, and retainer deals.', 
      status: 'Connected & Active', 
      connected: true, 
      icon: '🤝', 
      connectedAccount: 'bloom_zoho_org_us',
      lastSync: '1 hour ago',
      fields: { clientId: '1000.••••••••••••••••ZOHO', clientSecret: 'sec_••••••••••••••••SEC1' } 
    },
    { 
      id: 'ga4', 
      name: 'Google Analytics 4', 
      category: 'Analytics', 
      desc: 'Track Brand Portal traffic, visitor funnels, and referral conversions.', 
      status: 'Not Connected', 
      connected: false, 
      icon: '📊', 
      connectedAccount: '',
      lastSync: 'Never',
      fields: { measurementId: '', propertyId: '' } 
    },
    { 
      id: 'gcal', 
      name: 'Google Calendar Sync', 
      category: 'Production & Schedules', 
      desc: 'Two-way synchronization of talent availability and production shoot dates.', 
      status: 'Connected & Active', 
      connected: true, 
      icon: '📅', 
      connectedAccount: 'production@bloomstudio.com',
      lastSync: '5 minutes ago',
      fields: { calendarId: 'c_bloom_production_master', syncDirection: 'two-way' } 
    },
    { 
      id: 'twilio', 
      name: 'Twilio SMS Gateway', 
      category: 'Notifications', 
      desc: 'Instant SMS notifications to talent for urgent deliverable turn-ins & call times.', 
      status: 'Connected & Active', 
      connected: true, 
      icon: '📱', 
      connectedAccount: '+1 (800) 555-BLOOM',
      lastSync: '15 minutes ago',
      fields: { accountSid: 'AC77a1••••••••••••••••9901', authToken: 'auth_••••••••••••••••33b2' } 
    },
    { 
      id: 'sendgrid', 
      name: 'SendGrid Deal Dispatcher', 
      category: 'Email & IRS 1099', 
      desc: 'Official 1099-NEC tax dispatches, signed contract PDFs, and brand invoices.', 
      status: 'Connected & Active', 
      connected: true, 
      icon: '✉️', 
      connectedAccount: 'billing@bloomstudio.com',
      lastSync: '30 minutes ago',
      fields: { apiKey: 'SG.99z1••••••••••••••••K001', senderEmail: 'billing@bloomstudio.com' } 
    },
    { 
      id: 'tiktok', 
      name: 'TikTok Creator API', 
      category: 'Social & Video', 
      desc: 'Live follower velocity, video view counts, and viral post detection.', 
      status: 'Not Connected', 
      connected: false, 
      icon: '🎵', 
      connectedAccount: '',
      lastSync: 'Never',
      fields: { clientKey: '', clientSecret: '' } 
    }
  ];

  const [externalIntegrations, setExternalIntegrations] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_external_integrations');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge with default list in case new integrations were added
          const existingIds = new Set(parsed.map(p => p.id));
          const missing = DEFAULT_EXTERNAL_INTEGRATIONS.filter(d => !existingIds.has(d.id));
          return [...parsed, ...missing];
        }
      } catch (e) {}
    }
    return DEFAULT_EXTERNAL_INTEGRATIONS;
  });

  useEffect(() => {
    localStorage.setItem('wl_external_integrations', JSON.stringify(externalIntegrations));
  }, [externalIntegrations]);

  const [selectedIntegrationModal, setSelectedIntegrationModal] = useState<any | null>(null);
  const [showSecretKey, setShowSecretKey] = useState(false);

  const openIntegrationModal = (item: any) => {
    const vaultKey = localStorage.getItem('wl_api_key_' + item.id) || item.fields?.secretKey || item.fields?.apiKey || item.fields?.accessToken || '';
    setSelectedIntegrationModal({
      ...item,
      fields: {
        ...item.fields,
        secretKey: vaultKey
      }
    });
    setShowSecretKey(false);
  };
  const [integrationCategoryFilter, setIntegrationCategoryFilter] = useState<string>('all');
  const [isTestingIntegration, setIsTestingIntegration] = useState(false);
  const [isSyncingAllIntegrations, setIsSyncingAllIntegrations] = useState(false);

  // Brand Inquiries
  const [brandInquiries, setBrandInquiries] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_brandInquiries_op');
    return saved ? JSON.parse(saved) : [];
  });

  // Brand CRM Contacts
  const [brands, setBrands] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_brands');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return [
      { id: 'br_nike', name: 'Nike Athletics', contact: 'Sarah Lin (VP Partnerships)', email: 'sarah.lin@nike.com', spent: 75000, activeCampaigns: 2, status: 'Active Partner', category: 'Sportswear & Fitness', escrowPreference: '100% Pre-funded Escrow', notes: 'Corporate AP billing contact.' },
      { id: 'br_gymshark', name: 'Gymshark', contact: 'Alex Rivera (Influencer Lead)', email: 'alex.rivera@gymshark.com', spent: 42000, activeCampaigns: 1, status: 'Active Partner', category: 'Apparel & Athleisure', escrowPreference: '100% Pre-funded Escrow', notes: 'Prefers TikTok & IG Reels bundles.' },
      { id: 'br_aloyoga', name: 'Alo Yoga', contact: 'Jessica Vance (Talent Coordinator)', email: 'jessica@aloyoga.com', spent: 18500, activeCampaigns: 1, status: 'Contracted', category: 'Wellness & Lifestyle', escrowPreference: '100% Pre-funded Escrow', notes: 'Monthly recurring retainers.' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('wl_brands', JSON.stringify(brands));
  }, [brands]);

  const [isAddBrandModalOpen, setIsAddBrandModalOpen] = useState(false);
  const [isEditBrandModalOpen, setIsEditBrandModalOpen] = useState(false);
  const [selectedBrandForEdit, setSelectedBrandForEdit] = useState<any | null>(null);
  const [brandSearchTerm, setBrandSearchTerm] = useState('');
  const [brandStatusFilter, setBrandStatusFilter] = useState('All');
  const [newBrandForm, setNewBrandForm] = useState({
    name: '',
    contact: '',
    email: '',
    status: 'Warm Lead',
    spent: 0,
    activeCampaigns: 0,
    category: 'Fashion & Lifestyle',
    notes: '',
    escrowPreference: '100% Pre-funded Escrow'
  });

  // Escrow & Lock Brand Fund Modal State
  const [isEscrowModalOpen, setIsEscrowModalOpen] = useState(false);
  const [escrowTargetBrand, setEscrowTargetBrand] = useState('');
  const [escrowContactEmail, setEscrowContactEmail] = useState('');
  const [escrowCampaignTitle, setEscrowCampaignTitle] = useState('');
  const [escrowAmount, setEscrowAmount] = useState<number>(5000);
  const [escrowCreatorHandle, setEscrowCreatorHandle] = useState('');
  const [escrowReleaseCondition, setEscrowReleaseCondition] = useState('100% upon verified live URL & FTC disclosure compliance clearance');
  const [escrowNote, setEscrowNote] = useState('');

  // Brand Visibility of Creator Rate Cards (Director on/off switch)
  const [showRatesToBrands, setShowRatesToBrands] = useState<boolean>(() => {
    const saved = localStorage.getItem('wl_show_rates_to_brands');
    return saved === 'true'; // Default is false so creators aren't put in a box unless explicitly turned on
  });

  useEffect(() => {
    localStorage.setItem('wl_show_rates_to_brands', String(showRatesToBrands));
  }, [showRatesToBrands]);

  // Referrals
  const [boardReferrals, setBoardReferrals] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('wl_boardReferrals');
      const creatorSaved = localStorage.getItem('wl_referrals');
      let combined: any[] = [];
      if (saved) combined = [...combined, ...JSON.parse(saved)];
      if (creatorSaved) {
        const cParsed = JSON.parse(creatorSaved);
        for (const r of cParsed) {
          if (!combined.some(x => x.id === r.id)) {
            combined.push({
              id: r.id,
              referrer: r.referrer,
              referred: r.newclient,
              type: r.type || 'Creator',
              value: r.value ? `$${r.value}.00` : '$500.00',
              date: r.date,
              status: r.status || 'Pending Review'
            });
          }
        }
      }
      return combined;
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('wl_boardReferrals', JSON.stringify(boardReferrals));
  }, [boardReferrals]);

  // Retainers
  const [retainers, setRetainers] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_retainers');
    return saved ? JSON.parse(saved) : [];
  });

  // Contracts
  const [contracts, setContracts] = useState<any[]>(() => {
    const defaultContracts = [
      { id: 'CON-2026-101', name: 'Exclusive Representation Agreement - Alex Jones', client: 'Bloom Studio Main Agency', partner: 'Alex Jones (@alexjones)', type: 'Talent Representation', status: 'Active', value: '80% Split', signedDate: 'Jan 15, 2026', expiryDate: 'Jan 15, 2027', subagency: 'Bloom & Co' },
      { id: 'CON-2026-901', name: 'Nike x Bloom Sports Master Representation & Endorsement Agreement', client: 'Nike Athletics', partner: 'Serena Williams Creator (@serena_creator)', type: 'Brand Deal Endorsement', status: 'Active', value: '$35,000', signedDate: 'July 18, 2026', expiryDate: 'July 18, 2027', subagency: 'Bloom & Co' },
      { id: 'CON-2026-902', name: 'RedBull Digital Viral Talent Agreement', client: 'RedBull Digital', partner: 'Liam Sterling (@liam_viral)', type: 'Brand Deal Endorsement', status: 'Active', value: '$24,000', signedDate: 'July 20, 2026', expiryDate: 'July 20, 2027', subagency: 'Bloom & Co' }
    ];
    const saved = localStorage.getItem('wl_contracts');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch(e) { console.error(e); }
    }
    return defaultContracts;
  });
  useEffect(() => {
    localStorage.setItem('wl_contracts', JSON.stringify(contracts));
  }, [contracts]);

  // Casting Calls
  const [castingCalls, setCastingCalls] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_castingCalls');
    return saved ? JSON.parse(saved) : [];
  });

  // Agent Performance & Admin
  const defaultAgentsSeed = React.useMemo(() => [], []);

  const [agents, setAgents] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_agents');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const fakeNames = ['zach king', 'zack king', 'zachking', 'zackking', 'marcus cole', 'jordan lee', 'rachel sterling', 'sarah chen', 'devon brooks', 'alex vance', 'maya lin'];
          return parsed.filter(a => !fakeNames.some(f => (a.name || '').toLowerCase().includes(f)));
        }
      } catch (e) { /* fallback */ }
    }
    return defaultAgentsSeed;
  });

  const [newlyCreatedAgentInvite, setNewlyCreatedAgentInvite] = useState<any | null>(null);

  useEffect(() => {
    localStorage.setItem('wl_agents', JSON.stringify(agents));
  }, [agents]);

  useEffect(() => {
    const isOwner = !!currentUser?.isPlatformOwner;
    const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
    const q = isOwner 
      ? collection(db, 'studio-agents')
      : query(collection(db, 'studio-agents'), where('pod', '==', userPod));

    const unsub = onSnapshot(q, (snap) => {
      if (!snap.empty) {
        const list: any[] = [];
        const fakeNames = ['zach king', 'zack king', 'zachking', 'zackking', 'marcus cole', 'jordan lee', 'rachel sterling', 'sarah chen', 'devon brooks', 'alex vance', 'maya lin'];
        snap.forEach(d => {
          const data = d.data();
          if (!fakeNames.some(f => (data.name || '').toLowerCase().includes(f))) {
            list.push({ ...data, id: d.id });
          }
        });
        setAgents(list);
      }
    }, err => console.warn('[studio-agents] sync error:', err));
    return () => unsub();
  }, [currentUser]);
  const [agentNotes, setAgentNotes] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_agentNotes');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return [];
  });
  const [noteCategoryFilter, setNoteCategoryFilter] = useState('All');

  useEffect(() => {
    localStorage.setItem('wl_agentNotes', JSON.stringify(agentNotes));
  }, [agentNotes]);
  const [activeWorkspace, setActiveWorkspace] = useState('Bloom & Co. Master');

  // --- NEW INTEGRATED STATES ---
  const [workspaces, setWorkspaces] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_workspaces');
    return saved ? JSON.parse(saved) : [
      { id: 'ws_1', name: 'Bloom & Co. Master', niche: 'Beauty & Fashion', creators: 0 }
    ];
  });

  const [exclusivityItems, setExclusivityItems] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_exclusivityItems');
    return saved ? JSON.parse(saved) : [];
  });

  const [retentionItems, setRetentionItems] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_retentionItems');
    return saved ? JSON.parse(saved) : [];
  });

  const [growthItems, setGrowthItems] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_growthItems');
    return saved ? JSON.parse(saved) : [];
  });

  const [localOnboardingItems, setLocalOnboardingItems] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_onboarding_items');
    return saved ? JSON.parse(saved) : [];
  });

  const onboardingItems = propSetOnboardingItems ? propOnboardingItems : localOnboardingItems;
  const setOnboardingItems = propSetOnboardingItems || setLocalOnboardingItems;

  const [onboardingNicheFilter, setOnboardingNicheFilter] = useState<string>('all');

  const [rateHistory, setRateHistory] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_rateHistory');
    return saved ? JSON.parse(saved) : [];
  });

  // Per-Creator Growth Planning Roadmaps State (Synced with Firestore)
  const defaultRoadmapsSeed = React.useMemo(() => [], []);

  const [creatorRoadmaps, setCreatorRoadmaps] = useState<any[]>(() => {
    const saved = localStorage.getItem('wl_creator_roadmaps');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    const isOwner = !!currentUser?.isPlatformOwner;
    const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
    const isStaffOrDirector = ['director', 'agentmgr', 'agency', 'subagency', 'owner'].includes((currentRole || '').toLowerCase());

    let q;
    if (isOwner) {
      q = collection(db, 'studio-creator-roadmaps');
    } else if (isStaffOrDirector) {
      q = query(collection(db, 'studio-creator-roadmaps'), where('subagency', '==', userPod));
    } else {
      q = query(collection(db, 'studio-creator-roadmaps'), where('creatorId', '==', currentUser?.uid || currentUser?.id || 'none'));
    }

    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const items: any[] = [];
        snapshot.forEach(docSnap => items.push({ ...docSnap.data(), id: docSnap.id }));
        setCreatorRoadmaps(items);
      }
    }, (err) => console.warn('[studio-creator-roadmaps]', err));
    return () => unsub();
  }, [currentUser, currentRole]);

  const defaultGrowthSeed = React.useMemo(() => [], []);

  useEffect(() => {
    const isOwner = !!currentUser?.isPlatformOwner;
    const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
    const isStaffOrDirector = ['director', 'agentmgr', 'agency', 'subagency', 'owner'].includes((currentRole || '').toLowerCase());

    let q;
    if (isOwner) {
      q = collection(db, 'studio-growth-items');
    } else if (isStaffOrDirector) {
      q = query(collection(db, 'studio-growth-items'), where('subagency', '==', userPod));
    } else {
      q = query(collection(db, 'studio-growth-items'), where('creatorId', '==', currentUser?.uid || currentUser?.id || 'none'));
    }

    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const items: any[] = [];
        snapshot.forEach(docSnap => items.push({ ...docSnap.data(), id: docSnap.id }));
        setGrowthItems(items);
      }
    }, (err) => console.warn('[studio-growth-items]', err));
    return () => unsub();
  }, [currentUser, currentRole]);

  const [selectedRoadmapHandle, setSelectedRoadmapHandle] = useState<string>('');
  const [isPullingLiveTrajectory, setIsPullingLiveTrajectory] = useState(false);
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newGoalCategory, setNewGoalCategory] = useState('Follower Growth');
  const [newGoalDeadline, setNewGoalDeadline] = useState('Q4 2026');
  const [newMilestoneText, setNewMilestoneText] = useState('');

  // Editing Growth planning sub-state
  const [editingGrowthId, setEditingGrowthId] = useState<string | null>(null);
  const [editGrowthObjective, setEditGrowthObjective] = useState('');
  const [editGrowthProgress, setEditGrowthProgress] = useState('0%');
  const [editGrowthStatus, setEditGrowthStatus] = useState('Planning');
  const [editGrowthNotes, setEditGrowthNotes] = useState('');

  // SOP Procedures & Compliance Checklists
  const [procedures, setProcedures] = useState([
    { id: 'p_1', category: 'Creator Onboarding', step: 'Perform KYC & background check', desc: 'Verify real identities, check age (18+), scan for past compliance flags.', checked: true },
    { id: 'p_2', category: 'Creator Onboarding', step: 'Draft & sign exclusive talent agreement', desc: 'Execute exclusive legal representation agreements with specified split margins.', checked: true },
    { id: 'p_3', category: 'Creator Onboarding', step: 'Secure W-9/1099 compliance files', desc: 'Upload verified tax documentation and verify tax IDs via tracker desk.', checked: false },
    { id: 'p_4', category: 'Campaign Launch', step: 'Fund Stripe escrow deposit', desc: 'Ensure the brand funds the entire budget upfront into our escrow holds before drafting starts.', checked: true },
    { id: 'p_5', category: 'Campaign Launch', step: 'Draft and review content captions', desc: 'Auto-verify FTC hashtags (#ad, #sponsored) are within first two copy lines.', checked: false }
  ]);

  const [coordinatorProcedures, setCoordinatorProcedures] = useState([
    { id: 'coord_1', category: 'Creator Tracking', step: 'Monitor Creator Draft Submission Pace', desc: 'Track whether assigned creators submit initial drafts and creative assets before the campaign milestone deadline.', checked: true },
    { id: 'coord_2', category: 'Compliance Verification', step: 'Check FTC Disclosure Tags & Guidelines', desc: 'Ensure content draft copy contains all required FTC disclosure tags (#ad, #sponsored, #paidpartnership) within visible lines.', checked: true },
    { id: 'coord_3', category: 'Deliverable Status', step: 'Track Deliverable Progress & Stage Status', desc: 'Monitor the deliverable completion lifecycle from draft submission to director sign-off and published live links.', checked: true },
    { id: 'coord_4', category: 'Director Sign-off', step: 'Confirm Executive Director Clearance', desc: 'Follow up with the Agency Director on pending content approvals and executive sign-off for active campaigns.', checked: false },
    { id: 'coord_5', category: 'Calendar & Scheduling', step: 'Sync Creator Availability & Blackout Dates', desc: 'Coordinate creator shoot schedules, travel dates, and campaign booking availability in the production calendar.', checked: true }
  ]);

  const [creatorProcedures, setCreatorProcedures] = useState([
    { id: 'cp_1', category: 'Content Submission', step: 'How to Submit Content for Review', desc: 'Upload high-resolution draft video files (9:16 aspect ratio, 1080p/4K) and caption text with FTC disclosures to the My Content / Status portal at least 48 hours before the brand deadline.', checked: true },
    { id: 'cp_2', category: 'Sponsorship Opportunities', step: 'How to Apply to a Casting Call', desc: 'Browse available brand campaigns in the Casting Calls board, check the deliverable requirements and target audience match, and click "Apply" with your creative pitch or rate card.', checked: true },
    { id: 'cp_3', category: 'Brand Revisions', step: 'What to Do When a Brand Requests Revisions', desc: 'Review the brand feedback notes in Content Review, update the video edit or caption wording to address all requested items within 24 hours, and re-submit the revised draft.', checked: false },
    { id: 'cp_4', category: 'Deliverable Tracking', step: 'How to Log Deliverables & Claim Payouts', desc: 'Once your content is live, paste the published social media URL in Missions / Deliverables so your agent can verify engagement and trigger Stripe escrow settlement.', checked: true },
    { id: 'cp_5', category: 'Schedule Management', step: 'How to Request Time Off or Pause Availability', desc: 'Use the Availability Calendar to block out travel dates, vacations, or production blackout days so your agent does not pitch you for campaigns during those windows.', checked: false }
  ]);

  const [payoutLedger, setPayoutLedger] = useState<any[]>([]);

  // Maintenance & Migration state
  const [isPurgingSeedData, setIsPurgingSeedData] = useState(false);
  const [isMigratingCreators, setIsMigratingCreators] = useState(false);
  const [maintenanceFeedback, setMaintenanceFeedback] = useState<{ type: 'success' | 'error' | 'info'; title: string; message: string } | null>(null);

  const handleRunPurge = async () => {
    if (isPurgingSeedData) return;
    const confirm = window.confirm("Are you sure you want to purge all seed/sample data? This will remove sample creators, demo deals, and onboarding test records.");
    if (!confirm) return;
    setIsPurgingSeedData(true);
    setMaintenanceFeedback(null);
    try {
      if (onPurgeSeedData) {
        await onPurgeSeedData();
      } else {
        const { purgeLegacySeedDataFromFirestore } = await import("../lib/firebase");
        await purgeLegacySeedDataFromFirestore();
      }
      setMaintenanceFeedback({
        type: 'success',
        title: 'Purge Complete',
        message: 'Successfully removed sample creators, mock invoices, and demo deals from your database and active roster.'
      });
      triggerNotification('Seed Data Purged', 'Sample data successfully removed.', 'success');
    } catch (err: any) {
      console.warn('Purge error:', err);
      setMaintenanceFeedback({
        type: 'error',
        title: 'Purge Failed',
        message: err?.message || 'Failed to complete data purge. Check console for details.'
      });
      triggerNotification('Purge Failed', 'Could not complete data purge.', 'danger');
    } finally {
      setIsPurgingSeedData(false);
    }
  };

  const handleRunCreatorMigration = async () => {
    if (isMigratingCreators) return;
    setIsMigratingCreators(true);
    setMaintenanceFeedback(null);
    try {
      if (onMigrateCreatorsToStudio) {
        await onMigrateCreatorsToStudio();
      } else {
        const { migrateCreatorsToStudioCreators } = await import("../lib/firebase");
        await migrateCreatorsToStudioCreators(creators || []);
      }
      setMaintenanceFeedback({
        type: 'success',
        title: 'Schema Synchronized',
        message: 'All roster creators have been synchronized with the unified studio-creators collection.'
      });
      triggerNotification('Sync Complete', 'Creators schema successfully synced.', 'success');
    } catch (err: any) {
      console.warn('Migration error:', err);
      setMaintenanceFeedback({
        type: 'error',
        title: 'Sync Failed',
        message: err?.message || 'Failed to sync creators to studio schema.'
      });
      triggerNotification('Sync Failed', 'Could not sync creators.', 'danger');
    } finally {
      setIsMigratingCreators(false);
    }
  };

  const fetchLedger = async () => {
    try {
      const headers: Record<string, string> = {
        'Accept': 'application/json'
      };
      try {
        const authHeaders = await getAuthHeaders();
        if (authHeaders && typeof authHeaders === 'object') {
          for (const [k, v] of Object.entries(authHeaders)) {
            if (typeof k === 'string' && typeof v === 'string' && /^[\x21-\x7E]+$/.test(v)) {
              headers[k] = v;
            }
          }
        }
      } catch (authErr) {
        console.warn('Could not retrieve auth headers for ledger:', authErr);
      }

      const res = await fetch('/api/ledger-transactions', { headers });
      if (!res.ok) {
        // Silently skip if forbidden or unauthenticated
        return;
      }
      const data = await res.json();
      if (data && data.status === 'success' && Array.isArray(data.transactions)) {
        // Map API transaction schema to the local payoutLedger UI schema
        const mapped = data.transactions.map((t: any) => {
          let datePaid = '-';
          if (t.status === 'Settled / Paid' || t.status === 'Paid') {
            try {
              if (typeof t.timestamp === 'string') {
                datePaid = t.timestamp.split('T')[0];
              } else if (t.timestamp && typeof t.timestamp.toDate === 'function') {
                datePaid = t.timestamp.toDate().toISOString().split('T')[0];
              }
            } catch (e) {
              console.warn('Could not parse timestamp:', t.timestamp, e);
            }
          }
          return {
            id: t.id || t.transactionId || Math.random().toString(),
            dealTitle: t.milestone || 'Direct Deal',
            brand: t.brand || 'Agency Direct',
            creator: t.creator || '@creator',
            creatorName: t.creatorName || 'Assigned Talent',
            amount: Number(t.grossAmount) || 0,
            status: (t.status === 'Settled / Paid' || t.status === 'Paid') ? 'Paid' : 'Pending',
            payoutMethod: t.type === 'Escrow Deposit' ? 'Stripe Escrow Pre-Fund' : 'Direct Transfer',
            datePaid
          };
        });
        setPayoutLedger(mapped);
      }
    } catch (err) {
      console.warn('Failed to fetch ledger:', err);
    }
  };

  useEffect(() => {
    fetchLedger();
  }, [activeScreen]);

  // Dynamic Commission Split Policy States
  const [baselineCommission, setBaselineCommission] = useState(20);
  const [exclusiveAgencyCut, setExclusiveAgencyCut] = useState<number>(() => {
    const saved = localStorage.getItem('wl_exclusive_agency_cut');
    return saved ? parseInt(saved, 10) : 20; // 20% standard for exclusive
  });
  const [nonExclusiveAgencyCut, setNonExclusiveAgencyCut] = useState<number>(() => {
    const saved = localStorage.getItem('wl_non_exclusive_agency_cut');
    return saved ? parseInt(saved, 10) : 30; // 30% standard for non-exclusive
  });
  const [oneTimeAgencyCut, setOneTimeAgencyCut] = useState<number>(() => {
    const saved = localStorage.getItem('wl_onetime_agency_cut');
    return saved ? parseInt(saved, 10) : 15; // User chosen custom split
  });
  const [flatFeeAmount, setFlatFeeAmount] = useState<number>(() => {
    const saved = localStorage.getItem('wl_flat_fee_amount');
    return saved ? parseInt(saved, 10) : 500; // Flat fee category standard
  });
  const [flatFeeType, setFlatFeeType] = useState<'per_deal' | 'monthly_retainer' | 'per_deliverable'>('per_deal');
  const [simulatedDealBudget, setSimulatedDealBudget] = useState<number>(5000);
  const [showWhatYouGetModal, setShowWhatYouGetModal] = useState<boolean>(false);
  const [whatYouGetActiveTier, setWhatYouGetActiveTier] = useState<'all' | 'exclusive' | 'non_exclusive' | 'onetime' | 'flat_fee'>('all');

  // Custom Per-Deal Flat Fee & Compensation Overrides State
  const [customDealFilter, setCustomDealFilter] = useState<'all' | 'custom_flat' | 'standard' | 'custom_percent'>('all');
  const [selectedDealForPricing, setSelectedDealForPricing] = useState<any | null>(null);
  const [dealCompEditModel, setDealCompEditModel] = useState<'standard' | 'custom_flat_fee' | 'custom_percentage'>('custom_flat_fee');
  const [dealCompEditFlatFee, setDealCompEditFlatFee] = useState<number>(500);
  const [dealCompEditCadence, setDealCompEditCadence] = useState<'per_deal' | 'monthly_retainer' | 'per_deliverable'>('per_deal');
  const [dealCompEditCutPercent, setDealCompEditCutPercent] = useState<number>(15);
  const [dealCompEditNotes, setDealCompEditNotes] = useState<string>('');

  const getDealPricingBreakdown = (deal: any) => {
    const budget = Number(deal.budget || deal.value || deal.amount || 0);
    const isCustomFlat = deal.compensationModel === 'custom_flat_fee' || deal.splitType === 'Custom Flat Fee' || (deal.splitType === 'Flat Fee' && deal.flatFeeAmount !== undefined);
    const isCustomPercent = deal.compensationModel === 'custom_percentage' || deal.splitType === 'Custom %' || deal.splitType === 'One-Time';

    if (isCustomFlat) {
      const fee = deal.flatFeeAmount !== undefined ? Number(deal.flatFeeAmount) : flatFeeAmount;
      const agencyTake = Math.min(fee, budget);
      const creatorNet = Math.max(0, budget - agencyTake);
      const cadenceLabel = deal.flatFeeCadence === 'monthly_retainer' ? 'Monthly Retainer' : deal.flatFeeCadence === 'per_deliverable' ? 'Per UGC Video' : 'Per Deal';
      return {
        model: 'custom_flat_fee' as const,
        badgeLabel: `$${fee.toLocaleString()} Flat Fee`,
        badgeColor: 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40',
        cadenceLabel,
        agencyTake,
        creatorNet,
        effectivePercent: budget > 0 ? ((agencyTake / budget) * 100).toFixed(1) : '0.0',
        fee
      };
    }

    if (isCustomPercent) {
      const cut = deal.customAgencyCut !== undefined ? Number(deal.customAgencyCut) : (deal.split ? parseInt(deal.split, 10) : oneTimeAgencyCut);
      const agencyTake = (budget * cut) / 100;
      const creatorNet = budget - agencyTake;
      return {
        model: 'custom_percentage' as const,
        badgeLabel: `${cut}% Custom Cut`,
        badgeColor: 'bg-purple-950/80 text-purple-300 border-purple-500/40',
        cadenceLabel: 'Per Deal',
        agencyTake,
        creatorNet,
        effectivePercent: cut.toString(),
        cut
      };
    }

    // Standard Exclusive vs Non-Exclusive
    const cut = deal.splitType === 'Non-Exclusive' ? nonExclusiveAgencyCut : exclusiveAgencyCut;
    const agencyTake = (budget * cut) / 100;
    const creatorNet = budget - agencyTake;
    return {
      model: 'standard' as const,
      badgeLabel: `${cut}% Standard Split`,
      badgeColor: 'bg-amber-950/80 text-amber-300 border-amber-500/40',
      cadenceLabel: 'Standard Agency',
      agencyTake,
      creatorNet,
      effectivePercent: cut.toString(),
      cut
    };
  };

  const handleApplyQuickDealFlatFee = (dealId: string, feeAmount: number, cadence: 'per_deal' | 'monthly_retainer' | 'per_deliverable' = 'per_deal') => {
    if (!setDeals) return;
    const updatedPayload = {
      compensationModel: 'custom_flat_fee',
      splitType: 'Custom Flat Fee',
      split: `$${feeAmount.toLocaleString()} Flat Fee`,
      flatFeeAmount: feeAmount,
      flatFeeCadence: cadence
    };
    setDeals((prev: any[]) => prev.map((d: any) => d.id === dealId ? { ...d, ...updatedPayload } : d));
    setDoc(doc(db, 'studio-deals', dealId), updatedPayload, { merge: true }).catch((err) => {
      console.error('[studio-deals] Failed to update quick flat fee on server:', err);
      triggerNotification('Sync Error', 'Failed to save pricing change to server. Changes may revert.', 'danger');
    });
    triggerNotification('Deal Pricing Updated', `Applied $${feeAmount.toLocaleString()} Custom Flat Fee to deal.`, 'success');
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Set deal ${dealId} to $${feeAmount} custom flat fee`);
  };

  const handleApplyQuickStandardSplit = (dealId: string) => {
    if (!setDeals) return;
    const updatedPayload = {
      compensationModel: 'standard',
      splitType: 'Standard',
      split: `${exclusiveAgencyCut}% Agency Split`,
      flatFeeAmount: undefined,
      customAgencyCut: undefined
    };
    setDeals((prev: any[]) => prev.map((d: any) => d.id === dealId ? { ...d, ...updatedPayload } : d));
    setDoc(doc(db, 'studio-deals', dealId), updatedPayload, { merge: true }).catch((err) => {
      console.error('[studio-deals] Failed to reset standard split on server:', err);
      triggerNotification('Sync Error', 'Failed to save standard split reset to server. Changes may revert.', 'danger');
    });
    triggerNotification('Deal Reset to Standard', `Deal reset to agency standard split (${exclusiveAgencyCut}%).`, 'info');
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Reset deal ${dealId} to standard ${exclusiveAgencyCut}% agency split`);
  };

  const handleSaveDealPricingModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDealForPricing || !setDeals) return;
    const dealId = selectedDealForPricing.id;
    const budget = Number(selectedDealForPricing.budget || selectedDealForPricing.value || 0);

    let updatedFields: any = {
      compensationModel: dealCompEditModel,
      dealPricingNotes: dealCompEditNotes
    };

    if (dealCompEditModel === 'custom_flat_fee') {
      const agencyEarnings = Math.min(dealCompEditFlatFee, budget);
      const creatorPayout = Math.max(0, budget - agencyEarnings);
      updatedFields = {
        ...updatedFields,
        splitType: 'Custom Flat Fee',
        split: `$${dealCompEditFlatFee.toLocaleString()} Flat Fee`,
        flatFeeAmount: dealCompEditFlatFee,
        flatFeeCadence: dealCompEditCadence,
        customAgencyCut: undefined,
        agencyEarnings,
        creatorPayout
      };
    } else if (dealCompEditModel === 'custom_percentage') {
      const agencyEarnings = Math.round((budget * dealCompEditCutPercent) / 100);
      const creatorPayout = budget - agencyEarnings;
      updatedFields = {
        ...updatedFields,
        splitType: 'Custom %',
        split: `${dealCompEditCutPercent}% Custom Agency Cut`,
        customAgencyCut: dealCompEditCutPercent,
        flatFeeAmount: undefined,
        flatFeeCadence: undefined,
        agencyEarnings,
        creatorPayout
      };
    } else {
      const cut = selectedDealForPricing.splitType === 'Non-Exclusive' ? nonExclusiveAgencyCut : exclusiveAgencyCut;
      const agencyEarnings = Math.round((budget * cut) / 100);
      const creatorPayout = budget - agencyEarnings;
      updatedFields = {
        ...updatedFields,
        splitType: selectedDealForPricing.splitType === 'Non-Exclusive' ? 'Non-Exclusive' : 'Standard',
        split: `${cut}% Agency Split`,
        flatFeeAmount: undefined,
        flatFeeCadence: undefined,
        customAgencyCut: undefined,
        agencyEarnings,
        creatorPayout
      };
    }

    setDeals((prev: any[]) => prev.map((d: any) => d.id === dealId ? { ...d, ...updatedFields } : d));
    setDoc(doc(db, 'studio-deals', dealId), updatedFields, { merge: true }).catch((err) => {
      console.error('[studio-deals] Failed to save deal pricing modal changes on server:', err);
      triggerNotification('Sync Error', 'Failed to save deal pricing configuration to server. Changes may revert.', 'danger');
    });
    triggerNotification('Deal Pricing Saved', `Updated compensation structure for ${selectedDealForPricing.brand} (${selectedDealForPricing.id}).`, 'success');
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Configured custom compensation on deal ${selectedDealForPricing.id} (${dealCompEditModel === 'custom_flat_fee' ? `$${dealCompEditFlatFee} flat fee` : dealCompEditModel})`);
    setSelectedDealForPricing(null);
  };

  // Sync Commission Policy to/from Firestore & localStorage
  useEffect(() => {
    try {
      localStorage.setItem('wl_exclusive_agency_cut', exclusiveAgencyCut.toString());
      localStorage.setItem('wl_non_exclusive_agency_cut', nonExclusiveAgencyCut.toString());
      localStorage.setItem('wl_onetime_agency_cut', oneTimeAgencyCut.toString());
      localStorage.setItem('wl_flat_fee_amount', flatFeeAmount.toString());
    } catch (e) {
      console.warn('Could not cache commission policy to localStorage', e);
    }
  }, [exclusiveAgencyCut, nonExclusiveAgencyCut, oneTimeAgencyCut, flatFeeAmount]);

  useEffect(() => {
    const docRef = doc(db, 'studio-commission-policy', 'active_policy');
    const unsub = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.exclusiveAgencyCut !== undefined) setExclusiveAgencyCut(data.exclusiveAgencyCut);
        if (data.nonExclusiveAgencyCut !== undefined) setNonExclusiveAgencyCut(data.nonExclusiveAgencyCut);
        if (data.oneTimeAgencyCut !== undefined) setOneTimeAgencyCut(data.oneTimeAgencyCut);
        if (data.flatFeeAmount !== undefined) setFlatFeeAmount(data.flatFeeAmount);
        if (data.flatFeeType !== undefined) setFlatFeeType(data.flatFeeType);
      }
    }, (err) => console.warn('[studio-commission-policy]', err));
    return () => unsub();
  }, []);

  // Form Fields States
  const [inputText, setInputText] = useState('');
  const [inputTitle, setInputTitle] = useState('');
  const [inputNiche, setInputNiche] = useState('Beauty');
  const [inputSeverity, setInputSeverity] = useState('Medium');

  // New Referrals form states
  const [refReferrer, setRefReferrer] = useState('');
  const [refReferred, setRefReferred] = useState('');
  const [refType, setRefType] = useState('Creator');
  const [refValue, setRefValue] = useState('$200');

  // New Retainers form states
  const [retBrand, setRetBrand] = useState('');
  const [retAmount, setRetAmount] = useState('');
  const [retPosts, setRetPosts] = useState('');
  const [retNextInvoice, setRetNextInvoice] = useState('');
  const [retPaidStatus, setRetPaidStatus] = useState('Received');

  // New Rate history form states
  const [rateHandle, setRateHandle] = useState('');
  const [rateType, setRateType] = useState('TikTok Video');
  const [rateOld, setRateOld] = useState('');
  const [rateNew, setRateNew] = useState('');
  const [rateAgent, setRateAgent] = useState('Marcus Cole');
  const [rateReason, setRateReason] = useState('');
  const [rateIsMultiPlatform, setRateIsMultiPlatform] = useState(false);
  const [multiPlatformRates, setMultiPlatformRates] = useState<{ [key: string]: { oldRate: string; newRate: string; enabled: boolean } }>({
    'TikTok Video': { oldRate: '$1,200', newRate: '$1,500', enabled: true },
    'Instagram Reel': { oldRate: '$1,000', newRate: '$1,200', enabled: true },
    'YouTube Video': { oldRate: '$2,000', newRate: '$2,500', enabled: true },
    'TikTok Live integration': { oldRate: '$800', newRate: '$1,000', enabled: false },
    'UGC Deliverable': { oldRate: '$600', newRate: '$850', enabled: false }
  });

  // New Agent manager states & Dual-Role configuration
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentEmail, setNewAgentEmail] = useState('');
  const [newAgentRole, setNewAgentRole] = useState('Agent manager');
  const [newAgentHeadcount, setNewAgentHeadcount] = useState('');
  const [newAgentSplit, setNewAgentSplit] = useState('15%');
  const [newAgentIsSignedCreator, setNewAgentIsSignedCreator] = useState(false);
  const [newAgentSignedHandle, setNewAgentSignedHandle] = useState('');
  const [newAgentSignedSplit, setNewAgentSignedSplit] = useState('80% Creator / 20% Agency');
  const [newAgentSignedNiche, setNewAgentSignedNiche] = useState('Lifestyle & UGC');

  // Modal / Drawer state for editing an existing Agent Manager's dual-role status
  const [editingDualRoleAgent, setEditingDualRoleAgent] = useState<any | null>(null);
  const [selectedAgentAgreementForView, setSelectedAgentAgreementForView] = useState<any | null>(null);

  // Agent Onboard Form Dual-Role State
  const [aoIsSignedCreator, setAoIsSignedCreator] = useState(false);
  const [aoSignedHandle, setAoSignedHandle] = useState('');
  const [aoSignedSplit, setAoSignedSplit] = useState('80% Creator / 20% Agency');
  const [aoSignedNiche, setAoSignedNiche] = useState('Beauty & Lifestyle');
  const handleBotToggle = async () => {
    const nextState = !botsActive;
    setBotsActive(nextState);
    const tenantDocId = `${currentUser?.tenantId || activeTenantId || 'bloom_studio_default'}_bot_status`;
    try {
      await setDoc(doc(db, 'studio-agency-settings', tenantDocId), {
        botsActive: nextState,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser?.name || 'Director',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || activeTenantId || 'bloom_studio_default'
      }, { merge: true });
    } catch (err) {
      console.warn('[OperationBoard] Failed to persist bot toggle to Firestore:', err);
    }
    triggerNotification('Autopilot Bots', `Agency auto-scouting and DM marketing bots are now ${nextState ? 'ACTIVE' : 'PAUSED'}.`, nextState ? 'success' : 'warning');
    onAddActivityLog(currentUser?.name || 'Sarah Jenkins', currentRole || 'director', `${nextState ? 'Activated' : 'Suspended'} automatic scouting algorithms`);
  };

  const handleApproveScout = async (id: string, handle: string) => {
    setScrapedTalents(prev => prev.filter(t => t.id !== id));
    const waitlistId = 'w_' + (id.startsWith('scout_') ? id : id);
    const creatorName = handle.substring(1).replace(/^\w/, c => c.toUpperCase());
    const newEntry = {
      id: waitlistId,
      name: creatorName,
      handle,
      niche: 'Scouted',
      engagement: '5.5%',
      applyDate: 'Just now',
      status: 'Pending Review',
      subagency: currentUser?.subagency || activeTenantId || 'pod_main',
      tenantId: currentUser?.tenantId || 'bloom_studio_default',
      createdAt: new Date().toISOString()
    };
    setWaitlistCreators(prev => [newEntry, ...prev.filter(x => x.id !== waitlistId)]);

    try {
      await setDoc(doc(db, 'studio_waitlist', waitlistId), newEntry, { merge: true });
    } catch (err) {
      console.warn('Failed to save scout to studio_waitlist in Firestore:', err);
    }

    triggerNotification('Scout Approved', `${handle} moved to the agency vetting waitlist.`, 'success');
    onAddActivityLog(currentUser?.name || 'Staff', currentRole || 'director', `Approved scout candidate: ${handle}`);
  };

  const handleApproveWaitlist = async (id: string, name: string, handle: string) => {
    setWaitlistCreators(prev => prev.filter(c => c.id !== id));

    try {
      await setDoc(doc(db, 'studio_waitlist', id), {
        status: currentRole !== 'director' ? 'Under Review' : 'Approved',
        approvedAt: new Date().toISOString(),
        approvedBy: currentUser?.name || 'Director',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default'
      }, { merge: true });
    } catch (err) {
      console.warn('Failed to update studio_waitlist in Firestore:', err);
    }

    const creatorId = 'c_wait_' + Date.now();
    const actionQueueId = 'aq_wait_' + Date.now();

    if (currentRole !== 'director') {
      // 1. Add to creators list with status: 'Pending Director Approval'
      const pendingCreator = {
        id: creatorId,
        name,
        handle,
        platform: 'TikTok',
        niche: 'Lifestyle & Fashion',
        followers: '100K',
        eng: '4.2%',
        agreement: 'Proposed (80-20%)',
        status: 'Pending Director Approval',
        assignedAgent: currentUser?.name || 'Marcus Cole',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        createdAt: new Date().toISOString()
      };

      if (setCreators) {
        setCreators(prev => [...prev, pendingCreator]);
      }

      try {
        await setDoc(doc(db, 'studio-creators', creatorId), pendingCreator, { merge: true });
      } catch (err) {
        console.warn('Failed to save pending creator to Firestore:', err);
      }

      // 2. Add to Director's actionQueue
      const queueItem = {
        id: actionQueueId,
        tag: 'TALENT SIGNING',
        tagColor: '#C9A46A',
        title: `Approve Representation Contract for ${name} (${handle})`,
        timestamp: 'Just now',
        createdAt: new Date().toISOString(),
        isCompleted: false,
        associatedWaitlistHandle: handle,
        associatedWaitlistName: name,
        associatedCreatorId: creatorId,
        createdByAgent: currentUser?.name || 'Marcus Cole',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default'
      };

      if (setActionQueue) {
        setActionQueue(prev => [queueItem, ...prev]);
      }

      try {
        await setDoc(doc(db, 'studio-action-queue', actionQueueId), queueItem, { merge: true });
      } catch (err) {
        console.warn('Failed to save to studio-action-queue in Firestore:', err);
      }

      // 3. Dispatch alert notification to Director
      try {
        const notifId = 'notif_' + Date.now();
        await setDoc(doc(db, 'studio-notifications', notifId), {
          id: notifId,
          title: 'Talent Representation Approval Required',
          message: `${currentUser?.name || 'An agent'} submitted representation proposal for ${name} (${handle}). Director sign-off required.`,
          time: 'Just now',
          createdAt: new Date().toISOString(),
          read: false,
          type: 'warning',
          priority: 'high',
          recipientRole: 'director',
          subagency: currentUser?.subagency || activeTenantId || 'pod_main',
          tenantId: currentUser?.tenantId || 'bloom_studio_default'
        });
      } catch (notifErr) {
        console.warn('Failed to send director notification:', notifErr);
      }

      triggerNotification('Representation Proposal Routed', `Submitted representation proposal for ${name} to Director for final review.`, 'success');
      onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Submitted contract proposal for waitlist candidate: ${name}`);
    } else {
      // Direct Director Approval
      const onboardedCreator = {
        id: creatorId,
        name,
        handle,
        platform: 'TikTok',
        niche: 'Lifestyle & Fashion',
        followers: '100K',
        eng: '4.2%',
        agreement: 'Proposed (80-20%)',
        status: 'Pending Onboarding',
        assignedAgent: currentUser?.name || 'Director',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        createdAt: new Date().toISOString()
      };

      if (setCreators) {
        setCreators(prev => [...prev, onboardedCreator]);
      }

      try {
        await setDoc(doc(db, 'studio-creators', creatorId), onboardedCreator, { merge: true });
      } catch (err) {
        console.warn('Failed to save creator to Firestore:', err);
      }

      // Generate onboarding checklist
      if (setOnboardingItems) {
        setOnboardingItems(prev => [
          ...prev,
          {
            id: 'onb_' + Date.now(),
            name,
            handle,
            createdByAgent: currentUser?.name || 'Director',
            urgency: 'Normal',
            steps: [
              { step: 'Sign Talent Agreement', done: false },
              { step: 'Upload Federal W-9 Form', done: false },
              { step: 'Conduct Social Brand Audit', done: false },
              { step: 'Setup Media Kit & Rates', done: false }
            ]
          }
        ]);
      }

      triggerNotification('Onboarding Triggered', `${name} (${handle}) waitlist petition accepted. DocuSign onboarding bundle emailed automatically.`, 'success');
      onAddActivityLog(currentUser?.name || 'Director', 'director', `Approved waitlist creator to roster: ${name}`);
    }
  };

  const handleAddCrisis = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText || !inputTitle) return;
    const isAgentManager = currentRole === 'agentmgr';
    const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;
    const creatorHandle = inputTitle.startsWith('@') ? inputTitle : `@${inputTitle}`;
    const crisisId = 'c_' + Date.now();
    const now = new Date().toISOString();

    if (isAgentManager) {
      const crisisRecord = { 
        id: crisisId, 
        creator: creatorHandle, 
        brand: 'Under Evaluation', 
        issue: inputText.trim(), 
        severity: inputSeverity, 
        status: 'Routed to Director',
        paymentSafetyHold: false,
        escrowLocked: false,
        reportedBy: currentUser?.name || 'Agent Manager',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        createdAt: now,
        updatedAt: now
      };

      setCrisisEvents(prev => [crisisRecord, ...prev.filter(x => x.id !== crisisId)]);

      try {
        await setDoc(doc(db, 'studio-crisis-events', crisisId), crisisRecord, { merge: true });
      } catch (err) {
        console.warn('[Crisis Log] Failed to save crisis to Firestore:', err);
      }

      const queueId = 'aq_crisis_' + Date.now();
      const queueItem = {
        id: queueId,
        tag: 'CRISIS INCIDENT',
        tagColor: '#ef4444',
        title: `Crisis Incident Reported for ${creatorHandle} (${inputSeverity} Severity)`,
        timestamp: 'Just now',
        isCompleted: false,
        createdByAgent: currentUser?.name || 'Marcus Cole',
        creatorHandle,
        issue: inputText.trim(),
        severity: inputSeverity,
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        createdAt: now
      };

      if (setActionQueue) {
        setActionQueue(prev => [queueItem, ...prev.filter(x => x.id !== queueId)]);
      }

      try {
        await setDoc(doc(db, 'studio-action-queue', queueId), queueItem, { merge: true });
      } catch (err) {
        console.warn('[Crisis Action Queue] Failed to save to Firestore:', err);
      }

      try {
        const notifRef = collection(db, 'studio-notifications');
        await addDoc(notifRef, {
          title: `Crisis Incident Reported: ${creatorHandle}`,
          message: `${currentUser?.name || 'Agent Manager'} routed a ${inputSeverity} severity crisis for ${creatorHandle} to Director for payment safety hold evaluation.`,
          severity: 'warning',
          role: 'director',
          subagency: currentUser?.subagency || activeTenantId || 'pod_main',
          tenantId: currentUser?.tenantId || 'bloom_studio_default',
          createdAt: now
        });
      } catch (notifErr) {
        console.warn('[Crisis Notification] Failed to dispatch director alert:', notifErr);
      }

      triggerNotification('Crisis Incident Routed', `Incident for ${creatorHandle} routed to Director for payment safety hold evaluation.`, 'warning');
      onAddActivityLog(currentUser?.name || 'Marcus Cole', 'agentmgr', `Reported crisis incident for ${creatorHandle} to Director`);
    } else {
      // Genuine Director Payment Safety Hold & Escrow Locking
      const lockedDealIds = await lockEscrowForCreator(creatorHandle, inputText.trim());
      const crisisRecord = { 
        id: crisisId, 
        creator: creatorHandle, 
        brand: 'Under Evaluation', 
        issue: inputText.trim(), 
        severity: inputSeverity, 
        status: 'Payment Safety Hold Active',
        paymentSafetyHold: true,
        escrowLocked: true,
        lockedCards: true,
        lockedDealIds,
        reportedBy: currentUser?.name || 'Director',
        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        createdAt: now,
        updatedAt: now
      };

      setCrisisEvents(prev => [crisisRecord, ...prev.filter(x => x.id !== crisisId)]);

      try {
        await setDoc(doc(db, 'studio-crisis-events', crisisId), crisisRecord, { merge: true });
      } catch (err) {
        console.warn('[Crisis Log] Failed to save crisis to Firestore:', err);
      }

      try {
        const notifRef = collection(db, 'studio-notifications');
        await addDoc(notifRef, {
          title: `🛡️ Payment Safety Hold: ${creatorHandle}`,
          message: `Director activated payment safety hold on ${lockedDealIds.length} deal(s) and corporate debit accounts for ${creatorHandle}.`,
          severity: 'danger',
          role: 'director',
          subagency: currentUser?.subagency || activeTenantId || 'pod_main',
          tenantId: currentUser?.tenantId || 'bloom_studio_default',
          createdAt: now
        });
      } catch (notifErr) {
        console.warn('[Crisis Notification] Failed to dispatch safety hold alert:', notifErr);
      }

      triggerNotification(
        'Payment Safety Hold Activated', 
        `Safety hold active: Locked card payouts & escrow across ${lockedDealIds.length} deal(s) for ${creatorHandle}.`, 
        'danger'
      );
      onAddActivityLog(currentUser?.name || 'Sarah Jenkins', 'director', `Registered active crisis event & placed payment safety hold on ${creatorHandle} (${lockedDealIds.length} deals locked)`);
    }

    setInputText('');
    setInputTitle('');
  };

  const handleLockEscrowForCrisis = async (evt: any) => {
    const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;
    if (!isDirector) {
      triggerNotification('Access Denied', 'Payment safety hold authority is restricted to Directors and Platform Owners.', 'warning');
      return;
    }

    const lockedDealIds = await lockEscrowForCreator(evt.creator, evt.issue || 'Director Crisis Lock');
    const updatedEvt = { 
      ...evt, 
      paymentSafetyHold: true,
      escrowLocked: true, 
      lockedCards: true,
      status: 'Payment Safety Hold Active', 
      lockedDealIds, 
      lockedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    setCrisisEvents(prev => prev.map(c => c.id === evt.id ? updatedEvt : c));

    try {
      await setDoc(doc(db, 'studio-crisis-events', evt.id), updatedEvt, { merge: true });
    } catch (err) {
      console.warn('[Payment Safety Hold] Failed to update crisis in Firestore:', err);
    }

    triggerNotification('Payment Safety Hold Activated', `Safety hold placed: Locked card payouts & escrow across ${lockedDealIds.length} deal(s) for ${evt.creator}.`, 'danger');
    onAddActivityLog(currentUser?.name || 'Sarah Jenkins', 'director', `Placed payment safety hold on ${lockedDealIds.length} deal(s) & cards for ${evt.creator}`);
  };

  const handleResolveCrisisTicket = async (evt: any) => {
    const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;
    if (!isDirector) {
      triggerNotification('Access Denied', 'Resolving crisis tickets and releasing safety holds is restricted to Directors.', 'warning');
      return;
    }

    const unlockedDealIds = await unlockEscrowForCreator(evt.creator);
    setCrisisEvents(prev => prev.filter(c => c.id !== evt.id));

    try {
      await deleteDoc(doc(db, 'studio-crisis-events', evt.id));
    } catch (err) {
      console.warn('[Crisis Resolve] Failed to delete crisis doc in Firestore:', err);
    }

    triggerNotification('Safety Hold Released', `Payment safety holds released across ${unlockedDealIds.length} deal(s) and card accounts. Crisis ticket closed.`, 'success');
    onAddActivityLog(currentUser?.name || 'Sarah Jenkins', 'director', `Resolved crisis ticket and released payment safety hold across ${unlockedDealIds.length} deal(s) for ${evt.creator}`);
  };

  const handleAddBlacklist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputTitle || !inputText) return;
    
    // Security check: Only directors, admins, or platform owners can add to global blacklist
    const normalizedRole = (currentRole || currentUser?.role || '').toLowerCase();
    const isAdminOrDirector = ['director', 'agency', 'admin', 'owner'].includes(normalizedRole) || !!currentUser?.isPlatformOwner;
    if (!isAdminOrDirector) {
      triggerNotification('Access Denied', 'Only Directors and Administrators can blacklist brand partners.', 'warning');
      return;
    }

    const brandName = inputTitle.trim();
    const reason = inputText.trim();
    const blacklistId = 'bl_' + Date.now();
    const formattedDate = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const createdAt = new Date().toISOString();

    const record: BlacklistEntry = {
      id: blacklistId,
      brand: brandName,
      reason,
      date: formattedDate,
      blockedBy: currentUser?.name || currentUser?.email || 'Agency Director',
      subagency: currentUser?.subagency || activeTenantId || 'pod_main',
      tenantId: currentUser?.tenantId || 'bloom_studio_default',
      createdAt
    };

    try {
      // 1. Direct write to Firestore 'global-blacklist' collection
      await setDoc(doc(db, 'global-blacklist', blacklistId), record, { merge: true });

      // 2. Also mirror via service helper & API sync
      const authHeaders = await getAuthHeaders();
      await addBrandToGlobalBlacklist({
        brand: brandName,
        reason,
        blockedBy: record.blockedBy,
        subagency: record.subagency,
        tenantId: record.tenantId,
        authHeaders
      });

      // 3. Update local component state
      setBlacklistedBrands(prev => [record, ...prev.filter(x => x.id !== record.id)]);
      setInputTitle('');
      setInputText('');
      triggerNotification('Brand Blacklisted', `${brandName} written to 'global-blacklist' collection. All contract and deal initiation is blocked.`, 'warning');
      onAddActivityLog(currentUser?.name || 'Director HQ', 'director', `Added ${brandName} to global-blacklist (${reason})`);
    } catch (err: any) {
      console.warn('[Blacklist] Failed to persist blacklist entry to Firestore:', err);
      triggerNotification('Error', `Failed to write blacklist entry: ${err?.message || 'Database error'}`, 'danger');
    }
  };

  const handleRemoveBlacklist = async (brandItem: any) => {
    const normalizedRole = (currentRole || currentUser?.role || '').toLowerCase();
    const isAdminOrDirector = ['director', 'agency', 'admin', 'owner'].includes(normalizedRole) || !!currentUser?.isPlatformOwner;
    if (!isAdminOrDirector) {
      triggerNotification('Access Denied', 'Only Directors and Administrators can unblock blacklisted brand partners.', 'warning');
      return;
    }

    try {
      // 1. Direct delete from Firestore 'global-blacklist' collection
      await deleteDoc(doc(db, 'global-blacklist', brandItem.id));

      // 2. Mirror removal via service helper
      const authHeaders = await getAuthHeaders();
      await removeBrandFromGlobalBlacklist(brandItem.id, authHeaders);

      // 3. Update local component state
      setBlacklistedBrands(prev => prev.filter(x => x.id !== brandItem.id));
      triggerNotification('Brand Restored', `${brandItem.brand} removed from global-blacklist collection and unblocked agency-wide.`, 'success');
      onAddActivityLog(currentUser?.name || 'Director HQ', 'director', `Removed ${brandItem.brand} from global-blacklist`);
    } catch (err: any) {
      console.warn('[Blacklist] Failed to delete blacklist entry from Firestore:', err);
      triggerNotification('Error', `Failed to remove blacklist entry: ${err?.message || 'Database error'}`, 'danger');
    }
  };

  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputTitle || !inputText) return;
    
    const isDir = ['director', 'agency'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;
    const isAgentManager = (currentRole || '').toLowerCase() === 'agentmgr';

    if (!isDir && (!isAgentManager || !agentMgrCanAnnounce)) {
      triggerNotification('Access Denied', 'Broadcast authority is restricted to Directors and authorized Agent Managers.', 'warning');
      return;
    }

    const targetAudience = activeScreen === 'creator-announcements'
      ? (isAgentManager ? 'Assigned Roster' : 'Creators Only')
      : activeScreen === 'team-announcements'
      ? 'Staff Only'
      : (isAgentManager ? 'Assigned Roster' : 'All Agency');

    const announcementId = 'an_' + Date.now();
    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    const announcementPayload = {
      id: announcementId,
      title: inputTitle.trim(),
      text: inputText.trim(),
      date: formattedDate,
      createdAt: now.toISOString(),
      author: currentUser?.name || (isAgentManager ? 'Agent Manager' : 'Agency Director'),
      audience: targetAudience,
      readBy: [currentUser?.name || currentUser?.handle || 'Director'],
      channels: ['dashboard', 'push', 'sms']
    };

    if (onSendMassBroadcast) {
      try {
        await onSendMassBroadcast(announcementPayload, {
          sendPush: true,
          sendSms: true,
          sendChat: true,
          sendEmail: false
        });
      } catch (err) {
        console.warn('onSendMassBroadcast call error:', err);
      }
    } else {
      setAnnouncements(prev => [announcementPayload, ...prev.filter(x => x.id !== announcementId)]);
      try {
        await setDoc(doc(db, 'studio-announcements', announcementId), {
          ...announcementPayload,
          publishedAt: now.toISOString(),
          sentByUid: currentUser?.id || currentUser?.uid || 'dir_01',
          subagency: currentUser?.subagency || activeTenantId || 'pod_main',
          tenantId: currentUser?.tenantId || 'bloom_studio_default'
        });
      } catch (firestoreErr) {
        console.warn('Failed to write announcement to Firestore:', firestoreErr);
      }
    }

    setInputTitle('');
    setInputText('');
    triggerNotification('Announcement Dispatched', `Broadcast notification dispatched to ${targetAudience} across all channels.`, 'success');
    onAddActivityLog(currentUser?.name || (isAgentManager ? 'Marcus Cole' : 'Sarah Jenkins'), currentRole || 'none', `Published [${targetAudience}] announcement: ${inputTitle}`);
  };

  // --- DYNAMIC SWITCH RENDERER ---
  const renderScreenContent = () => {
    const uppercaseScreen = activeScreen.replace('-', ' ').toUpperCase();

    const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
    const isAgent = (currentRole || '').toLowerCase() === 'agent';
    const isCoordinator = (currentRole || '').toLowerCase() === 'coordinator';
    const isDirector = (currentRole || '').toLowerCase() === 'director';
    const isRestrictedRole = isAgentMgr || isAgent || isCoordinator;
    const mgrName = currentUser?.name || (isCoordinator ? 'Alex Vance' : isAgent ? 'Rachel Sterling' : 'Marcus Cole');
    const myCreators = (creators || []).filter(c => {
      const cAgent = (c.assignedAgent || '').toLowerCase();
      const cMgr = (c.assignedManager || '').toLowerCase();
      const cCoord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
      const myNameLower = mgrName.toLowerCase();
      const myHandleLower = (currentUser?.handle || '').toLowerCase();

      const isAssigned = cAgent === myNameLower || cMgr === myNameLower || cCoord === myNameLower ||
        (myHandleLower && (cAgent === myHandleLower || cCoord === myHandleLower));

      return isAssigned &&
        c.name.toLowerCase() !== myNameLower &&
        c.handle.toLowerCase() !== myHandleLower;
    });
    const myHandles = Array.from(new Set(myCreators.map(c => c.handle.toLowerCase()).filter(Boolean)));



    return (() => {
    switch (activeScreen) {
      case 'waitlist':
        const filteredWaitlist = isRestrictedRole
          ? waitlistCreators.filter(w => (w as any).addedBy === currentUser?.name || (w as any).addedBy === mgrName)
          : waitlistCreators;

        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Add Candidate Form */}
              <form 
                onSubmit={async e => {
                  e.preventDefault();
                  const data = new FormData(e.currentTarget);
                  const name = data.get('name') as string;
                  const handle = data.get('handle') as string;
                  const niche = data.get('niche') as string;
                  const eng = data.get('engagement') as string;
                  if (!name || !handle) return;
                  
                  const cleanHandle = handle.startsWith('@') ? handle : `@${handle}`;
                  const isAgentOrMgr = currentRole === 'agentmgr' || currentRole === 'agent';
                  const waitlistId = 'w_' + Date.now();
                  const newCandidate = { 
                    id: waitlistId, 
                    name, 
                    handle: cleanHandle, 
                    niche, 
                    engagement: eng || '4.5%', 
                    applyDate: 'Just now', 
                    addedBy: isAgentOrMgr ? (currentUser?.name || (currentRole === 'agent' ? 'Assigned Agent' : 'Marcus Cole')) : 'director',
                    status: isAgentOrMgr ? 'Pending Director Approval' : 'Approved',
                    subagency: currentUser?.subagency || activeTenantId || 'pod_main',
                    tenantId: currentUser?.tenantId || 'bloom_studio_default',
                    createdAt: new Date().toISOString()
                  };

                  setWaitlistCreators(prev => [...prev, newCandidate]);

                  try {
                    await setDoc(doc(db, 'studio_waitlist', waitlistId), newCandidate, { merge: true });
                  } catch (err) {
                    console.warn('Failed to save waitlist entry to Firestore:', err);
                  }

                  if (isAgentOrMgr) {
                    const queueId = 'aq_waitlist_' + Date.now();
                    const queueDoc = {
                      id: queueId,
                      tag: 'WAITLIST CANDIDATE',
                      tagColor: '#3b82f6',
                      title: `Suggested Waitlist Candidate: ${name} (${cleanHandle})`,
                      timestamp: 'Just now',
                      createdAt: new Date().toISOString(),
                      isCompleted: false,
                      createdByAgent: currentUser?.name || (currentRole === 'agent' ? 'Assigned Agent' : 'Marcus Cole'),
                      subagency: currentUser?.subagency || activeTenantId || 'pod_main',
                      tenantId: currentUser?.tenantId || 'bloom_studio_default'
                    };

                    if (setActionQueue) {
                      setActionQueue(prev => [queueDoc, ...prev]);
                    }

                    try {
                      await setDoc(doc(db, 'studio-action-queue', queueId), queueDoc, { merge: true });
                    } catch (err) {
                      console.warn('Failed to save to studio-action-queue in Firestore:', err);
                    }

                    try {
                      const notifId = 'notif_' + Date.now();
                      await setDoc(doc(db, 'studio-notifications', notifId), {
                        id: notifId,
                        title: 'New Waitlist Candidate Suggested',
                        message: `${currentUser?.name || 'An agent'} suggested candidate ${name} (${cleanHandle}) for vetting and onboarding approval.`,
                        time: 'Just now',
                        createdAt: new Date().toISOString(),
                        read: false,
                        type: 'info',
                        priority: 'normal',
                        recipientRole: 'director',
                        subagency: currentUser?.subagency || activeTenantId || 'pod_main',
                        tenantId: currentUser?.tenantId || 'bloom_studio_default'
                      });
                    } catch (notifErr) {
                      console.warn('Failed to send director notification for waitlist candidate:', notifErr);
                    }
                  }

                  e.currentTarget.reset();
                  if (isAgentOrMgr) {
                    triggerNotification('Candidate Suggested', `${name} (${cleanHandle}) submitted to Director for onboarding approval.`, 'info');
                    onAddActivityLog(currentUser?.name || (currentRole === 'agent' ? 'Assigned Agent' : 'Marcus Cole'), currentRole || 'agent', `Suggested candidate ${cleanHandle} for Director onboarding approval`);
                  } else {
                    triggerNotification('Added to Waitlist', `${name} successfully added to the vetting waitlist.`, 'success');
                    onAddActivityLog(currentUser?.name || 'Director', 'director', `Manually added ${cleanHandle} to vetting waitlist`);
                  }
                }}
                className="lg:col-span-4 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 text-xs"
              >
                <h3 className="font-serif font-semibold text-sm text-[#C9A46A] uppercase tracking-wider">
                  {isRestrictedRole ? 'Suggest Candidate to Director' : 'Add Waitlist Candidate'}
                </h3>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Creator Name</label>
                  <input type="text" name="name" required placeholder="e.g. Rachel Sterling" className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50" />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Social Handle</label>
                  <input type="text" name="handle" required placeholder="e.g. @rachelbeauty" className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50" />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Niche</label>
                  <select name="niche" className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white">
                    <option value="Pets">🐾 Pets</option>
                    <option value="Beauty">💄 Beauty &amp; Skincare</option>
                    <option value="Lifestyle">✨ Lifestyle</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Engagement Rate</label>
                  <input type="text" name="engagement" placeholder="e.g. 6.8%" defaultValue="5.5%" className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none" />
                </div>
                <button type="submit" className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-2.5 rounded-xl font-bold transition-colors">
                  {isRestrictedRole ? 'Submit Candidate for Director Review' : 'Add Creator to Waitlist'}
                </button>
              </form>

              {/* Roster View */}
              <div className="lg:col-span-8 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
                <h3 className="font-serif font-semibold text-lg text-white border-b border-white/5 pb-3">Creator Vetting Waitlist ({filteredWaitlist.length})</h3>
                {filteredWaitlist.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No candidates currently on waitlist.</p>
                ) : (
                  <div className="space-y-3">
                    {filteredWaitlist.map(wait => (
                      <div key={wait.id} className="bg-[#111E33] border border-white/5 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-semibold text-white">{wait.name}</h4>
                            {wait.addedBy && wait.addedBy !== 'director' && (
                              <span className="text-[10px] bg-blue-950 text-blue-300 border border-blue-500/20 px-2 py-0.5 rounded font-mono">
                                Suggested by {wait.addedBy}
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-[#C9A46A] font-mono">{wait.handle}</span>
                          <div className="text-[11px] text-[#7C8AA8] mt-1 flex items-center gap-3">
                            <span>Niche: <strong>{wait.niche}</strong></span>
                            <span>Engagement: <strong className="text-emerald-400">{wait.engagement}</strong></span>
                            <span>Applied: <strong>{wait.applyDate}</strong></span>
                          </div>
                        </div>
                        <div className="flex gap-2 shrink-0 items-center">
                          {isRestrictedRole ? (
                            <span className="text-[11px] bg-amber-950 text-amber-400 border border-amber-500/20 px-3 py-1.5 rounded-xl font-semibold">
                              ⏳ Submitted for Director Approval
                            </span>
                          ) : (
                            <>
                              <button 
                                onClick={async () => { 
                                  setWaitlistCreators(prev => prev.filter(c => c.id !== wait.id)); 
                                  try {
                                    await deleteDoc(doc(db, 'studio_waitlist', wait.id));
                                  } catch (err) {
                                    console.warn('Failed to delete waitlist entry from Firestore:', err);
                                  }
                                  triggerNotification('Waitlist Archived', 'Candidate rejected & archived.', 'info'); 
                                  onAddActivityLog(currentUser?.name || 'Director', 'director', `Removed ${wait.handle} from vetting waitlist`);
                                }} 
                                className="bg-transparent hover:bg-rose-950/20 text-slate-500 hover:text-rose-400 p-2 rounded-xl transition-all"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                              <button onClick={() => handleApproveWaitlist(wait.id, wait.name, wait.handle)} className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors">Approve &amp; Start Onboarding</button>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>
        );

      case 'bot-control':
        return (
          <div className="space-y-6">
            {/* Status Banner */}
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono">
                  ⚡ Local Sandbox Bot Process Monitor
                </div>
                <p className="text-xs text-amber-200/80 leading-relaxed">
                  The processes below execute inside a local event simulation loop. For live production execution across external platforms (Instagram, TikTok, IRS e-File), attach worker containers in your cloud deployment.
                </p>
              </div>
            </div>

            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-5">
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white">Bot Real-Time Process Control Panel</h3>
                  <p className="text-xs text-[#7C8AA8] mt-0.5">Toggle individual robotic agents, view active run metrics, or trigger test operations.</p>
                </div>
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/20 text-[10px] uppercase font-bold tracking-wider">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> Engine Live
                </span>
              </div>

              {/* Bot Processes Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                {[
                  { name: 'Outreach Bot', desc: 'Automated intro DMs and follow-ups', status: 'RUNNING', color: 'emerald-400', metrics: '14 Threads Today' },
                  { name: 'FTC compliance audit', desc: 'Auto-flag caption FTC disclosures', status: 'RUNNING', color: 'emerald-400', metrics: '15 Posts Audited' },
                  { name: 'Retention Guard', desc: 'Track creator tenure / risks', status: 'IDLE', color: 'amber-400', metrics: '3 alerts generated' },
                  { name: 'Tax compliance bot', desc: 'Validate W9 submissions & TINs', status: 'RUNNING', color: 'emerald-400', metrics: '2 verified today' }
                ].map((bot, idx) => (
                  <div key={idx} className="bg-[#111E33] border border-white/5 p-4 rounded-xl space-y-3 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <strong className="text-white text-sm block">{bot.name}</strong>
                        <span className={`text-[10px] font-bold text-${bot.color}`}>{bot.status}</span>
                      </div>
                      <p className="text-[#7C8AA8] text-[11px] leading-snug">{bot.desc}</p>
                    </div>
                    <div className="border-t border-white/5 pt-2 mt-2 flex justify-between items-center text-[10px]">
                      <span className="text-[#7C8AA8]">{bot.metrics}</span>
                      <button 
                        onClick={() => {
                          triggerNotification(`${bot.name} Manual Run`, `Forced immediate run cycle of ${bot.name}.`, 'success');
                          onAddActivityLog('Sarah Jenkins', 'director', `Manually triggered bot daemon task: ${bot.name}`);
                        }}
                        className="text-[#C9A46A] hover:underline font-semibold font-sans"
                      >
                        Force Run
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Terminal Logs */}
              <div className="bg-black/40 border border-white/5 rounded-xl p-4 font-mono text-[11px] text-slate-300 space-y-1.5">
                <div className="flex justify-between items-center text-[10px] text-[#7C8AA8] border-b border-white/5 pb-1.5 mb-2">
                  <span>BOT SYSTEM EVENT LEDGER</span>
                  <span className="text-emerald-400">ACTIVE POLLING...</span>
                </div>
                <div className="text-amber-400">[SYSTEM] Starting CRM Autopilot orchestrator...</div>
                <div className="text-emerald-400">[SCOUT-BOT] Scan complete: verified 14 new candidates. Added @bellaglows.</div>
                <div className="text-slate-400">[FTC-BOT] Audited latest post for @alexjones: #ad detected in line 1. Passed.</div>
                <div className="text-slate-400">[TAX-BOT] Polling newly uploaded W-9 PDFs for TIN match...</div>
                <div className="text-rose-400">[RETENTION-BOT] ALERT: @mrealness contract ending in 28 days. Dispatching contract renewal task.</div>
              </div>

            </div>
          </div>
        );

      case 'unified-calendar':
      case 'production-calendar':
      case 'calendar-avail':
      case 'availability-calendar':
      case 'calendar':
        return (
          <UnifiedCalendarHub
            agencySchedules={agencySchedules}
            setAgencySchedules={setAgencySchedules}
            creators={creators}
            deals={deals}
            currentRole={currentRole}
            currentUser={currentUser}
            defaultTab={activeScreen.includes('avail') ? 'availability' : 'production'}
            onAddActivityLog={(u, r, a) => onAddActivityLog && onAddActivityLog(u, r, a)}
            triggerNotification={(t, d, typ) => triggerNotification && triggerNotification(t, d, typ || 'info')}
            primaryBrandColor={primaryBrandColor}
            cardBgColor={cardBgColor}
            onNavigateToScreen={(screenId) => setActiveScreen && setActiveScreen(screenId)}
            myHandles={myHandles}
          />
        );

      case 'crisis-log':
        const filteredCrisisEvents = isRestrictedRole
          ? crisisEvents.filter(e => myHandles.includes((e.creator || '').toLowerCase()))
          : crisisEvents;
        const isAgentManager = currentRole === 'agentmgr';

        return (
          <div className="space-y-6">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white">Agency Crisis &amp; Escrow Flags Log</h3>
                  <p className="text-xs text-slate-400">Project Shield: Natural Language Sentiment &amp; Customer Service Red Flag Scanner</p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <select
                    value={selectedCreatorForCrisisScan}
                    onChange={(e) => setSelectedCreatorForCrisisScan(e.target.value)}
                    className="bg-[#111E33] border border-white/10 text-white text-xs rounded-xl px-3 py-2 outline-none focus:border-rose-500/50"
                  >
                    <option value="">Scan Entire Roster / Default</option>
                    {(creators || []).map((c: any) => (
                      <option key={c.id} value={c.handle}>{c.name} ({c.handle})</option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => handleRunSentimentCrisisScanner(selectedCreatorForCrisisScan)}
                    disabled={isScanningSentiment}
                    className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition cursor-pointer"
                  >
                    <ShieldAlert className={`w-4 h-4 ${isScanningSentiment ? 'animate-pulse' : ''}`} />
                    <span>{isScanningSentiment ? 'Project Shield Scanning Comments...' : '🛡️ Run AI Sentiment & Crisis Scanner'}</span>
                  </button>
                </div>
              </div>

              {sentimentResult && (
                <div className="bg-[#0b1629] border border-rose-500/40 rounded-2xl p-4 space-y-3 animate-fade-in text-xs font-mono">
                  <div className="flex items-center justify-between text-rose-400 border-b border-white/10 pb-2">
                    <span className="font-bold uppercase tracking-wider">Project Shield Sentiment Analysis Report</span>
                    <span className="bg-rose-500/20 text-rose-300 px-2.5 py-0.5 rounded-full text-[10px]">
                      Severity: {sentimentResult.severity} (Score: {sentimentResult.sentimentScore})
                    </span>
                  </div>
                  <div className="space-y-1 text-slate-300">
                    <p><strong className="text-white">Flagged Red Flag Phrases:</strong> {sentimentResult.detectedPhrases?.join(' | ')}</p>
                    <p><strong className="text-white">Manager Directive:</strong> {sentimentResult.recommendedAction}</p>
                  </div>
                </div>
              )}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <form onSubmit={handleAddCrisis} className="lg:col-span-4 bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-4 text-xs">
                  <h4 className="text-xs uppercase font-bold text-rose-400 flex items-center gap-1"><ShieldAlert className="w-4 h-4" /> {isAgentManager ? 'Report Assigned Creator Crisis' : 'Log active crisis'}</h4>
                  <div className="space-y-1.5">
                    <label className="text-[#7C8AA8] text-[10px] uppercase">Creator Handle</label>
                    {isAgentManager ? (
                      <select value={inputTitle} onChange={e => setInputTitle(e.target.value)} required className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-rose-500/50">
                        <option value="">Select assigned creator...</option>
                        {myCreators.map(c => <option key={c.id} value={c.handle}>{c.handle}</option>)}
                      </select>
                    ) : (
                      <input type="text" required placeholder="e.g. @alexjones" value={inputTitle} onChange={e => setInputTitle(e.target.value)} className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-rose-500/50" />
                    )}
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[#7C8AA8] text-[10px] uppercase">Severity</label>
                    <select value={inputSeverity} onChange={e => setInputSeverity(e.target.value)} className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none">
                      <option value="High">High (Immediate Brand Risk)</option>
                      <option value="Medium">Medium (Milestone Delay)</option>
                      <option value="Low">Low (Administrative check)</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[#7C8AA8] text-[10px] uppercase">Description</label>
                    <textarea required rows={3} placeholder="Describe copyright claims, breach details, etc..." value={inputText} onChange={e => setInputText(e.target.value)} className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-rose-500/50" />
                  </div>
                  <button type="submit" className="w-full bg-rose-600 hover:bg-rose-700 text-white py-2 rounded-lg font-semibold transition-colors">
                    {isAgentManager ? 'Report Incident to Director' : 'Activate Payment Safety Hold & Log Event'}
                  </button>
                </form>
                <div className="lg:col-span-8 space-y-3.5">
                  <h4 className="text-xs font-semibold text-[#7C8AA8] uppercase">Active Flagged Incidents</h4>
                  <div className="space-y-2 text-xs">
                    {filteredCrisisEvents.length === 0 ? (
                      <p className="text-slate-500 italic">No active incidents logged.</p>
                    ) : (
                      filteredCrisisEvents.map(evt => {
                        const isHoldActive = evt.paymentSafetyHold || evt.escrowLocked || evt.status === 'Payment Safety Hold Active' || evt.status === 'Escrow Locked';
                        return (
                          <div key={evt.id} className="p-4 bg-[#111E33] border border-rose-500/20 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-bold text-white">{evt.creator}</span>
                                <span className="text-[#7C8AA8]">&middot;</span>
                                <span className="text-slate-300">{evt.brand}</span>
                                <span className="bg-rose-950 text-rose-400 px-2 py-0.5 rounded text-[9px] font-bold">Severity: {evt.severity}</span>
                                {isHoldActive && (
                                  <span className="bg-red-950/80 border border-red-500/40 text-rose-300 px-2 py-0.5 rounded text-[9px] font-mono font-bold">
                                    🛡️ Payment Safety Hold Active
                                  </span>
                                )}
                                {evt.reportedBy && (
                                  <span className="bg-blue-950 text-blue-300 px-2 py-0.5 rounded text-[9px] font-bold">Reported by: {evt.reportedBy}</span>
                                )}
                              </div>
                              <p className="text-[#7C8AA8] leading-relaxed text-[11px]">{evt.issue}</p>
                            </div>
                            <div className="flex gap-2 shrink-0 items-center">
                              {isAgentManager ? (
                                <span className="text-[11px] bg-amber-950 text-amber-400 border border-amber-500/20 px-3 py-1.5 rounded-xl font-semibold">
                                  ⏳ Routed to Director
                                </span>
                              ) : (
                                <>
                                  {!isHoldActive && (
                                    <button onClick={() => handleLockEscrowForCrisis(evt)} className="bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold">Activate Safety Hold</button>
                                  )}
                                  <button onClick={() => handleResolveCrisisTicket(evt)} className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-500/20 px-3 py-1.5 rounded-lg font-semibold transition-colors">Release & Resolve</button>
                                </>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'exclusivity':
      case 'exclusivity-tracker':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Add Lock Form */}
              <form 
                onSubmit={e => {
                  e.preventDefault();
                  const data = new FormData(e.currentTarget);
                  const handle = data.get('handle') as string;
                  const type = data.get('type') as string;
                  const category = data.get('category') as string;
                  const exclusions = data.get('exclusions') as string;
                  const window = data.get('window') as string;
                  if (!handle) return;

                  setExclusivityItems(prev => [
                    ...prev,
                    {
                      id: 'ex_' + Date.now(),
                      handle,
                      type,
                      category: category || 'General Support',
                      exclusions: exclusions || 'N/A',
                      window: window || 'Permanent'
                    }
                  ]);
                  e.currentTarget.reset();
                  triggerNotification('Lock Logged', `Brand exclusivity lock added for ${handle}`, 'success');
                  onAddActivityLog('Sarah Jenkins', 'director', `Logged ${type} contract clause for ${handle}`);
                }}
                className="lg:col-span-4 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 text-xs"
              >
                <h3 className="font-serif font-semibold text-sm text-[#C9A46A] uppercase tracking-wider">Log Exclusivity Clause</h3>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Creator Handle</label>
                  <select name="handle" className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white">
                    {creators.filter(c => !isRestrictedRole || myHandles.includes(c.handle.toLowerCase())).map(c => <option key={c.id} value={c.handle}>{c.handle}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Agreement Type</label>
                  <select name="type" className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white">
                    <option value="Exclusive">Exclusive Lockout</option>
                    <option value="Non-Exclusive">Non-Exclusive (Freely endorse competitors)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Category / Sector</label>
                  <input type="text" name="category" placeholder="e.g. Energy Drinks &amp; Fitness" required className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50" />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Blacklisted Competitor Brands</label>
                  <input type="text" name="exclusions" placeholder="e.g. Monster, Red Bull, Celsius" required className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50" />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Active Window / Duration</label>
                  <input type="text" name="window" placeholder="e.g. July 2026 - Dec 2026" required className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50" />
                </div>
                <button type="submit" className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-2.5 rounded-xl font-bold transition-colors">
                  Log Exclusivity Clause
                </button>
              </form>

              {/* Exclusivity List Table */}
              <div className="lg:col-span-8 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
                <h3 className="font-serif font-semibold text-lg text-white border-b border-white/5 pb-3">Creator Brand Exclusivity Lock Tracker</h3>
                <div className="bg-[#111E33] border border-white/5 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-white/5 bg-[#0D1830] text-[#7C8AA8] uppercase font-mono tracking-wider">
                        <th className="p-3">Creator</th>
                        <th className="p-3">Type</th>
                        <th className="p-3">Exclusivity Category</th>
                        <th className="p-3">Blacklisted Brands</th>
                        <th className="p-3">Active Window</th>
                        <th className="p-3 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-slate-300 font-medium">
                      {exclusivityItems.filter(item => !isRestrictedRole || myHandles.includes(item.handle.toLowerCase())).map(item => (
                        <tr key={item.id} className="hover:bg-white/[0.01] transition-colors">
                          <td className="p-3 text-white font-semibold">{item.handle}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.type === 'Exclusive' ? 'bg-rose-950 text-rose-400' : 'bg-emerald-950 text-emerald-400'}`}>
                              {item.type}
                            </span>
                          </td>
                          <td className="p-3">{item.category}</td>
                          <td className="p-3 text-rose-400 max-w-[150px] truncate" title={item.exclusions}>{item.exclusions}</td>
                          <td className="p-3 text-[#7C8AA8]">{item.window}</td>
                          <td className="p-3 text-center">
                            <button 
                              onClick={() => {
                                setExclusivityItems(prev => prev.filter(x => x.id !== item.id));
                                triggerNotification('Clause Deleted', `Deleted clause for ${item.handle}`, 'warning');
                                onAddActivityLog('Sarah Jenkins', 'director', `Removed contract clause for ${item.handle}`);
                              }}
                              className="text-slate-500 hover:text-rose-400 p-1 rounded transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {exclusivityItems.length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-4 text-center italic text-slate-500">No exclusivity clauses on file.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
        );

      case 'brand-blacklist':
        return (
          <div className="space-y-6">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-6">
              <h3 className="font-serif font-semibold text-lg text-white border-b border-white/5 pb-3">Agency Brand Blacklist</h3>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {isRestrictedRole ? (
                  <div className="lg:col-span-4 bg-[#111E33] p-5 rounded-xl border border-white/5 space-y-3.5 text-xs">
                    <h4 className="text-xs uppercase font-bold text-[#C9A46A]">Director Controlled Registry</h4>
                    <p className="text-slate-400 leading-relaxed">
                      Only the Agency Director has authorization to block or unblock brand partnerships. 
                      Agents can reference this global blacklist to protect their assigned creator rosters.
                    </p>
                    <div className="p-3 bg-[#0D1830] rounded-lg border border-white/5 flex items-center gap-2 text-[11px] text-[#7C8AA8]">
                      🔒 Edit access restricted to Director
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleAddBlacklist} className="lg:col-span-4 bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-4 text-xs">
                    <h4 className="text-xs uppercase font-bold text-amber-500">Blacklist Brand</h4>
                    <div className="space-y-1.5">
                      <label className="text-[#7C8AA8] text-[10px] uppercase">Brand Name</label>
                      <input type="text" required placeholder="e.g. QuickBurn Cosmetics" value={inputTitle} onChange={e => setInputTitle(e.target.value)} className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-amber-500/50" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[#7C8AA8] text-[10px] uppercase">Reason</label>
                      <textarea required rows={3} placeholder="Specify defaults, poor ethics, or client violations..." value={inputText} onChange={e => setInputText(e.target.value)} className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-amber-500/50" />
                    </div>
                    <button type="submit" className="w-full bg-amber-600 hover:bg-amber-700 text-white py-2 rounded-lg font-semibold transition-colors">Block Brand Agency-Wide</button>
                  </form>
                )}
                <div className="lg:col-span-8 space-y-3">
                  <h4 className="text-xs font-semibold text-[#7C8AA8] uppercase">Blocked Registries</h4>
                  <div className="space-y-2 text-xs">
                    {blacklistedBrands.map(b => (
                      <div key={b.id} className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl flex items-start justify-between gap-4">
                        <div>
                          <span className="font-bold text-rose-400">{b.brand}</span>
                          {!isAgent && <p className="text-[11px] text-[#7C8AA8] mt-1 leading-relaxed">{b.reason}</p>}
                          {!isAgent && <span className="text-[10px] text-slate-500 mt-1.5 block">Blocked: {b.date}</span>}
                        </div>
                        {!isRestrictedRole && (
                          <button onClick={() => handleRemoveBlacklist(b)} className="text-xs font-bold text-[#C9A46A] hover:underline">Unblock</button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'team-announcements':
      case 'creator-announcements': {
        const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;
        const isAgentManager = (currentRole || '').toLowerCase() === 'agentmgr';
        const canBroadcast = isDirector || (isAgentManager && agentMgrCanAnnounce);
        const isCreator = currentRole === 'creator';
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-6">
              <div className="border-b border-white/5 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white">
                    {canBroadcast ? 'Broadcast Announcements' : 'Received Agency Notifications'}
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    {canBroadcast
                      ? 'Compose and dispatch broad-reach notifications and SMS alerts to active creator rosters and agent staff feeds.'
                      : 'Official directives, guidelines, and urgent notifications received directly on your mobile device from Agency Leadership.'}
                  </p>
                </div>
                {canBroadcast && onOpenMassBroadcast && (
                  <button
                    onClick={onOpenMassBroadcast}
                    className="bg-[#111E33] hover:bg-[#16243F] text-[#C9A46A] border border-[#C9A46A]/40 px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all shrink-0 self-start sm:self-auto shadow-sm"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Multi-Channel Dispatch Center
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {canBroadcast && (
                  <form onSubmit={handlePostAnnouncement} className="lg:col-span-4 bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-4 text-xs">
                    <h4 className="text-xs uppercase font-bold text-[#C9A46A]">
                      Compose Broadcast
                    </h4>
                    <div className="p-2.5 bg-[#0D1830] border border-amber-500/20 rounded-lg text-[#C9A46A] text-[11px] font-mono">
                      Target Audience: {activeScreen === 'creator-announcements' ? (isAgentManager ? 'Assigned Roster' : 'Creators Only') : 'Staff Only'}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[#7C8AA8] text-[10px] uppercase">Title</label>
                      <input type="text" required placeholder="e.g. Rate Card adjustment" value={inputTitle} onChange={e => setInputTitle(e.target.value)} className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[#7C8AA8] text-[10px] uppercase">Message</label>
                      <textarea required rows={4} placeholder="Write message to dispatch to feeds..." value={inputText} onChange={e => setInputText(e.target.value)} className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]/50" />
                    </div>
                    <button type="submit" className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-2 rounded-lg font-semibold transition-colors">
                      Broadcast
                    </button>
                  </form>
                )}
                <div className={!canBroadcast ? 'lg:col-span-12 space-y-3.5' : 'lg:col-span-8 space-y-3.5'}>
                  <h4 className="text-xs font-semibold text-[#7C8AA8] uppercase">
                    {canBroadcast ? 'Broadcast Logs' : 'Incoming Director Notifications'}
                  </h4>
                  <div className="space-y-3 text-xs">
                    {(() => {
                      const isOlderThan30Days = (ann: any) => {
                        const dateStr = ann.createdAt || ann.date;
                        if (!dateStr) return false;
                        const parsed = new Date(dateStr);
                        if (isNaN(parsed.getTime())) return false;
                        const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
                        return (Date.now() - parsed.getTime()) > thirtyDaysMs;
                      };
                      const displayedAnnouncements = announcements.filter(ann => {
                        if (!canBroadcast && isOlderThan30Days(ann)) return false;
                        if (activeScreen === 'creator-announcements' || isCreator) {
                          return ann.audience === 'Creators Only' || ann.audience === 'Assigned Roster' || ann.audience === 'All Agency' || !ann.audience;
                        }
                        if (activeScreen === 'team-announcements') {
                          return ann.audience === 'Staff Only' || ann.audience === 'All Agency' || !ann.audience;
                        }
                        return true;
                      });
                      return displayedAnnouncements.length === 0 ? (
                        <p className="text-slate-400 italic">No broadcasts have been sent yet.</p>
                      ) : (
                        displayedAnnouncements.map(ann => (
                          <div key={ann.id} className="p-4 bg-[#111E33] border border-white/5 rounded-xl space-y-2">
                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-2">
                                <h4 className="font-bold text-white text-sm">{ann.title}</h4>
                                {ann.audience && (
                                  <span className="text-[9px] bg-amber-950 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded font-mono">
                                    Audience: {ann.audience}
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] font-mono font-bold text-[#C9A46A] bg-[#C9A46A]/10 px-2.5 py-0.5 rounded border border-[#C9A46A]/20 shrink-0">
                                Sent: {ann.date || 'Today'}
                              </span>
                            </div>
                            <p className="text-slate-300 leading-relaxed text-[11px]">{ann.text}</p>
                            {ann.author && (
                              <span className="text-[9px] text-slate-500 block">Author: {ann.author}</span>
                            )}

                            {canBroadcast ? (
                              <div className="mt-3 pt-2.5 border-t border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[11px]">
                                <div className="flex flex-wrap items-center gap-1.5 text-slate-400">
                                  <span className="font-semibold text-slate-300 flex items-center gap-1">
                                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                                    Viewed by ({ann.readBy?.length || 0}):
                                  </span>
                                  {ann.readBy && ann.readBy.length > 0 ? (
                                    <div className="flex flex-wrap gap-1">
                                      {ann.readBy.map((name: string, i: number) => (
                                        <span key={i} className="text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full text-[10px] font-mono">
                                          {name}
                                        </span>
                                      ))}
                                    </div>
                                  ) : (
                                    <span className="text-slate-500 italic text-[10px]">No views yet</span>
                                  )}
                                </div>
                                <button
                                  onClick={async () => {
                                    setAnnouncements(prev => prev.filter(x => x.id !== ann.id));
                                    try {
                                      await deleteDoc(doc(db, 'studio-announcements', ann.id));
                                    } catch (err) {
                                      console.warn('Failed to delete announcement from Firestore:', err);
                                    }
                                    triggerNotification('Announcement Deleted', 'Broadcast has been removed.', 'info');
                                  }}
                                  className="text-rose-400 hover:text-rose-300 text-[10px] font-mono px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 transition shrink-0"
                                >
                                  Delete Broadcast
                                </button>
                              </div>
                            ) : (
                              <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-[10px]">
                                <span className="text-emerald-400 flex items-center gap-1 font-mono">
                                  <CheckCircle className="w-3.5 h-3.5" /> Read ({ann.date || 'Today'})
                                </span>
                              </div>
                            )}
                          </div>
                        ))
                      );
                    })()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      }

      case 'agency-setup':
      case 'agency-branding':
      case 'white-label': {
        const isDefaultHQ = (tenantId || 'bloom_studio_default') === 'bloom_studio_default';
        const currentTenantName = isDefaultHQ ? 'Bloom Studio HQ (Master Headquarters)' : ((tenantId || '').replace(/_/g, ' ').toUpperCase());
        const portalSubdomain = isDefaultHQ ? 'bloomstudio.agencyportal.com' : `${(tenantId || 'partner').toLowerCase().replace(/_/g, '')}.agencyportal.com`;

        const handleLogoUploadLocal = (e: React.ChangeEvent<HTMLInputElement>) => {
          const file = e.target.files?.[0];
          if (file && setSystemLogo) {
            const reader = new FileReader();
            reader.onloadend = () => {
              setSystemLogo(reader.result as string);
              triggerNotification('Logo Updated', 'Agency branding logo has been saved and applied.', 'success');
              onAddActivityLog(directorName, 'director', 'Updated white-label system logo file');
            };
            reader.readAsDataURL(file);
          }
        };

        const handleVslUploadLocal = (e: React.ChangeEvent<HTMLInputElement>) => {
          const file = e.target.files?.[0];
          if (file && setVslVideoUrl) {
            // Using URL.createObjectURL for large video files to avoid base64 storage limits during the session
            const videoUrl = URL.createObjectURL(file);
            setVslVideoUrl(videoUrl);
            triggerNotification('VSL Video Uploaded', 'Sales video successfully loaded for preview.', 'success');
            onAddActivityLog(directorName, 'director', 'Uploaded a new VSL video');
          }
        };

        const applyThemePreset = (preset: {
          accent: string;
          sidebar: string;
          dashboard: string;
          card: string;
          textMain: string;
          textMuted: string;
        }) => {
          if (setPrimaryBrandColor) setPrimaryBrandColor(preset.accent);
          if (setSidebarBgColor) setSidebarBgColor(preset.sidebar);
          if (setMainDashboardBg) setMainDashboardBg(preset.dashboard);
          if (setCardBgColor) setCardBgColor(preset.card);
          if (setTextMainColor) setTextMainColor(preset.textMain);
          if (setTextMutedColor) setTextMutedColor(preset.textMuted);
          saveTenantConfigInFirestore(tenantId || 'bloom_studio_default', {
            primaryBrandColor: preset.accent,
            sidebarBgColor: preset.sidebar,
            mainDashboardBg: preset.dashboard,
            cardBgColor: preset.card,
            textMainColor: preset.textMain,
            textMutedColor: preset.textMuted
          });
          triggerNotification('Preset Applied & Saved', 'Visual branding theme successfully updated and persisted to database.', 'success');
          onAddActivityLog(directorName, 'director', 'Applied new white-label branding visual preset');
        };

        return (
          <div className="space-y-6 min-w-0 w-full overflow-visible">
            {/* 1. Active Target Workspace & White-Label Identification Banner */}
            <div className="p-5 bg-gradient-to-r from-[#111E33] to-[#0D1830] border border-[#C9A46A]/30 rounded-2xl space-y-4 shadow-lg min-w-0 w-full">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-2 min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-md font-mono bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30 shrink-0">
                      {isDefaultHQ ? '👑 Primary HQ Workspace' : '🤝 Partner Sub-Agency Tenant'}
                    </span>
                    <span className="text-xs text-slate-400 font-mono break-all">
                      Active Target ID: <strong className="text-white font-mono">{tenantId || 'bloom_studio_default'}</strong>
                    </span>
                  </div>
                  <h3 className="font-serif font-bold text-lg text-white break-words">
                    Currently Styling: <span style={{ color: primaryBrandColor }}>{currentTenantName}</span>
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                    {isDefaultHQ
                      ? 'You are viewing & editing the Master Headquarters visual identity. This applies to your primary Director corporate web portal and admin environment.'
                      : `You are editing the white-label branding for ${currentTenantName}. Only users logging into ${portalSubdomain} will see these styles.`}
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-[#0A1220] p-2.5 rounded-xl border border-white/10 shrink-0 max-w-full flex-wrap">
                  <span className="text-[10px] text-[#7C8AA8] font-mono uppercase px-1 shrink-0">Web Portal URL:</span>
                  <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1.5 rounded-lg break-all select-all">
                    https://{portalSubdomain}
                  </span>
                </div>
              </div>
            </div>

            {/* 2. The Web Portal: White-Labels vs. Sub-Agencies Guide Card */}
            <div className="p-4 bg-[#111E33]/80 border border-blue-500/30 rounded-xl space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-blue-300 font-mono uppercase">
                <span>📖 The Web Portal: White-Labels vs. Sub-Agencies</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] text-slate-300 leading-relaxed">
                <div className="bg-[#0A1220]/60 p-3 rounded-lg border border-white/5 space-y-2">
                  <div className="flex items-center gap-2 text-white">
                    <span className="text-lg">🌐</span>
                    <strong className="block">White-Label (Independent)</strong>
                  </div>
                  <p>Independent partners with "no ties" to your brand. They use your software platform under their own URL and brand identity. They are completely isolated and self-governed.</p>
                </div>
                <div className="bg-[#0A1220]/60 p-3 rounded-lg border border-white/5 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400">
                    <span className="text-lg">🏢</span>
                    <strong className="block text-white">Sub-Agency (Under Authority)</strong>
                  </div>
                  <p>Agencies that are "under" you. They have their own name but follow <strong>your guidelines and rules</strong>. They receive your Platform-Wide mandates and operate as a branch of your primary agency.</p>
                </div>
              </div>
              <div className="pt-2 border-t border-white/5 text-[10px] text-slate-400 flex items-center gap-2">
                <Shield className="w-3 h-3 text-emerald-500" /> 
                <span>Note: "Platform-Wide" announcements from you are used to push down guidelines to all Sub-Agencies and White-Labels.</span>
              </div>
            </div>

            {/* 3. Corporate Identity & System Logo File Upload */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5">
              <div className="border-b border-white/5 pb-3 flex justify-between items-center">
                <h3 className="font-serif font-semibold text-lg text-white flex items-center gap-2">
                  👤 Corporate Identity &amp; System Logo File
                </h3>
                <span className="text-[10px] uppercase font-mono text-[#7C8AA8]">Target: {(tenantId || 'HQ').toUpperCase()}</span>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-[#111E33] rounded-xl border border-white/5">
                <div className="w-16 h-16 rounded-xl bg-slate-900 border border-white/10 flex items-center justify-center overflow-hidden shrink-0">
                  {systemLogo ? (
                    <img src={systemLogo} alt="Uploaded logo" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-2xl">🏢</span>
                  )}
                </div>
                <div className="flex-1 text-center sm:text-left space-y-2">
                  <span className="text-xs font-semibold text-white block">Corporate System Logo File</span>
                  <p className="text-[10px] text-slate-400">Upload a PNG or JPG to replace the sidebar and login branding.</p>
                  <label className="inline-block bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors" style={{ backgroundColor: primaryBrandColor }}>
                    Upload Logo File
                    <input type="file" accept="image/*" onChange={handleLogoUploadLocal} className="hidden" />
                  </label>
                  {systemLogo && (
                    <button onClick={() => { if (setSystemLogo) setSystemLogo(''); triggerNotification('Logo Reset', 'System logo restored to default.', 'info'); }} className="text-xs text-rose-400 hover:underline ml-3 font-medium">Reset Logo</button>
                  )}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-[#111E33] rounded-xl border border-white/5">
                <div className="w-24 h-16 rounded-xl bg-slate-900 border border-white/10 flex items-center justify-center overflow-hidden shrink-0 relative group">
                  {vslVideoUrl ? (
                    <>
                      <video src={vslVideoUrl} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-xl">▶</span>
                      </div>
                    </>
                  ) : (
                    <span className="text-2xl opacity-50">🎥</span>
                  )}
                </div>
                <div className="flex-1 text-center sm:text-left space-y-2">
                  <span className="text-xs font-semibold text-white block">Front Portal VSL Video (Preview)</span>
                  <p className="text-[10px] text-slate-400">Upload an MP4 video file to feature on the front login page.</p>
                  <label className="inline-block bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors" style={{ backgroundColor: primaryBrandColor }}>
                    Upload Video File
                    <input type="file" accept="video/*" onChange={handleVslUploadLocal} className="hidden" />
                  </label>
                  {vslVideoUrl && (
                    <button onClick={() => { if (setVslVideoUrl) setVslVideoUrl(''); triggerNotification('VSL Reset', 'VSL Video removed.', 'info'); }} className="text-xs text-rose-400 hover:underline ml-3 font-medium">Reset VSL</button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-medium">Director Name / Anonymous Role Title</label>
                  <input 
                    type="text" 
                    value={directorName} 
                    onChange={(e) => setDirectorName && setDirectorName(e.target.value)} 
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white focus:border-[#C9A46A]"
                    placeholder="e.g. Director" 
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-medium">Agency Brand Name</label>
                  <input 
                    type="text" 
                    value={agencyName} 
                    onChange={(e) => setAgencyName && setAgencyName(e.target.value)} 
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white focus:border-[#C9A46A]"
                    placeholder="e.g. Bloom Studio" 
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-medium">Legal Entity Registered Name</label>
                  <input 
                    type="text" 
                    value={legalEntityName} 
                    onChange={(e) => setLegalEntityName && setLegalEntityName(e.target.value)} 
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white focus:border-[#C9A46A]"
                    placeholder="e.g. Bloom &amp; Co. LLC" 
                  />
                </div>
              </div>

            </div>

            {/* Agency Visual Identity & Theme Configurator */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6">
              <div className="border-b border-white/5 pb-4">
                <h3 className="font-serif font-semibold text-lg text-white">Agency Branding &amp; Visual Theme Studio</h3>
                <p className="text-xs text-[#7C8AA8] mt-1">Customize visual identity, logo file, primary brand color accents, and portal appearance for this workspace.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Brand Visual Identity Panel */}
                <div className="space-y-5 bg-[#111E33] p-5 rounded-xl border border-white/5">
                  <h4 className="font-serif font-medium text-white text-sm flex items-center gap-2">
                    <Settings className="w-4 h-4" style={{ color: primaryBrandColor }} /> Custom Brand Identity
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="space-y-1.5">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Agency Name</label>
                      <input 
                        type="text" 
                        value={agencyName} 
                        onChange={(e) => setAgencyName && setAgencyName(e.target.value)} 
                        className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]" 
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Legal Entity Name</label>
                      <input 
                        type="text" 
                        value={legalEntityName} 
                        onChange={(e) => setLegalEntityName && setLegalEntityName(e.target.value)} 
                        className="w-full bg-[#0D1830] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]" 
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Color Accent</label>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={primaryBrandColor} 
                          onChange={(e) => setPrimaryBrandColor && setPrimaryBrandColor(e.target.value)} 
                          className="w-10 h-10 bg-transparent border-0 rounded cursor-pointer" 
                        />
                        <input 
                          type="text" 
                          value={primaryBrandColor} 
                          onChange={(e) => setPrimaryBrandColor && setPrimaryBrandColor(e.target.value)} 
                          className="flex-1 bg-[#0D1830] border border-white/10 rounded-lg p-2 text-white font-mono uppercase" 
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Sidebar Background</label>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={sidebarBgColor} 
                          onChange={(e) => setSidebarBgColor && setSidebarBgColor(e.target.value)} 
                          className="w-10 h-10 bg-transparent border-0 rounded cursor-pointer" 
                        />
                        <input 
                          type="text" 
                          value={sidebarBgColor} 
                          onChange={(e) => setSidebarBgColor && setSidebarBgColor(e.target.value)} 
                          className="flex-1 bg-[#0D1830] border border-white/10 rounded-lg p-2 text-white font-mono uppercase" 
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Dashboard Background</label>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={mainDashboardBg} 
                          onChange={(e) => setMainDashboardBg && setMainDashboardBg(e.target.value)} 
                          className="w-10 h-10 bg-transparent border-0 rounded cursor-pointer" 
                        />
                        <input 
                          type="text" 
                          value={mainDashboardBg} 
                          onChange={(e) => setMainDashboardBg && setMainDashboardBg(e.target.value)} 
                          className="flex-1 bg-[#0D1830] border border-white/10 rounded-lg p-2 text-white font-mono uppercase" 
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Card Background</label>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={cardBgColor} 
                          onChange={(e) => setCardBgColor && setCardBgColor(e.target.value)} 
                          className="w-10 h-10 bg-transparent border-0 rounded cursor-pointer" 
                        />
                        <input 
                          type="text" 
                          value={cardBgColor} 
                          onChange={(e) => setCardBgColor && setCardBgColor(e.target.value)} 
                          className="flex-1 bg-[#0D1830] border border-white/10 rounded-lg p-2 text-white font-mono uppercase" 
                        />
                      </div>
                    </div>
                  </div>

                  {/* Creator Phone/SMS Messages Toggle Section */}
                  <div className="pt-4 border-t border-white/5 space-y-2">
                    <div className="flex justify-between items-center bg-[#0D1830] p-3.5 rounded-xl border border-white/5">
                      <div className="space-y-1">
                        <span className="text-white text-xs font-bold font-serif flex items-center gap-1.5">
                          <Smartphone className="w-4 h-4 text-[#C9A46A]" style={{ color: primaryBrandColor }} /> SMS/Phone Signup Prompt
                        </span>
                        <p className="text-[10px] text-[#7C8AA8]">
                          Show the notification asking creators to sign up for phone message alerts.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const nextVal = !showPhoneMessagesAlert;
                          setShowPhoneMessagesAlert(nextVal);
                          safeStorage.setItem('wl_show_phone_messages_alert', String(nextVal));
                          triggerNotification('Alert Visibility Saved', `Creator phone signup alert is now ${nextVal ? 'enabled' : 'disabled'}.`, 'success');
                          onAddActivityLog('Director', 'director', `${nextVal ? 'Enabled' : 'Disabled'} creator phone/SMS alerts signup prompt`);
                        }}
                        className={`w-10 h-6 rounded-full transition-colors relative flex items-center px-1 cursor-pointer ${showPhoneMessagesAlert ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'}`}
                      >
                        <span className="w-4 h-4 rounded-full bg-white block shadow-sm"></span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex gap-3">
                    <button 
                      onClick={() => {
                        saveTenantConfigInFirestore(tenantId || 'bloom_studio_default', {
                          agencyName,
                          legalEntityName,
                          primaryBrandColor,
                          sidebarBgColor,
                          mainDashboardBg,
                          cardBgColor,
                          textMainColor,
                          textMutedColor,
                          agentMgrCanAnnounce
                        });
                        triggerNotification('Branding Configurations Saved', 'Agency visual styles updated and persisted.', 'success');
                        onAddActivityLog('Director', 'director', 'Saved agency branding configurations');
                      }} 
                      style={{ backgroundColor: primaryBrandColor }}
                      className="flex-1 text-[#0A1220] px-4 py-2.5 rounded-lg font-bold hover:opacity-90 transition-opacity text-xs cursor-pointer"
                    >
                      Save Branding &amp; Theme
                    </button>
                    <button 
                      onClick={() => {
                        if (setAgencyName) setAgencyName('Bloom Studio');
                        if (setLegalEntityName) setLegalEntityName('Bloom & Co');
                        if (setPrimaryBrandColor) setPrimaryBrandColor('#c7a77d');
                        if (setSidebarBgColor) setSidebarBgColor('#0f1a2c');
                        if (setMainDashboardBg) setMainDashboardBg('#0b1424');
                        if (setCardBgColor) setCardBgColor('#152238');
                        triggerNotification('Branding Reset', 'Styles restored to default preset.', 'info');
                      }}
                      className="text-xs bg-white/5 hover:bg-white/10 text-slate-300 px-3.5 py-1.5 rounded-lg border border-white/10 transition-all font-semibold cursor-pointer"
                    >
                      Reset Defaults
                    </button>
                  </div>
                </div>

                {/* Agency Logo & Theme Preview */}
                <div className="space-y-5 bg-[#111E33] p-5 rounded-xl border border-white/5 flex flex-col justify-between">
                  <div className="space-y-4">
                    <h4 className="font-serif font-medium text-white text-sm flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" /> Agency Logo &amp; Identity Preview
                    </h4>
                    
                    <div className="p-4 bg-[#0D1830] rounded-xl border border-white/5 space-y-3">
                      <span className="text-[10px] text-[#7C8AA8] font-mono uppercase block">Live Interface Header Preview</span>
                      <div className="flex items-center gap-3 p-3 bg-[#080d1a] rounded-lg border border-white/10">
                        {systemLogo ? (
                          <img src={systemLogo} alt="Logo" className="w-8 h-8 rounded-lg object-cover" />
                        ) : (
                          <div className="w-8 h-8 rounded-lg font-serif font-bold text-slate-950 flex items-center justify-center text-sm" style={{ backgroundColor: primaryBrandColor }}>
                            {agencyName.substring(0, 2).toUpperCase()}
                          </div>
                        )}
                        <div>
                          <div className="font-serif font-bold text-sm text-white">{agencyName}</div>
                          <div className="text-[10px] text-slate-400">{legalEntityName}</div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 text-xs">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Upload Agency Logo File (PNG / JPG / SVG)</label>
                      <div className="flex items-center gap-3">
                        <label className="flex-1 bg-[#0D1830] hover:bg-[#152238] border border-dashed border-white/20 hover:border-[#C9A46A] rounded-xl p-3 flex items-center justify-center gap-2 cursor-pointer transition-all group">
                          <Upload className="w-4 h-4 text-[#C9A46A] group-hover:scale-110 transition-transform" />
                          <span className="text-xs font-medium text-slate-300 group-hover:text-white">
                            {systemLogo ? 'Change Logo Image File' : 'Select Image File from Device'}
                          </span>
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="hidden" 
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                if (file.size > 5 * 1024 * 1024) {
                                  triggerNotification('File Too Large', 'Please select a logo image under 5MB.', 'warning');
                                  return;
                                }
                                const reader = new FileReader();
                                reader.onload = (event) => {
                                  const dataUrl = event.target?.result as string;
                                  if (setSystemLogo && dataUrl) {
                                    setSystemLogo(dataUrl);
                                    triggerNotification('Logo Uploaded', `Successfully attached logo file: ${file.name}`, 'success');
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }} 
                          />
                        </label>
                        {systemLogo && (
                          <button 
                            type="button"
                            onClick={() => {
                              if (setSystemLogo) setSystemLogo('');
                              triggerNotification('Logo Cleared', 'Agency logo reset to default font avatar.', 'info');
                            }}
                            className="px-3 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0"
                          >
                            Remove Logo
                          </button>
                        )}
                      </div>
                      {systemLogo && (
                        <p className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 mt-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Custom logo file attached &amp; active in workspace
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="p-3 bg-white/5 rounded-lg text-[10px] text-slate-400 leading-relaxed border border-white/5">
                    💡 All client-facing invoices, media kit exports, and talent agreements automatically inherit this brand identity.
                  </div>
                </div>
              </div>

              {/* White-Label Portal Sidebar Menu Visibility (Sub-Agency Creators & Staff View Only) */}
              <div className="border-t border-white/5 pt-6 space-y-4">
                <div className="space-y-1.5">
                  <h4 className="font-serif font-semibold text-white text-base flex items-center gap-2">
                    🔒 White-Label Portal Menu Visibility (Sub-Agency Creators &amp; Staff View Only)
                  </h4>
                  <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-200 leading-relaxed">
                    <strong>⚠️ Important Distinction:</strong> Checking or unchecking modules below controls which sidebar tabs are visible <strong>inside the White-Label Web Portal</strong> for sub-agency creators &amp; partner staff. This will <strong>NEVER</strong> hide or modify your own Director Headquarters left sidebar!
                    <span className="block mt-1 text-[11px] text-amber-300/80">
                      💡 To customize your own Director HQ sidebar, go to <strong>Agency System Setup ➔ Active Sidebar Customizer</strong>.
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {navCategoriesState && navCategoriesState.map((category) => (
                    <div key={category.title} className="p-4 bg-[#111E33] border border-white/5 rounded-xl space-y-3 flex flex-col justify-between">
                      <div>
                        <div className="font-mono text-[10px] font-bold uppercase tracking-wider text-center border-b border-white/5 pb-2 mb-2 text-[#C9A46A]" style={{ color: primaryBrandColor }}>
                          {category.title}
                        </div>
                        <div className="space-y-2 max-h-[160px] overflow-y-auto scrollbar-thin pr-1">
                          {category.items.map((item: any) => {
                            // Read white-label permission from localStorage or default to true
                            const wlKey = `wl_tab_${tenantId || 'bloom_studio_default'}_${item.id}`;
                            const isAllowed = localStorage.getItem(wlKey) !== 'false';
                            return (
                              <label key={item.id} className="flex items-center gap-2.5 p-2 bg-[#0D1830]/80 border border-white/5 rounded-lg cursor-pointer hover:bg-white/5 transition-all text-[11px] text-slate-200">
                                <input 
                                  type="checkbox" 
                                  defaultChecked={isAllowed}
                                  onChange={(e) => {
                                    localStorage.setItem(wlKey, String(e.target.checked));
                                    triggerNotification(
                                      'White-Label Portal Menu Updated', 
                                      `"${item.label}" is now ${e.target.checked ? 'visible to' : 'hidden from'} ${tenantId || 'bloom_studio_default'} portal users. (Director HQ sidebar untouched)`, 
                                      'success'
                                    );
                                  }}
                                  style={{ accentColor: primaryBrandColor }}
                                  className="w-3.5 h-3.5"
                                />
                                <span className="truncate">{item.label}</span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                      <div className="text-[9px] text-[#7C8AA8] font-mono mt-1 pt-1.5 border-t border-white/5 flex justify-between">
                        <span>Portal Items: {category.items.length}</span>
                        <span>Configured for: {(tenantId || 'HQ').toUpperCase()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 5. Data Maintenance & Migration Utilities (Director Controls) */}
              <div className="border-t border-white/5 pt-6 space-y-4">
                <div className="border-b border-white/5 pb-3">
                  <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
                    🛠️ Data Maintenance &amp; Migration Utilities
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
                    Manual database maintenance tools to sanitize sample test records, upgrade legacy Firestore collections, backfill new partner sub-agencies, and export system backups.
                  </p>
                </div>

                {maintenanceFeedback && (
                  <div className={`p-3.5 rounded-xl border text-xs flex items-center justify-between shadow-sm animate-fade-in ${
                    maintenanceFeedback.type === 'success' 
                      ? 'bg-emerald-950/70 border-emerald-500/30 text-emerald-300' 
                      : maintenanceFeedback.type === 'error'
                      ? 'bg-rose-950/70 border-rose-500/30 text-rose-300'
                      : 'bg-blue-950/70 border-blue-500/30 text-blue-300'
                  }`}>
                    <div>
                      <strong className="mr-1.5">{maintenanceFeedback.title}:</strong>
                      <span>{maintenanceFeedback.message}</span>
                    </div>
                    <button 
                      type="button" 
                      onClick={() => setMaintenanceFeedback(null)} 
                      className="text-white/60 hover:text-white ml-3 font-bold text-sm"
                    >
                      ×
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="font-serif font-semibold text-xs text-rose-300 flex items-center gap-1.5">
                        🗑️ Purge Seed Data
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                        Removes temporary sample creators, mock invoices, and demo deals created during onboarding so your database only contains real agency data.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={isPurgingSeedData}
                      onClick={handleRunPurge}
                      className="w-full bg-rose-950/70 hover:bg-rose-900/80 disabled:opacity-50 border border-rose-500/30 text-rose-300 font-semibold py-2 px-3 rounded-lg text-xs transition cursor-pointer shadow-sm mt-2 flex items-center justify-center gap-1.5"
                    >
                      {isPurgingSeedData ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Purging Data...
                        </>
                      ) : (
                        'Run Purge'
                      )}
                    </button>
                  </div>

                  <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="font-serif font-semibold text-xs text-amber-300 flex items-center gap-1.5">
                        🔄 Creators ➔ Studio-Creators
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                        Migrates any legacy creator records into the unified Firestore schema so all roster analytics, deals, and commission splits stay synced.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={isMigratingCreators}
                      onClick={handleRunCreatorMigration}
                      className="w-full bg-amber-500/10 hover:bg-amber-500/20 disabled:opacity-50 border border-amber-500/30 text-amber-300 font-semibold py-2 px-3 rounded-lg text-xs transition cursor-pointer shadow-sm mt-2 flex items-center justify-center gap-1.5"
                    >
                      {isMigratingCreators ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Syncing Schema...
                        </>
                      ) : (
                        'Sync Schema'
                      )}
                    </button>
                  </div>

                  <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="font-serif font-semibold text-xs text-emerald-300 flex items-center gap-1.5">
                        ⚡ Subagency Backfill
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                        Automatically initializes default Firestore document structures, visual branding themes, and role permissions for all connected sub-agencies.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onRunSubagencyBackfill && onRunSubagencyBackfill()}
                      className="w-full bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-500/30 text-emerald-300 font-semibold py-2 px-3 rounded-lg text-xs transition cursor-pointer shadow-sm mt-2"
                    >
                      Run Backfill
                    </button>
                  </div>

                  <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="font-serif font-semibold text-xs text-blue-300 flex items-center gap-1.5">
                        💾 System Database Backup
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                        Exports your entire local studio state and white-label settings to a downloadable JSON backup file for safe keeping.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const backupData: Record<string, any> = {};
                        for (let i = 0; i < localStorage.length; i++) {
                          const key = localStorage.key(i);
                          if (key && (key.startsWith('wl_') || key.startsWith('bloom_'))) {
                            const val = localStorage.getItem(key);
                            try {
                              backupData[key] = val ? JSON.parse(val) : val;
                            } catch {
                              backupData[key] = val;
                            }
                          }
                        }
                        const dateStr = new Date().toISOString().split('T')[0];
                        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `bloom-studio-backup-${dateStr}.json`;
                        a.click();
                        window.URL.revokeObjectURL(url);
                        triggerNotification('Backup Exported', 'All local storage data exported to JSON file.', 'success');
                      }}
                      className="w-full bg-blue-950/70 hover:bg-blue-900/80 border border-blue-500/30 text-blue-300 font-semibold py-2 px-3 rounded-lg text-xs transition cursor-pointer shadow-sm mt-2"
                    >
                      Export Backup JSON
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      }

      case 'intercepted-contacts':
      case 'intercepts':
        return (
          <div className="space-y-6">
            {/* Top Overview Banner */}
            <div className="p-5 bg-[#0D1830] border border-rose-500/20 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-rose-400 animate-pulse" /> Bloom AI Brand Watchdog & Solicitation Guard
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                  Anti-circumvention shield monitoring for off-platform brand outreach, direct messaging, and bypassing tactics. Paste or load any suspicious communication to run a threat risk audit.
                </p>
              </div>
              <span className="text-xs bg-rose-500/10 text-rose-400 border border-rose-500/30 px-3 py-1.5 rounded-full font-mono font-bold shrink-0 uppercase tracking-wider text-center">
                {localIntercepts.length} Recorded Intercepts
              </span>
            </div>

            {/* Split Screen Panel: Left (Scanner Sandbox) & Right (Intercept Logs) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Column: Interactive Watchdog Sandbox */}
              <div className="lg:col-span-5 bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4 shadow-2xl">
                <div className="border-b border-white/5 pb-3">
                  <h4 className="font-serif font-semibold text-sm text-[#C9A46A] flex items-center gap-2">
                    <Zap className="w-4 h-4" /> Solicitation Risk Sandbox Analyzer
                  </h4>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Paste raw DM copy, emails, or outreach logs to analyze for poaching signatures.
                  </p>
                </div>

                {/* Preset Sample Quick Loaders */}
                <div className="space-y-1.5">
                  <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">Quick-Load Simulated Threat Templates:</span>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      onClick={() => {
                        setScanSenderBrand("Gymshark Scout");
                        setScanTargetCreator("@alex_fitness");
                        setScanInputText("Hey Alex, we saw your Bloom representation. To bypass Bloom's 20% commission markup, we can set up a private agreement under the table. Email us directly at gymshark-scout-private@gmail.com and we can send Venmo.");
                        setScanResults(null);
                      }}
                      className="text-[9px] font-mono bg-rose-950/20 hover:bg-rose-950/40 text-rose-300 border border-rose-500/20 rounded px-2 py-1 transition cursor-pointer text-center font-semibold truncate"
                      title="Simulates Gymshark trying to bypass the agency"
                    >
                      ⚠️ Poaching Attempt
                    </button>
                    <button
                      onClick={() => {
                        setScanSenderBrand("FashionNova Brand Mgr");
                        setScanTargetCreator("@elena_style");
                        setScanInputText("Elena! We want to skip your agency managers entirely. Can we do a direct UGC deal and wire you $4,000 on Venmo? Just send your personal address to fashionnova-pr-direct@gmail.com.");
                        setScanResults(null);
                      }}
                      className="text-[9px] font-mono bg-amber-950/20 hover:bg-amber-950/40 text-amber-300 border border-amber-500/20 rounded px-2 py-1 transition cursor-pointer text-center font-semibold truncate"
                      title="Simulates FashionNova requesting Venmo & direct address"
                    >
                      ⚠️ Fee Avoidance
                    </button>
                    <button
                      onClick={() => {
                        setScanSenderBrand("Glossier PR");
                        setScanTargetCreator("@sophiarose");
                        setScanInputText("Hi Sophia! We love your style. We see you are represented by Bloom Studio. We'd love to submit a campaign brief to your managers for review. Please let us know if they are available to talk!");
                        setScanResults(null);
                      }}
                      className="text-[9px] font-mono bg-emerald-950/20 hover:bg-emerald-950/40 text-emerald-300 border border-emerald-500/20 rounded px-2 py-1 transition cursor-pointer text-center font-semibold truncate"
                      title="Simulates clean professional standard outreach"
                    >
                      ✓ Safe Outreach
                    </button>
                  </div>
                </div>

                {/* Input Fields */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-300 font-semibold block mb-1 font-mono">Brand Sender Name:</label>
                    <input
                      type="text"
                      value={scanSenderBrand}
                      onChange={e => setScanSenderBrand(e.target.value)}
                      placeholder="e.g. Gymshark Scout"
                      className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white placeholder:text-slate-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-300 font-semibold block mb-1 font-mono">Target Roster Creator:</label>
                    <select
                      value={scanTargetCreator}
                      onChange={e => setScanTargetCreator(e.target.value)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white font-mono cursor-pointer"
                    >
                      {creators.map(c => (
                        <option key={c.id} value={c.handle}>{c.name} ({c.handle})</option>
                      ))}
                      <option value="@unspecified">General Roster Broadcast</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-slate-300 font-semibold block mb-1 font-mono">Copy of Message / Direct Outreach text:</label>
                  <textarea
                    rows={4}
                    value={scanInputText}
                    onChange={e => setScanInputText(e.target.value)}
                    placeholder="Paste email draft, DM screenshot text, or inbound contact forms here..."
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-xs text-white placeholder:text-slate-500 leading-relaxed font-mono"
                  />
                </div>

                <button
                  onClick={handleRunWatchdogScan}
                  className="w-full bg-[#C9A46A] hover:bg-[#B38F55] text-[#060B14] font-bold py-2 px-4 rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
                >
                  <ShieldAlert className="w-4 h-4" /> Run Watchdog Analysis
                </button>

                {/* Live Sandbox Diagnostic Feedback */}
                {scanResults && (
                  <div className={`p-4 rounded-xl border text-xs space-y-3 font-mono animate-fadeIn ${
                    scanResults.threatScore >= 70 
                      ? 'bg-rose-950/20 border-rose-500/30 text-rose-200' 
                      : scanResults.threatScore >= 45
                      ? 'bg-amber-950/20 border-amber-500/30 text-amber-200'
                      : scanResults.threatScore >= 20
                      ? 'bg-blue-950/20 border-blue-500/30 text-blue-200'
                      : 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
                  }`}>
                    <div className="flex items-center justify-between border-b border-white/5 pb-2">
                      <span className="font-bold uppercase tracking-wider flex items-center gap-1">
                        {scanResults.threatScore >= 45 ? '⚠️ VIOLATION HIGHLIGHT' : '✓ CLEARED STATUS'}
                      </span>
                      <span className={`px-2 py-0.5 rounded font-bold uppercase text-[9px] ${
                        scanResults.riskRating === 'Critical Bypass Attempt' 
                          ? 'bg-rose-500 text-white' 
                          : scanResults.riskRating === 'High Risk'
                          ? 'bg-amber-500 text-slate-950'
                          : scanResults.riskRating === 'Medium Risk'
                          ? 'bg-blue-500 text-white'
                          : 'bg-emerald-500 text-white'
                      }`}>
                        {scanResults.riskRating}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[10px]">
                      <div>
                        <span className="text-slate-400 block">Classified Action:</span>
                        <span className="font-semibold">{scanResults.status}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Solicitation Threat score:</span>
                        <span className="font-bold text-sm">{scanResults.threatScore}%</span>
                      </div>
                    </div>

                    {scanResults.flaggedKeywords.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-[9px] text-slate-400 uppercase tracking-wider block">Flagged Risk Signatures:</span>
                        <div className="flex flex-wrap gap-1">
                          {scanResults.flaggedKeywords.map(kw => (
                            <span key={kw} className="bg-rose-500/10 text-rose-300 border border-rose-500/20 px-1.5 py-0.5 rounded text-[8px] font-bold">
                              {kw}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <p className="text-[11px] leading-relaxed border-t border-white/5 pt-2 italic">
                      "{scanResults.explainer}"
                    </p>
                  </div>
                )}
              </div>

              {/* Right Column: Logged Intercept Audit Trail */}
              <div className="lg:col-span-7 bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-3">
                  <h4 className="font-serif font-semibold text-sm text-white flex items-center gap-2">
                    <Shield className="w-4 h-4 text-rose-400" /> Active Interception & Legal Log ({localIntercepts.length})
                  </h4>
                  <span className="text-[10px] text-slate-400 font-mono">Durable Evidence Audit Trail</span>
                </div>

                {localIntercepts.length === 0 ? (
                  <div className="text-center py-20 text-slate-400 space-y-3 bg-[#111E33] border border-white/5 rounded-xl">
                    <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto animate-bounce" />
                    <p className="font-serif text-sm font-semibold text-white">Roster Fully Protected</p>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto leading-normal">
                      No bypass attempts or direct communications intercepted. All incoming queries have routed correctly through the agency.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
                    {localIntercepts.map((item: any) => (
                      <div key={item.id} className="bg-[#111E33] border border-white/5 p-4 rounded-xl space-y-3 hover:border-rose-500/30 transition-all">
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-white/5 pb-3">
                          <div>
                            <div className="flex items-center gap-2 text-xs">
                              <span className="font-mono font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded">
                                {item.brandId || item.sender}
                              </span>
                              <span className="text-slate-500">➔</span>
                              <span className="font-mono font-bold text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded">
                                {item.creatorId || item.receiver}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 mt-2 text-[10px]">
                              <span className="bg-rose-500/15 text-rose-400 border border-rose-500/30 px-2 py-0.5 rounded font-mono font-bold uppercase text-[9px]">
                                {item.reason || 'DIRECT_SOLICITATION'}
                              </span>
                              <span className="text-slate-400 font-mono">{item.timestamp}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 flex-wrap">
                            <button
                              onClick={() => {
                                triggerNotification('Formal Breach Notice Generated', `Pre-populated liquidated damages notice drafted for [${item.brandId || item.sender}].`, 'success');
                              }}
                              className="bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold px-2 py-1 rounded transition-all cursor-pointer flex items-center gap-1"
                              title="Draft pre-populated contract breach warning"
                            >
                              <FileText className="w-3 h-3" /> Breach Notice
                            </button>

                            <button
                              onClick={() => {
                                triggerNotification('Escalated to Legal Counsel', `Incident log [${item.id}] dispatched to agency legal desk.`, 'warning');
                              }}
                              className="bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-[10px] font-mono font-bold px-2 py-1 rounded transition-all cursor-pointer flex items-center gap-1"
                              title="Escalate direct circumvention breach to legal counsel"
                            >
                              <Scale className="w-3 h-3" /> Legal
                            </button>

                            <button
                              onClick={() => {
                                const filtered = localIntercepts.filter(m => m.id !== item.id);
                                setLocalIntercepts(filtered);
                                localStorage.setItem('wl_intercepted_mails', JSON.stringify(filtered));
                                triggerNotification('Log Archived', 'Record moved to archived compliance vault.', 'info');
                              }}
                              className="text-slate-400 hover:text-white text-[10px] px-2 py-1 rounded bg-white/5 transition-all cursor-pointer font-mono font-bold hover:bg-white/10"
                            >
                              Archive
                            </button>
                          </div>
                        </div>

                        <div className="bg-[#080d1a] p-3 rounded-lg border border-white/5 text-xs text-amber-200/90 italic font-mono leading-relaxed relative group">
                          "{item.flaggedContent || item.text || item.message}"
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>
        );

      case 'old-agency-setup-deprecated': {
        const handleLogoUploadLocal = (e: React.ChangeEvent<HTMLInputElement>) => {
          const file = e.target.files?.[0];
          if (file && setSystemLogo) {
            const reader = new FileReader();
            reader.onloadend = () => {
              setSystemLogo(reader.result as string);
              triggerNotification('Logo Updated', 'Agency branding logo has been saved and applied.', 'success');
              onAddActivityLog(directorName, 'director', 'Updated white-label system logo file');
            };
            reader.readAsDataURL(file);
          }
        };

        const applyThemePreset = (preset: {
          accent: string;
          sidebar: string;
          dashboard: string;
          card: string;
          textMain: string;
          textMuted: string;
        }) => {
          if (setPrimaryBrandColor) setPrimaryBrandColor(preset.accent);
          if (setSidebarBgColor) setSidebarBgColor(preset.sidebar);
          if (setMainDashboardBg) setMainDashboardBg(preset.dashboard);
          if (setCardBgColor) setCardBgColor(preset.card);
          if (setTextMainColor) setTextMainColor(preset.textMain);
          if (setTextMutedColor) setTextMutedColor(preset.textMuted);
          saveTenantConfigInFirestore(tenantId || 'bloom_studio_default', {
            primaryBrandColor: preset.accent,
            sidebarBgColor: preset.sidebar,
            mainDashboardBg: preset.dashboard,
            cardBgColor: preset.card,
            textMainColor: preset.textMain,
            textMutedColor: preset.textMuted
          });
          triggerNotification('Preset Applied & Saved', 'Visual branding theme successfully updated and persisted to database.', 'success');
          onAddActivityLog(directorName, 'director', 'Applied new white-label branding visual preset');
        };

        const toggleNavItemLocal = (catTitle: string, itemId: string) => {
          if (setNavCategoriesState && navCategoriesState) {
            const updated = navCategoriesState.map(cat => {
              if (cat.title === catTitle) {
                return {
                  ...cat,
                  items: cat.items.map((item: any) => {
                    if (item.id === itemId) {
                      return { ...item, isActive: !item.isActive };
                    }
                    return item;
                  })
                };
              }
              return cat;
            });
            setNavCategoriesState(updated);
            triggerNotification('Sidebar Updated', 'Toggled menu item visibility.', 'success');
          }
        };

        return (
          <div className="space-y-6 animate-fade-in text-slate-200">
            {/* Header Banner */}
            <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-white/5 rounded-2xl p-6 overflow-hidden">
              <div className="absolute -top-12 -right-12 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.08)_0%,transparent_70%) pointer-events-none"></div>
              <div className="relative">
                <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider block" style={{ color: primaryBrandColor }}>
                  Corporate Administration
                </span>
                <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1">
                  🏢 My Agency Setup &amp; Branding
                </h1>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Configure white-label properties, update visual themes, change director attributes, and toggle navigation menus in real-time.
                </p>
              </div>
            </div>

            {/* Platform Emergency Kill Switch Panel (Platform Owner Exclusive) */}
            <EmergencyKillSwitchPanel
              config={maintenanceConfig}
              currentUser={currentUser}
              onUpdateConfig={setMaintenanceConfig}
              triggerNotification={triggerNotification}
            />

            {/* Platform Owner Exclusive: System Audit Log Quick Portal */}
            {Boolean(currentUser?.isPlatformOwner || currentUser?.email === 'lilbitnd06@gmail.com' || currentUser?.role === 'owner') && (
              <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                    <Database className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-serif font-bold text-white text-base">System Audit Log</h3>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        Owner Exclusive
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5">
                      Inspect the chronologically sortable stream of all Firestore write operations, operator user attributions, and subagency pod partitions.
                    </p>
                  </div>
                </div>
                {setActiveScreen && (
                  <button
                    onClick={() => setActiveScreen('system-audit-log')}
                    className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-[#0A1220] font-semibold text-xs rounded-xl flex items-center gap-2 transition-all shadow-md shrink-0 cursor-pointer"
                  >
                    <span>Launch Audit Log</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Identity & Themes */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* 1. Identity & Corporate Details */}
                <div className="bg-[#0D1830] border border-white/5 rounded-xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                  <h3 className="font-serif font-semibold text-base text-white border-b border-white/5 pb-2 flex items-center gap-2">
                    👤 Corporate Identity
                  </h3>
                  
                  {/* System Logo Upload */}
                  <div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-[#111E33] rounded-xl border border-white/5">
                    <div className="w-16 h-16 rounded-xl bg-slate-900 border border-white/10 flex items-center justify-center overflow-hidden">
                      {systemLogo ? (
                        <img src={systemLogo} alt="Uploaded logo" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-2xl">🏢</span>
                      )}
                    </div>
                    <div className="flex-1 text-center sm:text-left space-y-2">
                      <span className="text-xs font-semibold text-white block">Corporate System Logo File</span>
                      <p className="text-[10px] text-slate-400">Upload a PNG or JPG to replace the sidebar and login branding.</p>
                      <label className="inline-block bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors" style={{ backgroundColor: primaryBrandColor }}>
                        Upload Logo File
                        <input type="file" accept="image/*" onChange={handleLogoUploadLocal} className="hidden" />
                      </label>
                      {systemLogo && (
                        <button onClick={() => { if (setSystemLogo) setSystemLogo(''); triggerNotification('Logo Reset', 'System logo restored to default.', 'info'); }} className="text-xs text-rose-400 hover:underline ml-3 font-medium">Reset Logo</button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <div className="space-y-1">
                      <label className="text-[#7C8AA8] font-medium">Director Name / Anonymous Role Title</label>
                      <input 
                        type="text" 
                        value={directorName} 
                        onChange={(e) => setDirectorName && setDirectorName(e.target.value)} 
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white focus:border-[#C9A46A]"
                        placeholder="e.g. Director" 
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[#7C8AA8] font-medium">Agency Brand Name</label>
                      <input 
                        type="text" 
                        value={agencyName} 
                        onChange={(e) => setAgencyName && setAgencyName(e.target.value)} 
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white focus:border-[#C9A46A]"
                        placeholder="e.g. Bloom Studio" 
                      />
                    </div>
                    <div className="space-y-1 md:col-span-2">
                      <label className="text-[#7C8AA8] font-medium">Legal Entity Registered Name</label>
                      <input 
                        type="text" 
                        value={legalEntityName} 
                        onChange={(e) => setLegalEntityName && setLegalEntityName(e.target.value)} 
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white focus:border-[#C9A46A]"
                        placeholder="e.g. Bloom &amp; Co. LLC" 
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end items-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        const backupData: Record<string, any> = {};
                        for (let i = 0; i < localStorage.length; i++) {
                          const key = localStorage.key(i);
                          if (key && key.startsWith('wl_')) {
                            const val = localStorage.getItem(key);
                            try {
                              backupData[key] = val ? JSON.parse(val) : val;
                            } catch {
                              backupData[key] = val;
                            }
                          }
                        }
                        const dateStr = new Date().toISOString().split('T')[0];
                        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `bloom-backup-${dateStr}.json`;
                        a.click();
                        window.URL.revokeObjectURL(url);
                        triggerNotification('Backup Exported', 'All local storage data exported to JSON file.', 'success');
                      }}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Export Backup
                    </button>
                    <button onClick={() => { triggerNotification('Settings Saved', 'Corporate identity attributes persisted in database.', 'success'); onAddActivityLog(directorName, 'director', 'Saved corporate identity parameters'); }} className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold transition-all" style={{ backgroundColor: primaryBrandColor }}>
                      Save Corporate Settings
                    </button>
                  </div>
                </div>

                {/* 2. Visual Themes & Custom Palette Editor */}
                <div className="bg-[#0D1830] border border-white/5 rounded-xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                  <div className="border-b border-white/5 pb-2 flex justify-between items-center">
                    <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
                      🎨 White-Label Design Engine
                    </h3>
                    <span className="text-[10px] uppercase font-bold text-[#7C8AA8] tracking-wider font-mono">Live CSS Customizers</span>
                  </div>

                  {/* Predefined Visual Presets */}
                  <div className="space-y-2">
                    <span className="text-[10px] uppercase text-[#7C8AA8] font-bold block font-mono">Quick Brand Themes:</span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      {[
                        { label: 'Bloom Charcoal', accent: '#c7a77d', sidebar: '#0f1a2c', dashboard: '#0b1424', card: '#152238', textMain: '#ffffff', textMuted: '#6b7c96' },
                        { label: 'GlowLab Pink', accent: '#ec4899', sidebar: '#1f1625', dashboard: '#0f0c11', card: '#261a2e', textMain: '#ffffff', textMuted: '#9e8fa6' },
                        { label: 'Stealth Emerald', accent: '#10b981', sidebar: '#0b1a1c', dashboard: '#050f11', card: '#122528', textMain: '#ffffff', textMuted: '#7da1a5' },
                        { label: 'Royal Purple', accent: '#8b5cf6', sidebar: '#181124', dashboard: '#0b0612', card: '#1d122b', textMain: '#ffffff', textMuted: '#9f8db3' }
                      ].map((preset, idx) => (
                        <button 
                          key={idx} 
                          onClick={() => applyThemePreset(preset)}
                          className="bg-[#111E33] border border-white/5 hover:border-[#C9A46A]/50 p-2 rounded-xl text-left font-semibold hover:bg-[#16243F] transition-all flex flex-col justify-between h-14"
                        >
                          <span className="text-[10px] text-white truncate block">{preset.label}</span>
                          <div className="flex gap-1 items-center mt-1">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: preset.accent }}></span>
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: preset.sidebar }}></span>
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: preset.dashboard }}></span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Live Hex Value Inputs */}
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-xs border-t border-white/5 pt-3">
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-[#7C8AA8]">Primary Accent</label>
                        <span className="w-3.5 h-3.5 rounded-full border border-white/10" style={{ backgroundColor: primaryBrandColor }}></span>
                      </div>
                      <div className="flex gap-1.5">
                        <input type="color" value={primaryBrandColor} onChange={(e) => setPrimaryBrandColor && setPrimaryBrandColor(e.target.value)} className="w-8 h-8 bg-transparent border-0 rounded cursor-pointer shrink-0" />
                        <input type="text" value={primaryBrandColor} onChange={(e) => setPrimaryBrandColor && setPrimaryBrandColor(e.target.value)} className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-white font-mono text-[11px]" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-[#7C8AA8]">Sidebar BG</label>
                        <span className="w-3.5 h-3.5 rounded-full border border-white/10" style={{ backgroundColor: sidebarBgColor }}></span>
                      </div>
                      <div className="flex gap-1.5">
                        <input type="color" value={sidebarBgColor} onChange={(e) => setSidebarBgColor && setSidebarBgColor(e.target.value)} className="w-8 h-8 bg-transparent border-0 rounded cursor-pointer shrink-0" />
                        <input type="text" value={sidebarBgColor} onChange={(e) => setSidebarBgColor && setSidebarBgColor(e.target.value)} className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-white font-mono text-[11px]" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-[#7C8AA8]">Dashboard BG</label>
                        <span className="w-3.5 h-3.5 rounded-full border border-white/10" style={{ backgroundColor: mainDashboardBg }}></span>
                      </div>
                      <div className="flex gap-1.5">
                        <input type="color" value={mainDashboardBg} onChange={(e) => setMainDashboardBg && setMainDashboardBg(e.target.value)} className="w-8 h-8 bg-transparent border-0 rounded cursor-pointer shrink-0" />
                        <input type="text" value={mainDashboardBg} onChange={(e) => setMainDashboardBg && setMainDashboardBg(e.target.value)} className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-white font-mono text-[11px]" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-[#7C8AA8]">Card Elements BG</label>
                        <span className="w-3.5 h-3.5 rounded-full border border-white/10" style={{ backgroundColor: cardBgColor }}></span>
                      </div>
                      <div className="flex gap-1.5">
                        <input type="color" value={cardBgColor} onChange={(e) => setCardBgColor && setCardBgColor(e.target.value)} className="w-8 h-8 bg-transparent border-0 rounded cursor-pointer shrink-0" />
                        <input type="text" value={cardBgColor} onChange={(e) => setCardBgColor && setCardBgColor(e.target.value)} className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-white font-mono text-[11px]" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-[#7C8AA8]">Main Text Color</label>
                        <span className="w-3.5 h-3.5 rounded-full border border-white/10" style={{ backgroundColor: textMainColor }}></span>
                      </div>
                      <div className="flex gap-1.5">
                        <input type="color" value={textMainColor} onChange={(e) => setTextMainColor && setTextMainColor(e.target.value)} className="w-8 h-8 bg-transparent border-0 rounded cursor-pointer shrink-0" />
                        <input type="text" value={textMainColor} onChange={(e) => setTextMainColor && setTextMainColor(e.target.value)} className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-white font-mono text-[11px]" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <label className="text-[#7C8AA8]">Muted Subtext Color</label>
                        <span className="w-3.5 h-3.5 rounded-full border border-white/10" style={{ backgroundColor: textMutedColor }}></span>
                      </div>
                      <div className="flex gap-1.5">
                        <input type="color" value={textMutedColor} onChange={(e) => setTextMutedColor && setTextMutedColor(e.target.value)} className="w-8 h-8 bg-transparent border-0 rounded cursor-pointer shrink-0" />
                        <input type="text" value={textMutedColor} onChange={(e) => setTextMutedColor && setTextMutedColor(e.target.value)} className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-white font-mono text-[11px]" />
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex justify-end">
                    <button
                      onClick={() => {
                        saveTenantConfigInFirestore(tenantId || 'bloom_studio_default', {
                          primaryBrandColor,
                          sidebarBgColor,
                          mainDashboardBg,
                          cardBgColor,
                          textMainColor,
                          textMutedColor
                        });
                        triggerNotification('White-Label Theme Saved', 'Palette colors saved and persisted to Firestore database.', 'success');
                        onAddActivityLog(directorName, 'director', 'Saved white-label custom palette configuration');
                      }}
                      style={{ backgroundColor: primaryBrandColor }}
                      className="text-[#0A1220] px-5 py-2.5 rounded-xl font-bold text-xs hover:opacity-90 transition-opacity cursor-pointer shadow-md"
                    >
                      Save White-Label Theme &amp; Palette
                    </button>
                  </div>
                </div>

                {/* 3. Domain Whitlabeling */}
                <div className="bg-[#0D1830] border border-white/5 rounded-xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                  <h3 className="font-serif font-semibold text-base text-white border-b border-white/5 pb-2 flex items-center gap-2">
                    🌐 Web Portal Custom Domain
                  </h3>
                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="text-[10px] text-[#7C8AA8] block mb-1">Custom Domain Address</label>
                      <input type="text" defaultValue="portal.bloomandco.studio" className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white outline-none focus:border-[#C9A46A]" />
                    </div>
                    <div className="p-3 bg-[#111E33] rounded-lg border border-white/5 flex justify-between items-center">
                      <div>
                        <span className="text-[10px] font-mono text-emerald-400 block font-bold">CName Target:</span>
                        <span className="text-[11px] text-[#7C8AA8] font-mono">cname.aistudio.build</span>
                      </div>
                      <span className="text-[9px] uppercase tracking-wider font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded">DNS Configured</span>
                    </div>
                  </div>
                </div>

                {/* 4. Data Maintenance & Migration Utilities (Director Controls) */}
                <div className="bg-[#0D1830] border border-white/5 rounded-xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                  <div className="border-b border-white/5 pb-3">
                    <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
                      🛠️ Data Maintenance &amp; Migration Utilities
                    </h3>
                    <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
                      Manual database maintenance tools to sanitize sample test records, upgrade legacy Firestore collections, and backfill new partner sub-agencies.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 space-y-2 flex flex-col justify-between">
                      <div>
                        <div className="font-serif font-semibold text-xs text-rose-300 flex items-center gap-1.5">
                          🗑️ Purge Seed Data
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                          Removes temporary sample creators, mock invoices, and demo deals created during onboarding so your database only contains real agency data.
                        </p>
                      </div>
                      <button
                        type="button"
                        disabled={isPurgingSeedData}
                        onClick={handleRunPurge}
                        className="w-full bg-rose-950/70 hover:bg-rose-900/80 disabled:opacity-50 border border-rose-500/30 text-rose-300 font-semibold py-2 px-3 rounded-lg text-xs transition cursor-pointer shadow-sm mt-2 flex items-center justify-center gap-1.5"
                      >
                        {isPurgingSeedData ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Purging Data...
                          </>
                        ) : (
                          'Run Purge'
                        )}
                      </button>
                    </div>

                    <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 space-y-2 flex flex-col justify-between">
                      <div>
                        <div className="font-serif font-semibold text-xs text-amber-300 flex items-center gap-1.5">
                          🔄 Creators ➔ Studio-Creators
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                          Migrates any legacy creator records into the unified Firestore schema so all roster analytics, deals, and commission splits stay synced.
                        </p>
                      </div>
                      <button
                        type="button"
                        disabled={isMigratingCreators}
                        onClick={handleRunCreatorMigration}
                        className="w-full bg-amber-500/10 hover:bg-amber-500/20 disabled:opacity-50 border border-amber-500/30 text-amber-300 font-semibold py-2 px-3 rounded-lg text-xs transition cursor-pointer shadow-sm mt-2 flex items-center justify-center gap-1.5"
                      >
                        {isMigratingCreators ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Syncing Schema...
                          </>
                        ) : (
                          'Sync Schema'
                        )}
                      </button>
                    </div>

                    <div className="bg-[#111E33] p-3.5 rounded-xl border border-white/5 space-y-2 flex flex-col justify-between">
                      <div>
                        <div className="font-serif font-semibold text-xs text-emerald-300 flex items-center gap-1.5">
                          ⚡ Subagency Backfill
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                          Automatically initializes default Firestore document structures, visual branding themes, and role permissions for all connected sub-agencies.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRunSubagencyBackfill && onRunSubagencyBackfill()}
                        className="w-full bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-500/30 text-emerald-300 font-semibold py-2 px-3 rounded-lg text-xs transition cursor-pointer shadow-sm mt-2"
                      >
                        Run Backfill
                      </button>
                    </div>
                  </div>
                </div>

              </div>

              {/* Right Column: Interactive Sidebar Config & Navigation Manager */}
              <div className="lg:col-span-5 space-y-6">
                
                <div className="bg-[#0D1830] border border-white/5 rounded-xl p-5 space-y-4 h-full" style={{ backgroundColor: cardBgColor }}>
                  <div className="border-b border-white/5 pb-2.5">
                    <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
                      🗂️ Active Sidebar Customizer
                    </h3>
                    <p className="text-[11px] text-[#7C8AA8] mt-0.5">Toggle visibility of menus, workflows, and modules in the primary navigation list.</p>
                  </div>

                  <div className="space-y-4 h-[620px] overflow-y-auto pr-1 scrollbar-thin">
                    {navCategoriesState && navCategoriesState.map((cat, catIdx) => (
                      <div key={catIdx} className="space-y-2 border-b border-white/5 pb-3 last:border-0 last:pb-0">
                        <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 font-bold block">{cat.title}</span>
                        <div className="space-y-1.5">
                          {cat.items && cat.items.map((item: any) => (
                            <div key={item.id} className="flex justify-between items-center p-2.5 bg-[#111E33]/60 hover:bg-[#111E33] rounded-lg border border-white/5 text-xs">
                              <span className="text-white font-medium">{item.label}</span>
                              <button 
                                onClick={() => toggleNavItemLocal(cat.title, item.id)}
                                className={`w-8 h-4.5 rounded-full transition-colors relative focus:outline-none flex items-center px-0.5 cursor-pointer ${item.isActive ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'}`}
                              >
                                <span className="w-3.5 h-3.5 rounded-full bg-white block shadow-sm"></span>
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                </div>

              </div>
            </div>
          </div>
        );
      }

      case 'integrations': {
        const filteredIntegrations = externalIntegrations.filter(item => {
          if (integrationCategoryFilter === 'all') return true;
          if (integrationCategoryFilter === 'social') return item.category === 'Social & Video';
          if (integrationCategoryFilter === 'finance') return item.category === 'Finance & Payments';
          if (integrationCategoryFilter === 'crm') return item.category === 'CRM & Sales' || item.category === 'Communication';
          if (integrationCategoryFilter === 'production') return item.category === 'Production & Schedules';
          if (integrationCategoryFilter === 'notifications') return item.category === 'Notifications' || item.category === 'Email & IRS 1099' || item.category === 'Analytics';
          return true;
        });

        const activeCount = externalIntegrations.filter(i => i.connected).length;
        const totalCount = externalIntegrations.length;

        const handleToggleIntegration = (item: any) => {
          if (item.connected) {
            // Disconnect
            setExternalIntegrations(prev => prev.map(x => x.id === item.id ? { ...x, connected: false, status: 'Not Connected', lastSync: 'Never' } : x));
            triggerNotification('Tool Disconnected', `Disconnected ${item.name} integration.`, 'info');
            onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Disconnected external integration: ${item.name}`);
          } else {
            // Open modal to configure credentials
            setSelectedIntegrationModal(item);
          }
        };

        const handleSyncTool = async (item: any) => {
          if (!item.connected) {
            triggerNotification('Not Connected', `Please configure and connect ${item.name} before syncing.`, 'warning');
            return;
          }
          try {
            const authHeaders = await getAuthHeaders();
            const res = await fetch('/api/integrations/sync', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', ...authHeaders },
              body: JSON.stringify({ toolId: item.id, toolName: item.name })
            });
            const data = await res.json();
            const syncTime = data.tool?.lastSync || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            setExternalIntegrations(prev => prev.map(x => x.id === item.id ? { ...x, lastSync: syncTime, latencyMs: data.tool?.latencyMs } : x));
            triggerNotification('Sync Verified', `Polled active webhooks and synced latest payloads for ${item.name} (${data.tool?.latencyMs || 24}ms latency).`, 'success');
            onAddActivityLog(currentUser?.name || 'User', currentRole || 'staff', `Synced external tool: ${item.name}`);
          } catch (e) {
            triggerNotification('Sync Error', `Unable to verify sync endpoint for ${item.name}.`, 'danger');
          }
        };

        const handleSyncAllTools = async () => {
          setIsSyncingAllIntegrations(true);
          try {
            const authHeaders = await getAuthHeaders();
            const res = await fetch('/api/integrations/sync', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', ...authHeaders },
              body: JSON.stringify({ syncAll: true })
            });
            const data = await res.json();
            const nowTime = data.formattedTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            setExternalIntegrations(prev => prev.map(x => x.connected ? { ...x, lastSync: nowTime } : x));
            setIsSyncingAllIntegrations(false);
            triggerNotification('Global Sync Complete', `All ${data.syncedCount || activeCount} active external tool connections polled and synchronized.`, 'success');
            onAddActivityLog(currentUser?.name || 'User', currentRole || 'staff', `Executed global sync for all ${data.syncedCount || activeCount} connected tools`);
          } catch (e) {
            setIsSyncingAllIntegrations(false);
            triggerNotification('Sync Failure', 'Global tool sync failed due to server connection issue.', 'danger');
          }
        };

        return (
          <div className="space-y-6 animate-fade-in">
            {/* Top Security & Architecture Banner */}
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider font-mono">
                      Integrated API Gateway (Status Only)
                    </span>
                    <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                      {activeCount} of {totalCount} Connected
                    </span>
                  </div>
                  <p className="text-xs text-emerald-200/80 leading-relaxed">
                    Connect external social platforms, creator APIs, payment gateways, CRM databases, and messaging bots. Status indicators update in real-time.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5 shrink-0">
                <button
                  onClick={handleSyncAllTools}
                  disabled={isSyncingAllIntegrations || activeCount === 0}
                  className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold font-mono px-4 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingAllIntegrations ? 'animate-spin' : ''}`} />
                  {isSyncingAllIntegrations ? 'Syncing All Tools...' : 'Sync All Active Tools'}
                </button>
              </div>
            </div>

            {/* Main Integrations Workspace Card */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6" style={{ backgroundColor: cardBgColor }}>
              
              {/* Header & Category Filters */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-white/5 pb-5">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white flex items-center gap-2">
                    <Sliders className="w-5 h-5 text-[#C9A46A]" /> Connected Tools &amp; External Integrations
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    Manage real-time API integrations, webhooks, and automated data pipelines.
                  </p>
                </div>

                {/* Filter Tabs */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
                  {[
                    { id: 'all', label: `All (${totalCount})` },
                    { id: 'social', label: 'Social & Video' },
                    { id: 'finance', label: 'Finance & Payouts' },
                    { id: 'crm', label: 'CRM & Comms' },
                    { id: 'production', label: 'Production & Sync' },
                    { id: 'notifications', label: 'Messaging & Analytics' }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setIntegrationCategoryFilter(tab.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer font-mono ${
                        integrationCategoryFilter === tab.id
                          ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow'
                          : 'bg-[#111E33] text-slate-400 hover:text-white border border-white/5'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Integrations Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {filteredIntegrations.map((item) => {
                  const isConn = item.connected;

                  return (
                    <div 
                      key={item.id} 
                      className={`bg-[#111E33] border rounded-2xl p-5 flex flex-col justify-between space-y-4 transition-all duration-200 hover:border-white/20 ${
                        isConn ? 'border-emerald-500/30 bg-gradient-to-b from-[#111E33] to-[#0d222d]' : 'border-white/5'
                      }`}
                    >
                      <div className="space-y-3">
                        {/* Top Icon & Status Pill */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <span className="text-2xl p-2 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                              {item.icon}
                            </span>
                            <div>
                              <span className="text-[10px] font-mono uppercase tracking-wider text-[#C9A46A] font-bold block">
                                {item.category}
                              </span>
                              <h4 className="text-sm font-bold text-white leading-tight mt-0.5">{item.name}</h4>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full ${isConn ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
                            <span className={`text-[10px] uppercase font-bold font-mono px-2 py-0.5 rounded-full border ${
                              isConn 
                                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/30' 
                                : 'bg-slate-800 text-slate-400 border-slate-700'
                            }`}>
                              {isConn ? 'Connected & Active' : 'Not Connected'}
                            </span>
                          </div>
                        </div>

                        {/* Description */}
                        <p className="text-xs text-[#7C8AA8] leading-relaxed">
                          {item.desc}
                        </p>

                        {/* Connection Metadata / Credentials Preview */}
                        {isConn ? (
                          <div className="bg-[#09101d] border border-emerald-500/20 rounded-xl p-3 space-y-1.5">
                            <div className="flex justify-between items-center text-[11px]">
                              <span className="text-slate-400 font-mono">Connected ID:</span>
                              <span className="font-mono text-emerald-300 font-semibold truncate max-w-[150px]">
                                {item.connectedAccount || 'Verified Live'}
                              </span>
                            </div>
                            <div className="flex justify-between items-center text-[11px]">
                              <span className="text-slate-400 font-mono">Last Synchronized:</span>
                              <span className="font-mono text-slate-300">{item.lastSync || 'Just now'}</span>
                            </div>
                          </div>
                        ) : (
                          <div className="bg-[#09101d] border border-white/5 rounded-xl p-2.5 text-center">
                            <span className="text-[11px] text-slate-400 italic">No credentials configured</span>
                          </div>
                        )}
                      </div>

                      {/* Action Controls */}
                      <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2">
                        {isConn ? (
                          <>
                            <button
                              onClick={() => openIntegrationModal(item)}
                              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition-all cursor-pointer font-mono flex items-center gap-1"
                              title="Configure API settings"
                            >
                              <Settings className="w-3.5 h-3.5" /> Configure
                            </button>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleSyncTool(item)}
                                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 transition-all cursor-pointer font-mono flex items-center gap-1"
                                title="Run instant sync ping"
                              >
                                <RefreshCw className="w-3 h-3" /> Sync
                              </button>
                              <button
                                onClick={() => handleToggleIntegration(item)}
                                className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 transition-all cursor-pointer font-mono"
                                title="Disconnect integration"
                              >
                                Disconnect
                              </button>
                            </div>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => openIntegrationModal(item)}
                              className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition-all cursor-pointer font-mono flex items-center gap-1"
                            >
                              <Key className="w-3.5 h-3.5" /> Set API Keys
                            </button>
                            <button
                              onClick={() => handleToggleIntegration(item)}
                              className="px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-mono shadow flex items-center gap-1"
                            >
                              <Plus className="w-3.5 h-3.5" /> Connect Tool
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Integration Configuration & Handshake Modal */}
            {selectedIntegrationModal && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-lg w-full p-6 space-y-6 shadow-2xl animate-scale-up">
                  
                  <div className="flex justify-between items-start border-b border-white/10 pb-4">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl p-2 rounded-xl bg-white/5 border border-white/10">
                        {selectedIntegrationModal.icon}
                      </span>
                      <div>
                        <h3 className="font-serif font-bold text-lg text-white">
                          Configure {selectedIntegrationModal.name}
                        </h3>
                        <span className="text-xs font-mono text-[#C9A46A]">
                          {selectedIntegrationModal.category} • {selectedIntegrationModal.connected ? 'Connected' : 'Setup Required'}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedIntegrationModal(null)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-4">
                    <p className="text-xs text-[#7C8AA8] leading-relaxed">
                      Enter your authorized API credentials or webhook endpoint. Tokens are securely encrypted and managed in our server-side vault.
                    </p>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-[11px] font-mono uppercase font-bold text-[#7C8AA8] mb-1">
                          Connected Account Identifier / Handle
                        </label>
                        <input
                          type="text"
                          value={selectedIntegrationModal.connectedAccount || ''}
                          onChange={(e) => setSelectedIntegrationModal({
                            ...selectedIntegrationModal,
                            connectedAccount: e.target.value
                          })}
                          placeholder="e.g. @agency_official or acct_production_99"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <label className="text-[11px] font-mono uppercase font-bold text-[#7C8AA8]">
                            API Secret Key / Bearer Token
                          </label>
                          {Boolean(selectedIntegrationModal.fields?.secretKey) && (
                            <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                              <Shield className="w-3 h-3" /> Securely Vaulted
                            </span>
                          )}
                        </div>
                        <div className="relative">
                          <input
                            type={showSecretKey ? "text" : "password"}
                            value={selectedIntegrationModal.fields?.secretKey || ''}
                            onChange={(e) => setSelectedIntegrationModal({
                              ...selectedIntegrationModal,
                              fields: { ...selectedIntegrationModal.fields, secretKey: e.target.value }
                            })}
                            placeholder="Enter or paste secret API key"
                            className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 pr-10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A] font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => setShowSecretKey(!showSecretKey)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1 transition cursor-pointer"
                            title={showSecretKey ? "Hide Secret" : "Show Secret"}
                          >
                            {showSecretKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">
                          Your key is saved in your local sandboxed vault and masked during display to prevent accidental exposure.
                        </p>
                      </div>

                      <div>
                        <label className="block text-[11px] font-mono uppercase font-bold text-[#7C8AA8] mb-1">
                          Webhook Callback URL / Event Endpoint (Optional)
                        </label>
                        <input
                          type="text"
                          value={selectedIntegrationModal.fields?.webhookUrl || `https://api.agencyportal.com/webhooks/${selectedIntegrationModal.id}`}
                          onChange={(e) => setSelectedIntegrationModal({
                            ...selectedIntegrationModal,
                            fields: { ...selectedIntegrationModal.fields, webhookUrl: e.target.value }
                          })}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-slate-300 focus:outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                    </div>

                    <div className="bg-[#111E33] border border-emerald-500/20 rounded-xl p-3 text-xs text-emerald-300/90 flex items-center gap-2.5">
                      <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Zero browser leakage: Handshake authenticates directly via isolated container RPC.</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-3 pt-4 border-t border-white/10">
                    {selectedIntegrationModal.connected && (
                      <button
                        onClick={() => {
                          handleToggleIntegration(selectedIntegrationModal);
                          setSelectedIntegrationModal(null);
                        }}
                        className="px-4 py-2 rounded-xl text-xs font-bold font-mono text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 transition-all cursor-pointer"
                      >
                        Disconnect Tool
                      </button>
                    )}
                    <div className="flex items-center gap-2 ml-auto">
                      <button
                        onClick={() => setSelectedIntegrationModal(null)}
                        className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 bg-white/5 hover:bg-white/10 transition cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={async () => {
                          const accountId = selectedIntegrationModal.connectedAccount;
                          const rawSecret = selectedIntegrationModal.fields?.secretKey?.trim();
                          const vaultKey = localStorage.getItem('wl_api_key_' + selectedIntegrationModal.id);
                          const finalKey = (rawSecret && rawSecret !== '••••••••••••••••••••••••') 
                            ? rawSecret 
                            : (vaultKey || '');

                          if (!accountId || !accountId.trim()) {
                            triggerNotification('Input Required', 'Please enter a valid Account Identifier / Handle.', 'warning');
                            return;
                          }
                          if (!finalKey || !finalKey.trim()) {
                            triggerNotification('Input Required', 'Please enter your API Secret Key or Bearer Token.', 'warning');
                            return;
                          }

                          // Persist key to vault so it never disappears!
                          localStorage.setItem('wl_api_key_' + selectedIntegrationModal.id, finalKey);

                          setIsTestingIntegration(true);
                          try {
                            const res = await fetch('/api/health');
                            if (!res.ok) throw new Error('Handshake failed');
                            
                            const nowTime = new Date().toLocaleTimeString();
                            const updated = {
                              ...selectedIntegrationModal,
                              connected: true,
                              status: 'Connected & Active',
                              lastSync: nowTime,
                              connectedAccount: accountId.trim(),
                              fields: {
                                ...selectedIntegrationModal.fields,
                                secretKey: finalKey
                              }
                            };
                            setExternalIntegrations(prev => prev.map(x => x.id === updated.id ? updated : x));
                            setIsTestingIntegration(false);
                            setSelectedIntegrationModal(null);
                            triggerNotification('Integration Verified', `Successfully authenticated and connected ${updated.name} for ${accountId.trim()}.`, 'success');
                            onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Verified & connected external tool: ${updated.name} (${accountId.trim()})`);
                          } catch (e) {
                            setIsTestingIntegration(false);
                            triggerNotification('Verification Failed', `Unable to verify ${selectedIntegrationModal.name} API handshake. Verify credentials and try again.`, 'danger');
                          }
                        }}
                        disabled={isTestingIntegration}
                        className="px-5 py-2 rounded-xl text-xs font-bold font-mono text-[#0A1220] bg-[#C9A46A] hover:bg-[#E3C48F] disabled:opacity-50 transition shadow cursor-pointer flex items-center gap-2"
                      >
                        {isTestingIntegration ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Verifying Handshake...
                          </>
                        ) : (
                          <>
                            <CheckCircleIcon className="w-3.5 h-3.5" /> Save &amp; Connect Live
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      }


      case 'user-accounts':
        return (
          <div className="space-y-6 min-w-0 w-full overflow-hidden">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
                <div>
                  <h3 className="font-sans font-medium text-lg text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-[#C9A46A]" /> {
                      (currentRole === 'subagency' || currentRole === 'agency')
                        ? `Agency Team & Member Approvals (${currentUser?.subagency || currentUser?.name || 'Bloom & Co'})`
                        : "Main Agency Roster & Approval Queue (Director)"
                    }
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    {(currentRole === 'subagency' || currentRole === 'agency')
                      ? "Manage pending signups and active team members assigned specifically to your agency. Approve requests to unlock their role."
                      : "Manage Main Agency signups and director-level accounts. Sub-agency signups are routed to their respective agency owners."
                    }
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <select
                    value={podApprovalSort}
                    onChange={(e: any) => setPodApprovalSort(e.target.value)}
                    className="bg-[#111E33] border border-white/10 text-xs text-white px-3 py-2 rounded-xl focus:outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    <option value="newest">Sort: Newest First</option>
                    <option value="oldest">Sort: Oldest First</option>
                    <option value="role">Sort: By Role</option>
                    <option value="status">Sort: By Status</option>
                  </select>
                  <button
                    onClick={() => {
                      setNewUserForm({ name: '', email: '', role: 'agent', handle: '', password: '' });
                      setIsAddUserModalOpen(true);
                    }}
                    className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                  >
                    <UserPlus className="w-4 h-4" /> Provision New Account
                  </button>
                </div>
              </div>

              {/* Accounts Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-white/5 bg-[#111E33]/50 text-[#7C8AA8] uppercase font-mono tracking-wider">
                      <th className="p-4">Name / Contact</th>
                      <th className="p-4">Agency / Target Role</th>
                      <th className="p-4">Handle</th>
                      <th className="p-4">Assigned Role</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Joined Date</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-[#B8C0D4]">
                    {userAccounts
                      .filter((u: any) => {
                        if (currentRole === 'subagency' || currentRole === 'agency') {
                          const myPod = (currentUser?.subagencyName || currentUser?.subagency || currentUser?.agency || currentUser?.pod || currentUser?.name || 'Bloom & Co').toLowerCase();
                          return u.pod && (
                            u.pod.toLowerCase().includes(myPod) ||
                            (myPod.includes('bloom') && u.pod?.toLowerCase().includes('bloom')) ||
                            (myPod.includes('viral') && u.pod?.toLowerCase().includes('viral'))
                          );
                        }
                        // Director queue: ONLY show Main Agency signups OR Sub-Agency Owners
                        // Never show signups from a Sub-Agency's invite link (creator, agent, agentmgr in a sub-agency pod)
                        const isSubAgencyOwner = u.role === 'subagency' || u.requestedRole === 'subagency' || u.role === 'agency' || u.requestedRole === 'agency';
                        const isMainAgencySignup = !u.pod || u.pod === 'Main Agency' || u.pod === 'pod_main' || u.pod === 'Main' || u.pod === 'Main Agency (Director)';
                        return isSubAgencyOwner || isMainAgencySignup;
                      })
                      .sort((a: any, b: any) => {
                        if (podApprovalSort === 'oldest') return (a.joined || a.createdAt || '').localeCompare(b.joined || b.createdAt || '');
                        if (podApprovalSort === 'role') return (a.role || a.requestedRole || '').localeCompare(b.role || b.requestedRole || '');
                        if (podApprovalSort === 'status') return (a.status || '').localeCompare(b.status || '');
                        return (b.joined || b.createdAt || '').localeCompare(a.joined || a.createdAt || '');
                      })
                      .map((user: any) => {
                        const isDirector = (currentRole === 'director' || !currentRole || currentUser?.name === 'Sarah Jenkins');
                        const isPodOwner = (currentRole === 'subagency' || currentRole === 'agency');
                        const myPod = (currentUser?.subagencyName || currentUser?.subagency || currentUser?.agency || currentUser?.pod || currentUser?.name || 'Bloom & Co').toLowerCase();
                        const isUserInMyPod = isPodOwner && user.pod && (
                          user.pod.toLowerCase().includes(myPod) ||
                          (myPod.includes('bloom') && user.pod?.toLowerCase().includes('bloom')) ||
                          (myPod.includes('viral') && user.pod?.toLowerCase().includes('viral'))
                        );
                        const canManageUser = isDirector || (isPodOwner && isUserInMyPod && user.role !== 'director' && user.role !== 'subagency' && user.role !== 'agency');

                        return (
                          <tr key={user.id} className="hover:bg-[#111E33]/30 transition-all">
                            <td className="p-4">
                              <div className="font-semibold text-white text-sm">{user.name}</div>
                              <div className="text-[11px] text-[#7C8AA8] font-mono">{user.email}</div>
                            </td>
                            <td className="p-4">
                              <div className="font-semibold text-amber-400 text-xs">{user.pod || 'Main Agency'}</div>
                              <div className="text-[10px] text-emerald-400 font-mono uppercase">
                                Target: {user.requestedRole || user.role || 'creator'}
                              </div>
                            </td>
                            <td className="p-4 font-mono text-xs text-sky-400">{user.handle || 'N/A'}</td>
                            <td className="p-4">
                              <select
                                value={user.role || 'none'}
                                onChange={(e) => {
                                  const newRole = e.target.value;
                                  setUserAccounts((prev: any[]) => prev.map(u => (u.id === user.id || u.uid === user.uid) ? { ...u, role: newRole, status: newRole === 'none' ? 'Pending Approval' : 'Active' } : u));
                                  setUserRoleInFirestore(activeTenantId, user.id || user.uid, newRole);
                                  onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Altered system security role of user ${user.name || user.email} to: ${newRole}`);
                                  triggerNotification('Security Role Updated', `Role for ${user.name || user.email} changed to ${newRole.toUpperCase()} successfully.`, 'success');
                                }}
                                disabled={!canManageUser}
                                className="bg-[#111E33] border border-white/10 text-white rounded-lg p-1 px-2.5 outline-none focus:border-[#C9A46A] text-xs font-mono disabled:opacity-50"
                              >
                                <option value="none">Pending / No Access</option>
                                <option value="director">Director</option>
                                <option value="agentmgr">Agent Manager (agentmgr)</option>
                                <option value="agent">Agent (agent)</option>
                                <option value="coordinator">Campaign Coordinator (coordinator)</option>
                                <option value="agency">Agency (agency)</option>
                                <option value="subagency">Sub-Agency (subagency)</option>
                                <option value="brand">Brand Partner (brand)</option>
                                <option value="creator">Creator (creator)</option>
                              </select>
                            </td>
                            <td className="p-4">
                              <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                                user.status === 'Active'
                                  ? 'bg-emerald-950 border border-emerald-500/30 text-emerald-400'
                                  : user.status === 'Revoked' || user.status === 'Revoked (Disabled)'
                                  ? 'bg-rose-950 border border-rose-500/40 text-rose-400 font-bold'
                                  : 'bg-amber-950 border border-amber-500/30 text-amber-500'
                              }`}>
                                {user.status}
                              </span>
                            </td>
                            <td className="p-4 font-mono text-[#7C8AA8]">{user.joined}</td>
                            <td className="p-4 text-right space-x-2">
                              {user.status === 'Pending Approval' && canManageUser && (
                                <button
                                  onClick={() => {
                                    const targetRole = user.requestedRole && user.requestedRole !== 'none' ? user.requestedRole : 'creator';
                                    setUserAccounts((prev: any[]) => prev.map(u => (u.id === user.id || u.uid === user.uid) ? { ...u, role: targetRole, status: 'Active' } : u));
                                    
                                    if (user.isApplication) {
                                      approveInviteApplicationInFirestore(activeTenantId, user, targetRole);
                                    } else {
                                      setUserRoleInFirestore(activeTenantId, user.id || user.uid, targetRole);
                                    }

                                    onAddActivityLog(currentUser?.name || "Pod Owner", currentRole || "none", `Approved pod signup for ${user.name || user.email} and assigned target role: ${targetRole.toUpperCase()}`);
                                    triggerNotification('User Approved', `Account for ${user.name || user.email} is now ACTIVE as ${targetRole.toUpperCase()}.`, 'success');
                                  }}
                                  className="bg-emerald-500 hover:bg-emerald-400 text-black font-bold p-1.5 px-3 rounded-lg text-[10px] transition-colors cursor-pointer mr-1"
                                  title="Approve request and unlock pod access"
                                >
                                  ✓ Approve Access
                                </button>
                              )}
                              {canManageUser && (
                                <button
                                  onClick={() => {
                                    const isRevoked = user.status === 'Revoked' || user.status === 'Revoked (Disabled)' || user.status === 'Suspended';
                                    const newStatus = isRevoked ? 'Active' : 'Revoked';
                                    setUserAccounts((prev: any[]) => prev.map(u => u.id === user.id ? { ...u, status: newStatus } : u));
                                    onAddActivityLog(currentUser?.name || "User", currentRole || "none", `${newStatus === 'Revoked' ? 'Revoked access for' : 'Re-enabled access for'} user account: ${user.name}`);
                                    triggerNotification(
                                      newStatus === 'Revoked' ? 'User Access Revoked' : 'User Access Restored',
                                      `Account for ${user.name} is now ${newStatus.toUpperCase()}. ${newStatus === 'Revoked' ? 'Login and access disabled immediately.' : 'Access re-enabled.'}`,
                                      newStatus === 'Revoked' ? 'warning' : 'success'
                                    );
                                  }}
                                  className={`p-1.5 px-3 rounded-lg text-[10px] font-semibold transition-colors cursor-pointer ${
                                    user.status === 'Active'
                                      ? 'bg-amber-950/60 border border-amber-500/30 text-amber-300 hover:bg-amber-950'
                                      : 'bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-950'
                                  }`}
                                  title={user.status === 'Active' ? "Revoke access immediately (can be re-enabled)" : "Re-enable access"}
                                >
                                  {user.status === 'Active' ? 'Revoke Access' : 'Re-enable Access'}
                                </button>
                              )}
                              {canManageUser && user.role !== 'director' && (
                                <button
                                  onClick={() => {
                                    setDeleteConfirmConfig({
                                      isOpen: true,
                                      title: user.isApplication ? 'Reject & Delete Application' : 'Permanently Delete User Account',
                                      itemName: `${user.name} (${user.email})`,
                                      itemType: user.isApplication ? 'pod invite application' : 'agency user account',
                                      isPermanent: true,
                                      message: user.isApplication 
                                        ? `Are you sure you want to permanently reject and delete the application for ${user.name}? This action cannot be undone.`
                                        : `Are you sure you want to permanently delete account ${user.name} (${user.email})? This action is permanent and will revoke access credentials immediately.`,
                                      confirmButtonText: user.isApplication ? 'Reject Application' : 'Delete Account',
                                      confirmButtonVariant: 'danger',
                                      onConfirm: () => {
                                        setUserAccounts((prev: any[]) => prev.filter(u => u.id !== user.id && u.uid !== user.uid));
                                        
                                        if (user.isApplication) {
                                          deleteInviteApplicationInFirestore(user.applicationId || user.id || user.uid);
                                          onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Rejected and deleted application for: ${user.name}`);
                                          triggerNotification('Application Rejected', `Applicant ${user.name} has been removed.`, 'info');
                                        } else {
                                          // Save to trash bin for regular users
                                          const savedTrash = localStorage.getItem('wl_trashItems') || '[]';
                                          try {
                                            const trashList = JSON.parse(savedTrash);
                                            trashList.push({
                                              id: 'trash_user_' + Date.now(),
                                              type: 'user',
                                              name: user.name,
                                              deletedAt: new Date().toLocaleDateString(),
                                              data: { ...user, notes: `User account permanently deleted` }
                                            });
                                            localStorage.setItem('wl_trashItems', JSON.stringify(trashList));
                                          } catch (err) { console.error(err); }

                                          const targetId = user.id || user.uid || user.email;
                                          if (targetId) {
                                            deleteDoc(doc(db, 'studio-users', targetId)).catch(e => console.warn('[deleteUser] studio-users error:', e));
                                            deleteDoc(doc(db, 'users', targetId)).catch(e => console.warn('[deleteUser] users error:', e));
                                          }
                                          onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Permanently deleted user account ${user.name} (${user.email})`);
                                          triggerNotification('Account Deleted', `Permanently deleted user profile ${user.name}.`, 'warning');
                                        }
                                        
                                        setDeleteConfirmConfig({ isOpen: false, title: '', itemName: '', itemType: '', onConfirm: () => {} });
                                      }
                                    });
                                  }}
                                  className="bg-rose-950/60 border border-rose-500/30 hover:bg-rose-950 text-rose-400 p-1.5 px-2.5 rounded-lg text-[10px] font-bold transition-colors cursor-pointer inline-flex items-center gap-1"
                                  title="Permanently delete profile"
                                >
                                  <Trash2 className="w-3.5 h-3.5 inline" /> Delete
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal for Provisioning User */}
            {isAddUserModalOpen && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl">
                  <div className="bg-[#111E33] border-b border-white/5 p-4 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-[#C9A46A] uppercase tracking-wider block font-mono">Administration Terminal</span>
                      <h3 className="text-sm font-bold text-white">Provision User Access</h3>
                    </div>
                    <button onClick={() => setIsAddUserModalOpen(false)} className="text-[#7C8AA8] hover:text-white text-sm">✕</button>
                  </div>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const newUser = {
                        id: 'u_' + Date.now(),
                        name: newUserForm.name,
                        email: newUserForm.email,
                        role: newUserForm.role,
                        handle: newUserForm.handle || 'N/A',
                        status: 'Active',
                        joined: new Date().toISOString().split('T')[0]
                      };
                      setUserAccounts((prev: any[]) => [...prev, newUser]);
                      onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Provisioned new credentialed user account: ${newUser.name} with security role: ${newUser.role}`);
                      triggerNotification('User Provisioned', `Account created successfully for ${newUser.name}.`, 'success');
                      setIsAddUserModalOpen(false);
                    }}
                    className="p-5 space-y-4 text-xs"
                  >
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Full Name</label>
                      <input
                        type="text"
                        required
                        value={newUserForm.name}
                        onChange={e => setNewUserForm(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        placeholder="e.g. Liam Parker"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Email Address</label>
                      <input
                        type="email"
                        required
                        value={newUserForm.email}
                        onChange={e => setNewUserForm(prev => ({ ...prev, email: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        placeholder="e.g. liam.parker@bloomandco.studio"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Social Handle</label>
                        <input
                          type="text"
                          value={newUserForm.handle}
                          onChange={e => setNewUserForm(prev => ({ ...prev, handle: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                          placeholder="@liamparker"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Security Level (Role)</label>
                        <select
                          value={newUserForm.role}
                          onChange={e => setNewUserForm(prev => ({ ...prev, role: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono text-xs"
                        >
                          <option value="agent">Agent</option>
                          <option value="agent_manager">Agent Manager</option>
                          <option value="coordinator">Campaign Coordinator</option>
                          <option value="creator">Creator</option>
                          <option value="brand">Brand Partner</option>
                        </select>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Sandbox Access Password</label>
                      <input
                        type="password"
                        required
                        value={newUserForm.password}
                        onChange={e => setNewUserForm(prev => ({ ...prev, password: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        placeholder="••••••••"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-3 rounded-xl font-bold uppercase tracking-wider transition duration-200 cursor-pointer text-xs"
                    >
                      Provision Credentials &amp; Issue Welcome SOP
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* Modal for Creating Sub-Agency Pod & Assigning/Inviting Owner */}
            {isCreatePodModalOpen && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl">
                  <div className="bg-[#111E33] border-b border-white/5 p-4 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-amber-400 uppercase tracking-wider block font-mono">Director-Only Architecture</span>
                      <h3 className="text-sm font-bold text-white">Create New Sub-Agency Pod &amp; Owner</h3>
                    </div>
                    <button onClick={() => setIsCreatePodModalOpen(false)} className="text-[#7C8AA8] hover:text-white text-sm">✕</button>
                  </div>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!newPodForm.name) return;
                      const cleanPodName = newPodForm.name.trim();
                      const cleanCode = cleanPodName.toUpperCase().replace(/[^A-Z0-9]/g, '_') + '_OWNER';
                      const cleanCreatorCode = cleanPodName.toUpperCase().replace(/[^A-Z0-9]/g, '_') + '_INVITE';

                      let ownerDisplayName = newPodForm.ownerName || 'Invited Owner';
                      let ownerEmailAddress = newPodForm.ownerEmail || 'pending@bloom.studio';

                      if (newPodForm.ownerMode === 'assign' && newPodForm.assignedUserId) {
                        const targetUser = userAccounts.find((u: any) => u.id === newPodForm.assignedUserId || u.email === newPodForm.assignedUserId);
                        if (targetUser) {
                          ownerDisplayName = targetUser.name;
                          ownerEmailAddress = targetUser.email;
                          setUserAccounts(prev => prev.map((u: any) => u.id === targetUser.id ? { ...u, role: 'subagency', pod: cleanPodName } : u));
                        }
                      }

                      const newPod = {
                        id: `pod_${Date.now()}`,
                        name: cleanPodName,
                        ownerName: ownerDisplayName,
                        ownerEmail: ownerEmailAddress,
                        ownerHandle: `@${ownerDisplayName.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
                        created: new Date().toISOString().split('T')[0],
                        status: newPodForm.ownerMode === 'invite' ? 'Pending Owner Invitation' : 'Active',
                        description: newPodForm.description || `Sub-Agency Pod managed by ${ownerDisplayName}`,
                        inviteCode: cleanCreatorCode
                      };

                      setSubagencyPods(prev => [newPod, ...prev]);

                      const newInviteEntries = [
                        {
                          id: `code_${Date.now()}_1`,
                          code: cleanCreatorCode,
                          role: 'creator',
                          pod: cleanPodName,
                          purpose: `Default creator invite link for ${cleanPodName}`,
                          uses: 0,
                          status: 'Active',
                          created: new Date().toISOString().split('T')[0]
                        },
                        {
                          id: `code_${Date.now()}_2`,
                          code: cleanCode,
                          role: 'subagency',
                          pod: cleanPodName,
                          purpose: `Sub-Agency Owner onboarding link for ${cleanPodName}`,
                          uses: 0,
                          status: 'Active',
                          created: new Date().toISOString().split('T')[0]
                        }
                      ];

                      setInviteCodes(prev => [...newInviteEntries, ...prev]);

                      onAddActivityLog(currentUser?.name || "Sarah Jenkins", "director", `Created sub-agency pod '${cleanPodName}' with owner '${ownerDisplayName}'`);
                      triggerNotification("Sub-Agency Pod Created", `Created isolated pod '${cleanPodName}'. Owner '${ownerDisplayName}' can now use code ${cleanCreatorCode} for their roster.`, "success");
                      setIsCreatePodModalOpen(false);
                    }}
                    className="p-6 space-y-4 text-xs"
                  >
                    <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 space-y-1">
                      <span className="font-bold block">Isolated Pod Architecture</span>
                      <p className="text-[11px] text-slate-300">
                        When created, the Sub-Agency Owner receives their own pod, custom invite links, and an isolated approval queue for adding their creators and agents.
                      </p>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Sub-Agency Pod Name *</label>
                      <input
                        type="text"
                        required
                        value={newPodForm.name}
                        onChange={e => setNewPodForm(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-amber-400"
                        placeholder="e.g. Bloom Luxury Agency, West Coast Pod"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Pod Description / Specialization</label>
                      <input
                        type="text"
                        value={newPodForm.description}
                        onChange={e => setNewPodForm(prev => ({ ...prev, description: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-amber-400"
                        placeholder="e.g. High-end fashion & lifestyle talent representation"
                      />
                    </div>

                    <div className="space-y-2 pt-1 border-t border-white/10">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Assign Sub-Agency Owner</label>
                      <div className="grid grid-cols-2 gap-2 bg-[#111E33] p-1 rounded-xl border border-white/10">
                        <button
                          type="button"
                          onClick={() => setNewPodForm(prev => ({ ...prev, ownerMode: 'invite' }))}
                          className={`py-2 rounded-lg font-bold text-xs transition-all ${newPodForm.ownerMode === 'invite' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'}`}
                        >
                          Invite New Owner
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewPodForm(prev => ({ ...prev, ownerMode: 'assign' }))}
                          className={`py-2 rounded-lg font-bold text-xs transition-all ${newPodForm.ownerMode === 'assign' ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'}`}
                        >
                          Assign Existing User
                        </button>
                      </div>
                    </div>

                    {newPodForm.ownerMode === 'invite' ? (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Owner Full Name *</label>
                          <input
                            type="text"
                            required
                            value={newPodForm.ownerName}
                            onChange={e => setNewPodForm(prev => ({ ...prev, ownerName: e.target.value }))}
                            className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-amber-400"
                            placeholder="e.g. Elena Rostova"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Owner Email *</label>
                          <input
                            type="email"
                            required
                            value={newPodForm.ownerEmail}
                            onChange={e => setNewPodForm(prev => ({ ...prev, ownerEmail: e.target.value }))}
                            className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-amber-400"
                            placeholder="e.g. elena@bloom.studio"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Select Existing Account *</label>
                        <select
                          required
                          value={newPodForm.assignedUserId}
                          onChange={e => setNewPodForm(prev => ({ ...prev, assignedUserId: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-amber-400"
                        >
                          <option value="">-- Choose Account --</option>
                          {userAccounts.map((u: any) => (
                            <option key={u.id || u.email} value={u.id || u.email}>
                              {u.name} ({u.email}) — Current Role: {u.role}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 py-3 rounded-xl font-bold uppercase tracking-wider transition duration-200 cursor-pointer text-xs"
                    >
                      Create Sub-Agency &amp; Provision Isolated Pod
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        );

      case 'access-codes':
        return (
          <div className="space-y-6">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
                <div>
                  <h3 className="font-sans font-medium text-lg text-white flex items-center gap-2">
                    <Key className="w-5 h-5 text-[#C9A46A]" /> {
                      (currentRole === 'subagency' || currentRole === 'agency')
                        ? `Pod Invite Links & Access Codes (${currentUser?.subagency || currentUser?.name || 'Bloom & Co'})`
                        : "Main Agency Invite Links & Access Codes (Director)"
                    }
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    {(currentRole === 'subagency' || currentRole === 'agency')
                      ? "Generate invite links specifically for your pod. Signups using these links route directly into your pod's approval queue."
                      : "Generate invite tokens for the Main Agency. Sub-agency owners generate and manage their own pod links independently."
                    }
                  </p>
                </div>
                <button
                  onClick={() => {
                    setNewCodeForm({ code: generateSecureInviteCode('BLOOM_'), role: 'creator', maxUses: '5', expiry: '2026-12-31', purpose: '' });
                    setIsAddCodeModalOpen(true);
                  }}
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                >
                  <Plus className="w-4 h-4" /> Issue Access Code
                </button>
              </div>

              {/* Codes Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-white/5 bg-[#111E33]/50 text-[#7C8AA8] uppercase font-mono tracking-wider">
                      <th className="p-4">Access Code</th>
                      <th className="p-4">Target Pod</th>
                      <th className="p-4">Target Security Level</th>
                      <th className="p-4">Uses (Used / Max)</th>
                      <th className="p-4">Expiry Date</th>
                      <th className="p-4">Purpose / Memo</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-[#B8C0D4]">
                    {inviteCodes
                      .filter((code: any) => {
                        if (currentRole === 'subagency' || currentRole === 'agency') {
                          const myPod = (currentUser?.subagency || currentUser?.agency || currentUser?.pod || currentUser?.name || 'Bloom & Co').toLowerCase();
                          return (code.pod && code.pod.toLowerCase().includes(myPod)) ||
                            (myPod.includes('bloom') && code.pod?.toLowerCase().includes('bloom')) ||
                            (myPod.includes('viral') && code.pod?.toLowerCase().includes('viral'));
                        }
                        return !code.pod || code.pod === 'Main Agency' || code.pod === 'main' || code.pod === 'Main';
                      })
                      .map((code: any) => (
                      <tr key={code.code} className="hover:bg-[#111E33]/30 transition-all">
                        <td className="p-4">
                          <span className="font-mono font-bold text-white text-xs tracking-wide select-all bg-[#111E33]/40 border border-white/5 rounded-lg px-2.5 py-1 inline-block">{code.code}</span>
                        </td>
                        <td className="p-4">
                          <span className="font-semibold text-amber-400 text-xs">{code.pod || 'Main Agency'}</span>
                        </td>
                        <td className="p-4">
                          <span className="font-mono text-xs text-sky-400 capitalize">{code.role.replace('_', ' ')}</span>
                        </td>
                        <td className="p-4 font-mono">
                          <span className="text-white font-bold">{code.used}</span> / {code.maxUses}
                        </td>
                        <td className="p-4 font-mono text-[#7C8AA8]">{code.expiry}</td>
                        <td className="p-4 text-xs text-slate-300 italic max-w-[220px] truncate">{code.purpose || 'No memo provided'}</td>
                        <td className="p-4">
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                            code.status === 'Active'
                              ? 'bg-emerald-950 border border-emerald-500/30 text-emerald-400'
                              : 'bg-rose-950 border border-rose-500/30 text-rose-400'
                          }`}>
                            {code.status}
                          </span>
                        </td>
                        <td className="p-4 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            onClick={() => {
                              const url = `${window.location.origin}/?invite=${code.code}`;
                              navigator.clipboard.writeText(url);
                              triggerNotification('Invite Link Copied', `Copied link for ${code.pod || 'Main Agency'} (${code.role}): ${url}`, 'success');
                            }}
                            className="bg-sky-950/40 border border-sky-500/30 hover:bg-sky-950/60 text-sky-400 font-semibold text-[10px] py-1 px-2.5 rounded-lg transition-colors cursor-pointer"
                            title="Copy signup invite link"
                          >
                            🔗 Copy Link
                          </button>
                          {code.status === 'Active' && (
                            <button
                              onClick={() => {
                                setInviteCodes((prev: any[]) => prev.map(c => c.code === code.code ? { ...c, status: 'Revoked' } : c));
                                onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Revoked system-wide invitation access code: ${code.code}`);
                                triggerNotification('Access Code Revoked', `Successfully cancelled access privileges for token: ${code.code}.`, 'warning');
                              }}
                              className="bg-rose-950/40 border border-rose-500/20 hover:bg-rose-950/60 text-rose-400 font-semibold text-[10px] py-1 px-2.5 rounded-lg transition-colors cursor-pointer"
                            >
                              Revoke Token
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal for Issuing Code */}
            {isAddCodeModalOpen && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl">
                  <div className="bg-[#111E33] border-b border-white/5 p-4 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-[#C9A46A] uppercase tracking-wider block font-mono">Cryptography Core</span>
                      <h3 className="text-sm font-bold text-white">Issue Invitation Access Token</h3>
                    </div>
                    <button onClick={() => setIsAddCodeModalOpen(false)} className="text-[#7C8AA8] hover:text-white text-sm">✕</button>
                  </div>
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const targetPod = (currentRole === 'subagency' || currentRole === 'agency')
                        ? (currentUser?.subagency || currentUser?.agency || currentUser?.pod || currentUser?.name || 'Bloom & Co')
                        : 'Main Agency';
                      const newCode = {
                        code: newCodeForm.code,
                        role: newCodeForm.role,
                        pod: targetPod,
                        maxUses: parseInt(newCodeForm.maxUses) || 5,
                        used: 0,
                        expiry: newCodeForm.expiry,
                        status: 'Active',
                        purpose: newCodeForm.purpose
                      };
                      setInviteCodes((prev: any[]) => [newCode, ...prev]);
                      onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Generated secure registration token ${newCode.code} for pod ${targetPod} targeting role: ${newCode.role}`);
                      triggerNotification('Invite Code Generated', `Secure code ${newCode.code} registered for ${targetPod}.`, 'success');
                      setIsAddCodeModalOpen(false);
                    }}
                    className="p-5 space-y-4 text-xs"
                  >
                    <div className="p-2.5 bg-amber-950/40 border border-amber-500/30 rounded-xl text-[11px] text-amber-300">
                      <strong>Target Pod:</strong> {(currentRole === 'subagency' || currentRole === 'agency')
                        ? (currentUser?.subagency || currentUser?.agency || currentUser?.pod || currentUser?.name || 'Bloom & Co')
                        : 'Main Agency (Director)'}
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Custom Token Code</label>
                      <input
                        type="text"
                        required
                        value={newCodeForm.code}
                        onChange={e => setNewCodeForm(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono font-bold tracking-wider"
                        placeholder="BLOOM_PARTNER_CODE"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Target Security Level</label>
                        <select
                          value={newCodeForm.role}
                          onChange={e => setNewCodeForm(prev => ({ ...prev, role: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono text-xs"
                        >
                          <option value="creator">Creator (Represented Roster)</option>
                          <option value="agent">Agent (Agency Agent)</option>
                          <option value="agentmgr">Agent Manager</option>
                          <option value="brand">Brand Partner (Escrow Client)</option>
                          <option value="coordinator">Campaign Coordinator (Execution)</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Maximum Allowed Uses</label>
                        <input
                          type="number"
                          required
                          value={newCodeForm.maxUses}
                          onChange={e => setNewCodeForm(prev => ({ ...prev, maxUses: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                          min="1"
                        />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Expiration Date</label>
                      <input
                        type="date"
                        required
                        value={newCodeForm.expiry}
                        onChange={e => setNewCodeForm(prev => ({ ...prev, expiry: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Purpose / Memo</label>
                      <textarea
                        value={newCodeForm.purpose}
                        onChange={e => setNewCodeForm(prev => ({ ...prev, purpose: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] h-16 resize-none"
                        placeholder="Brief description of who will use this access code..."
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-3 rounded-xl font-bold uppercase tracking-wider transition duration-200 cursor-pointer text-xs"
                    >
                      Issue Token &amp; Save to Master Gatekeeper
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        );

      case 'audit-trail':
        return (
          <div className="space-y-6">
            {/* Immutability disclaimer banner */}
            <div className="bg-[#1A1118] border border-rose-500/20 rounded-2xl p-5 flex items-start gap-4 shadow-lg">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                <ShieldAlert className="w-5 h-5 animate-pulse" />
              </div>
              <div className="space-y-1 text-left">
                <h4 className="text-xs font-bold text-rose-400 uppercase tracking-widest font-mono">⚠️ BINDING AUDIT COMPLIANCE MODULE</h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Under Federal Securities &amp; FTC Guidelines, this network transaction ledger operates under strict write-only immutability rules. Modifying, deleting, or bypassing this trail is programmatically locked for all system profiles — including the Director.
                </p>
              </div>
            </div>

            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
                <div>
                  <h3 className="font-sans font-medium text-lg text-white flex items-center gap-2">
                    <Activity className="w-5 h-5 text-[#C9A46A]" /> Immutably Logged System Operations
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    Complete cryptographic record of every database rewrite, financial validation, contract execution, and access control event.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-500/30 px-3 py-1.5 rounded-full font-bold uppercase tracking-wider font-mono">
                    ✓ SECURE INTEGRITY VERIFIED
                  </span>
                </div>
              </div>

              {/* Filters for Audit Log */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 bg-[#111E33] border border-white/5 rounded-xl px-3 py-2 flex items-center gap-2">
                  <span className="text-slate-500">🔍</span>
                  <input
                    type="text"
                    value={auditFilterText}
                    onChange={(e) => setAuditFilterText(e.target.value)}
                    placeholder="Search logs by operator name, description or role..."
                    className="bg-transparent text-white border-none outline-none text-xs w-full focus:ring-0"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-[#7C8AA8] font-mono uppercase tracking-wider">Role Filter:</span>
                  <select
                    value={auditFilterRole}
                    onChange={(e) => setAuditFilterRole(e.target.value)}
                    className="bg-[#111E33] border border-white/10 text-white rounded-xl p-2 px-3.5 outline-none focus:border-[#C9A46A] text-xs font-mono"
                  >
                    <option value="All">All Roles</option>
                    <option value="director">Director Only</option>
                    <option value="agent_manager">Agent Manager</option>
                    <option value="coordinator">Campaign Coordinator</option>
                    <option value="agent">Agent</option>
                    <option value="subagency">Sub-Agency</option>
                    <option value="brand">Brand Partner</option>
                    <option value="bot">Bot Engine</option>
                  </select>
                </div>
              </div>

              {/* Audit Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-white/5 bg-[#111E33]/50 text-[#7C8AA8] uppercase font-mono tracking-wider">
                      <th className="p-4 w-1/4">Timestamp</th>
                      <th className="p-4 w-1/4">Operator Name</th>
                      <th className="p-4 w-1/6">Role</th>
                      <th className="p-4 w-2/5">Action Captured</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-[#B8C0D4]">
                    {activityLogs
                      .filter((log: any) => {
                        const search = auditFilterText.toLowerCase();
                        const matchText = (log.user || '').toLowerCase().includes(search) || 
                                          (log.action || '').toLowerCase().includes(search) ||
                                          (log.role || '').toLowerCase().includes(search);
                        const matchRole = auditFilterRole === 'All' || 
                                          (log.role || '').toLowerCase() === auditFilterRole.toLowerCase();
                        return matchText && matchRole;
                      })
                      .map((log: any) => {
                        const isDirector = (log.role || '').toLowerCase() === 'director';
                        return (
                          <tr key={log.id} className={`transition-all hover:bg-[#111E33]/20 ${isDirector ? 'bg-amber-500/[0.02]' : ''}`}>
                            <td className="p-4 text-[#7C8AA8] whitespace-nowrap font-mono">{log.time}</td>
                            <td className="p-4 font-semibold text-white flex items-center gap-2">
                              {log.user}
                              {isDirector && (
                                <span className="text-[8px] bg-amber-500/15 text-amber-500 border border-amber-500/25 px-1.5 py-0.5 rounded-full font-bold uppercase font-mono">
                                  Director Action
                                </span>
                              )}
                            </td>
                            <td className="p-4">
                              <span className={`inline-block px-2.5 py-0.5 rounded-full font-semibold text-[10px] border ${
                                log.role?.toLowerCase() === 'director' ? 'bg-amber-950/40 border-amber-500/30 text-amber-400' :
                                log.role?.toLowerCase() === 'bot' ? 'bg-slate-800 border-white/10 text-slate-300' :
                                log.role?.toLowerCase() === 'agentmgr' || log.role?.toLowerCase() === 'agent_manager' || log.role?.toLowerCase() === 'agent' ? 'bg-sky-950/40 border-sky-500/30 text-sky-400' :
                                log.role?.toLowerCase() === 'subagency' || log.role?.toLowerCase() === 'sub-agency' ? 'bg-purple-950/40 border-purple-500/30 text-purple-400' :
                                log.role?.toLowerCase() === 'coordinator' ? 'bg-indigo-950/40 border-indigo-500/30 text-indigo-400' :
                                'bg-teal-950/40 border-teal-500/30 text-teal-400'
                              }`}>
                                {log.role}
                              </span>
                            </td>
                            <td className="p-4 font-mono text-[11px] text-slate-300">{log.action}</td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'backup':
        return (
          <div className="space-y-6">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <h3 className="font-serif font-semibold text-lg text-white border-b border-white/5 pb-3">Database Backup &amp; Recovery</h3>
              <p className="text-xs text-[#7C8AA8]">Download consolidated JSON schemas of all agency state models (creators, deals, invoices, audit trails) to local storage.</p>
              <div className="bg-[#111E33] p-6 rounded-xl border border-white/5 text-center space-y-4 max-w-md mx-auto">
                <Download className="w-12 h-12 text-[#C9A46A] mx-auto" />
                <div>
                  <span className="font-bold text-white text-sm">JSON State Exporter</span>
                  <p className="text-[10px] text-[#7C8AA8] mt-1">Export real-time cache states instantly.</p>
                </div>
                <button type="button" onClick={() => {
                  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ creators, deals, invoices }));
                  const downloadAnchor = document.createElement('a');
                  downloadAnchor.setAttribute("href", dataStr);
                  downloadAnchor.setAttribute("download", "bloom_studio_state_backup.json");
                  document.body.appendChild(downloadAnchor);
                  downloadAnchor.click();
                  downloadAnchor.remove();
                  triggerNotification('Backup Exported', 'Full schema state backup downloaded as JSON.', 'success');
                  onAddActivityLog('Sarah Jenkins', 'director', 'Triggered full system database backup export');
                }} className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2.5 rounded-xl text-xs font-semibold transition-colors">Download Database JSON</button>
              </div>
            </div>
          </div>
        );

      // --- BRAND INQUIRIES INTERACTIVE VIEW ---
      case 'brand-inquiries':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                <span className="text-[10px] text-[#7C8AA8] uppercase">Total Inquiries</span>
                <div className="text-2xl font-bold text-white mt-1">{brandInquiries.length}</div>
              </div>
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                <span className="text-[10px] text-[#7C8AA8] uppercase">Pending Review</span>
                <div className="text-2xl font-bold text-amber-400 mt-1">{brandInquiries.filter(i => i.status === 'Pending').length}</div>
              </div>
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                <span className="text-[10px] text-[#7C8AA8] uppercase">Pipeline Volume</span>
                <div className="text-2xl font-bold text-emerald-400 mt-1">$35,500</div>
              </div>
            </div>
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <h3 className="font-serif font-semibold text-base text-white border-b border-white/5 pb-2">Active Brand Requests Desk</h3>
              <div className="space-y-3.5">
                {brandInquiries.map(inq => (
                  <div key={inq.id} className="p-4 bg-[#111E33] border border-white/5 rounded-xl space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[10px] text-[#C9A46A] uppercase font-bold">{inq.niche}</span>
                        <h4 className="text-sm font-bold text-white">{inq.brand}</h4>
                        <span className="text-[10px] text-[#7C8AA8]">{inq.date}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-mono text-emerald-400 font-semibold block">${inq.budget.toLocaleString()}</span>
                        <span className={`inline-block text-[9px] uppercase font-bold px-2 py-0.5 rounded ${inq.status === 'Pending' ? 'bg-amber-950 text-amber-400' : inq.status === 'Approved' ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>{inq.status}</span>
                      </div>
                    </div>
                    <p className="text-xs text-[#B8C0D4] leading-relaxed italic">"{inq.message}"</p>
                    {inq.status === 'Pending' && (
                      <div className="flex gap-2 justify-end">
                        <button onClick={() => { setBrandInquiries(prev => prev.map(x => x.id === inq.id ? { ...x, status: 'Declined' } : x)); triggerNotification('Inquiry Declined', `Archived ${inq.brand} inquiry.`, 'info'); onAddActivityLog(currentUser?.name || 'Sarah Jenkins', currentRole || 'director', `Declined inquiry from ${inq.brand}`); }} className="px-3 py-1.5 bg-[#16243F] hover:bg-[#1f3256] text-[#7C8AA8] hover:text-white rounded-lg text-xs font-semibold transition-colors">Decline</button>
                        <button 
                          onClick={async () => {
                            // Query the 'global-blacklist' Firestore collection before allowing a new deal to be created
                            const blCheck = await checkBrandBlacklist(inq.brand, currentUser?.tenantId || activeTenantId);
                            if (blCheck.isBlacklisted) {
                              triggerNotification(
                                'Deal Creation Blocked',
                                `Brand '${blCheck.matchedBrand || inq.brand}' is present in the Global Blacklist (${blCheck.reason}). Deal initiation is prohibited.`,
                                'danger'
                              );
                              return;
                            }

                            const newDealId = 'deal_inq_' + Date.now();
                            const newDealObj: Deal = {
                              id: newDealId,
                              title: `${inq.brand} Campaign (${inq.niche || 'Sponsorship'})`,
                              brand: inq.brand,
                              creator: creators[0]?.name || 'Creator',
                              creatorHandle: creators[0]?.handle || '@creator',
                              budget: inq.budget || 5000,
                              value: inq.budget || 5000,
                              stage: 'Lead',
                              status: 'In Negotiation',
                              platform: 'YouTube',
                              due: inq.date || new Date().toISOString().slice(0, 10),
                              dueDate: inq.date || new Date().toISOString().slice(0, 10),
                              tenantId: currentUser?.tenantId || activeTenantId || 'bloom_studio_default',
                              subagency: currentUser?.subagency || 'pod_main'
                            };

                            try {
                              await setDoc(doc(db, 'studio-deals', newDealId), newDealObj, { merge: true });
                            } catch (e) {
                              console.warn('[studio-deals] Error persisting inquiry deal:', e);
                            }

                            if (setDeals) {
                              setDeals(prev => [newDealObj, ...prev]);
                            }

                            setBrandInquiries(prev => prev.map(x => x.id === inq.id ? { ...x, status: 'Approved' } : x));
                            triggerNotification('Inquiry Approved', `${inq.brand} accepted. Lead deal created in pipeline.`, 'success');
                            onAddActivityLog(currentUser?.name || 'Sarah Jenkins', currentRole || 'director', `Approved brand inquiry from ${inq.brand} and initiated deal ${newDealObj.id}`);
                          }} 
                          className="px-3 py-1.5 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                        >
                          Accept &amp; Generate Deal
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      // --- ALL DEALS LISTING ---
      case 'all-deals': {
        return (
          <div className="space-y-6">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-4">
                <div>
                  <h3 className="text-xl font-serif text-white flex items-center gap-2">
                    <Layers className="w-5 h-5 text-[#C9A46A]" /> All Deals &amp; Revenue Pipeline
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-1">Live deal records with centralized Global Blacklist verification upon initiation.</p>
                </div>
                <button
                  onClick={() => {
                    const brandPrompt = window.prompt('Enter Brand Name to initiate new deal:');
                    if (!brandPrompt || !brandPrompt.trim()) return;
                    const cleanBrand = brandPrompt.trim();
                    (async () => {
                      const blCheck = await checkBrandBlacklist(cleanBrand, currentUser?.tenantId || activeTenantId);
                      if (blCheck.isBlacklisted) {
                        triggerNotification(
                          'Deal Creation Blocked',
                          `Brand '${blCheck.matchedBrand || cleanBrand}' is present in the Global Blacklist (${blCheck.reason}). Deal creation is prohibited.`,
                          'danger'
                        );
                        return;
                      }

                      const titlePrompt = window.prompt('Enter Campaign/Deal Title:', `${cleanBrand} Campaign`) || `${cleanBrand} Campaign`;
                      const budgetPrompt = Number(window.prompt('Enter Deal Value / Budget ($):', '5000')) || 5000;
                      
                      const newDealId = 'deal_' + Date.now();
                      const createdDeal: Deal = {
                        id: newDealId,
                        title: titlePrompt,
                        brand: cleanBrand,
                        creator: creators[0]?.name || 'Creator',
                        creatorHandle: creators[0]?.handle || '@creator',
                        budget: budgetPrompt,
                        value: budgetPrompt,
                        stage: 'Lead',
                        status: 'In Negotiation',
                        platform: 'YouTube',
                        due: new Date().toISOString().slice(0, 10),
                        dueDate: new Date().toISOString().slice(0, 10),
                        tenantId: currentUser?.tenantId || activeTenantId || 'bloom_studio_default',
                        subagency: currentUser?.subagency || 'pod_main'
                      };

                      try {
                        await setDoc(doc(db, 'studio-deals', newDealId), createdDeal, { merge: true });
                      } catch (err) {
                        console.warn('[studio-deals] Error persisting new deal:', err);
                      }

                      if (setDeals) {
                        setDeals(prev => [createdDeal, ...prev]);
                      }

                      triggerNotification('Deal Initiated', `Successfully initiated deal for ${cleanBrand} ($${budgetPrompt.toLocaleString()}).`, 'success');
                      onAddActivityLog(currentUser?.name || 'Director', currentRole || 'director', `Initiated deal for ${cleanBrand}: ${createdDeal.title}`);
                    })();
                  }}
                  className="px-4 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Sparkles className="w-4 h-4" /> Initiate New Deal
                </button>
              </div>

              <div className="mt-6 space-y-3">
                {deals && deals.length > 0 ? (
                  deals.map((d: Deal) => (
                    <div key={d.id} className="p-4 bg-[#111E33] border border-white/5 rounded-xl flex flex-col sm:flex-row justify-between sm:items-center gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{d.title || `${d.brand} Campaign`}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded font-mono bg-white/5 text-[#C9A46A] border border-white/10 font-bold uppercase">{d.brand}</span>
                          <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 font-bold border border-emerald-500/20">{d.stage || 'In Progress'}</span>
                        </div>
                        <p className="text-[#7C8AA8] mt-1">Creator: <strong className="text-slate-300">{d.creator || d.creatorHandle}</strong> &middot; Platform: {d.platform || 'General'} &middot; Status: {d.status}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-emerald-400 font-bold font-mono text-sm block">${Number(d.value || d.budget || 0).toLocaleString()}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{d.dueDate || d.due || 'Recent'}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-slate-400 text-xs">No deals logged in the pipeline yet. Click "Initiate New Deal" to add one.</div>
                )}
              </div>
            </div>
          </div>
        );
      }

      // --- BRAND CRM CONTACTS ---
      case 'brand-crm': {
        const filteredBrandsList = brands.filter(b => {
          const matchesSearch = (b.name || '').toLowerCase().includes(brandSearchTerm.toLowerCase()) ||
                                (b.contact || '').toLowerCase().includes(brandSearchTerm.toLowerCase()) ||
                                (b.email || '').toLowerCase().includes(brandSearchTerm.toLowerCase()) ||
                                (b.category || '').toLowerCase().includes(brandSearchTerm.toLowerCase());
          const matchesStatus = brandStatusFilter === 'All' || b.status === brandStatusFilter;
          return matchesSearch && matchesStatus;
        });

        const totalCRMSpend = brands.reduce((sum, b) => sum + (Number(b.spent) || 0), 0);
        const activePartnerCount = brands.filter(b => b.status === 'Active Partner' || b.status === 'Contracted').length;

        return (
          <div className="space-y-6 animate-fade-in">
            {/* Top Stat Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono tracking-wider">Registered Brand Partners</span>
                <p className="text-2xl font-bold text-white mt-1">{brands.length}</p>
                <span className="text-[10px] text-emerald-400 font-semibold">{activePartnerCount} Active Accounts</span>
              </div>
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono tracking-wider">Total Contracted Spend</span>
                <p className="text-2xl font-bold text-emerald-400 mt-1">${totalCRMSpend.toLocaleString()}</p>
                <span className="text-[10px] text-[#7C8AA8]">Across lifetime deals</span>
              </div>
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase font-mono tracking-wider">Escrow Settlement Mode</span>
                <p className="text-2xl font-bold text-[#C9A46A] mt-1">Pre-Funded</p>
                <span className="text-[10px] text-slate-400">100% upfront creator protection</span>
              </div>
            </div>

            {/* Educational Definition Badge for Brand CRM & Escrow */}
            <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[#C9A46A] font-bold uppercase font-mono text-[10px] bg-[#16243F] px-2 py-0.5 rounded border border-[#C9A46A]/20">
                    CRM &amp; Escrow Directives
                  </span>
                  <span className="text-white font-semibold">Account Manager &amp; Billing Automation</span>
                </div>
                <p className="text-[#7C8AA8] text-[11px] leading-relaxed">
                  Registered brands retain designated billing contacts, AP emails, and escrow preferences. When you initiate <strong>"Create Escrow / Lock Brand Fund"</strong>, the system dispatches the pre-funding deposit request and binding invoice straight to the brand's verified contact email.
                </p>
              </div>
            </div>

            {/* Brand Directory Main Container */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-4">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white">Brand Client Directory</h3>
                  <p className="text-xs text-[#7C8AA8]">Manage brand accounts, direct decision-maker contacts, lifetime budgets, and escrow locking.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setNewBrandForm({
                        name: '',
                        contact: '',
                        email: '',
                        status: 'Warm Lead',
                        spent: 0,
                        activeCampaigns: 0,
                        category: 'Fashion & Lifestyle',
                        notes: '',
                        escrowPreference: '100% Pre-funded Escrow'
                      });
                      setIsAddBrandModalOpen(true);
                    }}
                    className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Register Brand
                  </button>
                </div>
              </div>

              {/* Filters & Search */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 flex items-center gap-2">
                  <span className="text-slate-500">🔍</span>
                  <input
                    type="text"
                    value={brandSearchTerm}
                    onChange={(e) => setBrandSearchTerm(e.target.value)}
                    placeholder="Search brands by company name, contact person, email or category..."
                    className="bg-transparent text-white border-none outline-none text-xs w-full focus:ring-0"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-[#7C8AA8] font-mono uppercase tracking-wider">Status:</span>
                  <select
                    value={brandStatusFilter}
                    onChange={(e) => setBrandStatusFilter(e.target.value)}
                    className="bg-[#111E33] border border-white/10 text-white rounded-xl p-2 px-3 outline-none focus:border-[#C9A46A] text-xs font-mono"
                  >
                    <option value="All">All Statuses</option>
                    <option value="Active Partner">Active Partner</option>
                    <option value="Contracted">Contracted</option>
                    <option value="In Negotiation">In Negotiation</option>
                    <option value="Warm Lead">Warm Lead</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              {/* Brands Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredBrandsList.map(b => (
                  <div key={b.id} className="p-4 bg-[#111E33] border border-white/5 hover:border-white/10 rounded-xl space-y-3.5 transition-all">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-base font-bold text-white">{b.name}</span>
                          {b.category && (
                            <span className="text-[10px] text-slate-400 bg-[#16243F] px-2 py-0.5 rounded font-mono border border-white/5">
                              {b.category}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-300 mt-1">
                          Contact: <strong className="text-white">{b.contact}</strong>
                        </p>
                      </div>
                      <span className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded font-mono border ${
                        b.status === 'Active Partner' || b.status === 'Contracted'
                          ? 'bg-emerald-950/80 text-emerald-400 border-emerald-500/30'
                          : b.status === 'In Negotiation'
                          ? 'bg-sky-950/80 text-sky-400 border-sky-500/30'
                          : b.status === 'Warm Lead'
                          ? 'bg-amber-950/80 text-amber-400 border-amber-500/30'
                          : 'bg-slate-800 text-slate-400 border-white/10'
                      }`}>
                        {b.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-[#7C8AA8] bg-[#0D1830] p-3 rounded-lg border border-white/5">
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">AP / Contact Email</span>
                        <span className="text-slate-200 font-mono text-[11px] truncate block" title={b.email}>{b.email}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">Lifetime Spend</span>
                        <span className="text-emerald-400 font-bold font-mono text-[11px]">${Number(b.spent || 0).toLocaleString()}</span>
                      </div>
                      <div className="mt-1">
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">Active Campaigns</span>
                        <span className="text-white font-semibold">{b.activeCampaigns || 0} Deals</span>
                      </div>
                      <div className="mt-1">
                        <span className="text-[10px] text-slate-500 block uppercase font-mono">Escrow Preference</span>
                        <span className="text-[#C9A46A] font-semibold text-[11px]">{b.escrowPreference || '100% Pre-funded'}</span>
                      </div>
                    </div>

                    {b.notes && (
                      <p className="text-[11px] text-slate-400 italic bg-[#16243F]/50 p-2 rounded border border-white/5">
                        "{b.notes}"
                      </p>
                    )}

                    <div className="flex items-center justify-between pt-1 border-t border-white/5">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setEscrowTargetBrand(b.name);
                            setEscrowContactEmail(b.email);
                            setEscrowCampaignTitle(`${b.name} Seasonal Activation`);
                            setEscrowAmount(5000);
                            setIsEscrowModalOpen(true);
                          }}
                          className="px-2.5 py-1.5 bg-[#C9A46A]/20 hover:bg-[#C9A46A]/30 text-[#C9A46A] border border-[#C9A46A]/40 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Lock className="w-3 h-3" /> Lock Fund / Escrow
                        </button>
                        <button
                          onClick={() => {
                            setSelectedBrandForEdit(b);
                            setIsEditBrandModalOpen(true);
                          }}
                          className="px-2.5 py-1.5 bg-[#16243F] hover:bg-[#1f3050] text-slate-300 hover:text-white rounded-lg text-[11px] font-semibold transition-colors cursor-pointer"
                        >
                          Edit
                        </button>
                      </div>
                      <button
                        onClick={() => {
                          setBrands(prev => prev.filter(x => x.id !== b.id));
                          triggerNotification('Brand Deleted', `${b.name} removed from CRM.`, 'warning');
                          onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Deleted brand record ${b.name}`);
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                        title="Delete Brand Account"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {filteredBrandsList.length === 0 && (
                  <div className="col-span-2 text-center py-10 bg-[#111E33] rounded-xl border border-white/5 space-y-2">
                    <p className="text-sm text-slate-400">No matching brand records found.</p>
                    <button
                      onClick={() => {
                        setBrandSearchTerm('');
                        setBrandStatusFilter('All');
                      }}
                      className="text-xs text-[#C9A46A] hover:underline"
                    >
                      Clear search filters
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Modal: Register Brand */}
            {isAddBrandModalOpen && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-white/10 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-scale-up">
                  <div className="p-5 border-b border-white/5 flex justify-between items-center bg-[#111E33]">
                    <div>
                      <h3 className="font-serif font-semibold text-lg text-white">Register New Brand Partner</h3>
                      <p className="text-xs text-[#7C8AA8]">Add a client to your agency directory to route invoices and escrow contracts.</p>
                    </div>
                    <button
                      onClick={() => setIsAddBrandModalOpen(false)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      if (!newBrandForm.name || !newBrandForm.contact || !newBrandForm.email) {
                        triggerNotification('Missing Fields', 'Please provide brand name, contact person, and billing email.', 'danger');
                        return;
                      }

                      // Check global blacklist
                      const blCheck = await checkBrandBlacklist(newBrandForm.name.trim(), currentUser?.tenantId || activeTenantId);
                      if (blCheck.isBlacklisted) {
                        triggerNotification(
                          'Brand Registration Blocked',
                          `Brand '${blCheck.matchedBrand || newBrandForm.name}' is on the Global Blacklist (${blCheck.reason}). Registration is prohibited.`,
                          'danger'
                        );
                        return;
                      }

                      const newB = {
                        id: 'br_' + Date.now(),
                        name: newBrandForm.name,
                        contact: newBrandForm.contact,
                        email: newBrandForm.email,
                        status: newBrandForm.status,
                        spent: Number(newBrandForm.spent) || 0,
                        activeCampaigns: Number(newBrandForm.activeCampaigns) || 0,
                        category: newBrandForm.category,
                        notes: newBrandForm.notes,
                        escrowPreference: newBrandForm.escrowPreference
                      };
                      setBrands(prev => [newB, ...prev]);
                      setIsAddBrandModalOpen(false);
                      triggerNotification('Brand Registered', `Successfully registered ${newBrandForm.name} in CRM directory.`, 'success');
                      onAddActivityLog(currentUser?.name || "User", currentRole || "none", `Registered new brand account: ${newBrandForm.name} (${newBrandForm.email})`);
                    }}
                    className="p-5 space-y-4 text-xs max-h-[80vh] overflow-y-auto"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Brand / Company Name *</label>
                        <input
                          type="text"
                          required
                          value={newBrandForm.name}
                          onChange={e => setNewBrandForm(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="e.g. Gymshark, Sephora, Celsius"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Category / Industry</label>
                        <select
                          value={newBrandForm.category}
                          onChange={e => setNewBrandForm(prev => ({ ...prev, category: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        >
                          <option value="Fashion & Lifestyle">Fashion &amp; Lifestyle</option>
                          <option value="Beauty & Skincare">Beauty &amp; Skincare</option>
                          <option value="Sportswear & Fitness">Sportswear &amp; Fitness</option>
                          <option value="Gaming & Tech">Gaming &amp; Tech</option>
                          <option value="Food & Beverage">Food &amp; Beverage</option>
                          <option value="Health & Wellness">Health &amp; Wellness</option>
                          <option value="Entertainment & Media">Entertainment &amp; Media</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Decision Maker / Contact Name *</label>
                        <input
                          type="text"
                          required
                          value={newBrandForm.contact}
                          onChange={e => setNewBrandForm(prev => ({ ...prev, contact: e.target.value }))}
                          placeholder="e.g. Rachel Adams (Influencer Lead)"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Billing / AP Contact Email *</label>
                        <input
                          type="email"
                          required
                          value={newBrandForm.email}
                          onChange={e => setNewBrandForm(prev => ({ ...prev, email: e.target.value }))}
                          placeholder="e.g. accounts.payable@brand.com"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Account Status</label>
                        <select
                          value={newBrandForm.status}
                          onChange={e => setNewBrandForm(prev => ({ ...prev, status: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        >
                          <option value="Warm Lead">Warm Lead</option>
                          <option value="In Negotiation">In Negotiation</option>
                          <option value="Contracted">Contracted</option>
                          <option value="Active Partner">Active Partner</option>
                          <option value="Inactive">Inactive</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Initial / Lifetime Budget ($)</label>
                        <input
                          type="number"
                          value={newBrandForm.spent}
                          onChange={e => setNewBrandForm(prev => ({ ...prev, spent: Number(e.target.value) }))}
                          placeholder="0"
                          min="0"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Active Campaigns</label>
                        <input
                          type="number"
                          value={newBrandForm.activeCampaigns}
                          onChange={e => setNewBrandForm(prev => ({ ...prev, activeCampaigns: Number(e.target.value) }))}
                          placeholder="0"
                          min="0"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Escrow Pre-funding Requirement</label>
                      <select
                        value={newBrandForm.escrowPreference}
                        onChange={e => setNewBrandForm(prev => ({ ...prev, escrowPreference: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                      >
                        <option value="100% Pre-funded Escrow">100% Pre-funded Escrow (Standard Creator Protection)</option>
                        <option value="50% Upfront Deposit / 50% on Delivery">50% Upfront Deposit / 50% on Delivery</option>
                        <option value="Net 15 Direct Wire (Approved Corporate AP)">Net 15 Direct Wire (Approved Corporate AP)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Internal Notes &amp; Campaign Goals</label>
                      <textarea
                        value={newBrandForm.notes}
                        onChange={e => setNewBrandForm(prev => ({ ...prev, notes: e.target.value }))}
                        placeholder="Add background notes on brand guidelines, target demographics, past deal history..."
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] h-20 resize-none"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-3 border-t border-white/5">
                      <button
                        type="button"
                        onClick={() => setIsAddBrandModalOpen(false)}
                        className="px-4 py-2.5 bg-[#16243F] hover:bg-[#1f3050] text-slate-300 hover:text-white rounded-xl text-xs font-semibold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2.5 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold"
                      >
                        Save Brand to CRM
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Modal: Edit Brand */}
            {isEditBrandModalOpen && selectedBrandForEdit && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-white/10 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-scale-up">
                  <div className="p-5 border-b border-white/5 flex justify-between items-center bg-[#111E33]">
                    <div>
                      <h3 className="font-serif font-semibold text-lg text-white">Edit Brand: {selectedBrandForEdit.name}</h3>
                      <p className="text-xs text-[#7C8AA8]">Update contact credentials and account details.</p>
                    </div>
                    <button
                      onClick={() => setIsEditBrandModalOpen(false)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      setBrands(prev => prev.map(x => x.id === selectedBrandForEdit.id ? selectedBrandForEdit : x));
                      setIsEditBrandModalOpen(false);
                      triggerNotification('Brand Updated', `${selectedBrandForEdit.name} details saved.`, 'success');
                      onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Updated brand details for ${selectedBrandForEdit.name}`);
                    }}
                    className="p-5 space-y-4 text-xs"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Brand Name</label>
                        <input
                          type="text"
                          required
                          value={selectedBrandForEdit.name}
                          onChange={e => setSelectedBrandForEdit((prev: any) => ({ ...prev, name: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Contact Person</label>
                        <input
                          type="text"
                          required
                          value={selectedBrandForEdit.contact}
                          onChange={e => setSelectedBrandForEdit((prev: any) => ({ ...prev, contact: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Billing / AP Email</label>
                        <input
                          type="email"
                          required
                          value={selectedBrandForEdit.email}
                          onChange={e => setSelectedBrandForEdit((prev: any) => ({ ...prev, email: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Status</label>
                        <select
                          value={selectedBrandForEdit.status}
                          onChange={e => setSelectedBrandForEdit((prev: any) => ({ ...prev, status: e.target.value }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        >
                          <option value="Warm Lead">Warm Lead</option>
                          <option value="In Negotiation">In Negotiation</option>
                          <option value="Contracted">Contracted</option>
                          <option value="Active Partner">Active Partner</option>
                          <option value="Inactive">Inactive</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Lifetime Spend ($)</label>
                        <input
                          type="number"
                          value={selectedBrandForEdit.spent}
                          onChange={e => setSelectedBrandForEdit((prev: any) => ({ ...prev, spent: Number(e.target.value) }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Active Deals Count</label>
                        <input
                          type="number"
                          value={selectedBrandForEdit.activeCampaigns}
                          onChange={e => setSelectedBrandForEdit((prev: any) => ({ ...prev, activeCampaigns: Number(e.target.value) }))}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Internal Notes</label>
                      <textarea
                        value={selectedBrandForEdit.notes || ''}
                        onChange={e => setSelectedBrandForEdit((prev: any) => ({ ...prev, notes: e.target.value }))}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] h-16 resize-none"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-3 border-t border-white/5">
                      <button
                        type="button"
                        onClick={() => setIsEditBrandModalOpen(false)}
                        className="px-4 py-2 bg-[#16243F] text-slate-300 rounded-xl"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold rounded-xl"
                      >
                        Save Changes
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Modal: Create Escrow / Lock Brand Fund */}
            {isEscrowModalOpen && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl animate-scale-up">
                  <div className="p-5 border-b border-white/10 flex justify-between items-center bg-[#111E33]">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-[#C9A46A]/20 flex items-center justify-center text-[#C9A46A]">
                        <Lock className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="font-serif font-semibold text-lg text-white">Create Escrow &amp; Lock Brand Funds</h3>
                        <p className="text-xs text-[#7C8AA8]">Dispatch pre-funding escrow agreement and invoice to the brand's verified billing email.</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setIsEscrowModalOpen(false)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Clarification on Invoice vs Lock Brand Fund */}
                  <div className="p-4 bg-[#16243F] border-b border-white/5 text-xs text-slate-300 space-y-1.5">
                    <div className="font-semibold text-[#C9A46A] flex items-center gap-1.5">
                      <span>💡 Escrow vs. Standard Invoice Definition:</span>
                    </div>
                    <p className="text-[11px] leading-relaxed">
                      <strong>Standard Invoice:</strong> A post-pay billing statement with Net 15/30 terms.<br />
                      <strong>Lock Brand Fund (Escrow):</strong> Requires the brand to pre-deposit 100% of the funds into agency escrow <em>before</em> creator production begins, guaranteeing creator compensation upon verified delivery.
                    </p>
                  </div>

                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      if (!escrowTargetBrand || !escrowContactEmail || !escrowAmount) {
                        triggerNotification('Missing Fields', 'Please specify brand, email, and amount.', 'danger');
                        return;
                      }

                      // Check global blacklist before locking funds / creating escrow contract
                      const blCheck = await checkBrandBlacklist(escrowTargetBrand, currentUser?.tenantId || activeTenantId);
                      if (blCheck.isBlacklisted) {
                        triggerNotification(
                          'Escrow Creation Blocked',
                          `Brand '${blCheck.matchedBrand || escrowTargetBrand}' is on the Global Blacklist (${blCheck.reason}). Escrow funding and deal dispatch is prohibited.`,
                          'danger'
                        );
                        return;
                      }

                      // Auto record in payout ledger as pending escrow
                      const newLedgerItem = {
                        id: 'led_' + Date.now(),
                        dealTitle: escrowCampaignTitle || `${escrowTargetBrand} Escrow Hold`,
                        brand: escrowTargetBrand,
                        creator: escrowCreatorHandle || '@creator',
                        creatorName: escrowCreatorHandle || 'Assigned Talent',
                        amount: Number(escrowAmount) || 5000,
                        status: 'Pending',
                        payoutMethod: 'Stripe Escrow Pre-Fund',
                        datePaid: '-'
                      };

                      // Call API
                      const authHeaders = await getAuthHeaders();
                      fetch('/api/ledger-transactions', {
                        method: 'POST',
                        headers: { 
                          'Content-Type': 'application/json',
                          ...authHeaders 
                        },
                        body: JSON.stringify({
                          transactionId: newLedgerItem.id,
                          brand: newLedgerItem.brand,
                          creator: newLedgerItem.creator,
                          creatorName: newLedgerItem.creatorName,
                          type: 'Escrow Deposit',
                          grossAmount: newLedgerItem.amount,
                          agencyCut: newLedgerItem.amount * 0.2,
                          creatorPayout: newLedgerItem.amount * 0.8,
                          status: 'Locked in Escrow',
                          milestone: newLedgerItem.dealTitle
                        })
                      }).catch(err => console.error('Ledger API error:', err));

                      setPayoutLedger((prev: any) => [newLedgerItem, ...prev]);
                      setIsEscrowModalOpen(false);

                      triggerNotification(
                        'Escrow Invoice Dispatched',
                        `Pre-funding invoice for $${Number(escrowAmount).toLocaleString()} dispatched to ${escrowContactEmail} (${escrowTargetBrand}). Funds locked in escrow upon deposit.`,
                        'success'
                      );
                      onAddActivityLog(
                        currentUser?.name || 'User',
                        currentRole || 'none',
                        `Dispatched $${Number(escrowAmount).toLocaleString()} escrow funding invoice to ${escrowTargetBrand} at ${escrowContactEmail}`
                      );
                    }}
                    className="p-5 space-y-4 text-xs"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Target Brand Account *</label>
                        <select
                          value={escrowTargetBrand}
                          onChange={(e) => {
                            const b = brands.find(x => x.name === e.target.value);
                            setEscrowTargetBrand(e.target.value);
                            if (b) setEscrowContactEmail(b.email);
                          }}
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                          required
                        >
                          <option value="">-- Choose Brand Partner --</option>
                          {brands.map(b => (
                            <option key={b.id} value={b.name}>{b.name} ({b.contact})</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Recipient Billing Email (AP) *</label>
                        <input
                          type="email"
                          required
                          value={escrowContactEmail}
                          onChange={e => setEscrowContactEmail(e.target.value)}
                          placeholder="billing@brand.com"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Campaign / Deal Title</label>
                        <input
                          type="text"
                          required
                          value={escrowCampaignTitle}
                          onChange={e => setEscrowCampaignTitle(e.target.value)}
                          placeholder="e.g. Summer UGC Bundle"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Escrow Deposit Amount ($) *</label>
                        <input
                          type="number"
                          required
                          min="100"
                          value={escrowAmount}
                          onChange={e => setEscrowAmount(Number(e.target.value))}
                          placeholder="5000"
                          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A] font-mono font-bold text-emerald-400"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Beneficiary Creator Roster</label>
                      <select
                        value={escrowCreatorHandle}
                        onChange={e => setEscrowCreatorHandle(e.target.value)}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                      >
                        <option value="">-- All Designated Campaign Creators --</option>
                        {creators.map(c => (
                          <option key={c.id} value={c.handle}>{c.handle} ({c.name})</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[#7C8AA8] uppercase font-semibold text-[10px]">Release / Settlement Condition</label>
                      <input
                        type="text"
                        value={escrowReleaseCondition}
                        onChange={e => setEscrowReleaseCondition(e.target.value)}
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-3 border-t border-white/5">
                      <button
                        type="button"
                        onClick={() => setIsEscrowModalOpen(false)}
                        className="px-4 py-2.5 bg-[#16243F] text-slate-300 rounded-xl font-semibold"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2.5 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold rounded-xl shadow-lg flex items-center gap-1.5 cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" /> Dispatch Escrow Invoice &amp; Agreement
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        );
      }

      // --- REFERRALS LEDGER ---
      case 'referrals':
        return (
          <div className="space-y-6">
            {/* Log Referral Form */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="border-b border-white/5 pb-2">
                <h3 className="font-serif font-semibold text-base text-white">Log Roster &amp; Deal Referral</h3>
                <p className="text-xs text-[#7C8AA8]">Add a new referral record to track who sent it, reward values, and reward notices.</p>
              </div>
              <form onSubmit={(e) => {
                e.preventDefault();
                if (!refReferrer || !refReferred) {
                  triggerNotification('Form Error', 'Please fill out all required fields.', 'danger');
                  return;
                }
                const newRef = {
                  id: 'ref_b_' + Date.now(),
                  referrer: refReferrer,
                  referred: refReferred,
                  type: refType,
                  value: refValue,
                  date: new Date().toISOString().split('T')[0],
                  status: 'Pending Approval'
                };
                setBoardReferrals(prev => [newRef, ...prev]);
                triggerNotification('Referral Logged', `Successfully logged referral from ${refReferrer} to ${refReferred}.`, 'success');
                onAddActivityLog('Sarah Jenkins', 'director', `Logged referral: ${refReferrer} sent ${refReferred}`);
                setRefReferrer('');
                setRefReferred('');
              }} className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Referrer (Who Sent Them)</label>
                  <select
                    value={refReferrer}
                    onChange={(e) => setRefReferrer(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  >
                    <option value="">-- Choose Creator --</option>
                    {creators.map(c => (
                      <option key={c.id} value={c.handle}>{c.handle} ({c.name})</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Referred Talent/Brand</label>
                  <input
                    type="text"
                    value={refReferred}
                    onChange={(e) => setRefReferred(e.target.value)}
                    placeholder="e.g. @creativemax or Nike Campaign"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Type of Referral</label>
                  <select
                    value={refType}
                    onChange={(e) => setRefType(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                  >
                    <option value="Creator">Creator Representation</option>
                    <option value="Brand Deal">Brand Deal Campaign</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Bonus Reward Value</label>
                  <input
                    type="text"
                    value={refValue}
                    onChange={(e) => setRefValue(e.target.value)}
                    placeholder="e.g. $250"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>
                <div className="md:col-span-4 flex justify-end">
                  <button type="submit" className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl font-bold transition-all flex items-center gap-1.5">
                    <Plus className="w-4 h-4" /> Log Referral Record
                  </button>
                </div>
              </form>
            </div>

            {/* Referrals Desk List */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <h3 className="font-serif font-semibold text-lg text-white border-b border-white/5 pb-2">Active Referral Ledger</h3>
              <div className="space-y-3">
                {boardReferrals.map(ref => (
                  <div key={ref.id} className="p-4 bg-[#111E33] border border-white/5 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div>
                      <span className="text-[#C9A46A] font-bold block">{ref.referrer} referred {ref.referred}</span>
                      <p className="text-[10px] text-[#7C8AA8] mt-0.5">Type: {ref.type} &middot; Submitted: {ref.date}</p>
                    </div>
                    <div className="flex items-center justify-between md:justify-end gap-4">
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-mono text-[#7C8AA8]">Bonus ($):</span>
                            <input
                              type="text"
                              value={ref.value}
                              onChange={(e) => {
                                const val = e.target.value;
                                setBoardReferrals(prev => prev.map(x => x.id === ref.id ? { ...x, value: val } : x));
                              }}
                              placeholder="$500.00"
                              className="w-24 bg-[#0A1220] border border-white/10 rounded-lg px-2.5 py-1 text-emerald-400 font-mono text-xs text-right focus:outline-none focus:border-[#C9A46A]"
                            />
                          </div>
                          <span className={`text-[10px] uppercase font-bold block mt-1 ${ref.status === 'Paid' ? 'text-emerald-400' : 'text-amber-400'}`}>{ref.status}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {ref.status !== 'Paid' && (
                          <button onClick={() => {
                            setBoardReferrals(prev => prev.map(x => x.id === ref.id ? { ...x, status: 'Paid' } : x));
                            triggerNotification('Bonus Disbursed', `Disbursed ${ref.value} referral credit to ${ref.referrer}`, 'success');
                            onAddActivityLog('Sarah Jenkins', 'director', `Paid referral bonus of ${ref.value} to ${ref.referrer}`);
                          }} className="bg-emerald-950 hover:bg-emerald-900 text-emerald-400 px-3 py-1.5 rounded-lg font-bold border border-emerald-500/15 transition-all text-[11px]">+ Release</button>
                        )}
                        <button onClick={() => {
                          triggerNotification('Reward Notice Sent', `Dispatched bonus notice to ${ref.referrer}. They will receive their ${ref.value} bonus.`, 'success');
                          onAddActivityLog('Sarah Jenkins', 'director', `Dispatched referral award notice to ${ref.referrer} for referring ${ref.referred}`);
                        }} className="bg-[#16243F] hover:bg-[#1e345c] text-white px-3 py-1.5 rounded-lg font-semibold transition-colors text-[11px] flex items-center gap-1">
                          <Send className="w-3 h-3" /> Notice
                        </button>
                        <button onClick={() => {
                          setBoardReferrals(prev => prev.filter(x => x.id !== ref.id));
                          triggerNotification('Referral Removed', 'Referral registry slot deleted.', 'warning');
                        }} className="p-1.5 bg-rose-950/30 hover:bg-rose-900/30 text-rose-400 border border-rose-500/10 rounded-lg" title="Delete Referral">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {boardReferrals.length === 0 && (
                  <p className="text-xs text-slate-500 italic text-center py-4">No logged referrals on record.</p>
                )}
              </div>
            </div>
          </div>
        );

      // --- RETAINERS TRACKER ---
      case 'retainers':
        return (
          <div className="space-y-6">
            {/* Add Retainer Client */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="border-b border-white/5 pb-2">
                <h3 className="font-serif font-semibold text-base text-[#C9A46A]">Add Monthly Retainer Contract</h3>
                <p className="text-xs text-[#7C8AA8]">Input fixed client partnerships with monthly recurring billing limits.</p>
              </div>
              <form onSubmit={async (e) => {
                e.preventDefault();
                if (!retBrand || !retAmount) {
                  triggerNotification('Error', 'Please enter brand and amount.', 'danger');
                  return;
                }

                const cleanBrand = retBrand.trim();
                const blCheck = await checkBrandBlacklist(cleanBrand, currentUser?.tenantId || activeTenantId);
                if (blCheck.isBlacklisted) {
                  triggerNotification(
                    'Retainer Contract Blocked',
                    `Brand '${blCheck.matchedBrand || cleanBrand}' is on the Global Blacklist (${blCheck.reason}). Retainer contract initiation is prohibited.`,
                    'danger'
                  );
                  return;
                }

                const newRet = {
                  id: 'ret_' + Date.now(),
                  brand: cleanBrand,
                  amount: parseInt(retAmount) || 2000,
                  cycle: 'Monthly',
                  status: retPaidStatus === 'Received' ? 'Active' : 'Unpaid (Overdue)',
                  postsIncluded: parseInt(retPosts) || 5,
                  nextInvoice: retNextInvoice || '2026-08-01'
                };
                setRetainers(prev => [newRet, ...prev]);
                triggerNotification('Retainer Added', `New recurring contract added for ${cleanBrand}.`, 'success');
                onAddActivityLog(currentUser?.name || 'Sarah Jenkins', currentRole || 'director', `Created retainer agreement: ${cleanBrand} ($${retAmount}/mo)`);
                setRetBrand('');
                setRetAmount('');
                setRetPosts('');
                setRetNextInvoice('');
              }} className="grid grid-cols-1 md:grid-cols-5 gap-4 text-xs">
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Brand Partner</label>
                  <input
                    type="text"
                    value={retBrand}
                    onChange={(e) => setRetBrand(e.target.value)}
                    placeholder="e.g. Alo Yoga"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Monthly Amount ($)</label>
                  <input
                    type="number"
                    value={retAmount}
                    onChange={(e) => setRetAmount(e.target.value)}
                    placeholder="e.g. 4000"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Monthly Posts Limit</label>
                  <input
                    type="number"
                    value={retPosts}
                    onChange={(e) => setRetPosts(e.target.value)}
                    placeholder="e.g. 8"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Next Billing Cycle</label>
                  <input
                    type="date"
                    value={retNextInvoice}
                    onChange={(e) => setRetNextInvoice(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-[#C9A46A]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[#7C8AA8]">Payment Status</label>
                  <select
                    value={retPaidStatus}
                    onChange={(e) => setRetPaidStatus(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                  >
                    <option value="Received">Payment Received</option>
                    <option value="Not Received">Not Received (Arrears)</option>
                  </select>
                </div>
                <div className="md:col-span-5 flex justify-end">
                  <button type="submit" className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl font-bold transition-all">
                    Establish Contract
                  </button>
                </div>
              </form>
            </div>

            {/* List Retainers */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <h3 className="font-serif font-semibold text-lg text-white border-b border-white/5 pb-2">Monthly Retainer Clients</h3>
              <div className="space-y-3.5">
                {retainers.map(ret => {
                  const isUnpaid = ret.status.toLowerCase().includes('unpaid') || ret.status.toLowerCase().includes('paused') || ret.status === 'Not Received';
                  return (
                    <div key={ret.id} className="p-4 bg-[#111E33] border border-white/5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">{ret.brand} Retainer</span>
                          {isUnpaid ? (
                            <span className="bg-rose-950/80 text-rose-400 text-[9px] font-bold px-2 py-0.5 rounded border border-rose-500/20">🚨 UNPAID / ARREARS</span>
                          ) : (
                            <span className="bg-emerald-950/80 text-emerald-400 text-[9px] font-bold px-2 py-0.5 rounded border border-emerald-500/20">✓ Received</span>
                          )}
                        </div>
                        <p className="text-[#7C8AA8] mt-1">SOP: includes up to <strong>{ret.postsIncluded} monthly posts</strong> &middot; Next Billing: <strong>{ret.nextInvoice}</strong></p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0 self-end sm:self-auto">
                        <div className="text-right">
                          <span className="text-emerald-400 font-bold font-mono text-sm block">${ret.amount.toLocaleString()}/mo</span>
                          <span className={`text-[10px] uppercase font-bold ${isUnpaid ? 'text-rose-400 animate-pulse' : 'text-emerald-400'}`}>{ret.status}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          {isUnpaid ? (
                            <button onClick={() => {
                              setRetainers(prev => prev.map(x => x.id === ret.id ? { ...x, status: 'Active' } : x));
                              triggerNotification('Retainer Paid', `Successfully marked retainer for ${ret.brand} as Paid!`, 'success');
                              onAddActivityLog('Sarah Jenkins', 'director', `Retainer payment recorded for ${ret.brand}`);
                            }} className="bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/20 text-emerald-400 px-2.5 py-1.5 rounded-lg font-bold text-[11px]" title="Mark payment as received">
                              Mark Paid
                            </button>
                          ) : (
                            <button onClick={() => {
                              setRetainers(prev => prev.map(x => x.id === ret.id ? { ...x, status: 'Unpaid (Overdue)' } : x));
                              triggerNotification('Retainer Flagged', `Marked retainer for ${ret.brand} as outstanding/unpaid.`, 'warning');
                              onAddActivityLog('Sarah Jenkins', 'director', `Flagged retainer payment default for ${ret.brand}`);
                            }} className="bg-rose-950/60 hover:bg-rose-900/60 border border-rose-500/20 text-rose-400 px-2.5 py-1.5 rounded-lg font-bold text-[11px]" title="Flag payment overdue">
                              Mark Unpaid
                            </button>
                          )}
                          
                          {isUnpaid && (
                            <button onClick={() => {
                              triggerNotification('Arrears Notice Dispatched', `Sent payment overdue invoice warning to ${ret.brand} billing office.`, 'warning');
                              onAddActivityLog('Sarah Jenkins', 'director', `Dispatched outstanding payment notice to retainer client: ${ret.brand}`);
                            }} className="bg-amber-950/70 hover:bg-amber-900/70 text-amber-300 border border-amber-500/20 px-2.5 py-1.5 rounded-lg text-[11px] font-semibold">
                              Notify Arrears
                            </button>
                          )}

                          <button onClick={() => { triggerNotification('Invoice Sent', `Dispatched monthly retainer invoice to ${ret.brand}`, 'success'); onAddActivityLog('Sarah Jenkins', 'director', `Auto-generated retainer invoice for ${ret.brand} (${ret.amount})`); }} className="bg-[#16243F] hover:bg-[#1e345c] text-white px-2.5 py-1.5 rounded-lg font-semibold transition-colors text-[11px]">Send Invoice</button>
                          
                          <button onClick={() => {
                            setRetainers(prev => prev.filter(x => x.id !== ret.id));
                            triggerNotification('Retainer Terminated', `Ended retainer contract with ${ret.brand}`, 'warning');
                            onAddActivityLog('Sarah Jenkins', 'director', `Cancelled retainer contract with ${ret.brand}`);
                          }} className="p-1.5 bg-rose-950/30 hover:bg-rose-900/30 text-rose-400 border border-rose-500/10 rounded-lg" title="Delete Retainer">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
                {retainers.length === 0 && (
                  <p className="text-xs text-slate-500 italic text-center py-4">No retainer contracts established.</p>
                )}
              </div>
            </div>
          </div>
        );

      // --- RATE HISTORIES ---
      case 'rate-history':
        return (
          <div className="space-y-6">
            {/* Director Rate Card Brand Visibility Master Control */}
            {isDirector && (
              <div className="bg-[#111E33] border-2 border-[#C9A46A]/40 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-mono font-bold bg-[#C9A46A] text-[#0A1220] px-2.5 py-0.5 rounded-full">
                      Director Policy
                    </span>
                    <h3 className="font-serif font-semibold text-base text-white">Brand Rate Card Visibility Control</h3>
                  </div>
                  <p className="text-xs text-[#7C8AA8] leading-relaxed">
                    Choose whether prospective brand sponsors can view exact creator rate card figures on public media kits, or if rates remain masked as <em>"Custom Negotiated Rates"</em> to prevent talent from being pigeonholed into fixed price ceilings.
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0 bg-[#0D1830] p-2.5 rounded-xl border border-white/10">
                  <div className="text-right">
                    <span className="text-[11px] font-bold block text-white">
                      {showRatesToBrands ? 'Rates Visible to Brands' : 'Rates Masked (Flexible Scope)'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {showRatesToBrands ? 'Showing exact dollar rates' : 'Hiding numbers on media kit'}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      const nextVal = !showRatesToBrands;
                      setShowRatesToBrands(nextVal);
                      localStorage.setItem('wl_show_rates_to_brands', String(nextVal));
                      // Dispatch storage event so MediaKit components update instantly
                      window.dispatchEvent(new Event('storage'));
                      triggerNotification(
                        'Visibility Policy Updated',
                        nextVal ? 'Exact deliverable rates are now visible to brand viewers on Media Kits.' : 'Deliverable rates are now masked with flexible scope on Media Kits.',
                        'success'
                      );
                      onAddActivityLog(
                        currentUser?.name || 'User',
                        currentRole || 'none',
                        `Toggled brand rate visibility to ${nextVal ? 'VISIBLE' : 'MASKED (FLEXIBLE)'}`
                      );
                    }}
                    className={`w-14 h-7 rounded-full transition-colors relative cursor-pointer p-1 ${
                      showRatesToBrands ? 'bg-[#C9A46A]' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        showRatesToBrands ? 'translate-x-7' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            )}

            {/* Top statistics cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-fade-in">
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase">Average TikTok base</span>
                <p className="text-xl font-bold text-[#C9A46A]">$3,200 <span className="text-xs text-emerald-400">(+28% YoY)</span></p>
              </div>
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase">Average IG Reel</span>
                <p className="text-xl font-bold text-[#C9A46A]">$2,400 <span className="text-xs text-emerald-400">(+33% YoY)</span></p>
              </div>
              <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl space-y-1">
                <span className="text-[10px] text-[#7C8AA8] uppercase">Average YouTube dedication</span>
                <p className="text-xl font-bold text-[#C9A46A]">$8,000 <span className="text-xs text-emerald-400">(+14% YoY)</span></p>
              </div>
            </div>

            {/* Log Rate Change Form - ONLY DIRECTOR */}
            {isDirector ? (
              <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3">
                  <div>
                    <h3 className="font-serif font-semibold text-base text-[#C9A46A]">Log Talent Rate Card Adjustment</h3>
                    <p className="text-xs text-[#7C8AA8]">Officially document verified increases or changes in individual baseline deliverable values across one or multiple platforms.</p>
                  </div>
                  <div className="flex items-center gap-2 bg-[#111E33] p-1.5 rounded-xl border border-white/10 shrink-0">
                    <button
                      type="button"
                      onClick={() => setRateIsMultiPlatform(false)}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        !rateIsMultiPlatform ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow' : 'text-[#7C8AA8] hover:text-white'
                      }`}
                    >
                      Single Platform
                    </button>
                    <button
                      type="button"
                      onClick={() => setRateIsMultiPlatform(true)}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        rateIsMultiPlatform ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow' : 'text-[#7C8AA8] hover:text-white'
                      }`}
                    >
                      Multi-Platform Bundle
                    </button>
                  </div>
                </div>

                <form onSubmit={(e) => {
                  e.preventDefault();
                  if (!rateHandle) {
                    triggerNotification('Creator Missing', 'Please select a creator handle.', 'danger');
                    return;
                  }

                  if (rateIsMultiPlatform) {
                    const activeEntries = (Object.entries(multiPlatformRates) as [string, { oldRate: string; newRate: string; enabled: boolean }][]).filter(([_, val]) => val.enabled);
                    if (activeEntries.length === 0) {
                      triggerNotification('No Platforms Enabled', 'Please select at least one platform to update.', 'danger');
                      return;
                    }

                    const newAdjustments: any[] = [];
                    const savedCustomRates = JSON.parse(localStorage.getItem('wl_custom_ratecards') || '{}');
                    if (!savedCustomRates[rateHandle]) savedCustomRates[rateHandle] = {};

                    activeEntries.forEach(([plat, val], idx) => {
                      const oldVal = val.oldRate.startsWith('$') ? val.oldRate : `$${val.oldRate}`;
                      const newVal = val.newRate.startsWith('$') ? val.newRate : `$${val.newRate}`;
                      
                      newAdjustments.push({
                        id: `rh_${Date.now()}_${idx}`,
                        handle: rateHandle,
                        type: plat,
                        oldRate: oldVal,
                        newRate: newVal,
                        date: new Date().toISOString().split('T')[0],
                        agent: rateAgent,
                        reason: rateReason || 'Multi-platform package rate update'
                      });

                      // Sync to media kit rate card storage
                      savedCustomRates[rateHandle][plat] = newVal;
                    });

                    localStorage.setItem('wl_custom_ratecards', JSON.stringify(savedCustomRates));
                    setRateHistory(prev => [...newAdjustments, ...prev]);
                    triggerNotification('Multi-Platform Rates Logged', `Logged ${activeEntries.length} platform rate updates for ${rateHandle}. Media kit updated automatically.`, 'success');
                    onAddActivityLog('Sarah Jenkins', 'director', `Logged multi-platform rate update for ${rateHandle} (${activeEntries.length} platforms)`);
                    setRateReason('');
                  } else {
                    if (!rateOld || !rateNew) {
                      triggerNotification('Fields Missing', 'Please fill in old rate and new rate.', 'danger');
                      return;
                    }
                    const oldVal = rateOld.startsWith('$') ? rateOld : `$${rateOld}`;
                    const newVal = rateNew.startsWith('$') ? rateNew : `$${rateNew}`;
                    const newAdjustment = {
                      id: 'rh_' + Date.now(),
                      handle: rateHandle,
                      type: rateType,
                      oldRate: oldVal,
                      newRate: newVal,
                      date: new Date().toISOString().split('T')[0],
                      agent: rateAgent,
                      reason: rateReason || 'Market demand adjustment'
                    };

                    // Sync to media kit rate card storage
                    const savedCustomRates = JSON.parse(localStorage.getItem('wl_custom_ratecards') || '{}');
                    if (!savedCustomRates[rateHandle]) savedCustomRates[rateHandle] = {};
                    savedCustomRates[rateHandle][rateType] = newVal;
                    localStorage.setItem('wl_custom_ratecards', JSON.stringify(savedCustomRates));

                    setRateHistory(prev => [newAdjustment, ...prev]);
                    triggerNotification('Rate Logged', `Successfully logged rate adjustment for ${rateHandle} (${rateType}). Media kit updated automatically.`, 'success');
                    onAddActivityLog('Sarah Jenkins', 'director', `Logged rate change for ${rateHandle} [${rateType}]: ${oldVal} -> ${newVal}`);
                    setRateOld('');
                    setRateNew('');
                    setRateReason('');
                  }
                }} className="space-y-4 text-xs">
                  {/* Common Details: Creator & Agent & Reason */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="text-[#7C8AA8]">Select Creator</label>
                      <select
                        value={rateHandle}
                        onChange={(e) => setRateHandle(e.target.value)}
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                        required
                      >
                        <option value="">-- Choose Creator --</option>
                        {creators.map(c => (
                          <option key={c.id} value={c.handle}>{c.handle} ({c.name})</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[#7C8AA8]">Direct Coordinator / Agent</label>
                      <input
                        type="text"
                        value={rateAgent}
                        onChange={(e) => setRateAgent(e.target.value)}
                        placeholder="e.g. Marcus Cole"
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[#7C8AA8]">Adjustment Justification / Reason</label>
                      <input
                        type="text"
                        value={rateReason}
                        onChange={(e) => setRateReason(e.target.value)}
                        placeholder="e.g. Follower milestone or high viral conversion"
                        className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                      />
                    </div>
                  </div>

                  {/* Mode 1: Single Platform */}
                  {!rateIsMultiPlatform && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-3.5 bg-[#111E33]/60 rounded-xl border border-white/5">
                      <div className="space-y-1">
                        <label className="text-[#7C8AA8]">Content Type / Platform</label>
                        <select
                          value={rateType}
                          onChange={(e) => setRateType(e.target.value)}
                          className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                        >
                          <option value="TikTok Video">TikTok Video</option>
                          <option value="Instagram Reel">Instagram Reel</option>
                          <option value="YouTube Video">YouTube Dedicated Video</option>
                          <option value="TikTok Live integration">TikTok Live Integration</option>
                          <option value="UGC Deliverable">UGC Deliverable / Whitelist</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[#7C8AA8]">Prior Rate</label>
                        <input
                          type="text"
                          value={rateOld}
                          onChange={(e) => setRateOld(e.target.value)}
                          placeholder="e.g. $1,200"
                          className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                          required
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[#7C8AA8]">New Rate Card</label>
                        <input
                          type="text"
                          value={rateNew}
                          onChange={(e) => setRateNew(e.target.value)}
                          placeholder="e.g. $1,500"
                          className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-white"
                          required
                        />
                      </div>
                    </div>
                  )}

                  {/* Mode 2: Multi-Platform Simultaneous Logging */}
                  {rateIsMultiPlatform && (
                    <div className="space-y-3 p-4 bg-[#111E33]/60 rounded-xl border border-white/5">
                      <div className="flex items-center justify-between pb-2 border-b border-white/5">
                        <span className="font-semibold text-white">Log Multiple Platforms Simultaneously</span>
                        <span className="text-[11px] text-[#C9A46A] font-mono">Syncs directly into talent's Media Kit</span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {(Object.entries(multiPlatformRates) as [string, { oldRate: string; newRate: string; enabled: boolean }][]).map(([platformName, data]) => (
                          <div key={platformName} className={`p-3 rounded-xl border transition-all ${data.enabled ? 'bg-[#0D1830] border-[#C9A46A]/40' : 'bg-[#0A1220] border-white/5 opacity-60'}`}>
                            <div className="flex items-center justify-between mb-2">
                              <label className="flex items-center gap-2 cursor-pointer font-bold text-white">
                                <input
                                  type="checkbox"
                                  checked={data.enabled}
                                  onChange={(e) => {
                                    const checked = e.target.checked;
                                    setMultiPlatformRates(prev => ({
                                      ...prev,
                                      [platformName]: { ...prev[platformName], enabled: checked }
                                    }));
                                  }}
                                  className="accent-[#C9A46A] w-4 h-4 rounded"
                                />
                                <span>{platformName}</span>
                              </label>
                              <span className="text-[10px] font-mono text-[#7C8AA8]">{data.enabled ? 'Active' : 'Skipped'}</span>
                            </div>

                            {data.enabled && (
                              <div className="grid grid-cols-2 gap-2 pt-1">
                                <div>
                                  <label className="text-[10px] text-[#7C8AA8] block">Old Rate</label>
                                  <input
                                    type="text"
                                    value={data.oldRate}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      setMultiPlatformRates(prev => ({
                                        ...prev,
                                        [platformName]: { ...prev[platformName], oldRate: val }
                                      }));
                                    }}
                                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-white font-mono text-xs"
                                    placeholder="$1,000"
                                  />
                                </div>
                                <div>
                                  <label className="text-[10px] text-[#7C8AA8] block">New Rate</label>
                                  <input
                                    type="text"
                                    value={data.newRate}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      setMultiPlatformRates(prev => ({
                                        ...prev,
                                        [platformName]: { ...prev[platformName], newRate: val }
                                      }));
                                    }}
                                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-emerald-400 font-mono font-bold text-xs"
                                    placeholder="$1,500"
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end pt-1">
                    <button type="submit" className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      <span>{rateIsMultiPlatform ? 'Log Multi-Platform Bundle & Sync Media Kit' : 'Log Adjustment & Sync Media Kit'}</span>
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              <div className="p-8 bg-[#0D1830] border border-white/5 rounded-2xl text-center space-y-2">
                <Shield className="w-8 h-8 text-[#C9A46A] mx-auto" />
                <h4 className="font-serif font-semibold text-white text-sm">Director Clearance Required</h4>
                <p className="text-xs text-[#7C8AA8] max-w-md mx-auto">
                  Modifying creator base deliverable pricing, rate cards, and compensation histories is strictly restricted to the Agency Director.
                </p>
              </div>
            )}

            {/* Rate Adjustment Journal - ONLY DIRECTOR */}
            {isDirector && (
              <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
                <h3 className="font-serif font-semibold text-base text-white border-b border-white/5 pb-2">Logged Rate Change Journal</h3>
                <div className="space-y-3.5">
                  {rateHistory.map(hist => (
                    <div key={hist.id} className="p-4 bg-[#111E33] border border-white/5 rounded-xl flex justify-between items-center text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-[#C9A46A] text-sm">{hist.handle}</span>
                          <span className="text-[10px] text-slate-500 bg-[#16243F] border border-white/5 px-2 py-0.5 rounded font-mono">{hist.type}</span>
                        </div>
                        <p className="text-slate-300 mt-1.5 font-sans">
                          Reason: <span className="italic text-slate-400">"{hist.reason}"</span>
                        </p>
                        <p className="text-[10px] text-[#7C8AA8] mt-1">Logged: <strong>{hist.date}</strong> &middot; Coordinated by: <strong>{hist.agent}</strong></p>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <div>
                          <span className="text-[#7C8AA8] line-through font-mono block">{hist.oldRate}</span>
                          <span className="text-emerald-400 font-bold font-mono text-sm block">→ {hist.newRate}</span>
                        </div>
                        <button onClick={() => {
                          setRateHistory(prev => prev.filter(x => x.id !== hist.id));
                          triggerNotification('Record Removed', 'Rate adjustment history log deleted.', 'warning');
                        }} className="p-1.5 bg-rose-950/30 hover:bg-rose-900/30 text-rose-400 border border-rose-500/10 rounded-lg cursor-pointer" title="Delete Log Record">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                  {rateHistory.length === 0 && (
                    <p className="text-xs text-slate-500 italic text-center py-4">No historical rate adjustments on file.</p>
                  )}
                </div>
              </div>
            )}

            {/* Request Roster Audits - ONLY DIRECTOR */}
            {isDirector && (
              <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                  <div>
                    <h3 className="font-serif font-semibold text-base text-white">Quick Roster Rate Check &amp; Audit Dispatch</h3>
                    <p className="text-xs text-[#7C8AA8]">Request pricing evaluations that route directly to the assigned talent agent manager.</p>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/20">
                    Agent Dispatch Active
                  </span>
                </div>
                <div className="space-y-3 text-xs">
                  {creators.map(cr => (
                    <div key={cr.id} className="p-3 bg-[#111E33] border border-white/5 rounded-xl flex justify-between items-center">
                      <div>
                        <span className="font-bold text-white block">{cr.name}</span>
                        <span className="text-slate-500 font-mono text-[10px]">{cr.handle} &middot; {cr.platform}</span>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <span className="text-emerald-400 font-bold font-mono">$2,500 - $5,000 base</span>
                        <button
                          onClick={() => {
                            triggerNotification('Rate Audit Dispatched', `Audit checklist for ${cr.handle} routed to assigned Talent Manager (Marcus Cole) and logged in Audit Operations Desk.`, 'info');
                            onAddActivityLog('Sarah Jenkins', 'director', `Dispatched talent rate card audit for ${cr.handle} to agent Marcus Cole`);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-[#C9A46A]/20 hover:bg-[#C9A46A]/30 text-[#C9A46A] border border-[#C9A46A]/40 font-semibold font-mono text-[11px] transition-colors cursor-pointer"
                        >
                          Request Audit →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );

      // --- CASTING CALLS ---
      case 'casting':
        return (
          <div className="space-y-6">
            {/* Creative Campaign Brief Builder & Dispatcher */}
            <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 border-b border-white/5 pb-2.5">
                <Sparkles className="w-4 h-4 text-[#C9A46A]" />
                <h3 className="font-serif font-semibold text-base text-white">Creative Campaign Brief Builder &amp; Dispatcher</h3>
              </div>
              <form onSubmit={async (e) => {
                e.preventDefault();
                if (!briefCreatorHandle) {
                  triggerNotification('Selection Required', 'Please select a creator from your roster to dispatch the campaign brief.', 'warning');
                  return;
                }
                if (!briefTitle.trim() || !briefContent.trim()) {
                  triggerNotification('Fields Required', 'Please enter a brief title and content guidelines.', 'warning');
                  return;
                }

                // Check brand blacklist before dispatching campaign brief
                const blCheck = await checkBrandBlacklist(briefBrandName.trim(), currentUser?.tenantId || activeTenantId);
                if (blCheck.isBlacklisted) {
                  triggerNotification(
                    'Campaign Brief Blocked',
                    `Brand '${blCheck.matchedBrand || briefBrandName}' is on the Global Blacklist (${blCheck.reason}). Brief dispatch is prohibited.`,
                    'danger'
                  );
                  return;
                }

                const briefId = 'brief_' + Date.now();
                const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
                const newBrief = {
                  id: briefId,
                  brand: briefBrandName,
                  title: briefTitle,
                  creatorHandle: briefCreatorHandle,
                  briefContent: briefContent,
                  deliverables: briefDeliverables,
                  keyHooks: briefHooks.split('\n').map(h => h.trim()).filter(h => h !== ''),
                  sentAt: new Date().toISOString(),
                  status: 'Sent',
                  payout: briefPayout,
                  tenantId: userPod,
                  subagency: userPod,
                  pod: userPod
                };

                try {
                  await setDoc(doc(db, 'studio-briefs', briefId), newBrief);
                  try {
                    const existing = safeStorage.getItem('wl_creator_briefs');
                    const list = existing ? JSON.parse(existing) : [];
                    const formattedLocalBrief = {
                      id: briefId,
                      creatorHandle: briefCreatorHandle,
                      brandName: briefBrandName,
                      campaignGoals: briefContent,
                      deliverables: briefDeliverables,
                      requiredHooks: briefHooks,
                      passedBy: currentUser?.name || 'Agency Management',
                      senderRole: currentRole || 'Director',
                      sentAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                      status: 'Passed to Creator (Pending Acceptance)',
                      payout: briefPayout
                    };
                    safeStorage.setItem('wl_creator_briefs', JSON.stringify([formattedLocalBrief, ...list]));
                  } catch (e) {
                    console.warn("safeStorage error for wl_creator_briefs:", e);
                  }

                  triggerNotification('✓ Brief Dispatched', `Creative brief sent successfully to ${briefCreatorHandle}.`, 'success');
                  if (onAddActivityLog) {
                    onAddActivityLog(currentUser?.name || 'Sarah Jenkins', currentRole || 'none', `Dispatched brief "${briefTitle}" to ${briefCreatorHandle}`);
                  }
                  setBriefTitle('Summer Botanical Serum UGC Brief');
                  setBriefContent('Create a high-energy 15-30 second TikTok/Reel demonstrating the Summer Botanical Serum application. Focus on natural sunlight skin glow and cold-pressed botanical extract benefits.');
                } catch (err) {
                  console.error("Failed to write brief to Firestore:", err);
                  triggerNotification('Sync Error', 'Failed to dispatch brief to Firestore.', 'danger');
                }
              }} className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                
                {/* Creator Selector Dropdown */}
                <div className="space-y-1 md:col-span-2">
                  <label className="text-[#7C8AA8] font-mono font-bold uppercase tracking-wider block">Select Roster Creator to Receive Brief</label>
                  <select 
                    value={briefCreatorHandle} 
                    onChange={e => setBriefCreatorHandle(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white font-mono focus:border-[#C9A46A] outline-none"
                  >
                    <option value="">-- Choose Roster Creator (Dropdown) --</option>
                    {(creators || []).map(c => (
                      <option key={c.id} value={c.handle}>
                        {c.name || 'Unnamed Creator'} ({c.handle || '@unnamed'}) - {c.niche || 'General'}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Campaign Brand & Title */}
                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-mono font-bold uppercase tracking-wider block">Campaign Sponsor Brand</label>
                  <input 
                    type="text" 
                    value={briefBrandName} 
                    onChange={e => setBriefBrandName(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C9A46A] outline-none font-mono"
                    placeholder="e.g. Bloom Botanical Skincare"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-mono font-bold uppercase tracking-wider block">Brief Title</label>
                  <input 
                    type="text" 
                    value={briefTitle} 
                    onChange={e => setBriefTitle(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C9A46A] outline-none font-mono"
                    placeholder="e.g. Summer Botanical Serum UGC Brief"
                  />
                </div>

                {/* Deliverables & Payout Offer */}
                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-mono font-bold uppercase tracking-wider block">Deliverables Requirements</label>
                  <input 
                    type="text" 
                    value={briefDeliverables} 
                    onChange={e => setBriefDeliverables(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C9A46A] outline-none font-mono"
                    placeholder="e.g. 1x 9:16 Short-Form Video + Paid Usage Rights"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-mono font-bold uppercase tracking-wider block">Sponsor Budget / Payout Offer</label>
                  <input 
                    type="text" 
                    value={briefPayout} 
                    onChange={e => setBriefPayout(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C9A46A] outline-none font-mono"
                    placeholder="e.g. $3,500 Escrow Payout"
                  />
                </div>

                {/* Content Guidelines Textarea */}
                <div className="space-y-1 md:col-span-2">
                  <label className="text-[#7C8AA8] font-mono font-bold uppercase tracking-wider block">Brief Script &amp; Concept Guidelines</label>
                  <textarea 
                    value={briefContent} 
                    onChange={e => setBriefContent(e.target.value)}
                    rows={3}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C9A46A] outline-none font-sans"
                    placeholder="Describe specific filming goals, hooks, wardrobe, background requirements, and verbal talking points..."
                  />
                </div>

                {/* Key Hook Phrases Textarea */}
                <div className="space-y-1 md:col-span-2">
                  <label className="text-[#7C8AA8] font-mono font-bold uppercase tracking-wider block">Recommended Hook Lines (One Per Line)</label>
                  <textarea 
                    value={briefHooks} 
                    onChange={e => setBriefHooks(e.target.value)}
                    rows={2}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C9A46A] outline-none font-mono"
                    placeholder="Enter recommended hook phrases, each on a new line..."
                  />
                </div>

                {/* Submit button */}
                <div className="md:col-span-2 pt-2 flex justify-end">
                  <button 
                    type="submit"
                    className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2 rounded-xl text-xs font-bold transition-colors shadow-lg cursor-pointer flex items-center gap-1.5"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Generate &amp; Dispatch Creative Brief</span>
                  </button>
                </div>
              </form>
            </div>

            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-5">
              <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                <h3 className="font-serif font-semibold text-lg text-white">Active Campaign Casting Calls</h3>
                <button onClick={() => {
                  const title = prompt("Casting brief title:") || "Winter Solstice Lookbook";
                  const bud = parseInt(prompt("Budget ($):") || "5000") || 5000;
                  setCastingCalls(prev => [...prev, { id: 'cc_' + Date.now(), campaign: title, budget: bud, slots: 2, platform: 'TikTok', desc: 'Outfits compilation reels.', applications: [] }]);
                  triggerNotification('Casting Published', `Casting Call published: ${title}`, 'success');
                  onAddActivityLog('Sarah Jenkins', 'director', `Created open casting brief: ${title}`);
                }} className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors">
                  <Plus className="w-3.5 h-3.5" /> Launch Casting Call
                </button>
              </div>
              <div className="space-y-4">
                {castingCalls.map(cc => (
                  <div key={cc.id} className="p-4 bg-[#111E33] border border-white/5 rounded-xl space-y-3 text-xs">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-white text-sm">{cc.campaign}</h4>
                        <span className="text-[10px] text-[#7C8AA8] uppercase font-bold">{cc.platform} Brief</span>
                      </div>
                      <div className="text-right">
                        <span className="text-emerald-400 font-bold font-mono block">${cc.budget.toLocaleString()}</span>
                        <span className="text-[10px] text-[#7C8AA8]">{cc.slots} slots available</span>
                      </div>
                    </div>
                    <p className="text-[#7C8AA8]">{cc.desc}</p>
                    <div className="space-y-2 border-t border-white/5 pt-2">
                      <span className="text-[10px] uppercase text-[#7C8AA8] font-bold block">Creator Applications:</span>
                      {cc.applications.filter(app => !isRestrictedRole || myHandles.includes(app.handle.toLowerCase())).map(app => (
                        <div key={app.id} className="flex justify-between items-center py-1 font-mono text-[11px]">
                          <span>{app.handle} ({app.followers})</span>
                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${app.status === 'Approved' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-400'}`}>{app.status}</span>
                            {app.status === 'Applied' && (
                              <button onClick={() => {
                                setCastingCalls(prev => prev.map(x => x.id === cc.id ? { ...x, applications: x.applications.map(y => y.id === app.id ? { ...y, status: 'Approved' } : y) } : x));
                                triggerNotification('Creator Casted', `Approved ${app.handle} for casting.`, 'success');
                                onAddActivityLog('Sarah Jenkins', 'director', `Approved ${app.handle} for ${cc.campaign}`);
                              }} className="text-xs text-[#C9A46A] hover:underline font-semibold font-sans">Cast Creator</button>
                            )}
                          </div>
                        </div>
                      ))}
                      {cc.applications.filter(app => !isRestrictedRole || myHandles.includes(app.handle.toLowerCase())).length === 0 && <p className="text-[10px] text-slate-500 italic">No applications received yet.</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      // --- FINANCIAL GROSS REVENUE & MANUAL LEDGER ---
      case 'revenue': {
        const isCreator = currentRole === 'creator';
        const handle = currentUser?.handle || '@alexjones';

        const myLedgerItems = isCreator
          ? payoutLedger.filter(item =>
              item.creator.toLowerCase() === handle.toLowerCase() ||
              item.creatorName.toLowerCase() === (currentUser?.name || '').toLowerCase() ||
              item.creator === '@alexjones' // fallback sample so creator always sees ledger entries
            )
          : payoutLedger;

        const handleMarkPaymentSent = async (id: string) => {
          const today = new Date().toISOString().split('T')[0];
          const targetItem = payoutLedger.find(x => x.id === id);
          if (!targetItem) return;

          // Optimistic local update
          setPayoutLedger(prev =>
            prev.map(x => (x.id === id ? { ...x, status: 'Paid', datePaid: today } : x))
          );
          
          try {
            const authHeaders = await getAuthHeaders();
            const res = await fetch('/api/ledger-transactions', {
              method: 'POST',
              headers: { 
                'Content-Type': 'application/json',
                ...authHeaders 
              },
              body: JSON.stringify({
                transactionId: targetItem.id,
                brand: targetItem.brand,
                creator: targetItem.creator,
                creatorName: targetItem.creatorName,
                type: targetItem.payoutMethod === 'Stripe Escrow Pre-Fund' ? 'Escrow Deposit' : 'Milestone Release',
                grossAmount: targetItem.amount,
                agencyCut: targetItem.amount * 0.2, // Default 20% split
                creatorPayout: targetItem.amount * 0.8,
                status: 'Settled / Paid',
                milestone: targetItem.dealTitle
              })
            });
            
            if (!res.ok) {
              const errData = await res.json();
              throw new Error(errData.error || 'Failed to sync payment status with server.');
            }

            triggerNotification('Payment Sent', 'Ledger item marked as paid out and synced to shared backend.', 'success');
          } catch (err: any) {
            console.error('Ledger Sync Error:', err);
            triggerNotification('Sync Error', err.message || 'Payment marked locally but failed to sync to server.', 'warning');
          }
          
          const whoMarked = currentUser?.name || 'Sarah Jenkins';
          const whoRole = currentRole || 'none';
          onAddActivityLog(whoMarked, whoRole, `Marked manual payout ledger item ${id} as sent (${today})`);

          // Payment Audit: Log to studio-activity-log with creator, amount, method, date, and who marked it
          const matchingCreator = creators.find(c =>
            c.handle.toLowerCase() === targetItem.creator.toLowerCase() ||
            c.name.toLowerCase() === (targetItem.creatorName || '').toLowerCase()
          );
          const method = matchingCreator?.paymentMethod || 'PayPal';

          try {
            const logRef = collection(db, 'studio-activity-log');
            const q = query(logRef, where('ledgerItemId', '==', id));
            const snap = await getDocs(q);
            const alreadyLogged = !snap.empty && snap.docs.some(d => d.data().action === 'Payment Sent');

            if (!alreadyLogged) {
              await addDoc(logRef, {
                action: 'Payment Sent',
                ledgerItemId: id,
                creator: targetItem.creatorName || targetItem.creator || '',
                creatorHandle: targetItem.creator || '',
                amount: targetItem.amount || 0,
                method: method,
                date: today,
                whoMarked: whoMarked,
                markedByRole: whoRole,
                senderUid: currentUser?.id || 'director_staff',
                role: whoRole,
                timestamp: new Date().toISOString(),
                subagency: 'pod_main'
              });
              console.log('[Payment Audit] Logged payment event to studio-activity-log for item:', id);
            } else {
              console.log('[Payment Audit] Payment event already logged in studio-activity-log, skipping duplicate for item:', id);
            }
          } catch (err) {
            console.error('[Payment Audit] Error checking or writing to studio-activity-log:', err);
          }
        };

        const isDirectorOrOwner = ['director', 'agency'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;

        const handleDeleteLedgerItem = (id: string) => {
          if (!isDirectorOrOwner) {
            triggerNotification('Access Denied', 'Deleting financial ledger records requires Director or Platform Owner permissions.', 'warning');
            return;
          }
          const item = payoutLedger.find(x => x.id === id);
          setDeleteConfirmConfig({
            isOpen: true,
            title: 'Delete Payout Ledger Record',
            itemName: `${item?.dealTitle || 'Ledger Entry'} (${item?.creatorName || item?.creator || 'Creator'}) - $${item?.amount?.toLocaleString() || '0'}`,
            itemType: 'payout ledger entry',
            isPermanent: true,
            message: `Are you sure you want to permanently remove this payout ledger record?`,
            confirmButtonText: 'Delete Record',
            confirmButtonVariant: 'danger',
            onConfirm: async () => {
              // Optimistic update
              setPayoutLedger(prev => prev.filter(x => x.id !== id));
              
              try {
                const authHeaders = await getAuthHeaders();
                const res = await fetch(`/api/ledger-transactions/${id}`, {
                  method: 'DELETE',
                  headers: { ...authHeaders }
                });
                if (!res.ok) throw new Error('Failed to delete from server.');
                
                triggerNotification('Ledger Record Deleted', 'Ledger record has been permanently removed from the shared backend.', 'success');
              } catch (err: any) {
                console.error('Ledger Delete Error:', err);
                triggerNotification('Delete Error', 'Record removed locally but failed to delete from server.', 'warning');
              }
              
              const who = currentUser?.name || 'Director';
              const role = currentRole || 'director';
              onAddActivityLog(who, role, `Deleted manual payout ledger record (${id})`);

              try {
                const logRef = collection(db, 'studio-activity-log');
                await addDoc(logRef, {
                  action: 'Financial Record Deleted',
                  ledgerItemId: id,
                  dealTitle: item?.dealTitle || '',
                  creator: item?.creatorName || item?.creator || '',
                  amount: item?.amount || 0,
                  whoDeleted: who,
                  role: role,
                  timestamp: new Date().toISOString(),
                  subagency: currentUser?.subagency || activeTenantId || 'pod_main',
                  tenantId: currentUser?.tenantId || 'bloom_studio_default'
                });
              } catch (auditErr) {
                console.warn('[Ledger Audit] Failed to record ledger delete in studio-activity-log:', auditErr);
              }
            }
          });
        };

        const handleClearAllLedger = () => {
          if (!isDirectorOrOwner) {
            triggerNotification('Access Denied', 'Clearing the master payout ledger requires Director or Platform Owner authority.', 'warning');
            return;
          }
          setDeleteConfirmConfig({
            isOpen: true,
            title: 'Clear Manual Payout Ledger',
            itemName: `${payoutLedger.length} Manual Payout Records`,
            itemType: 'payout ledger',
            isPermanent: true,
            message: `Are you sure you want to permanently clear all ${payoutLedger.length} manual earnings and payout records? This action cannot be undone.`,
            confirmButtonText: `Clear All ${payoutLedger.length} Records`,
            confirmButtonVariant: 'danger',
            onConfirm: async () => {
              const ids = payoutLedger.map(x => x.id);
              setPayoutLedger([]);
              
              try {
                const authHeaders = await getAuthHeaders();
                await Promise.all(ids.map(id => 
                  fetch(`/api/ledger-transactions/${id}`, { 
                    method: 'DELETE', 
                    headers: { ...authHeaders } 
                  })
                ));
                triggerNotification('Ledger Cleared', 'All manual payout ledger records have been cleared from shared backend.', 'success');
              } catch (err) {
                console.error('Clear Ledger Error:', err);
                triggerNotification('Clear Error', 'Local view cleared, but some records may remain on the server.', 'warning');
              }
              
              const who = currentUser?.name || 'Director';
              const role = currentRole || 'director';
              onAddActivityLog(who, role, `Cleared all ${ids.length} manual payout ledger records`);

              try {
                const logRef = collection(db, 'studio-activity-log');
                await addDoc(logRef, {
                  action: 'Master Financial Ledger Cleared',
                  deletedRecordCount: ids.length,
                  whoDeleted: who,
                  role: role,
                  timestamp: new Date().toISOString(),
                  subagency: currentUser?.subagency || activeTenantId || 'pod_main',
                  tenantId: currentUser?.tenantId || 'bloom_studio_default'
                });
              } catch (auditErr) {
                console.warn('[Ledger Audit] Failed to record ledger clear in studio-activity-log:', auditErr);
              }
            }
          });
        };

        const handleExport1099Csv = () => {
          const headers = [
            'Creator Name',
            'Handle',
            'Deal / Campaign',
            'Brand',
            'Amount ($)',
            'Status',
            'Date Paid',
            'Payment Method',
            'Payment Detail',
            'YTD Creator Paid Total ($)',
            '1099 Required ($600+ threshold)'
          ];

          const rows: string[] = [headers.map(sanitizeCsvCell).join(',')];
          const creatorsMap = new Map<string, { creatorObj?: Creator; items: any[]; ytdPaid: number }>();

          const targetCreators = isCreator
            ? creators.filter(c => c.handle.toLowerCase() === handle.toLowerCase() || c.name.toLowerCase() === (currentUser?.name || '').toLowerCase())
            : creators;

          targetCreators.forEach(c => {
            creatorsMap.set(c.handle.toLowerCase(), { creatorObj: c, items: [], ytdPaid: 0 });
          });

          myLedgerItems.forEach(item => {
            const key = (item.creator || '').toLowerCase();
            if (!creatorsMap.has(key)) {
              const foundC = creators.find(c => c.handle.toLowerCase() === key || c.name.toLowerCase() === (item.creatorName || '').toLowerCase());
              creatorsMap.set(key, { creatorObj: foundC, items: [], ytdPaid: 0 });
            }
            const entry = creatorsMap.get(key)!;
            entry.items.push(item);
            if (item.status === 'Paid') {
              entry.ytdPaid += (item.amount || 0);
            }
          });

          creatorsMap.forEach((val, handleKey) => {
            const cName = val.creatorObj?.name || handleKey;
            const cHandle = val.creatorObj?.handle || handleKey;
            const cMethod = val.creatorObj?.paymentMethod || 'PayPal';
            const cDetail = cMethod === 'Other' ? 'Contact agency directly' : (val.creatorObj?.paymentDetails || val.creatorObj?.email || 'Not provided');
            const ytd = val.ytdPaid;
            const req1099 = ytd >= 600 ? 'YES ($600+ Met)' : 'NO (<$600)';

            if (val.items.length === 0) {
              rows.push(formatCsvRow([
                cName,
                cHandle,
                'No recorded deals',
                '-',
                0,
                'None',
                '-',
                cMethod,
                cDetail,
                ytd,
                req1099
              ]));
            } else {
              val.items.forEach(item => {
                rows.push(formatCsvRow([
                  cName,
                  cHandle,
                  item.dealTitle || '',
                  item.brand || '',
                  item.amount || 0,
                  item.status || 'Pending',
                  item.datePaid || '-',
                  cMethod,
                  cDetail,
                  ytd,
                  req1099
                ]));
              });
              // Summary YTD total row per creator
              rows.push(formatCsvRow([
                `TOTAL YTD - ${cName}`,
                cHandle,
                'YTD PAID EARNINGS',
                '-',
                ytd,
                'SUMMARY',
                '-',
                cMethod,
                cDetail,
                ytd,
                req1099
              ]));
            }
          });

          const csvContent = "data:text/csv;charset=utf-8," + rows.join("\n");
          const encodedUri = encodeURI(csvContent);
          const link = document.createElement("a");
          link.setAttribute("href", encodedUri);
          link.setAttribute("download", `creator_earnings_1099_report_${new Date().toISOString().split('T')[0]}.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          triggerNotification('1099 CSV Exported', 'Downloaded per-creator earnings report with YTD totals ($600 threshold).', 'success');
          onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', 'Exported 1099 creator earnings CSV report');
        };

        return (
          <div className="space-y-6 animate-fade-in">
            {/* Full-Stack Financial Ledger Connected Banner */}
            <div className="bg-[#0D1830] border border-emerald-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5 text-emerald-400">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>
                  <strong className="text-white">Full-Stack Financial Ledger Connected:</strong> Powered by Express server API (<code className="text-emerald-400 font-mono text-[11px]">/api/ledger-transactions</code>) with Firestore + local offline fallback (no card billing required). Simulated SMS &amp; Email active while awaiting Twilio/SendGrid credentials.
                </span>
              </div>
              <span className="text-[10px] font-mono px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                FULL STACK ACTIVE
              </span>
            </div>

            {/* Stripe Connect Integration Point Notice Banner */}
            <div className="bg-[#111E33] border border-[#C9A46A]/30 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/40 text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold uppercase">
                    Stripe Connect — Integration Point
                  </span>
                  <span className="text-xs font-semibold text-white">Manual Agency Payout Ledger</span>
                </div>
                <p className="text-xs text-[#7C8AA8] leading-relaxed">
                  Earnings are currently tracked via a manual ledger. Future Stripe Connect integration will enable automatic escrow settlement and direct bank deposit routing. Do not wire live payment processing yet.
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs text-[#C9A46A] font-mono font-bold bg-[#16243F] px-3 py-1.5 rounded-xl border border-white/10">
                  Mode: Manual Settlement
                </span>
              </div>
            </div>

            {isCreator ? (
              <>
                <div className="border-b border-white/5 pb-3">
                  <h3 className="font-serif font-semibold text-lg text-white">Escrow Ledger</h3>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    Historical personal payouts and active escrow balances recorded by agency leadership.
                  </p>
                </div>

                {/* Creator Summary Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] text-[#7C8AA8] uppercase">Pending Payouts</span>
                    <div className="text-2xl font-bold text-[#C9A46A] mt-1">
                      ${myLedgerItems.filter(i => i.status === 'Pending').reduce((s, i) => s + i.amount, 0).toLocaleString()}
                    </div>
                    <span className="text-[9px] text-[#C9A46A]/80 block mt-1">Awaiting settlement from agency ledger</span>
                  </div>
                  <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] text-[#7C8AA8] uppercase">Cleared Payouts</span>
                    <div className="text-2xl font-bold text-emerald-400 mt-1">
                      ${myLedgerItems.filter(i => i.status === 'Paid').reduce((s, i) => s + i.amount, 0).toLocaleString()}
                    </div>
                    <span className="text-[9px] text-emerald-400/80 block mt-1">Settled and transferred campaign payouts</span>
                  </div>
                  <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] text-[#7C8AA8] uppercase">Total Net Earnings</span>
                    <div className="text-2xl font-bold text-sky-400 mt-1">
                      ${myLedgerItems.reduce((s, i) => s + i.amount, 0).toLocaleString()}
                    </div>
                    <span className="text-[9px] text-sky-400/80 block mt-1">Cumulative net earnings across deals</span>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Agency-Wide Revenue Metrics for Director / Staff */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] text-[#7C8AA8] uppercase">Total Gross Revenue</span>
                    <div className="text-2xl font-bold text-white mt-1">$135,400</div>
                  </div>
                  <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] text-[#7C8AA8] uppercase">Net Margin (20%)</span>
                    <div className="text-2xl font-bold text-emerald-400 mt-1">$27,080</div>
                  </div>
                  <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] text-[#7C8AA8] uppercase">Pending Escrow Ledger</span>
                    <div className="text-2xl font-bold text-[#C9A46A] mt-1">
                      ${payoutLedger.filter(i => i.status === 'Pending').reduce((s, i) => s + i.amount, 0).toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] text-[#7C8AA8] uppercase">Settled Payouts</span>
                    <div className="text-2xl font-bold text-sky-400 mt-1">
                      ${payoutLedger.filter(i => i.status === 'Paid').reduce((s, i) => s + i.amount, 0).toLocaleString()}
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Manual Payout Ledger Table */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white">Manual Earnings &amp; Payout Ledger</h3>
                  <p className="text-xs text-[#7C8AA8]">
                    {isCreator
                      ? 'Read-only manual ledger of your campaign earnings, amounts, settlement status, and payout dates.'
                      : 'Manage creator payouts manually. Mark payments as sent when bank or wire transfer has been completed.'}
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {isDirectorOrOwner && payoutLedger.length > 0 && (
                    <button
                      onClick={handleClearAllLedger}
                      className="bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-500/30 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Clear Ledger
                    </button>
                  )}
                  <button
                    onClick={handleExport1099Csv}
                    className="bg-[#111E33] hover:bg-[#16243F] text-slate-200 border border-[#C9A46A]/40 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm hover:border-[#C9A46A]"
                  >
                    <Download className="w-3.5 h-3.5 text-[#C9A46A]" />
                    Export 1099 CSV (YTD $600+)
                  </button>
                  {isDirectorOrOwner ? (
                    <span className="text-xs bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded-xl font-mono">
                      Director Controls Enabled
                    </span>
                  ) : !isCreator ? (
                    <span className="text-xs bg-blue-950/80 text-blue-400 border border-blue-500/30 px-3 py-1 rounded-xl font-mono">
                      Staff View (Audit Only)
                    </span>
                  ) : null}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-white/5 text-[#7C8AA8] uppercase font-mono tracking-wider bg-[#111E33]/40">
                      <th className="p-3">Deal / Campaign</th>
                      <th className="p-3">Brand</th>
                      {!isCreator && <th className="p-3">Creator</th>}
                      <th className="p-3">Amount</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Payout Method</th>
                      <th className="p-3">Date Paid</th>
                      {!isCreator && <th className="p-3 text-right">Action</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {myLedgerItems.map(item => {
                      const matchingCreator = creators.find(c => c.handle.toLowerCase() === item.creator.toLowerCase() || c.name.toLowerCase() === item.creatorName.toLowerCase());
                      const method = matchingCreator?.paymentMethod === 'Zelle' ? 'Agency Debit Card' : (matchingCreator?.paymentMethod || 'Agency Debit Card');
                      const detail = method === 'Agency Debit Card'
                        ? `Visa Debit •••• ${matchingCreator?.stripeCardLast4 || '4242'} (Stripe Instant)`
                        : method === 'Other'
                        ? 'Contact agency directly'
                        : (matchingCreator?.paymentDetails || matchingCreator?.email || 'Not provided');

                      return (
                      <tr key={item.id} className="hover:bg-[#111E33]/30">
                        <td className="p-3 font-semibold text-white">{item.dealTitle}</td>
                        <td className="p-3 text-slate-300">{item.brand}</td>
                        {!isCreator && (
                          <td className="p-3 text-slate-300">
                            {item.creatorName} <span className="text-[#7C8AA8] font-mono">({item.creator})</span>
                          </td>
                        )}
                        <td className="p-3 font-mono font-bold text-emerald-400">${item.amount.toLocaleString()}</td>
                        <td className="p-3">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-bold font-mono border ${
                              item.status === 'Paid'
                                ? 'bg-emerald-950/70 text-emerald-400 border-emerald-500/30'
                                : 'bg-amber-950/70 text-amber-400 border-amber-500/30'
                            }`}
                          >
                            {item.status}
                          </span>
                        </td>
                        <td className="p-3">
                          <div className="flex flex-col gap-0.5">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono border ${
                                method === 'Agency Debit Card' 
                                  ? 'bg-[#16243F] text-emerald-300 border-emerald-500/30' 
                                  : 'bg-[#16243F] text-[#C9A46A] border-[#C9A46A]/30'
                              }`}>
                                {method === 'Agency Debit Card' ? '⚡ Agency Debit Card (Stripe)' : method}
                              </span>
                              <span className={`text-[11px] font-mono ${item.status === 'Pending' ? 'text-amber-300 font-semibold' : 'text-slate-400'}`}>
                                {detail}
                              </span>
                            </div>
                            {matchingCreator?.paymentNote && (
                              <span className="text-[10px] text-[#7C8AA8] italic">
                                Note: {matchingCreator.paymentNote}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="p-3 font-mono text-slate-400">{item.datePaid}</td>
                        {!isCreator && (
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              {item.status === 'Pending' ? (
                                <button
                                  onClick={() => handleMarkPaymentSent(item.id)}
                                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer font-sans"
                                >
                                  Mark Payment as Sent
                                </button>
                              ) : (
                                <span className="text-emerald-400 text-xs font-semibold">
                                  ✔ Sent ({item.datePaid})
                                </span>
                              )}
                              {isDirectorOrOwner && (
                                <button
                                  onClick={() => handleDeleteLedgerItem(item.id)}
                                  className="text-slate-400 hover:text-rose-400 p-1.5 rounded-lg hover:bg-rose-950/40 transition-colors"
                                  title="Delete Ledger Record"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        )}
                      </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      }

      // --- AGENT MANAGER & TEAM WORKLOAD TERMINAL ---
      case 'agent-manager':
      case 'team-manager':
      case 'team-workload':
      case 'team-workloads':
      case 'workload':
        return (
          <div className="space-y-6 animate-fade-in">
            {/* Workload & Team Manager Unified Banner */}
            <div className="bg-[#111E33] border border-[#C9A46A]/30 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md">
              <div className="flex items-start sm:items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#C9A46A]/10 border border-[#C9A46A]/20 text-[#C9A46A] shrink-0">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                      ⚡ Unified Team Manager &amp; Workload Engine
                    </span>
                    <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                      Two-Way Synchronized
                    </span>
                  </div>
                  <p className="text-xs text-[#7C8AA8] mt-0.5 leading-relaxed">
                    Team Manager and Workloads are unified. Any creator assignment, deal distribution, or capacity change dynamically syncs across all agency staff desks.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-mono text-[#C9A46A] bg-[#0D1830] border border-[#C9A46A]/30 px-3 py-1.5 rounded-xl">
                  Active Staff: {agents.length} | Signed Talent: {creators.length}
                </span>
              </div>
            </div>

            {/* Live Workload Capacity Distribution Hub */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-[#C9A46A]" /> Team Workload &amp; Creator Roster Assignments
                  </h3>
                  <p className="text-xs text-[#7C8AA8] mt-0.5">
                    Real-time workload distribution per agent. Reassign talent with instant two-way synchronization across deal pipelines and calendars.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {agents.map((ag) => {
                  // Compute dynamic workload for this agent from creators list
                  const assignedTalent = creators.filter(c => 
                    (c.assignedAgent && c.assignedAgent.toLowerCase().includes(ag.name.toLowerCase())) ||
                    (c.assignedCoordinator && c.assignedCoordinator.toLowerCase().includes(ag.name.toLowerCase())) ||
                    (ag.signedCreatorHandle && c.handle.toLowerCase() === ag.signedCreatorHandle.toLowerCase())
                  );
                  const activeHeadcount = Math.max(assignedTalent.length, ag.headcount || 0);
                  const maxCapacity = 6;
                  const capacityPct = Math.min(100, Math.round((activeHeadcount / maxCapacity) * 100));

                  return (
                    <div key={`workload-${ag.id}`} className="bg-[#111E33] border border-white/10 rounded-xl p-4 space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-white text-sm">{ag.name}</h4>
                          <span className="text-[10px] font-mono text-[#C9A46A]">{ag.role}</span>
                        </div>
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                          capacityPct >= 90 ? 'bg-rose-950/60 text-rose-300 border-rose-500/30' :
                          capacityPct >= 60 ? 'bg-amber-950/60 text-amber-300 border-amber-500/30' :
                          'bg-emerald-950/60 text-emerald-300 border-emerald-500/30'
                        }`}>
                          {capacityPct}% Capacity
                        </span>
                      </div>

                      {/* Capacity Bar */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-[#7C8AA8]">
                          <span>Assigned Roster Load</span>
                          <span className="font-bold text-slate-200">{activeHeadcount} / {maxCapacity} Creators</span>
                        </div>
                        <div className="w-full bg-[#0D1830] h-2 rounded-full overflow-hidden border border-white/5">
                          <div
                            className={`h-full transition-all duration-500 ${
                              capacityPct >= 90 ? 'bg-rose-500' :
                              capacityPct >= 60 ? 'bg-amber-400' :
                              'bg-emerald-400'
                            }`}
                            style={{ width: `${capacityPct}%` }}
                          />
                        </div>
                      </div>

                      {/* Quick Assign Talent Dropdown */}
                      <div className="pt-2 border-t border-white/5 space-y-1.5">
                        <label className="text-[10px] text-[#7C8AA8] font-mono uppercase block">
                          + Assign Talent to {ag.name.split(' ')[0]}
                        </label>
                        <select
                          onChange={(e) => {
                            const creatorHandle = e.target.value;
                            if (!creatorHandle) return;
                            // Update creator in state
                            setCreators(prev => prev.map(c => 
                              c.handle === creatorHandle 
                                ? { ...c, assignedAgent: ag.name, assignedCoordinator: ag.role === 'Coordinator' ? ag.name : c.assignedCoordinator } 
                                : c
                            ));
                            // Update agent headcount in state
                            setAgents(prev => prev.map(a => 
                              a.id === ag.id ? { ...a, headcount: (a.headcount || 0) + 1 } : a
                            ));
                            triggerNotification('Workload Rebalanced', `Assigned ${creatorHandle} to ${ag.name}. Workloads synchronized.`, 'success');
                            onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Assigned creator ${creatorHandle} to agent ${ag.name} in Team Workload Manager`);
                            e.target.value = '';
                          }}
                          defaultValue=""
                          className="w-full bg-[#0D1830] border border-white/10 text-slate-300 text-xs rounded-lg p-2 font-mono focus:border-[#C9A46A] outline-none cursor-pointer"
                        >
                          <option value="">Select creator to wire/assign...</option>
                          {creators.map(c => (
                            <option key={c.id} value={c.handle}>
                              {c.handle} ({c.name})
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Currently Assigned Handles Pills */}
                      {assignedTalent.length > 0 && (
                        <div className="flex flex-wrap gap-1 pt-1">
                          {assignedTalent.map(c => (
                            <span key={c.id} className="text-[9.5px] font-mono bg-[#0D1830] text-[#C9A46A] border border-[#C9A46A]/20 px-2 py-0.5 rounded">
                              {c.handle}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Onboard New Agent Form */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5">
              <div className="border-b border-white/5 pb-3 flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-[#C9A46A]" />
                    <h3 className="font-serif font-semibold text-lg text-white">Add New Agency Coordinator / Agent Manager</h3>
                  </div>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    Onboard and register new agents to assign creator headcounts, deal splits, and commission allocations. Agent managers have operational agreements distinct from talent contracts.
                  </p>
                </div>
                <span className="text-[10px] font-mono bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/20 px-3 py-1 rounded-full uppercase font-bold">
                  Director Clearance
                </span>
              </div>

              <form onSubmit={async (e) => {
                e.preventDefault();
                if (!newAgentName) {
                  triggerNotification('Fields Missing', 'Please enter the agent name.', 'danger');
                  return;
                }
                const newId = 'ag_' + Date.now();
                const contractId = 'c_ag_' + Date.now();
                const newAgent = {
                  id: newId,
                  name: newAgentName,
                  email: newAgentEmail || `${newAgentName.toLowerCase().replace(/\s+/g, '.')}@bloomstudio.com`,
                  role: newAgentRole,
                  pod: currentUser?.subagencyName || currentUser?.pod || 'Bloom & Co - Main Agency',
                  headcount: parseInt(newAgentHeadcount) || 0,
                  volume: 0,
                  score: 92,
                  split: newAgentSplit || '15%',
                  status: 'Active',
                  isSignedCreator: newAgentIsSignedCreator,
                  signedCreatorHandle: newAgentIsSignedCreator ? (newAgentSignedHandle.startsWith('@') ? newAgentSignedHandle : `@${newAgentSignedHandle}`) : '',
                  talentCommissionSplit: newAgentIsSignedCreator ? newAgentSignedSplit : '',
                  creatorNiche: newAgentIsSignedCreator ? newAgentSignedNiche : '',
                  agentAgreementId: contractId,
                  createdAt: new Date().toISOString()
                };

                // Generate specific Agent Manager Agreement
                const newAgentContract = {
                  id: contractId,
                  name: `Agent Manager Operating Agreement - ${newAgentName}${newAgentIsSignedCreator ? ' (Dual-Role Creator & Staff)' : ''}`,
                  client: 'Bloom Studio Management Agency',
                  partner: `${newAgentName} (${newAgentRole})`,
                  type: 'Agent Manager Agreement',
                  status: 'Active',
                  value: `${newAgentSplit || '15%'} Management Override${newAgentIsSignedCreator ? ' + ' + newAgentSignedSplit + ' Personal Creator Deals' : ''}`,
                  signedDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                  expiryDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                  subagency: currentUser?.subagencyName || 'Bloom & Co',
                  isAgentManagerContract: true,
                  isDualSignedContract: newAgentIsSignedCreator,
                  agentName: newAgentName,
                  agentRole: newAgentRole,
                  contractTargetRole: 'agent_manager',
                  overrideCommission: newAgentSplit || '15%',
                  creatorSplitOverride: newAgentIsSignedCreator ? newAgentSignedSplit : '',
                  signedCreatorHandle: newAgentIsSignedCreator ? newAgent.signedCreatorHandle : '',
                  creatorNiche: newAgentIsSignedCreator ? newAgentSignedNiche : '',
                  terms: `This AGENT MANAGER OPERATING AGREEMENT governs the staff representation duties, talent management allocations, and ${newAgentIsSignedCreator ? 'dual-role signed creator representation terms' : 'operating provisions'} for ${newAgentName}.`
                };

                setAgents(prev => [newAgent, ...prev]);
                setContracts(prev => [newAgentContract, ...prev]);

                try {
                  await setDoc(doc(db, 'studio-agents', newId), cleanForFirestore(newAgent), { merge: true });
                  await setDoc(doc(db, 'studio-contracts', contractId), cleanForFirestore(newAgentContract), { merge: true });
                } catch (err) {
                  console.warn('[studio-agents] Firestore save error:', err);
                }

                triggerNotification(
                  'Agent Onboarded',
                  `Successfully registered ${newAgentName} as ${newAgentRole}${newAgentIsSignedCreator ? ' with Dual-Role Signed Creator status' : ''}.`,
                  'success'
                );
                onAddActivityLog(
                  currentUser?.name || 'Sarah Jenkins',
                  'director',
                  `Onboarded agent manager ${newAgentName} (${newAgentRole}) with ${newAgentIsSignedCreator ? `Dual-Role Creator representation (${newAgent.signedCreatorHandle})` : 'standard staff agreement'}`
                );

                setNewAgentName('');
                setNewAgentEmail('');
                setNewAgentHeadcount('');
                setNewAgentIsSignedCreator(false);
                setNewAgentSignedHandle('');
              }} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <label className="text-[#7C8AA8] font-semibold">Agent Full Name</label>
                    <input
                      type="text"
                      value={newAgentName}
                      onChange={(e) => setNewAgentName(e.target.value)}
                      placeholder="e.g. Rachel Sterling"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A]"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[#7C8AA8] font-semibold">Agency Email</label>
                    <input
                      type="email"
                      value={newAgentEmail}
                      onChange={(e) => setNewAgentEmail(e.target.value)}
                      placeholder="e.g. rachel@bloomstudio.com"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[#7C8AA8] font-semibold">Staff Designation / Role</label>
                    <select
                      value={newAgentRole}
                      onChange={(e) => setNewAgentRole(e.target.value)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A]"
                    >
                      <option value="Agent manager">Agent manager</option>
                      <option value="Agent">Agent</option>
                      <option value="Coordinator">Coordinator</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[#7C8AA8] font-semibold">Manager Override Split (%)</label>
                    <input
                      type="text"
                      value={newAgentSplit}
                      onChange={(e) => setNewAgentSplit(e.target.value)}
                      placeholder="e.g. 15%"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[#7C8AA8] font-semibold">Initial Assigned Roster Headcount</label>
                    <input
                      type="number"
                      value={newAgentHeadcount}
                      onChange={(e) => setNewAgentHeadcount(e.target.value)}
                      placeholder="e.g. 3 creators"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[#7C8AA8] font-semibold">Assigned Pod / Agency Unit</label>
                    <input
                      type="text"
                      disabled
                      value={currentUser?.subagencyName || currentUser?.pod || 'Bloom & Co - Main Agency'}
                      className="w-full bg-[#111E33]/60 border border-white/5 rounded-xl p-3 text-slate-400 font-mono"
                    />
                  </div>
                </div>

                {/* Director Choice: Agent Manager is also a Signed Creator */}
                <div className="bg-gradient-to-r from-purple-950/40 via-[#111E33] to-amber-950/40 border border-[#C9A46A]/30 rounded-2xl p-4.5 space-y-3">
                  <label className="flex items-start gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={newAgentIsSignedCreator}
                      onChange={(e) => setNewAgentIsSignedCreator(e.target.checked)}
                      className="w-4 h-4 mt-0.5 rounded accent-[#C9A46A] cursor-pointer"
                    />
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white text-sm">
                          ⭐ This agent manager is also signed to the agency as a creator
                        </span>
                        <span className="bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30 text-[9px] px-2.5 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                          Dual-Role Staff &amp; Creator
                        </span>
                      </div>
                      <p className="text-xs text-[#7C8AA8] leading-relaxed">
                        Enable this choice if this agent manager wants to be represented by the agency for personal sponsorships, brand endorsements, and creator deals alongside their managerial role. The system will issue a customized <strong>Dual-Role Operating Agreement</strong> containing both staff override and talent representation clauses.
                      </p>
                    </div>
                  </label>

                  {newAgentIsSignedCreator && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-white/10 mt-2">
                      <div className="space-y-1">
                        <label className="text-[11px] text-[#C9A46A] font-semibold flex items-center gap-1">
                          <Sparkles className="w-3 h-3" /> Personal Creator Handle
                        </label>
                        <input
                          type="text"
                          required={newAgentIsSignedCreator}
                          value={newAgentSignedHandle}
                          onChange={(e) => setNewAgentSignedHandle(e.target.value)}
                          placeholder="e.g. @rachelsterling"
                          className="w-full bg-[#0D1830] border border-[#C9A46A]/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-[#C9A46A]"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] text-[#C9A46A] font-semibold">Personal Creator Deal Split</label>
                        <input
                          type="text"
                          value={newAgentSignedSplit}
                          onChange={(e) => setNewAgentSignedSplit(e.target.value)}
                          placeholder="e.g. 80% Creator / 20% Agency"
                          className="w-full bg-[#0D1830] border border-[#C9A46A]/30 rounded-xl p-2.5 text-white font-mono outline-none focus:border-[#C9A46A]"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] text-[#C9A46A] font-semibold">Creator Niche / Category</label>
                        <input
                          type="text"
                          value={newAgentSignedNiche}
                          onChange={(e) => setNewAgentSignedNiche(e.target.value)}
                          placeholder="e.g. Beauty, High Fashion & UGC"
                          className="w-full bg-[#0D1830] border border-[#C9A46A]/30 rounded-xl p-2.5 text-white outline-none focus:border-[#C9A46A]"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex justify-end pt-1">
                  <button type="submit" className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2.5 rounded-xl font-bold transition-all flex items-center gap-2 shadow-lg shadow-[#C9A46A]/10 cursor-pointer">
                    <UserPlus className="w-4 h-4" /> Register Staff Profile {newAgentIsSignedCreator ? '& Dual-Role Agreement' : ''}
                  </button>
                </div>
              </form>
            </div>

            {/* List & Score Agents */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-semibold text-lg text-white">Active Agent Roster, Operating Contracts &amp; Scoring</h3>
                  <p className="text-xs text-[#7C8AA8] mt-0.5">
                    Manage commissions, track assignments, and adjust active scores. Agent managers have operating contracts distinct from talent representation.
                  </p>
                </div>
                <span className="text-xs font-mono text-[#C9A46A] bg-[#111E33] border border-white/10 px-3 py-1 rounded-xl shrink-0">
                  Total Staff: {agents.length}
                </span>
              </div>
              
              <div className="space-y-4">
                {agents.map(ag => {
                  // Determine ranking badge based on score
                  let badgeText = "Meeting Expectations";
                  let badgeColor = "bg-sky-950/80 text-sky-400 border-sky-500/20";
                  if (ag.score >= 95) {
                    badgeText = "👑 Elite Coordinator";
                    badgeColor = "bg-[#C9A46A]/20 text-[#C9A46A] border-[#C9A46A]/30";
                  } else if (ag.score >= 85) {
                    badgeText = "⭐ Star Performer";
                    badgeColor = "bg-emerald-950/80 text-emerald-400 border-emerald-500/20";
                  } else if (ag.score < 70) {
                    badgeText = "⚠️ Coaching Required";
                    badgeColor = "bg-rose-950/80 text-rose-400 border-rose-500/20";
                  }

                  const isDual = !!ag.isSignedCreator;

                  return (
                    <div
                      key={ag.id}
                      className={`p-5 rounded-2xl border transition-all flex flex-col xl:flex-row xl:items-center justify-between gap-5 text-xs ${
                        isDual
                          ? 'bg-gradient-to-r from-[#111E33] via-[#141b2d] to-[#1f1933] border-[#C9A46A]/30 shadow-lg shadow-purple-950/20'
                          : 'bg-[#111E33] border-white/5'
                      }`}
                    >
                      {/* Name, Role & Dual-Role Details */}
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2.5 flex-wrap">
                          <h4 className="font-bold text-white text-base">{ag.name}</h4>
                          <span className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full border ${badgeColor}`}>
                            {badgeText}
                          </span>
                          {isDual ? (
                            <span className="bg-gradient-to-r from-purple-900/60 to-amber-900/60 text-[#C9A46A] border border-[#C9A46A]/50 text-[10px] px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1 shadow-sm">
                              <Sparkles className="w-3 h-3 text-[#C9A46A]" /> Dual-Role: Agent Manager + Signed Creator
                            </span>
                          ) : (
                            <span className="bg-slate-800/80 text-slate-300 border border-white/10 text-[10px] px-2 py-0.5 rounded-full font-mono">
                              👔 Agency Operating Staff
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 text-[#7C8AA8] text-[11px]">
                          <div>
                            <span>Staff Designation: </span>
                            <strong className="text-slate-200">{ag.role}</strong>
                          </div>
                          <div>
                            <span>Pod Assignment: </span>
                            <strong className="text-slate-200">{ag.pod || 'Bloom & Co'}</strong>
                          </div>
                          <div>
                            <span>Evaluation Score: </span>
                            <strong className="text-emerald-400 font-mono">{ag.score}/100</strong>
                          </div>
                        </div>

                        {/* Dual Role Metadata Banner */}
                        {isDual && (
                          <div className="bg-[#0D1830]/80 border border-[#C9A46A]/20 rounded-xl p-2.5 flex items-center justify-between gap-4 flex-wrap text-[11px]">
                            <div className="flex items-center gap-4 flex-wrap">
                              <span className="text-[#C9A46A] font-semibold flex items-center gap-1 font-mono">
                                <span>Signed Handle:</span>
                                <strong className="text-white bg-[#111E33] px-2 py-0.5 rounded border border-white/10">{ag.signedCreatorHandle || '@creator'}</strong>
                              </span>
                              <span className="text-slate-300">
                                Talent Split: <strong className="text-emerald-400 font-mono">{ag.talentCommissionSplit || '80% Creator / 20% Agency'}</strong>
                              </span>
                              {ag.creatorNiche && (
                                <span className="text-slate-300">
                                  Niche: <strong className="text-purple-300">{ag.creatorNiche}</strong>
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold bg-[#C9A46A]/10 px-2 py-0.5 rounded">
                              Dual Operating Addendum Active
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Interactive Rating Score Board Slider */}
                      <div className="w-full xl:w-44 space-y-1.5 shrink-0 bg-[#0D1830]/60 p-3 rounded-xl border border-white/5">
                        <div className="flex justify-between text-[10px] text-[#7C8AA8]">
                          <span>Performance Score</span>
                          <span className="font-bold text-white font-mono">{ag.score}%</span>
                        </div>
                        <input
                          type="range"
                          min="50"
                          max="100"
                          value={ag.score}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setAgents(prev => prev.map(x => x.id === ag.id ? { ...x, score: val } : x));
                          }}
                          className="w-full accent-[#C9A46A] bg-[#111E33] h-1.5 rounded cursor-pointer"
                        />
                      </div>

                      {/* Controls & Actions */}
                      <div className="flex flex-col sm:flex-row xl:flex-col items-end justify-center gap-2.5 shrink-0">
                        <div className="text-right flex items-center xl:flex-col xl:items-end gap-3 xl:gap-0.5">
                          <span className="text-slate-300 font-medium">Roster: <strong>{ag.headcount} creators</strong></span>
                          <span className="text-emerald-400 font-bold font-mono">Manager Override: {ag.split}</span>
                        </div>

                        <div className="flex items-center gap-2 flex-wrap justify-end">
                          {/* Button to open Dual-Role Configuration Modal */}
                          <button
                            onClick={() => setEditingDualRoleAgent(ag)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border ${
                              isDual
                                ? 'bg-purple-950/60 hover:bg-purple-900/60 text-purple-200 border-purple-500/40'
                                : 'bg-[#16243F] hover:bg-[#1f3358] text-[#C9A46A] border-[#C9A46A]/20'
                            }`}
                            title="Configure dual-role signed status"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            {isDual ? 'Dual-Role: Active' : 'Enable Dual-Role'}
                          </button>

                          {/* Button to view Agent Operating Agreement */}
                          <button
                            onClick={() => {
                              const foundContract = contracts.find(c => c.id === ag.agentAgreementId || c.partner?.includes(ag.name) || c.agentName === ag.name);
                              setSelectedAgentAgreementForView({
                                agent: ag,
                                contract: foundContract || {
                                  id: ag.agentAgreementId || 'CON-AG-' + ag.id,
                                  name: `Agent Manager Operating Agreement - ${ag.name}`,
                                  type: 'Agent Manager Agreement',
                                  partner: `${ag.name} (${ag.role})`,
                                  value: `${ag.split} Management Override${isDual ? ' + ' + (ag.talentCommissionSplit || '80/20') + ' Personal Deals' : ''}`,
                                  signedDate: 'Jan 15, 2026',
                                  expiryDate: 'Jan 15, 2027',
                                  status: 'Active',
                                  isAgentManagerContract: true,
                                  isDualSignedContract: isDual,
                                  agentName: ag.name,
                                  agentRole: ag.role,
                                  overrideCommission: ag.split,
                                  creatorSplitOverride: ag.talentCommissionSplit || '80% Creator / 20% Agency',
                                  signedCreatorHandle: ag.signedCreatorHandle || '@creator',
                                  creatorNiche: ag.creatorNiche || 'Lifestyle'
                                }
                              });
                            }}
                            className="px-3 py-1.5 bg-[#16243F] hover:bg-[#1f3358] text-slate-200 hover:text-white border border-white/10 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5 text-[#C9A46A]" /> View Agreement
                          </button>

                          <button
                            onClick={() => {
                              const nextSplit = prompt("Enter new commission override for " + ag.name + " (e.g. 18%):") || ag.split;
                              setAgents(prev => prev.map(x => x.id === ag.id ? { ...x, split: nextSplit } : x));
                              setDoc(doc(db, 'studio-agents', ag.id), cleanForFirestore({ ...ag, split: nextSplit }), { merge: true }).catch((err) => {
                                console.error('[studio-agents] Failed to save commission override:', err);
                                triggerNotification('Sync Error', `Failed to persist commission override for ${ag.name} to Firestore.`, 'danger');
                              });
                              triggerNotification('Override Adjusted', `Adjusted commission override for ${ag.name} to ${nextSplit}`, 'success');
                              onAddActivityLog(currentUser?.name || 'Sarah Jenkins', 'director', `Adjusted commission override of agent manager ${ag.name} to ${nextSplit}`);
                            }}
                            className="bg-[#16243F] hover:bg-[#1f3358] text-[#C9A46A] border border-[#C9A46A]/20 px-2.5 py-1.5 rounded-lg font-semibold transition-colors"
                          >
                            Adjust Override
                          </button>
                          
                          <button
                            onClick={async () => {
                              if (confirm(`Are you sure you want to offboard agent manager ${ag.name}?`)) {
                                setAgents(prev => prev.filter(x => x.id !== ag.id));
                                try {
                                  const { moveToTrash } = await import('../lib/trashService');
                                  await moveToTrash('studio-agents', ag, 'agent', currentUser);
                                } catch (e) { /* ignore */ }
                                triggerNotification('Agent Moved to Trash', `Staff profile for ${ag.name} archived to Recoup Trash (30-day recovery window active).`, 'warning');
                                onAddActivityLog(currentUser?.name || 'Sarah Jenkins', 'director', `Archived agent staff account for ${ag.name} to 30-day trash bin`);
                              }
                            }}
                            className="p-1.5 bg-rose-950/30 hover:bg-rose-900/30 text-rose-400 border border-rose-500/10 rounded-lg cursor-pointer"
                            title="Delete Staff Profile"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal: Edit Dual-Role Signed Creator Status */}
            {editingDualRoleAgent && (
              <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl">
                  <div className="bg-[#111E33] border-b border-white/10 p-5 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-[#C9A46A] uppercase font-mono tracking-wider block font-bold">
                        Director Dashboard &middot; Dual-Role Representation
                      </span>
                      <h3 className="text-base font-bold text-white flex items-center gap-2 mt-0.5">
                        <Sparkles className="w-4 h-4 text-[#C9A46A]" />
                        Configure Signed Creator Status: {editingDualRoleAgent.name}
                      </h3>
                    </div>
                    <button
                      onClick={() => setEditingDualRoleAgent(null)}
                      className="text-[#7C8AA8] hover:text-white text-base cursor-pointer p-1"
                    >
                      ✕
                    </button>
                  </div>

                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const updated = {
                        ...editingDualRoleAgent,
                        isSignedCreator: editingDualRoleAgent.isSignedCreator,
                        signedCreatorHandle: editingDualRoleAgent.isSignedCreator
                          ? (editingDualRoleAgent.signedCreatorHandle?.startsWith('@') ? editingDualRoleAgent.signedCreatorHandle : `@${editingDualRoleAgent.signedCreatorHandle || 'creator'}`)
                          : '',
                        talentCommissionSplit: editingDualRoleAgent.isSignedCreator ? (editingDualRoleAgent.talentCommissionSplit || '80% Creator / 20% Agency') : '',
                        creatorNiche: editingDualRoleAgent.isSignedCreator ? (editingDualRoleAgent.creatorNiche || 'Lifestyle') : ''
                      };

                      setAgents(prev => prev.map(a => a.id === updated.id ? updated : a));
                      try {
                        await setDoc(doc(db, 'studio-agents', updated.id), cleanForFirestore(updated), { merge: true });
                      } catch (err) {
                        console.warn('[studio-agents] Firestore save error:', err);
                      }

                      triggerNotification(
                        'Dual-Role Updated',
                        `Updated dual-role representation settings for ${updated.name}.`,
                        'success'
                      );
                      onAddActivityLog(
                        currentUser?.name || 'Sarah Jenkins',
                        'director',
                        `Updated signed creator representation for agent manager ${updated.name}: ${updated.isSignedCreator ? `Signed as ${updated.signedCreatorHandle}` : 'Standard staff only'}`
                      );
                      setEditingDualRoleAgent(null);
                    }}
                    className="p-6 space-y-4 text-xs"
                  >
                    <div className="bg-gradient-to-r from-purple-950/40 via-[#111E33] to-amber-950/40 border border-[#C9A46A]/30 rounded-xl p-4 space-y-3">
                      <label className="flex items-start gap-3 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={!!editingDualRoleAgent.isSignedCreator}
                          onChange={(e) => {
                            const checked = e.target.checked;
                            setEditingDualRoleAgent((prev: any) => ({
                              ...prev,
                              isSignedCreator: checked,
                              signedCreatorHandle: checked ? (prev.signedCreatorHandle || `@${prev.name.toLowerCase().replace(/\s+/g, '')}`) : '',
                              talentCommissionSplit: checked ? (prev.talentCommissionSplit || '80% Creator / 20% Agency') : '',
                              creatorNiche: checked ? (prev.creatorNiche || 'Lifestyle & UGC') : ''
                            }));
                          }}
                          className="w-4 h-4 mt-0.5 rounded accent-[#C9A46A] cursor-pointer"
                        />
                        <div>
                          <span className="font-bold text-white text-xs flex items-center gap-2">
                            <span>⭐ This agent manager is also signed to the agency as a creator</span>
                            <span className="bg-[#C9A46A]/20 text-[#C9A46A] text-[9px] px-2 py-0.5 rounded-full font-mono font-bold uppercase">
                              Dual-Role
                            </span>
                          </span>
                          <p className="text-[11px] text-[#7C8AA8] mt-1">
                            When enabled, this agent manager is officially represented by the agency for personal brand sponsorships while remaining an active talent manager.
                          </p>
                        </div>
                      </label>
                    </div>

                    {editingDualRoleAgent.isSignedCreator && (
                      <div className="space-y-3 pt-2">
                        <div className="space-y-1">
                          <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Personal Creator Handle</label>
                          <input
                            type="text"
                            required
                            value={editingDualRoleAgent.signedCreatorHandle || ''}
                            onChange={(e) => setEditingDualRoleAgent((prev: any) => ({ ...prev, signedCreatorHandle: e.target.value }))}
                            className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white font-mono outline-none focus:border-[#C9A46A]"
                            placeholder="@rachelsterling"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Personal Talent Split</label>
                            <input
                              type="text"
                              value={editingDualRoleAgent.talentCommissionSplit || '80% Creator / 20% Agency'}
                              onChange={(e) => setEditingDualRoleAgent((prev: any) => ({ ...prev, talentCommissionSplit: e.target.value }))}
                              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white font-mono outline-none focus:border-[#C9A46A]"
                              placeholder="80% Creator / 20% Agency"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Creator Primary Niche</label>
                            <input
                              type="text"
                              value={editingDualRoleAgent.creatorNiche || 'Lifestyle'}
                              onChange={(e) => setEditingDualRoleAgent((prev: any) => ({ ...prev, creatorNiche: e.target.value }))}
                              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#C9A46A]"
                              placeholder="Beauty & Fashion"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Manager Override Commission</label>
                          <input
                            type="text"
                            value={editingDualRoleAgent.split || '15%'}
                            onChange={(e) => setEditingDualRoleAgent((prev: any) => ({ ...prev, split: e.target.value }))}
                            className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white font-mono outline-none focus:border-[#C9A46A]"
                            placeholder="15%"
                          />
                        </div>
                      </div>
                    )}

                    <div className="pt-3 flex gap-3">
                      <button
                        type="button"
                        onClick={() => setEditingDualRoleAgent(null)}
                        className="flex-1 bg-[#111E33] hover:bg-[#16243F] text-slate-300 py-3 rounded-xl font-semibold transition-colors cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-3 rounded-xl font-bold transition-all shadow-lg shadow-[#C9A46A]/10 cursor-pointer"
                      >
                        Save Dual-Role Status
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Modal: View Agent Manager Operating Agreement */}
            {selectedAgentAgreementForView && (
              <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
                  <div className="bg-[#111E33] border-b border-white/10 p-5 flex justify-between items-center shrink-0">
                    <div>
                      <span className="text-[10px] text-[#C9A46A] uppercase font-mono tracking-wider block font-bold">
                        Bloom Studio Legal Vault &middot; Staff Operating Agreement
                      </span>
                      <h3 className="text-base font-bold text-white mt-0.5">
                        {selectedAgentAgreementForView.contract?.name || `Agent Manager Agreement - ${selectedAgentAgreementForView.agent?.name}`}
                      </h3>
                    </div>
                    <button
                      onClick={() => setSelectedAgentAgreementForView(null)}
                      className="text-[#7C8AA8] hover:text-white text-base cursor-pointer p-1"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
                    {/* Summary Header */}
                    <div className="bg-[#111E33] border border-white/10 rounded-xl p-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                      <div>
                        <span className="text-[#7C8AA8] block text-[10px] uppercase font-mono">Agent Manager</span>
                        <strong className="text-white font-serif">{selectedAgentAgreementForView.agent?.name}</strong>
                      </div>
                      <div>
                        <span className="text-[#7C8AA8] block text-[10px] uppercase font-mono">Role Designation</span>
                        <strong className="text-[#C9A46A]">{selectedAgentAgreementForView.agent?.role}</strong>
                      </div>
                      <div>
                        <span className="text-[#7C8AA8] block text-[10px] uppercase font-mono">Manager Override</span>
                        <strong className="text-emerald-400 font-mono">{selectedAgentAgreementForView.agent?.split || '15%'}</strong>
                      </div>
                      <div>
                        <span className="text-[#7C8AA8] block text-[10px] uppercase font-mono">Representation</span>
                        <strong className="text-purple-300 font-mono">
                          {selectedAgentAgreementForView.agent?.isSignedCreator ? 'Dual-Role Signed' : 'Staff Only'}
                        </strong>
                      </div>
                    </div>

                    {/* Dual-Role Banner if applicable */}
                    {selectedAgentAgreementForView.agent?.isSignedCreator && (
                      <div className="bg-gradient-to-r from-purple-950/60 to-amber-950/60 border border-[#C9A46A]/40 rounded-xl p-4 space-y-2">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-[#C9A46A]" />
                          <h4 className="font-bold text-white text-sm">Dual-Role Talent Representation Addendum (Active)</h4>
                        </div>
                        <p className="text-[#7C8AA8] text-[11px] leading-relaxed">
                          This agreement incorporates dual representation terms: <strong className="text-white">{selectedAgentAgreementForView.agent?.name}</strong> acts as an <strong>Agent Manager</strong> receiving a <strong>{selectedAgentAgreementForView.agent?.split || '15%'} override</strong> on managed roster deals, and is concurrently signed to the agency as a talent under handle <strong className="text-white font-mono">{selectedAgentAgreementForView.agent?.signedCreatorHandle || '@creator'}</strong> with personal talent split <strong className="text-emerald-400 font-mono">{selectedAgentAgreementForView.agent?.talentCommissionSplit || '80/20'}</strong>.
                        </p>
                      </div>
                    )}

                    {/* Operating Clauses */}
                    <div className="space-y-4">
                      <div className="border-b border-white/5 pb-2">
                        <h4 className="font-bold text-[#C9A46A] uppercase tracking-wider text-[11px] font-mono">1. Scope of Managerial Duties</h4>
                        <p className="text-slate-400 mt-1 leading-relaxed">
                          Agent Manager is engaged by Bloom Studio Management Agency to execute talent procurement, brand deal negotiations, campaign delivery oversight, and roster growth. Agent Manager agrees to maintain fiduciary standards in all talent negotiations and brand communications.
                        </p>
                      </div>

                      <div className="border-b border-white/5 pb-2">
                        <h4 className="font-bold text-[#C9A46A] uppercase tracking-wider text-[11px] font-mono">2. Managerial Commission Override Structure</h4>
                        <p className="text-slate-400 mt-1 leading-relaxed">
                          Agency shall disburse to Agent Manager a managerial commission override equal to <strong className="text-white">{selectedAgentAgreementForView.agent?.split || '15%'}</strong> of net agency commissions generated from all deals procured or negotiated for talent assigned to Agent Manager's designated roster.
                        </p>
                      </div>

                      {selectedAgentAgreementForView.agent?.isSignedCreator && (
                        <div className="border-b border-white/5 pb-2 bg-purple-950/20 p-3 rounded-lg border border-purple-500/20">
                          <h4 className="font-bold text-purple-300 uppercase tracking-wider text-[11px] font-mono">3. Dual-Role Personal Creator Split &amp; Representation</h4>
                          <p className="text-slate-300 mt-1 leading-relaxed">
                            Agency shall represent Agent Manager in their personal creator capacity for handle <strong className="text-white font-mono">{selectedAgentAgreementForView.agent?.signedCreatorHandle || '@creator'}</strong>. Gross revenues from personal brand endorsements, UGC, and sponsorships shall be split at <strong className="text-emerald-400 font-mono">{selectedAgentAgreementForView.agent?.talentCommissionSplit || '80% Creator / 20% Agency'}</strong>.
                          </p>
                        </div>
                      )}

                      <div className="border-b border-white/5 pb-2">
                        <h4 className="font-bold text-[#C9A46A] uppercase tracking-wider text-[11px] font-mono">{selectedAgentAgreementForView.agent?.isSignedCreator ? '4' : '3'}. Confidentiality &amp; Client Non-Solicitation</h4>
                        <p className="text-slate-400 mt-1 leading-relaxed">
                          Agent Manager acknowledges access to proprietary agency contacts, brand relationships, rate benchmarks, and creator contracts. All agency data remains strictly confidential and protected by intellectual property covenants.
                        </p>
                      </div>
                    </div>

                    {/* Signatures */}
                    <div className="bg-[#111E33] border border-white/10 rounded-xl p-4 grid grid-cols-2 gap-4 text-[11px]">
                      <div>
                        <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Agency Director</span>
                        <p className="text-white font-serif font-bold mt-1">{currentUser?.role === 'director' ? (currentUser?.name || 'Agency Director') : 'Agency Director'}</p>
                        <span className="text-[10px] text-emerald-400 font-mono">Digitally Verified &bull; Active</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Agent Manager Signee</span>
                        <p className="text-white font-serif font-bold mt-1">{selectedAgentAgreementForView.agent?.name}</p>
                        <span className="text-[10px] text-emerald-400 font-mono">Digitally Executed</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#111E33] border-t border-white/10 p-4 flex justify-end shrink-0">
                    <button
                      onClick={() => setSelectedAgentAgreementForView(null)}
                      className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2 rounded-xl font-bold transition-all cursor-pointer"
                    >
                      Close Agreement
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      // --- AGENT TASKS WORKSPACE DASHBOARD ---
      case 'agent-dash':
        {
          const isCoordinatorRole = (currentRole || '').toLowerCase() === 'coordinator';
          const isAgentRole = (currentRole || '').toLowerCase() === 'agent';
          const isAgentMgrRole = (currentRole || '').toLowerCase() === 'agentmgr';
          const isDirectorRole = (currentRole || '').toLowerCase() === 'director';

          const activeAgentName = currentUser?.name || (isCoordinatorRole ? 'Alex Vance' : isAgentRole ? 'Rachel Sterling' : 'Marcus Cole');
          const activeAgentObj = agents.find(ag => 
            ag.name.toLowerCase() === activeAgentName.toLowerCase() || 
            ag.id === currentUser?.id ||
            (currentUser?.handle && ag.signedCreatorHandle?.toLowerCase() === currentUser.handle.toLowerCase())
          ) || {
            id: 'ag_fallback',
            name: activeAgentName,
            role: isCoordinatorRole ? 'Campaign Coordinator' : isAgentRole ? 'Talent Agent' : 'Senior Agent Manager',
            pod: currentUser?.subagencyName || currentUser?.pod || 'Bloom & Co - Main Agency',
            split: isCoordinatorRole ? '12%' : isAgentRole ? '15%' : '15%',
            score: 95,
            headcount: 3,
            volume: 45000,
            status: 'Active',
            isSignedCreator: activeAgentName.toLowerCase().includes('rachel') || (currentUser?.handle || '').toLowerCase() === '@rachelsterling',
            signedCreatorHandle: activeAgentName.toLowerCase().includes('rachel') ? '@rachelsterling' : ''
          };
          
          const assignedCreators = creators.filter(c => {
            const ag = (c.assignedAgent || '').toLowerCase();
            const coord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
            const mgr = (c.assignedManager || '').toLowerCase();
            const myNameLower = activeAgentName.toLowerCase();
            const myHandleLower = (currentUser?.handle || '').toLowerCase();

            if (isCoordinatorRole) {
              return coord === myNameLower || (myHandleLower && (coord === myHandleLower || coord.includes(myHandleLower.replace('@', ''))));
            }
            if (isAgentRole) {
              return ag === myNameLower || (myHandleLower && (ag === myHandleLower || ag.includes(myHandleLower.replace('@', ''))));
            }
            if (isAgentMgrRole) {
              return mgr === myNameLower || ag === myNameLower || (myHandleLower && (mgr === myHandleLower || ag === myHandleLower));
            }
            return ag === myNameLower || ag === myHandleLower || coord === myNameLower || coord === myHandleLower || mgr === myNameLower;
          });

          const assignedHandles = assignedCreators.map(c => (c.handle || '').toLowerCase());
          const assignedNames = assignedCreators.map(c => (c.name || '').toLowerCase());

          const myScopedDeals = deals.filter(d => {
            const dCreator = (d.creator || '').toLowerCase();
            const dHandle = (d.creatorHandle || '').toLowerCase();
            const dAgent = (d.agent || '').toLowerCase();
            const dCoord = (d.coordinator || '').toLowerCase();
            const myNameLower = activeAgentName.toLowerCase();

            return (
              assignedHandles.includes(dHandle) ||
              assignedNames.includes(dCreator) ||
              dAgent === myNameLower ||
              dCoord === myNameLower ||
              dAgent.includes(myNameLower) ||
              dCoord.includes(myNameLower)
            );
          });

          const totalRosterVolume = myScopedDeals.reduce((sum, d) => {
            const rawVal = typeof d.value === 'number' ? d.value : parseFloat(String(d.value || d.amount || 0).replace(/[^0-9.]/g, '')) || 0;
            return sum + rawVal;
          }, 0);

          const splitPct = parseFloat(activeAgentObj?.split || '15') / 100;
          const estimatedStaffCommission = totalRosterVolume * splitPct;

          const isDualRoleSigned = activeAgentObj?.isSignedCreator || activeAgentName.toLowerCase().includes('rachel') || (currentUser?.handle || '').toLowerCase() === '@rachelsterling';

          // Group agents into roles for the switcher sandbox
          const managerStaff = agents.filter(a => (a.role || '').toLowerCase().includes('manager') || (a.role || '').toLowerCase().includes('lead'));
          const agentStaff = agents.filter(a => !(a.role || '').toLowerCase().includes('manager') && !(a.role || '').toLowerCase().includes('coordinator'));
          const coordStaff = agents.filter(a => (a.role || '').toLowerCase().includes('coordinator'));

          return (
            <div className="space-y-6">
              {/* Multi-Staff Persona Sandbox: Test 3 Agents, 2 Managers, 2 Coordinators */}
              <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-4.5 space-y-3.5 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-[#C9A46A]">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold tracking-wider">Staff Persona Sandbox</span>
                        <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.2 rounded font-mono">
                          Live Isolation Active
                        </span>
                      </div>
                      <h4 className="text-xs font-semibold text-white">Switch between 3 Agents, 2 Agent Managers, and 2 Coordinators</h4>
                    </div>
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
                    <span>Active:</span>
                    <strong className="text-amber-400">{activeAgentName}</strong>
                    <span className="text-slate-600">&bull;</span>
                    <span className="text-slate-300">({activeAgentObj.role})</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {/* Agent Managers Column */}
                  <div className="bg-[#111E33] border border-amber-400/20 rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-mono font-bold text-amber-400 uppercase">
                      <span>💼 Agent Managers ({managerStaff.length})</span>
                      <span>Internal Managers</span>
                    </div>
                    <div className="space-y-1.5">
                      {managerStaff.map((ag) => {
                        const isActive = activeAgentName.toLowerCase() === ag.name.toLowerCase();
                        return (
                          <button
                            key={ag.id}
                            onClick={() => {
                              handleRequestRoleSwitch('agentmgr', {
                                id: ag.id,
                                name: ag.name,
                                role: 'agentmgr',
                                handle: ag.signedCreatorHandle || `@${ag.name.toLowerCase().replace(/\s+/g, '')}`,
                                subagencyName: ag.pod,
                                agency: ag.pod,
                                pod: ag.pod,
                                email: ag.email
                              });
                              triggerNotification('Staff Switched', `Active dashboard set to Agent Manager: ${ag.name}.`, 'info');
                            }}
                            className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex items-center justify-between gap-1.5 cursor-pointer ${
                              isActive
                                ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-md'
                                : 'bg-[#0D1830] text-slate-300 hover:bg-[#16243F] hover:text-white border border-white/5'
                            }`}
                          >
                            <div className="min-w-0">
                              <span className="truncate block font-medium">{ag.name}</span>
                              <span className={`text-[9px] block ${isActive ? 'text-slate-900/80' : 'text-slate-500'}`}>
                                {ag.pod?.replace('Bloom & Co - ', '') || 'Main Agency'} &bull; {ag.split} Override
                              </span>
                            </div>
                            {isActive && <span className="w-2 h-2 rounded-full bg-slate-950 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Talent Agents Column */}
                  <div className="bg-[#111E33] border border-sky-400/20 rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-mono font-bold text-sky-400 uppercase">
                      <span>👔 Talent Agents ({agentStaff.length})</span>
                      <span>Assigned Roster</span>
                    </div>
                    <div className="space-y-1.5">
                      {agentStaff.map((ag) => {
                        const isActive = activeAgentName.toLowerCase() === ag.name.toLowerCase();
                        return (
                          <button
                            key={ag.id}
                            onClick={() => {
                              handleRequestRoleSwitch('agent', {
                                id: ag.id,
                                name: ag.name,
                                role: 'agent',
                                handle: ag.signedCreatorHandle || `@${ag.name.toLowerCase().replace(/\s+/g, '')}`,
                                subagencyName: ag.pod,
                                agency: ag.pod,
                                pod: ag.pod,
                                email: ag.email
                              });
                              triggerNotification('Staff Switched', `Active dashboard set to Talent Agent: ${ag.name}.`, 'info');
                            }}
                            className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex items-center justify-between gap-1.5 cursor-pointer ${
                              isActive
                                ? 'bg-sky-400 text-slate-950 font-bold shadow-md'
                                : 'bg-[#0D1830] text-slate-300 hover:bg-[#16243F] hover:text-white border border-white/5'
                            }`}
                          >
                            <div className="min-w-0">
                              <div className="flex items-center gap-1">
                                <span className="truncate font-medium">{ag.name}</span>
                                {ag.isSignedCreator && (
                                  <span className={`text-[8px] px-1 rounded font-mono font-bold ${isActive ? 'bg-purple-900 text-purple-200' : 'bg-purple-500/20 text-purple-300'}`}>
                                    Dual
                                  </span>
                                )}
                              </div>
                              <span className={`text-[9px] block ${isActive ? 'text-slate-900/80' : 'text-slate-500'}`}>
                                {ag.role} &bull; {ag.split} Split
                              </span>
                            </div>
                            {isActive && <span className="w-2 h-2 rounded-full bg-slate-950 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Coordinators Column */}
                  <div className="bg-[#111E33] border border-emerald-400/20 rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-mono font-bold text-emerald-400 uppercase">
                      <span>📋 Coordinators ({coordStaff.length})</span>
                      <span>Logistics &amp; FTC</span>
                    </div>
                    <div className="space-y-1.5">
                      {coordStaff.map((ag) => {
                        const isActive = activeAgentName.toLowerCase() === ag.name.toLowerCase();
                        return (
                          <button
                            key={ag.id}
                            onClick={() => {
                              handleRequestRoleSwitch('coordinator', {
                                id: ag.id,
                                name: ag.name,
                                role: 'coordinator',
                                handle: ag.signedCreatorHandle || `@${ag.name.toLowerCase().replace(/\s+/g, '')}`,
                                subagencyName: ag.pod,
                                agency: ag.pod,
                                pod: ag.pod,
                                email: ag.email
                              });
                              triggerNotification('Staff Switched', `Active dashboard set to Coordinator: ${ag.name}.`, 'info');
                            }}
                            className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all flex items-center justify-between gap-1.5 cursor-pointer ${
                              isActive
                                ? 'bg-emerald-400 text-slate-950 font-bold shadow-md'
                                : 'bg-[#0D1830] text-slate-300 hover:bg-[#16243F] hover:text-white border border-white/5'
                            }`}
                          >
                            <div className="min-w-0">
                              <span className="truncate block font-medium">{ag.name}</span>
                              <span className={`text-[9px] block ${isActive ? 'text-slate-900/80' : 'text-slate-500'}`}>
                                {ag.role} &bull; {ag.split} Fee
                              </span>
                            </div>
                            {isActive && <span className="w-2 h-2 rounded-full bg-slate-950 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Welcome & Profile Banner */}
              <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#C9A46A]/20 rounded-2xl p-6 overflow-hidden shadow-xl">
                <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.08)_0%,transparent_70%) pointer-events-none"></div>
                <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider font-mono">
                        {activeAgentObj?.pod || 'Bloom & Co - Main Agency'}
                      </span>
                      <span className="text-[10px] bg-white/5 text-slate-300 border border-white/10 px-2 py-0.5 rounded-md font-mono">
                        {activeAgentObj?.role || (isCoordinatorRole ? 'Lead Campaign Coordinator' : isAgentRole ? 'Commercial Talent Agent' : 'Senior Agent Manager')}
                      </span>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-md font-mono font-bold">
                        Staff Commission / Fee: {activeAgentObj?.split || '15%'}
                      </span>
                    </div>
                    <h1 className="font-serif font-semibold text-2xl text-white mt-2 flex items-center gap-2">
                      <span>{activeAgentName}</span>
                      {isDualRoleSigned && (
                        <span className="text-xs font-sans font-normal bg-gradient-to-r from-purple-900/60 to-amber-900/60 text-[#C9A46A] border border-[#C9A46A]/40 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-[#C9A46A]" /> Dual-Role Signed Creator
                        </span>
                      )}
                    </h1>
                    <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed max-w-2xl">
                      {isCoordinatorRole
                        ? `Manage campaign logistics, FTC disclosure compliance checkoffs, milestone escrow sign-offs, and coordinator deliverables for your ${assignedCreators.length} assigned talent.`
                        : isAgentRole
                        ? `Pitch brand campaigns and sponsor opportunities for your assigned creator roster (${assignedCreators.length} talent), advocate for creator interests, maintain creator relations, and track pitching outreach (No Deal Negotiations).`
                        : `Lead your agency pod roster (${assignedCreators.length} talent), oversee campaign deliverables, delegate to staff coordinators, and govern contract compliance.`}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <div className="flex items-center gap-2 bg-black/30 px-4 py-2.5 rounded-xl border border-white/10">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      <div className="text-right">
                        <div className="text-[9px] text-[#7C8AA8] uppercase font-mono">Active Dashboard Scope</div>
                        <div className="text-xs font-mono font-bold text-white">{currentRole?.toUpperCase() || 'STAFF'}</div>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Performance Score: <strong className="text-[#C9A46A]">{activeAgentObj?.score || 95}/100</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Key Metrics Strip */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 space-y-1">
                  <div className="text-[10px] text-[#7C8AA8] font-mono uppercase flex items-center justify-between">
                    <span>Assigned Talent</span>
                    <Users className="w-3.5 h-3.5 text-sky-400" />
                  </div>
                  <div className="text-xl font-bold text-white">{assignedCreators.length} <span className="text-xs font-normal text-slate-400">Creators</span></div>
                  <div className="text-[10px] text-emerald-400 font-mono">100% Isolated to {activeAgentName.split(' ')[0]}</div>
                </div>

                <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 space-y-1">
                  <div className="text-[10px] text-[#7C8AA8] font-mono uppercase flex items-center justify-between">
                    <span>Managed Deal Flow</span>
                    <Briefcase className="w-3.5 h-3.5 text-[#C9A46A]" />
                  </div>
                  <div className="text-xl font-bold text-white">${totalRosterVolume.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{myScopedDeals.length} active sponsorships</div>
                </div>

                <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 space-y-1">
                  <div className="text-[10px] text-[#7C8AA8] font-mono uppercase flex items-center justify-between">
                    <span>Est. Commission / Fee</span>
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-xl font-bold text-emerald-400">${Math.round(estimatedStaffCommission).toLocaleString()}</div>
                  <div className="text-[10px] text-slate-400 font-mono">Based on {activeAgentObj?.split || '15%'} contract override</div>
                </div>

                <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 space-y-1">
                  <div className="text-[10px] text-[#7C8AA8] font-mono uppercase flex items-center justify-between">
                    <span>Operating Rating</span>
                    <CheckSquare className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="text-xl font-bold text-[#C9A46A]">{activeAgentObj?.score || 95}/100</div>
                  <div className="text-[10px] text-emerald-400 font-mono">Zero FTC audit violations</div>
                </div>
              </div>

              {/* Dual-Role Signed Creator Banner (If this manager is also signed as talent) */}
              {isDualRoleSigned && (
                <div className="bg-gradient-to-r from-purple-950/40 via-[#111E33] to-amber-950/30 border border-[#C9A46A]/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-[#C9A46A]/10 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0 mt-0.5">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-xs font-bold text-white">Dual-Role Talent Representation Active</h4>
                        <span className="text-[10px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.5 rounded">
                          Handle: {activeAgentObj?.signedCreatorHandle || '@rachelsterling'}
                        </span>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                          Split: {activeAgentObj?.talentCommissionSplit || '80% Creator / 20% Agency'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-1">
                        You hold an active Talent Representation contract in the agency vault alongside your Agent Operating Agreement.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => {
                        handleRequestRoleSwitch('creator', {
                          id: activeAgentObj?.id || 'cr_rachel_sterling',
                          name: activeAgentName,
                          role: 'creator',
                          handle: activeAgentObj?.signedCreatorHandle || '@rachelsterling',
                          subagencyName: activeAgentObj?.pod || 'Bloom & Co'
                        });
                        triggerNotification('Switched to Creator View', `Opened personal Creator Portal for ${activeAgentObj?.signedCreatorHandle || '@rachelsterling'}.`, 'info');
                      }}
                      className="bg-[#C9A46A] hover:bg-[#b8935a] text-[#0A1220] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                    >
                      <User className="w-3.5 h-3.5" /> Open My Talent Portal
                    </button>
                    <button
                      onClick={() => {
                        onNavigate('contracts');
                        triggerNotification('Vault Opened', `Viewing agreements in the Legal Vault.`, 'info');
                      }}
                      className="bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                    >
                      View Contracts
                    </button>
                  </div>
                </div>
              )}

              {/* Grid Split: Left = My Assigned Roster, Right = Staff Delegation / Sub-Assignment */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                
                {/* Left Column: My Assigned Creators (Director Top-Down Assignment) */}
                <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <div>
                      <h3 className="text-xs font-semibold text-white flex items-center gap-2 uppercase tracking-wider" style={{ color: primaryBrandColor }}>
                        <Lock className="w-4 h-4" /> 🔒 My Assigned Roster ({assignedCreators.length})
                      </h3>
                      <p className="text-[10px] text-[#7C8AA8] mt-0.5">Creators strictly assigned to {activeAgentName} from the Director Panel.</p>
                    </div>
                    <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2.5 py-1 rounded-full font-bold uppercase">
                      Strict Roster Scope
                    </span>
                  </div>

                  <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                    {assignedCreators.length === 0 ? (
                      <div className="text-center py-10 space-y-2">
                        <p className="text-xs text-slate-400">No creators are currently assigned to {activeAgentName}.</p>
                        <p className="text-[10px] text-slate-500">The Director assigns talent top-down from the Director Control Panel.</p>
                      </div>
                    ) : (
                      assignedCreators.map((creator) => (
                        <div key={creator.id} className="p-3.5 bg-[#111E33] rounded-xl border border-white/5 flex items-center justify-between gap-4 hover:bg-[#16243F]/40 transition-colors">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-9 h-9 rounded-full bg-[#16243F] border border-[#C9A46A]/20 flex items-center justify-center font-bold text-[#C9A46A] text-xs shrink-0" style={{ color: primaryBrandColor, borderColor: `${primaryBrandColor}20` }}>
                              {creator.name ? creator.name.split(' ').map((n: string) => n[0]).join('') : creator.handle.slice(1, 3).toUpperCase()}
                            </div>
                            <div className="min-w-0">
                              <div className="font-semibold text-white text-xs flex items-center gap-1.5 truncate">
                                <span>{creator.name || creator.handle}</span>
                                <span className="text-[10px] text-slate-400 font-normal">({creator.handle})</span>
                                <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded shrink-0">Assigned</span>
                              </div>
                              <div className="text-[10px] text-[#7C8AA8] mt-0.5 truncate">
                                {creator.niche || 'Creator'} &middot; {creator.followers || '100K+'} &middot; <strong className="text-slate-300">{creator.agreement || 'Exclusive Representation'}</strong>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => {
                                triggerNotification(
                                  'Encrypted Thread Opened', 
                                  `Secure communications channel opened with ${creator.handle}.`, 
                                  'info'
                                );
                                onAddActivityLog(
                                  activeAgentName, 
                                  currentRole || 'agentmgr', 
                                  `Opened secure communications thread with assigned creator ${creator.handle}`
                                );
                              }}
                              className="bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                            >
                              <Mail className="w-3 h-3" /> Message
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Right Column: Delegate Down to Staff Coordinator / Pod Agent */}
                <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <div>
                      <h3 className="text-xs font-semibold text-white flex items-center gap-2 uppercase tracking-wider" style={{ color: primaryBrandColor }}>
                        <Users className="w-4 h-4" /> 👔 Staff Delegation &amp; Coordinator Sub-Assignment
                      </h3>
                      <p className="text-[10px] text-[#7C8AA8] mt-0.5">Assign your managed creators down to pod staff coordinators.</p>
                    </div>
                    <span className="text-[9px] bg-sky-500/10 text-sky-400 border border-sky-500/25 px-2.5 py-1 rounded-full font-bold uppercase">
                      Pod Roster
                    </span>
                  </div>

                  <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                    {assignedCreators.length === 0 ? (
                      <p className="text-slate-500 text-xs italic text-center py-6">No managed creators available for delegation.</p>
                    ) : (
                      assignedCreators.map(creator => (
                        <div key={creator.id} className="p-3 bg-[#111E33] rounded-xl border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <span className="font-semibold text-white text-xs block">{creator.name} ({creator.handle})</span>
                            <span className="text-[10px] text-[#7C8AA8] font-mono">Assigned Coordinator: <strong className="text-slate-300">{creator.assignedCoordinator || creator.coordinator || 'Unassigned'}</strong></span>
                          </div>
                          <div className="flex items-center gap-2">
                            <select
                              value={creator.assignedCoordinator || creator.coordinator || 'Unassigned'}
                              onChange={(e) => {
                                const nextVal = e.target.value;
                                if (setCreators) {
                                  setCreators((prev: any[]) => prev.map((c: any) => c.id === creator.id ? { ...c, assignedCoordinator: nextVal, coordinator: nextVal } : c));
                                }
                                triggerNotification('Sub-Assignment Updated', `Delegated ${creator.handle} to coordinator ${nextVal}.`, 'success');
                                onAddActivityLog(activeAgentName, currentRole || 'agentmgr', `Delegated creator ${creator.handle} down to coordinator ${nextVal}`);
                              }}
                              className="bg-[#0D1830] border border-white/10 text-slate-200 text-[11px] px-2.5 py-1.5 rounded-lg focus:outline-none focus:border-[#C9A46A] cursor-pointer"
                            >
                              <option value="Unassigned">Unassigned Pool</option>
                              {agents.map((ag: any) => (
                                <option key={ag.id} value={ag.name}>{ag.name} ({ag.role || 'Staff'})</option>
                              ))}
                            </select>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Scoped Brand Deals & Campaigns Pipeline */}
              <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                  <div>
                    <h3 className="font-serif font-semibold text-sm text-white flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-[#C9A46A]" /> 💼 Active Brand Deals Pipeline ({myScopedDeals.length})
                    </h3>
                    <p className="text-[10px] text-[#7C8AA8] mt-0.5">Sponsorship campaigns strictly linked to your assigned talent roster.</p>
                  </div>
                  <span className="text-[9px] bg-[#C9A46A]/10 text-[#C9A46A] border border-[#C9A46A]/30 px-2.5 py-1 rounded-full font-bold uppercase">
                    Scoped Deals
                  </span>
                </div>

                <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
                  {myScopedDeals.length === 0 ? (
                    <p className="text-xs text-slate-500 italic text-center py-4">No active brand deals recorded for your assigned talent roster.</p>
                  ) : (
                    myScopedDeals.map((deal) => {
                      const dealVal = typeof deal.value === 'number' ? deal.value : parseFloat(String(deal.value || deal.amount || 0).replace(/[^0-9.]/g, '')) || 0;
                      const staffCut = dealVal * splitPct;
                      return (
                        <div key={deal.id} className="p-3 bg-[#111E33] border border-white/5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-xs">{deal.brand}</span>
                              <span className="text-[10px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.2 rounded">{deal.creator}</span>
                              <span className="text-[10px] text-slate-400">({deal.creatorHandle || '@talent'})</span>
                            </div>
                            <div className="text-[11px] text-[#7C8AA8] mt-1 flex items-center gap-3">
                              <span>Deliverable: <strong className="text-slate-300">{deal.deliverable || deal.type || 'Sponsorship'}</strong></span>
                              <span>&middot;</span>
                              <span>Platform: <strong className="text-slate-300">{deal.platform || 'YouTube'}</strong></span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 shrink-0">
                            <div className="text-right">
                              <div className="text-xs font-bold text-white">${dealVal.toLocaleString()}</div>
                              <div className="text-[10px] font-mono text-emerald-400">Staff Cut: ~${Math.round(staffCut).toLocaleString()}</div>
                            </div>
                            <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                              deal.status === 'Signed' || deal.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/25' :
                              deal.status === 'In Negotiation' || deal.status === 'Draft' ? 'bg-amber-500/10 text-amber-400 border-amber-500/25' :
                              'bg-sky-500/10 text-sky-400 border-sky-500/25'
                            }`}>
                              {deal.status || 'Active'}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Roster Mission Tracking & Deadlines */}
              <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                  <div>
                    <h3 className="font-serif font-semibold text-sm text-white flex items-center gap-2">
                      <CheckSquare className="w-4 h-4 text-[#C9A46A]" /> 🎯 Roster Mission Tracking &amp; Deadlines
                    </h3>
                    <p className="text-[10px] text-[#7C8AA8] mt-0.5">Live tracking of campaign missions, deadlines, and deliverables for your assigned creator roster.</p>
                  </div>
                  <span className="text-[9px] bg-[#C9A46A]/10 text-[#C9A46A] border border-[#C9A46A]/30 px-2.5 py-1 rounded-full font-bold uppercase">
                    Live Roster Tracker
                  </span>
                </div>
                <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                  {(() => {
                    const rosterHandles = assignedCreators.map(c => c.handle.toLowerCase());
                    const rosterNames = assignedCreators.map(c => (c.name || '').toLowerCase());
                    const rosterMissions = missions.filter(m => {
                      if (rosterHandles.length === 0) return false;
                      const mCreator = (m.creator || '').toLowerCase();
                      return rosterHandles.includes(mCreator) || rosterNames.includes(mCreator);
                    });

                    if (rosterMissions.length === 0) {
                      return <p className="text-xs text-slate-500 italic text-center py-4">No active campaign missions currently scheduled for your assigned creators.</p>;
                    }

                    return rosterMissions.map(m => (
                      <div key={m.id} className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-xs">{m.name}</span>
                            <span className="text-[10px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.5 rounded">{m.creator}</span>
                          </div>
                          <div className="text-[11px] text-[#7C8AA8] mt-1 flex items-center gap-3">
                            <span>Deadline: <strong className="text-white">{m.due || m.deadline || 'Aug 15, 2026'}</strong></span>
                            <span>&middot;</span>
                            <span>Deliverables: <strong className="text-slate-300">{m.completed || 0}/{m.total || 1} Done</strong></span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                            m.status === 'Accepted (On track)' || m.status === 'On track' ? 'bg-sky-500/10 text-sky-400 border-sky-500/25' :
                            m.status === 'Declined' ? 'bg-rose-500/10 text-rose-400 border-rose-500/25' :
                            m.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/25' :
                            'bg-amber-500/10 text-amber-400 border-amber-500/25'
                          }`}>
                            {m.status || 'Pending'}
                          </span>
                        </div>
                      </div>
                    ));
                  })()}
                </div>
              </div>

              {/* Coordinator Workflow & Compliance Queue */}
              <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4" style={{ backgroundColor: cardBgColor }}>
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                  <div>
                    <h3 className="font-serif font-semibold text-sm text-white">Staff Logistics &amp; Compliance Queue</h3>
                    <p className="text-xs text-[#7C8AA8]">Review pending deliverables, FTC disclosures, and campaign payment checkoffs.</p>
                  </div>
                  <span className="text-[10px] font-mono bg-white/5 text-slate-300 px-2 py-1 rounded">3 Tasks Active</span>
                </div>
                <div className="space-y-3 text-xs">
                  {[
                    { task: `Audit campaign briefs with ${activeAgentName}'s assigned talent`, date: 'July 18, 2026', checked: true },
                    { task: 'Sync with brand partner on milestone escrow disbursement', date: 'July 20, 2026', checked: false },
                    { task: 'Verify FTC compliance disclosures (#ad / #sponsored) for draft videos', date: 'July 22, 2026', checked: false }
                  ].map((t, idx) => (
                    <label key={idx} className="p-3 bg-[#111E33] border border-white/5 rounded-xl flex items-start gap-3 cursor-pointer hover:bg-[#16243F]/30 transition-colors">
                      <input type="checkbox" defaultChecked={t.checked} className="accent-[#C9A46A] mt-0.5 w-4 h-4 cursor-pointer" style={{ accentColor: primaryBrandColor }} onChange={() => triggerNotification('Task Checked', `Toggled staff workspace task compliance.`, 'success')} />
                      <div>
                        <span className="font-semibold text-white block">{t.task}</span>
                        <span className="text-[10px] text-[#7C8AA8]">Required by: {t.date}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          );
        }
      case 'agent-scoring':
        return (
          <div className="space-y-6">
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6">
              <h2 className="text-2xl font-serif text-white">Agent Performance</h2>
              <p className="text-slate-400">This module has been restored. Full metrics will resume shortly.</p>
            </div>
          </div>
        );
      default:
        return null;
    }
    })();
  };
  return renderScreenContent();

}