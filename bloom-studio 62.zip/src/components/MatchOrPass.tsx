import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform, animate } from 'motion/react';
import { 
  X, Heart, Sparkles, Shield, Share2, Copy, Check, Mail, ExternalLink, 
  RotateCcw, Send, CheckCircle2, ChevronRight, Eye, Smartphone, Lock, Briefcase, Filter, UserCheck, ShieldCheck, FileText, Image as ImageIcon, Trash2
} from 'lucide-react';
import { Creator, Deal, BrandSwipeRecord } from '../types';
import BrandTermsAgreementModal from './BrandTermsAgreementModal';
import DirectorMatchDeckManager from './DirectorMatchDeckManager';
import { db } from '../lib/firebase';
import { doc, deleteDoc } from 'firebase/firestore';
import { moveToTrash } from '../lib/trashService';
import { safeStorage } from '../utils/safeStorage';

interface MatchOrPassProps {
  creators: Creator[];
  setCreators?: React.Dispatch<React.SetStateAction<Creator[]>>;
  deals?: Deal[];
  onAddDeal?: (deal: Deal) => void;
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentUser?: any;
  currentRole?: string;
  isSneakPeekMode?: boolean;
}

const DEFAULT_NICHES = ['All niches', 'Pets', 'Beauty', 'Lifestyle'];

export default function MatchOrPass({
  creators,
  setCreators,
  deals = [],
  onAddDeal,
  onAddActivityLog,
  triggerNotification,
  currentUser,
  currentRole = 'brand',
  isSneakPeekMode = false
}: MatchOrPassProps) {
  const isDirector = currentRole === 'director' || currentRole === 'agency';
  const isBrandViewer = currentRole === 'brand' || isSneakPeekMode;
  const isAgentOrManager = currentRole === 'agent' || currentRole === ('agentmgr' as any);
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';

  // Director-controlled niche list (defaults strictly to Pets, Beauty, Lifestyle)
  const [activeNiches, setActiveNiches] = useState<string[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_discovery_niches');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_NICHES;
  });

  // Sync niches if updated in Director Dashboard
  useEffect(() => {
    const handleStorage = () => {
      try {
        const saved = safeStorage.getItem('wl_discovery_niches');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setActiveNiches(parsed);
          }
        }
      } catch (e) {}
    };

    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const [selectedNiche, setSelectedNiche] = useState<string>('All niches');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [lastDirection, setLastDirection] = useState<'left' | 'right' | null>(null);

  // Check if Brand has agreed to Platform Rules & Non-Circumvention
  const [hasAgreedTerms, setHasAgreedTerms] = useState<boolean>(() => {
    try {
      const saved = safeStorage.getItem('wl_brand_terms_accepted');
      const record = safeStorage.getItem('wl_brand_terms_record');
      return saved === 'true' || Boolean(record);
    } catch (e) {
      return false;
    }
  });

  // Modal State for Mandatory Terms
  const [termsModalOpen, setTermsModalOpen] = useState<boolean>(false);

  // Modal State for Safe Creator Deletion
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [creatorToDelete, setCreatorToDelete] = useState<Creator | null>(null);

  // Modal State for Adding Custom Creator to Swipe Deck
  const [isAddCreatorModalOpen, setIsAddCreatorModalOpen] = useState<boolean>(false);
  const [newCreatorForm, setNewCreatorForm] = useState({
    name: '',
    handle: '',
    niche: 'Beauty',
    followers: '250K',
    engagementRate: '5.2%',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    bio: 'Lifestyle & UGC Content Creator specializing in engaging product reviews.'
  });

  const handleCreateAndAddCreatorToDeck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCreatorForm.name.trim() || !newCreatorForm.handle.trim()) {
      alert('Please fill out creator name and handle.');
      return;
    }

    const created: Creator = {
      id: 'cr_' + Date.now(),
      name: newCreatorForm.name,
      handle: newCreatorForm.handle.startsWith('@') ? newCreatorForm.handle : `@${newCreatorForm.handle}`,
      avatar: newCreatorForm.avatar,
      matchOrPassPrimaryPhoto: newCreatorForm.avatar,
      niche: newCreatorForm.niche as any,
      matchOrPassFeaturedNiche: newCreatorForm.niche,
      followers: newCreatorForm.followers,
      eng: newCreatorForm.engagementRate,
      platform: 'TikTok',
      agreement: 'Non-Exclusive (70%)',
      bio: newCreatorForm.bio,
      location: 'USA',
      email: `${newCreatorForm.handle.replace('@', '')}@creator.com`,
      phone: '+1 555-0192',
      status: 'active'
    };

    if (setCreators) {
      setCreators(prev => [created, ...prev]);
    }
    setIsAddCreatorModalOpen(false);
    triggerNotification('Creator Added', `${created.name} (${created.handle}) is now in the match deck!`, 'success');
    onAddActivityLog?.(currentUser?.name || 'User', currentRole, `Added ${created.handle} to Match or Pass Deck`);
  };

  // Auto popup Platform Rules modal on brand entry if not yet signed
  useEffect(() => {
    if (isBrandViewer && !hasAgreedTerms) {
      const timer = setTimeout(() => {
        setTermsModalOpen(true);
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [isBrandViewer, hasAgreedTerms]);

  // Stored Liked Creators
  const [likedCreators, setLikedCreators] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_liked_creators');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Stored Passed IDs
  const [passedIds, setPassedIds] = useState<string[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_passed_creator_ids');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Booking / Match Modal State
  const [bookingModalOpen, setBookingModalOpen] = useState<boolean>(false);
  const [targetCreator, setTargetCreator] = useState<any>(null);
  const [targetCreatorIndex, setTargetCreatorIndex] = useState<number>(0);
  const [bookingForm, setBookingForm] = useState({
    brandName: currentUser?.name || 'Acme Global Brand',
    contactEmail: currentUser?.email || 'partnerships@brand.com',
    contactName: currentUser?.name || 'Brand Partnerships Lead',
    budget: 3500,
    platform: 'TikTok',
    deliverables: '1x 60s Dedicated TikTok Video + 30-Day Spark Ads Rights',
    brief: 'Showcase product drop with genuine unboxing and high-energy hook.',
    deadline: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]
  });

  // Sneak Peek Sharing Modal State (Director Only)
  const [shareModalOpen, setShareModalOpen] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedEmail, setCopiedEmail] = useState<boolean>(false);
  const [emailClientName, setEmailClientName] = useState<string>('Nike / LVMH Brand Team');
  const [selectedEmailTalentNiche, setSelectedEmailTalentNiche] = useState<string>('Pets, Beauty & Lifestyle');
  const [isPhotoRevealed, setIsPhotoRevealed] = useState<boolean>(false);

  useEffect(() => {
    setIsPhotoRevealed(false);
  }, [currentIndex]);

  // Server-anonymized discovery creators for anti-poaching & brand security
  const [discoveredCreators, setDiscoveredCreators] = useState<Creator[] | null>(null);

  useEffect(() => {
    if (isBrandViewer) {
      let isMounted = true;
      fetch('/api/creators/public-discovery')
        .then(res => res.json())
        .then(data => {
          if (isMounted && data && data.success && Array.isArray(data.creators)) {
            setDiscoveredCreators(data.creators);
          }
        })
        .catch(err => {
          console.warn('Failed to fetch public discovery creators:', err);
        });
      return () => { isMounted = false; };
    }
  }, [isBrandViewer]);

  // Generate anonymous creator number for anti-poaching (e.g. Creator #104)
  function getCreatorNumber(creator: any, idx: number) {
    if (!creator) return `Creator #${idx + 101}`;
    if (creator.creatorNumber) return `Creator #${creator.creatorNumber}`;
    if (creator.id) {
      const cleanNum = creator.id.toString().replace(/\D/g, '');
      if (cleanNum && cleanNum.length >= 2) {
        return `Creator #${cleanNum.slice(-3)}`;
      }
    }
    const handle = (creator.handle || creator.name || 'talent').replace(/[^a-zA-Z0-9]/g, '');
    let hash = 0;
    for (let i = 0; i < handle.length; i++) {
      hash = (hash << 5) - hash + handle.charCodeAt(i);
      hash |= 0;
    }
    const finalNum = Math.abs(hash % 900) + 100;
    return `Creator #${finalNum}`;
  }

  // Filtered pool of active creators (respects director deck toggles and active niches)
  const availableCreators = useMemo(() => {
    const sourceList = (isBrandViewer && discoveredCreators && discoveredCreators.length > 0)
      ? discoveredCreators
      : creators;

    let active = sourceList.filter(c => (c.status === 'Active' || !c.status) && c.matchOrPassActive !== false);
    
    const roleLower = (currentRole || '').toLowerCase();
    const isRestrictedStaff = ['agentmgr', 'agent', 'coordinator'].includes(roleLower);
    if (isRestrictedStaff) {
      const userName = (currentUser?.name || '').toLowerCase();
      if (userName) {
        active = active.filter(c => {
          const ag = (c.assignedAgent || (c as any).agent || '').toLowerCase();
          const mgr = (c.assignedManager || '').toLowerCase();
          const coord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
          return (
            ag.includes(userName) || userName.includes(ag) ||
            mgr.includes(userName) || userName.includes(mgr) ||
            coord.includes(userName) || userName.includes(coord) ||
            (userName.includes('marcus') && (ag.includes('marcus') || mgr.includes('marcus'))) ||
            (userName.includes('alex') && (ag.includes('alex') || coord.includes('alex')))
          );
        });
      }
    }

    // FTC & Anti-Poaching: Strict anonymization for Brand users to prevent bypass/circumvention
    if (isBrandViewer) {
      active = active.map((c, idx) => ({
        ...c,
        name: getCreatorNumber(c, idx),
        handle: `@talent_${c.id?.toString().slice(-4) || idx + 100}`,
        email: 'contact@agency.com',
        phone: 'HIDDEN'
      }));
    }

    return active.filter(c => {
      if (selectedNiche === 'All niches') return true;
      const niche = (c.matchOrPassFeaturedNiche || c.niche || '').toLowerCase();
      const target = selectedNiche.toLowerCase();

      if (target === 'pets' || target === 'pet' || target === 'pet & animals') {
        return niche.includes('pet') || niche.includes('animal') || niche.includes('dog') || niche.includes('cat');
      }
      if (target === 'beauty') {
        return niche.includes('beauty') || niche.includes('makeup') || niche.includes('skincare') || niche.includes('cosmetics');
      }
      if (target === 'lifestyle') {
        return niche.includes('lifestyle') || niche.includes('daily') || niche.includes('vlog') || niche.includes('wellness');
      }
      if (target === 'fashion') return niche.includes('fashion') || niche.includes('style');
      if (target === 'fitness') return niche.includes('fitness') || niche.includes('sports') || niche.includes('gym');
      if (target === 'tech') return niche.includes('tech') || niche.includes('gadget') || niche.includes('software');
      if (target === 'comedy') return niche.includes('comedy') || niche.includes('humor') || niche.includes('skit');
      if (target === 'gaming') return niche.includes('gaming') || niche.includes('game') || niche.includes('stream');
      
      return niche.includes(target);
    });
  }, [creators, discoveredCreators, selectedNiche, isBrandViewer, currentRole, currentUser]);

  const currentCreator = availableCreators[currentIndex] || null;
  const nextCreator = availableCreators[currentIndex + 1] || null;

  // Helper to record brand swipe into live Director telemetry feed
  const recordBrandSwipeTelemetry = (
    action: 'match' | 'pass', 
    creatorToAct: any, 
    creatorIdx: number, 
    proposedBudget?: number, 
    deliverables?: string, 
    notes?: string
  ) => {
    const creatorNum = getCreatorNumber(creatorToAct, creatorIdx);
    const newSwipe: BrandSwipeRecord = {
      id: 'swipe_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      brandName: currentUser?.name || 'Nike Global Partnerships',
      brandContactName: currentUser?.name || 'Brand Partnerships Lead',
      brandContactEmail: currentUser?.email || 'partnerships@brand.com',
      creatorId: creatorToAct.id || String(creatorIdx),
      creatorHandle: creatorToAct.handle || '@talent',
      creatorName: creatorToAct.name || 'Talent',
      creatorNumber: creatorNum,
      creatorNiche: creatorToAct.matchOrPassFeaturedNiche || creatorToAct.niche || 'Pets',
      creatorAvatar: creatorToAct.matchOrPassPrimaryPhoto || creatorToAct.avatar || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80',
      action: action,
      timestamp: Date.now(),
      dateStr: 'Today at ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timeAgo: 'Just now',
      proposedBudget: proposedBudget,
      platform: bookingForm.platform || 'TikTok',
      deliverables: deliverables,
      notes: notes,
      dealCreated: false
    };

    try {
      const existing = safeStorage.getItem('wl_brand_swipe_feed');
      const list: BrandSwipeRecord[] = existing ? JSON.parse(existing) : [];
      const updated = [newSwipe, ...list];
      safeStorage.setItem('wl_brand_swipe_feed', JSON.stringify(updated));
    } catch (e) {}
  };

  // Motion drag transforms & physics
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-240, 240], [-22, 22]);
  const passStampOpacity = useTransform(x, [-110, -35], [1, 0]);
  const likeStampOpacity = useTransform(x, [35, 110], [0, 1]);

  const isSwipingRef = useRef(false);

  const processSwipeAction = (direction: 'left' | 'right', creatorToAct: any, creatorIdx: number) => {
    if (!creatorToAct) return;
    const creatorNum = getCreatorNumber(creatorToAct, creatorIdx);

    if (direction === 'right') {
      // Like / Match
      const isAlreadyLiked = likedCreators.some(c => c.id === creatorToAct.id || c.handle === creatorToAct.handle);
      if (!isAlreadyLiked) {
        const creatorEntry = { 
          ...creatorToAct, 
          creatorNumberDisplay: creatorNum,
          likedAt: new Date().toISOString() 
        };
        const updated = [creatorEntry, ...likedCreators];
        setLikedCreators(updated);
        try {
          safeStorage.setItem('wl_liked_creators', JSON.stringify(updated));
        } catch (e) {}
      }

      // Record telemetry for director
      recordBrandSwipeTelemetry('match', creatorToAct, creatorIdx, 3500, 'Initial Right Swipe / Match Interest');

      onAddActivityLog(
        currentUser?.name || 'Brand / Client',
        currentRole,
        `❤️ MATCHED with ${creatorNum} (${creatorToAct.niche || 'Talent'}) on Discover deck`
      );

      // Open booking form modal to finalize campaign intent
      setTargetCreator(creatorToAct);
      setTargetCreatorIndex(creatorIdx);
      setBookingModalOpen(true);
    } else {
      // Pass
      const updatedPassed = [...passedIds, creatorToAct.id || creatorToAct.handle];
      setPassedIds(updatedPassed);
      try {
        safeStorage.setItem('wl_passed_creator_ids', JSON.stringify(updatedPassed));
      } catch (e) {}

      // Record telemetry for director
      recordBrandSwipeTelemetry('pass', creatorToAct, creatorIdx, undefined, undefined, 'Passed during card swipe session');

      triggerNotification(
        'Passed Talent',
        `Passed ${creatorNum}. Showing next creator in deck.`,
        'info'
      );
    }
  };

  const executeSwipe = async (direction: 'left' | 'right') => {
    if (!currentCreator || isSwipingRef.current) return;
    isSwipingRef.current = true;
    setLastDirection(direction);

    const activeCreator = currentCreator;
    const activeIdx = currentIndex;
    const flyOutX = direction === 'right' ? 550 : -550;

    // Smoothly animate card off screen
    await animate(x, flyOutX, { duration: 0.22, ease: 'easeOut' });

    // Execute state changes
    processSwipeAction(direction, activeCreator, activeIdx);

    // Advance index and reset x to 0 for next card
    setCurrentIndex(prev => prev + 1);
    x.set(0);
    isSwipingRef.current = false;
  };

  const requestDeleteCurrentCreator = () => {
    if (!currentCreator) return;
    setCreatorToDelete(currentCreator);
    setIsDeleteModalOpen(true);
  };

  const executeConfirmedDelete = async () => {
    if (!creatorToDelete) return;
    const targetId = creatorToDelete.id;
    const targetHandle = creatorToDelete.handle;
    const targetName = creatorToDelete.name || creatorToDelete.handle;

    try {
      // 1. Safe Soft-delete to 30-Day Trash Bin
      await moveToTrash('studio-creators', creatorToDelete, 'creator', currentUser);
    } catch (err: any) {
      console.error(`Error archiving creator to trash:`, err);
    }

    // 2. Remove from local custom deck creators if exists
    try {
      const savedCustomCreators = safeStorage.getItem('wl_custom_deck_creators');
      if (savedCustomCreators) {
        const map = JSON.parse(savedCustomCreators);
        delete map[targetId];
        if (targetHandle) delete map[targetHandle];
        safeStorage.setItem('wl_custom_deck_creators', JSON.stringify(map));
      }
    } catch (e) {}

    // 3. Immediately filter local state so user gets instant responsive feedback
    if (setCreators) {
      setCreators(prev => prev.filter(c => c.id !== targetId && c.handle?.toLowerCase() !== targetHandle?.toLowerCase()));
    }

    // Safely reposition or advance index if needed
    if (creators.length <= 1) {
      setCurrentIndex(0);
    }
    x.set(0);

    triggerNotification('Creator Moved to Trash', `${targetName} archived to Recoup Trash (30-day recovery window active).`, 'info');
    onAddActivityLog(currentUser?.name || 'User', currentRole, `Moved ${targetHandle} to 30-day trash bin`);
    setIsDeleteModalOpen(false);
    setCreatorToDelete(null);
  };

  const handleResetDeck = () => {
    x.set(0);
    setCurrentIndex(0);
    setLastDirection(null);
    triggerNotification('Deck Refreshed', 'Creator matchmaking deck reset to the beginning.', 'success');
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetCreator) return;

    const creatorNum = getCreatorNumber(targetCreator, targetCreatorIndex);

    const newDeal: Deal = {
      id: 'deal_match_' + Date.now(),
      brand: bookingForm.brandName,
      title: `Match Booking: ${creatorNum} × ${bookingForm.brandName}`,
      creator: targetCreator.handle,
      agent: targetCreator.assignedAgent || 'Agency Director',
      budget: Number(bookingForm.budget) || 3500,
      value: Number(bookingForm.budget) || 3500,
      amount: Number(bookingForm.budget) || 3500,
      platform: bookingForm.platform as any,
      stage: 'Lead',
      due: bookingForm.deadline || new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      dueDate: bookingForm.deadline || new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      coordinator: 'Marcus Cole',
      notes: `[Match or Pass Inbound Match]: ${bookingForm.brief} | Talent: ${creatorNum} (${targetCreator.niche}) | Deliverables: ${bookingForm.deliverables}`
    };

    if (onAddDeal) {
      onAddDeal(newDeal);
    } else {
      try {
        const storedDeals = JSON.parse(safeStorage.getItem('wl_deals') || '[]');
        safeStorage.setItem('wl_deals', JSON.stringify([newDeal, ...storedDeals]));
      } catch (err) {}
    }

    // Update telemetry feed with full booking brief
    recordBrandSwipeTelemetry(
      'match', 
      targetCreator, 
      targetCreatorIndex, 
      Number(bookingForm.budget) || 3500, 
      bookingForm.deliverables, 
      bookingForm.brief
    );

    onAddActivityLog(
      currentUser?.name || 'Brand Client',
      currentRole,
      `🚀 INBOUND CAMPAIGN BRIEF: Submitted booking match for ${creatorNum} (${targetCreator.niche}) for $${Number(bookingForm.budget).toLocaleString()}`
    );

    triggerNotification(
      'Campaign Match Requested!',
      `Your proposal to work with ${creatorNum} has been routed directly to the Agency Director. We will reach out within 2 hours.`,
      'success'
    );

    setBookingModalOpen(false);
  };

  const publicSneakPeekUrl = `${window.location.origin}/#sneak-peek`;

  const sampleEmailTemplate = `Subject: Exclusive Talent Preview: Roster Selection for ${emailClientName}

Hi ${emailClientName.split(' ')[0] || 'Team'},

We put together an interactive Sneak Peek of our represented roster creators currently available for Q3/Q4 brand campaigns:

👉 Live Interactive Talent Deck: ${publicSneakPeekUrl}

Top Available Creators in ${selectedEmailTalentNiche}:
• Verified TikTok & IG talent with over 1.8M+ combined reach
• Clean brand safety score & audited 4.5%+ engagement rates
• Full FTC compliance & escrow protection included on all deliverables

Feel free to swipe right on any creator you would like to book or reply directly to this email to lock in hold dates.

Best regards,
Agency Talent Director
Bloom Studio Enterprise Network`;

  const currentCreatorNum = currentCreator ? getCreatorNumber(currentCreator, currentIndex) : '';
  const nextCreatorNum = nextCreator ? getCreatorNumber(nextCreator, currentIndex + 1) : '';

  // Get active photo uploaded by Director or default avatar
  const currentCreatorPhoto = currentCreator 
    ? (currentCreator.matchOrPassPrimaryPhoto || currentCreator.avatar || 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80')
    : '';

  const nextCreatorPhoto = nextCreator
    ? (nextCreator.matchOrPassPrimaryPhoto || nextCreator.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80')
    : '';

  // IF USER IS A DIRECTOR: Render the Director Control & Oversight Center!
  // The director controls deck photos, talent visibility, and monitors brand match/pass activity.
  if (isDirector && !isSneakPeekMode) {
    return (
      <div id="director-match-pass-command">
        <DirectorMatchDeckManager
          creators={creators}
          setCreators={setCreators}
          deals={deals}
          onAddDeal={onAddDeal}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
          currentUser={currentUser}
          currentRole={currentRole}
          onOpenSneakPeekModal={currentRole === ('agentmgr' as any) ? undefined : () => setShareModalOpen(true)}
        />

        {/* Sneak Peek Strategy Kit Modal for Director */}
        {shareModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#081222] border border-blue-900/60 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider block">
                    Enterprise Outreach Strategy
                  </span>
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#C9A46A]" />
                    Sneak Peek Strategy Kit
                  </h3>
                </div>
                <button
                  onClick={() => setShareModalOpen(false)}
                  className="p-2 rounded-full bg-[#0D1830] text-slate-400 hover:text-white transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="text-[10px] font-mono text-slate-400 block mb-1">Public Guest Sneak Peek URL</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={publicSneakPeekUrl}
                      className="w-full bg-[#0D1830] border border-blue-900/40 rounded-xl p-2.5 text-xs text-slate-200 font-mono focus:outline-none"
                    />
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(publicSneakPeekUrl);
                        setCopiedLink(true);
                        setTimeout(() => setCopiedLink(false), 2000);
                      }}
                      className="px-4 py-2.5 rounded-xl bg-[#C9A46A] text-[#070D18] font-mono font-bold text-xs shrink-0 cursor-pointer flex items-center gap-1.5"
                    >
                      {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedLink ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Mail className="w-4 h-4 text-blue-400" />
                    Pre-Formatted Agency Pitch Email
                  </h4>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(sampleEmailTemplate);
                      setCopiedEmail(true);
                      setTimeout(() => setCopiedEmail(false), 2500);
                    }}
                    className="text-xs text-[#C9A46A] hover:underline font-mono cursor-pointer flex items-center gap-1"
                  >
                    {copiedEmail ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedEmail ? 'Copied Email!' : 'Copy Email Pitch'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-mono text-slate-400 block mb-1">Target Brand Name</label>
                    <input
                      type="text"
                      value={emailClientName}
                      onChange={e => setEmailClientName(e.target.value)}
                      className="w-full bg-[#0D1830] border border-blue-900/40 rounded-lg p-2 text-xs text-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-slate-400 block mb-1">Talent Niche Focus</label>
                    <input
                      type="text"
                      value={selectedEmailTalentNiche}
                      onChange={e => setSelectedEmailTalentNiche(e.target.value)}
                      className="w-full bg-[#0D1830] border border-blue-900/40 rounded-lg p-2 text-xs text-white focus:outline-none"
                    />
                  </div>
                </div>

                <pre className="p-4 bg-[#050A14] border border-blue-900/40 rounded-xl text-xs text-slate-300 font-mono whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto">
                  {sampleEmailTemplate}
                </pre>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    );
  }

  // BRAND VIEW: Interactive Discovery Deck with Mandatory Platform Rules Pop-up & Gate
  return (
    <div id="match-or-pass-container" className="min-h-screen bg-[#070D18] text-white p-4 md:p-8 space-y-8 font-sans relative">
      
      {/* Main Header matching user request */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-1 text-left">
          <div className="flex items-center gap-2">
            <h1 className="text-3xl md:text-4xl font-serif font-medium tracking-tight text-white">
              Discover creators
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20">
              Brand Discovery Portal
            </span>
          </div>
          <p className="text-sm text-slate-400 font-sans">
            Swipe through creators by niche — like one to start a conversation
          </p>
        </div>

        <div className="flex items-center gap-3">
          {isDirector && (
            <button
              onClick={() => setIsAddCreatorModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition shadow-lg cursor-pointer"
            >
              <Sparkles className="w-4 h-4 fill-slate-950" />
              <span>Add Creator to Deck</span>
            </button>
          )}

          {/* Platform Rules & Non-Circumvention Agreement Trigger */}
          <button
            id="brand-platform-rules-btn"
            onClick={() => setTermsModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0D1830] hover:bg-[#132347] border border-blue-900/50 hover:border-emerald-500/50 text-slate-300 hover:text-white text-xs font-mono transition cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Platform Rules &amp; Non-Circumvention</span>
            <span className="sm:hidden">Rules</span>
          </button>
        </div>
      </div>

      {/* Niche Filter Pills (Director controls active list: Pets, Beauty, Lifestyle) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-blue-900/40">
        {activeNiches.map((niche) => {
          const isSelected = selectedNiche === niche;
          return (
            <button
              key={niche}
              onClick={() => {
                setSelectedNiche(niche);
                setCurrentIndex(0);
                x.set(0);
              }}
              className={`px-4 py-2 rounded-full text-xs font-medium transition cursor-pointer whitespace-nowrap ${
                isSelected
                  ? 'bg-emerald-400 text-[#070D18] font-bold shadow-md shadow-emerald-400/20'
                  : 'bg-[#0E1B33] hover:bg-[#142647] text-slate-300 border border-white/5 hover:border-white/10'
              }`}
            >
              {niche}
            </button>
          );
        })}
      </div>

      {/* LOCKED NOTICE IF TERMS NOT YET ACCEPTED */}
      {!hasAgreedTerms && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 rounded-2xl bg-gradient-to-r from-blue-950/70 via-[#0E1A2E] to-blue-950/70 border border-emerald-500/40 text-left flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl"
        >
          <div className="flex items-start gap-3">
            <Shield className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Platform Rules &amp; Non-Circumvention Required</span>
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full uppercase">Action Required</span>
              </h4>
              <p className="text-xs text-slate-300">
                Please review and accept our 4 core platform clauses (Non-Circumvention, Proprietary Code, Security, and Compliance Oversight) to unlock the discovery deck.
              </p>
            </div>
          </div>

          <button
            onClick={() => setTermsModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-[#070D18] text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer shadow-lg shadow-emerald-500/20 shrink-0"
          >
            Review &amp; Sign Rules
          </button>
        </motion.div>
      )}

      {/* Matchmaking Deck Center Area */}
      <div className={`max-w-md mx-auto space-y-6 transition-all ${!hasAgreedTerms ? 'opacity-40 pointer-events-none filter blur-[1px]' : ''}`}>
        {/* Card Stage Container */}
        <div className="relative h-[530px] w-full flex items-center justify-center">
          
          {/* Background Card Preview (Stack effect under the top card) */}
          {nextCreator && (
            <div className="absolute inset-0 bg-[#0A1324] border border-blue-950/40 rounded-3xl p-6 flex flex-col justify-between shadow-xl scale-[0.95] translate-y-3 opacity-60 pointer-events-none select-none z-0 overflow-hidden">
              <div className="flex-1 flex items-center justify-center">
                <div className="w-40 h-40 rounded-2xl overflow-hidden bg-slate-900 border border-white/10 opacity-70">
                  <img src={nextCreatorPhoto} alt="Next talent" className="w-full h-full object-cover" />
                </div>
              </div>
              <div className="space-y-2 pt-4 border-t border-white/5 text-left">
                <h4 className="text-base font-bold text-slate-400 font-mono">
                  {nextCreatorNum}
                </h4>
                <p className="text-xs text-slate-500">{nextCreator.niche || 'Talent'}</p>
              </div>
            </div>
          )}

          {/* Top Interactive Swipe Card */}
          {currentCreator ? (
            <motion.div
              key={`${currentCreator.id || currentCreator.handle}_${currentIndex}`}
              style={{ x, rotate }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.7}
              onDragEnd={async (_, info) => {
                if (isSwipingRef.current || !hasAgreedTerms) return;
                const swipeThreshold = 70;
                const velocityThreshold = 350;

                if (info.offset.x > swipeThreshold || info.velocity.x > velocityThreshold) {
                  await executeSwipe('right');
                } else if (info.offset.x < -swipeThreshold || info.velocity.x < -velocityThreshold) {
                  await executeSwipe('left');
                } else {
                  animate(x, 0, { type: 'spring', stiffness: 500, damping: 30 });
                }
              }}
              initial={{ scale: 0.96, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 bg-[#0E1A2E] border border-blue-950/80 rounded-3xl p-6 flex flex-col justify-between shadow-2xl shadow-black/60 cursor-grab active:cursor-grabbing select-none overflow-hidden z-10 touch-none"
            >
              {/* WORK WITH / LIKE Stamp (Top-Left) */}
              <motion.div
                style={{ opacity: likeStampOpacity }}
                className="absolute top-6 left-6 border-4 border-emerald-400 text-emerald-400 font-extrabold text-lg px-4 py-1.5 rounded-xl rotate-[-18deg] tracking-widest pointer-events-none z-20 uppercase bg-emerald-950/60 backdrop-blur-sm shadow-lg"
              >
                WORK WITH
              </motion.div>

              {/* PASS Stamp (Top-Right) */}
              <motion.div
                style={{ opacity: passStampOpacity }}
                className="absolute top-6 right-6 border-4 border-rose-500 text-rose-500 font-extrabold text-lg px-4 py-1.5 rounded-xl rotate-[18deg] tracking-widest pointer-events-none z-20 uppercase bg-rose-950/60 backdrop-blur-sm shadow-lg"
              >
                PASS
              </motion.div>

              {/* Director-Uploaded Picture & Visual Area with Anti-Poaching Privacy Veil */}
              <div 
                onClick={() => setIsPhotoRevealed(true)}
                className="flex-1 flex flex-col items-center justify-center relative overflow-hidden rounded-2xl bg-[#081222] border-2 border-white/5 cursor-pointer group"
                title={isPhotoRevealed ? "Photo unmasked" : "Click to reveal creator identity (Anti-Poaching Protection)"}
              >
                <img 
                  src={currentCreatorPhoto} 
                  alt="Creator photo" 
                  className={`w-full h-full object-cover transition-all duration-500 ${isPhotoRevealed ? '' : 'filter blur-2xl grayscale-[30%] scale-105 opacity-80'}`}
                />

                {/* Subtle gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0E1A2E] via-transparent to-black/40 pointer-events-none" />

                {!isPhotoRevealed && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-md flex flex-col items-center justify-center p-4 text-center space-y-2.5 z-10 transition group-hover:bg-black/50">
                    <div className="w-12 h-12 rounded-full bg-[#C9A46A]/20 border border-[#C9A46A]/50 flex items-center justify-center text-[#C9A46A] shadow-lg">
                      <Shield className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-white font-mono block tracking-wide">Anti-Poaching Identity Veil</span>
                      <span className="text-[10px] text-slate-300 font-mono block">Click photo to reveal verified talent photo</span>
                    </div>
                  </div>
                )}

                {/* Top Badge: Anonymous Creator Number */}
                <div className="absolute top-3 left-3 flex items-center gap-2 z-20">
                  <span className="px-3 py-1 rounded-full bg-black/70 backdrop-blur-md text-[#C9A46A] font-mono text-xs font-bold border border-[#C9A46A]/40 shadow-lg">
                    {currentCreatorNum}
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/30">
                    {currentCreator.matchOrPassFeaturedNiche || currentCreator.niche || 'Pets'}
                  </span>
                </div>

                {/* Bottom Overlay Tagline */}
                {currentCreator.matchOrPassTagline && (
                  <div className="absolute bottom-2 inset-x-3 text-left z-20">
                    <p className="text-xs text-white/90 font-mono bg-black/70 backdrop-blur-sm p-1.5 rounded-lg border border-white/10 truncate">
                      {currentCreator.matchOrPassTagline}
                    </p>
                  </div>
                )}
              </div>

              {/* Bottom Details Section */}
              <div className="space-y-3 pt-3 border-t border-white/5 text-left">
                <div>
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-white tracking-tight font-mono">
                      {currentCreatorNum}
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      Verified Roster
                    </span>
                  </div>
                  <p className="text-xs font-medium text-[#C9A46A] mt-0.5">
                    {currentCreator.matchOrPassFeaturedNiche || currentCreator.niche || 'Pets, Beauty & Lifestyle'}
                  </p>
                </div>

                {/* Reach & Engagement Stat Tiles */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#081222] border border-white/5 rounded-xl p-2.5">
                    <span className="text-[10px] font-mono font-bold tracking-wider text-slate-500 uppercase block mb-0.5">
                      REACH
                    </span>
                    <span className="text-base font-bold text-white font-mono">
                      {currentCreator.followers || '1.8M'}
                    </span>
                  </div>

                  <div className="bg-[#081222] border border-white/5 rounded-xl p-2.5">
                    <span className="text-[10px] font-mono font-bold tracking-wider text-slate-500 uppercase block mb-0.5">
                      ENGAGEMENT
                    </span>
                    <span className="text-base font-bold text-emerald-400 font-mono">
                      {currentCreator.eng || '4.1%'}
                    </span>
                  </div>
                </div>

                {/* Privacy & Contact protection notice */}
                <div className="flex items-center gap-2 text-[11px] text-slate-400 leading-snug">
                  <Shield className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  <span>Contact details shared only through the agency once matched</span>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="inset-0 w-full h-full bg-[#0E1A2E] border border-blue-950/80 rounded-3xl p-8 flex flex-col items-center justify-center text-center space-y-4 shadow-2xl"
            >
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">You're All Caught Up!</h3>
                <p className="text-xs text-slate-400 max-w-xs">
                  You've reviewed all available talent in the <strong>{selectedNiche}</strong> category.
                </p>
              </div>
              <button
                onClick={handleResetDeck}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#081222] hover:bg-[#132347] border border-blue-900 text-slate-200 hover:text-white text-xs font-mono font-semibold transition cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-[#C9A46A]" />
                <span>Start Deck Over</span>
              </button>
            </motion.div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col items-center gap-3 pt-2">
          <div className="flex items-center justify-center gap-8">
            {/* PASS (Left X) Button */}
            <button
              id="swipe-pass-btn"
              disabled={!currentCreator || !hasAgreedTerms}
              onClick={() => executeSwipe('left')}
              className="w-16 h-16 rounded-full bg-[#0E1A2E] hover:bg-rose-950/40 border border-slate-700 hover:border-rose-500/60 flex items-center justify-center text-slate-400 hover:text-rose-400 transition-all cursor-pointer shadow-lg shadow-black/40 disabled:opacity-30 disabled:cursor-not-allowed group active:scale-95"
              title="Pass (Swipe Left)"
            >
              <X className="w-7 h-7 group-hover:scale-110 transition-transform" />
            </button>

            {/* LIKE / WORK WITH (Right Heart) Button */}
            <button
              id="swipe-like-btn"
              disabled={!currentCreator || !hasAgreedTerms}
              onClick={() => executeSwipe('right')}
              className="w-16 h-16 rounded-full bg-[#0E1A2E] hover:bg-emerald-950/40 border-2 border-emerald-500/50 hover:border-emerald-400 flex items-center justify-center text-emerald-400 hover:text-emerald-300 transition-all cursor-pointer shadow-lg shadow-emerald-950/30 disabled:opacity-30 disabled:cursor-not-allowed group active:scale-95"
              title="Work With Creator (Swipe Right)"
            >
              <Heart className="w-7 h-7 fill-emerald-400/20 group-hover:fill-emerald-400 group-hover:scale-110 transition-all" />
            </button>
          </div>

          {/* Director Deck Management Controls (Safely separated from swipe actions) */}
          {isDirector && currentCreator && (
            <button
              id="swipe-delete-btn"
              onClick={requestDeleteCurrentCreator}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/20 hover:bg-rose-950/50 border border-rose-500/20 hover:border-rose-500/40 text-rose-400 hover:text-rose-300 text-xs font-mono transition-colors cursor-pointer"
              title="Archive this creator to 30-Day Recoup Trash"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Archive Creator Card (30-Day Trash)</span>
            </button>
          )}
        </div>

        {/* HOW THIS WORKS Card */}
        <div className="bg-[#081222] border border-blue-950 rounded-2xl p-5 text-left space-y-3">
          <h4 className="text-[11px] font-mono font-bold tracking-wider text-slate-400 uppercase">
            HOW THIS WORKS
          </h4>
          <div className="space-y-2 text-xs text-slate-300">
            <div className="flex items-start gap-3">
              <span className="text-slate-400 text-sm">↰</span>
              <span>Swipe or click <strong>left</strong> to pass</span>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-emerald-400 text-sm">♡</span>
              <span>Swipe or click <strong>right</strong> to like — we'll reach out to line up your campaign</span>
            </div>
          </div>
        </div>

        {/* CREATORS YOU'VE LIKED Card */}
        <div className="bg-[#081222] border border-blue-950 rounded-2xl p-5 text-left space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-[11px] font-mono font-bold tracking-wider text-slate-400 uppercase">
              CREATORS YOU'VE LIKED ({likedCreators.length})
            </h4>
            {likedCreators.length > 0 && (
              <button
                onClick={() => {
                  setLikedCreators([]);
                  safeStorage.removeItem('wl_liked_creators');
                }}
                className="text-[10px] font-mono text-slate-500 hover:text-slate-400 transition cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>

          {likedCreators.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-2">
              None yet — start swiping
            </p>
          ) : (
            <div className="space-y-2 pt-1 max-h-60 overflow-y-auto pr-1">
              {likedCreators.map((c, i) => {
                const displayName = c.creatorNumberDisplay || getCreatorNumber(c, i);

                return (
                  <div
                    key={c.id || c.handle || i}
                    className="p-3 bg-[#0D1830] border border-blue-950/60 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <Heart className="w-4 h-4 fill-emerald-400" />
                      </div>
                      <div>
                        <div className="font-bold text-white font-mono">{displayName}</div>
                        <div className="text-[10px] text-[#C9A46A]">{c.niche || 'Talent'} • {c.followers || '1M'}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setTargetCreator(c);
                        setTargetCreatorIndex(i);
                        setBookingModalOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-[#070D18] font-mono text-[11px] font-bold uppercase cursor-pointer"
                    >
                      Book Deal
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* BOOKING / MATCH PROPOSAL FORM MODAL */}
      {bookingModalOpen && targetCreator && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#081222] border border-blue-900/60 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="space-y-0.5">
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                  Match Liked • Start Conversation
                </span>
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Heart className="w-5 h-5 text-emerald-400 fill-emerald-400" />
                  Work with {getCreatorNumber(targetCreator, targetCreatorIndex)}
                </h3>
              </div>
              <button
                onClick={() => setBookingModalOpen(false)}
                className="p-2 rounded-full bg-[#0D1830] text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitBooking} className="space-y-4 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-1">Your Brand / Organization</label>
                <input
                  type="text"
                  required
                  value={bookingForm.brandName}
                  onChange={e => setBookingForm(prev => ({ ...prev, brandName: e.target.value }))}
                  className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Contact Name</label>
                  <input
                    type="text"
                    required
                    value={bookingForm.contactName}
                    onChange={e => setBookingForm(prev => ({ ...prev, contactName: e.target.value }))}
                    className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Official Brand Email</label>
                  <input
                    type="email"
                    required
                    value={bookingForm.contactEmail}
                    onChange={e => setBookingForm(prev => ({ ...prev, contactEmail: e.target.value }))}
                    className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Target Budget ($ USD)</label>
                  <input
                    type="number"
                    min="500"
                    step="250"
                    required
                    value={bookingForm.budget}
                    onChange={e => setBookingForm(prev => ({ ...prev, budget: Number(e.target.value) }))}
                    className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Primary Platform</label>
                  <select
                    value={bookingForm.platform}
                    onChange={e => setBookingForm(prev => ({ ...prev, platform: e.target.value }))}
                    className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="TikTok">TikTok</option>
                    <option value="Instagram">Instagram</option>
                    <option value="YouTube">YouTube</option>
                    <option value="Multi-Platform">Multi-Platform</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Deliverables &amp; Usage</label>
                <input
                  type="text"
                  required
                  value={bookingForm.deliverables}
                  onChange={e => setBookingForm(prev => ({ ...prev, deliverables: e.target.value }))}
                  placeholder="e.g. 1x 60s Dedicated Reel + 30-Day Spark Ads Rights"
                  className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Brief Summary / Campaign Goal</label>
                <textarea
                  rows={3}
                  required
                  value={bookingForm.brief}
                  onChange={e => setBookingForm(prev => ({ ...prev, brief: e.target.value }))}
                  placeholder="Describe your target product, campaign timing, and main creative hook..."
                  className="w-full bg-[#0D1830] border border-blue-900/50 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A] resize-none"
                />
              </div>

              <div className="p-3.5 bg-blue-950/40 border border-blue-800/40 rounded-xl text-[11px] text-slate-300 space-y-1">
                <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Platform Protection &amp; Escrow Guarantee</span>
                </div>
                <p className="text-slate-400 leading-relaxed font-sans">
                  By submitting this match, our agency talent director receives your proposal immediately. Direct negotiation, contract generation, and deliverables are protected under your signed Non-Circumvention Agreement.
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setBookingModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-[#0D1830] hover:bg-[#132347] text-slate-400 hover:text-white transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-[#070D18] font-bold uppercase tracking-wider transition cursor-pointer shadow-lg shadow-emerald-500/20"
                >
                  Submit Campaign Match
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* ADD CREATOR TO MATCH DECK MODAL */}
      {isAddCreatorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0b1320] border border-emerald-500/40 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl animate-fade-in text-left">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                Add Custom Creator to Swipe Deck
              </h3>
              <button
                onClick={() => setIsAddCreatorModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAndAddCreatorToDeck} className="space-y-3">
              <div>
                <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">Creator Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Maya Lin"
                  value={newCreatorForm.name}
                  onChange={e => setNewCreatorForm(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">Social Handle</label>
                  <input
                    type="text"
                    required
                    placeholder="@mayalin"
                    value={newCreatorForm.handle}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, handle: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">Niche Category</label>
                  <select
                    value={newCreatorForm.niche}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, niche: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Beauty">Beauty</option>
                    <option value="Lifestyle">Lifestyle</option>
                    <option value="Pets">Pets</option>
                    <option value="Tech">Tech</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Fitness">Fitness</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">Followers Reach</label>
                  <input
                    type="text"
                    placeholder="e.g. 450K"
                    value={newCreatorForm.followers}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, followers: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">Engagement Rate</label>
                  <input
                    type="text"
                    placeholder="e.g. 6.8%"
                    value={newCreatorForm.engagementRate}
                    onChange={e => setNewCreatorForm(prev => ({ ...prev, engagementRate: e.target.value }))}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">Photo Image URL</label>
                <input
                  type="text"
                  value={newCreatorForm.avatar}
                  onChange={e => setNewCreatorForm(prev => ({ ...prev, avatar: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono font-bold uppercase text-slate-400 mb-1">Short Bio</label>
                <textarea
                  rows={2}
                  value={newCreatorForm.bio}
                  onChange={e => setNewCreatorForm(prev => ({ ...prev, bio: e.target.value }))}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsAddCreatorModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-mono text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase tracking-wider cursor-pointer shadow-lg"
                >
                  Add Creator To Deck
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATOR DECK ARCHIVE CONFIRMATION MODAL */}
      {isDeleteModalOpen && creatorToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#0B1424] border border-rose-500/40 rounded-3xl p-6 max-w-md w-full space-y-5 shadow-2xl shadow-black/90">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-rose-400">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Archive Creator to Trash?</h3>
                <p className="text-xs text-slate-400">Confirmation required before removal from match deck</p>
              </div>
            </div>

            <div className="p-4 bg-[#111E33] border border-white/5 rounded-2xl flex items-center gap-3">
              <img
                src={creatorToDelete.avatar || creatorToDelete.matchOrPassPrimaryPhoto || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80'}
                alt={creatorToDelete.name}
                className="w-12 h-12 rounded-xl object-cover border border-white/10"
              />
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-bold text-white truncate">{creatorToDelete.name}</h4>
                <p className="text-xs font-mono text-emerald-400 truncate">{creatorToDelete.handle}</p>
                <span className="text-[10px] text-slate-400 font-mono uppercase">{creatorToDelete.niche || 'Talent'}</span>
              </div>
            </div>

            <div className="p-3.5 bg-blue-950/40 border border-blue-900/40 rounded-xl space-y-1 text-xs text-slate-300">
              <p className="font-semibold text-slate-200">Safety &amp; Recovery Guarantee:</p>
              <p className="text-[11px] text-slate-400">
                This creator will be safely archived to the <strong>30-Day Recoup Trash Bin</strong>. All associated contracts, W-9 tax data, and earnings history remain intact and can be restored at any time within 30 days.
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsDeleteModalOpen(false);
                  setCreatorToDelete(null);
                }}
                className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded-xl text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeConfirmedDelete}
                className="flex-1 py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-rose-600/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Confirm Move to Trash</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MANDATORY BRAND ONBOARDING PLATFORM RULES MODAL */}
      <BrandTermsAgreementModal
        isOpen={termsModalOpen}
        onClose={() => setTermsModalOpen(false)}
        currentUser={currentUser}
        currentRole={currentRole}
        onAgreed={(record) => {
          setHasAgreedTerms(true);
          onAddActivityLog(
            record.signedBy,
            currentRole,
            `⚖️ Electronic Signature Verified: Platform Rules & Non-Circumvention Agreement [${record.hash}]`
          );
          triggerNotification(
            'Terms Acknowledged & Logged',
            `Signed Platform Non-Circumvention Agreement. Hash: ${record.hash}`,
            'success'
          );
        }}
      />
    </div>
  );
}
