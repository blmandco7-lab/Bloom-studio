import React, { useState, useMemo } from 'react';
import {
  FileText,
  Lock,
  Mail,
  Shield,
  CheckCircle,
  Clock,
  AlertTriangle,
  Search,
  Plus,
  Trash2,
  Download,
  Eye,
  Send,
  UserCheck,
  Building,
  Key,
  Calendar,
  DollarSign,
  Copy,
  ExternalLink,
  ChevronDown,
  X,
  FileCheck,
  ShieldCheck,
  Check,
  Paperclip,
  RefreshCw,
  Award
} from 'lucide-react';
import { Contract, Creator, ContractEmailDispatch } from '../types';
import { auditContractExpirations, activeContractVault, AuditableContract } from '../lib/complianceAudit';
import MultiFilePdfViewerModal, { ViewableFile } from './DocumentViewerModal';
import { generateSecureToken, generateSecurePinCode } from '../utils/cryptoUtils';
import { checkBrandBlacklist } from '../lib/blacklistService';

interface ContractsVaultProps {
  contracts: Contract[];
  stagedContracts: any[];
  creators: Creator[];
  currentRole: string;
  currentUser: any;
  isRestrictedRole?: boolean;
  onSaveContract: (contract: Contract) => void;
  onDeleteContract: (contractId: string) => void;
  onStageContract: (staged: any) => void;
  onDeleteStagedContract: (stagedId: string) => void;
  onUpdateCreatorAgreement?: (creatorId: string, agreement: string, agreementType: string, scope?: string) => void;
  onNotify?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'error') => void;
  onTriggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'error') => void;
  onAddActivityLog: (user: string, role: string, action: string) => void;
  initialTab?: 'repository' | 'exclusivity' | 'staged' | 'outbox' | 'security';
}

// Generate realistic SHA-256 verification hash
function generateSha256Hash(id: string, party: string): string {
  let hash = 0;
  const str = `${id}-${party}-bloom-vault-secure-sha256-signature`;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return `0x${hex}7f8a9e1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f`.slice(0, 64);
}

export const ContractsVault: React.FC<ContractsVaultProps> = ({
  contracts,
  stagedContracts,
  creators,
  currentRole,
  currentUser,
  isRestrictedRole = false,
  onSaveContract,
  onDeleteContract,
  onStageContract,
  onDeleteStagedContract,
  onUpdateCreatorAgreement,
  onNotify,
  onTriggerNotification,
  onAddActivityLog,
  initialTab = 'repository'
}) => {
  const notify = onNotify || onTriggerNotification || ((t: string, m: string) => console.log(t, m));
  const [activeTab, setActiveTab] = useState<'repository' | 'staged' | 'outbox' | 'security'>(initialTab === 'exclusivity' ? 'repository' : (initialTab as any) || 'repository');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [exclusivityFilter, setExclusivityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modals
  const [showNewContractModal, setShowNewContractModal] = useState(false);
  const [selectedContractForView, setSelectedContractForView] = useState<Contract | null>(null);
  const [selectedContractForEmail, setSelectedContractForEmail] = useState<Contract | null>(null);
  const [showQuickExclusivityModal, setShowQuickExclusivityModal] = useState(false);
  const [selectedCreatorForExclusivity, setSelectedCreatorForExclusivity] = useState<Creator | null>(null);

  // Email Dispatch State
  const [emailRecipient, setEmailRecipient] = useState('');
  const [emailRecipientName, setEmailRecipientName] = useState('');
  const [emailRecipientRole, setEmailRecipientRole] = useState('Talent');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailCoverNote, setEmailCoverNote] = useState('');
  const [emailRequirePin, setEmailRequirePin] = useState(false);
  const [emailPinCode, setEmailPinCode] = useState('');
  const [emailExpireDays, setEmailExpireDays] = useState('14');
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  // New Contract Form State
  const [newContractCategory, setNewContractCategory] = useState<'Talent Representation' | 'Agent Manager Agreement' | 'Brand Deal / UGC' | 'NDA / Confidentiality' | 'MSA / Agency' | 'One-Time Deal' | 'Flat Fee Deal'>('Talent Representation');
  const [newContractExclusivity, setNewContractExclusivity] = useState<'Exclusive' | 'Non-Exclusive' | 'One-Time' | 'Flat Fee' | 'Co-Representation' | 'Retainer' | 'Commission Override'>('Exclusive');
  const [newContractParty, setNewContractParty] = useState('');
  const [newContractPartyEmail, setNewContractPartyEmail] = useState('');
  const [newContractTitle, setNewContractTitle] = useState('');
  const [newContractSplit, setNewContractSplit] = useState('80% Creator / 20% Agency');
  const [customAgencyPercentage, setCustomAgencyPercentage] = useState<number>(15);
  const [customFlatFeeAmount, setCustomFlatFeeAmount] = useState<string>('$500 Flat Agency Fee');
  const [newContractStartDate, setNewContractStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [newContractEndDate, setNewContractEndDate] = useState(
    new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [newContractScope, setNewContractScope] = useState('Full Commercial Sponsorships & Direct UGC Deals');
  const [newContractTerms, setNewContractTerms] = useState('Standard 12-month representation terms with 30-day non-renewal written notice.');
  const [newContractValue, setNewContractValue] = useState('');
  const [newContractAutoRenew, setNewContractAutoRenew] = useState(true);
  const [attachedFileName, setAttachedFileName] = useState('');

  // Agent Manager Specific Form State
  const [newContractAgentRole, setNewContractAgentRole] = useState('Agent manager');
  const [newContractCommissionOverride, setNewContractCommissionOverride] = useState('15% Override on Managed Roster');
  const [newContractBaseSalary, setNewContractBaseSalary] = useState('$5,000 / Month Retainer');
  const [newContractIsDualSigned, setNewContractIsDualSigned] = useState(false);
  const [newContractDualCreatorHandle, setNewContractDualCreatorHandle] = useState('');
  const [newContractDualCreatorSplit, setNewContractDualCreatorSplit] = useState('80% Creator / 20% Agency');

  // Quick Exclusivity Editor Form State
  const [quickAgreementType, setQuickAgreementType] = useState('Exclusive');
  const [quickSplit, setQuickSplit] = useState('80%');
  const [quickScope, setQuickScope] = useState('Full Commercial Representation');
  const [quickCustomLabel, setQuickCustomLabel] = useState('');

  // Role permissions
  const normRole = (currentRole || '').toLowerCase();
  const isAgentMgr = normRole === 'agentmgr' || normRole.includes('manager');
  const isAgentUser = normRole === 'agent' || normRole.includes('agent');
  const isCoordinator = normRole === 'coordinator' || normRole.includes('coord');
  const isWhiteLabelOrSub = normRole.includes('white') || normRole.includes('whitelabel') || normRole.includes('sub') || normRole.includes('affiliate');
  const isCreator = currentRole === 'creator' || currentUser?.role === 'creator' || currentUser?.isCreator === true || (isRestrictedRole && !!(currentUser?.handle || currentUser?.creatorId));
  const isBrand = currentRole === 'brand' || currentUser?.role === 'brand';
  const isPlatformOwner = Boolean(currentUser?.isPlatformOwner);
  const isDirector = !isCreator && !isBrand && (normRole === 'director' || currentUser?.role === 'director' || isPlatformOwner);
  const isStaffRestricted = (isAgentMgr || isAgentUser || isCoordinator || isWhiteLabelOrSub || Boolean(isRestrictedRole)) && !isDirector;
  const isAgent = !isCreator && !isBrand && isStaffRestricted;

  // Multi-File and PDF Viewer Modal State
  const [docViewerOpen, setDocViewerOpen] = useState(false);
  const [docViewerFiles, setDocViewerFiles] = useState<ViewableFile[]>([]);
  const [docViewerTitle, setDocViewerTitle] = useState('Document Preview');

  // Resolve matching creator profile
  const matchingCreator = useMemo(() => {
    if (!isCreator) return null;
    const userHandle = (currentUser?.handle || '').toLowerCase().replace('@', '').trim();
    const userEmail = (currentUser?.email || '').toLowerCase().trim();
    const userName = (currentUser?.name || '').toLowerCase().trim();
    const userId = currentUser?.id || currentUser?.id || currentUser?.creatorId;

    return creators.find(c => 
      (userId && (c.id === userId || c.id === userId)) ||
      (userHandle && c.handle?.toLowerCase().replace('@', '').trim() === userHandle) ||
      (userEmail && c.email?.toLowerCase().trim() === userEmail) ||
      (userName && c.name?.toLowerCase().trim() === userName)
    ) || null;
  }, [isCreator, currentUser, creators]);

  // Creator Handle filter for strict ABAC
  const myHandle = (currentUser?.handle || matchingCreator?.handle || '').toLowerCase().replace('@', '').trim();
  const myEmail = (currentUser?.email || matchingCreator?.email || '').toLowerCase().trim();
  const myName = (currentUser?.name || matchingCreator?.name || '').toLowerCase().trim();
  const myId = (currentUser?.id || currentUser?.id || currentUser?.creatorId || matchingCreator?.id || '').toLowerCase().trim();

  // Helper to test if a contract belongs to the current creator
  const isMatchingCreatorContract = (cnt: Contract): boolean => {
    // 1. Direct creator ID match
    if (myId && cnt.creatorId && cnt.creatorId.toLowerCase() === myId) return true;
    
    // 2. Direct creator handle match
    const cntHandle = (cnt.creatorHandle || '').toLowerCase().replace('@', '').trim();
    if (myHandle && cntHandle && cntHandle === myHandle) return true;

    // 3. Exact email match
    const email = (cnt.partyEmail || (cnt as any).email || '').toLowerCase().trim();
    if (myEmail && email && email === myEmail) return true;

    // 4. Exact matchingCreator record checks
    if (matchingCreator) {
      const cId = (matchingCreator.id || '').toLowerCase().trim();
      const cHandle = (matchingCreator.handle || '').toLowerCase().replace('@', '').trim();
      const cEmail = (matchingCreator.email || '').toLowerCase().trim();
      const cName = (matchingCreator.name || '').toLowerCase().trim();

      if (cId && cnt.creatorId && cnt.creatorId.toLowerCase() === cId) return true;
      if (cHandle && cntHandle && cntHandle === cHandle) return true;
      if (cEmail && email && email === cEmail) return true;

      const party = (cnt.party || cnt.name || '').toLowerCase().trim();
      if (cHandle && party.includes(`@${cHandle}`)) return true;
      if (cName && (party === cName || party.startsWith(`${cName} (`))) return true;
    }

    const party = (cnt.party || cnt.name || '').toLowerCase().trim();
    if (myHandle && party.includes(`@${myHandle}`)) return true;
    if (myName && (party === myName || party.startsWith(`${myName} (`))) return true;

    return false;
  };

  // Base Scoped Contracts for the active role (Strictly creator's own contract if creator, or staff member's scoped contracts)
  const scopedBaseContracts = useMemo(() => {
    if (isCreator) {
      const directMatches = contracts.filter(isMatchingCreatorContract);
      const hasRep = directMatches.some(m => m.agreementCategory === 'Talent Representation' || m.type?.includes('Representation') || m.type?.includes('Management'));

      // Synthesize official personal representation contract if not already present
      if (!hasRep) {
        const cName = matchingCreator?.name || currentUser?.name || 'Talent Member';
        const cHandle = matchingCreator?.handle || currentUser?.handle || (myHandle ? `@${myHandle}` : '@creator');
        const cSplit = matchingCreator?.commissionSplit || '80% Creator / 20% Agency Split';
        const cTier = matchingCreator?.tier || 'Tier 1 Talent';
        const cAgreement = matchingCreator?.agreement || 'Exclusive Talent Representation';
        const cAgreementType = matchingCreator?.agreementType || 'Exclusive';
        const cScope = matchingCreator?.exclusivityScope || 'Full Commercial Representation, Brand Endorsements & UGC Deliverables';

        const repContract: Contract = {
          id: `cnt_${(myHandle || 'talent').replace(/[^a-z0-9]/gi, '_')}_rep`,
          party: `${cName} (${cHandle})`,
          partyEmail: matchingCreator?.email || currentUser?.email || 'talent@bloom.co',
          creatorId: matchingCreator?.id || currentUser?.id || 'talent_1',
          creatorHandle: cHandle,
          name: `${cName} Representation Agreement`,
          title: `${cAgreement} • ${cTier}`,
          type: cAgreement,
          agreementCategory: 'Talent Representation',
          exclusivityType: cAgreementType as any,
          exclusivityScope: cScope,
          start: '2026-01-01',
          end: '2027-01-01',
          signedDate: '2026-01-01',
          expiryDate: '2027-01-01',
          terms: `${cSplit}. Commercial rights, brand deal pitching, campaign invoicing, and escrow management executed under Bloom & Co.`,
          revenueSplit: cSplit,
          status: 'Active',
          autoRenew: true,
          renewalNoticeDays: 30,
          governingLaw: 'State of California / Entertainment Standard',
          fullText: `AGENCY REPRESENTATION AND MANAGEMENT AGREEMENT\n\nThis Agreement is entered into between Bloom & Co. ("Agency") and ${cName} ("Talent").\n\n1. SCOPE OF REPRESENTATION: Agency is granted ${cAgreementType} authority to represent Talent for commercial brand sponsorships, integrations, and UGC content.\n2. COMMISSION & REVENUE SPLIT: All net earnings shall be remitted as follows: ${cSplit}.\n3. TERM & TERMINATION: Active for 12 months with automatic annual renewal unless 30-day written notice is provided.\n4. FIDUCIARY ESCROW: Agency maintains all brand campaign deposits in verified escrow prior to deliverable release.\n\n[Cryptographically Sealed & Encrypted in Legal Vault]`,
          securityHash: generateSha256Hash(`cnt_${cHandle}`, cName)
        };

        return [repContract, ...directMatches];
      }

      return directMatches;
    }

    const isStaffRole = isStaffRestricted;
    const isDirectorRole = isDirector;

    if (isStaffRole && !isDirectorRole) {
      const activeStaffName = (currentUser?.name || 'Marcus Cole').toLowerCase();
      const activeStaffHandle = (currentUser?.handle || '').toLowerCase();

      // Find creators assigned to this staff member
      const myAssignedCreators = (creators || []).filter((c: any) =>
        (c.assignedAgent || '').toLowerCase() === activeStaffName ||
        (c.assignedManager || '').toLowerCase() === activeStaffName ||
        (c.assignedCoordinator || '').toLowerCase() === activeStaffName ||
        (c.coordinator || '').toLowerCase() === activeStaffName
      );
      const myCreatorHandles = myAssignedCreators.map((c: any) => (c.handle || '').toLowerCase());
      const myCreatorNames = myAssignedCreators.map((c: any) => (c.name || '').toLowerCase());

      return contracts.filter(cnt => {
        // Agency-signed internal contracts, Master Agency Agreements, MSA/Agency, and MCN umbrella contracts are completely hidden from agents/managers/coordinators/sub-agencies
        if (cnt.agreementCategory === 'MSA / Agency' || cnt.type === 'Master Services Agreement' || cnt.type === 'Agency Master' || cnt.type === 'Agency Representation Agreement') {
          return false;
        }

        // Hide other agent managers' internal operating agreements
        if (cnt.isAgentManagerContract || cnt.agreementCategory === 'Agent Manager Agreement' || cnt.type === 'Agent Manager Agreement') {
          const partnerLower = (cnt.partner || '').toLowerCase();
          const agentNameLower = (cnt.agentName || '').toLowerCase();
          return partnerLower.includes(activeStaffName) || agentNameLower.includes(activeStaffName);
        }

        // Include agreements for their assigned creators
        const partyLower = (cnt.party || cnt.name || '').toLowerCase();
        const handleLower = (cnt.creatorHandle || '').toLowerCase();
        if (myCreatorHandles.some(h => partyLower.includes(h) || handleLower.includes(h))) return true;
        if (myCreatorNames.some(n => partyLower.includes(n))) return true;

        // Include agreements where this staff is explicitly designated
        if ((cnt.agentName || '').toLowerCase() === activeStaffName) return true;
        if (activeStaffHandle && (partyLower.includes(activeStaffHandle) || handleLower.includes(activeStaffHandle))) return true;

        return false;
      });
    }

    return contracts;
  }, [isCreator, contracts, matchingCreator, currentUser, myHandle, myEmail, myName, myId, currentRole, creators, isStaffRestricted, isDirector]);

  // Filtered Contracts for display
  const filteredContracts = useMemo(() => {
    if (isCreator) {
      return scopedBaseContracts;
    }
    return scopedBaseContracts.filter(cnt => {
      // Brand strict isolation
      if (isBrand) {
        const brand = (cnt.brandName || cnt.party || '').toLowerCase();
        const email = (cnt.brandEmail || cnt.partyEmail || '').toLowerCase();
        const myBrandName = (currentUser?.name || '').toLowerCase();
        const match = (myBrandName && brand.includes(myBrandName)) || (myEmail && email === myEmail);
        if (!match) return false;
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const party = (cnt.party || cnt.name || '').toLowerCase();
        const title = (cnt.title || cnt.type || '').toLowerCase();
        const terms = (cnt.terms || '').toLowerCase();
        const id = (cnt.id || '').toLowerCase();
        const hash = (cnt.securityHash || '').toLowerCase();
        if (!party.includes(q) && !title.includes(q) && !terms.includes(q) && !id.includes(q) && !hash.includes(q)) {
          return false;
        }
      }

      // Category Filter
      if (categoryFilter !== 'all') {
        const cat = cnt.agreementCategory || (cnt.type.includes('Talent') ? 'Talent Representation' : 'Brand Deal / UGC');
        if (cat !== categoryFilter) return false;
      }

      // Exclusivity Filter
      if (exclusivityFilter !== 'all') {
        const val = exclusivityFilter.toLowerCase();
        const typeStr = (cnt.type || '').toLowerCase();
        const exclStr = (cnt.exclusivityType || '').toLowerCase();
        const catStr = (cnt.agreementCategory || '').toLowerCase();

        if (val === 'exclusive') {
          if (!(exclStr.includes('exclusive') && !exclStr.includes('non-')) && !(typeStr.includes('exclusive') && !typeStr.includes('non-'))) return false;
        } else if (val === 'non-exclusive') {
          if (!exclStr.includes('non-exclusive') && !typeStr.includes('non-exclusive')) return false;
        } else if (val === 'single-project' || val === 'one-time') {
          if (!exclStr.includes('one-time') && !typeStr.includes('one-time') && !typeStr.includes('single') && !catStr.includes('one-time')) return false;
        } else {
          const excl = cnt.exclusivityType || (
            typeStr.includes('exclusive') && !typeStr.includes('non-') ? 'Exclusive' :
            typeStr.includes('non-exclusive') ? 'Non-Exclusive' :
            typeStr.includes('one-time') ? 'One-Time' :
            typeStr.includes('co-') ? 'Co-Representation' : 'Retainer'
          );
          if (excl.toLowerCase() !== val) return false;
        }
      }

      // Status Filter
      if (statusFilter !== 'all') {
        if ((cnt.status || 'Active').toLowerCase() !== statusFilter.toLowerCase()) return false;
      }

      return true;
    });
  }, [scopedBaseContracts, isCreator, isBrand, myEmail, currentUser, searchQuery, categoryFilter, exclusivityFilter, statusFilter]);

  // Scoped Staged Contracts for Creator
  const scopedStagedContracts = useMemo(() => {
    if (!isCreator) return stagedContracts;
    return stagedContracts.filter(sc => {
      const party = (sc.creatorName || sc.creator || sc.party || '').toLowerCase();
      const handle = (sc.creatorHandle || '').toLowerCase().replace('@', '');
      const email = (sc.recipientEmail || '').toLowerCase();
      return (myHandle && (party.includes(myHandle) || handle.includes(myHandle))) ||
             (myName && party.includes(myName)) ||
             (myEmail && email === myEmail);
    });
  }, [isCreator, stagedContracts, myHandle, myName, myEmail]);

  // Aggregate stats (Calculated strictly from scopedBaseContracts for creator)
  const stats = useMemo(() => {
    const total = scopedBaseContracts.length;
    let exclusiveCount = 0;
    let nonExclusiveCount = 0;
    let oneTimeCount = 0;
    let expiringSoonCount = 0;
    let pendingSignCount = scopedStagedContracts.length;

    scopedBaseContracts.forEach(cnt => {
      const typeStr = (cnt.type || '').toLowerCase();
      const excl = cnt.exclusivityType || (
        typeStr.includes('exclusive') && !typeStr.includes('non-') ? 'Exclusive' :
        typeStr.includes('non-exclusive') ? 'Non-Exclusive' :
        typeStr.includes('one-time') ? 'One-Time' : 'Other'
      );
      if (excl === 'Exclusive') exclusiveCount++;
      else if (excl === 'Non-Exclusive') nonExclusiveCount++;
      else if (excl === 'One-Time') oneTimeCount++;

      // Check expiry
      if (cnt.end) {
        const [y, m, d] = cnt.end.split('-').map(Number);
        const end = new Date(y, m - 1, d).getTime();
        const diffDays = Math.ceil((end - Date.now()) / (1000 * 60 * 60 * 24));
        if (diffDays >= 0 && diffDays <= 60) expiringSoonCount++;
      }
    });

    return { total, exclusiveCount, nonExclusiveCount, oneTimeCount, expiringSoonCount, pendingSignCount };
  }, [scopedBaseContracts, scopedStagedContracts]);

  // Dispatched Emails strictly scoped
  const allDispatchedEmails = useMemo(() => {
    const list: { contractId: string; contractTitle: string; dispatch: ContractEmailDispatch }[] = [];
    scopedBaseContracts.forEach(c => {
      if (c.dispatchedEmails && c.dispatchedEmails.length > 0) {
        c.dispatchedEmails.forEach(d => {
          if (isCreator) {
            const recEmail = (d.recipientEmail || '').toLowerCase();
            const recName = (d.recipientName || '').toLowerCase();
            const isMine = (myEmail && recEmail === myEmail) ||
                           (myName && recName.includes(myName)) ||
                           (myHandle && recName.includes(myHandle));
            if (!isMine) return;
          }
          list.push({
            contractId: c.id,
            contractTitle: c.title || c.type || 'Legal Agreement',
            dispatch: d
          });
        });
      }
    });
    return list.sort((a, b) => new Date(b.dispatch.sentAt).getTime() - new Date(a.dispatch.sentAt).getTime());
  }, [scopedBaseContracts, isCreator, myEmail, myName, myHandle]);

  // Handler: Open Email Dispatch Modal
  const handleOpenEmailModal = (contract: Contract) => {
    setSelectedContractForEmail(contract);
    const partyName = contract.party || contract.name || 'Signing Party';
    setEmailRecipientName(partyName);

    // Look for matching creator email
    const matchedCreator = creators.find(c =>
      c.name.toLowerCase() === partyName.toLowerCase() ||
      (contract.party || '').toLowerCase().includes(c.handle.toLowerCase().replace('@', ''))
    );

    setEmailRecipient(contract.partyEmail || matchedCreator?.email || `${partyName.toLowerCase().replace(/[^a-z0-9]/g, '')}@agencytalent.com`);
    setEmailSubject(`[SECURE LEGAL DISPATCH] ${contract.type || 'Agreement'} — Bloom Studio x ${partyName}`);
    setEmailCoverNote(
      `Dear ${partyName},\n\nPlease review and execute the attached ${contract.type || 'Agreement'} between yourself and Bloom Studio.\n\nKey Terms:\n- Revenue Split: ${contract.revenueSplit || contract.terms || '80/20'}\n- Effective Term: ${contract.start || 'Immediate'} through ${contract.end || '12 Months'}\n- Exclusivity: ${contract.exclusivityType || 'Exclusive'}\n\nPlease click the secure signing link below to review the document and complete digital execution.\n\nBest regards,\nLegal & Talent Affairs\nBloom Studio Management`
    );
    // Secure PIN generation: Assign a cryptographically secure random 4-digit code
    setEmailPinCode(generateSecurePinCode());
  };

  // Handler: Dispatch Email
  const handleDispatchEmail = async () => {
    if (!selectedContractForEmail) return;
    if (!emailRecipient.trim()) {
      notify('Missing Recipient', 'Please enter a valid recipient email address.', 'warning');
      return;
    }

    // Verify recipient / counterparty against Global Blacklist
    const counterpartyToCheck = selectedContractForEmail.party || emailRecipientName || '';
    if (counterpartyToCheck) {
      const blCheck = await checkBrandBlacklist(counterpartyToCheck, currentUser?.tenantId);
      if (blCheck.isBlacklisted) {
        notify(
          'Dispatch Blocked',
          `Counterparty '${blCheck.matchedBrand || counterpartyToCheck}' is on the Global Blacklist (${blCheck.reason}). Contract dispatch is prohibited.`,
          'error'
        );
        return;
      }
    }

    setIsSendingEmail(true);

    const dispatchToken = generateSecureToken('sgn_');
    const newDispatch: ContractEmailDispatch = {
      id: 'disp_' + Date.now(),
      recipientEmail: emailRecipient,
      recipientName: emailRecipientName || selectedContractForEmail.party || 'Recipient',
      recipientRole: emailRecipientRole,
      subject: emailSubject,
      coverNote: emailCoverNote,
      sentAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      sentBy: currentUser?.name || 'Agency Director',
      status: 'Delivered',
      secureToken: dispatchToken,
      accessPin: emailRequirePin ? emailPinCode : undefined,
      expiresAt: new Date(Date.now() + parseInt(emailExpireDays, 10) * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    };

    const updatedContract: Contract = {
      ...selectedContractForEmail,
      status: selectedContractForEmail.status === 'Draft' ? 'Pending Signature' : selectedContractForEmail.status,
      dispatchedEmails: [newDispatch, ...(selectedContractForEmail.dispatchedEmails || [])]
    };

    setTimeout(() => {
      onSaveContract(updatedContract);
      setIsSendingEmail(false);
      setSelectedContractForEmail(null);

      notify(
        '✉️ Contract Dispatched Securely',
        `Legal document delivered to ${emailRecipient}. Secure signing token: ${dispatchToken.slice(0, 12)}...`,
        'success'
      );
      onAddActivityLog(
        currentUser?.name || 'Staff User',
        currentRole || 'none',
        `Dispatched secure legal contract [${selectedContractForEmail.id}] to ${emailRecipient} (${newDispatch.recipientRole})`
      );
    }, 600);
  };

  // Handler: Send Reminder to Creator to Re-sign
  const handleSendReminderToResign = (contract: Contract) => {
    notify(
      'Re-sign Reminder Dispatched',
      `Automated email reminder dispatched to ${contract.party} (${contract.partyEmail || contract.party}) to re-sign contract. Expiration Date: ${contract.end || 'Upcoming'}.`,
      'success'
    );
    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'Agent Manager',
        currentRole,
        `Dispatched contract re-sign reminder to ${contract.party} for agreement [${contract.id}]`
      );
    }
  };

  // Handler: Create New Contract
  const handleCreateNewContract = async () => {
    if (!newContractParty.trim()) {
      notify('Missing Party', 'Please enter the signing talent or brand name.', 'warning');
      return;
    }

    // Verify party against Global Blacklist before contract initiation
    const blCheck = await checkBrandBlacklist(newContractParty.trim(), currentUser?.tenantId);
    if (blCheck.isBlacklisted) {
      notify(
        'Contract Initiation Blocked',
        `Brand / Party '${blCheck.matchedBrand || newContractParty}' is on the Global Blacklist (${blCheck.reason}). Initiating contracts with this entity is barred.`,
        'error'
      );
      return;
    }

    const isAgentContract = newContractCategory === 'Agent Manager Agreement';
    const typeTitle =
      isAgentContract
        ? (newContractIsDualSigned ? 'Agent Manager Operating & Dual Signed Creator Agreement' : 'Agent Management & Commission Override Agreement')
        : newContractCategory === 'Talent Representation'
        ? `${newContractExclusivity} Talent Representation Agreement`
        : newContractCategory === 'One-Time Deal'
        ? 'One-Time Project & UGC Single Campaign Agreement'
        : newContractCategory === 'Brand Deal / UGC'
        ? 'Brand Sponsorship & Commercial Deliverables Agreement'
        : newContractCategory === 'NDA / Confidentiality'
        ? 'Mutual Non-Disclosure Agreement (NDA)'
        : 'Master Services Agreement (MSA)';

    const contractId = 'c_' + Date.now();
    const shaHash = generateSha256Hash(contractId, newContractParty);

    const newContract: Contract = {
      id: contractId,
      title: newContractTitle || typeTitle,
      party: newContractParty,
      partyEmail: newContractPartyEmail || `${newContractParty.toLowerCase().replace(/[^a-z0-9]/g, '')}@agencytalent.com`,
      type: typeTitle,
      agreementCategory: newContractCategory,
      exclusivityType: isAgentContract ? (newContractIsDualSigned ? ('Dual-Role Agreement' as any) : ('Commission Override' as any)) : newContractExclusivity,
      exclusivityScope: isAgentContract ? (newContractScope || 'Roster Management, Brand Solicitations & Campaign Execution') : newContractScope,
      revenueSplit: isAgentContract ? (newContractIsDualSigned ? `${newContractCommissionOverride} & ${newContractDualCreatorSplit}` : newContractCommissionOverride) : newContractSplit,
      start: newContractStartDate,
      end: newContractEndDate,
      terms: newContractTerms,
      value: newContractValue || (isAgentContract ? '$60,000/yr Est. Overrides' : newContractExclusivity === 'One-Time' ? '$2,500' : '$25,000/yr Est.'),
      status: 'Active',
      autoRenew: newContractAutoRenew,
      renewalNoticeDays: 30,
      securityHash: shaHash,
      encryptionLevel: 'AES-256-GCM',
      accessTier: isAgentContract ? 'agency_internal' : 'all_parties',
      isAgentManagerContract: isAgentContract,
      isDualSignedContract: isAgentContract && newContractIsDualSigned,
      contractTargetRole: isAgentContract ? (newContractIsDualSigned ? 'dual_creator_agent' : 'agentmgr') : 'creator',
      agentName: isAgentContract ? newContractParty : undefined,
      agentCommissionOverride: isAgentContract ? newContractCommissionOverride : undefined,
      baseSalaryOrRetainer: isAgentContract ? newContractBaseSalary : undefined,
      creatorHandle: isAgentContract && newContractIsDualSigned ? newContractDualCreatorHandle : undefined,
      fileAttachment: attachedFileName
        ? {
            name: attachedFileName,
            size: '248 KB',
            type: 'application/pdf'
          }
        : undefined,
      signatures: {
        agencySigned: true,
        agencySignedBy: currentUser?.name || 'Agency Director',
        agencySignedDate: new Date().toISOString().split('T')[0]
      },
      dispatchedEmails: []
    };

    onSaveContract(newContract);
    setShowNewContractModal(false);

    // Reset inputs
    setNewContractParty('');
    setNewContractPartyEmail('');
    setNewContractTitle('');
    setAttachedFileName('');

    notify(
      'Contract Logged & Secured',
      `New ${newContractExclusivity} contract registered for ${newContract.party}. SHA-256 checksum generated.`,
      'success'
    );
    onAddActivityLog(
      currentUser?.name || 'User',
      currentRole,
      `Executed and registered new ${newContractExclusivity} agreement with ${newContract.party}`
    );
  };

  // Handler: Quick Log Representation / Exclusivity for Creator
  const handleSaveQuickExclusivity = () => {
    if (!selectedCreatorForExclusivity) return;

    let fullAgreementStr = '';
    if (quickAgreementType === 'Exclusive') {
      fullAgreementStr = `Exclusive (${quickSplit})`;
    } else if (quickAgreementType === 'Non-Exclusive') {
      fullAgreementStr = `Non-Exclusive (${quickSplit})`;
    } else if (quickAgreementType === 'One-Time Deal') {
      fullAgreementStr = `One-Time Project (${quickSplit} fee)`;
    } else if (quickAgreementType === 'Co-Representation') {
      fullAgreementStr = `Co-Representation (50/50)`;
    } else if (quickAgreementType === 'Monthly Retainer') {
      fullAgreementStr = `Monthly Retainer + ${quickSplit}`;
    } else {
      fullAgreementStr = quickCustomLabel || quickAgreementType;
    }

    if (onUpdateCreatorAgreement) {
      onUpdateCreatorAgreement(
        selectedCreatorForExclusivity.id,
        fullAgreementStr,
        quickAgreementType,
        quickScope
      );
    }

    setShowQuickExclusivityModal(false);
    setSelectedCreatorForExclusivity(null);

    notify(
      'Representation Status Updated',
      `${selectedCreatorForExclusivity.name} representation logged as ${fullAgreementStr}.`,
      'success'
    );
    onAddActivityLog(
      currentUser?.name || 'User',
      currentRole,
      `Updated representation model for ${selectedCreatorForExclusivity.name} to ${fullAgreementStr}`
    );
  };

  return (
    <div className="space-y-6 animate-fade-in text-[#E5E9F0]" id="contracts-vault-root">
      {/* Top Header & Security Banner */}
      <div className="bg-[#0D1830] border border-amber-500/20 rounded-2xl p-6 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-amber-500/10 via-transparent to-transparent pointer-events-none rounded-full blur-2xl" />

        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-amber-950/80 border border-amber-500/40 text-amber-300 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold flex items-center gap-1.5">
                <Shield className="w-3 h-3 text-amber-400" />
                <span>{isCreator ? 'AES-256 ENCRYPTED TALENT VAULT' : 'AES-256 ENCRYPTED LEGAL VAULT'}</span>
              </span>
              <span className="bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold">
                {isCreator ? 'CONFIDENTIAL PERSONAL RECORD' : 'ZERO-TRUST ABAC ACTIVE'}
              </span>
            </div>
            <h2 className="text-2xl font-serif font-bold text-white tracking-tight">
              {isCreator ? 'My Representation Agreement & Legal Vault' : 'Agency Legal Vault & Contract Control Hub'}
            </h2>
            <p className="text-xs text-[#7C8AA8] mt-1 max-w-2xl leading-relaxed">
              {isCreator
                ? 'Your official talent representation agreement with Bloom & Co., active exclusivity terms, compensation splits, and executed brand partnership contracts.'
                : 'Log representation exclusivity models (Exclusive, Non-Exclusive, One-Time Project Deals, Co-Rep, Retainers), store all agency legal documents securely, and dispatch contracts via encrypted email envelopes with tamper-evident audit trails.'}
            </p>
          </div>

          {!isCreator ? (
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <button
                id="btn-vault-signed-agreements"
                onClick={() => {
                  if (typeof window !== 'undefined' && (window as any).navigateToScreen) {
                    (window as any).navigateToScreen('signed-agreements-vault');
                  }
                }}
                className="bg-[#0F2448] hover:bg-[#163363] text-emerald-300 border border-emerald-500/40 px-3.5 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Signed Agreements Vault</span>
              </button>

              <button
                id="btn-quick-log-exclusivity"
                onClick={() => {
                  if (creators.length > 0) {
                    setSelectedCreatorForExclusivity(creators[0]);
                    setQuickAgreementType('Exclusive');
                    setQuickSplit('80%');
                    setShowQuickExclusivityModal(true);
                  } else {
                    notify('No Creators', 'Please add creators to roster first.', 'info');
                  }
                }}
                className="bg-[#111E33] hover:bg-[#16243F] text-amber-300 border border-amber-500/30 hover:border-amber-400 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              >
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Log Exclusivity Status</span>
              </button>

              <button
                id="btn-vault-new-contract"
                onClick={() => setShowNewContractModal(true)}
                className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Create / Store Contract</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              {filteredContracts.length > 0 && (
                <button
                  id="btn-creator-view-my-agreement"
                  onClick={() => setSelectedContractForView(filteredContracts[0])}
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md"
                >
                  <Eye className="w-4 h-4" />
                  <span>Inspect Signed Contract</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Security Metric Strip */}
        {isCreator ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-white/5">
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-white/5">
              <span className="text-[10px] font-mono text-[#7C8AA8] uppercase block">My Contracts</span>
              <div className="text-lg font-bold text-white font-mono mt-0.5">{filteredContracts.length}</div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-amber-500/20">
              <span className="text-[10px] font-mono text-amber-400 uppercase block">Representation</span>
              <div className="text-sm font-bold text-amber-300 font-mono mt-1 truncate">
                {scopedBaseContracts[0]?.exclusivityType || matchingCreator?.agreementType || 'Exclusive'}
              </div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-emerald-500/20">
              <span className="text-[10px] font-mono text-emerald-400 uppercase block">Split Schedule</span>
              <div className="text-sm font-bold text-emerald-300 font-mono mt-1 truncate">
                {scopedBaseContracts[0]?.revenueSplit || matchingCreator?.commissionSplit || '80% / 20%'}
              </div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-sky-500/20">
              <span className="text-[10px] font-mono text-sky-400 uppercase block">Agreement Term</span>
              <div className="text-xs font-bold text-sky-300 font-mono mt-1">12 Months (Active)</div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-purple-500/20">
              <span className="text-[10px] font-mono text-purple-400 uppercase block">Cryptographic Seal</span>
              <div className="text-xs font-bold text-purple-300 font-mono mt-1 flex items-center gap-1">
                <CheckCircle className="w-3 h-3 text-emerald-400" />
                <span>SHA-256 Valid</span>
              </div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-teal-500/20">
              <span className="text-[10px] font-mono text-teal-400 uppercase block">Vault Access</span>
              <div className="text-xs font-bold text-teal-300 font-mono mt-1">Direct Encrypted</div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-white/5">
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-white/5">
              <span className="text-[10px] font-mono text-[#7C8AA8] uppercase block">Total Contracts</span>
              <div className="text-lg font-bold text-white font-mono mt-0.5">{stats.total}</div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-amber-500/20">
              <span className="text-[10px] font-mono text-amber-400 uppercase block">Exclusive Locks</span>
              <div className="text-lg font-bold text-amber-300 font-mono mt-0.5">{stats.exclusiveCount}</div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-sky-500/20">
              <span className="text-[10px] font-mono text-sky-400 uppercase block">Non-Exclusive</span>
              <div className="text-lg font-bold text-sky-300 font-mono mt-0.5">{stats.nonExclusiveCount}</div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-purple-500/20">
              <span className="text-[10px] font-mono text-purple-400 uppercase block">One-Time Deals</span>
              <div className="text-lg font-bold text-purple-300 font-mono mt-0.5">{stats.oneTimeCount}</div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-rose-500/20">
              <span className="text-[10px] font-mono text-rose-400 uppercase block">Expiring &lt; 60d</span>
              <div className="text-lg font-bold text-rose-300 font-mono mt-0.5">{stats.expiringSoonCount}</div>
            </div>
            <div className="bg-[#111E33]/70 p-3 rounded-xl border border-emerald-500/20">
              <span className="text-[10px] font-mono text-emerald-400 uppercase block">Dispatches Out</span>
              <div className="text-lg font-bold text-emerald-300 font-mono mt-0.5">{allDispatchedEmails.length}</div>
            </div>
          </div>
        )}
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/5 pb-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            id="tab-contracts-repository"
            onClick={() => setActiveTab('repository')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'repository'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isCreator ? `My Legal Agreements (${filteredContracts.length})` : `Contracts Repository (${filteredContracts.length})`}</span>
          </button>

          {isCreator && scopedStagedContracts.length > 0 && (
            <button
              id="tab-contracts-staged-creator"
              onClick={() => setActiveTab('staged')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'staged'
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                  : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
              }`}
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span>Pending Envelopes ({scopedStagedContracts.length})</span>
            </button>
          )}

          {!isCreator && (
            <>
              <button
                id="tab-contracts-staged"
                onClick={() => setActiveTab('staged')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  activeTab === 'staged'
                    ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                    : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
                }`}
              >
                <FileCheck className="w-3.5 h-3.5" />
                <span>Staged Envelopes ({stagedContracts.length})</span>
              </button>

              <button
                id="tab-contracts-outbox"
                onClick={() => setActiveTab('outbox')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  activeTab === 'outbox'
                    ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                    : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Secure Email Outbox ({allDispatchedEmails.length})</span>
              </button>

              <button
                id="tab-contracts-security"
                onClick={() => setActiveTab('security')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  activeTab === 'security'
                    ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                    : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Security &amp; SHA-256 Checksums</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* TAB 1: ALL CONTRACTS REPOSITORY */}
      {activeTab === 'repository' && (
        <div className="space-y-4">
          {/* Automated Compliance Audit Status Bar (45-Day Threshold) - Staff only */}
          {!isCreator && (() => {
            const today = new Date();
            const DAYS_THRESHOLD = 45;
            const msInDay = 24 * 60 * 60 * 1000;

            const auditableList: AuditableContract[] = contracts.map(c => ({
              id: c.id,
              creatorName: c.party || c.name || 'Talent',
              expirationDate: c.end || c.expiryDate || '2027-01-01',
              party: c.party,
              partyEmail: c.partyEmail,
              type: c.type
            }));

            const expiringAlerts = auditableList.filter(c => {
              const [y, m, d] = c.expirationDate.split('-').map(Number);
              const exp = new Date(y, m - 1, d);
              const diffDays = Math.ceil((exp.getTime() - today.getTime()) / msInDay);
              return diffDays > 0 && diffDays <= DAYS_THRESHOLD;
            });

            if (expiringAlerts.length === 0) return null;

            return (
              <div className="bg-[#101F42] border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0 mt-0.5">
                    <AlertTriangle className="w-4 h-4 animate-pulse" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold uppercase text-white tracking-wide">
                        Automated Compliance Engine Audit
                      </h4>
                      <span className="text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
                        {expiringAlerts.length} Action{expiringAlerts.length > 1 ? 's' : ''} Required (≤ 45 Days)
                      </span>
                    </div>
                    <p className="text-[11px] text-[#94A3B8] mt-0.5 leading-relaxed">
                      Contracts nearing expiration boundary ({DAYS_THRESHOLD}-day alert trigger):{' '}
                      {expiringAlerts.map((a, idx) => {
                        const [y, m, d] = a.expirationDate.split('-').map(Number);
                        const daysLeft = Math.ceil((new Date(y, m - 1, d).getTime() - today.getTime()) / msInDay);
                        return (
                          <span key={a.id} className="text-amber-200 font-semibold">
                            {a.creatorName} ({daysLeft}d left){idx < expiringAlerts.length - 1 ? ', ' : ''}
                          </span>
                        );
                      })}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const logs = auditContractExpirations(auditableList);
                    notify(
                      "Automated Compliance Sweep Run",
                      `Audited ${auditableList.length} legal records. Dispatched ${logs.length} urgent renewal notices.`,
                      "warning"
                    );
                    onAddActivityLog(
                      currentUser?.name || "User",
                      currentRole,
                      `Executed automated contract expiration compliance sweep. ${logs.length} alert(s) triggered.`
                    );
                  }}
                  className="px-3.5 py-2 bg-[#3B82F6] hover:bg-blue-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shrink-0 cursor-pointer shadow-sm"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Run Audit Sweep</span>
                </button>
              </div>
            );
          })()}

          {/* Filters Bar - Hidden for Creators so they directly see their representation contract */}
          {!isCreator && (
            <div className="bg-[#0D1830] p-4 rounded-2xl border border-white/5 flex flex-wrap items-end justify-between gap-4">
              <div className="flex flex-wrap items-end gap-3">
                {/* 2. Legal Agreement Vault Filter */}
                <div className="custom-dropdown-container !mb-0">
                  <label className="dropdown-label">AGREEMENT EXCLUSIVITY TYPE</label>
                  <select
                    id="agreementTypeSelect"
                    className="bloom-navy-select !py-2.5 !px-3.5 !text-xs"
                    value={exclusivityFilter}
                    onChange={e => setExclusivityFilter(e.target.value)}
                  >
                    <option value="all">All Representation Agreements</option>
                    <option value="exclusive">Exclusive Representation Contract</option>
                    <option value="non-exclusive">Non-Exclusive Talent Contract</option>
                    <option value="single-project">One-Time / Single Project Deliverable</option>
                  </select>
                </div>

                {/* Category Filter */}
                <div className="custom-dropdown-container !mb-0">
                  <label className="dropdown-label">DOCUMENT CATEGORY</label>
                  <select
                    id="select-category-filter"
                    value={categoryFilter}
                    onChange={e => setCategoryFilter(e.target.value)}
                    className="bloom-navy-select !py-2.5 !px-3.5 !text-xs"
                  >
                    <option value="all">All Document Categories</option>
                    <option value="Talent Representation">Talent Representation</option>
                    <option value="Agent Manager Agreement">Agent Manager Agreements (Staff)</option>
                    <option value="Brand Deal / UGC">Brand Deals &amp; UGC</option>
                    <option value="One-Time Deal">One-Time Project Deals</option>
                    <option value="NDA / Confidentiality">NDAs &amp; Confidentiality</option>
                    <option value="MSA / Agency">MSAs &amp; Agency</option>
                  </select>
                </div>

                {/* Status Filter */}
                <div className="custom-dropdown-container !mb-0">
                  <label className="dropdown-label">SIGNING STATUS</label>
                  <select
                    id="select-status-filter"
                    value={statusFilter}
                    onChange={e => setStatusFilter(e.target.value)}
                    className="bloom-navy-select !py-2.5 !px-3.5 !text-xs"
                  >
                    <option value="all">All Execution Statuses</option>
                    <option value="Active">Active</option>
                    <option value="Pending Signature">Pending Signature</option>
                    <option value="Expiring Soon">Expiring Soon</option>
                    <option value="Expired">Expired</option>
                    <option value="Draft">Draft</option>
                  </select>
                </div>
              </div>

              {/* Search Input */}
              <div className="relative min-w-[240px] flex-1 sm:flex-initial mb-0.5">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#7C8AA8]" />
                <input
                  id="input-vault-search"
                  type="text"
                  placeholder="Search talent, brand, terms, or hash..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-2.5 bg-[#101F42] border border-white/10 rounded-xl text-xs text-white placeholder-[#7C8AA8] focus:outline-none focus:border-[#3B82F6]"
                />
              </div>
            </div>
          )}

          {/* Contracts Table */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table id="table-vault-contracts" className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                    <th className="p-4 font-semibold">Signing Party &amp; Title</th>
                    <th className="p-4 font-semibold">Agreement &amp; Exclusivity</th>
                    <th className="p-4 font-semibold">Revenue Split / Value</th>
                    <th className="p-4 font-semibold">Term Period</th>
                    <th className="p-4 font-semibold">Status</th>
                    <th className="p-4 font-semibold">Security Integrity</th>
                    <th className="p-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredContracts.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-12 text-center text-[#7C8AA8] space-y-3">
                        <FileText className="w-10 h-10 mx-auto text-[#7C8AA8]/40 mb-2" />
                        <p className="text-sm text-slate-300 font-semibold">No contracts found matching your filters.</p>
                        <p className="text-xs text-[#7C8AA8]">
                          Create a new contract or adjust your category, exclusivity, or search query.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    filteredContracts.map(cnt => {
                      const partyName = cnt.party || cnt.name || 'Signing Party';
                      const isAgentAgreement = cnt.isAgentManagerContract || cnt.agreementCategory === 'Agent Manager Agreement' || cnt.contractTargetRole === 'agentmgr' || cnt.contractTargetRole === 'dual_creator_agent';
                      const isDualRole = cnt.isDualSignedContract || cnt.contractTargetRole === 'dual_creator_agent';

                      const exclType = cnt.exclusivityType || (
                        isDualRole ? 'Dual-Role Agreement' :
                        isAgentAgreement ? 'Commission Override' :
                        cnt.type.toLowerCase().includes('exclusive') && !cnt.type.toLowerCase().includes('non-') ? 'Exclusive' :
                        cnt.type.toLowerCase().includes('non-exclusive') ? 'Non-Exclusive' :
                        cnt.type.toLowerCase().includes('one-time') ? 'One-Time' : 'Standard'
                      );

                      const shaShort = (cnt.securityHash || generateSha256Hash(cnt.id, partyName)).slice(0, 10);

                      return (
                        <tr key={cnt.id} id={`contract-row-${cnt.id}`} className="hover:bg-[#111E33]/50 transition-colors">
                          {/* Party & Title */}
                          <td className="p-4">
                            <div className="font-bold text-white text-sm flex flex-wrap items-center gap-2">
                              <span>{partyName}</span>
                              {isDualRole ? (
                                <span className="bg-gradient-to-r from-purple-950 to-amber-950 text-[#C9A46A] border border-[#C9A46A]/50 text-[9px] px-2 py-0.5 rounded-full font-mono font-bold uppercase">
                                  🌟 Dual-Role (Staff + Signed Talent)
                                </span>
                              ) : isAgentAgreement ? (
                                <span className="bg-indigo-950/80 text-indigo-300 border border-indigo-500/40 text-[9px] px-2 py-0.5 rounded-full font-mono font-bold uppercase">
                                  👔 Agent Manager Agreement
                                </span>
                              ) : null}
                              {cnt.fileAttachment && (
                                <span title="PDF document attached" className="text-amber-400 bg-amber-950/60 p-1 rounded">
                                  <Paperclip className="w-3 h-3" />
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-[#C9A46A] mt-0.5 font-medium">{cnt.title || cnt.type}</div>
                            {cnt.creatorHandle && (
                              <div className="text-[10px] font-mono text-emerald-400 mt-0.5">Signed Handle: {cnt.creatorHandle}</div>
                            )}
                            <div className="text-[10px] font-mono text-[#7C8AA8] mt-0.5">ID: {cnt.id}</div>
                          </td>

                          {/* Agreement & Exclusivity */}
                          <td className="p-4">
                            <span
                              className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-lg border ${
                                isDualRole
                                  ? 'bg-gradient-to-r from-purple-950/80 to-amber-950/80 border-[#C9A46A]/50 text-amber-200'
                                  : isAgentAgreement || exclType === 'Commission Override'
                                  ? 'bg-indigo-950/80 border-indigo-500/40 text-indigo-300'
                                  : exclType === 'Exclusive'
                                  ? 'bg-amber-950/80 border-amber-500/40 text-amber-300'
                                  : exclType === 'Non-Exclusive'
                                  ? 'bg-sky-950/80 border-sky-500/40 text-sky-300'
                                  : exclType === 'One-Time'
                                  ? 'bg-purple-950/80 border-purple-500/40 text-purple-300'
                                  : exclType === 'Co-Representation'
                                  ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                                  : 'bg-[#111E33] border-white/10 text-slate-300'
                              }`}
                            >
                              <Lock className="w-3 h-3" />
                              <span>{exclType}</span>
                            </span>
                            <div className="text-[10px] text-[#7C8AA8] mt-1 max-w-xs truncate">
                              {cnt.exclusivityScope || cnt.terms || 'Full commercial representation'}
                            </div>
                          </td>

                          {/* Split / Value */}
                          <td className="p-4 font-mono">
                            <div className="text-emerald-400 font-bold text-xs">
                              {isStaffRestricted ? '•••• Protected' : (cnt.revenueSplit || '80/20 Split')}
                            </div>
                            {cnt.value && (
                              <div className="text-[10px] text-[#7C8AA8]">
                                {isStaffRestricted ? '••••' : cnt.value}
                              </div>
                            )}
                          </td>

                          {/* Term Period */}
                          <td className="p-4 font-mono text-xs">
                            <div className="text-white font-medium">Duration: {cnt.start && cnt.end ? `${cnt.start} to ${cnt.end}` : '12 Months'}</div>
                            <div className="text-[10px] text-amber-300 font-bold mt-0.5">
                              Expires: {cnt.end || '2027-01-01'}
                            </div>
                            <div className="text-[9px] text-[#7C8AA8] mt-0.5">
                              {cnt.autoRenew ? '🔄 Auto-renews (30d notice)' : 'Manual renewal'}
                            </div>
                          </td>

                          {/* Status */}
                          <td className="p-4">
                            <span
                              className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                                (cnt.status || 'Active') === 'Active'
                                  ? 'bg-emerald-950 border-emerald-500/30 text-emerald-400'
                                  : (cnt.status || '') === 'Pending Signature'
                                  ? 'bg-amber-950 border-amber-500/30 text-amber-400'
                                  : (cnt.status || '').includes('Expiring')
                                  ? 'bg-rose-950 border-rose-500/30 text-rose-400'
                                  : 'bg-[#111E33] border-white/10 text-slate-400'
                              }`}
                            >
                              {cnt.status || 'Active'}
                            </span>
                          </td>

                          {/* Security Integrity */}
                          <td className="p-4">
                            <div className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                              <Shield className="w-3 h-3 text-emerald-400 shrink-0" />
                              <span>SHA: {shaShort}...</span>
                            </div>
                            <div className="text-[9px] text-[#7C8AA8] mt-0.5">
                              {cnt.dispatchedEmails?.length ? `Dispatched (${cnt.dispatchedEmails.length}x)` : 'Stored in Vault'}
                            </div>
                          </td>

                          {/* Actions */}
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* View / Inspect */}
                              <button
                                id={`btn-view-contract-${cnt.id}`}
                                onClick={() => setSelectedContractForView(cnt)}
                                className="p-1.5 bg-[#111E33] hover:bg-[#16243F] text-[#C9A46A] border border-white/5 rounded-lg transition-colors cursor-pointer"
                                title="Inspect Full Legal Document"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>

                              {/* Preview as PDF Modal */}
                              <button
                                type="button"
                                onClick={() => {
                                  setDocViewerFiles([
                                    {
                                      name: `${(cnt.party || 'Legal_Agreement').replace(/[^a-z0-9]/gi, '_')}_Executed.pdf`,
                                      category: cnt.type || 'Contract Vault Document',
                                      description: `${cnt.name || cnt.title} — Parties: Bloom & Co. and ${cnt.party}. Terms: ${isStaffRestricted ? 'Protected' : (cnt.revenueSplit || cnt.terms)}`
                                    }
                                  ]);
                                  setDocViewerTitle(`Contract Inspection — ${cnt.party || cnt.name}`);
                                  setDocViewerOpen(true);
                                }}
                                className="p-1.5 bg-[#111E33] hover:bg-[#16243F] text-sky-300 border border-white/5 rounded-lg transition-colors cursor-pointer"
                                title="View PDF Document"
                              >
                                <FileText className="w-3.5 h-3.5" />
                              </button>

                              {/* Send Re-sign Reminder */}
                              {!isCreator && (
                                <button
                                  id={`btn-remind-resign-${cnt.id}`}
                                  onClick={() => handleSendReminderToResign(cnt)}
                                  className="px-2 py-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                                  title="Send reminder email to creator to re-sign contract"
                                >
                                  <Send className="w-3 h-3 text-amber-400" />
                                  <span>Send Reminder</span>
                                </button>
                              )}

                              {/* Email Out */}
                              {!isCreator && (
                                <button
                                  id={`btn-email-contract-${cnt.id}`}
                                  onClick={() => handleOpenEmailModal(cnt)}
                                  className="p-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg transition-colors cursor-pointer"
                                  title="Dispatch Contract via Secure Email"
                                >
                                  <Mail className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {/* Delete (Staff or Director) */}
                              {!isCreator && (
                                <button
                                  id={`btn-delete-contract-${cnt.id}`}
                                  onClick={() => {
                                    onDeleteContract(cnt.id);
                                  }}
                                  className="p-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-lg transition-colors cursor-pointer"
                                  title="Delete Contract (Move to Recoup Trash)"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: STAGED ENVELOPES & PENDING SIGNATURES */}
      {activeTab === 'staged' && (
        <div className="space-y-6">
          {isCreator ? (
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
              <div>
                <h3 className="text-base font-serif font-bold text-[#C9A46A] flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-amber-400" />
                  <span>My Pending Signature Envelopes ({scopedStagedContracts.length})</span>
                </h3>
                <p className="text-xs text-[#7C8AA8] leading-relaxed mt-1">
                  Digital envelopes deployed by the agency awaiting your electronic signature and biometric verification.
                </p>
              </div>

              <div className="space-y-3 mt-4">
                {scopedStagedContracts.length === 0 ? (
                  <div className="text-center py-10 text-[#7C8AA8] space-y-2">
                    <CheckCircle className="w-8 h-8 mx-auto text-emerald-400/50" />
                    <p className="text-xs">No pending contract envelopes awaiting your signature.</p>
                  </div>
                ) : (
                  scopedStagedContracts.map(sc => (
                    <div
                      key={sc.id}
                      className="p-4 bg-[#111E33] border border-amber-500/30 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs"
                    >
                      <div>
                        <div className="font-bold text-white text-sm">{sc.agreementType || 'Talent Representation Agreement'}</div>
                        <div className="text-xs text-[#C9A46A] font-mono mt-0.5">Term: {sc.termDuration || '12 Months'}</div>
                        <div className="flex items-center gap-2 text-[10px] text-[#7C8AA8] mt-1 font-mono">
                          <span>Deployed: {sc.date}</span>
                          <span>&bull;</span>
                          <span className="text-emerald-400">Envelope: {sc.token || 'AES-256 Sealed'}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="bg-amber-950/80 text-amber-400 border border-amber-500/30 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono">
                          {sc.status || 'Pending Signature'}
                        </span>
                        <button
                          onClick={() => {
                            notify('Signature Verified', `Successfully executed digital envelope ${sc.id}.`, 'success');
                            onAddActivityLog(myName || 'Creator', 'creator', `Electronically signed envelope ${sc.id}`);
                          }}
                          className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md font-mono"
                        >
                          Sign Electronically
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Deploy Staged Contract Form */}
              <div className="lg:col-span-5 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
                <h3 className="text-base font-serif font-bold text-[#C9A46A] flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-amber-400" />
                  <span>Stage New Digital Envelope</span>
                </h3>
                <p className="text-xs text-[#7C8AA8] leading-relaxed">
                  Deploy digital contract envelopes to talent or brands. Dispatches activation tokens to the Creator Portal for electronic execution.
                </p>

                <div className="space-y-3.5 pt-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Target Creator / Signing Party</label>
                    <input
                      type="text"
                      id="input-stage-creator"
                      placeholder="e.g. Rachel Sterling or @rachelsterling"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Agreement Type &amp; Exclusivity</label>
                    <select
                      id="select-stage-type"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                    >
                      <option value="Exclusive Talent Representation (80/20 - 20% Agency Cut)">Exclusive Talent Representation (80/20 - 20% Agency Cut)</option>
                      <option value="Non-Exclusive Representation (70/30 - 30% Agency Cut)">Non-Exclusive Representation (70/30 - 30% Agency Cut)</option>
                      <option value="One-Time Project Agreement (Custom Split)">One-Time Project Agreement (Custom Split)</option>
                      <option value="Flat Fee Representation Agreement ($500 Flat Fee Category)">Flat Fee Representation Agreement ($500 Flat Fee Category)</option>
                      <option value="Co-Representation Agreement (50/50)">Co-Representation Agreement (50/50)</option>
                      <option value="Brand Sponsorship Agreement">Brand Sponsorship Agreement</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Term Duration</label>
                    <input
                      type="text"
                      id="input-stage-term"
                      defaultValue="12 Months"
                      placeholder="e.g. 12 Months"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  <button
                    id="btn-deploy-staged-envelope"
                    onClick={() => {
                      const cInput = document.getElementById('input-stage-creator') as HTMLInputElement;
                      const tSelect = document.getElementById('select-stage-type') as HTMLSelectElement;
                      const termInput = document.getElementById('input-stage-term') as HTMLInputElement;

                      const creator = cInput?.value?.trim();
                      const agreementType = tSelect?.value;
                      const term = termInput?.value?.trim() || '12 Months';

                      if (!creator) {
                        notify('Missing Party', 'Please enter creator name or handle.', 'warning');
                        return;
                      }

                      const newStaged = {
                        id: 'sc_' + Date.now(),
                        creatorName: creator,
                        agreementType,
                        termDuration: term,
                        status: 'Pending Signature',
                        date: new Date().toISOString().split('T')[0],
                        token: generateSecureToken('env_'),
                        subagency: currentUser?.subagency || 'pod_main'
                      };

                      onStageContract(newStaged);
                      cInput.value = '';

                      notify('Envelope Staged', `Contract envelope deployed for ${creator}.`, 'success');
                      onAddActivityLog(
                        currentUser?.name || 'User',
                        currentRole,
                        `Deployed staged contract envelope for ${creator} (${term})`
                      );
                    }}
                    className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md font-mono"
                  >
                    Deploy Envelope to Creator Portal
                  </button>
                </div>
              </div>

              {/* Staged Envelopes Pool */}
              <div className="lg:col-span-7 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs uppercase font-bold text-[#7C8AA8] tracking-wider">
                    Active Staged Envelopes Pool ({stagedContracts.length})
                  </h4>
                  <p className="text-[11px] text-[#7C8AA8] mt-1">
                    Envelopes awaiting electronic signature from creators or brand contacts.
                  </p>

                  <div className="space-y-3 mt-4 max-h-[320px] overflow-y-auto pr-1">
                    {stagedContracts.map(sc => (
                      <div
                        key={sc.id}
                        className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl flex justify-between items-center text-xs"
                      >
                        <div>
                          <div className="font-bold text-white text-sm">{sc.creatorName}</div>
                          <div className="text-[11px] text-[#C9A46A] mt-0.5">{sc.agreementType || 'Talent Representation'}</div>
                          <div className="flex items-center gap-2 text-[10px] text-[#7C8AA8] mt-1 font-mono">
                            <span>Term: {sc.termDuration}</span>
                            <span>&bull;</span>
                            <span>Deployed: {sc.date}</span>
                            {sc.token && (
                              <>
                                <span>&bull;</span>
                                <span className="text-emerald-400">Token: {sc.token}</span>
                              </>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="bg-amber-950/80 text-amber-400 border border-amber-500/30 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono">
                            {sc.status || 'Pending Signature'}
                          </span>
                          <button
                            id={`btn-delete-staged-${sc.id}`}
                            onClick={() => {
                              onDeleteStagedContract(sc.id);
                              notify('Envelope Revoked', `Envelope for ${sc.creatorName} voided and removed from staging pool.`, 'info');
                            }}
                            className="text-[#7C8AA8] hover:text-rose-400 p-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                            title="Void and Revoke Envelope"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}

                    {stagedContracts.length === 0 && (
                      <div className="text-center py-10 text-[#7C8AA8] space-y-2">
                        <CheckCircle className="w-8 h-8 mx-auto text-emerald-400/50" />
                        <p className="text-xs">No pending signature envelopes in staging queue.</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="text-[10px] text-[#7C8AA8] text-center border-t border-white/5 pt-3 font-mono">
                  🔒 Cryptographic electronic envelope security active &bull; RFC 3161 timestamping enabled.
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: SECURE EMAIL OUTBOX */}
      {activeTab === 'outbox' && !isCreator && (
        <div className="space-y-4">
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/5 pb-4">
              <div>
                <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                  <Mail className="w-5 h-5 text-amber-400" />
                  <span>Secure Legal Email Outbox &amp; Delivery Log</span>
                </h3>
                <p className="text-xs text-[#7C8AA8] mt-1">
                  Audit log of all legal documents and representation contracts emailed to talent, brands, or outside counsel.
                </p>
              </div>

              <div className="text-xs font-mono text-[#7C8AA8]">
                Dispatches Logged: {allDispatchedEmails.length}
              </div>
            </div>

            {/* Email Outbox Table */}
            <div className="overflow-x-auto">
              <table id="table-email-outbox" className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                    <th className="p-4 font-semibold">Recipient &amp; Role</th>
                    <th className="p-4 font-semibold">Contract Title</th>
                    <th className="p-4 font-semibold">Subject</th>
                    <th className="p-4 font-semibold">Sent Timestamp</th>
                    <th className="p-4 font-semibold">Status</th>
                    <th className="p-4 font-semibold">Secure Token</th>
                    <th className="p-4 font-semibold text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {allDispatchedEmails.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-12 text-center text-[#7C8AA8] space-y-3">
                        <Mail className="w-10 h-10 mx-auto text-[#7C8AA8]/40 mb-2" />
                        <p className="text-sm text-slate-300 font-semibold">No dispatched contract emails logged yet.</p>
                        <p className="text-xs text-[#7C8AA8]">
                          Select any contract from the Repository and click "Email Contract" to dispatch legal documents securely.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    allDispatchedEmails.map(({ contractId, contractTitle, dispatch }) => (
                      <tr key={dispatch.id} className="hover:bg-[#111E33]/40 transition-colors">
                        <td className="p-4">
                          <div className="font-bold text-white text-sm">{dispatch.recipientName}</div>
                          <div className="text-xs text-[#C9A46A] font-mono mt-0.5">{dispatch.recipientEmail}</div>
                          <span className="inline-block mt-1 text-[9px] px-2 py-0.5 rounded bg-[#111E33] border border-white/10 text-slate-300 font-mono">
                            {dispatch.recipientRole}
                          </span>
                        </td>

                        <td className="p-4 text-white font-medium">
                          {contractTitle}
                        </td>

                        <td className="p-4 text-[#B8C0D4] max-w-xs truncate">
                          {dispatch.subject}
                        </td>

                        <td className="p-4 font-mono text-[#7C8AA8] text-xs">
                          {dispatch.sentAt}
                          <div className="text-[10px] text-slate-400">By {dispatch.sentBy}</div>
                        </td>

                        <td className="p-4">
                          <span className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[10px] px-2.5 py-1 rounded-full font-mono font-bold flex items-center gap-1 w-max">
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span>{dispatch.status}</span>
                          </span>
                        </td>

                        <td className="p-4 font-mono text-[10px] text-amber-300">
                          {dispatch.secureToken.slice(0, 14)}...
                        </td>

                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => {
                                const signingUrl = `${window.location.origin}?contract_token=${dispatch.secureToken}`;
                                navigator.clipboard.writeText(signingUrl);
                                notify('Secure Link Copied', `Signing URL for ${dispatch.recipientName} copied to clipboard.`, 'success');
                              }}
                              className="text-slate-300 hover:text-white bg-[#111E33] border border-white/10 px-2 py-1.5 rounded-lg text-[10px] font-mono flex items-center gap-1 cursor-pointer"
                              title="Copy Public Secure Signing URL"
                            >
                              <Copy className="w-3 h-3 text-[#C9A46A]" />
                              <span>Copy Link</span>
                            </button>
                            <a
                              href={`?contract_token=${dispatch.secureToken}`}
                              className="text-[#C9A46A] hover:text-[#E3C48F] bg-[#111E33] border border-[#C9A46A]/30 px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer flex items-center gap-1"
                              title="Open Public Signing Portal in Test Mode"
                            >
                              <span>Test Portal</span>
                            </a>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SECURITY & SHA-256 INTEGRITY */}
      {activeTab === 'security' && !isCreator && (
        <div className="space-y-6">
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6">
            <div>
              <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-400" />
                <span>Tamper-Evident SHA-256 Checksums &amp; Zero-Trust Vault</span>
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-1">
                Every contract stored in Bloom Studio is cryptographically sealed with a SHA-256 digest to prevent unauthorized tampering or retroactive term modification.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-2">
                <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block">
                  Encryption Standard
                </span>
                <div className="text-sm font-bold text-white">AES-256-GCM at Rest &amp; TLS 1.3 in Transit</div>
                <p className="text-xs text-[#7C8AA8]">
                  All contract bodies, compensation terms, and talent emails are protected against unauthorized pod leakage.
                </p>
              </div>

              <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-2">
                <span className="text-[10px] font-mono uppercase text-emerald-400 font-bold block">
                  Access Control Hierarchy (ABAC)
                </span>
                <div className="text-sm font-bold text-white">Role-Based &amp; Pod-Isolated Scopes</div>
                <p className="text-xs text-[#7C8AA8]">
                  Directors hold full agency execution rights. Talent accounts can only access their personal agreements.
                </p>
              </div>
            </div>

            {/* Checksum Verification List */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs uppercase font-bold text-[#7C8AA8] tracking-wider">
                Active Contract Cryptographic Verification Table
              </h4>

              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {contracts.map(c => {
                  const partyName = c.party || c.name || 'Signing Party';
                  const hash = c.securityHash || generateSha256Hash(c.id, partyName);

                  return (
                    <div
                      key={c.id}
                      className="p-3 bg-[#111E33] border border-white/5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div>
                        <span className="font-bold text-white">{partyName}</span>
                        <span className="text-slate-400 text-xs ml-2 font-mono">({c.type})</span>
                        <div className="text-[10px] font-mono text-emerald-400/90 break-all mt-0.5">
                          {hash}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] bg-emerald-950 border border-emerald-500/40 text-emerald-300 px-2 py-0.5 rounded font-mono font-bold flex items-center gap-1">
                          <CheckCircle className="w-3 h-3 text-emerald-400" />
                          <span>VALID SEAL</span>
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: CREATE / STORE NEW CONTRACT */}
      {showNewContractModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="font-serif font-bold text-lg text-white">Create &amp; Store Legal Contract</h3>
              </div>
              <button
                onClick={() => setShowNewContractModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
              {/* Category & Exclusivity */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Agreement Category</label>
                  <select
                    value={newContractCategory}
                    onChange={e => {
                      const cat = e.target.value as any;
                      setNewContractCategory(cat);
                      if (cat === 'Agent Manager Agreement') {
                        setNewContractExclusivity('Commission Override' as any);
                        setNewContractSplit('15% Agent Commission Override on Managed Deals');
                        setNewContractScope('Assigned Roster Management, Brand Solicitations & Campaign Execution');
                        setNewContractTerms('15% deal commission override on assigned creator roster deals + $5,000 monthly retainer. 24-month non-solicitation of agency brand network and represented talent.');
                      } else {
                        setNewContractExclusivity('Exclusive');
                        setNewContractSplit('80% Creator / 20% Agency');
                        setNewContractScope('Full Commercial Sponsorships & Direct UGC Deals');
                        setNewContractTerms('Standard 12-month representation terms with 30-day non-renewal written notice.');
                      }
                    }}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    <option value="Talent Representation">Talent Representation (Creator)</option>
                    <option value="Agent Manager Agreement">Agent Manager Agreement (Staff / Operations)</option>
                    <option value="Brand Deal / UGC">Brand Deal / UGC</option>
                    <option value="One-Time Deal">One-Time Project Deal</option>
                    <option value="NDA / Confidentiality">NDA / Confidentiality</option>
                    <option value="MSA / Agency">MSA / Agency</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">
                    {newContractCategory === 'Agent Manager Agreement' ? 'Compensation Structure' : 'Exclusivity Status'}
                  </label>
                  {newContractCategory === 'Agent Manager Agreement' ? (
                    <select
                      value={newContractExclusivity}
                      onChange={e => setNewContractExclusivity(e.target.value as any)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                    >
                      <option value="Commission Override">Commission Override (15% Net)</option>
                      <option value="Retainer">Monthly Retainer + Commission</option>
                      <option value="Exclusive">Full-Time Exclusive Representation</option>
                    </select>
                  ) : (
                    <select
                      value={newContractExclusivity}
                      onChange={e => {
                        const val = e.target.value as any;
                        setNewContractExclusivity(val);
                        if (val === 'Exclusive') setNewContractSplit('80% Creator / 20% Agency (20% Agency Cut)');
                        else if (val === 'Non-Exclusive') setNewContractSplit('70% Creator / 30% Agency (30% Agency Cut)');
                        else if (val === 'One-Time') setNewContractSplit(`${100 - customAgencyPercentage}% Creator / ${customAgencyPercentage}% Agency (Custom One-Time Split)`);
                        else if (val === 'Flat Fee') setNewContractSplit(customFlatFeeAmount || '$500 Flat Agency Fee per Campaign');
                        else if (val === 'Co-Representation') setNewContractSplit('50% Split Management');
                      }}
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                    >
                      <option value="Exclusive">Exclusive Representation (20% Agency Cut / 80% Creator)</option>
                      <option value="Non-Exclusive">Non-Exclusive Representation (30% Agency Cut / 70% Creator)</option>
                      <option value="One-Time">One-Time Project / Single Deal (I Choose the Split)</option>
                      <option value="Flat Fee">Flat Fee Category (Fixed $ Compensation)</option>
                      <option value="Co-Representation">Co-Representation (50/50)</option>
                      <option value="Retainer">Monthly Retainer &amp; Ambassador</option>
                    </select>
                  )}
                </div>
              </div>

              {/* Special Agent Manager Dual-Role Covenant Section */}
              {newContractCategory === 'Agent Manager Agreement' && (
                <div className="bg-[#111E33] border border-amber-500/30 rounded-xl p-4 space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Staff Title / Role</label>
                      <select
                        value={newContractAgentRole}
                        onChange={e => setNewContractAgentRole(e.target.value)}
                        className="w-full bg-[#0D1830] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                      >
                        <option value="Agent manager">Agent manager</option>
                        <option value="Agent">Agent</option>
                        <option value="Coordinator">Coordinator</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Commission Override</label>
                      <input
                        type="text"
                        value={newContractCommissionOverride}
                        onChange={e => setNewContractCommissionOverride(e.target.value)}
                        placeholder="e.g. 15% Override on Managed Deals"
                        className="w-full bg-[#0D1830] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-emerald-400 font-mono outline-none focus:border-[#C9A46A]"
                      />
                    </div>
                  </div>

                  {/* Dual Role Choice */}
                  <div className="pt-2 border-t border-white/10">
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={newContractIsDualSigned}
                        onChange={e => setNewContractIsDualSigned(e.target.checked)}
                        className="w-4 h-4 rounded accent-[#C9A46A] cursor-pointer"
                      />
                      <div>
                        <span className="font-bold text-white text-xs flex items-center gap-2">
                          <span>⭐ This Agent Manager is also a Signed Creator in the Agency</span>
                          <span className="bg-[#C9A46A]/20 text-[#C9A46A] text-[9px] px-2 py-0.5 rounded-full font-mono font-bold uppercase">Dual-Role</span>
                        </span>
                        <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                          Indicate if this manager is actively signed to the agency as a creator with personal brand deals and an 80/20 revenue split.
                        </p>
                      </div>
                    </label>

                    {newContractIsDualSigned && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 p-3 bg-[#0D1830] border border-[#C9A46A]/30 rounded-xl">
                        <div className="space-y-1">
                          <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Personal Creator Handle</label>
                          <input
                            type="text"
                            value={newContractDualCreatorHandle}
                            onChange={e => setNewContractDualCreatorHandle(e.target.value)}
                            placeholder="e.g. @marcus_creator"
                            className="w-full bg-[#111E33] border border-amber-500/30 rounded-lg px-3 py-1.5 text-xs text-white font-mono outline-none"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Personal Talent Split</label>
                          <input
                            type="text"
                            value={newContractDualCreatorSplit}
                            onChange={e => setNewContractDualCreatorSplit(e.target.value)}
                            placeholder="e.g. 80% Creator / 20% Agency"
                            className="w-full bg-[#111E33] border border-amber-500/30 rounded-lg px-3 py-1.5 text-xs text-emerald-400 font-mono outline-none"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Signing Party & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">
                    {newContractCategory === 'Agent Manager Agreement' ? 'Agent Manager Name' : 'Signing Party (Creator / Brand)'}
                  </label>
                  <input
                    type="text"
                    placeholder={newContractCategory === 'Agent Manager Agreement' ? 'e.g. Marcus Cole' : 'e.g. Maya Paws (@mayapaws)'}
                    value={newContractParty}
                    onChange={e => setNewContractParty(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">
                    {newContractCategory === 'Agent Manager Agreement' ? 'Agency Work Email' : 'Party Legal Email'}
                  </label>
                  <input
                    type="email"
                    placeholder={newContractCategory === 'Agent Manager Agreement' ? 'e.g. marcus@bloomstudio.com' : 'e.g. maya@agencytalent.com'}
                    value={newContractPartyEmail}
                    onChange={e => setNewContractPartyEmail(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              {/* Custom Split Picker for One-Time or Flat Fee */}
              {newContractExclusivity === 'One-Time' && (
                <div className="bg-[#111E33] border border-sky-500/30 rounded-xl p-3.5 space-y-2.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-white">⚡ One-Time Project Split (You Choose):</span>
                    <span className="font-mono font-bold text-[#C9A46A]">{100 - customAgencyPercentage}% Creator / {customAgencyPercentage}% Agency Cut</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min={5}
                      max={50}
                      step={5}
                      value={customAgencyPercentage}
                      onChange={e => {
                        const val = parseInt(e.target.value, 10);
                        setCustomAgencyPercentage(val);
                        setNewContractSplit(`${100 - val}% Creator / ${val}% Agency (Custom One-Time Split)`);
                      }}
                      className="flex-1 accent-[#C9A46A] h-2 bg-[#0D1830] rounded-lg cursor-pointer"
                    />
                    <span className="font-mono text-xs font-bold text-amber-300 w-12 text-right">{customAgencyPercentage}% Cut</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {[10, 15, 20, 25, 30, 35].map(pct => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => {
                          setCustomAgencyPercentage(pct);
                          setNewContractSplit(`${100 - pct}% Creator / ${pct}% Agency (Custom One-Time Split)`);
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-semibold border transition-all cursor-pointer ${
                          customAgencyPercentage === pct
                            ? 'bg-[#C9A46A] text-[#0A1220] border-[#C9A46A]'
                            : 'bg-[#0D1830] text-slate-300 border-white/10 hover:border-white/20'
                        }`}
                      >
                        {100 - pct}/{pct} ({pct}% Cut)
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {newContractExclusivity === 'Flat Fee' && (
                <div className="bg-[#111E33] border border-purple-500/30 rounded-xl p-3.5 space-y-2.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-white">🏷️ Flat Fee Category Structure:</span>
                    <span className="font-mono font-bold text-purple-300">{customFlatFeeAmount}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {['$250 Flat UGC Fee', '$500 Flat Agency Fee', '$1,000 Flat Campaign Fee', '$2,500 Flat Brand Deal Fee', '$5,000 Flat Retainer'].map(feeStr => (
                      <button
                        key={feeStr}
                        type="button"
                        onClick={() => {
                          setCustomFlatFeeAmount(feeStr);
                          setNewContractSplit(feeStr);
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-semibold border transition-all cursor-pointer ${
                          customFlatFeeAmount === feeStr
                            ? 'bg-purple-600 text-white border-purple-400'
                            : 'bg-[#0D1830] text-slate-300 border-white/10 hover:border-white/20'
                        }`}
                      >
                        {feeStr}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Split & Estimated Value */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Revenue Split</label>
                  <input
                    type="text"
                    placeholder="e.g. 80% Creator / 20% Agency"
                    value={newContractSplit}
                    onChange={e => setNewContractSplit(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Estimated Contract Value</label>
                  <input
                    type="text"
                    placeholder="e.g. $30,000 / Year"
                    value={newContractValue}
                    onChange={e => setNewContractValue(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              {/* Dates */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Start Date</label>
                  <input
                    type="date"
                    value={newContractStartDate}
                    onChange={e => setNewContractStartDate(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">End Date</label>
                  <input
                    type="date"
                    value={newContractEndDate}
                    onChange={e => setNewContractEndDate(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              {/* Scope & Terms */}
              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Exclusivity Scope</label>
                <input
                  type="text"
                  placeholder="e.g. Full Commercial Representation across TikTok, IG, and YT"
                  value={newContractScope}
                  onChange={e => setNewContractScope(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Key Legal Terms Summary</label>
                <textarea
                  rows={3}
                  value={newContractTerms}
                  onChange={e => setNewContractTerms(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              {/* Attachment Simulator */}
              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Attach PDF / DOCX Document (Optional)</label>
                <div className="border-2 border-dashed border-white/10 rounded-xl p-4 text-center hover:border-amber-500/40 transition-colors">
                  {attachedFileName ? (
                    <div className="flex items-center justify-between bg-[#111E33] p-2.5 rounded-lg text-xs">
                      <div className="flex items-center gap-2 text-white font-medium">
                        <Paperclip className="w-4 h-4 text-amber-400" />
                        <span>{attachedFileName} (248 KB)</span>
                      </div>
                      <button
                        onClick={() => setAttachedFileName('')}
                        className="text-rose-400 hover:text-rose-300 text-xs font-semibold cursor-pointer"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Paperclip className="w-6 h-6 text-[#7C8AA8] mx-auto mb-1" />
                      <p className="text-xs text-slate-300 font-medium">Drag &amp; drop contract PDF or click to select</p>
                      <button
                        type="button"
                        onClick={() => setAttachedFileName(`${newContractParty || 'contract'}_representation_agreement.pdf`)}
                        className="mt-2 text-[11px] text-amber-300 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-lg cursor-pointer"
                      >
                        + Attach Standard Bloom Legal PDF
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end items-center gap-3 border-t border-white/10 pt-4">
              <button
                type="button"
                onClick={() => setShowNewContractModal(false)}
                className="px-4 py-2 bg-[#111E33] hover:bg-[#16243F] text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleCreateNewContract}
                className="px-5 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                Seal &amp; Store in Vault
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: FULL LEGAL DOCUMENT INSPECTOR */}
      {selectedContractForView && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-3xl w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                    AES-256 VERIFIED
                  </span>
                  <span className="text-[10px] font-mono text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-500/30 font-bold">
                    {selectedContractForView.exclusivityType || 'Exclusive'}
                  </span>
                </div>
                <h3 className="font-serif font-bold text-xl text-white mt-1">
                  {selectedContractForView.title || selectedContractForView.type}
                </h3>
              </div>
              <button
                onClick={() => setSelectedContractForView(null)}
                className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Body */}
            <div className="bg-[#111E33] p-6 rounded-xl border border-white/5 space-y-4 max-h-[60vh] overflow-y-auto text-xs leading-relaxed text-[#B8C0D4]">
              <div className="text-center border-b border-white/10 pb-4">
                <h4 className="font-serif font-bold text-base text-white uppercase tracking-wider">
                  BLOOM STUDIO MANAGEMENT &amp; TALENT AGENCY
                </h4>
                <p className="text-[10px] text-[#7C8AA8] font-mono mt-0.5">
                  OFFICIAL {selectedContractForView.isAgentManagerContract || selectedContractForView.agreementCategory === 'Agent Manager Agreement' ? 'AGENT MANAGER & OPERATING' : 'TALENT & BRAND'} LEGAL RECORD &bull; DOCUMENT ID: {selectedContractForView.id}
                </p>
              </div>

              {isStaffRestricted ? (
                /* PROTECTED VIEW FOR AGENT MANAGERS / RESTRICTED STAFF */
                <div className="bg-[#0D1830] p-6 rounded-xl border border-amber-500/30 text-center space-y-4 my-2">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400">
                    <Lock className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-serif font-bold text-base text-white">Internal Contract Text Protected</h4>
                    <p className="text-xs text-[#7C8AA8] max-w-md mx-auto leading-relaxed">
                      Internal clauses, legal terms, and document body text are restricted from Agent Manager view. Legal metadata, duration, and expiration dates are active.
                    </p>
                  </div>

                  <div className="bg-[#111E33] p-4 rounded-xl border border-white/10 max-w-md mx-auto grid grid-cols-2 gap-3 text-left font-mono text-xs">
                    <div>
                      <span className="text-[10px] text-[#7C8AA8] uppercase block">Contract Duration</span>
                      <span className="font-bold text-white">{selectedContractForView.start && selectedContractForView.end ? `${selectedContractForView.start} to ${selectedContractForView.end}` : '12 Months (Active)'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#7C8AA8] uppercase block">Expiration Date</span>
                      <span className="font-bold text-amber-300">{selectedContractForView.end || '2027-01-01'}</span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => handleSendReminderToResign(selectedContractForView)}
                      className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-lg cursor-pointer inline-flex items-center gap-2"
                    >
                      <Send className="w-4 h-4" />
                      <span>Send Re-sign Reminder to Creator</span>
                    </button>
                  </div>
                </div>
              ) : selectedContractForView.isAgentManagerContract || selectedContractForView.agreementCategory === 'Agent Manager Agreement' ? (
                /* AGENT MANAGER OPERATING AGREEMENT */
                <div className="space-y-4">
                  <p>
                    <strong className="text-white">THIS AGENT MANAGER OPERATING AGREEMENT</strong> is entered into as of{' '}
                    <span className="text-amber-300 font-mono">{selectedContractForView.start || '2026-01-01'}</span>, by and between{' '}
                    <strong className="text-white">BLOOM STUDIO AGENCY LLC</strong> (&ldquo;Agency&rdquo;) and{' '}
                    <strong className="text-white">{selectedContractForView.party || selectedContractForView.agentName || 'Agent Manager'}</strong> (&ldquo;Agent Manager / Talent Rep&rdquo;).
                  </p>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">1. APPOINTMENT &amp; FIDUCIARY ROSTER RESPONSIBILITIES</h5>
                    <p>
                      Agency hereby engages Agent Manager as a representative of Bloom Studio to manage, negotiate, and coordinate commercial brand campaigns, UGC deliverables, and creator communications across assigned talent rosters. Agent Manager acts as an agency fiduciary and operating staff member, distinct from signed talent.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">2. COMMISSION OVERRIDE &amp; COMPENSATION STRUCTURE</h5>
                    <p>
                      In consideration of talent management and brand solicitation services, Agent Manager shall receive a{' '}
                      <strong className="text-emerald-400 font-mono">{selectedContractForView.agentCommissionOverride || selectedContractForView.revenueSplit || '15% Commission Override'}</strong>{' '}
                      on all net collected agency revenue generated by creators in their assigned roster.
                      {selectedContractForView.baseSalaryOrRetainer && (
                        <span> Agency also authorizes a baseline monthly retainer of <strong className="text-white font-mono">{selectedContractForView.baseSalaryOrRetainer}</strong>.</span>
                      )}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">3. ESCROW DISBURSEMENTS &amp; ZERO-LEAKAGE COMPLIANCE</h5>
                    <p>
                      All gross campaign earnings, client invoices, and sponsor escrow deposits must be processed directly through Bloom Studio central banking and verified smart contracts. Agent Manager is strictly prohibited from receiving off-platform brand remittances or redirecting brand deals.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">4. 24-MONTH NON-SOLICITATION &amp; CONFIDENTIALITY</h5>
                    <p>
                      Agent Manager covenants that during affiliation and for a period of twenty-four (24) months post-termination, they shall not directly or indirectly solicit, induce, or divert any signed agency creator or registered brand client away from Bloom Studio.
                    </p>
                  </div>

                  {/* Dual-Signed Addendum */}
                  {(selectedContractForView.isDualSignedContract || selectedContractForView.contractTargetRole === 'dual_creator_agent' || selectedContractForView.creatorHandle) && (
                    <div className="p-4 bg-gradient-to-r from-purple-950/70 to-amber-950/70 border border-[#C9A46A]/40 rounded-xl space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-amber-400 font-bold text-xs">🌟 ADDENDUM: DUAL-ROLE SIGNED CREATOR STATUS</span>
                        <span className="bg-[#C9A46A]/20 text-[#C9A46A] text-[9px] px-2 py-0.5 rounded-full font-mono font-bold uppercase">
                          Covenant Active
                        </span>
                      </div>
                      <p className="text-[#E0E7FF] text-[11px] leading-relaxed">
                        <strong className="text-white">CONCURRENT TALENT REPRESENTATION:</strong> It is mutually acknowledged that Agent Manager is concurrently represented by Bloom Studio as a signed content creator ({selectedContractForView.creatorHandle || '@signed_talent'}). For personal brand sponsorships, UGC appearances, and commercial likeness licensing, Agent shall receive standard talent representation under an <strong className="text-emerald-300 font-mono">80% Creator / 20% Agency split</strong>. The 15% manager override applies strictly to other third-party roster talent managed by Agent.
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                /* STANDARD TALENT / BRAND REPRESENTATION AGREEMENT */
                <div className="space-y-4">
                  <p>
                    <strong className="text-white">THIS AGREEMENT</strong> is entered into as of{' '}
                    <span className="text-amber-300 font-mono">{selectedContractForView.start || '2026-01-01'}</span>, by and between{' '}
                    <strong className="text-white">BLOOM STUDIO AGENCY LLC</strong> (&ldquo;Agency&rdquo;) and{' '}
                    <strong className="text-white">{selectedContractForView.party || 'Talent'}</strong> (&ldquo;Signing Party&rdquo;).
                  </p>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">1. SCOPE OF REPRESENTATION &amp; EXCLUSIVITY</h5>
                    <p>
                      Signing Party grants Agency {selectedContractForView.exclusivityType || 'exclusive'} rights across the agreed media channels ({selectedContractForView.exclusivityScope || 'TikTok, Instagram, and YouTube'}) to solicit, negotiate, and execute commercial sponsorships, brand partnerships, and UGC licensing deliverables.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">2. COMPENSATION &amp; REVENUE SPLIT</h5>
                    <p>
                      All gross compensation earned under this Agreement shall be distributed according to the established split schedule:{' '}
                      <strong className="text-emerald-400 font-mono">
                        {isStaffRestricted ? '•••• Protected Agency Terms' : (selectedContractForView.revenueSplit || selectedContractForView.terms || '80% Talent / 20% Agency')}
                      </strong>.
                      Agency shall manage brand collection, escrow holdings, and FTC compliance verifications.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">3. TERM &amp; TERMINATION</h5>
                    <p>
                      This Agreement shall remain in effect from{' '}
                      <span className="text-white font-mono">{selectedContractForView.start || '2026-01-01'}</span> through{' '}
                      <span className="text-white font-mono">{selectedContractForView.end || '2027-01-01'}</span>. Either party may provide thirty (30) days written notice prior to term expiration to conclude representation.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="font-bold text-white uppercase text-[11px]">4. CONFIDENTIALITY &amp; BRAND SAFETY</h5>
                    <p>
                      Both parties agree to maintain strict confidentiality regarding financial rates, brand negotiations, and non-public campaign deliverables in accordance with Bloom Studio Global Security Policy.
                    </p>
                  </div>
                </div>
              )}

              {/* Digital Signatures Block */}
              <div className="pt-4 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-[#0D1830] p-3 rounded-lg border border-white/5 space-y-1 font-mono text-[11px]">
                  <span className="text-[10px] text-[#7C8AA8] uppercase block">Agency Representative</span>
                  <div className="font-bold text-emerald-400">✅ {selectedContractForView.signatures?.agencySignedBy || 'Agency Leadership'}</div>
                  <div className="text-[10px] text-[#7C8AA8]">Signed: {selectedContractForView.signatures?.agencySignedDate || selectedContractForView.start || '2026-01-01'}</div>
                </div>

                <div className="bg-[#0D1830] p-3 rounded-lg border border-white/5 space-y-1 font-mono text-[11px]">
                  <span className="text-[10px] text-[#7C8AA8] uppercase block">
                    {selectedContractForView.isAgentManagerContract || selectedContractForView.agreementCategory === 'Agent Manager Agreement' ? 'Agent Manager Signee' : 'Signing Party Representative'}
                  </span>
                  <div className="font-bold text-amber-300">✅ {selectedContractForView.party || selectedContractForView.agentName || 'Talent Representative'}</div>
                  <div className="text-[10px] text-[#7C8AA8]">Verified: {selectedContractForView.start || '2026-01-01'}</div>
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="flex flex-wrap justify-between items-center gap-3 border-t border-white/10 pt-4">
              <div className="text-[10px] font-mono text-[#7C8AA8] flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-emerald-400" />
                <span>SHA-256: {(selectedContractForView.securityHash || generateSha256Hash(selectedContractForView.id, selectedContractForView.party || '')).slice(0, 24)}...</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    notify('PDF Exported', 'Contract PDF compiled and saved to local downloads.', 'success');
                  }}
                  className="px-3.5 py-2 bg-[#111E33] hover:bg-[#16243F] text-slate-200 border border-white/10 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download PDF</span>
                </button>

                {!isCreator && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        const contract = selectedContractForView;
                        setSelectedContractForView(null);
                        handleOpenEmailModal(contract);
                      }}
                      className="px-4 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Email Out to Talent</span>
                    </button>

                    <button
                      type="button"
                      id="btn-delete-contract-modal"
                      onClick={() => {
                        const contractId = selectedContractForView.id;
                        setSelectedContractForView(null);
                        onDeleteContract(contractId);
                      }}
                      className="px-3.5 py-2 bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="Move contract to Recoup Trash"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: SECURE CONTRACT EMAIL DISPATCH */}
      {selectedContractForEmail && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0D1830] border border-amber-500/40 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-amber-400" />
                <h3 className="font-serif font-bold text-lg text-white">
                  Dispatch Contract via Secure Email
                </h3>
              </div>
              <button
                onClick={() => setSelectedContractForEmail(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
              {/* Recipient info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Recipient Name</label>
                  <input
                    type="text"
                    value={emailRecipientName}
                    onChange={e => setEmailRecipientName(e.target.value)}
                    placeholder="e.g. Maya Paws"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Recipient Email</label>
                  <input
                    type="email"
                    value={emailRecipient}
                    onChange={e => setEmailRecipient(e.target.value)}
                    placeholder="e.g. maya@agencytalent.com"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              {/* Subject */}
              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Email Subject Line</label>
                <input
                  type="text"
                  value={emailSubject}
                  onChange={e => setEmailSubject(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              {/* Cover Note with Quick Templates */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Cover Message / Note</label>
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-[#7C8AA8]">Templates:</span>
                    <button
                      type="button"
                      onClick={() =>
                        setEmailCoverNote(
                          `Dear ${emailRecipientName},\n\nPlease review and execute the attached Exclusive Talent Representation Agreement with Bloom Studio.\n\nSplit: 80% Talent / 20% Agency\nTerm: 12 Months\n\nClick the secure link below to sign.`
                        )
                      }
                      className="text-[10px] text-amber-300 hover:underline cursor-pointer"
                    >
                      Exclusive
                    </button>
                    <span className="text-[#7C8AA8]">&bull;</span>
                    <button
                      type="button"
                      onClick={() =>
                        setEmailCoverNote(
                          `Dear ${emailRecipientName},\n\nAttached is the One-Time Campaign Agreement for your upcoming brand deliverable.\n\nAgency Fee: 15%\nDeliverable Deadline: 14 Days\n\nPlease execute via the link below.`
                        )
                      }
                      className="text-[10px] text-sky-300 hover:underline cursor-pointer"
                    >
                      One-Time Deal
                    </button>
                    <span className="text-[#7C8AA8]">&bull;</span>
                    <button
                      type="button"
                      onClick={() =>
                        setEmailCoverNote(
                          `Dear ${emailRecipientName},\n\nAttached is your Agent Manager Operating Agreement governing your staff management responsibilities, talent roster commission override (15%), and agency representation provisions.\n\nPlease review and sign digitally.`
                        )
                      }
                      className="text-[10px] text-emerald-300 hover:underline cursor-pointer"
                    >
                      Agent Agreement
                    </button>
                    <span className="text-[#7C8AA8]">&bull;</span>
                    <button
                      type="button"
                      onClick={() =>
                        setEmailCoverNote(
                          `Dear ${emailRecipientName},\n\nAttached is your Dual-Role Agent Manager & Signed Creator Agreement. This establishes both your 15% agency management commission override and your 80/20 exclusive creator representation rights with Bloom Studio.\n\nPlease execute digitally.`
                        )
                      }
                      className="text-[10px] text-purple-300 hover:underline cursor-pointer"
                    >
                      Dual-Role
                    </button>
                  </div>
                </div>

                <textarea
                  rows={5}
                  value={emailCoverNote}
                  onChange={e => setEmailCoverNote(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              {/* Security Controls */}
              <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-3">
                <span className="text-[10px] font-mono uppercase text-amber-400 font-bold block">
                  Envelope Security Controls
                </span>

                <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={emailRequirePin}
                      onChange={e => setEmailRequirePin(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-500"
                    />
                    <span className="text-slate-300">Require Access PIN to unlock document</span>
                  </label>

                  {emailRequirePin && (
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-[#7C8AA8]">PIN:</span>
                      <input
                        type="text"
                        value={emailPinCode}
                        onChange={e => setEmailPinCode(e.target.value)}
                        className="w-20 bg-[#0D1830] border border-white/10 rounded-lg px-2 py-1 text-xs text-white font-mono text-center"
                      />
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between gap-3 text-xs pt-2 border-t border-white/5">
                  <span className="text-slate-400">Signing Link Expiration:</span>
                  <select
                    value={emailExpireDays}
                    onChange={e => setEmailExpireDays(e.target.value)}
                    className="bg-[#0D1830] border border-white/10 text-white text-xs rounded-lg px-2.5 py-1"
                  >
                    <option value="3">3 Days</option>
                    <option value="7">7 Days</option>
                    <option value="14">14 Days</option>
                    <option value="30">30 Days</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap justify-between items-center gap-3 border-t border-white/10 pt-4">
              <a
                href={`mailto:${emailRecipient}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailCoverNote)}`}
                className="text-xs text-[#7C8AA8] hover:text-white flex items-center gap-1 transition-colors"
                target="_blank"
                rel="noreferrer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open in Desktop Email Client</span>
              </a>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedContractForEmail(null)}
                  className="px-4 py-2 bg-[#111E33] hover:bg-[#16243F] text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isSendingEmail}
                  onClick={handleDispatchEmail}
                  className="px-5 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingEmail ? 'Dispatching Envelope...' : 'Send Secure Contract Email'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: QUICK EXCLUSIVITY / REPRESENTATION LOGGER */}
      {showQuickExclusivityModal && selectedCreatorForExclusivity && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0D1830] border border-amber-500/40 rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-amber-400" />
                <h3 className="font-serif font-bold text-lg text-white">
                  Log Representation: {selectedCreatorForExclusivity.name}
                </h3>
              </div>
              <button
                onClick={() => setShowQuickExclusivityModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Representation Model</label>
                <select
                  value={quickAgreementType}
                  onChange={e => {
                    const val = e.target.value;
                    setQuickAgreementType(val);
                    if (val === 'Exclusive') setQuickSplit('80% (20% Agency Cut)');
                    else if (val === 'Non-Exclusive') setQuickSplit('70% (30% Agency Cut)');
                    else if (val === 'One-Time Deal') setQuickSplit('85% (Custom One-Time)');
                    else if (val === 'Flat Fee') setQuickSplit('$500 Flat Fee');
                    else if (val === 'Co-Representation') setQuickSplit('50% (50/50)');
                  }}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                >
                  <option value="Exclusive">Exclusive Representation (20% Agency Cut / 80% Creator)</option>
                  <option value="Non-Exclusive">Non-Exclusive (30% Agency Cut / 70% Creator)</option>
                  <option value="One-Time Deal">One-Time Project / Single Deal (I Choose the Split)</option>
                  <option value="Flat Fee">Flat Fee Category (Fixed $ Fee per Campaign)</option>
                  <option value="Co-Representation">Co-Representation (Joint Management 50/50)</option>
                  <option value="Monthly Retainer">Monthly Retainer &amp; Brand Ambassador</option>
                  <option value="Work-for-Hire">Work-for-Hire / Whitelisting Licensing</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Creator Commission Split</label>
                  <select
                    value={quickSplit}
                    onChange={e => setQuickSplit(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer"
                  >
                    <option value="85%">85% Creator / 15% Agency</option>
                    <option value="80%">80% Creator / 20% Agency</option>
                    <option value="75%">75% Creator / 25% Agency</option>
                    <option value="70%">70% Creator / 30% Agency</option>
                    <option value="60%">60% Creator / 40% Agency</option>
                    <option value="50%">50% Creator / 50% Agency (Co-Rep)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-semibold">Category / Platform Lock</label>
                  <input
                    type="text"
                    value={quickScope}
                    onChange={e => setQuickScope(e.target.value)}
                    placeholder="e.g. Full Commercial or Beauty Niche Only"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end items-center gap-3 border-t border-white/10 pt-4">
              <button
                type="button"
                onClick={() => setShowQuickExclusivityModal(false)}
                className="px-4 py-2 bg-[#111E33] hover:bg-[#16243F] text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveQuickExclusivity}
                className="px-5 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                Save Representation Status
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Multi-File & PDF Viewer Modal */}
      <MultiFilePdfViewerModal
        isOpen={docViewerOpen}
        onClose={() => setDocViewerOpen(false)}
        title={docViewerTitle}
        files={docViewerFiles}
      />
    </div>
  );
};
