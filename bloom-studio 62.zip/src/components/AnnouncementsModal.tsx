/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Bell, 
  Megaphone, 
  X, 
  Users, 
  User, 
  Search, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  Smartphone, 
  MessageSquare, 
  ShieldCheck, 
  Filter, 
  ExternalLink,
  ChevronRight,
  Send,
  Lock,
  Radio
} from 'lucide-react';
import { Role, Creator } from '../types';

export interface AnnouncementItem {
  id: string;
  title: string;
  text: string;
  date: string;
  createdAt?: string;
  author: string;
  authorRole?: string;
  audience: string; // 'All Agency' | 'Everyone' | 'Creators Only' | 'Staff Only' | 'Assigned Roster' | 'Specific Creator' | 'Specific Team'
  targetCreatorName?: string;
  targetCreatorHandle?: string;
  targetTeamName?: string;
  readBy?: string[];
  priority?: 'normal' | 'important' | 'urgent';
  channels?: string[];
}

interface AnnouncementsModalProps {
  isOpen: boolean;
  onClose: () => void;
  announcements: AnnouncementItem[];
  setAnnouncements: React.Dispatch<React.SetStateAction<AnnouncementItem[]>>;
  currentRole: Role;
  currentUser: any;
  creators: Creator[];
  onOpenMassBroadcast: () => void;
  onOpenDirectMessageLookup: () => void;
  onOpenPhoneSimulator: () => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog: (user: string, role: string, action: string) => void;
}

export const AnnouncementsModal: React.FC<AnnouncementsModalProps> = ({
  isOpen,
  onClose,
  announcements,
  setAnnouncements,
  currentRole,
  currentUser,
  creators,
  onOpenMassBroadcast,
  onOpenDirectMessageLookup,
  onOpenPhoneSimulator,
  triggerNotification,
  onAddActivityLog
}) => {
  const [activeTab, setActiveTab] = useState<'everyone' | 'creators' | 'team'>('everyone');
  const [searchQuery, setSearchQuery] = useState('');
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [teamFilter, setTeamFilter] = useState<string>('all');

  const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase());
  const roleName = (currentRole || 'none').toLowerCase();
  const isCreator = roleName === 'creator';
  const isBrand = roleName === 'brand';
  const isStaff = ['agentmgr', 'agent', 'coordinator'].includes(roleName);

  // Filter announcements for non-directors so they ONLY see what the director specifically sent to them
  const recipientAllowedAnnouncements = useMemo(() => {
    if (isDirector) return announcements;

    return announcements.filter(ann => {
      const aud = (ann.audience || '').toLowerCase();
      const targetTeam = (ann.targetTeamName || '').toLowerCase();
      const targetCreator = (ann.targetCreatorName || ann.targetCreatorHandle || '').toLowerCase();
      const myHandle = (currentUser?.handle || '').toLowerCase();
      const myName = (currentUser?.name || '').toLowerCase();

      // Everyone broadcast
      if (aud.includes('everyone') || aud.includes('all agency') || aud === 'all') {
        return true;
      }

      // Creator viewing
      if (isCreator) {
        if (aud.includes('creator') || aud.includes('talent') || aud.includes('roster')) {
          // If targeted to a specific creator
          if (ann.targetCreatorHandle || ann.targetCreatorName) {
            return (
              (myHandle && targetCreator.includes(myHandle)) ||
              (myName && targetCreator.includes(myName)) ||
              targetCreator.includes('alexjones') // default sandbox match
            );
          }
          return true;
        }
        return false;
      }

      // Staff (Agent Manager, Agent, Coordinator) viewing
      if (isStaff) {
        if (aud.includes('staff') || aud.includes('team')) {
          if (roleName === 'agentmgr') {
            return targetTeam.includes('all') || targetTeam.includes('manager') || targetTeam.includes('staff') || !targetTeam;
          }
          if (roleName === 'agent') {
            return targetTeam.includes('all') || targetTeam.includes('agent') || targetTeam.includes('staff') || !targetTeam;
          }
          if (roleName === 'coordinator') {
            return targetTeam.includes('all') || targetTeam.includes('coordinator') || targetTeam.includes('staff') || !targetTeam;
          }
          return true;
        }
        return false;
      }

      // Brand viewing
      if (isBrand) {
        return aud.includes('brand');
      }

      return false;
    });
  }, [announcements, isDirector, isCreator, isStaff, isBrand, roleName, currentUser]);

  // Categorize announcements for director
  const categorized = useMemo(() => {
    const everyoneList: AnnouncementItem[] = [];
    const creatorsList: AnnouncementItem[] = [];
    const teamList: AnnouncementItem[] = [];

    announcements.forEach(ann => {
      const aud = (ann.audience || '').toLowerCase();
      const targetTeam = (ann.targetTeamName || '').toLowerCase();
      const targetCreator = (ann.targetCreatorName || ann.targetCreatorHandle || '').toLowerCase();

      if (aud.includes('everyone') || aud.includes('all agency') || aud === 'all') {
        everyoneList.push(ann);
      } else if (aud.includes('creator') || aud.includes('talent') || aud.includes('roster') || targetCreator) {
        creatorsList.push(ann);
      } else if (aud.includes('staff') || aud.includes('team') || aud.includes('agent') || aud.includes('manager') || aud.includes('coordinator') || targetTeam) {
        teamList.push(ann);
      } else {
        everyoneList.push(ann);
      }
    });

    return {
      everyone: everyoneList,
      creators: creatorsList,
      team: teamList
    };
  }, [announcements]);

  // Current list to display
  const currentList = useMemo(() => {
    // If not director, directly return the recipient list filtered by search
    if (!isDirector) {
      if (!searchQuery.trim()) return recipientAllowedAnnouncements;
      const q = searchQuery.toLowerCase().trim();
      return recipientAllowedAnnouncements.filter(ann => 
        ann.title.toLowerCase().includes(q) ||
        ann.text.toLowerCase().includes(q) ||
        ann.author.toLowerCase().includes(q)
      );
    }

    // Director 3-tab view
    let list: AnnouncementItem[] = [];
    if (activeTab === 'everyone') {
      list = categorized.everyone;
    } else if (activeTab === 'creators') {
      list = categorized.creators;
      if (creatorFilter !== 'all') {
        list = list.filter(ann => {
          const matchTarget = (ann.targetCreatorHandle || ann.targetCreatorName || '').toLowerCase();
          const q = creatorFilter.toLowerCase();
          return matchTarget.includes(q) || (ann.text && ann.text.toLowerCase().includes(q)) || ann.audience.toLowerCase().includes(q);
        });
      }
    } else if (activeTab === 'team') {
      list = categorized.team;
      if (teamFilter !== 'all') {
        list = list.filter(ann => {
          const matchTeam = (ann.targetTeamName || ann.audience || '').toLowerCase();
          const q = teamFilter.toLowerCase();
          return matchTeam.includes(q) || (ann.text && ann.text.toLowerCase().includes(q));
        });
      }
    }

    if (!searchQuery.trim()) return list;

    const q = searchQuery.toLowerCase().trim();
    return list.filter(ann => 
      ann.title.toLowerCase().includes(q) ||
      ann.text.toLowerCase().includes(q) ||
      ann.author.toLowerCase().includes(q) ||
      (ann.audience && ann.audience.toLowerCase().includes(q)) ||
      (ann.targetCreatorName && ann.targetCreatorName.toLowerCase().includes(q)) ||
      (ann.targetTeamName && ann.targetTeamName.toLowerCase().includes(q))
    );
  }, [isDirector, recipientAllowedAnnouncements, categorized, activeTab, creatorFilter, teamFilter, searchQuery]);

  if (!isOpen) return null;

  const handleDeleteAnnouncement = (id: string, title: string) => {
    if (!isDirector) return;
    setAnnouncements(prev => prev.filter(x => x.id !== id));
    triggerNotification('Announcement Deleted', `"${title}" has been removed.`, 'info');
    onAddActivityLog(currentUser?.name || 'User', currentRole, `Deleted announcement: ${title}`);
  };

  const getAudienceBadge = (ann: AnnouncementItem) => {
    const aud = ann.audience;
    if (ann.targetCreatorName || ann.targetCreatorHandle) {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-semibold flex items-center gap-1">
          <User className="w-3 h-3" /> Per Creator: {ann.targetCreatorHandle || ann.targetCreatorName}
        </span>
      );
    }
    if (ann.targetTeamName) {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 font-semibold flex items-center gap-1">
          <Users className="w-3 h-3" /> Per Team: {ann.targetTeamName}
        </span>
      );
    }
    if (aud.includes('Creator') || aud.includes('Roster')) {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-semibold flex items-center gap-1">
          <User className="w-3 h-3" /> Per Creator (All Talent)
        </span>
      );
    }
    if (aud.includes('Staff') || aud.includes('Agent') || aud.includes('Manager')) {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 font-semibold flex items-center gap-1">
          <Users className="w-3 h-3" /> Per Team (Staff &amp; Agents)
        </span>
      );
    }
    return (
      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 font-semibold flex items-center gap-1">
        <Megaphone className="w-3 h-3" /> Everyone (Studio-Wide)
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in font-sans">
      <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#111E33]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">
                  {isDirector ? 'Director Broadcast Center' : 'Director Phone Notifications & Bulletins'}
                </h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500 text-slate-950">
                  {isDirector ? `${announcements.length} Dispatched` : `${recipientAllowedAnnouncements.length} Received`}
                </span>
              </div>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                {isDirector 
                  ? 'Dispatch and oversee mobile phone push alerts & SMS announcements to Everyone, Per Creator, and Per Team.' 
                  : 'Official directives, guidelines, and urgent notifications received directly on your mobile device from the Agency Director.'}
              </p>
            </div>
          </div>

          {/* Header Action Buttons */}
          <div className="flex items-center gap-2">
            {/* ONLY the Director can broadcast */}
            {isDirector && (
              <button
                onClick={() => {
                  onClose();
                  onOpenMassBroadcast();
                }}
                className="px-3 py-2 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md"
                title="Send Mass Text & Announcement to Everyone, Per Creator, or Per Team"
              >
                <Plus className="w-4 h-4" /> Mass Send Text
              </button>
            )}

            <button
              onClick={() => {
                onClose();
                onOpenDirectMessageLookup();
              }}
              className="px-3 py-2 rounded-xl bg-[#16243F] hover:bg-[#1f3050] text-[#C9A46A] border border-[#C9A46A]/30 font-semibold text-xs flex items-center gap-1.5 transition cursor-pointer"
              title="Search and send private 1-on-1 direct message"
            >
              <MessageSquare className="w-4 h-4" /> DM Lookup
            </button>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/5 transition cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mobile Phone Notification Info Banner */}
        <div className="px-4 py-2.5 bg-gradient-to-r from-amber-500/10 via-[#111E33] to-sky-500/10 border-b border-white/5 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-amber-300 font-medium">
            <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              {isDirector 
                ? '📱 Mobile Dispatch Routing: All broadcasts are pushed directly as SMS & Lockscreen Phone Notifications to recipients.'
                : '📱 Mobile Push & SMS Alert Feed: Messages sent by the Director appear instantly on your device lockscreen.'}
            </span>
          </div>
          <button
            onClick={() => {
              onClose();
              onOpenPhoneSimulator();
            }}
            className="text-[11px] font-semibold text-sky-400 hover:text-sky-300 underline shrink-0 cursor-pointer flex items-center gap-1"
          >
            <Smartphone className="w-3.5 h-3.5" /> View Phone Simulator
          </button>
        </div>

        {/* Primary Tabs & Filter Toolbar (Only Director sees tabs; non-directors see recipient search) */}
        {isDirector ? (
          <div className="p-4 border-b border-white/5 bg-[#0D1830] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              {/* Main Tabs */}
              <div className="flex items-center gap-2 bg-[#111E33] p-1 rounded-xl border border-white/5 shrink-0">
                <button
                  onClick={() => setActiveTab('everyone')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                    activeTab === 'everyone'
                      ? 'bg-amber-500 text-slate-950 font-bold shadow'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Megaphone className="w-3.5 h-3.5" />
                  Everyone ({categorized.everyone.length})
                </button>

                <button
                  onClick={() => setActiveTab('creators')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                    activeTab === 'creators'
                      ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  Per Creator ({categorized.creators.length})
                </button>

                <button
                  onClick={() => setActiveTab('team')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                    activeTab === 'team'
                      ? 'bg-indigo-500 text-white font-bold shadow'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  Per Team ({categorized.team.length})
                </button>
              </div>

              {/* Search Input */}
              <div className="relative flex-1 max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={`Search ${activeTab} announcements...`}
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-9 pr-4 py-1.5 text-xs text-white placeholder-slate-400 outline-none focus:border-[#C9A46A]"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* Sub-Filters for Creator / Team */}
            {activeTab === 'creators' && creators.length > 0 && (
              <div className="flex items-center gap-2 flex-wrap pt-1 text-xs">
                <span className="text-[11px] font-mono text-slate-400 uppercase">Filter Creator:</span>
                <button
                  onClick={() => setCreatorFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                    creatorFilter === 'all'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-[#111E33] text-slate-400 hover:text-white'
                  }`}
                >
                  All Creators
                </button>
                {creators.slice(0, 6).map(c => (
                  <button
                    key={c.id}
                    onClick={() => setCreatorFilter(c.handle || c.name)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                      creatorFilter === (c.handle || c.name)
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-[#111E33] text-slate-400 hover:text-white'
                    }`}
                  >
                    {c.handle || c.name}
                  </button>
                ))}
              </div>
            )}

            {activeTab === 'team' && (
              <div className="flex items-center gap-2 flex-wrap pt-1 text-xs">
                <span className="text-[11px] font-mono text-slate-400 uppercase">Filter Team:</span>
                <button
                  onClick={() => setTeamFilter('all')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                    teamFilter === 'all'
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-[#111E33] text-slate-400 hover:text-white'
                  }`}
                >
                  All Staff
                </button>
                <button
                  onClick={() => setTeamFilter('agent manager')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                    teamFilter === 'agent manager'
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-[#111E33] text-slate-400 hover:text-white'
                  }`}
                >
                  Agent Managers
                </button>
                <button
                  onClick={() => setTeamFilter('agent')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                    teamFilter === 'agent'
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-[#111E33] text-slate-400 hover:text-white'
                  }`}
                >
                  Talent Agents
                </button>
                <button
                  onClick={() => setTeamFilter('coordinator')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                    teamFilter === 'coordinator'
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-[#111E33] text-slate-400 hover:text-white'
                  }`}
                >
                  Coordinators
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="p-3.5 border-b border-white/5 bg-[#0D1830] flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Recipient Mode: Only Director broadcasts addressed to you are displayed.</span>
            </div>
            <div className="relative w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search your notifications..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-9 pr-4 py-1 text-xs text-white placeholder-slate-400 outline-none focus:border-[#C9A46A]"
              />
            </div>
          </div>
        )}

        {/* Content List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {currentList.length === 0 ? (
            <div className="text-center py-12 bg-[#111E33]/40 rounded-2xl border border-white/5 space-y-3">
              <Smartphone className="w-10 h-10 text-slate-500 mx-auto" />
              <div>
                <h4 className="text-sm font-bold text-white">
                  {isDirector ? 'No Announcements Found' : 'No Phone Notifications Received Yet'}
                </h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  {isDirector 
                    ? (searchQuery ? `No broadcasts matching "${searchQuery}".` : `No announcements have been published in the ${activeTab} category yet.`)
                    : 'When the Agency Director sends a broadcast or mobile alert to your role, it will appear here and on your phone simulator.'}
                </p>
              </div>
            </div>
          ) : (
            currentList.map(ann => (
              <div 
                key={ann.id}
                className="p-4 sm:p-5 bg-[#111E33] hover:bg-[#16243F]/80 border border-white/5 hover:border-amber-500/30 rounded-2xl space-y-3 transition-all shadow-sm"
              >
                {/* Top Row: Title, Target Audience Badge, Timestamp */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <h4 className="text-sm sm:text-base font-bold text-white leading-snug">
                      {ann.title}
                    </h4>
                    {getAudienceBadge(ann)}
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-300 font-semibold flex items-center gap-1">
                      <Smartphone className="w-3 h-3 text-sky-400" /> Phone Push &amp; SMS
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 text-slate-400 text-xs font-mono">
                    <Clock className="w-3.5 h-3.5 text-[#C9A46A]" />
                    <span>{ann.date || 'Today'}</span>
                  </div>
                </div>

                {/* Announcement Body */}
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {ann.text}
                </p>

                {/* Footer: Author, Read Receipts, Actions */}
                <div className="pt-3 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3 flex-wrap text-slate-400">
                    <span className="text-[11px]">
                      From: <strong className="text-white">{ann.author}</strong> ({ann.authorRole || 'Agency Director'})
                    </span>

                    {/* Read Receipts Tracker */}
                    {isDirector && (
                      <div className="flex items-center gap-1.5 text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>
                          Viewed by ({ann.readBy?.length || 0}):
                        </span>
                        {ann.readBy && ann.readBy.length > 0 ? (
                          <div className="flex items-center gap-1 flex-wrap">
                            {ann.readBy.slice(0, 4).map((name, i) => (
                              <span key={i} className="text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded text-[10px] font-mono">
                                {name}
                              </span>
                            ))}
                            {ann.readBy.length > 4 && (
                              <span className="text-slate-400 text-[10px]">+{ann.readBy.length - 4} more</span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-500 italic text-[10px]">Pending initial reads</span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => {
                        onClose();
                        onOpenPhoneSimulator();
                      }}
                      className="text-[11px] font-medium text-sky-300 hover:text-sky-200 px-2.5 py-1 rounded-lg bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/20 transition flex items-center gap-1 cursor-pointer"
                      title="Inspect lockscreen push alert on Phone Simulator"
                    >
                      <Smartphone className="w-3 h-3" /> View on Phone
                    </button>

                    <button
                      onClick={() => {
                        onClose();
                        onOpenDirectMessageLookup();
                      }}
                      className="text-[11px] font-medium text-[#C9A46A] hover:text-[#E3C48F] px-2.5 py-1 rounded-lg bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 transition flex items-center gap-1 cursor-pointer"
                      title="Reply privately to the Director"
                    >
                      <MessageSquare className="w-3 h-3" /> Reply / DM
                    </button>

                    {isDirector && (
                      <button
                        onClick={() => handleDeleteAnnouncement(ann.id, ann.title)}
                        className="text-[11px] font-medium text-rose-400 hover:text-rose-300 px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 transition flex items-center gap-1 cursor-pointer"
                        title="Delete this announcement"
                      >
                        <Trash2 className="w-3 h-3" /> Delete
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer info bar */}
        <div className="p-3.5 border-t border-white/5 bg-[#111E33] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Director Broadcast Mesh
            </span>
            <span>•</span>
            <button
              onClick={() => {
                onClose();
                onOpenPhoneSimulator();
              }}
              className="text-[#C9A46A] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5" /> View Mobile Lockscreen Notifications
            </button>
          </div>
          <span className="text-[11px] font-mono text-slate-500">
            {isDirector 
              ? `${announcements.length} Total Agency Announcements Stored`
              : `${recipientAllowedAnnouncements.length} Notifications for your profile`}
          </span>
        </div>

      </div>
    </div>
  );
};
