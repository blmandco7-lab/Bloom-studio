import React, { useState, useEffect } from 'react';
import { BookOpen, Sparkles, Send, Share2, Copy, CheckCircle2, ArrowRight, FileText, RefreshCw } from 'lucide-react';
import { db } from '../lib/firebase';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  query, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';

export interface InsightArticle {
  id: string;
  slug: string;
  title: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  keywords: string[];
  readTime: string;
  publishedDate: string;
  summary: string;
  markdownContent: string;
}

interface AgencyPublicInsightsProps {
  initialArticles?: InsightArticle[];
  currentRole?: string;
}

/**
 * AgencyPublicInsights:
 * Public-facing insights and white paper reader outside tenant pods.
 * Features a Director generator form and a clean "White Paper" reading layout.
 * Decoupled from Firebase tenant write contexts.
 */
export default function AgencyPublicInsights({
  currentRole,
  initialArticles = [
    {
      id: "art_1",
      slug: "pet-ugc-strategies-2026",
      title: "Engineering High-Conversion Pet UGC: Why 4K Authenticity Beats Studio Commercials",
      niche: "Pets",
      keywords: ["Pet UGC strategies", "Canine influencer ROI", "FTC pet compliance"],
      readTime: "4 min read",
      publishedDate: "August 20, 2026",
      summary: "An analysis of 1.2M organic views across canine wellness and grooming campaigns, demonstrating why raw UGC formats convert 180% higher than traditional product staging.",
      markdownContent: `
# Engineering High-Conversion Pet UGC: Why 4K Authenticity Beats Studio Commercials

*Published by Bloom Studio Research Group &bull; August 2026*

---

### Executive Summary
In the pet wellness and grooming verticals, consumer trust is inextricably linked to raw, unfiltered pet reactions. Traditional 30-second studio commercials fail to demonstrate authentic product palatability and pet comfort. Our recent analysis across **12 canine campaigns** demonstrates a **180% increase in ROAS** when brands switch to mobile 4K user-generated video reels.

---

### 1. The Frictionless First 3 Seconds (Pet Hook Rate)
Canine attention hooks must establish emotional resonance instantly:
- **Zero Second Hook**: Immediate close-up of a canine tasting or reacting to the balm/shampoo.
- **Auditory Clarity**: Crisp ASMR sound design (chewing, tail wagging, organic water splashes).
- **FTC Tagging**: Unambiguous visual and audible disclosure at second 0 to prevent ad account strikes.

---

### 2. Eliminating Ad Fatigue Through Whitelisting
Direct creator whitelisting outperformed brand-owned dark posts by **2.4x in click-through rate (CTR)**. Audiences perceive content coming directly from verified pet accounts as an organic community recommendation rather than corporate marketing.

---

### Key Takeaways for Pet Brand Marketers
1. **Prioritize 9:16 mobile-first framing** over glossy cinematic widescreen.
2. **Lock in Net 30/60 cashflow terms** to maintain healthy inventory cycles while media scales.
3. **Ensure strict copyright audio clearance** prior to scaling paid spend.
      `
    },
    {
      id: "art_2",
      slug: "beauty-omnibus-growth-2026",
      title: "The Beauty Omnibus: Scaling Makeup, Skincare, and Haircare ROI through Fragmented UGC",
      niche: "Beauty",
      keywords: ["Makeup conversion", "Skincare whitelisting", "Haircare UGC results"],
      readTime: "5 min read",
      publishedDate: "August 12, 2026",
      summary: "A comprehensive framework for scaling beauty brands across makeup, hair, and skincare by leveraging high-resolution visual proof and creator authority.",
      markdownContent: `
# The Beauty Omnibus: Scaling Makeup, Skincare, and Haircare ROI through Fragmented UGC

*Published by Bloom Studio Research Group &bull; August 2026*

---

### Executive Summary
The beauty vertical is no longer a monolith. To achieve sustainable growth in 2026, brands must deploy specific creative strategies for **Makeup** (visual payoff), **Skincare** (scientific proof), and **Haircare** (long-term transformation).

---

### 1. Makeup: The "Visual Payoff" Hook
Makeup UGC converts best when the "transformation" is established in the first 1.5 seconds.
- **Side-by-Side Comparison**: Split-screen views showing immediate coverage or pigment payoff.
- **Lighting Integrity**: Natural daylight shots outperform studio ring lights for establishing shade-match trust.

---

### 2. Skincare: The Texture & Barrier Paradigm
Skincare buyers demand macro-level evidence:
- **Macro-Skincare**: Close-up shots of formula absorption and skin barrier glow.
- **Derm-Backed Whitelisting**: Leveraging creators with technical skin knowledge to reduce customer skepticism.

---

### 3. Haircare: The Transformation Journey
Haircare requires proof of health and volume:
- **Scalp & Root Analysis**: Visual evidence of hair density and root strength.
- **Application ASMR**: Focusing on the "ritual" of haircare to increase perceived value.

---

### 4. Regulatory Fortification
With heightened FTC scrutiny in cosmetics, creator contracts must enforce:
- Prominent audio and on-screen #ad disclosure.
- Verified absence of non-cleared commercial music.
- Pre-cleared 30-day Spark Ads and Meta Partnership authorization.
      `
    },
    {
      id: "art_3",
      slug: "lifestyle-creator-monetization",
      title: "Luxury Lifestyle Monetization: Bridging the Gap Between Aesthetic and Conversion",
      niche: "Lifestyle",
      keywords: ["Luxury lifestyle ROI", "High-ticket UGC", "Aesthetic branding"],
      readTime: "6 min read",
      publishedDate: "August 28, 2026",
      summary: "Analysis of how luxury lifestyle creators can maintain premium aesthetic standards while driving measurable high-ticket sales.",
      markdownContent: `
# Luxury Lifestyle Monetization: Bridging the Gap Between Aesthetic and Conversion

*Published by Bloom Studio Research Group &bull; August 2026*

---

### Executive Summary
In the luxury lifestyle space, the primary friction point is maintaining "brand prestige" while implementing performance-driven direct response tactics. Our research indicates that high-ticket conversions rely on "aspirational utility"—demonstrating luxury as a functional upgrade to daily life.

---

### 1. The Aspirational Utility Loop
Success in lifestyle UGC requires a transition from passive aesthetic shots to active utility:
- **Spatial Storytelling**: Showing products integrated into high-end environments naturally.
- **The "First-Class" Experience**: Highlighting tactile quality (weight, texture, finish) through macro-cinematography.

---

### 2. Scaling High-Ticket ROAS
Whitelisting premium lifestyle accounts has shown a **3.1x increase in Average Order Value (AOV)** compared to standard brand ads. The perceived social status of the creator serves as the primary trust mechanism for luxury purchases.
      `
    },
    {
      id: "art_4",
      slug: "hair-growth-retention-study",
      title: "Hair Growth & Scalp Health: The 6-Month Visual Retention Study",
      niche: "Beauty",
      keywords: ["Haircare growth data", "Scalp health ROI", "Retention study"],
      readTime: "7 min read",
      publishedDate: "September 02, 2026",
      summary: "A longitudinal study of visual transformation in the haircare vertical, identifying the critical milestones that drive long-term customer loyalty.",
      markdownContent: `
# Hair Growth & Scalp Health: The 6-Month Visual Retention Study

*Published by Bloom Studio Research Group &bull; September 2026*

---

### Executive Summary
Haircare brands suffer from high churn due to "unrealistic expectation lag." This research outlines how "Progressive UGC" (capturing a single creator over 6 months) reduces churn by 44% by setting accurate visual milestones for the consumer.

---

### 1. Milestone Marketing
Documenting the hair journey at day 1, 30, 90, and 180 creates a "Proof Chain" that static ads cannot replicate.
- **Root Density Analysis**: Using macro lenses to show follicle health improvement.
- **Luster & Sheen Benchmark**: Measuring light reflection before and after consistent ritual use.

---

### 2. Community Trust via Continuity
Creators who document a multi-month journey see a **5x increase in "Saved" posts**, as audiences treat the content as an educational resource rather than an advertisement.
      `
    },
    {
      id: "art_5",
      slug: "lifestyle-travel-roi",
      title: "High-Ticket Hospitality: Measuring Creator-Driven Bookings in Luxury Travel",
      niche: "Lifestyle",
      keywords: ["Luxury travel ROI", "Hospitality conversion", "Travel UGC"],
      readTime: "5 min read",
      publishedDate: "September 05, 2026",
      summary: "Quantitative analysis of how luxury hospitality brands can attribute direct booking revenue to high-end lifestyle creator stays.",
      markdownContent: `
# High-Ticket Hospitality: Measuring Creator-Driven Bookings in Luxury Travel

*Published by Bloom Studio Research Group &bull; September 2026*

---

### Executive Summary
Luxury hospitality often struggles with "brand awareness vs. direct booking" attribution. This study demonstrates that "Seamless Itinerary UGC" (showing the exact flow of a luxury stay) increases booking inquiry volume by 215% compared to generic scenic shots.

---

### 1. The "Flow" Strategy
Audiences want to see the friction-less transition from check-in to amenities:
- **Spatial Navigation**: A "walking tour" perspective of the suite and grounds.
- **Amenity Interaction**: Focus on service speed and the "human touch" of luxury staff.

---

### 2. Attribution Channels
By implementing dedicated creator booking links and "Concierge Mention" codes, brands achieved a **12:1 ROI** on high-end creator hosted stays.
      `
    }
  ]
}: AgencyPublicInsightsProps) {
  const [articles, setArticles] = useState<InsightArticle[]>(initialArticles);
  const [activeArticle, setActiveArticle] = useState<InsightArticle>(initialArticles[0]);
  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);

  // Generator form state
  const [formTitle, setFormTitle] = useState('');
  const [formSummary, setFormSummary] = useState('');
  const [formNiche, setFormNiche] = useState<'Pets' | 'Beauty' | 'Lifestyle'>('Beauty');
  const [formCampaignMetric, setFormCampaignMetric] = useState('');
  const [formKeywords, setFormKeywords] = useState('');
  const [formAnalysis, setFormAnalysis] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const canGenerate = ['director', 'agency'].includes((currentRole || '').toLowerCase());

  // Sync with Firestore
  useEffect(() => {
    if (!db) {
      setIsLoading(false);
      return;
    }

    try {
      const q = query(
        collection(db, 'agency-research-papers'), 
        orderBy('createdAt', 'desc')
      );

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const fetchedArticles: InsightArticle[] = [];
        snapshot.forEach((docItem) => {
          fetchedArticles.push(docItem.data() as InsightArticle);
        });

        if (fetchedArticles.length > 0) {
          setArticles(prev => {
            // Merge fetched with initial / local
            const combined = [...fetchedArticles];
            return combined;
          });
          if (!activeArticle || !fetchedArticles.find(a => a.id === activeArticle.id)) {
            setActiveArticle(fetchedArticles[0]);
          }
        }
        setIsLoading(false);
      }, (error) => {
        // Gracefully handle permission or network errors by falling back to initial articles
        console.info("Using local insight articles (Firestore sync optional):", error?.message || error);
        setIsLoading(false);
      });

      return () => unsubscribe();
    } catch (err) {
      setIsLoading(false);
    }
  }, []);

  const handleGeneratePost = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);

    try {
      const nicheEmoji = formNiche === 'Pets' ? '🐾' : formNiche === 'Beauty' ? '✨' : '🥂';
      const paperId = `art_${Date.now()}`;
      const newArticle: InsightArticle = {
        id: paperId,
        slug: `strategic-analysis-${formNiche.toLowerCase()}-${Date.now()}`,
        title: formTitle || `Strategic Insights: Scaling ${formNiche} Brands`,
        niche: formNiche,
        keywords: formKeywords.split(',').map(k => k.trim()).filter(k => k),
        readTime: `${Math.max(2, Math.floor((formAnalysis.length + 100) / 400))} min read`,
        publishedDate: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        summary: formSummary || `Strategic playbook examining recent benchmark data to accelerate organic customer acquisition in ${formNiche}.`,
        markdownContent: `
# ${formTitle || `Strategic Insights: Scaling ${formNiche} Brands`}

*Published by Bloom Studio Research Group &bull; ${new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}*

---

### Executive Summary
${formSummary || `Recent campaign analysis in the ${formNiche} vertical demonstrates a significant shift in consumer trust patterns and acquisition efficiency.`}

---

### Data-Driven Performance Benchmark
Recent campaign performance across ${formNiche} demonstrated standout efficiency:
- **Campaign Metric Highlights**: ${formCampaignMetric || 'N/A'}
- **Primary Strategic Focus**: ${formKeywords || 'N/A'}

---

### In-Depth Analysis & Strategy ${nicheEmoji}
${formAnalysis || 'No detailed analysis provided for this report.'}

---

### Key Operational Takeaways
1. **Targeted Micro-Storytelling**: Leverage niche creators with dedicated followings rather than generic macro influencers.
2. **Visual Proof Protocol**: Ensure high-resolution macro cinematography to establish product efficacy.
3. **Regulatory Fortification**: Enforce copyright-safe audio and full FTC disclosure protocols across all deliverables.
        `
      };

      // Update local state immediately for instant feedback
      setArticles(prev => [newArticle, ...prev]);
      setActiveArticle(newArticle);

      // Try saving to Firestore if available
      try {
        if (db) {
          await setDoc(doc(db, 'agency-research-papers', paperId), {
            ...newArticle,
            createdAt: serverTimestamp()
          });
        }
      } catch (firestoreErr) {
        console.info("Saved locally (Firestore sync restricted):", firestoreErr);
      }

      setIsGeneratorOpen(false);
      // Reset form
      setFormTitle('');
      setFormSummary('');
      setFormCampaignMetric('');
      setFormKeywords('');
      setFormAnalysis('');
    } catch (err) {
      console.error("Failed to publish research paper:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 pb-20">
      {/* Header Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-lg bg-slate-900 text-[#B89359] font-serif font-bold flex items-center justify-center">
              B
            </span>
            <div>
              <h1 className="font-serif font-bold text-base text-slate-900">BLOOM STUDIO INSIGHTS</h1>
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block">
                Public Agency White Papers &amp; UGC Benchmarks
              </span>
            </div>
          </div>

          {canGenerate && (
            <button
              type="button"
              onClick={() => setIsGeneratorOpen(!isGeneratorOpen)}
              className="inline-flex items-center gap-2 bg-[#B89359] hover:bg-[#a6824a] text-white font-bold text-xs px-4 py-2 rounded-xl transition-all cursor-pointer shadow-md"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isGeneratorOpen ? 'Cancel Generation' : 'Write New White Paper'}</span>
            </button>
          )}
        </div>
      </header>

      {/* Generator Drawer */}
      {isGeneratorOpen && (
        <div className="max-w-4xl mx-auto mt-6 px-4 animate-in slide-in-from-top duration-500">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-serif font-bold text-xl text-slate-900">
                  Director's White Paper Studio
                </h3>
                <p className="text-xs text-slate-500">
                  Compose high-authority research papers to showcase agency expertise.
                </p>
              </div>
            </div>

            <form onSubmit={handleGeneratePost} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 font-bold uppercase tracking-wider text-[10px]">Research Paper Title</label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={e => setFormTitle(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none focus:border-[#B89359] transition-colors"
                    placeholder="e.g., The 2026 Haircare ROI Study: Visual Proof Chains"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-700 font-bold uppercase tracking-wider text-[10px]">One-Sentence Executive Summary</label>
                  <input
                    type="text"
                    required
                    value={formSummary}
                    onChange={e => setFormSummary(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none focus:border-[#B89359] transition-colors"
                    placeholder="Short summary for the index view..."
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-700 font-bold uppercase tracking-wider text-[10px]">Vertical / Niche</label>
                  <select
                    value={formNiche}
                    onChange={e => setFormNiche(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none focus:border-[#B89359] transition-colors"
                  >
                    <option value="Beauty">Beauty (Makeup, Skincare, Hair)</option>
                    <option value="Pets">Pets / Canine Wellness</option>
                    <option value="Lifestyle">Luxury Lifestyle</option>
                  </select>
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="text-slate-700 font-bold uppercase tracking-wider text-[10px]">SEO Keywords & Key Results</label>
                  <input
                    type="text"
                    required
                    value={formKeywords}
                    onChange={e => setFormKeywords(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none focus:border-[#B89359] transition-colors"
                    placeholder="e.g., 40% Churn Reduction, Hair Retention, Visual Proof"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 font-bold uppercase tracking-wider text-[10px]">Campaign Benchmark (Data Points)</label>
                <input
                  type="text"
                  required
                  value={formCampaignMetric}
                  onChange={e => setFormCampaignMetric(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none focus:border-[#B89359] transition-colors"
                  placeholder="e.g., 1.2M Views, 18.4% ER, 3.2x ROAS across 15 creators"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-700 font-bold uppercase tracking-wider text-[10px]">In-Depth Analysis & Strategic Insights</label>
                <textarea
                  required
                  value={formAnalysis}
                  onChange={e => setFormAnalysis(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 outline-none focus:border-[#B89359] transition-colors min-h-[150px] resize-none"
                  placeholder="Describe your research findings, strategies used, and why this vertical is scaling..."
                />
              </div>

              <button
                type="submit"
                disabled={isGenerating}
                className="w-full py-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm transition-all cursor-pointer shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Compiling Official White Paper...</span>
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4" />
                    <span>Compile & Publish Research Paper</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Main Content Layout */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Sidebar: Article Index */}
        <aside className="lg:col-span-4 space-y-3">
          <h3 className="text-xs font-mono uppercase tracking-wider text-slate-500 font-bold px-2">
            Published Intelligence Reports
          </h3>

          <div className="space-y-2.5">
            {articles.map((art) => (
              <button
                key={art.id}
                type="button"
                onClick={() => setActiveArticle(art)}
                className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer block ${
                  activeArticle.id === art.id
                    ? 'bg-white border-[#B89359] shadow-md ring-1 ring-[#B89359]/30'
                    : 'bg-white/70 hover:bg-white border-slate-200'
                }`}
                aria-label={`Read article: ${art.title}`}
                aria-current={activeArticle.id === art.id ? 'true' : 'false'}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#B89359] bg-amber-50 px-2 py-0.5 rounded">
                    {art.niche}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">{art.readTime}</span>
                </div>
                <h4 className="font-serif font-bold text-sm text-slate-900 line-clamp-2">
                  {art.title}
                </h4>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                  {art.summary}
                </p>
              </button>
            ))}
          </div>
        </aside>

        {/* Right Reader Area: Pure White Paper Layout */}
        <article className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl p-8 sm:p-12 shadow-xl space-y-6">
          <div className="border-b border-slate-100 pb-6 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono uppercase font-bold tracking-widest text-[#B89359] bg-amber-50/80 px-3 py-0.5 rounded-full border border-[#B89359]/20">
                {activeArticle.niche} Vertical Research
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {activeArticle.publishedDate}
              </span>
            </div>

            <h1 className="font-serif font-bold text-3xl sm:text-4xl text-slate-900 leading-tight">
              {activeArticle.title}
            </h1>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {activeArticle.keywords.map((kw, i) => (
                <span key={i} className="text-[11px] font-mono text-slate-500 bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
                  #{kw}
                </span>
              ))}
            </div>
          </div>

          {/* White Paper Markdown Render Body */}
          <div className="prose prose-slate max-w-none text-slate-700 leading-relaxed text-sm space-y-4">
            <div className="whitespace-pre-line font-sans">
              {activeArticle.markdownContent}
            </div>
          </div>

          {/* Bottom Divider & Signature */}
          <div className="border-t border-slate-200 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
            <span>Authored by Bloom Studio Research Lab</span>
            <span>Zero-tracking, public reader mode</span>
          </div>
        </article>
      </main>
    </div>
  );
}
