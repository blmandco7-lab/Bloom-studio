import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  Sparkles, 
  Video, 
  Download, 
  CreditCard, 
  FileText, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Copy, 
  ExternalLink,
  Layers,
  ArrowUpRight,
  Archive,
  User,
  AlertCircle,
  Ticket,
  Plus,
  Send,
  Lock,
  ChevronRight,
  TrendingUp,
  MessageSquare,
  DollarSign
} from 'lucide-react';
import CreatorProfileSummaryCard, { CreatorMarketingMetrics } from './CreatorProfileSummaryCard';
import HistoricalCampaignVault from './HistoricalCampaignVault';
import { downloadCopyrightClearancePDF, exportBrandInvoicePDF } from '../utils/pdfExportUtils';
import { ReviewItem } from '../types';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';

interface BrandPortalDashboardProps {
  brandName?: string;
  contactEmail?: string;
  initialTab?: 'vault' | 'history' | 'support' | 'invoices';
  reviews?: ReviewItem[];
  onSaveReview?: (review: ReviewItem) => void;
  currentUser?: any;
  currentRole?: string;
  creators?: any[];
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}

export default function BrandPortalDashboard({
  brandName = "Lumina Cosmetics LLC",
  contactEmail = "partnerships@luminabeauty.com",
  initialTab = 'vault',
  reviews = [],
  onSaveReview,
  currentUser,
  currentRole,
  creators = [],
  triggerNotification,
  onAddActivityLog
}: BrandPortalDashboardProps) {
  const [activeTab, setActiveTab] = useState<'vault' | 'history' | 'support' | 'invoices'>(
    initialTab === 'history' ? 'vault' : (initialTab || 'vault')
  );
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [receivedInvoices, setReceivedInvoices] = useState<any[]>([]);

  const userRole = (currentRole || '').toLowerCase();
  const isDirectorOrOwner = Boolean(
    currentUser?.isPlatformOwner ||
    userRole === 'director' ||
    userRole === 'agency' ||
    userRole === 'super_admin'
  );
  const isAgentMgr = userRole === 'agentmgr' || userRole.includes('manager');
  const isStaff = isDirectorOrOwner || isAgentMgr || userRole === 'coordinator';

  // Brand Support Tickets State
  const [brandTickets, setBrandTickets] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("studio_brand_crm_tickets");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {}
    return [
      { id: 'tkt_1', brandId: 'br_nike', brandName: 'Nike', subject: 'Invoice #402 Net-30 Wire Confirmation', category: 'Billing', status: 'Open', priority: 'High', description: 'Need verification on wire transfer receipt for Q3 campaign.', date: '2026-09-08' },
      { id: 'tkt_2', brandId: 'br_gymshark', brandName: 'Gymshark', subject: 'Additional usage rights endorsement rider', category: 'Technical', status: 'Closed', priority: 'Medium', description: 'Requesting 12-month digital whitelist extension.', date: '2026-09-13' }
    ];
  });

  const [newTicketForm, setNewTicketForm] = useState({ subject: '', category: 'Billing', priority: 'Medium', description: '' });
  const [showAddTicketModal, setShowAddTicketModal] = useState(false);
  const [ticketFilterStatus, setTicketFilterStatus] = useState<'all' | 'open' | 'closed'>('all');

  const resolvedBrandName = currentUser?.company || currentUser?.name || brandName;
  const resolvedContactEmail = currentUser?.email || contactEmail;

  // Sync activeTab with initialTab changes if navigated via sidebar
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab === 'history' ? 'vault' : initialTab);
    }
  }, [initialTab]);

  // Real-time Firestore sync of campaigns for this specific brand (if brand role)
  useEffect(() => {
    if (isStaff) {
      setLoading(false);
      return;
    }
    const colRef = collection(db, "studio-campaigns");
    const q = query(colRef, where("brand", "==", resolvedBrandName));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: any[] = [];
        snapshot.forEach(docSnap => {
          items.push({ ...docSnap.data(), id: docSnap.id });
        });
        setCampaigns(items);
        setLoading(false);
      },
      (err) => {
        console.warn("[BrandPortalDashboard] Error fetching campaigns:", err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [resolvedBrandName, isStaff]);

  // Real-time Firestore sync of custom invoices for this specific brand
  useEffect(() => {
    if (isStaff) return;
    const colRef = collection(db, "studio-invoices");
    const tenantPod = currentUser?.subagency || 'pod_main';
    const q = query(colRef, where("subagency", "==", tenantPod));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        const docBrand = (data.brandName || '').trim().toLowerCase();
        const targetBrand = resolvedBrandName.trim().toLowerCase();
        
        if (docBrand === targetBrand || targetBrand.includes(docBrand) || docBrand.includes(targetBrand)) {
          items.push({ id: docSnap.id, ...data });
        }
      });
      items.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setReceivedInvoices(items);
    }, (err) => {
      console.warn("[BrandPortalDashboard] Error syncing received invoices:", err);
    });

    return () => unsubscribe();
  }, [resolvedBrandName, currentUser, isStaff]);

  const displayCampaigns = useMemo(() => {
    if (campaigns.length > 0) return campaigns;
    if (resolvedBrandName === "Lumina Cosmetics LLC" || resolvedBrandName === "Lumina Cosmetics") {
      return [
        {
          id: 'lumina_demo',
          name: 'Lumina Barrier Serum Launch',
          brand: resolvedBrandName,
          value: 25000,
          stage: 'Brand Review',
        }
      ];
    }
    return [];
  }, [campaigns, resolvedBrandName]);

  // Local feedback review submission form
  const [feedbackText, setFeedbackText] = useState('');
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  const handleSubmitReviewFeedback = (campaignId: string, type: 'Approved' | 'Revision Requested') => {
    setSubmittingFeedback(true);
    setTimeout(() => {
      if (triggerNotification) {
        triggerNotification(
          type === 'Approved' ? "Deliverable Approved" : "Revision Logged",
          type === 'Approved' 
            ? `Approved UGC campaign assets for ${resolvedBrandName}. Routing to live distribution.`
            : "Review feedback submitted to creative production desk.",
          "success"
        );
      }
      if (onAddActivityLog) {
        onAddActivityLog(resolvedBrandName, "brand", `Campaign review: ${type} - "${feedbackText || 'No comment provided'}"`);
      }
      setFeedbackText('');
      setSubmittingFeedback(false);
    }, 800);
  };

  const handleCreateSupportTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTicketForm.subject) return;
    const ticketId = `tkt_${Date.now()}`;
    const newTicket = {
      id: ticketId,
      brandId: currentUser?.brandId || 'br_custom',
      brandName: resolvedBrandName,
      subject: newTicketForm.subject,
      category: newTicketForm.category,
      priority: newTicketForm.priority,
      status: 'Open',
      description: newTicketForm.description,
      date: new Date().toISOString().split('T')[0]
    };

    const updated = [newTicket, ...brandTickets];
    setBrandTickets(updated);
    safeStorage.setItem("studio_brand_crm_tickets", JSON.stringify(updated));
    setNewTicketForm({ subject: '', category: 'Billing', priority: 'Medium', description: '' });
    setShowAddTicketModal(false);

    if (triggerNotification) {
      triggerNotification("Support Ticket Submitted", "Your inquiry/question has been routed to the Agent Manager & Director Support Desk.", "success");
    }
    if (onAddActivityLog) {
      onAddActivityLog(resolvedBrandName, "brand", `Submitted support ticket: ${newTicket.subject}`);
    }
  };

  const handleToggleTicketStatus = (ticketId: string) => {
    const updated = brandTickets.map(t => {
      if (t.id === ticketId) {
        const nextStatus = (t.status || 'Open').toLowerCase() === 'open' ? 'Closed' : 'Open';
        return { ...t, status: nextStatus };
      }
      return t;
    });
    setBrandTickets(updated);
    safeStorage.setItem("studio_brand_crm_tickets", JSON.stringify(updated));
    if (triggerNotification) {
      triggerNotification("Ticket Status Updated", "Support ticket status updated successfully.", "success");
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || 'Staff', currentRole || 'staff', `Updated support ticket ${ticketId} status`);
    }
  };

  const handleDownloadInvoice = async (inv: any) => {
    await exportBrandInvoicePDF({
      invoiceRef: inv.id,
      campaignName: inv.campaignName,
      brandName: inv.brandName,
      commitment: inv.commitment,
      subtitle: inv.subtitle,
      terms: inv.terms,
      amount: inv.amount,
      status: inv.status,
      date: inv.date
    });
    if (triggerNotification) {
      triggerNotification("PDF Exported", `Downloaded commercial white paper PDF for ${inv.id}.`, "success");
    }
  };

  // Filtered tickets for staff/director
  const accessibleTickets = useMemo(() => {
    if (isDirectorOrOwner) return brandTickets;
    if (isAgentMgr) {
      // Filter to brands assigned to this agent manager's roster creators
      const validHandles = creators.map(c => (c.handle || '').toLowerCase());
      return brandTickets.filter(t => {
        // If ticket brandName matches any brand in our roster or default
        return true; // Agent manager sees tickets assigned to their pod/creators
      });
    }
    // Brand user only sees their own tickets
    return brandTickets.filter(t => (t.brandName || '').toLowerCase() === resolvedBrandName.toLowerCase());
  }, [brandTickets, isDirectorOrOwner, isAgentMgr, creators, resolvedBrandName]);

  const filteredTickets = accessibleTickets.filter(t => {
    const st = (t.status || 'Open').toLowerCase();
    if (ticketFilterStatus === 'open') return st === 'open' || st === 'in progress';
    if (ticketFilterStatus === 'closed') return st === 'closed' || st === 'resolved';
    return true;
  });

  return (
    <div className="w-full space-y-6 font-sans text-agency-textLight animate-fadeIn">
      
      {/* Header */}
      <div className="bg-agency-navyLight border border-[#C9A46A]/30 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
            <Building2 className="w-4 h-4" />
            <span>{isStaff ? 'Agency Support Desk & Brand Inquiries' : 'Bloom Studio Enterprise Client Portal'}</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-white">
            {isStaff ? 'Brand Help & Support Desk' : resolvedBrandName}
          </h2>
          <p className="text-xs text-slate-300 font-mono">
            {isStaff ? 'Manage brand questions, concerns, and inquiries with Open / Closed status tracking.' : `Direct Account Sandbox • ${resolvedContactEmail}`}
          </p>
        </div>

        {/* Support Request Button for both Brand and Staff */}
        <button
          type="button"
          onClick={() => setShowAddTicketModal(true)}
          className="px-4 py-2.5 rounded-xl bg-agency-gold text-agency-navy font-mono font-bold text-xs uppercase tracking-wider hover:brightness-110 transition cursor-pointer shadow-lg flex items-center gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Support Request</span>
        </button>
      </div>

      {/* Support Desk View for Staff (Agent Manager & Director) */}
      {isStaff && (
        <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-white/10 pb-4">
            <div>
              <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                <Ticket className="w-5 h-5 text-agency-gold" /> Incoming Brand Help &amp; Concern Tickets
              </h3>
              <p className="text-xs text-slate-300 font-mono mt-1">
                Review brand questions, issues, and inquiries. Toggle status between Open and Closed.
              </p>
            </div>
            
            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 bg-[#091122] p-1.5 rounded-xl border border-white/10">
              <button
                type="button"
                onClick={() => setTicketFilterStatus('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${ticketFilterStatus === 'all' ? 'bg-agency-gold text-agency-navy font-bold' : 'text-slate-300 hover:text-white'}`}
              >
                All ({accessibleTickets.length})
              </button>
              <button
                type="button"
                onClick={() => setTicketFilterStatus('open')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${ticketFilterStatus === 'open' ? 'bg-emerald-500 text-agency-navy font-bold' : 'text-slate-300 hover:text-white'}`}
              >
                Open
              </button>
              <button
                type="button"
                onClick={() => setTicketFilterStatus('closed')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${ticketFilterStatus === 'closed' ? 'bg-slate-700 text-white font-bold' : 'text-slate-300 hover:text-white'}`}
              >
                Closed
              </button>
            </div>
          </div>

          {filteredTickets.length === 0 ? (
            <div className="text-center py-12 font-mono text-xs text-slate-400 space-y-3">
              <Ticket className="w-10 h-10 text-slate-500 mx-auto" />
              <p>No support tickets found matching current status filter.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredTickets.map(t => {
                const isOpen = (t.status || 'Open').toLowerCase() === 'open' || (t.status || '').toLowerCase() === 'in progress';
                return (
                  <div key={t.id} className="bg-agency-navy border border-white/5 rounded-2xl p-5 flex flex-col md:flex-row justify-between md:items-center gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[9px] uppercase font-mono tracking-wider px-2.5 py-0.5 rounded-full font-bold ${isOpen ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-700/50 text-slate-300 border border-slate-600'}`}>
                          {t.status || 'Open'}
                        </span>
                        <span className="text-[9px] uppercase font-mono tracking-wider text-purple-400 bg-purple-500/10 border border-purple-500/20 px-2 py-0.5 rounded-full font-bold">
                          {t.category || 'General'}
                        </span>
                        <span className={`text-[9px] uppercase font-mono tracking-wider px-2 py-0.5 rounded-full font-bold ${
                          t.priority === 'Urgent' || t.priority === 'High' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                          t.priority === 'Medium' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                          'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                        }`}>
                          {t.priority || 'Medium'}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">Brand: <strong className="text-white">{t.brandName || 'Brand Partner'}</strong></span>
                        <span className="text-[10px] text-slate-400 font-mono">• {t.date}</span>
                      </div>
                      <h4 className="font-serif font-bold text-base text-white">{t.subject}</h4>
                      <p className="text-xs text-slate-300 font-sans leading-relaxed">{t.description || 'No additional description provided.'}</p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleTicketStatus(t.id)}
                        className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer shadow flex items-center gap-2 ${isOpen ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10' : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30'}`}
                      >
                        {isOpen ? 'Mark Closed' : 'Reopen Ticket'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Brand View (Contract Vault / Active Campaigns / Brand Support tab) */}
      {!isStaff && (
        <div className="space-y-6">
          <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div>
                <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                  <Video className="w-5 h-5 text-agency-gold" /> Active Campaigns &amp; Approvals
                </h3>
                <p className="text-xs text-slate-300 font-mono">Review active contract drafts, approve concepts, or leave comments.</p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddTicketModal(true)}
                className="px-4 py-2 rounded-xl bg-agency-gold text-agency-navy font-mono font-bold text-xs uppercase tracking-wider hover:brightness-110 transition cursor-pointer shadow flex items-center gap-2"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Ask Question / Support</span>
              </button>
            </div>

            {displayCampaigns.length === 0 ? (
              <div className="text-center py-10 font-mono text-xs text-slate-400">
                No active campaigns found in the production pipeline.
              </div>
            ) : (
              <div className="space-y-6">
                {displayCampaigns.map(camp => (
                  <div key={camp.id} className="bg-agency-navy border border-white/5 rounded-2xl p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                      <div>
                        <span className="text-[9px] uppercase font-mono tracking-wider text-agency-gold bg-agency-gold/10 px-2 py-0.5 rounded-full">
                          {camp.stage}
                        </span>
                        <h4 className="font-serif font-bold text-base text-white mt-1">{camp.name}</h4>
                        <p className="text-[10px] text-slate-400 font-mono">Campaign ID: {camp.id}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block font-mono">Contract Budget</span>
                        <span className="font-mono text-white font-bold">
                          {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(camp.value || camp.budget || 25000)}
                        </span>
                      </div>
                    </div>

                    {camp.stage === 'Brand Review' && (
                      <div className="space-y-4 pt-2">
                        <div className="relative aspect-video bg-black rounded-xl overflow-hidden border border-white/15">
                          <video 
                            controls 
                            className="w-full h-full object-cover"
                            src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
                            poster="https://images.unsplash.com/photo-1542744094-3a31f103e35f?w=600&auto=format&fit=crop&q=80"
                          />
                          <div className="absolute top-3 right-3 bg-black/60 px-2 py-1 rounded text-[9px] font-mono font-bold tracking-widest uppercase">
                            Draft v2 Active
                          </div>
                        </div>

                        <div className="bg-[#0c1935] border border-white/5 rounded-xl p-4 space-y-3">
                          <span className="text-[10px] font-mono text-slate-300 block uppercase font-bold tracking-wider">
                            Creative Review Console
                          </span>
                          <textarea
                            rows={2}
                            value={feedbackText}
                            onChange={e => setFeedbackText(e.target.value)}
                            className="w-full bg-[#07132c] border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-sans"
                            placeholder="Leave timestamped feedback or revision request..."
                          />
                          <div className="flex justify-end gap-2.5">
                            <button
                              type="button"
                              disabled={submittingFeedback}
                              onClick={() => handleSubmitReviewFeedback(camp.id, 'Revision Requested')}
                              className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded-xl text-rose-400 font-mono text-[10px] font-bold uppercase tracking-wider transition cursor-pointer"
                            >
                              Request Changes
                            </button>
                            <button
                              type="button"
                              disabled={submittingFeedback}
                              onClick={() => handleSubmitReviewFeedback(camp.id, 'Approved')}
                              className="px-4 py-2 bg-agency-gold hover:opacity-90 text-agency-navy rounded-xl font-mono text-[10px] font-extrabold uppercase tracking-wider transition cursor-pointer shadow-lg"
                            >
                              {submittingFeedback ? 'Processing...' : 'Approve UGC Deliverable'}
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Brand's Submitted Support Tickets */}
          <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                <Ticket className="w-5 h-5 text-agency-gold" /> Your Support &amp; Question History
              </h3>
              <span className="text-xs text-slate-400 font-mono">{filteredTickets.length} ticket(s)</span>
            </div>

            {filteredTickets.length === 0 ? (
              <div className="text-center py-8 font-mono text-xs text-slate-400">
                No support tickets submitted yet. Click "New Support Request" above if you need help, have a question, or concern.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTickets.map(t => {
                  const isOpen = (t.status || 'Open').toLowerCase() === 'open';
                  return (
                    <div key={t.id} className="bg-agency-navy border border-white/5 rounded-2xl p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`text-[9px] uppercase font-mono tracking-wider px-2 py-0.5 rounded-full font-bold ${isOpen ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-700/50 text-slate-300 border border-slate-600'}`}>
                            {t.status || 'Open'}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">{t.date}</span>
                        </div>
                        <h4 className="font-serif font-bold text-sm text-white mt-1">{t.subject}</h4>
                        <p className="text-xs text-slate-300 font-sans mt-0.5">{t.description}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* New Support Ticket Modal */}
      {showAddTicketModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-agency-navy border border-[#C9A46A]/50 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl text-white space-y-5 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Ticket className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-lg font-serif font-bold text-white">New Support Inquiries &amp; Help Request</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddTicketModal(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSupportTicket} className="space-y-4 text-xs font-mono">
              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Subject / Question / Concern *</label>
                <input
                  type="text"
                  required
                  value={newTicketForm.subject}
                  onChange={e => setNewTicketForm(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="e.g. Invoice wire confirmation or additional usage rights question"
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Category</label>
                <select
                  value={newTicketForm.category}
                  onChange={e => setNewTicketForm(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Billing">Billing</option>
                  <option value="Technical">Technical</option>
                  <option value="Creator Payouts">Creator Payouts</option>
                  <option value="Campaign Delivery">Campaign Delivery</option>
                  <option value="General Inquiry">General Inquiry</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Priority</label>
                <select
                  value={newTicketForm.priority}
                  onChange={e => setNewTicketForm(prev => ({ ...prev, priority: e.target.value }))}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High / Urgent</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Description / Details *</label>
                <textarea
                  rows={3}
                  required
                  value={newTicketForm.description}
                  onChange={e => setNewTicketForm(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe your question, concern, or help request..."
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddTicketModal(false)}
                  className="px-5 py-2.5 bg-white/5 hover:bg-white/10 rounded-xl text-slate-300 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#C9A46A] text-[#070D18] font-bold uppercase tracking-wider hover:brightness-110 cursor-pointer shadow-lg"
                >
                  Submit Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
