import React from 'react';
import { Eye, EyeOff, ShieldAlert, Sparkles, Crown } from 'lucide-react';

interface OwnerOverrideToggleProps {
  userRole?: 'Owner' | 'Manager' | 'director' | 'agency' | string;
  isManagerPreview: boolean;
  onToggleManagerPreview: (preview: boolean) => void;
  className?: string;
}

/**
 * Premium Admin-Only Toggle:
 * Renders for Executive/Owner/Director profiles.
 * Allows the agency principal to switch between full financial transparency
 * and masking staff/manager view in real-time.
 */
export default function OwnerOverrideToggle({
  userRole,
  isManagerPreview,
  onToggleManagerPreview,
  className = ""
}: OwnerOverrideToggleProps) {
  const normRole = (userRole || '').toLowerCase();
  const isOwner = ['owner', 'director', 'agency', 'admin', 'principal'].includes(normRole);

  // CRITICAL RULE: Never render for non-Owner profiles
  if (!isOwner) {
    return null;
  }

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Visual State Indicator Badge */}
      <div className="hidden sm:flex items-center gap-1.5 text-[11px] font-mono">
        {isManagerPreview ? (
          <span className="text-slate-400 bg-slate-800/80 border border-slate-700 px-2.5 py-1 rounded-lg flex items-center gap-1">
            <EyeOff className="w-3.5 h-3.5 text-slate-400" />
            <span>Staff Masking Active</span>
          </span>
        ) : (
          <span className="text-[#C9A46A] bg-[#111E33] border border-[#C9A46A]/30 px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-sm">
            <Crown className="w-3.5 h-3.5 text-[#C9A46A]" />
            <span>Director Master Financials Unlocked</span>
          </span>
        )}
      </div>

      {/* Interactive Toggle Switch */}
      <button
        type="button"
        onClick={() => onToggleManagerPreview(!isManagerPreview)}
        className={`relative inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold font-sans transition-all duration-300 cursor-pointer shadow-lg select-none ${
          !isManagerPreview
            ? 'bg-[#111E33] text-[#C9A46A] border border-[#C9A46A]/60 shadow-[#C9A46A]/10'
            : 'bg-[#0E1B33] text-slate-300 border border-slate-600 hover:border-slate-400'
        }`}
        title={!isManagerPreview ? "Switch to Manager View Masking" : "Switch back to Director Master View"}
      >
        <span className="flex items-center gap-1.5">
          {!isManagerPreview ? (
            <>
              <Eye className="w-3.5 h-3.5 text-[#C9A46A] animate-pulse" />
              <span>Director Master View</span>
            </>
          ) : (
            <>
              <EyeOff className="w-3.5 h-3.5 text-slate-400" />
              <span>Preview Staff View</span>
            </>
          )}
        </span>

        {/* Custom Pill Slider */}
        <div
          className={`w-9 h-4.5 rounded-full p-0.5 transition-colors duration-200 ease-in-out flex items-center ${
            !isManagerPreview ? 'bg-[#C9A46A]/30 border border-[#C9A46A]/60' : 'bg-slate-700 border border-slate-600'
          }`}
        >
          <div
            className={`w-3.5 h-3.5 rounded-full shadow-md transform transition-transform duration-200 ease-in-out ${
              !isManagerPreview
                ? 'translate-x-4 bg-[#C9A46A] shadow-[#C9A46A]/50'
                : 'translate-x-0 bg-slate-400'
            }`}
          />
        </div>
      </button>
    </div>
  );
}
