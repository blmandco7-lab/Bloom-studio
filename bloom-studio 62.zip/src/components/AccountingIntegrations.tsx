import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { 
  Link2, CheckCircle2, RefreshCw, Download, Send, Plus, Trash2, 
  Shield, Users, DollarSign, Building2, Key, ExternalLink, HelpCircle,
  AlertCircle, Check, Sparkles, FileText, ArrowUpRight, Lock, Copy, TrendingUp, MonitorPlay
} from 'lucide-react';
import { Creator, Deal } from '../types';
import { formatCsvRow, sanitizeCsvCell } from '../utils/security';

interface AccountingIntegrationsProps {
  creators: Creator[];
  deals: Deal[];
  taxItems: any[];
  currentUser?: any;
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

interface InvitedCpa {
  id: string;
  name: string;
  email: string;
  firm: string;
  accessLevel: 'Full Auditor & 1099 Filing' | 'Read-Only Ledger' | 'Tax Season Reviewer';
  status: 'Active' | 'Pending Invite';
  invitedAt: string;
  lastAccess?: string;
}

interface WaveConfig {
  connected: boolean;
  apiToken: string;
  businessId: string;
  syncInvoices: boolean;
  syncPayouts: boolean;
  syncEscrow: boolean;
  lastSync?: string;
}

interface ZohoConfig {
  connected: boolean;
  clientId: string;
  clientSecret: string;
  orgId: string;
  dataCenter: 'us' | 'eu' | 'in' | 'au' | 'ca';
  syncVendors: boolean;
  syncBills: boolean;
  syncTaxes: boolean;
  lastSync?: string;
}

export default function AccountingIntegrations({
  creators,
  deals,
  taxItems,
  currentUser,
  onAddActivityLog,
  triggerNotification
}: AccountingIntegrationsProps) {
  // Wave state
  const [waveConfig, setWaveConfig] = useState<WaveConfig>({
    connected: false,
    apiToken: '',
    businessId: '',
    syncInvoices: true,
    syncPayouts: true,
    syncEscrow: true
  });

  // Zoho state
  const [zohoConfig, setZohoConfig] = useState<ZohoConfig>({
    connected: false,
    clientId: '',
    clientSecret: '',
    orgId: '',
    dataCenter: 'us',
    syncVendors: true,
    syncBills: true,
    syncTaxes: true
  });

  // Invited CPAs state
  const [invitedCpas, setInvitedCpas] = useState<InvitedCpa[]>(() => {
    const saved = localStorage.getItem('bloom_invited_cpas');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      {
        id: 'cpa_01',
        name: 'David Sterling, CPA',
        email: 'david@sterlingtaxadvisors.com',
        firm: 'Sterling Tax & Wealth Advisory LLC',
        accessLevel: 'Full Auditor & 1099 Filing',
        status: 'Active',
        invitedAt: '2026-01-10',
        lastAccess: '2026-02-12 09:44 AM'
      }
    ];
  });

  // Modal / form states
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [newCpaName, setNewCpaName] = useState('');
  const [newCpaEmail, setNewCpaEmail] = useState('');
  const [newCpaFirm, setNewCpaFirm] = useState('');
  const [newCpaAccess, setNewCpaAccess] = useState<'Full Auditor & 1099 Filing' | 'Read-Only Ledger' | 'Tax Season Reviewer'>('Full Auditor & 1099 Filing');
  const [isSyncingWave, setIsSyncingWave] = useState(false);
  const [isSyncingZoho, setIsSyncingZoho] = useState(false);
  const [apiErrorMessage, setApiErrorMessage] = useState<string | null>(null);

  // Persistence
  useEffect(() => {
    localStorage.setItem('bloom_invited_cpas', JSON.stringify(invitedCpas));
  }, [invitedCpas]);

  useEffect(() => {
    const subagency = currentUser?.subagency || "pod_main";
    const colRef = collection(db, "studio-accounting-connections");
    const q = query(colRef, where("subagency", "==", subagency));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      snapshot.forEach(doc => {
        const data = doc.data();
        if (data.platform === "wave") {
          setWaveConfig(prev => ({ 
            ...prev, 
            connected: data.connected,
            lastSync: data.lastVerifiedAt ? new Date(data.lastVerifiedAt).toLocaleString() : prev.lastSync
          }));
        } else if (data.platform === "zoho") {
          setZohoConfig(prev => ({ 
            ...prev, 
            connected: data.connected,
            lastSync: data.lastVerifiedAt ? new Date(data.lastVerifiedAt).toLocaleString() : prev.lastSync
          }));
        }
      });
    }, (err) => {
      console.warn("Error syncing accounting connections:", err);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Wave Handlers
  const handleSaveWave = (e: React.FormEvent) => {
    e.preventDefault();
    setWaveConfig(prev => ({ ...prev, connected: !!prev.apiToken.trim() }));
    setApiErrorMessage(null);
    triggerNotification('Wave Settings Saved', 'Wave Accounting API connection parameters updated.', 'success');
    onAddActivityLog('Director', 'director', 'Updated Wave Accounting integration configurations');
  };

  const handleTestWave = async () => {
    if (!waveConfig.apiToken) {
      triggerNotification('Missing API Token', 'Please enter your Wave API Full Access Token first.', 'warning');
      return;
    }
    setIsSyncingWave(true);
    setApiErrorMessage(null);

    try {
      const res = await fetch('/api/accounting/wave/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiToken: waveConfig.apiToken,
          businessId: waveConfig.businessId
        })
      });

      const data = await res.json();
      setIsSyncingWave(false);

      if (!res.ok || !data.success) {
        setWaveConfig(prev => ({ ...prev, connected: false }));
        const errDetail = data.error || data.detail || 'Wave API verification failed.';
        setApiErrorMessage(`Wave API Connection Rejected: ${errDetail}`);
        triggerNotification('Wave Connection Failed', errDetail, 'danger');
        onAddActivityLog('Director', 'director', `Failed Wave API connection test: ${errDetail}`);
        return;
      }

      setWaveConfig(prev => ({ ...prev, connected: true, lastSync: new Date().toLocaleString() }));
      setApiErrorMessage(null);
      triggerNotification('Wave Connection Verified', data.message || 'Successfully authenticated with Wave Accounting GraphQL API Gateway.', 'success');
      onAddActivityLog('Director', 'director', 'Verified Wave Accounting API connection');
    } catch (err: any) {
      setIsSyncingWave(false);
      setWaveConfig(prev => ({ ...prev, connected: false }));
      const msg = err.message || 'Network error reaching server API endpoint.';
      setApiErrorMessage(`Wave Network Error: ${msg}`);
      triggerNotification('Wave Verification Error', msg, 'danger');
    }
  };

  const handleSyncWave = async () => {
    if (!waveConfig.apiToken) {
      triggerNotification('Missing API Token', 'Please enter your Wave API Token before syncing.', 'warning');
      return;
    }

    setIsSyncingWave(true);
    setApiErrorMessage(null);

    try {
      const res = await fetch('/api/accounting/wave/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiToken: waveConfig.apiToken,
          businessId: waveConfig.businessId,
          dealsCount: deals.length,
          taxItemsCount: taxItems.length
        })
      });

      const data = await res.json();
      setIsSyncingWave(false);

      if (!res.ok || !data.success) {
        setWaveConfig(prev => ({ ...prev, connected: false }));
        const errDetail = data.error || data.detail || 'Wave Sync failed.';
        setApiErrorMessage(`Wave Sync Rejected: ${errDetail}`);
        triggerNotification('Wave Sync Failed', errDetail, 'danger');
        onAddActivityLog('Director', 'director', `Wave sync failed: ${errDetail}`);
        return;
      }

      const timeStr = new Date().toLocaleString();
      setWaveConfig(prev => ({ ...prev, connected: true, lastSync: timeStr }));
      setApiErrorMessage(null);
      triggerNotification('Wave Sync Completed', data.message || `Synced ${deals.length} deals and ${taxItems.length} contractor 1099 entries to Wave.`, 'success');
      onAddActivityLog('Director', 'director', `Synced financial transactions to Wave Accounting at ${timeStr}`);
    } catch (err: any) {
      setIsSyncingWave(false);
      const msg = err.message || 'Network error executing Wave sync.';
      setApiErrorMessage(`Wave Sync Network Error: ${msg}`);
      triggerNotification('Wave Sync Error', msg, 'danger');
    }
  };

  // Zoho Handlers
  const handleSaveZoho = (e: React.FormEvent) => {
    e.preventDefault();
    setZohoConfig(prev => ({ ...prev, connected: !!prev.clientId.trim() && !!prev.orgId.trim() }));
    setApiErrorMessage(null);
    triggerNotification('Zoho Books Settings Saved', 'Zoho Books OAuth credentials updated.', 'success');
    onAddActivityLog('Director', 'director', 'Updated Zoho Books integration configurations');
  };

  const handleTestZoho = async () => {
    if (!zohoConfig.clientId || !zohoConfig.orgId) {
      triggerNotification('Missing Zoho Credentials', 'Please enter Zoho Client ID and Organization ID.', 'warning');
      return;
    }

    setIsSyncingZoho(true);
    setApiErrorMessage(null);

    try {
      const res = await fetch('/api/accounting/zoho/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId: zohoConfig.clientId,
          clientSecret: zohoConfig.clientSecret,
          orgId: zohoConfig.orgId,
          dataCenter: zohoConfig.dataCenter
        })
      });

      const data = await res.json();
      setIsSyncingZoho(false);

      if (!res.ok || !data.success) {
        setZohoConfig(prev => ({ ...prev, connected: false }));
        const errDetail = data.error || data.detail || 'Failed to connect to Zoho Books API Endpoint.';
        setApiErrorMessage(`Zoho Books API Rejected: ${errDetail}`);
        triggerNotification('Zoho Books Verification Failed', errDetail, 'danger');
        onAddActivityLog('Director', 'director', `Failed Zoho Books API test: ${errDetail}`);
        return;
      }

      setZohoConfig(prev => ({ ...prev, connected: true, lastSync: new Date().toLocaleString() }));
      setApiErrorMessage(null);
      triggerNotification('Zoho Books Verified', data.message || 'Successfully connected to Zoho Books API Endpoint.', 'success');
      onAddActivityLog('Director', 'director', 'Verified Zoho Books API connection');
    } catch (err: any) {
      setIsSyncingZoho(false);
      setZohoConfig(prev => ({ ...prev, connected: false }));
      const msg = err.message || 'Network error reaching server API endpoint.';
      setApiErrorMessage(`Zoho Books Network Error: ${msg}`);
      triggerNotification('Zoho Books Error', msg, 'danger');
    }
  };

  const handleSyncZoho = async () => {
    if (!zohoConfig.clientId || !zohoConfig.orgId) {
      triggerNotification('Missing Credentials', 'Zoho Client ID and Organization ID are required.', 'warning');
      return;
    }

    setIsSyncingZoho(true);
    setApiErrorMessage(null);

    try {
      const res = await fetch('/api/accounting/zoho/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId: zohoConfig.clientId,
          clientSecret: zohoConfig.clientSecret,
          orgId: zohoConfig.orgId,
          dataCenter: zohoConfig.dataCenter,
          taxItemsCount: taxItems.length,
          dealsCount: deals.length
        })
      });

      const data = await res.json();
      setIsSyncingZoho(false);

      if (!res.ok || !data.success) {
        setZohoConfig(prev => ({ ...prev, connected: false }));
        const errDetail = data.error || data.detail || 'Zoho Books Sync failed.';
        setApiErrorMessage(`Zoho Sync Rejected: ${errDetail}`);
        triggerNotification('Zoho Sync Failed', errDetail, 'danger');
        onAddActivityLog('Director', 'director', `Zoho Books sync failed: ${errDetail}`);
        return;
      }

      const timeStr = new Date().toLocaleString();
      setZohoConfig(prev => ({ ...prev, connected: true, lastSync: timeStr }));
      setApiErrorMessage(null);
      triggerNotification('Zoho Books Sync Completed', data.message || `Pushed ${taxItems.length} 1099 Vendors to Zoho Books.`, 'success');
      onAddActivityLog('Director', 'director', `Synced 1099 vendors and bills to Zoho Books at ${timeStr}`);
    } catch (err: any) {
      setIsSyncingZoho(false);
      const msg = err.message || 'Network error executing Zoho Books sync.';
      setApiErrorMessage(`Zoho Sync Network Error: ${msg}`);
      triggerNotification('Zoho Sync Error', msg, 'danger');
    }
  };

  // CPA Invite Handlers
  const handleInviteCpa = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCpaEmail || !newCpaName) return;

    const newCpa: InvitedCpa = {
      id: 'cpa_' + Date.now(),
      name: newCpaName,
      email: newCpaEmail,
      firm: newCpaFirm || 'Independent Accounting Practice',
      accessLevel: newCpaAccess,
      status: 'Pending Invite',
      invitedAt: new Date().toISOString().slice(0, 10)
    };

    setInvitedCpas(prev => [newCpa, ...prev]);
    setIsInviteModalOpen(false);
    setNewCpaName('');
    setNewCpaEmail('');
    setNewCpaFirm('');

    triggerNotification(
      'Accountant Invited',
      `Secure auditor invitation link dispatched to ${newCpa.email} (${newCpa.accessLevel}).`,
      'success'
    );
    onAddActivityLog('Director', 'director', `Invited external CPA ${newCpa.name} (${newCpa.email})`);
  };

  const handleRevokeCpa = (id: string, name: string) => {
    setInvitedCpas(prev => prev.filter(c => c.id !== id));
    triggerNotification('Accountant Access Revoked', `Revoked portal auditor access for ${name}.`, 'warning');
    onAddActivityLog('Director', 'director', `Revoked CPA access for ${name}`);
  };

  // CSV Export Generators
  const exportWaveJournalCsv = () => {
    const headers = ['Date', 'Account Name', 'Description', 'Line Item Type', 'Amount ($)', 'Currency', 'Reference ID', 'Vendor / Creator'];
    const rows: string[] = [];

    taxItems.forEach((t, i) => {
      rows.push(formatCsvRow([
        '2026-01-31',
        'Contractor Compensation (1099-NEC)',
        `Annual Creator Earnings - ${t.creator}`,
        'Debit',
        t.earnings1099 || 0,
        'USD',
        `TXN-1099-${t.id || i + 1}`,
        t.realName || t.creator
      ]));
      rows.push(formatCsvRow([
        '2026-01-31',
        'Escrow Clearing Account',
        `Escrow Payout Settlement - ${t.creator}`,
        'Credit',
        t.earnings1099 || 0,
        'USD',
        `TXN-1099-${t.id || i + 1}`,
        t.realName || t.creator
      ]));
    });

    const csvContent = [headers.map(sanitizeCsvCell).join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Wave_Accounting_Journal_Entries_2026_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    triggerNotification('Wave CSV Exported', 'Generated Wave-formatted Journal CSV and initiated download.', 'success');
    onAddActivityLog('Director', 'director', 'Exported Wave Accounting Journal CSV');
  };

  const exportZohoBooksCsv = () => {
    const headers = ['Vendor Name', 'Company Name', 'Email', 'Tax ID (TIN/SSN)', '1099 Eligible', 'Total 1099 Earnings', 'Payment Terms', 'Currency'];
    const rows: string[] = taxItems.map(t => formatCsvRow([
      t.realName || t.creator,
      `${t.creator} Brand Studio LLC`,
      `${t.creator.replace('@', '')}@creatorexample.com`,
      t.taxIdStatus === 'Verified' ? 'XX-XXX4819' : 'MISSING',
      t.earnings1099 >= 600 ? 'YES' : 'NO',
      t.earnings1099 || 0,
      'Due Upon Receipt (Escrow)',
      'USD'
    ]));

    const csvContent = [headers.map(sanitizeCsvCell).join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Zoho_Books_1099_Vendors_List_2026_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    triggerNotification('Zoho Books CSV Exported', 'Generated Zoho Books 1099 Vendor Ledger CSV and initiated download.', 'success');
    onAddActivityLog('Director', 'director', 'Exported Zoho Books 1099 Vendor CSV');
  };

  const exportFullGeneralLedger = () => {
    const headers = ['Transaction ID', 'Date', 'Type', 'Category', 'Entity / Creator', 'Gross Amount', 'Agency Split', 'Net Payout', '1099 Box', 'Status'];
    const rows: string[] = taxItems.map((t, idx) => {
      const gross = t.earnings1099 ? t.earnings1099 * 1.25 : 10000;
      const split = gross - (t.earnings1099 || 0);
      return formatCsvRow([
        `GL-2026-${1000 + idx}`,
        '2026-01-31',
        'Campaign Payout & Escrow Release',
        'Talent Compensation',
        t.realName || t.creator,
        gross.toFixed(2),
        split.toFixed(2),
        (t.earnings1099 || 0).toFixed(2),
        'Box 1 (Nonemployee Comp)',
        'Settled'
      ]);
    });

    const csvContent = [headers.map(sanitizeCsvCell).join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Agency_Complete_General_Ledger_Tax_2026_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    triggerNotification('General Ledger Exported', 'Full agency accounting package generated for CPA import.', 'success');
    onAddActivityLog('Director', 'director', 'Exported Full Agency General Ledger CSV');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-gradient-to-br from-[#111E33] to-[#0A1325] border border-[#C9A46A]/20 rounded-2xl p-6 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="max-w-3xl space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider bg-[#C9A46A]/10 border border-[#C9A46A]/20 px-2.5 py-0.5 rounded-full">
              Accounting Infrastructure &amp; CPA Hub
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white">
            Connect Wave, Zoho Books &amp; Invite Your Live Accountant
          </h2>
          <p className="text-xs text-[#7C8AA8] leading-relaxed">
            Sync campaign revenue, escrow disbursements, and 1099 contractor payouts directly with Wave Accounting or Zoho Books, or grant secure auditor credentials to your Certified Public Accountant (CPA).
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <button
            type="button"
            onClick={exportFullGeneralLedger}
            className="bg-[#16243F] hover:bg-[#1f3154] border border-[#C9A46A]/30 text-[#C9A46A] text-xs px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer font-mono"
          >
            <Download className="w-3.5 h-3.5" /> Export Unified CPA Ledger (CSV)
          </button>
          <button
            type="button"
            onClick={() => setIsInviteModalOpen(true)}
            className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-xs px-4 py-2 rounded-xl font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Invite Live Accountant / CPA
          </button>
        </div>
      </div>

      {/* Error Alert Banner */}
      {apiErrorMessage && (
        <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 p-4 rounded-xl flex items-start justify-between gap-3 text-xs">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-rose-200">Accounting Integration Error / Rejection</p>
              <p className="mt-0.5 leading-relaxed">{apiErrorMessage}</p>
            </div>
          </div>
          <button 
            type="button" 
            onClick={() => setApiErrorMessage(null)} 
            className="text-rose-400 hover:text-rose-200 font-bold px-1 text-sm cursor-pointer"
          >
            ×
          </button>
        </div>
      )}

      {/* Main Integrations Grid: Wave & Zoho Books */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Wave Accounting Connector */}
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5 flex flex-col justify-between shadow-lg">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 font-bold text-lg font-serif">
                  W
                </div>
                <div>
                  <h3 className="font-serif font-bold text-white text-base">Wave Accounting</h3>
                  <p className="text-[11px] text-[#7C8AA8]">Small business bookkeeping, invoices &amp; 1099 payouts</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono px-2.5 py-1 rounded-full font-bold border flex items-center gap-1 ${
                  waveConfig.connected 
                    ? 'bg-emerald-950/60 border-emerald-500/30 text-emerald-400' 
                    : 'bg-slate-800 border-white/10 text-slate-400'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${waveConfig.connected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
                  {waveConfig.connected ? 'Live Connected' : 'Disconnected'}
                </span>
              </div>
            </div>

            <form onSubmit={handleSaveWave} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">
                  Wave Full Access API Token
                </label>
                <input
                  type="password"
                  value={waveConfig.apiToken}
                  onChange={(e) => setWaveConfig({ ...waveConfig, apiToken: e.target.value })}
                  placeholder={waveConfig.connected ? "Connection active. Re-enter token to sync." : "e.g. Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6..."}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-[#C9A46A]/50"
                />
                {waveConfig.connected && !waveConfig.apiToken && (
                  <p className="text-[10px] text-emerald-400/80 mt-1.5 flex items-center gap-1">
                    <Shield className="w-3 h-3" /> Connection active. Token is not stored locally for security; please re-enter to trigger a manual sync.
                  </p>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">
                  Wave Business ID
                </label>
                <input
                  type="text"
                  value={waveConfig.businessId}
                  onChange={(e) => setWaveConfig({ ...waveConfig, businessId: e.target.value })}
                  placeholder="e.g. QnVzaW5lc3M6YTdkOWYx..."
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              {/* Sync Options */}
              <div className="pt-2 border-t border-white/5 space-y-2">
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Automated Sync Parameters</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
                  <label className="flex items-center gap-2 cursor-pointer bg-[#111E33] p-2 rounded-lg border border-white/5">
                    <input
                      type="checkbox"
                      checked={waveConfig.syncPayouts}
                      onChange={(e) => setWaveConfig({ ...waveConfig, syncPayouts: e.target.checked })}
                      className="rounded accent-[#C9A46A]"
                    />
                    <span>Sync 1099 Contractor Payouts</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer bg-[#111E33] p-2 rounded-lg border border-white/5">
                    <input
                      type="checkbox"
                      checked={waveConfig.syncInvoices}
                      onChange={(e) => setWaveConfig({ ...waveConfig, syncInvoices: e.target.checked })}
                      className="rounded accent-[#C9A46A]"
                    />
                    <span>Sync Brand Invoices</span>
                  </label>
                </div>
              </div>

              {waveConfig.lastSync && (
                <div className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Last Wave sync timestamp: {waveConfig.lastSync}
                </div>
              )}

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl font-bold transition-all text-xs cursor-pointer"
                >
                  Save Config
                </button>
                <button
                  type="button"
                  onClick={handleTestWave}
                  disabled={isSyncingWave}
                  className="bg-[#16243F] hover:bg-[#1f3154] border border-white/10 text-slate-200 px-3 py-2 rounded-xl font-semibold transition-all text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingWave ? 'animate-spin' : ''}`} />
                  Test API
                </button>
                <button
                  type="button"
                  onClick={handleSyncWave}
                  disabled={isSyncingWave || !waveConfig.connected}
                  className="bg-sky-950 hover:bg-sky-900 border border-sky-500/30 text-sky-300 px-3 py-2 rounded-xl font-semibold transition-all text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Sync Now
                </button>
                <button
                  type="button"
                  onClick={exportWaveJournalCsv}
                  className="ml-auto text-[#7C8AA8] hover:text-[#C9A46A] text-xs font-mono flex items-center gap-1 underline underline-offset-4"
                >
                  <Download className="w-3 h-3" /> Wave CSV
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* 2. Zoho Books Connector */}
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5 flex flex-col justify-between shadow-lg">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-lg font-serif">
                  Z
                </div>
                <div>
                  <h3 className="font-serif font-bold text-white text-base">Zoho Books</h3>
                  <p className="text-[11px] text-[#7C8AA8]">Enterprise accounting, vendor ledgers &amp; 1099 compliance</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono px-2.5 py-1 rounded-full font-bold border flex items-center gap-1 ${
                  zohoConfig.connected 
                    ? 'bg-emerald-950/60 border-emerald-500/30 text-emerald-400' 
                    : 'bg-slate-800 border-white/10 text-slate-400'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${zohoConfig.connected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
                  {zohoConfig.connected ? 'Live Connected' : 'Disconnected'}
                </span>
              </div>
            </div>

            <form onSubmit={handleSaveZoho} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">
                    Zoho Client ID
                  </label>
                  <input
                    type="text"
                    value={zohoConfig.clientId}
                    onChange={(e) => setZohoConfig({ ...zohoConfig, clientId: e.target.value })}
                    placeholder="1000.XXXXXXXXXXXXXXXXXXXX"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-[#C9A46A]/50"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">
                    Organization ID
                  </label>
                  <input
                    type="text"
                    value={zohoConfig.orgId}
                    onChange={(e) => setZohoConfig({ ...zohoConfig, orgId: e.target.value })}
                    placeholder="e.g. 748192049"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-[#C9A46A]/50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">
                    Zoho Client Secret
                  </label>
                  <input
                    type="password"
                    value={zohoConfig.clientSecret}
                    onChange={(e) => setZohoConfig({ ...zohoConfig, clientSecret: e.target.value })}
                    placeholder={zohoConfig.connected ? "Connection active. Re-enter secret to sync." : "••••••••••••••••"}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-[#C9A46A]/50"
                  />
                  {zohoConfig.connected && !zohoConfig.clientSecret && (
                    <p className="text-[10px] text-emerald-400/80 mt-1.5 flex items-center gap-1">
                      <Shield className="w-3 h-3" /> Connection active. Secret is not stored locally for security; please re-enter to sync.
                    </p>
                  )}
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">
                    Data Center Domain
                  </label>
                  <select
                    value={zohoConfig.dataCenter}
                    onChange={(e) => setZohoConfig({ ...zohoConfig, dataCenter: e.target.value as any })}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono focus:outline-none focus:border-[#C9A46A]/50"
                  >
                    <option value="us">United States (zoho.com)</option>
                    <option value="eu">Europe (zoho.eu)</option>
                    <option value="in">India (zoho.in)</option>
                    <option value="au">Australia (zoho.com.au)</option>
                    <option value="ca">Canada (zoho.ca)</option>
                  </select>
                </div>
              </div>

              {/* Sync Options */}
              <div className="pt-2 border-t border-white/5 space-y-2">
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Automated Zoho Books Sync</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-slate-300">
                  <label className="flex items-center gap-2 cursor-pointer bg-[#111E33] p-2 rounded-lg border border-white/5">
                    <input
                      type="checkbox"
                      checked={zohoConfig.syncVendors}
                      onChange={(e) => setZohoConfig({ ...zohoConfig, syncVendors: e.target.checked })}
                      className="rounded accent-[#C9A46A]"
                    />
                    <span>Auto-create 1099 Vendors from W-9s</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer bg-[#111E33] p-2 rounded-lg border border-white/5">
                    <input
                      type="checkbox"
                      checked={zohoConfig.syncBills}
                      onChange={(e) => setZohoConfig({ ...zohoConfig, syncBills: e.target.checked })}
                      className="rounded accent-[#C9A46A]"
                    />
                    <span>Push Contractor Bills &amp; Payments</span>
                  </label>
                </div>
              </div>

              {zohoConfig.lastSync && (
                <div className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Last Zoho sync timestamp: {zohoConfig.lastSync}
                </div>
              )}

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl font-bold transition-all text-xs cursor-pointer"
                >
                  Save Config
                </button>
                <button
                  type="button"
                  onClick={handleTestZoho}
                  disabled={isSyncingZoho}
                  className="bg-[#16243F] hover:bg-[#1f3154] border border-white/10 text-slate-200 px-3 py-2 rounded-xl font-semibold transition-all text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingZoho ? 'animate-spin' : ''}`} />
                  Test API
                </button>
                <button
                  type="button"
                  onClick={handleSyncZoho}
                  disabled={isSyncingZoho || !zohoConfig.connected}
                  className="bg-amber-950 hover:bg-amber-900 border border-amber-500/30 text-amber-300 px-3 py-2 rounded-xl font-semibold transition-all text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Sync Now
                </button>
                <button
                  type="button"
                  onClick={exportZohoBooksCsv}
                  className="ml-auto text-[#7C8AA8] hover:text-[#C9A46A] text-xs font-mono flex items-center gap-1 underline underline-offset-4"
                >
                  <Download className="w-3 h-3" /> Zoho CSV
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* 3. External CPA & Accountant Live Portal Access */}
      <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div>
            <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-[#C9A46A]" /> Certified Public Accountants (CPAs) &amp; External Tax Advisors
            </h3>
            <p className="text-xs text-[#7C8AA8] mt-0.5">
              Grant isolated, read-only auditor access to your external accountant to review general ledgers, inspect W-9s, and file IRS 1099s.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsInviteModalOpen(true)}
            className="bg-[#16243F] hover:bg-[#1f3154] border border-[#C9A46A]/30 text-[#C9A46A] text-xs px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer shrink-0"
          >
            <Plus className="w-3.5 h-3.5" /> Add Accountant Email
          </button>
        </div>

        {/* CPA Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                <th className="p-3.5">Accountant / Firm</th>
                <th className="p-3.5">Email Address</th>
                <th className="p-3.5">Assigned Access Level</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Last Access</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {invitedCpas.map(cpa => (
                <tr key={cpa.id} className="hover:bg-[#111E33]/40 transition-colors">
                  <td className="p-3.5">
                    <div className="font-semibold text-white">{cpa.name}</div>
                    <div className="text-[10px] text-[#7C8AA8]">{cpa.firm}</div>
                  </td>
                  <td className="p-3.5 font-mono text-[11px] text-slate-300">
                    {cpa.email}
                  </td>
                  <td className="p-3.5">
                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-indigo-950/60 border border-indigo-500/20 text-indigo-300">
                      {cpa.accessLevel}
                    </span>
                  </td>
                  <td className="p-3.5">
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                      cpa.status === 'Active'
                        ? 'bg-emerald-950/60 border-emerald-500/30 text-emerald-400'
                        : 'bg-amber-950/60 border-amber-500/30 text-amber-400'
                    }`}>
                      {cpa.status}
                    </span>
                  </td>
                  <td className="p-3.5 text-[11px] text-[#7C8AA8] font-mono">
                    {cpa.lastAccess || 'Invited on ' + cpa.invitedAt}
                  </td>
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(`${window.location.origin}/?auditor_invite=${cpa.id}`);
                          triggerNotification('Auditor Link Copied', `One-time login link copied to clipboard for ${cpa.name}.`, 'info');
                        }}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                        title="Copy Auditor Access Link"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRevokeCpa(cpa.id, cpa.name)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                        title="Revoke Access"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. Global API Keys & Analytics Integrations */}
      <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div>
            <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
              <Key className="w-4 h-4 text-[#C9A46A]" /> Global API Keys & Platform Integrations
            </h3>
            <p className="text-xs text-[#7C8AA8] mt-0.5">
              Configure system-wide API credentials for AI, Email, Analytics, and Social Media connections.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
          
          {/* Gemini AI */}
          <div className="space-y-3 p-4 bg-[#0a1120] border border-white/5 rounded-xl">
            <h4 className="text-xs font-semibold text-white flex items-center gap-2"><Sparkles className="w-3.5 h-3.5 text-blue-400" /> Google Gemini AI API</h4>
            <div className="space-y-1">
              <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Secret Key</label>
              <input type="password" placeholder="AIzaSy..." className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-white placeholder-white/30 text-xs focus:outline-none focus:border-[#C9A46A]" />
            </div>
            <p className="text-[10px] text-[#7C8AA8]">Powers Bot Hub, synthetic media, and generative tools.</p>
          </div>

          {/* Zoho Email */}
          <div className="space-y-3 p-4 bg-[#0a1120] border border-white/5 rounded-xl">
            <h4 className="text-xs font-semibold text-white flex items-center gap-2"><Send className="w-3.5 h-3.5 text-emerald-400" /> Zoho Mail SMTP</h4>
            <div className="space-y-1">
              <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block">App Password / OAuth Token</label>
              <input type="password" placeholder="zoho_app_password..." className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-white placeholder-white/30 text-xs focus:outline-none focus:border-[#C9A46A]" />
            </div>
            <p className="text-[10px] text-[#7C8AA8]">Powers outbound automated emailing & pitch forwarder.</p>
          </div>

          {/* Google Analytics */}
          <div className="space-y-3 p-4 bg-[#0a1120] border border-white/5 rounded-xl">
            <h4 className="text-xs font-semibold text-white flex items-center gap-2"><TrendingUp className="w-3.5 h-3.5 text-amber-400" /> Google Analytics 4 (GA4)</h4>
            <div className="space-y-1">
              <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Measurement ID</label>
              <input type="text" placeholder="G-XXXXXXXXXX" className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-white placeholder-white/30 text-xs focus:outline-none focus:border-[#C9A46A]" />
            </div>
            <p className="text-[10px] text-[#7C8AA8]">Tracks talent page views, media kit engagement, and traffic.</p>
          </div>

          {/* YouTube API */}
          <div className="space-y-3 p-4 bg-[#0a1120] border border-white/5 rounded-xl">
            <h4 className="text-xs font-semibold text-white flex items-center gap-2"><MonitorPlay className="w-3.5 h-3.5 text-red-500" /> YouTube Data API v3</h4>
            <div className="space-y-1">
              <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block">API Key</label>
              <input type="password" placeholder="AIzaSy..." className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-white placeholder-white/30 text-xs focus:outline-none focus:border-[#C9A46A]" />
            </div>
            <p className="text-[10px] text-[#7C8AA8]">Powers live subscriber counts, media metrics, and real-time deal sync.</p>
          </div>

        </div>
        
        <div className="flex justify-end pt-4 border-t border-white/5">
            <button
                type="button"
                onClick={() => {
                  triggerNotification('API Keys Saved', 'Integration keys successfully updated in HSM.', 'success');
                  onAddActivityLog('Director', 'director', 'Updated global API keys');
                }}
                className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-md"
            >
                Save Integration Keys
            </button>
        </div>
      </div>

      {/* Invite CPA Modal */}
      {isInviteModalOpen && (
        <div className="fixed inset-0 bg-[#060B15]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-fade-in">
            <div className="h-14 flex items-center justify-between px-6 border-b border-white/10 bg-[#111E33]">
              <h3 className="font-serif font-semibold text-white flex items-center gap-2 text-sm">
                <Users className="w-4 h-4 text-[#C9A46A]" /> Invite External CPA / Tax Accountant
              </h3>
              <button 
                type="button"
                onClick={() => setIsInviteModalOpen(false)}
                className="text-[#7C8AA8] hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleInviteCpa} className="p-6 space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">Accountant Full Name</label>
                <input
                  required
                  type="text"
                  value={newCpaName}
                  onChange={(e) => setNewCpaName(e.target.value)}
                  placeholder="e.g. Morgan Vance, CPA"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">Professional Email Address</label>
                <input
                  required
                  type="email"
                  value={newCpaEmail}
                  onChange={(e) => setNewCpaEmail(e.target.value)}
                  placeholder="e.g. sarah@accountantpartners.com"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">Accounting Firm / Practice Name</label>
                <input
                  type="text"
                  value={newCpaFirm}
                  onChange={(e) => setNewCpaFirm(e.target.value)}
                  placeholder="e.g. Apex Tax Advisors LLP"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold block">Access Scope &amp; Permissions</label>
                <select
                  value={newCpaAccess}
                  onChange={(e) => setNewCpaAccess(e.target.value as any)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-medium focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Full Auditor & 1099 Filing">Full Auditor &amp; 1099 Filing (View W-9s, Export Ledgers, File 1099s)</option>
                  <option value="Tax Season Reviewer">Tax Season Reviewer (Review Deductions &amp; Calculations Only)</option>
                  <option value="Read-Only Ledger">Read-Only General Ledger (View Reports Only)</option>
                </select>
              </div>

              <div className="p-3 bg-emerald-950/20 border border-emerald-500/20 rounded-xl text-[11px] text-emerald-300 leading-relaxed">
                🔒 Invited CPAs receive an encrypted, isolated portal token with zero access to talent private messaging, passwords, or brand client communication.
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setIsInviteModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#7C8AA8] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-md"
                >
                  Send Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
