import React, { useState, useMemo } from 'react';
import { 
  Search, Filter, X, Check, DollarSign, Calendar, AlertTriangle, 
  ExternalLink, Layers, ArrowRight, ShieldAlert, FileText, CheckCircle, 
  Sparkles, Download, Copy, RefreshCw, User, Tag
} from 'lucide-react';
import { Deal, Creator } from '../types';

interface DealSearchModalProps {
  deals: Deal[];
  creators: Creator[];
  isOpen?: boolean;
  onClose?: () => void;
  onSelectDeal?: (deal: Deal) => void;
  onUpdateDealStage?: (dealId: string, stage: Deal['stage']) => void;
  currentRole?: string;
  currentUser?: any;
  primaryBrandColor?: string;
  cardBgColor?: string;
  triggerNotification?: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  isInlineView?: boolean;
}

export default function DealSearchModal({
  deals = [],
  creators = [],
  isOpen = true,
  onClose,
  onSelectDeal,
  onUpdateDealStage,
  currentRole = 'director',
  currentUser,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  triggerNotification,
  onAddActivityLog,
  isInlineView = false
}: DealSearchModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStage, setSelectedStage] = useState<string>('all');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');
  const [selectedBudgetTier, setSelectedBudgetTier] = useState<string>('all');
  const [filterMissingW9, setFilterMissingW9] = useState(false);
  const [filterFtcRequired, setFilterFtcRequired] = useState(false);
  const [filterOverdue, setFilterOverdue] = useState(false);
  const [sortBy, setSortBy] = useState<'value_desc' | 'value_asc' | 'due_soon' | 'brand'>('value_desc');

  // Multi-facet filtering logic
  const filteredDeals = useMemo(() => {
    return deals.filter(deal => {
      // 1. Text Search across all fields
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesBrand = (deal.brand || '').toLowerCase().includes(query);
        const matchesCreator = (deal.creator || '').toLowerCase().includes(query) || (deal.creatorHandle || '').toLowerCase().includes(query);
        const matchesTitle = (deal.title || '').toLowerCase().includes(query);
        const matchesAgent = (deal.agent || '').toLowerCase().includes(query);
        const matchesNotes = (deal.notes || '').toLowerCase().includes(query);
        const matchesDeliverable = (deal.deliverable || '').toLowerCase().includes(query);
        const matchesId = (deal.id || '').toLowerCase().includes(query);

        if (!matchesBrand && !matchesCreator && !matchesTitle && !matchesAgent && !matchesNotes && !matchesDeliverable && !matchesId) {
          return false;
        }
      }

      // 2. Stage Filter
      if (selectedStage !== 'all' && deal.stage !== selectedStage) {
        return false;
      }

      // 3. Platform Filter
      if (selectedPlatform !== 'all' && (deal.platform || '').toLowerCase() !== selectedPlatform.toLowerCase()) {
        return false;
      }

      // 4. Budget Range Filter
      const val = Number(deal.budget || deal.value || 0);
      if (selectedBudgetTier === 'under1k' && val >= 1000) return false;
      if (selectedBudgetTier === '1k_5k' && (val < 1000 || val > 5000)) return false;
      if (selectedBudgetTier === '5k_15k' && (val < 5000 || val > 15000)) return false;
      if (selectedBudgetTier === 'over15k' && val <= 15000) return false;

      // 5. Special Flags (W-9, FTC, Overdue)
      if (filterMissingW9) {
        const matchedCreator = creators.find(c => 
          c.name.toLowerCase() === (deal.creator || '').toLowerCase() ||
          c.handle.toLowerCase() === (deal.creator || '').toLowerCase()
        );
        const hasW9 = matchedCreator && (matchedCreator.w9Status === 'Verified' || matchedCreator.w9Status === 'Received');
        if (hasW9) return false;
      }

      if (filterFtcRequired) {
        const hasFtcDeliverable = (deal.deliverable || '').toLowerCase().includes('sponsored') || (deal.deliverable || '').toLowerCase().includes('ad') || (deal.deliverable || '').toLowerCase().includes('tiktok') || (deal.deliverable || '').toLowerCase().includes('reel');
        if (!hasFtcDeliverable) return false;
      }

      if (filterOverdue) {
        if (!deal.due) return false;
        const dueDate = new Date(deal.due);
        const isPast = dueDate.getTime() < Date.now() && deal.stage !== 'Completed';
        if (!isPast) return false;
      }

      return true;
    }).sort((a, b) => {
      const valA = Number(a.budget || a.value || 0);
      const valB = Number(b.budget || b.value || 0);

      if (sortBy === 'value_desc') return valB - valA;
      if (sortBy === 'value_asc') return valA - valB;
      if (sortBy === 'brand') return (a.brand || '').localeCompare(b.brand || '');
      if (sortBy === 'due_soon') {
        const dateA = a.due ? new Date(a.due).getTime() : 9999999999999;
        const dateB = b.due ? new Date(b.due).getTime() : 9999999999999;
        return dateA - dateB;
      }
      return 0;
    });
  }, [deals, creators, searchTerm, selectedStage, selectedPlatform, selectedBudgetTier, filterMissingW9, filterFtcRequired, filterOverdue, sortBy]);

  // Aggregate values of search results
  const totalResultsValue = filteredDeals.reduce((sum, d) => sum + (Number(d.budget || d.value || 0)), 0);

  const handleCopyDealSummary = (deal: Deal) => {
    const text = `🤝 Deal: ${deal.brand} x ${deal.creator}\n💰 Budget: $${Number(deal.budget || deal.value || 0).toLocaleString()}\n📍 Stage: ${deal.stage}\n📱 Platform: ${deal.platform || 'Cross-Platform'}\n🗓️ Due Date: ${deal.due || 'TBD'}`;
    navigator.clipboard.writeText(text);
    triggerNotification?.('Copied to Clipboard', `Deal summary for ${deal.brand} copied.`, 'success');
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedStage('all');
    setSelectedPlatform('all');
    setSelectedBudgetTier('all');
    setFilterMissingW9(false);
    setFilterFtcRequired(false);
    setFilterOverdue(false);
    setSortBy('value_desc');
  };

  const content = (
    <div className="space-y-6">
      
      {/* Search Header */}
      <div className="bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 relative overflow-hidden" style={{ backgroundColor: cardBgColor }}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                DEEP DEAL INTELLIGENCE
              </span>
              <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded border border-white/5">
                {filteredDeals.length} of {deals.length} deals
              </span>
            </div>
            <h1 className="font-serif text-2xl font-bold text-white flex items-center gap-2.5 mt-1">
              <Search className="w-6 h-6" style={{ color: primaryBrandColor }} />
              Deal Finder &amp; Cross-Agency Search
            </h1>
            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Instant multi-attribute search across all active agency sponsorships, talent deliverables, and contracts.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-[#111E33] border border-white/10 px-4 py-2 rounded-xl text-right">
              <span className="text-[10px] text-[#7C8AA8] font-mono block uppercase">Filtered Pipeline Volume</span>
              <span className="text-lg font-bold font-mono text-emerald-400">
                ${totalResultsValue.toLocaleString()}
              </span>
            </div>

            {onClose && !isInlineView && (
              <button 
                onClick={onClose}
                className="p-2.5 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded-xl border border-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Global Search Input Box */}
        <div className="mt-5 relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4 text-[#C9A46A]" />
          </div>
          <input
            type="text"
            placeholder="Search by brand name, creator handle, deliverable keyword, agent, or notes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#111E33] border border-white/15 focus:border-[#C9A46A] rounded-xl pl-10 pr-10 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-none shadow-inner"
            autoFocus={!isInlineView}
          />
          {searchTerm && (
            <button 
              onClick={() => setSearchTerm('')}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Badges & Controls */}
        <div className="mt-4 pt-4 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          <div className="flex flex-wrap items-center gap-2">
            {/* Stage Filter */}
            <select
              value={selectedStage}
              onChange={(e) => setSelectedStage(e.target.value)}
              className="bg-[#111E33] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
            >
              <option value="all">All Stages</option>
              <option value="Lead">Lead</option>
              <option value="Pitched">Pitched</option>
              <option value="Negotiating">Negotiating</option>
              <option value="Contracted">Contracted</option>
              <option value="Live">Live</option>
              <option value="Completed">Completed</option>
              <option value="Paused — crisis hold">Crisis Hold</option>
            </select>

            {/* Platform Filter */}
            <select
              value={selectedPlatform}
              onChange={(e) => setSelectedPlatform(e.target.value)}
              className="bg-[#111E33] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
            >
              <option value="all">All Platforms</option>
              <option value="TikTok">TikTok</option>
              <option value="Instagram">Instagram</option>
              <option value="YouTube">YouTube</option>
              <option value="UGC">UGC</option>
              <option value="Cross-Platform">Cross-Platform</option>
            </select>

            {/* Budget Tier */}
            <select
              value={selectedBudgetTier}
              onChange={(e) => setSelectedBudgetTier(e.target.value)}
              className="bg-[#111E33] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
            >
              <option value="all">Any Budget Tier</option>
              <option value="under1k">Under $1,000</option>
              <option value="1k_5k">$1,000 - $5,000</option>
              <option value="5k_15k">$5,000 - $15,000</option>
              <option value="over15k">$15,000+</option>
            </select>

            {/* Quick Flag Toggles */}
            <button
              onClick={() => setFilterMissingW9(!filterMissingW9)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono flex items-center gap-1 transition-colors cursor-pointer border ${
                filterMissingW9 
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-bold' 
                  : 'bg-[#111E33] text-slate-400 border-white/10 hover:text-white'
              }`}
            >
              <AlertTriangle className="w-3 h-3 text-rose-400" />
              Missing W-9
            </button>

            <button
              onClick={() => setFilterFtcRequired(!filterFtcRequired)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono flex items-center gap-1 transition-colors cursor-pointer border ${
                filterFtcRequired 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 font-bold' 
                  : 'bg-[#111E33] text-slate-400 border-white/10 hover:text-white'
              }`}
            >
              <ShieldAlert className="w-3 h-3 text-amber-400" />
              FTC Disclosure
            </button>

            <button
              onClick={() => setFilterOverdue(!filterOverdue)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono flex items-center gap-1 transition-colors cursor-pointer border ${
                filterOverdue 
                  ? 'bg-red-500/20 text-red-300 border-red-500/40 font-bold' 
                  : 'bg-[#111E33] text-slate-400 border-white/10 hover:text-white'
              }`}
            >
              <Calendar className="w-3 h-3 text-red-400" />
              Overdue
            </button>
          </div>

          {/* Sort & Reset */}
          <div className="flex items-center gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#111E33] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none cursor-pointer"
            >
              <option value="value_desc">Highest Value ($)</option>
              <option value="value_asc">Lowest Value ($)</option>
              <option value="due_soon">Due Date (Soonest)</option>
              <option value="brand">Brand (A-Z)</option>
            </select>

            {(searchTerm || selectedStage !== 'all' || selectedPlatform !== 'all' || selectedBudgetTier !== 'all' || filterMissingW9 || filterFtcRequired || filterOverdue) && (
              <button
                onClick={handleResetFilters}
                className="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg text-xs font-mono transition-colors cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>

        </div>
      </div>

      {/* Results Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs text-[#7C8AA8] px-1 font-mono">
          <span>Found {filteredDeals.length} matching partnerships</span>
          <span>Sorted by {sortBy.replace('_', ' ')}</span>
        </div>

        {filteredDeals.length === 0 ? (
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-12 text-center space-y-3" style={{ backgroundColor: cardBgColor }}>
            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mx-auto text-slate-400">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-white font-bold text-base">No deals match your search criteria</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Try adjusting your query, stage filters, or toggling off flag filters to view more deals.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 bg-[#C9A46A] text-[#0A1220] rounded-xl text-xs font-bold transition-all cursor-pointer inline-block"
              style={{ backgroundColor: primaryBrandColor }}
            >
              Clear All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredDeals.map((deal) => {
              const matchedCreator = creators.find(c => 
                c.name.toLowerCase() === (deal.creator || '').toLowerCase() ||
                c.handle.toLowerCase() === (deal.creator || '').toLowerCase()
              );
              const hasW9 = matchedCreator && (matchedCreator.w9Status === 'Verified' || matchedCreator.w9Status === 'Received');

              return (
                <div 
                  key={deal.id}
                  className="bg-[#0D1830] border border-white/5 hover:border-[#C9A46A]/50 rounded-2xl p-5 space-y-4 transition-all shadow-md group relative"
                  style={{ backgroundColor: cardBgColor }}
                >
                  
                  {/* Top Bar: Brand, Creator, Value */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-white text-base group-hover:text-[#C9A46A] transition-colors">
                          {deal.brand}
                        </h3>
                        <span className="text-[10px] font-mono bg-white/5 px-2 py-0.5 rounded text-slate-300 border border-white/5">
                          {deal.platform || 'Cross-Platform'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-[#7C8AA8]">
                        <User className="w-3.5 h-3.5 text-[#C9A46A]" />
                        <span className="text-slate-200 font-semibold">{deal.creator || deal.creatorHandle || 'Assigned Talent'}</span>
                        {matchedCreator?.followers && (
                          <span className="text-[10px] font-mono text-slate-400">({matchedCreator.followers})</span>
                        )}
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-lg font-bold font-mono text-emerald-400 block">
                        ${Number(deal.budget || deal.value || 0).toLocaleString()}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold font-mono uppercase tracking-wider inline-block mt-0.5 ${
                        deal.stage === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                        deal.stage === 'Live' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                        deal.stage === 'Contracted' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' :
                        deal.stage === 'Negotiating' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                        deal.stage === 'Pitched' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                        'bg-slate-500/10 text-slate-300 border border-slate-500/20'
                      }`}>
                        {deal.stage}
                      </span>
                    </div>
                  </div>

                  {/* Deliverable & Notes */}
                  <div className="bg-[#111E33] p-3 rounded-xl border border-white/5 space-y-1.5 text-xs">
                    {deal.deliverable && (
                      <div className="flex items-start gap-2 text-slate-300">
                        <FileText className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                        <span className="text-[11px] leading-snug">
                          <strong>Deliverable:</strong> {deal.deliverable}
                        </span>
                      </div>
                    )}
                    {deal.notes && (
                      <p className="text-[11px] text-slate-400 italic line-clamp-2">
                        &ldquo;{deal.notes}&rdquo;
                      </p>
                    )}
                    <div className="pt-1 flex flex-wrap items-center justify-between text-[10px] font-mono text-[#7C8AA8]">
                      <span>Due: {deal.due || 'Open Timeline'}</span>
                      <span>Agent: {deal.agent || 'Marcus Cole'}</span>
                    </div>
                  </div>

                  {/* Operational Risk Indicators */}
                  <div className="flex flex-wrap items-center gap-2">
                    {!hasW9 && Number(deal.budget || deal.value || 0) >= 600 && (
                      <span className="px-2 py-0.5 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded text-[9px] font-mono flex items-center gap-1">
                        <AlertTriangle className="w-2.5 h-2.5" /> W-9 Missing (&gt;$600)
                      </span>
                    )}
                    {(deal.deliverable || '').toLowerCase().includes('sponsored') && (
                      <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded text-[9px] font-mono flex items-center gap-1">
                        <ShieldAlert className="w-2.5 h-2.5" /> FTC Disclosure
                      </span>
                    )}
                    {deal.invoiceGenerated && (
                      <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded text-[9px] font-mono flex items-center gap-1">
                        <CheckCircle className="w-2.5 h-2.5" /> Invoice Ready
                      </span>
                    )}
                  </div>

                  {/* Actions Footer */}
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2 text-xs">
                    {/* Stage quick selector */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-[#7C8AA8] font-mono">Stage:</span>
                      <select
                        value={deal.stage}
                        onChange={(e) => onUpdateDealStage?.(deal.id, e.target.value as Deal['stage'])}
                        className="bg-[#111E33] border border-white/10 rounded-md px-2 py-0.5 text-[11px] text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
                      >
                        <option value="Lead">Lead</option>
                        <option value="Pitched">Pitched</option>
                        <option value="Negotiating">Negotiating</option>
                        <option value="Contracted">Contracted</option>
                        <option value="Live">Live</option>
                        <option value="Completed">Completed</option>
                        <option value="Paused — crisis hold">Crisis Hold</option>
                      </select>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleCopyDealSummary(deal)}
                        className="p-1.5 bg-[#111E33] hover:bg-[#16243F] text-slate-300 hover:text-white rounded-lg border border-white/5 text-[11px] cursor-pointer"
                        title="Copy deal briefing"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      {onSelectDeal && (
                        <button
                          onClick={() => onSelectDeal(deal)}
                          className="px-2.5 py-1 bg-[#C9A46A]/20 hover:bg-[#C9A46A]/30 text-[#C9A46A] border border-[#C9A46A]/40 rounded-lg text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <span>Inspect</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );

  if (isInlineView) {
    return content;
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex justify-center items-center p-4 overflow-y-auto">
      <div className="w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl">
        {content}
      </div>
    </div>
  );
}
