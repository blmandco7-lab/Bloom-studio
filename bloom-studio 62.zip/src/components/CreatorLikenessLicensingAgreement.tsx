/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, FileText, CheckCircle2, Loader2, X, AlertTriangle, Lock, Award, KeyRound } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { doc, setDoc, serverTimestamp, collection, addDoc } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';
import { recordAgreementInVault } from '../lib/cryptoSignatures';

interface CreatorLikenessLicensingAgreementProps {
  creatorId: string;
  creatorName: string;
  creatorHandle?: string;
  currentUser?: any;
  isOpen: boolean;
  onClose: () => void;
  onLicenseActivated: (licenseRecord: any) => void;
}

const CreatorLikenessLicensingAgreement: React.FC<CreatorLikenessLicensingAgreementProps> = ({
  creatorId,
  creatorName,
  creatorHandle,
  currentUser,
  isOpen,
  onClose,
  onLicenseActivated
}) => {
  const [signature, setSignature] = useState('');
  const [agreedToBiometricTerms, setAgreedToBiometricTerms] = useState(false);
  const [agreedToRoyaltyTerms, setAgreedToRoyaltyTerms] = useState(false);
  const [agreedToRevocationTerms, setAgreedToRevocationTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAccept = async () => {
    const trimmedSig = signature.trim();
    if (!trimmedSig) {
      setError('Please type your full legal name to execute the digital signature.');
      return;
    }

    if (!agreedToBiometricTerms || !agreedToRoyaltyTerms || !agreedToRevocationTerms) {
      setError('Please acknowledge and check all 3 legal compliance clauses below before signing.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const effectiveCreatorId = creatorId || currentUser?.uid || currentUser?.id || 'unknown';
    const effectiveCreatorName = creatorName || currentUser?.name || trimmedSig;
    const effectiveHandle = creatorHandle || currentUser?.handle || `@${effectiveCreatorName.toLowerCase().replace(/\s+/g, '')}`;
    const effectiveSubagency = currentUser?.subagency || 'pod_main';

    const licenseDocId = `${effectiveCreatorId}_likeness_license`;
    const timestampIso = new Date().toISOString();

    const licenseRecord = {
      id: licenseDocId,
      creatorId: effectiveCreatorId,
      creatorName: effectiveCreatorName,
      creatorHandle: effectiveHandle,
      signedBy: trimmedSig,
      signedAt: timestampIso,
      status: 'Active',
      version: '2026.1',
      biometricConsentGranted: true,
      subagency: effectiveSubagency,
      termsClauses: [
        'Clause A: Biometric Facial & Vocal Geometry Processing Grant',
        'Clause B: Flat-rate Escrow Compensation & Royalty Allocation',
        'Clause C: Perpetual Ownership & Real-time Revocation at Will'
      ],
      disclosureCompliance: 'FTC 16 CFR § 255.5 Synthetic Media Standard'
    };

    try {
      // 1. Try secure backend signature execution if token available
      let serverSuccess = false;
      try {
        const token = auth.currentUser ? await auth.currentUser.getIdToken() : null;
        if (token) {
          const resp = await fetch('/api/likeness/sign', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
              signature: trimmedSig,
              creatorId: effectiveCreatorId,
              creatorName: effectiveCreatorName,
              creatorHandle: effectiveHandle
            })
          });
          if (resp.ok) {
            serverSuccess = true;
          }
        }
      } catch (backendErr) {
        console.warn('Backend likeness sign fallback to direct Firestore:', backendErr);
      }

      // 2. Direct Firestore storage in studio-likeness-licenses
      if (!serverSuccess) {
        await setDoc(doc(db, 'studio-likeness-licenses', licenseDocId), licenseRecord, { merge: true });
        
        // Also update creator profile record
        try {
          await setDoc(doc(db, 'studio-creators', effectiveCreatorId), {
            likenessLicenseStatus: 'Active',
            likenessLicenseSignedBy: trimmedSig,
            likenessLicenseSignedAt: timestampIso,
            likenessConsentActive: true
          }, { merge: true });
        } catch (profileErr) {
          console.warn('Creator profile update note:', profileErr);
        }
      }

      // 3. Persist in safe storage for instant client-side authorization
      try {
        safeStorage.setItem(`likeness_license_${effectiveCreatorId}`, JSON.stringify(licenseRecord));
        safeStorage.setItem(`likeness_license_${effectiveHandle}`, JSON.stringify(licenseRecord));
        recordAgreementInVault({
          id: licenseDocId,
          documentType: 'AI Twin Likeness & Biometric Rights License',
          signerName: trimmedSig,
          signerEmail: currentUser?.email || `${effectiveHandle.replace('@', '')}@creator.com`,
          organization: `${effectiveCreatorName} Media`,
          signerRole: 'creator',
          isoTimestamp: timestampIso,
          formattedTimestamp: new Date(timestampIso).toLocaleString(),
          digest: `SHA256:LIKENESS_${effectiveCreatorId.toUpperCase()}_CONSENT`,
          clausesAccepted: [
            'Biometric Facial & Vocal Geometry Processing Grant',
            'Flat-rate Escrow Compensation & Royalty Allocation',
            'Perpetual Ownership & Real-time Revocation Rights'
          ]
        });
      } catch (e) {
        console.error(e);
      }

      onLicenseActivated(licenseRecord);
      onClose();
    } catch (err: any) {
      console.error('Licensing Execution Error:', err);
      setError(err?.message || 'Failed to record likeness license consent. Please check your connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-2xl bg-[#0B1B3D] border border-[#D4AF37]/40 rounded-3xl overflow-hidden shadow-2xl shadow-black/80 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 border-b border-white/10 bg-gradient-to-r from-[#142850] to-[#0B1B3D] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#D4AF37]/15 border border-[#D4AF37]/30 rounded-xl">
              <Shield className="w-6 h-6 text-[#D4AF37]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-[#D4AF37]">Creator Likeness Licensing</h2>
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono rounded-full font-semibold">Legal Binding</span>
              </div>
              <p className="text-xs text-[#7C8AA8]">Biometric Data Rights, FTC Compliance & Synthetic Twin Consent</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 text-[#7C8AA8] hover:text-white rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Legal Body */}
        <div className="p-6 md:p-8 space-y-6 overflow-y-auto custom-scrollbar flex-1">
          <div className="bg-[#142850] border border-white/10 rounded-2xl p-6 space-y-5 text-sm leading-relaxed text-[#B8C0D4]">
            <div className="flex items-start gap-3 pb-4 border-b border-white/5">
              <KeyRound className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-white font-medium">
                  This legally binding digital addendum grants Bloom Studio and verified brand partners express permission to synthesize and render UGC advertising content using your approved biometric likeness, facial vectors, and synthetic voice clone.
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-[#D4AF37] flex items-center gap-2 text-xs uppercase tracking-wider">
                <FileText className="w-4 h-4" /> Clause A: Biometric Likeness Grant
              </h4>
              <p className="text-xs text-[#9EACC7]">
                The Creator grants Bloom Studio a revocable, non-exclusive license to process their facial geometry, video imagery, and vocal voice prints strictly to generate synthetic digital campaign assets inside the approved campaign brief framework.
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-[#D4AF37] flex items-center gap-2 text-xs uppercase tracking-wider">
                <FileText className="w-4 h-4" /> Clause B: Escrow & Royalty Allocation
              </h4>
              <p className="text-xs text-[#9EACC7]">
                All campaign deliverables generated via the AI digital twin model shall clear and unlock compensation structures based strictly on the individual flat-rate escrow terms assigned to the creative brief. No assets may be commercialized without corresponding payout escrow.
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-[#D4AF37] flex items-center gap-2 text-xs uppercase tracking-wider">
                <FileText className="w-4 h-4" /> Clause C: Ownership & Real-Time Revocation at Will
              </h4>
              <p className="text-xs text-[#9EACC7]">
                The Creator perpetually retains 100% ownership of their biological likeness and may deactivate or revoke this authorization toggle at any time inside their creator portal, immediately pausing all future synthetic asset generations.
              </p>
            </div>

            <div className="pt-2 border-t border-white/5">
              <p className="text-[10px] text-[#7C8AA8] italic">
                Mandatory Transparency Standard: In accordance with FTC 16 CFR § 255.5, all outputs generated using synthetic twin pipelines are tagged with machine-readable authenticity metadata and require clear visual disclosure tags.
              </p>
            </div>
          </div>

          {/* Compliance Checkboxes */}
          <div className="space-y-3 bg-[#0D1830] border border-white/10 rounded-2xl p-4">
            <label className="flex items-start gap-3 cursor-pointer text-xs text-[#B8C0D4] select-none">
              <input
                type="checkbox"
                checked={agreedToBiometricTerms}
                onChange={(e) => setAgreedToBiometricTerms(e.target.checked)}
                className="mt-0.5 rounded border-white/20 bg-[#142850] text-[#D4AF37] focus:ring-[#D4AF37] h-4 w-4 shrink-0"
              />
              <span>I explicitly authorize the processing of my facial vectors and voice prints for synthetic twin UGC generation (Clause A).</span>
            </label>

            <label className="flex items-start gap-3 cursor-pointer text-xs text-[#B8C0D4] select-none">
              <input
                type="checkbox"
                checked={agreedToRoyaltyTerms}
                onChange={(e) => setAgreedToRoyaltyTerms(e.target.checked)}
                className="mt-0.5 rounded border-white/20 bg-[#142850] text-[#D4AF37] focus:ring-[#D4AF37] h-4 w-4 shrink-0"
              />
              <span>I confirm that all synthetic deliveries must adhere to campaign escrow payout agreements (Clause B).</span>
            </label>

            <label className="flex items-start gap-3 cursor-pointer text-xs text-[#B8C0D4] select-none">
              <input
                type="checkbox"
                checked={agreedToRevocationTerms}
                onChange={(e) => setAgreedToRevocationTerms(e.target.checked)}
                className="mt-0.5 rounded border-white/20 bg-[#142850] text-[#D4AF37] focus:ring-[#D4AF37] h-4 w-4 shrink-0"
              />
              <span>I understand that I retain full likeness ownership and can pause or revoke this consent at any time (Clause C).</span>
            </label>
          </div>

          {/* Signature Area */}
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-bold tracking-widest font-mono">
                  Digital Signature (Type Full Legal Name)
                </label>
                <span className="text-[10px] text-[#D4AF37] font-mono">Timestamped SHA-256</span>
              </div>
              <input
                type="text"
                value={signature}
                onChange={(e) => setSignature(e.target.value)}
                placeholder={creatorName || 'Your Full Legal Name'}
                className="w-full bg-[#142850] border border-white/10 rounded-2xl px-5 py-3.5 text-white placeholder:text-white/20 focus:border-[#D4AF37] outline-none transition-all shadow-inner font-serif text-base"
              />
            </div>

            {error && (
              <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl flex items-center gap-2 text-xs text-rose-300">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            <button
              onClick={handleAccept}
              disabled={isSubmitting || !signature.trim() || !agreedToBiometricTerms || !agreedToRoyaltyTerms || !agreedToRevocationTerms}
              className="w-full py-4 bg-gradient-to-r from-[#D4AF37] to-[#E5C378] hover:from-[#E5C378] hover:to-[#D4AF37] disabled:opacity-40 disabled:cursor-not-allowed text-[#0B1B3D] font-bold rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/15 cursor-pointer text-sm"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Recording Cryptographic Likeness License...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Execute Likeness License & Unlock AI Twin</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatorLikenessLicensingAgreement;
