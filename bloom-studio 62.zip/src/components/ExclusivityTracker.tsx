import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Lock,
  Unlock,
  AlertTriangle,
  CheckCircle2,
  Search,
  Plus,
  Trash2,
  Calendar,
  Building2,
  Users,
  Shield,
  ShieldCheck,
  Clock,
  Sparkles,
  Download,
  Filter,
  X,
  FileCheck,
  ArrowRight,
  Info
} from 'lucide-react';
import { Creator, Contract, Deal, Role } from '../types';
import { formatCsvRow, sanitizeCsvCell } from '../utils/security';
import { db } from '../lib/firebase';
import { collection, onSnapshot, doc, setDoc, deleteDoc, query, where } from 'firebase/firestore';
import { moveToTrash } from '../lib/trashService';
import { safeStorage } from '../utils/safeStorage';

export interface BrandExclusivityLock {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  brandName: string;
  category: string;
  exclusivityType: 'Exclusive Lockout' | 'Non-Exclusive' | 'Territory-Restricted' | 'First-Right-of-Refusal';
  blacklistedBrands: string; // e.g. "Adidas, Puma, Under Armour"
  scope: string; // e.g. "All Social Channels (TikTok, IG, YouTube)"
  startDate: string;
  endDate: string;
  dealValue?: string;
  notes?: string;
  status: 'Active' | 'Expiring Soon' | 'Expired';
  subagency?: string;
  createdAt?: string;
}

interface ExclusivityTrackerProps {
  creators: Creator[];
  contracts?: Contract[];
  deals?: Deal[];
  currentRole?: Role;
  currentUser?: any;
  isRestrictedRole?: boolean;
  onUpdateCreatorAgreement?: (creatorId: string, agreement: string, agreementType?: string, scope?: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (author: string, role: string, description: string) => void;
}

const DEFAULT_EXCLUSIVITY_LOCKS: BrandExclusivityLock[] = [
  {
    id: 'excl_1',
    creatorId: 'c_alex_jones',
    creatorName: 'Alex Jones',
    creatorHandle: '@alexjones',
    brandName: 'Nike',
    category: 'Athletic Footwear & Sportswear',
    exclusivityType: 'Exclusive Lockout',
    blacklistedBrands: 'Adidas, Puma, Under Armour, New Balance, Reebok, Lululemon',
    scope: 'All Social Feeds (TikTok, Instagram, YouTube Dedicated)',
    startDate: '2026-01-01',
    endDate: '2026-10-31',
    dealValue: '$28,000',
    notes: 'Q1-Q3 Global footwear exclusivity. No competing athletic shoe logos allowed in feed.',
    status: 'Active',
    subagency: 'pod_main'
  },
  {
    id: 'excl_2',
    creatorId: 'c_kayla_laurent',
    creatorName: 'Kayla Laurent',
    creatorHandle: '@kaylalooks',
    brandName: 'Glow Recipe',
    category: 'Skincare & Fruit-Powered Serums',
    exclusivityType: 'Exclusive Lockout',
    blacklistedBrands: 'Drunk Elephant, Sunday Riley, Summer Fridays, Laneige',
    scope: 'Short-Form Video (TikTok & Reels)',
    startDate: '2026-03-01',
    endDate: '2026-09-01',
    dealValue: '$15,500',
    notes: 'Hydration serum ambassador. 6-month competitive skincare non-compete window.',
    status: 'Active',
    subagency: 'pod_main'
  },
  {
    id: 'excl_3',
    creatorId: 'c_sophia_wells',
    creatorName: 'Sophia Wells',
    creatorHandle: '@shopwithsoph',
    brandName: 'Celsius Energy',
    category: 'Energy Drinks & Functional Beverages',
    exclusivityType: 'Exclusive Lockout',
    blacklistedBrands: 'Monster Energy, Red Bull, Prime, Alani Nu, Ghost Energy',
    scope: 'TikTok Dedicated & Sponsored Integration',
    startDate: '2026-02-15',
    endDate: '2026-08-30',
    dealValue: '$12,000',
    notes: 'Cannot feature or hold any competing beverage cans in workout or desk routine videos.',
    status: 'Active',
    subagency: 'pod_main'
  },
  {
    id: 'excl_4',
    creatorId: 'c_liam_sterling',
    creatorName: 'Liam Sterling',
    creatorHandle: '@liam_viral',
    brandName: 'NordVPN',
    category: 'Cybersecurity & VPN Software',
    exclusivityType: 'Non-Exclusive',
    blacklistedBrands: 'ExpressVPN (30-day window)',
    scope: 'YouTube Mid-Roll Ad Placements',
    startDate: '2026-05-01',
    endDate: '2026-08-15',
    dealValue: '$8,500',
    notes: 'Non-exclusive software sponsor. 30-day post-post blackout before running other VPN sponsors.',
    status: 'Expiring Soon',
    subagency: 'pod_main'
  }
];

export const ExclusivityTracker: React.FC<ExclusivityTrackerProps> = ({
  creators = [],
  contracts = [],
  deals = [],
  currentRole = 'director',
  currentUser,
  isRestrictedRole = false,
  onUpdateCreatorAgreement,
  triggerNotification,
  onAddActivityLog
}) => {
  const notify = triggerNotification || ((t: string, m: string) => console.log(t, m));

  // Role checks
  const isCreator = currentRole === 'creator' || currentUser?.role === 'creator';
  const myHandle = (currentUser?.handle || '').toLowerCase().replace('@', '').trim();
  const myPod = currentUser?.subagency || 'pod_main';

  // State
  const [locks, setLocks] = useState<BrandExclusivityLock[]>([]);
  const [activeTab, setActiveTab] = useState<'brand_locks' | 'conflict_checker' | 'roster_representation'>('brand_locks');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Modal State: Add Lock
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCreatorId, setNewCreatorId] = useState('');
  const [newBrandName, setNewBrandName] = useState('');
  const [newCategory, setNewCategory] = useState('Athletic Footwear & Sportswear');
  const [newExclusivityType, setNewExclusivityType] = useState<'Exclusive Lockout' | 'Non-Exclusive' | 'Territory-Restricted' | 'First-Right-of-Refusal'>('Exclusive Lockout');
  const [newBlacklistedBrands, setNewBlacklistedBrands] = useState('');
  const [newScope, setNewScope] = useState('All Social Channels (TikTok, IG, YouTube)');
  const [newStartDate, setNewStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [newEndDate, setNewEndDate] = useState(
    new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [newDealValue, setNewDealValue] = useState('$15,000');
  const [newNotes, setNewNotes] = useState('');

  // Modal State: Edit Creator Representation Agreement
  const [selectedCreatorForRep, setSelectedCreatorForRep] = useState<Creator | null>(null);
  const [repAgreementType, setRepAgreementType] = useState('Exclusive');
  const [repSplit, setRepSplit] = useState('80%');
  const [repScope, setRepScope] = useState('Full Commercial Representation');

  // Conflict Checker Tool State
  const [checkCreatorId, setCheckCreatorId] = useState('');
  const [checkBrandName, setCheckBrandName] = useState('');
  const [checkCategory, setCheckCategory] = useState('');
  const [checkResult, setCheckResult] = useState<{
    hasConflict: boolean;
    conflictingLocks: BrandExclusivityLock[];
    message: string;
    details: string[];
  } | null>(null);

  // Delete confirmation modal state
  const [deleteConfirmLock, setDeleteConfirmLock] = useState<BrandExclusivityLock | null>(null);

  // Automated Conflict Warning State during Add Lock
  const [detectedConflicts, setDetectedConflicts] = useState<BrandExclusivityLock[] | null>(null);
  const [overrideConflict, setOverrideConflict] = useState(false);

  // Firestore Real-time Subscription for studio-brand-exclusivity
  useEffect(() => {
    const isOwner = !!currentUser?.isPlatformOwner;
    const isStaffOrDirector = ['director', 'agentmgr', 'agency', 'subagency', 'owner'].includes((currentRole || '').toLowerCase());
    
    let baseQuery;
    if (isOwner) {
      baseQuery = collection(db, 'studio-brand-exclusivity');
    } else if (isStaffOrDirector) {
      baseQuery = query(
        collection(db, 'studio-brand-exclusivity'),
        where('subagency', '==', myPod)
      );
    } else {
      // Creator: Filter by creatorId or handle
      baseQuery = query(
        collection(db, 'studio-brand-exclusivity'),
        where('creatorId', '==', currentUser?.uid || currentUser?.id || 'none')
      );
    }

    const unsub = onSnapshot(
      baseQuery,
      (snapshot) => {
        if (snapshot.empty) {
          const alreadySeeded = safeStorage.getItem('bloom_excl_seeded_v2');
          if (!alreadySeeded) {
            safeStorage.setItem('bloom_excl_seeded_v2', 'true');
            DEFAULT_EXCLUSIVITY_LOCKS.forEach((d) => {
              const seededDoc = { ...d, subagency: myPod };
              setDoc(doc(db, 'studio-brand-exclusivity', d.id), seededDoc, { merge: true }).catch(() => {});
            });
            setLocks(DEFAULT_EXCLUSIVITY_LOCKS.map(d => ({ ...d, subagency: myPod })));
          } else {
            setLocks([]);
          }
        } else {
          safeStorage.setItem('bloom_excl_seeded_v2', 'true');
          const items: BrandExclusivityLock[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as BrandExclusivityLock;
            items.push({ ...data, id: docSnap.id });
          });
          setLocks(items);
        }
      },
      (err) => {
        console.warn('[ExclusivityTracker] Firestore subscription fallback:', err);
        setLocks(DEFAULT_EXCLUSIVITY_LOCKS);
      }
    );

    return () => unsub();
  }, [currentUser, currentRole, myPod]);

  // Filtered locks based on role & search
  const visibleLocks = useMemo(() => {
    return locks.filter((l) => {
      // Role scope
      if (isCreator && myHandle) {
        const creatorHandle = (l.creatorHandle || '').toLowerCase().replace('@', '');
        if (creatorHandle !== myHandle && !creatorHandle.includes(myHandle)) {
          return false;
        }
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          (l.creatorName || '').toLowerCase().includes(q) ||
          (l.creatorHandle || '').toLowerCase().includes(q) ||
          (l.brandName || '').toLowerCase().includes(q) ||
          (l.category || '').toLowerCase().includes(q) ||
          (l.blacklistedBrands || '').toLowerCase().includes(q);
        if (!match) return false;
      }

      // Category filter
      if (categoryFilter !== 'all' && l.category !== categoryFilter) {
        return false;
      }

      // Status filter
      if (statusFilter !== 'all') {
        const today = new Date().toISOString().split('T')[0];
        const isExp = l.endDate < today;
        const isSoon = !isExp && new Date(l.endDate).getTime() - Date.now() < 30 * 24 * 60 * 60 * 1000;
        
        if (statusFilter === 'Active' && (isExp || isSoon)) return false;
        if (statusFilter === 'Expiring Soon' && !isSoon) return false;
        if (statusFilter === 'Expired' && !isExp) return false;
      }

      return true;
    });
  }, [locks, isCreator, myHandle, searchQuery, categoryFilter, statusFilter]);

  // Unique categories for filter dropdown
  const uniqueCategories = useMemo(() => {
    const set = new Set<string>();
    locks.forEach((l) => {
      if (l.category) set.add(l.category);
    });
    return Array.from(set);
  }, [locks]);

  // Handler: Add New Brand Exclusivity Lock
  const handleSaveNewLock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBrandName.trim()) {
      notify('Missing Brand Name', 'Please enter the brand granting or requiring exclusivity.', 'warning');
      return;
    }

    const creator = creators.find((c) => c.id === newCreatorId) || creators[0];
    if (!creator && creators.length > 0) {
      notify('Missing Creator', 'Please select a creator from the roster.', 'warning');
      return;
    }

    // Automated Exclusivity Conflict Gate
    if (!overrideConflict && creator) {
      const today = new Date().toISOString().split('T')[0];
      const activeLocks = locks.filter((l) => {
        const matchCreator =
          l.creatorId === creator.id ||
          l.creatorHandle.toLowerCase().replace('@', '') === creator.handle.toLowerCase().replace('@', '') ||
          l.creatorName.toLowerCase() === creator.name.toLowerCase();
        const isActive = l.endDate >= today;
        return matchCreator && isActive;
      });

      const conflicts: BrandExclusivityLock[] = [];
      const catQuery = newCategory.trim().toLowerCase();
      const brandQuery = newBrandName.trim().toLowerCase();

      activeLocks.forEach((l) => {
        let isHit = false;
        const dateOverlap = !(l.endDate < newStartDate || l.startDate > newEndDate);
        if (dateOverlap && catQuery && (l.category.toLowerCase().includes(catQuery) || catQuery.includes(l.category.toLowerCase()))) {
          isHit = true;
        }
        if (dateOverlap && brandQuery && l.blacklistedBrands.toLowerCase().includes(brandQuery)) {
          isHit = true;
        }
        if (isHit && !conflicts.some((c) => c.id === l.id)) {
          conflicts.push(l);
        }
      });

      if (conflicts.length > 0) {
        setDetectedConflicts(conflicts);
        notify('Exclusivity Collision Detected!', `Active conflict with ${conflicts.map(c => c.brandName).join(', ')}. Review warning below before overriding.`, 'warning');
        return;
      }
    }

    const newId = 'excl_' + Date.now();
    const newLock: BrandExclusivityLock = {
      id: newId,
      creatorId: creator ? creator.id : 'custom',
      creatorName: creator ? creator.name : 'Roster Creator',
      creatorHandle: creator ? creator.handle : '@creator',
      brandName: newBrandName.trim(),
      category: newCategory,
      exclusivityType: newExclusivityType,
      blacklistedBrands: newBlacklistedBrands.trim() || 'Direct category competitors',
      scope: newScope,
      startDate: newStartDate,
      endDate: newEndDate,
      dealValue: newDealValue.trim(),
      notes: newNotes.trim(),
      status: newEndDate < new Date().toISOString().split('T')[0] ? 'Expired' : 'Active',
      subagency: myPod,
      createdAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'studio-brand-exclusivity', newId), newLock);
      setLocks((prev) => [newLock, ...prev]);
      setShowAddModal(false);
      setDetectedConflicts(null);
      setOverrideConflict(false);
      notify('Brand Exclusivity Logged', `Active category lockout recorded for ${newLock.creatorName} with ${newLock.brandName}.`, 'success');
      onAddActivityLog?.(
        currentUser?.name || 'Talent Agent',
        currentRole || 'agent',
        `Logged ${newLock.exclusivityType} lock for ${newLock.creatorName} (${newLock.brandName} - ${newLock.category})`
      );
      // Reset form
      setNewBrandName('');
      setNewBlacklistedBrands('');
      setNewNotes('');
    } catch (err) {
      console.error('Error saving brand lock:', err);
      notify('Save Failed', 'Could not save exclusivity lock to Firestore database.', 'danger');
    }
  };

  // Handler: Delete Lock
  const handleDeleteLock = (lock: BrandExclusivityLock) => {
    setDeleteConfirmLock(lock);
  };

  const executeDeleteLock = async (lock: BrandExclusivityLock) => {
    const lockId = lock.id;
    const brandName = lock.brandName;
    const creatorName = lock.creatorName;

    const lockObj = locks.find(l => l.id === lockId) || { id: lockId, brandName, creatorName, category: 'Brand Exclusivity Lock' };

    // Optimistically update local state
    setLocks((prev) => prev.filter((l) => l.id !== lockId));
    setDeleteConfirmLock(null);

    notify('Exclusivity Moved to Trash', `${brandName} blackout lock moved to 30-day Recoup Trash.`, 'info');
    onAddActivityLog?.(
      currentUser?.name || 'Talent Agent',
      (currentRole as string) || 'none',
      `Moved ${brandName} exclusivity lock for ${creatorName} to 30-day trash bin`
    );

    try {
      await moveToTrash('studio-brand-exclusivity', lockObj, 'exclusivity', currentUser);
    } catch (err) {
      console.error('Error moving brand lock to trash:', err);
    }
  };

  // Handler: Run Conflict Checker
  const handleRunConflictCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkCreatorId) {
      notify('Select Creator', 'Please select a creator to evaluate.', 'warning');
      return;
    }
    const targetCreator = creators.find((c) => c.id === checkCreatorId);
    if (!targetCreator) return;

    const brandQuery = checkBrandName.trim().toLowerCase();
    const categoryQuery = checkCategory.trim().toLowerCase();
    const today = new Date().toISOString().split('T')[0];

    // Check against active locks for this creator
    const creatorLocks = locks.filter((l) => {
      const matchCreator =
        l.creatorId === targetCreator.id ||
        l.creatorHandle.toLowerCase().replace('@', '') === targetCreator.handle.toLowerCase().replace('@', '') ||
        l.creatorName.toLowerCase() === targetCreator.name.toLowerCase();
      const isActive = l.endDate >= today;
      return matchCreator && isActive;
    });

    const conflicts: BrandExclusivityLock[] = [];
    const details: string[] = [];

    creatorLocks.forEach((l) => {
      let isHit = false;
      // Category match
      if (categoryQuery && l.category.toLowerCase().includes(categoryQuery)) {
        isHit = true;
        details.push(`Category collision: Already locked with ${l.brandName} for "${l.category}" until ${l.endDate}.`);
      }
      // Direct brand blacklist match
      if (brandQuery && l.blacklistedBrands.toLowerCase().includes(brandQuery)) {
        isHit = true;
        details.push(`Brand explicitly blacklisted by ${l.brandName} contract terms (Active through ${l.endDate}).`);
      }
      // Same brand active
      if (brandQuery && l.brandName.toLowerCase() === brandQuery) {
        details.push(`Existing partnership with ${l.brandName} is already on record.`);
      }

      if (isHit && !conflicts.some((c) => c.id === l.id)) {
        conflicts.push(l);
      }
    });

    if (conflicts.length > 0) {
      setCheckResult({
        hasConflict: true,
        conflictingLocks: conflicts,
        message: `⚠️ Exclusivity Collision Detected for ${targetCreator.name}!`,
        details
      });
    } else {
      setCheckResult({
        hasConflict: false,
        conflictingLocks: [],
        message: `✅ Cleared to Pitch: No Active Exclusivity Conflicts Found for ${targetCreator.name}.`,
        details: [
          `No active category lockouts or competitor blacklists found for "${checkBrandName || 'New Brand'}" (${checkCategory || 'Selected Category'}).`,
          `Creator representation agreement allows commercial sponsorships in this sector.`
        ]
      });
    }
  };

  // Handler: Save Creator Representation Update
  const handleSaveCreatorRep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCreatorForRep) return;

    const fullAgreementStr = `${repAgreementType} (${repSplit})`;
    onUpdateCreatorAgreement?.(selectedCreatorForRep.id, fullAgreementStr, repAgreementType, repScope);

    notify(
      'Representation Status Updated',
      `${selectedCreatorForRep.name} representation updated to ${fullAgreementStr}.`,
      'success'
    );
    onAddActivityLog?.(
      currentUser?.name || 'Talent Director',
      currentRole || 'none',
      `Updated ${selectedCreatorForRep.name} agency representation to ${fullAgreementStr} (${repScope})`
    );

    setSelectedCreatorForRep(null);
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['Creator Name', 'Creator Handle', 'Brand Name', 'Category', 'Exclusivity Type', 'Blacklisted Competitors', 'Scope', 'Start Date', 'End Date', 'Deal Value', 'Notes'];
    const rows = visibleLocks.map((l) => formatCsvRow([
      l.creatorName,
      l.creatorHandle,
      l.brandName,
      l.category,
      l.exclusivityType,
      l.blacklistedBrands,
      l.scope,
      l.startDate,
      l.endDate,
      l.dealValue || '',
      l.notes || ''
    ]));

    const csvContent = [headers.map(sanitizeCsvCell).join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `brand_exclusivity_matrix_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    notify('Exclusivity Matrix Exported', 'Downloaded brand deal exclusivity dataset as CSV.', 'success');
  };

  return (
    <div id="screen-exclusivity-tracker" className="space-y-6 max-w-7xl mx-auto p-4 sm:p-6 text-slate-100">
      {/* Header Banner */}
      <div className="bg-[#0A1220] border border-white/10 rounded-3xl p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-serif font-bold text-white tracking-tight">
                  Brand Deal Exclusivity Tracker &amp; Conflict Monitor
                </h1>
                <p className="text-xs text-[#7C8AA8] mt-0.5">
                  Track commercial brand non-competes, competitor blacklists (e.g. Nike vs Adidas), and verify category availability before booking new deals.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {!isCreator && (
              <button
                id="btn-add-exclusivity-lock"
                onClick={() => setShowAddModal(true)}
                className="px-4 py-2.5 bg-[#C9A46A] hover:bg-[#D8B47E] text-[#0A1220] font-bold text-xs rounded-xl shadow-lg flex items-center gap-2 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Log Brand Exclusivity Lock</span>
              </button>
            )}

            <button
              id="btn-export-exclusivity-csv"
              onClick={handleExportCSV}
              className="px-3.5 py-2.5 bg-[#111E33] hover:bg-[#16243F] text-slate-200 border border-white/10 text-xs font-semibold rounded-xl flex items-center gap-2 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Quick KPI Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/5">
          <div className="bg-[#0D1830]/80 border border-white/5 rounded-2xl p-4">
            <div className="text-xs text-[#7C8AA8] flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Active Brand Locks</span>
            </div>
            <div className="text-xl font-bold text-white font-mono mt-1">
              {locks.filter((l) => l.endDate >= new Date().toISOString().split('T')[0]).length}
            </div>
            <div className="text-[10px] text-emerald-400 mt-0.5">Protected partnerships</div>
          </div>

          <div className="bg-[#0D1830]/80 border border-white/5 rounded-2xl p-4">
            <div className="text-xs text-[#7C8AA8] flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>Expiring Soon (30d)</span>
            </div>
            <div className="text-xl font-bold text-amber-400 font-mono mt-1">
              {
                locks.filter((l) => {
                  const today = new Date().toISOString().split('T')[0];
                  const diff = new Date(l.endDate).getTime() - Date.now();
                  return l.endDate >= today && diff < 30 * 24 * 60 * 60 * 1000;
                }).length
              }
            </div>
            <div className="text-[10px] text-amber-400/80 mt-0.5">Ready for competitor pitch</div>
          </div>

          <div className="bg-[#0D1830]/80 border border-white/5 rounded-2xl p-4">
            <div className="text-xs text-[#7C8AA8] flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-sky-400" />
              <span>Blacklisted Competitors</span>
            </div>
            <div className="text-xl font-bold text-sky-300 font-mono mt-1">
              {
                locks.reduce((acc, l) => {
                  if (!l.blacklistedBrands) return acc;
                  return acc + l.blacklistedBrands.split(',').length;
                }, 0)
              }
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Competitor brands barred</div>
          </div>

          <div className="bg-[#0D1830]/80 border border-white/5 rounded-2xl p-4">
            <div className="text-xs text-[#7C8AA8] flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-purple-400" />
              <span>Exclusive Talent</span>
            </div>
            <div className="text-xl font-bold text-purple-300 font-mono mt-1">
              {creators.filter((c) => (c.agreement || '').toLowerCase().includes('exclusive') && !(c.agreement || '').toLowerCase().includes('non-')).length}
            </div>
            <div className="text-[10px] text-purple-400/80 mt-0.5">Agency exclusive roster</div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/5 pb-2">
        <div className="flex flex-wrap items-center gap-2">
          <button
            id="tab-excl-brand-locks"
            onClick={() => setActiveTab('brand_locks')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'brand_locks'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Brand Exclusivity Matrix ({visibleLocks.length})</span>
          </button>

          <button
            id="tab-excl-conflict-checker"
            onClick={() => setActiveTab('conflict_checker')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'conflict_checker'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Brand Conflict Simulator</span>
          </button>

          {!isCreator && (
            <button
              id="tab-excl-roster-representation"
              onClick={() => setActiveTab('roster_representation')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'roster_representation'
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                  : 'bg-[#0D1830] text-[#7C8AA8] hover:text-white border border-white/5'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Roster Agency Representation Status ({creators.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* TAB 1: BRAND DEAL EXCLUSIVITY MATRIX */}
      {activeTab === 'brand_locks' && (
        <div className="space-y-4">
          {/* Filter and Search Bar */}
          <div className="bg-[#0D1830] p-4 rounded-2xl border border-white/5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by creator, brand, category, or competitor blacklist..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              {/* Category Filter */}
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="all">All Categories ({locks.length})</option>
                {uniqueCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>

              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="all">All Statuses</option>
                <option value="Active">Active Lockout</option>
                <option value="Expiring Soon">Expiring Soon (30d)</option>
                <option value="Expired">Expired Blackout</option>
              </select>
            </div>
          </div>

          {/* Exclusivity Locks Table */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table id="table-brand-exclusivity" className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                    <th className="p-4 font-semibold">Creator</th>
                    <th className="p-4 font-semibold">Brand Partner</th>
                    <th className="p-4 font-semibold">Product Category &amp; Exclusivity Type</th>
                    <th className="p-4 font-semibold">Blacklisted Competitor Brands</th>
                    <th className="p-4 font-semibold">Active Window / Duration</th>
                    <th className="p-4 font-semibold">Status</th>
                    {!isCreator && <th className="p-4 font-semibold text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {visibleLocks.map((lock) => {
                    const today = new Date().toISOString().split('T')[0];
                    const isExpired = lock.endDate < today;
                    const isExpiringSoon = !isExpired && new Date(lock.endDate).getTime() - Date.now() < 30 * 24 * 60 * 60 * 1000;

                    return (
                      <tr key={lock.id} className="hover:bg-[#111E33]/40 transition-colors">
                        {/* Creator */}
                        <td className="p-4">
                          <div className="font-bold text-white text-sm">{lock.creatorName}</div>
                          <div className="text-xs text-[#C9A46A] font-mono mt-0.5">{lock.creatorHandle}</div>
                        </td>

                        {/* Brand */}
                        <td className="p-4">
                          <div className="font-bold text-white flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-amber-400" />
                            <span>{lock.brandName}</span>
                          </div>
                          {lock.dealValue && (
                            <div className="text-[11px] text-emerald-400 font-mono mt-0.5 font-semibold">
                              {lock.dealValue} Deal Value
                            </div>
                          )}
                        </td>

                        {/* Category & Type */}
                        <td className="p-4 max-w-xs">
                          <div className="font-semibold text-slate-200">{lock.category}</div>
                          <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold mt-1 bg-amber-950/80 border border-amber-500/30 text-amber-300">
                            <Lock className="w-2.5 h-2.5" />
                            <span>{lock.exclusivityType}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 mt-1">{lock.scope}</div>
                        </td>

                        {/* Blacklisted Competitor Brands */}
                        <td className="p-4 max-w-sm">
                          <div className="text-xs text-rose-300 font-medium bg-rose-950/30 border border-rose-500/20 rounded-xl p-2.5">
                            <span className="font-bold text-rose-400 uppercase text-[9px] tracking-wider block mb-1">
                              Blocked Competitors:
                            </span>
                            {lock.blacklistedBrands || 'Direct category competitors'}
                          </div>
                          {lock.notes && (
                            <div className="text-[10px] text-slate-400 italic mt-1.5">Note: {lock.notes}</div>
                          )}
                        </td>

                        {/* Active Window */}
                        <td className="p-4 font-mono text-xs text-slate-300">
                          <div className="flex items-center gap-1 text-slate-200">
                            <Calendar className="w-3.5 h-3.5 text-[#C9A46A]" />
                            <span>{lock.startDate}</span>
                            <ArrowRight className="w-3 h-3 text-slate-500" />
                            <span>{lock.endDate}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            {isExpired
                              ? 'Ended'
                              : `${Math.ceil((new Date(lock.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))} days remaining`}
                          </div>
                        </td>

                        {/* Status */}
                        <td className="p-4">
                          {isExpired ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                              Expired
                            </span>
                          ) : isExpiringSoon ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-950 text-amber-300 border border-amber-500/40 animate-pulse">
                              <Clock className="w-3 h-3" />
                              Expiring Soon
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                              <CheckCircle2 className="w-3 h-3" />
                              Active Lock
                            </span>
                          )}
                        </td>

                        {/* Actions */}
                        {!isCreator && (
                          <td className="p-4 text-right">
                            <button
                              id={`btn-delete-lock-${lock.id}`}
                              type="button"
                              onClick={() => handleDeleteLock(lock)}
                              className="p-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-lg transition-colors cursor-pointer"
                              title="Release / Delete Exclusivity Lock"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        )}
                      </tr>
                    );
                  })}

                  {visibleLocks.length === 0 && (
                    <tr>
                      <td colSpan={isCreator ? 6 : 7} className="p-12 text-center text-slate-400">
                        <Lock className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                        <p className="font-semibold text-white">No Brand Exclusivity Locks Found</p>
                        <p className="text-xs text-slate-500 mt-1">
                          No active brand deal blackout clauses match your search or filter criteria.
                        </p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BRAND CONFLICT SIMULATOR */}
      {activeTab === 'conflict_checker' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 bg-[#0D1830] border border-white/5 rounded-3xl p-6 space-y-4 shadow-xl">
            <div>
              <h3 className="text-base font-serif font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#C9A46A]" />
                <span>Test Brand Deal Conflict</span>
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-1">
                Before pitching a creator to a new sponsor, test their profile against all active category locks and competitor non-competes.
              </p>
            </div>

            <form onSubmit={handleRunConflictCheck} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Select Creator to Pitch *</label>
                <select
                  value={checkCreatorId}
                  onChange={(e) => setCheckCreatorId(e.target.value)}
                  required
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50 cursor-pointer"
                >
                  <option value="">-- Choose Creator from Roster --</option>
                  {creators.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.handle})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Target Prospect Brand *</label>
                <input
                  type="text"
                  placeholder="e.g. Puma, Adidas, Red Bull, Drunk Elephant, HelloFresh"
                  value={checkBrandName}
                  onChange={(e) => setCheckBrandName(e.target.value)}
                  required
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Brand Product Sector / Category</label>
                <input
                  type="text"
                  placeholder="e.g. Athletic Footwear, Energy Drinks, Skincare, Meal Kits"
                  value={checkCategory}
                  onChange={(e) => setCheckCategory(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              <button
                type="submit"
                id="btn-run-conflict-check"
                className="w-full bg-[#C9A46A] hover:bg-[#D8B47E] text-[#0A1220] py-3 rounded-xl font-bold text-xs shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Evaluate Exclusivity Collision</span>
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 space-y-4">
            <div className="bg-[#0D1830] border border-white/5 rounded-3xl p-6 shadow-xl min-h-[340px] flex flex-col justify-center">
              {checkResult ? (
                <div className="space-y-4">
                  <div
                    className={`p-4 rounded-2xl border flex items-start gap-3.5 ${
                      checkResult.hasConflict
                        ? 'bg-rose-950/40 border-rose-500/40 text-rose-200'
                        : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                    }`}
                  >
                    {checkResult.hasConflict ? (
                      <AlertTriangle className="w-6 h-6 text-rose-400 shrink-0 mt-0.5" />
                    ) : (
                      <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <h4 className="font-bold text-sm">{checkResult.message}</h4>
                      <ul className="mt-2 space-y-1 text-xs list-disc list-inside opacity-90">
                        {checkResult.details.map((d, i) => (
                          <li key={i}>{d}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {checkResult.conflictingLocks.length > 0 && (
                    <div className="space-y-2 mt-4">
                      <h5 className="text-xs font-mono uppercase tracking-wider text-[#7C8AA8] font-bold">
                        Conflicting Active Lockout Records:
                      </h5>
                      {checkResult.conflictingLocks.map((c) => (
                        <div
                          key={c.id}
                          className="bg-[#111E33] border border-rose-500/30 rounded-2xl p-4 text-xs space-y-1.5"
                        >
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-white">{c.brandName} Lockout</span>
                            <span className="font-mono text-amber-400 font-bold">{c.endDate} expiry</span>
                          </div>
                          <div className="text-slate-300">Category: {c.category}</div>
                          <div className="text-rose-300 font-mono text-[11px]">
                            Blacklist: {c.blacklistedBrands}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center text-slate-400 space-y-2 p-8">
                  <Sparkles className="w-10 h-10 mx-auto text-[#C9A46A]/40 animate-pulse" />
                  <h4 className="font-bold text-white text-sm">Awaiting Conflict Evaluation</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Select a creator and enter a target brand name on the left to verify if any active brand non-competes would be violated.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ROSTER AGENCY REPRESENTATION STATUS */}
      {activeTab === 'roster_representation' && !isCreator && (
        <div className="bg-[#0D1830] border border-white/5 rounded-3xl p-6 space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/5 pb-4">
            <div>
              <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400" />
                <span>Roster Representation &amp; Agency Exclusivity</span>
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-1">
                Track which creators are under exclusive management (100% agency-represented) vs non-exclusive / co-representation agreements.
              </p>
            </div>
            <div className="text-xs font-mono text-[#7C8AA8]">Total Roster: {creators.length} Creators</div>
          </div>

          <div className="overflow-x-auto">
            <table id="table-representation-matrix" className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                  <th className="p-4 font-semibold">Creator</th>
                  <th className="p-4 font-semibold">Agency Representation Model</th>
                  <th className="p-4 font-semibold">Commission Split</th>
                  <th className="p-4 font-semibold">Scope &amp; Territory</th>
                  <th className="p-4 font-semibold">Assigned Agent</th>
                  <th className="p-4 font-semibold text-right">Quick Edit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {creators.map((c) => {
                  const agreementText = c.agreement || 'Exclusive (80%)';
                  const isExcl =
                    agreementText.toLowerCase().includes('exclusive') &&
                    !agreementText.toLowerCase().includes('non-');
                  const isNonExcl = agreementText.toLowerCase().includes('non-exclusive');
                  const isOneTime =
                    agreementText.toLowerCase().includes('one-time') ||
                    agreementText.toLowerCase().includes('single');
                  const isCoRep = agreementText.toLowerCase().includes('co-');

                  return (
                    <tr key={c.id} className="hover:bg-[#111E33]/40 transition-colors">
                      <td className="p-4">
                        <div className="font-bold text-white text-sm">{c.name}</div>
                        <div className="text-xs text-[#C9A46A] font-mono mt-0.5">{c.handle}</div>
                      </td>

                      <td className="p-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold border ${
                            isExcl
                              ? 'bg-amber-950/80 border-amber-500/40 text-amber-300'
                              : isNonExcl
                              ? 'bg-sky-950/80 border-sky-500/40 text-sky-300'
                              : isOneTime
                              ? 'bg-purple-950/80 border-purple-500/40 text-purple-300'
                              : isCoRep
                              ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                              : 'bg-[#111E33] border-white/10 text-slate-300'
                          }`}
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>{isExcl ? 'Exclusive Agency Rep' : isNonExcl ? 'Non-Exclusive' : isOneTime ? 'One-Time Project' : isCoRep ? 'Co-Representation' : 'Custom'}</span>
                        </span>
                      </td>

                      <td className="p-4 font-mono font-bold text-emerald-400 text-xs">
                        {c.commissionSplit || agreementText.match(/\d+%/)?.[0] || '80/20'}
                      </td>

                      <td className="p-4 text-slate-300 text-xs max-w-xs">
                        {c.exclusivityScope || 'Full Commercial Brand Partnerships & Inquiries'}
                      </td>

                      <td className="p-4 font-mono text-amber-300 text-xs">
                        👤 {c.assignedAgent || 'Marcus Cole'}
                      </td>

                      <td className="p-4 text-right">
                        <button
                          id={`btn-edit-rep-${c.id}`}
                          onClick={() => {
                            setSelectedCreatorForRep(c);
                            setRepAgreementType(isExcl ? 'Exclusive' : isNonExcl ? 'Non-Exclusive' : isOneTime ? 'One-Time Deal' : 'Co-Representation');
                            setRepSplit(c.commissionSplit || '80%');
                            setRepScope(c.exclusivityScope || 'Full Commercial Representation');
                          }}
                          className="bg-[#111E33] hover:bg-[#16243F] text-[#C9A46A] border border-white/10 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
                        >
                          Update Status
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: ADD BRAND EXCLUSIVITY LOCK */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-white/10 rounded-3xl p-6 max-w-xl w-full space-y-4 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-serif font-bold text-white">Log Brand Deal Exclusivity Lock</h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewLock} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Select Creator *</label>
                <select
                  value={newCreatorId}
                  onChange={(e) => setNewCreatorId(e.target.value)}
                  required
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                >
                  {creators.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.handle})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-semibold">Brand Partner *</label>
                  <input
                    type="text"
                    placeholder="e.g. Nike, Celsius, Sephora"
                    value={newBrandName}
                    onChange={(e) => setNewBrandName(e.target.value)}
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-semibold">Deal Value (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. $25,000"
                    value={newDealValue}
                    onChange={(e) => setNewDealValue(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Product Sector / Category *</label>
                <input
                  type="text"
                  placeholder="e.g. Athletic Footwear & Apparel"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  required
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Blacklisted Competitor Brands *</label>
                <input
                  type="text"
                  placeholder="e.g. Adidas, Puma, Under Armour, New Balance"
                  value={newBlacklistedBrands}
                  onChange={(e) => setNewBlacklistedBrands(e.target.value)}
                  required
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
                <p className="text-[10px] text-slate-500">Comma-separated list of competitor brands blocked during this window.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-semibold">Exclusivity Start Date *</label>
                  <input
                    type="date"
                    value={newStartDate}
                    onChange={(e) => setNewStartDate(e.target.value)}
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#7C8AA8] font-semibold">Exclusivity End Date *</label>
                  <input
                    type="date"
                    value={newEndDate}
                    onChange={(e) => setNewEndDate(e.target.value)}
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Scope &amp; Channels</label>
                <input
                  type="text"
                  placeholder="e.g. All Social Feeds (TikTok, IG, YouTube)"
                  value={newScope}
                  onChange={(e) => setNewScope(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Contract Notes</label>
                <textarea
                  rows={2}
                  placeholder="Additional contractual terms or blackout conditions..."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              {detectedConflicts && detectedConflicts.length > 0 && (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 space-y-2 text-left">
                  <div className="flex items-center gap-2 text-amber-400 font-bold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>⚠️ Exclusivity Collision Detected!</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">
                    This creator has active commitments that overlap with your proposed dates and category:
                  </p>
                  <ul className="list-disc pl-4 text-[11px] text-amber-200 space-y-1">
                    {detectedConflicts.map(c => (
                      <li key={c.id}>
                        <strong>{c.brandName}</strong> ({c.category}) — Active through {c.endDate}
                      </li>
                    ))}
                  </ul>
                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 italic">Director override required to proceed with double-booking.</span>
                    <button
                      type="button"
                      onClick={() => {
                        setOverrideConflict(true);
                        setDetectedConflicts(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-[#070D18] font-bold text-[11px] transition shadow cursor-pointer"
                    >
                      Acknowledge & Force Override
                    </button>
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#111E33] text-slate-300 rounded-xl font-semibold hover:bg-[#16243F] transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C9A46A] text-[#0A1220] font-bold rounded-xl hover:bg-[#D8B47E] transition cursor-pointer shadow-md"
                >
                  Save Exclusivity Lock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT CREATOR REPRESENTATION AGREEMENT */}
      {selectedCreatorForRep && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-white/10 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-serif font-bold text-white">
                  Update Representation for {selectedCreatorForRep.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedCreatorForRep(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCreatorRep} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Representation Type</label>
                <select
                  value={repAgreementType}
                  onChange={(e) => setRepAgreementType(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                >
                  <option value="Exclusive">Exclusive Representation (Full Agency Management)</option>
                  <option value="Non-Exclusive">Non-Exclusive (Open Pitching &amp; Brand Sourcing)</option>
                  <option value="One-Time Deal">One-Time Project / Single Campaign</option>
                  <option value="Co-Representation">Co-Representation (Joint Management)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Commission Split (Creator %)</label>
                <input
                  type="text"
                  placeholder="e.g. 80% (or 70%, 85%)"
                  value={repSplit}
                  onChange={(e) => setRepSplit(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[#7C8AA8] font-semibold">Representation Scope</label>
                <input
                  type="text"
                  placeholder="e.g. Full Commercial Representation, TikTok Only"
                  value={repScope}
                  onChange={(e) => setRepScope(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setSelectedCreatorForRep(null)}
                  className="px-4 py-2 bg-[#111E33] text-slate-300 rounded-xl font-semibold hover:bg-[#16243F] transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C9A46A] text-[#0A1220] font-bold rounded-xl hover:bg-[#D8B47E] transition cursor-pointer shadow-md"
                >
                  Save Status
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CONFIRM RELEASE / DELETE BRAND EXCLUSIVITY LOCK */}
      {deleteConfirmLock && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-rose-500/40 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl relative">
            <div className="flex items-center gap-3 border-b border-white/10 pb-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Release Exclusivity Lock</h3>
                <p className="text-xs text-rose-300/80 font-mono mt-0.5">
                  {deleteConfirmLock.brandName} • {deleteConfirmLock.creatorName}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to release and permanently remove the <strong className="text-white">{deleteConfirmLock.brandName}</strong> category blackout lock for <strong className="text-amber-300">{deleteConfirmLock.creatorName}</strong> ({deleteConfirmLock.creatorHandle})?
            </p>

            <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 text-[11px] text-slate-400 space-y-1">
              <div><strong className="text-slate-300">Category:</strong> {deleteConfirmLock.category}</div>
              <div><strong className="text-slate-300">Blocked:</strong> {deleteConfirmLock.blacklistedBrands}</div>
              <div><strong className="text-slate-300">Window:</strong> {deleteConfirmLock.startDate} to {deleteConfirmLock.endDate}</div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button
                id="btn-cancel-delete-lock"
                type="button"
                onClick={() => setDeleteConfirmLock(null)}
                className="px-4 py-2 bg-[#111E33] text-slate-300 rounded-xl font-semibold hover:bg-[#16243F] transition cursor-pointer"
              >
                Keep Lock
              </button>
              <button
                id="btn-confirm-delete-lock"
                type="button"
                onClick={() => executeDeleteLock(deleteConfirmLock)}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl transition cursor-pointer shadow-lg shadow-rose-900/30 flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Lock</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExclusivityTracker;
