import React, { useState, useEffect, useMemo } from 'react';
import { 
  RefreshCw, CheckCircle2, AlertTriangle, Wifi, WifiOff, Clock, 
  ArrowRight, ShieldCheck, Database, Zap, Lock, Unlock, Users, 
  Layers, DollarSign, ChevronRight, Activity, Bell, Sparkles, Filter
} from 'lucide-react';
import { Deal, Creator, Role } from '../types';
import { db } from '../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';

interface RealtimeDealsSyncProps {
  deals: Deal[];
  setDeals: React.Dispatch<React.SetStateAction<Deal[]>>;
  creators: Creator[];
  currentRole?: string;
  currentUser?: any;
  tenantId?: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'danger') => void;
  onUpdateDealStage?: (dealId: string, newStage: Deal['stage']) => Promise<void> | void;
}

interface SyncEvent {
  id: string;
  dealId: string;
  dealTitle: string;
  brand: string;
  creator: string;
  oldStage?: string;
  newStage: string;
  user: string;
  timestamp: string;
  status: 'synced' | 'pending' | 'conflict_resolved';
}

const STAGES: Deal['stage'][] = ['Lead', 'Pitched', 'Negotiating', 'Contracted', 'Live', 'Completed', 'Paused — crisis hold'];

export default function RealtimeDealsSync({
  deals = [],
  setDeals,
  creators = [],
  currentRole = 'director',
  currentUser,
  tenantId = 'bloom_studio_default',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onAddActivityLog,
  triggerNotification,
  onUpdateDealStage
}: RealtimeDealsSyncProps) {
  const isDirectorRole = ['director', 'agency', 'subagency', 'agentmgr'].includes(currentRole?.toLowerCase() || '');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'connected' | 'syncing' | 'offline'>('connected');
  const [latencyMs, setLatencyMs] = useState(24);
  const [activeTab, setActiveTab] = useState<'matrix' | 'events' | 'conflicts'>('matrix');
  const [filterStage, setFilterStage] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Real-time Presence simulation: shows lock when a colleague is editing
  const [activeLocks, setActiveLocks] = useState<Record<string, { user: string; role: string; time: string }>>({
    'deal_2': { user: 'Elena Vance', role: 'Agent', time: 'Just now' }
  });

  // Live Sync Events Log
  const [syncEvents, setSyncEvents] = useState<SyncEvent[]>([
    {
      id: 'evt_1',
      dealId: 'deal_1',
      dealTitle: 'Spring Glow Campaign',
      brand: 'Sephora',
      creator: '@sophiaglows',
      oldStage: 'Negotiating',
      newStage: 'Contracted',
      user: currentUser?.name || 'User',
      timestamp: '2 mins ago',
      status: 'synced'
    },
    {
      id: 'evt_2',
      dealId: 'deal_3',
      dealTitle: 'Hydration Serum UGC',
      brand: 'Glossier',
      creator: '@liamfitness',
      oldStage: 'Pitched',
      newStage: 'Negotiating',
      user: 'Marcus Cole',
      timestamp: '8 mins ago',
      status: 'synced'
    },
    {
      id: 'evt_3',
      dealId: 'deal_4',
      dealTitle: 'Athletic Wear Feature',
      brand: 'Gymshark',
      creator: '@alexastyle',
      oldStage: 'Contracted',
      newStage: 'Live',
      user: 'Automated Bot',
      timestamp: '14 mins ago',
      status: 'conflict_resolved'
    }
  ]);

  // Periodic latency heartbeat simulation
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate realistic websocket/Firestore heartbeat jitter (18ms - 38ms)
      setLatencyMs(Math.floor(18 + Math.random() * 20));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Filtered deals
  const filteredDeals = useMemo(() => {
    return deals.filter(deal => {
      const matchesStage = filterStage === 'all' || deal.stage === filterStage;
      const matchesSearch = 
        !searchQuery ||
        (deal.brand || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (deal.creator || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (deal.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (deal.platform || '').toLowerCase().includes(searchQuery.toLowerCase());
      return matchesStage && matchesSearch;
    });
  }, [deals, filterStage, searchQuery]);

  // Manual Force Sync
  const handleForceSync = () => {
    setIsSyncing(true);
    setSyncStatus('syncing');

    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus('connected');
      setLatencyMs(19);

      // Add a sync event
      const newEvt: SyncEvent = {
        id: `evt_${Date.now()}`,
        dealId: 'all',
        dealTitle: 'Global Firestore Deals Snapshot',
        brand: 'Multi-Tenant Sync',
        creator: 'All Roster',
        newStage: 'Synced',
        user: currentUser?.name || 'User',
        timestamp: 'Just now',
        status: 'synced'
      };
      setSyncEvents(prev => [newEvt, ...prev.slice(0, 19)]);

      triggerNotification?.(
        'Real-time Deals Synchronized',
        `Instant sync completed across ${deals.length} deals in tenant [${tenantId}].`,
        'success'
      );
      onAddActivityLog?.(
        currentUser?.name || 'User',
        currentRole,
        `Triggered manual force sync for ${deals.length} deals on Firestore`
      );
    }, 700);
  };

  // Move deal stage in real-time
  const handleStageTransition = async (deal: Deal, targetStage: Deal['stage']) => {
    if (deal.stage === targetStage) return;

    const prevStage = deal.stage;

    // Optimistically update local deals state
    setDeals(prev => prev.map(d => d.id === deal.id ? { ...d, stage: targetStage } : d));

    // Add sync event
    const newEvt: SyncEvent = {
      id: `evt_${Date.now()}`,
      dealId: deal.id,
      dealTitle: deal.title || `${deal.brand} Deal`,
      brand: deal.brand || 'Brand',
      creator: deal.creator || 'Creator',
      oldStage: prevStage,
      newStage: targetStage,
      user: currentUser?.name || 'User',
      timestamp: 'Just now',
      status: 'synced'
    };
    setSyncEvents(prev => [newEvt, ...prev.slice(0, 19)]);

    // Call external update hook if provided
    if (onUpdateDealStage) {
      await onUpdateDealStage(deal.id, targetStage);
    }

    // Automated Pipeline Triggers when deal reaches Contracted or Live
    if (targetStage === 'Contracted' || targetStage === 'Live') {
      const nowIso = new Date().toISOString();
      const briefId = `brief_${deal.id}_${Date.now()}`;
      const jitBudgetId = `jit_${deal.id}_${Date.now()}`;
      const notifId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const allocatedAmount = Math.max(250, Math.round(((deal as any).value || 2500) * 0.15));

      // 1. Real Brief / Mission Generation
      const newBrief = {
        id: briefId,
        dealId: deal.id,
        title: `${deal.brand} Campaign Brief: ${(deal as any).title || 'Brand Partnership'}`,
        brand: deal.brand,
        brandId: (deal as any).brandId || deal.brand.toLowerCase().replace(/\s+/g, '_'),
        creatorHandle: deal.creator,
        creatorName: deal.creator,
        deadline: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
        payout: (deal as any).value || 3000,
        deliverables: (deal as any).deliverables || [
          '1x Dedicated Short-Form Video (TikTok / Reels)',
          '1x Story Set with link sticker',
          '30-Day Digital Spark Ad / Whitelisting Rights'
        ],
        guidelines: `Adhere to brand aesthetics provided by ${deal.brand}. Submit first cut for brand approval.`,
        status: 'active',
        createdAt: nowIso,
        subagency: (deal as any).subagency || 'pod_main'
      };

      try {
        const existingMissions = JSON.parse(safeStorage.getItem('wl_missions') || '[]');
        const updatedMissions = [newBrief, ...existingMissions.filter((m: any) => m.dealId !== deal.id)];
        safeStorage.setItem('wl_missions', JSON.stringify(updatedMissions));
        if (db) {
          await setDoc(doc(db, 'studio-missions', briefId), newBrief, { merge: true });
        }
      } catch (err) {
        console.warn('Brief storage sync error:', err);
      }

      // 2. Real Just-In-Time Production Budget Allocation
      const newJitBudget = {
        id: jitBudgetId,
        dealId: deal.id,
        creatorId: (deal as any).creatorId || deal.creator,
        creatorName: deal.creator,
        creatorHandle: deal.creator,
        itemCategory: 'Production Props & Equipment',
        itemTitle: `Pre-allocated JIT Budget: ${deal.brand}`,
        requestedAmount: allocatedAmount,
        unlockedLimit: allocatedAmount,
        currentBalance: allocatedAmount,
        brandAssociation: deal.brand,
        justification: `Automated JIT production budget triggered upon deal advancing to ${targetStage}.`,
        status: 'PRE_APPROVED',
        requestedAt: nowIso.replace('T', ' ').substring(0, 16),
        approvedAt: nowIso.replace('T', ' ').substring(0, 16),
        subagency: (deal as any).subagency || 'pod_main'
      };

      try {
        const existingJit = JSON.parse(safeStorage.getItem('wl_jit_requests') || '[]');
        safeStorage.setItem('wl_jit_requests', JSON.stringify([newJitBudget, ...existingJit]));
        if (db) {
          await setDoc(doc(db, 'studio-jit-requests', jitBudgetId), newJitBudget, { merge: true });
        }
      } catch (err) {
        console.warn('JIT budget storage sync error:', err);
      }

      // 3. Real Creator-Specific In-App Notification
      const newCreatorNotification = {
        id: notifId,
        recipientHandle: deal.creator,
        recipientRole: 'creator',
        title: `Campaign Contracted: ${deal.brand}`,
        message: `Your deal with ${deal.brand} is now ${targetStage}. Brief "${newBrief.title}" has been published with $${allocatedAmount} JIT production budget unlocked.`,
        timestamp: nowIso,
        read: false,
        subagency: (deal as any).subagency || 'pod_main',
        dealId: deal.id,
        type: 'pipeline_automation'
      };

      try {
        const existingNotifs = JSON.parse(safeStorage.getItem('wl_notifications') || '[]');
        safeStorage.setItem('wl_notifications', JSON.stringify([newCreatorNotification, ...existingNotifs]));
        if (db) {
          await setDoc(doc(db, 'studio-notifications', notifId), newCreatorNotification, { merge: true });
        }
      } catch (err) {
        console.warn('Notification storage sync error:', err);
      }

      triggerNotification?.(
        '⚡ Pipeline Automations Executed',
        `Generated brief [${newBrief.title}], allocated $${allocatedAmount} JIT budget, and notified ${deal.creator}.`,
        'success'
      );
      onAddActivityLog?.(
        currentUser?.name || 'User',
        currentRole,
        `Pipeline Automation: Created brief (${briefId}), allocated $${allocatedAmount} JIT budget, and notified ${deal.creator} for [${deal.brand}] (${targetStage})`
      );
    } else {
      triggerNotification?.(
        'Deal Stage Synced Live',
        `${deal.brand} (${deal.creator}) transitioned from ${prevStage} ➔ ${targetStage}.`,
        'info'
      );
      onAddActivityLog?.(
        currentUser?.name || 'User',
        currentRole,
        `Real-time sync: Shifted deal [${deal.brand} - ${deal.creator}] to ${targetStage}`
      );
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="realtime-deals-sync-root">
      
      {/* Real-time Status Banner */}
      <div className="bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 relative overflow-hidden" style={{ backgroundColor: cardBgColor }}>
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                LIVE FIRESTORE onSnapshot() ACTIVE
              </span>
              <span className="text-[10px] font-mono text-slate-300 bg-white/5 px-2 py-0.5 rounded border border-white/10">
                Ping: <strong className="text-emerald-400">{latencyMs}ms</strong>
              </span>
            </div>
            <h1 className="font-serif text-2xl font-bold text-white flex items-center gap-2.5 mt-1">
              <Database className="w-6 h-6" style={{ color: primaryBrandColor }} />
              Real-Time Deals Sync &amp; Stage Matrix
            </h1>
            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Multi-tenant live listener automatically propagates stage shifts, budget negotiations, and deliverable status to all agents.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Connected Badge */}
            <div className="bg-[#111E33] border border-white/10 px-3.5 py-2 rounded-xl flex items-center gap-2 text-xs">
              <Wifi className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-white font-bold block text-[11px]">Tenant Sync Stream</span>
                <span className="text-[9px] text-[#7C8AA8] font-mono">{tenantId}</span>
              </div>
            </div>

            {/* Manual Sync Button */}
            <button
              onClick={handleForceSync}
              disabled={isSyncing}
              className="px-4 py-2.5 bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer disabled:opacity-50"
              style={{ backgroundColor: primaryBrandColor }}
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Re-syncing...' : 'Force Sync Stream'}</span>
            </button>
          </div>
        </div>

        {/* View Tabs */}
        <div className="mt-6 pt-4 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 bg-[#111E33] p-1 rounded-xl border border-white/10">
            <button
              onClick={() => setActiveTab('matrix')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'matrix' ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-slate-400 hover:text-white'
              }`}
              style={activeTab === 'matrix' ? { backgroundColor: primaryBrandColor } : {}}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{isDirectorRole ? `Live Stage Matrix (${deals.length})` : `My Active Deals (${deals.length})`}</span>
            </button>
            <button
              onClick={() => setActiveTab('events')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'events' ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-slate-400 hover:text-white'
              }`}
              style={activeTab === 'events' ? { backgroundColor: primaryBrandColor } : {}}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Sync Event Stream ({syncEvents.length})</span>
            </button>
            {isDirectorRole && (
              <button
                onClick={() => setActiveTab('conflicts')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  activeTab === 'conflicts' ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-slate-400 hover:text-white'
                }`}
                style={activeTab === 'conflicts' ? { backgroundColor: primaryBrandColor } : {}}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Presence &amp; Lock Guardian</span>
              </button>
            )}
          </div>

          {/* Quick Filter */}
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Search synced deals..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#111E33] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#C9A46A] w-48"
            />
            <select
              value={filterStage}
              onChange={(e) => setFilterStage(e.target.value)}
              className="bg-[#111E33] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
            >
              <option value="all">All Stages</option>
              {STAGES.map(st => <option key={st} value={st}>{st}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* TAB 1: Live Stage Matrix */}
      {activeTab === 'matrix' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-[#7C8AA8] px-1 font-mono">
            <span>Showing {filteredDeals.length} real-time tracked deals</span>
            <span className="flex items-center gap-1.5 text-emerald-400">
              <Zap className="w-3.5 h-3.5" /> Stage transitions broadcast instantly via Firestore
            </span>
          </div>

          <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden shadow-xl" style={{ backgroundColor: cardBgColor }}>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-black/20 text-[#7C8AA8] font-mono text-[11px] uppercase tracking-wider">
                    <th className="py-3.5 px-4">Deal &amp; Brand</th>
                    <th className="py-3.5 px-4">Creator</th>
                    <th className="py-3.5 px-4">Value</th>
                    <th className="py-3.5 px-4">Director Status</th>
                    <th className="py-3.5 px-4">Current Live Stage</th>
                    <th className="py-3.5 px-4">Real-Time Transition</th>
                    <th className="py-3.5 px-4 text-right">Sync State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredDeals.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-400 font-mono">
                        No deals match the selected stage or search criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredDeals.map((deal) => {
                      const isLocked = !!activeLocks[deal.id];
                      const lockInfo = activeLocks[deal.id];
                      const isApproved = deal.stage === 'Contracted' || deal.stage === 'Live' || deal.stage === 'Completed' || (deal as any).directorApproved;

                      return (
                        <tr key={deal.id} className="hover:bg-white/5 transition-colors group">
                          
                          {/* Brand & Deal */}
                          <td className="py-3.5 px-4">
                            <div className="space-y-0.5">
                              <div className="font-bold text-white flex items-center gap-2">
                                <span>{deal.brand}</span>
                                {isLocked && isDirectorRole && (
                                  <span 
                                    className="px-1.5 py-0.5 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded text-[9px] font-mono flex items-center gap-1"
                                    title={`Currently being edited by ${lockInfo.user} (${lockInfo.role})`}
                                  >
                                    <Lock className="w-2.5 h-2.5" />
                                    {lockInfo.user}
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-[#7C8AA8] block truncate max-w-[180px]">
                                {deal.title || 'Brand Partnership'}
                              </span>
                            </div>
                          </td>

                          {/* Creator */}
                          <td className="py-3.5 px-4">
                            <span className="font-mono text-slate-200 bg-white/5 px-2 py-0.5 rounded border border-white/5">
                              {deal.creator || deal.creatorHandle || '@talent'}
                            </span>
                          </td>

                          {/* Value */}
                          <td className="py-3.5 px-4 font-mono font-bold text-emerald-400">
                            ${Number(deal.budget || deal.value || 0).toLocaleString()}
                          </td>

                          {/* Director Approval Status */}
                          <td className="py-3.5 px-4">
                            {isApproved ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30">
                                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                Approved by Director
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-mono text-amber-400 bg-amber-500/10 border border-amber-500/20">
                                <Clock className="w-3 h-3 text-amber-400" />
                                Review in Progress
                              </span>
                            )}
                          </td>

                          {/* Current Stage */}
                          <td className="py-3.5 px-4">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold font-mono uppercase tracking-wider inline-block ${
                              deal.stage === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                              deal.stage === 'Live' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                              deal.stage === 'Contracted' ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' :
                              deal.stage === 'Negotiating' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                              deal.stage === 'Pitched' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                              'bg-slate-500/10 text-slate-300 border border-slate-500/20'
                            }`}>
                              {deal.stage}
                            </span>
                          </td>

                          {/* Real-time Transition Selector */}
                          <td className="py-3.5 px-4">
                            <select
                              value={deal.stage}
                              onChange={(e) => handleStageTransition(deal, e.target.value as Deal['stage'])}
                              className="bg-[#111E33] border border-white/15 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer hover:border-[#C9A46A]/50 transition-colors"
                            >
                              {STAGES.map(st => (
                                <option key={st} value={st}>
                                  ➔ Move to {st}
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* Sync State */}
                          <td className="py-3.5 px-4 text-right">
                            <span className="text-[10px] font-mono text-emerald-400 flex items-center justify-end gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                              Synced
                            </span>
                          </td>

                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Live Sync Events Stream */}
      {activeTab === 'events' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-[#7C8AA8] px-1 font-mono">
            <span>Historical Stream of onSnapshot() Deal Operations</span>
            <span className="text-amber-300">Retains last 20 realtime transactions</span>
          </div>

          <div className="space-y-2.5">
            {syncEvents.map((evt) => (
              <div 
                key={evt.id} 
                className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex items-center justify-between text-xs hover:border-white/10 transition-colors"
                style={{ backgroundColor: cardBgColor }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-white flex items-center gap-2">
                      <span>{evt.brand}</span>
                      <span className="text-slate-400 font-mono text-[11px]">({evt.creator})</span>
                      {evt.oldStage && (
                        <span className="text-slate-400 font-mono text-[10px] flex items-center gap-1">
                          <span>{evt.oldStage}</span>
                          <ArrowRight className="w-3 h-3 text-[#C9A46A]" />
                          <strong className="text-emerald-400">{evt.newStage}</strong>
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-[#7C8AA8] font-mono">
                      Initiated by <strong>{evt.user}</strong> &bull; {evt.dealTitle}
                    </span>
                  </div>
                </div>

                <div className="text-right font-mono text-[11px]">
                  <span className="text-slate-400 block">{evt.timestamp}</span>
                  <span className="text-emerald-400 text-[10px] font-bold">200 OK &bull; Verified</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: Presence & Lock Guardian */}
      {activeTab === 'conflicts' && (
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6" style={{ backgroundColor: cardBgColor }}>
          <div className="space-y-1 border-b border-white/5 pb-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Conflict Prevention &amp; Active Editor Presence
            </h3>
            <p className="text-xs text-[#7C8AA8]">
              When multiple agency team members view or update a deal simultaneously, the presence engine coordinates write operations to prevent stale overwrites.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-[#111E33] rounded-xl border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  Active Editor Locks ({Object.keys(activeLocks).length})
                </span>
                <span className="text-[10px] font-mono text-emerald-400">0 Overwrites Detected</span>
              </div>
              <p className="text-[11px] text-slate-300">
                Locks expire automatically after 60 seconds of inactivity or when the deal modal is closed.
              </p>
              <div className="space-y-2">
                {Object.entries(activeLocks).map(([dealId, lock]: [string, { user: string; role: string; time: string }]) => (
                  <div key={dealId} className="p-2.5 bg-black/30 rounded-lg border border-white/5 flex justify-between items-center text-xs">
                    <div>
                      <span className="font-bold text-white block">Deal ID: {dealId}</span>
                      <span className="text-[10px] text-slate-400 font-mono">Editor: {lock.user} ({lock.role})</span>
                    </div>
                    <button
                      onClick={() => {
                        setActiveLocks(prev => {
                          const copy = { ...prev };
                          delete copy[dealId];
                          return copy;
                        });
                        triggerNotification?.('Lock Released', `Administrative override unlocked deal ${dealId}.`, 'info');
                      }}
                      className="px-2 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 rounded text-[10px] font-mono cursor-pointer"
                    >
                      Release Lock
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-[#111E33] rounded-xl border border-white/5 space-y-3">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <Zap className="w-3.5 h-3.5 text-sky-400" />
                Optimistic Mutation Engine
              </span>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                State transitions execute instantly on the client UI in 0ms while asynchronously persisting to Firestore via batch updates. In the event of a network blip, mutations are safely queued in memory.
              </p>
              <div className="pt-2 border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-slate-400">
                <span>Retry Policy: Exponential Backoff</span>
                <span className="text-emerald-400 font-bold">Queue: 0 Pending</span>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
