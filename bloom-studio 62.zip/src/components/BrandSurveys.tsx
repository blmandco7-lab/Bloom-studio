import React, { useState } from 'react';
import { Award, CheckCircle, Star, BarChart, FileText, Send, ShieldAlert, Heart, MessageSquare, PlusCircle, X, Globe, Mail, Phone, Upload, PenTool, Sparkles, Filter } from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';

export interface BrandSurvey {
  id: string;
  brand: string;
  campaignName: string;
  creator: string;
  npsScore: number; // 0-10
  rating: number; // 1-5
  feedbackText: string;
  q1Rating: number;
  q2Rating: number;
  q3Rating: number;
  q4Rating: number;
  q5Rating: number;
  submittedAt: string;
  source?: string;
  loggedBy?: string;
}

const DEFAULT_SURVEYS: BrandSurvey[] = [
  {
    id: 'srv_sephora_01',
    brand: 'Sephora USA',
    campaignName: 'Fall Glow Beauty Drop',
    creator: '@partner_creator',
    npsScore: 10,
    rating: 5,
    q1Rating: 5,
    q2Rating: 5,
    q3Rating: 5,
    q4Rating: 5,
    q5Rating: 5,
    feedbackText: 'Exceptional content quality and fast turnaround on revisions. The video achieved a 4.2x engagement benchmark across Tiktok & Instagram Reels.',
    submittedAt: '09/18/2026',
    source: 'External Email Feedback',
    loggedBy: 'Agency Director'
  },
  {
    id: 'srv_loreal_02',
    brand: "L'Oréal Luxe",
    campaignName: 'Radiance Serum Launch',
    creator: '@roster_partner',
    npsScore: 9,
    rating: 5,
    q1Rating: 5,
    q2Rating: 4,
    q3Rating: 5,
    q4Rating: 5,
    q5Rating: 5,
    feedbackText: 'Strong alignment with luxury aesthetic guidelines. Highly recommend continuing this talent partnership into Q4.',
    submittedAt: '09/12/2026',
    source: 'Executive Call / Meeting',
    loggedBy: 'Agency Director'
  },
  {
    id: 'srv_gymshark_03',
    brand: 'Gymshark',
    campaignName: 'Performance Apparel Push',
    creator: '@studio_talent',
    npsScore: 8,
    rating: 4,
    q1Rating: 4,
    q2Rating: 5,
    q3Rating: 4,
    q4Rating: 4,
    q5Rating: 4,
    feedbackText: 'High conversion rate on discount codes provided. Minor delay on 2nd revision but overall great deliverable compliance.',
    submittedAt: '09/05/2026',
    source: 'Post-Campaign PDF Survey',
    loggedBy: 'Agency Director'
  }
];

interface BrandSurveysProps {
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentUser?: any;
  currentRole?: string;
}

export default function BrandSurveys({ onAddActivityLog, triggerNotification, currentUser, currentRole = 'director' }: BrandSurveysProps) {
  // Load surveys from safeStorage with initial fallback seed
  const [surveys, setSurveys] = useState<BrandSurvey[]>(() => {
    try {
      const saved = safeStorage.getItem('bloom_brand_surveys');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading surveys from safeStorage:', e);
    }
    return DEFAULT_SURVEYS;
  });

  const saveSurveysToStorage = (updatedSurveys: BrandSurvey[]) => {
    setSurveys(updatedSurveys);
    try {
      safeStorage.setItem('bloom_brand_surveys', JSON.stringify(updatedSurveys));
    } catch (e) {
      console.error('Error saving surveys to safeStorage:', e);
    }
  };

  // Director External Survey Modal State
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [extBrand, setExtBrand] = useState('');
  const [extCampaign, setExtCampaign] = useState('');
  const [extCreator, setExtCreator] = useState('@partner_creator');
  const [extSource, setExtSource] = useState('External Email / Client Note');
  const [extRating, setExtRating] = useState(5);
  const [extNps, setExtNps] = useState(10);
  const [extQ1, setExtQ1] = useState(5);
  const [extQ2, setExtQ2] = useState(5);
  const [extQ3, setExtQ3] = useState(5);
  const [extQ4, setExtQ4] = useState(5);
  const [extQ5, setExtQ5] = useState(5);
  const [extFeedback, setExtFeedback] = useState('');
  const [extNotes, setExtNotes] = useState('');

  // Brand Feedback Form State
  const [campaignName, setCampaignName] = useState('');
  const [selectedCreator, setSelectedCreator] = useState('@partner_creator');
  const [q1, setQ1] = useState(5); // Creative alignment
  const [q2, setQ2] = useState(5); // Deliverable compliance
  const [q3, setQ3] = useState(5); // Professionalism
  const [q4, setQ4] = useState(5); // Audience Resonance
  const [q5, setQ5] = useState(5); // Agency recommendation
  const [feedbackText, setFeedbackText] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!campaignName || !feedbackText) return;

    // Calculate a consolidated rating and mock NPS
    const avgRating = Math.round((q1 + q2 + q3 + q4 + q5) / 5);
    const calculatedNps = q5 === 5 ? 10 : q5 === 4 ? 8 : q5 === 3 ? 6 : q5 === 2 ? 4 : 2;

    const newSurvey: BrandSurvey = {
      id: 'srv_' + Date.now(),
      brand: currentUser?.name || 'DripRoom',
      campaignName,
      creator: selectedCreator,
      npsScore: calculatedNps,
      rating: avgRating,
      q1Rating: q1,
      q2Rating: q2,
      q3Rating: q3,
      q4Rating: q4,
      q5Rating: q5,
      feedbackText,
      submittedAt: new Date().toLocaleDateString(),
      source: 'Direct Brand Portal Portal Submission'
    };

    saveSurveysToStorage([newSurvey, ...surveys]);
    setIsSubmitted(true);

    if (triggerNotification) {
      triggerNotification(
        "📊 Feedback Logged",
        "Your campaign feedback has been securely routed directly to the Agency Director.",
        "success"
      );
    }

    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || "Brand Partner",
        "brand",
        `Submitted structured campaign feedback for "${campaignName}"`
      );
    }
  };

  const handleSaveExternalSurvey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!extBrand.trim() || !extCampaign.trim() || !extFeedback.trim()) return;

    const finalFeedback = extNotes.trim() 
      ? `${extFeedback.trim()}\n\n[Director Internal Notes]: ${extNotes.trim()}`
      : extFeedback.trim();

    const newSurvey: BrandSurvey = {
      id: 'srv_ext_' + Date.now(),
      brand: extBrand.trim(),
      campaignName: extCampaign.trim(),
      creator: extCreator.trim() || '@partner_creator',
      npsScore: Number(extNps),
      rating: Number(extRating),
      q1Rating: Number(extQ1),
      q2Rating: Number(extQ2),
      q3Rating: Number(extQ3),
      q4Rating: Number(extQ4),
      q5Rating: Number(extQ5),
      feedbackText: finalFeedback,
      submittedAt: new Date().toLocaleDateString(),
      source: extSource || 'Director External Entry',
      loggedBy: currentUser?.name || 'Agency Director'
    };

    saveSurveysToStorage([newSurvey, ...surveys]);
    setIsLogModalOpen(false);

    // Reset external form
    setExtBrand('');
    setExtCampaign('');
    setExtCreator('@partner_creator');
    setExtSource('External Email / Client Note');
    setExtRating(5);
    setExtNps(10);
    setExtQ1(5);
    setExtQ2(5);
    setExtQ3(5);
    setExtQ4(5);
    setExtQ5(5);
    setExtFeedback('');
    setExtNotes('');

    if (triggerNotification) {
      triggerNotification(
        "External Survey Logged",
        `Successfully logged external survey for ${newSurvey.brand} (${newSurvey.campaignName}).`,
        "success"
      );
    }

    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || "Agency Director",
        "director",
        `Logged external brand survey from ${newSurvey.brand} via ${extSource}`
      );
    }
  };

  const handleResetForm = () => {
    setCampaignName('');
    setSelectedCreator('@alexjones');
    setQ1(5);
    setQ2(5);
    setQ3(5);
    setQ4(5);
    setQ5(5);
    setFeedbackText('');
    setIsSubmitted(false);
  };

  // Calculations for Director overview
  const totalCount = surveys.length;
  const promoters = surveys.filter(s => s.npsScore >= 9).length;
  const detractors = surveys.filter(s => s.npsScore <= 6).length;
  const nps = totalCount > 0 ? Math.round(((promoters - detractors) / totalCount) * 100) : 0;
  const averageRating = totalCount > 0 
    ? (surveys.reduce((sum, s) => sum + s.rating, 0) / totalCount).toFixed(1) 
    : '5.0';

  const isDirector = currentRole === 'director';

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden">
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider font-mono">
              {isDirector ? "Quality Assurance Operations" : "Secure Direct Liaison Feedback"}
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              {isDirector ? "Brand Satisfaction Surveys" : "Brand Feedback to Director"}
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed max-w-3xl">
              {isDirector 
                ? "Monitor brand partner satisfaction metrics, Net Promoter Scores (NPS), and campaign feedback reviews to ensure highest service delivery. Use the button on the right to log external feedback or offline surveys."
                : "This feedback portal routes your satisfaction indicators directly to the Agency Director's personal workspace. Outside roster talent cannot intercept these replies."}
            </p>
          </div>

          {isDirector && (
            <button
              type="button"
              onClick={() => setIsLogModalOpen(true)}
              className="inline-flex items-center gap-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-4.5 py-3 rounded-xl text-xs transition shadow-xl shrink-0 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Log External Survey</span>
            </button>
          )}
        </div>
      </div>

      {isDirector ? (
        /* ==================== DIRECTOR VIEW ==================== */
        <>
          {/* KPI Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-[#C9A46A]/10 text-[#C9A46A] rounded-xl">
                <BarChart className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase block">Net Promoter Score (NPS)</span>
                <span className="text-xl font-bold text-emerald-400">+{nps} %</span>
              </div>
            </div>

            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <Star className="w-5 h-5" fill="#10B981" />
              </div>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase block">Average Campaign Rating</span>
                <span className="text-xl font-bold text-white">{averageRating} / 5.0 Stars</span>
              </div>
            </div>

            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase block">Completed Reviews</span>
                <span className="text-xl font-bold text-cyan-400">{totalCount} responses</span>
              </div>
            </div>
          </div>

          {/* Feedback Feed Block */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-white/5 pb-3 gap-2">
              <div>
                <h3 className="text-xs font-semibold text-[#7C8AA8] uppercase tracking-wider">
                  Recent Brand Feedback Submissions ({surveys.length})
                </h3>
                <p className="text-[10px] text-slate-500">Includes direct portal submissions and director-logged external surveys</p>
              </div>

              <button
                type="button"
                onClick={() => setIsLogModalOpen(true)}
                className="inline-flex items-center gap-1.5 bg-[#111E33] hover:bg-[#1a2d4d] border border-[#C9A46A]/30 text-[#C9A46A] hover:text-white font-semibold px-3 py-1.5 rounded-xl text-xs transition cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>+ Log External Survey</span>
              </button>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              {surveys.map(srv => (
                <div key={srv.id} className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4 hover:border-blue-900/40 transition">
                  <div className="flex justify-between items-start gap-2">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[9px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 px-2.5 py-0.5 rounded-full uppercase tracking-wider font-bold border border-[#C9A46A]/20">
                          {srv.brand}
                        </span>
                        {srv.source && (
                          <span className="text-[9px] font-mono text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded-full uppercase tracking-wider font-medium border border-cyan-500/20 flex items-center gap-1">
                            <Globe className="w-3 h-3" />
                            {srv.source}
                          </span>
                        )}
                        <span className="text-[9px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded-full">
                          {srv.submittedAt}
                        </span>
                      </div>
                      <h4 className="font-semibold text-white text-base mt-2">{srv.campaignName}</h4>
                      <p className="text-[10px] text-[#7C8AA8] mt-0.5">Influencer Roster: <span className="text-slate-300 font-medium">{srv.creator}</span></p>
                    </div>

                    <div className="text-right flex flex-col items-end gap-1.5 shrink-0">
                      <div className="flex gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3.5 h-3.5 ${i < srv.rating ? 'text-[#C9A46A]' : 'text-slate-700'}`}
                            fill={i < srv.rating ? '#C9A46A' : 'none'}
                          />
                        ))}
                      </div>
                      <span className="text-[9px] font-mono text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                        NPS Metric: {srv.npsScore}/10
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-black/20 p-2.5 rounded-xl text-[9px] text-slate-400 font-mono">
                    <div className="text-center p-1 border-r border-white/5">
                      <span className="block text-slate-500">CREATIVE ALIGN</span>
                      <span className="font-bold text-[#C9A46A]">{srv.q1Rating}/5</span>
                    </div>
                    <div className="text-center p-1 border-r border-white/5">
                      <span className="block text-slate-500">COMPLIANCE</span>
                      <span className="font-bold text-[#C9A46A]">{srv.q2Rating}/5</span>
                    </div>
                    <div className="text-center p-1 border-r border-white/5">
                      <span className="block text-slate-500">COMMUNICATION</span>
                      <span className="font-bold text-[#C9A46A]">{srv.q3Rating}/5</span>
                    </div>
                    <div className="text-center p-1 border-r border-white/5">
                      <span className="block text-slate-500">ROI RESONANCE</span>
                      <span className="font-bold text-[#C9A46A]">{srv.q4Rating}/5</span>
                    </div>
                    <div className="text-center p-1">
                      <span className="block text-slate-500">RECOMMEND</span>
                      <span className="font-bold text-[#C9A46A]">{srv.q5Rating}/5</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#B8C0D4] leading-relaxed italic bg-[#111E33] p-3.5 rounded-xl border border-white/5">
                    "{srv.feedbackText}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        /* ==================== BRAND VIEW ==================== */
        <div className="max-w-3xl mx-auto">
          {isSubmitted ? (
            /* Success State */
            <div className="bg-[#0D1830] border-2 border-emerald-500/30 rounded-2xl p-8 text-center space-y-6 shadow-2xl animate-fade-in">
              <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full flex items-center justify-center text-3xl mx-auto">
                ✓
              </div>
              <div className="space-y-2">
                <h2 className="font-serif text-xl font-bold text-white">Feedback Successfully Dispatched</h2>
                <p className="text-xs text-[#7C8AA8] leading-relaxed">
                  Thank you for your valuable insights! Your qualitative metrics and roster evaluation scorecards have been compiled and routed directly to the Agency Director's operational workspace.
                </p>
              </div>

              <div className="p-4 bg-[#111E33] rounded-xl border border-white/5 text-left text-xs font-mono text-[#B8C0D4] space-y-2 max-w-md mx-auto">
                <p className="text-[#C9A46A] font-bold text-[10px] uppercase">SUBMISSION METRIC RECEIPT:</p>
                <p>• Campaign: <span className="text-white">{campaignName}</span></p>
                <p>• Assessed Talent: <span className="text-white">{selectedCreator}</span></p>
                <p>• Avg Scorecard Rating: <span className="text-white">{((q1 + q2 + q3 + q4 + q5) / 5).toFixed(1)} / 5.0</span></p>
                <p>• Delivery Channel: Encrypted Uplink to Workspace</p>
              </div>

              <button
                onClick={handleResetForm}
                className="bg-[#111E33] hover:bg-slate-800 text-xs text-[#C9A46A] hover:text-white border border-[#C9A46A]/20 hover:border-transparent px-5 py-2.5 rounded-xl font-semibold transition"
              >
                Submit Another Campaign Feedback
              </button>
            </div>
          ) : (
            /* feedback Form with full roster of questions */
            <div className="bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl overflow-hidden shadow-2xl">
              <div className="border-b border-white/5 p-5 bg-[#111E33]/60 flex items-center gap-3">
                <FileText className="w-5 h-5 text-[#C9A46A]" />
                <div>
                  <h3 className="font-serif font-semibold text-white text-sm uppercase tracking-wider">
                    Post-Campaign Partner Evaluation
                  </h3>
                  <p className="text-[10px] text-[#7C8AA8]">
                    Please fulfill the following roster verification questions to conclude your active campaign.
                  </p>
                </div>
              </div>

              <form onSubmit={handleSubmitFeedback} className="p-6 space-y-6 text-xs text-left">
                {/* Campaign and Creator Selection */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider block">
                      Campaign Reference Name
                    </label>
                    <input
                      type="text"
                      required
                      value={campaignName}
                      onChange={e => setCampaignName(e.target.value)}
                      placeholder="e.g. Summer Transition Launch"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-2.5 text-white outline-none focus:border-[#C9A46A] transition font-semibold"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider block">
                      Assessed Roster Creator
                    </label>
                    <select
                      value={selectedCreator}
                      onChange={e => setSelectedCreator(e.target.value)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-[#C9A46A] transition font-semibold"
                    >
                      <option value="@partner_creator">Partner Creator (@partner_creator)</option>
                      <option value="@roster_partner">Roster Partner (@roster_partner)</option>
                      <option value="@studio_talent">Studio Talent (@studio_talent)</option>
                    </select>
                  </div>
                </div>

                {/* Full Roster of Questions */}
                <div className="space-y-5 border-t border-b border-white/5 py-5">
                  <h4 className="text-[10px] text-[#C9A46A] font-mono font-bold uppercase tracking-widest flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5" /> Performance Scorecard Questions
                  </h4>

                  {/* Q1: Creative Alignment */}
                  <div className="bg-[#111E33]/30 p-4 rounded-xl border border-white/5 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="font-bold text-slate-200 block text-xs">
                        Q1: Creative Direction &amp; Styling Alignment
                      </span>
                      <span className="text-[10px] text-[#C9A46A] font-semibold">
                        {q1 === 5 ? "⭐⭐⭐⭐⭐ Exceeded" : q1 === 4 ? "⭐⭐⭐⭐ Aligned" : q1 === 3 ? "⭐⭐⭐ Satisfactory" : q1 === 2 ? "⭐⭐ Subpar" : "⭐ Critical"}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Did the produced content align perfectly with your brand's aesthetic guidelines, tone, and campaign styling?
                    </p>
                    <div className="flex gap-2 pt-1.5">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setQ1(num)}
                          className={`flex-1 py-2 rounded-lg font-bold font-mono transition text-xs border ${
                            q1 === num 
                              ? 'bg-[#C9A46A] text-[#0A1220] border-transparent shadow' 
                              : 'bg-[#111E33] text-slate-400 border-white/10 hover:border-slate-600'
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Q2: Deliverable Compliance */}
                  <div className="bg-[#111E33]/30 p-4 rounded-xl border border-white/5 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="font-bold text-slate-200 block text-xs">
                        Q2: Deliverable Quality &amp; Brief Compliance
                      </span>
                      <span className="text-[10px] text-[#C9A46A] font-semibold">
                        {q2 === 5 ? "⭐⭐⭐⭐⭐ Faultless" : q2 === 4 ? "⭐⭐⭐⭐ Compliant" : q2 === 3 ? "⭐⭐⭐ Satisfactory" : q2 === 2 ? "⭐⭐ Minor Errors" : "⭐ Non-compliant"}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Did the deliverables fulfill all specifications outlined in your campaign brief, including duration, call-to-actions, and FTC regulations?
                    </p>
                    <div className="flex gap-2 pt-1.5">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setQ2(num)}
                          className={`flex-1 py-2 rounded-lg font-bold font-mono transition text-xs border ${
                            q2 === num 
                              ? 'bg-[#C9A46A] text-[#0A1220] border-transparent shadow' 
                              : 'bg-[#111E33] text-slate-400 border-white/10 hover:border-slate-600'
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Q3: Professionalism & Communication */}
                  <div className="bg-[#111E33]/30 p-4 rounded-xl border border-white/5 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="font-bold text-slate-200 block text-xs">
                        Q3: Professionalism &amp; Response Speed
                      </span>
                      <span className="text-[10px] text-[#C9A46A] font-semibold">
                        {q3 === 5 ? "⭐⭐⭐⭐⭐ Outstanding" : q3 === 4 ? "⭐⭐⭐⭐ Responsive" : q3 === 3 ? "⭐⭐⭐ Acceptable" : q3 === 2 ? "⭐⭐ Delayed" : "⭐ Unresponsive"}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      How would you evaluate the professionalism, speed of revisions, and communication responsiveness of the creator and liaison?
                    </p>
                    <div className="flex gap-2 pt-1.5">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setQ3(num)}
                          className={`flex-1 py-2 rounded-lg font-bold font-mono transition text-xs border ${
                            q3 === num 
                              ? 'bg-[#C9A46A] text-[#0A1220] border-transparent shadow' 
                              : 'bg-[#111E33] text-slate-400 border-white/10 hover:border-slate-600'
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Q4: Audience Resonance & Engagement */}
                  <div className="bg-[#111E33]/30 p-4 rounded-xl border border-white/5 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="font-bold text-slate-200 block text-xs">
                        Q4: Audience Resonance &amp; Estimated ROI
                      </span>
                      <span className="text-[10px] text-[#C9A46A] font-semibold">
                        {q4 === 5 ? "⭐⭐⭐⭐⭐ Viral / High ROI" : q4 === 4 ? "⭐⭐⭐⭐ Solid Eng" : q4 === 3 ? "⭐⭐⭐ Average" : q4 === 2 ? "⭐⭐ Soft Resonance" : "⭐ No Impact"}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      How well did the initial viewer traction, comment sentiments, and audience engagement align with your campaign ROI targets?
                    </p>
                    <div className="flex gap-2 pt-1.5">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setQ4(num)}
                          className={`flex-1 py-2 rounded-lg font-bold font-mono transition text-xs border ${
                            q4 === num 
                              ? 'bg-[#C9A46A] text-[#0A1220] border-transparent shadow' 
                              : 'bg-[#111E33] text-slate-400 border-white/10 hover:border-slate-600'
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Q5: Overall Agency Satisfaction */}
                  <div className="bg-[#111E33]/30 p-4 rounded-xl border border-white/5 space-y-2.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <span className="font-bold text-slate-200 block text-xs">
                        Q5: Agency Recommendation &amp; Renewal Likelihood
                      </span>
                      <span className="text-[10px] text-[#C9A46A] font-semibold">
                        {q5 === 5 ? "⭐⭐⭐⭐⭐ Definitely Renew" : q5 === 4 ? "⭐⭐⭐⭐ Very Likely" : q5 === 3 ? "⭐⭐⭐ Neutral" : q5 === 2 ? "⭐⭐ Unlikely" : "⭐ Never"}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      Based on this campaign's output, how likely are you to run additional campaign cycles with Bloom Studio?
                    </p>
                    <div className="flex gap-2 pt-1.5">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setQ5(num)}
                          className={`flex-1 py-2 rounded-lg font-bold font-mono transition text-xs border ${
                            q5 === num 
                              ? 'bg-[#C9A46A] text-[#0A1220] border-transparent shadow' 
                              : 'bg-[#111E33] text-slate-400 border-white/10 hover:border-slate-600'
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Qualitative Feedback Textarea */}
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider block">
                    Qualitative Feedback &amp; Suggestions for Director
                  </label>
                  <p className="text-[10px] text-slate-500 mb-1 leading-normal">
                    Please provide detailed, specific guidance regarding what went exceptionally well or any constructive parameters to optimize subsequent agreements.
                  </p>
                  <textarea
                    required
                    rows={4}
                    value={feedbackText}
                    onChange={e => setFeedbackText(e.target.value)}
                    placeholder="Type constructive partner feedback details directly for Agency Leadership..."
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-4 py-3 text-white outline-none focus:ring-0 resize-none transition font-semibold"
                  ></textarea>
                </div>

                {/* Disclaimer Alert */}
                <div className="p-3 bg-amber-950/15 border border-amber-500/10 rounded-xl text-[10px] text-amber-500 flex items-start gap-2 font-mono">
                  <ShieldAlert className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                  <span>
                    <strong>Direct Routing Node Active:</strong> Submitting logs this evaluation into secure executive folders immediately. Backspace or manual deletions of executed feedback parameters are not allowed after submission.
                  </span>
                </div>

                {/* Actions */}
                <button
                  type="submit"
                  className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" /> Dispatch Feedback to Agency Director
                </button>
              </form>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* ⚡ DIRECTOR LOG EXTERNAL SURVEY MODAL                                      */}
      {/* ========================================================================= */}
      {isLogModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl text-left overflow-hidden relative">
            
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-white/10 bg-[#111E33] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-[#C9A46A]/15 text-[#C9A46A] rounded-xl border border-[#C9A46A]/30">
                  <PenTool className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-white text-base sm:text-lg">Log External Survey / Feedback</h3>
                  <p className="text-[11px] text-[#7C8AA8]">Record brand partner survey results received via email, phone calls, PDF forms, or offline meetings.</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsLogModalOpen(false)}
                className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/5 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form Body */}
            <form onSubmit={handleSaveExternalSurvey} className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1 text-xs text-left">
              
              {/* Brand Name & Campaign */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-300 font-mono font-bold uppercase tracking-wider block">
                    Brand / Organization Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={extBrand}
                    onChange={e => setExtBrand(e.target.value)}
                    placeholder="e.g. Sephora USA, Nike, Gymshark"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#C9A46A] transition font-semibold"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-300 font-mono font-bold uppercase tracking-wider block">
                    Campaign Reference Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={extCampaign}
                    onChange={e => setExtCampaign(e.target.value)}
                    placeholder="e.g. Fall Glow Beauty Campaign"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#C9A46A] transition font-semibold"
                  />
                </div>
              </div>

              {/* Assessed Creator & Source Channel */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-300 font-mono font-bold uppercase tracking-wider block">
                    Assessed Roster Creator / Handle
                  </label>
                  <input
                    type="text"
                    required
                    value={extCreator}
                    onChange={e => setExtCreator(e.target.value)}
                    placeholder="e.g. @partner_creator"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#C9A46A] transition font-semibold"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-300 font-mono font-bold uppercase tracking-wider block">
                    Survey Feedback Channel / Source
                  </label>
                  <select
                    value={extSource}
                    onChange={e => setExtSource(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#C9A46A] transition font-semibold"
                  >
                    <option value="External Email / Client Note">External Email / Client Note</option>
                    <option value="Executive Call / Meeting">Executive Call / Meeting</option>
                    <option value="Post-Campaign PDF Survey">Post-Campaign PDF Survey</option>
                    <option value="Google Form / Typeform Export">Google Form / Typeform Export</option>
                    <option value="Offline Interview / QA Review">Offline Interview / QA Review</option>
                    <option value="Third-Party Quality Audit">Third-Party Quality Audit</option>
                  </select>
                </div>
              </div>

              {/* Overall Rating & NPS Score */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-[#111E33]/40 rounded-xl border border-white/5">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#C9A46A] font-mono font-bold uppercase tracking-wider block">
                    Overall Star Rating (1 - 5)
                  </label>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setExtRating(star)}
                        className="p-1 cursor-pointer transition hover:scale-110"
                      >
                        <Star
                          className={`w-6 h-6 ${star <= extRating ? 'text-[#C9A46A]' : 'text-slate-700'}`}
                          fill={star <= extRating ? '#C9A46A' : 'none'}
                        />
                      </button>
                    ))}
                    <span className="text-xs font-bold font-mono text-white ml-2">{extRating}.0 / 5.0</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider block">
                    Net Promoter Score (NPS 0 - 10)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={extNps}
                      onChange={e => setExtNps(Number(e.target.value))}
                      className="w-full accent-[#C9A46A] cursor-pointer"
                    />
                    <span className="font-mono font-bold text-sm text-emerald-400 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded">
                      {extNps}/10
                    </span>
                  </div>
                </div>
              </div>

              {/* Detailed Category Scorecards */}
              <div className="space-y-3 p-4 bg-[#111E33]/30 rounded-xl border border-white/5">
                <span className="text-[10px] font-mono font-bold uppercase text-[#C9A46A] tracking-wider block">
                  Detailed Scorecard Ratings (1 to 5)
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-300 text-[11px]">
                  <div className="flex items-center justify-between bg-[#111E33] p-2.5 rounded-lg border border-white/5">
                    <span>Q1: Creative Alignment</span>
                    <select
                      value={extQ1}
                      onChange={e => setExtQ1(Number(e.target.value))}
                      className="bg-[#0D1830] text-white border border-white/10 rounded px-2 py-1 font-mono font-bold"
                    >
                      {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} Stars</option>)}
                    </select>
                  </div>

                  <div className="flex items-center justify-between bg-[#111E33] p-2.5 rounded-lg border border-white/5">
                    <span>Q2: Brief Compliance</span>
                    <select
                      value={extQ2}
                      onChange={e => setExtQ2(Number(e.target.value))}
                      className="bg-[#0D1830] text-white border border-white/10 rounded px-2 py-1 font-mono font-bold"
                    >
                      {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} Stars</option>)}
                    </select>
                  </div>

                  <div className="flex items-center justify-between bg-[#111E33] p-2.5 rounded-lg border border-white/5">
                    <span>Q3: Professionalism</span>
                    <select
                      value={extQ3}
                      onChange={e => setExtQ3(Number(e.target.value))}
                      className="bg-[#0D1830] text-white border border-white/10 rounded px-2 py-1 font-mono font-bold"
                    >
                      {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} Stars</option>)}
                    </select>
                  </div>

                  <div className="flex items-center justify-between bg-[#111E33] p-2.5 rounded-lg border border-white/5">
                    <span>Q4: Audience ROI</span>
                    <select
                      value={extQ4}
                      onChange={e => setExtQ4(Number(e.target.value))}
                      className="bg-[#0D1830] text-white border border-white/10 rounded px-2 py-1 font-mono font-bold"
                    >
                      {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} Stars</option>)}
                    </select>
                  </div>
                </div>
              </div>

              {/* Feedback Text Area */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-300 font-mono font-bold uppercase tracking-wider block">
                  External Feedback &amp; Survey Comments *
                </label>
                <textarea
                  required
                  rows={3}
                  value={extFeedback}
                  onChange={e => setExtFeedback(e.target.value)}
                  placeholder="Paste or type the client's survey response or feedback text..."
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#C9A46A] transition font-medium text-xs resize-none"
                ></textarea>
              </div>

              {/* Director Notes Area */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider block">
                  Director Internal Operational Notes (Optional)
                </label>
                <textarea
                  rows={2}
                  value={extNotes}
                  onChange={e => setExtNotes(e.target.value)}
                  placeholder="Add internal action items, liaison notes, or follow-up instructions..."
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-slate-300 outline-none focus:border-[#C9A46A] transition font-medium text-xs resize-none"
                ></textarea>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsLogModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg transition cursor-pointer"
                >
                  <Send className="w-4 h-4" /> Save External Survey Log
                </button>
              </div>
            </form>

          </div>
        </div>
      )}
    </div>
  );
}
