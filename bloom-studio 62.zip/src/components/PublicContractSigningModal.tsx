import React, { useState, useEffect } from 'react';
import { FileText, Shield, Lock, CheckCircle, AlertTriangle, Key, PenTool, Check, Building2, User, Loader2 } from 'lucide-react';
import { Contract } from '../types';
import { getStoredMaintenanceConfig, subscribeMaintenanceConfig } from '../lib/maintenanceConfig';
import { recordAgreementInVault } from '../lib/cryptoSignatures';

interface PublicContractSigningModalProps {
  contractToken: string;
  contracts?: Contract[]; // Kept for backwards compatibility, ignored for security
  onSignContract?: (contractId: string, dispatchId: string, signatureName: string) => void;
  onClose: () => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'error') => void;
}

export const PublicContractSigningModal: React.FC<PublicContractSigningModalProps> = ({
  contractToken,
  onSignContract,
  onClose,
  triggerNotification
}) => {
  const [loading, setLoading] = useState(true);
  const [verifyingPin, setVerifyingPin] = useState(false);
  const [submittingSign, setSubmittingSign] = useState(false);

  const [requiresPin, setRequiresPin] = useState(false);
  const [enteredPin, setEnteredPin] = useState('');
  const [pinError, setPinError] = useState(false);

  const [matchedContract, setMatchedContract] = useState<any>(null);
  const [matchedDispatch, setMatchedDispatch] = useState<any>(null);
  const [signerName, setSignerName] = useState('');
  const [signatureConfirmed, setSignatureConfirmed] = useState(false);
  const [isSignedSuccess, setIsSignedSuccess] = useState(false);
  const [invalidToken, setInvalidToken] = useState(false);
  const [maintenance, setMaintenance] = useState(getStoredMaintenanceConfig);

  useEffect(() => {
    const unsub = subscribeMaintenanceConfig((cfg) => setMaintenance(cfg));
    return () => unsub();
  }, []);

  // Server-side verification on mount
  useEffect(() => {
    let isMounted = true;
    const verifyToken = async () => {
      setLoading(true);
      try {
        const res = await fetch('/api/contracts/public-verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: contractToken })
        });
        const data = await res.json();
        if (!isMounted) return;

        if (data.requiresPin) {
          setRequiresPin(true);
          setLoading(false);
        } else if (data.success) {
          setMatchedContract(data.contract);
          setMatchedDispatch(data.dispatch);
          setSignerName(data.dispatch?.recipientName || '');
          setRequiresPin(false);
          setLoading(false);
        } else {
          setInvalidToken(true);
          setLoading(false);
        }
      } catch (e) {
        if (isMounted) {
          setInvalidToken(true);
          setLoading(false);
        }
      }
    };

    verifyToken();
    return () => { isMounted = false; };
  }, [contractToken]);

  const handleVerifyPinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!enteredPin.trim()) return;

    setVerifyingPin(true);
    setPinError(false);

    try {
      const res = await fetch('/api/contracts/public-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: contractToken, accessPin: enteredPin.trim() })
      });
      const data = await res.json();

      if (data.success) {
        setMatchedContract(data.contract);
        setMatchedDispatch(data.dispatch);
        setSignerName(data.dispatch?.recipientName || '');
        setRequiresPin(false);
      } else {
        setPinError(true);
        triggerNotification?.('PIN Verification Failed', data.error || 'The access PIN entered is incorrect.', 'error');
      }
    } catch (err) {
      setPinError(true);
    } finally {
      setVerifyingPin(false);
    }
  };

  const handleExecuteSigning = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!signerName.trim()) {
      triggerNotification?.('Signer Name Required', 'Please enter your legal name to execute this agreement.', 'warning');
      return;
    }
    if (!signatureConfirmed) {
      triggerNotification?.('Confirmation Required', 'Please acknowledge the electronic signature terms.', 'warning');
      return;
    }

    setSubmittingSign(true);

    try {
      const res = await fetch('/api/contracts/public-sign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: contractToken,
          accessPin: enteredPin.trim(),
          signerName: signerName.trim()
        })
      });
      const data = await res.json();

      if (data.success) {
        onSignContract?.(data.contractId, data.dispatchId, signerName.trim());
        recordAgreementInVault({
          id: data.dispatchId || `contract_sig_${Date.now()}`,
          documentType: matchedContract?.name || 'Executed Public Contract & Brief',
          signerName: signerName.trim(),
          signerEmail: matchedDispatch?.recipientEmail || '',
          organization: matchedContract?.brandName || 'Agency Partner Network',
          signerRole: 'partner',
          isoTimestamp: new Date().toISOString(),
          formattedTimestamp: new Date().toLocaleString(),
          digest: data.digest || `SHA256:PUBLIC_CONTRACT_${(data.contractId || 'SIG').toUpperCase()}`,
          clausesAccepted: [
            'E-SIGN Act Electronic Record Consent',
            'Milestone Deliverables & Approval Covenants',
            'Escrow Payment & Non-Circumvention Rules'
          ]
        });
        setIsSignedSuccess(true);
        triggerNotification?.(
          'Contract Executed Successfully',
          `Legal agreement ${matchedContract?.name || 'Contract'} signed by ${signerName}.`,
          'success'
        );
      } else {
        triggerNotification?.('Execution Failed', data.error || 'Failed to record signature.', 'error');
      }
    } catch (err) {
      triggerNotification?.('Execution Error', 'An error occurred while sealing contract.', 'error');
    } finally {
      setSubmittingSign(false);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 bg-[#0A1220]/90 backdrop-blur-md flex items-center justify-center p-4">
        <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl p-8 text-center space-y-4 shadow-2xl">
          <Loader2 className="w-10 h-10 text-[#C9A46A] animate-spin mx-auto" />
          <p className="text-xs text-slate-300 font-mono">Verifying Encrypted Contract Envelope...</p>
        </div>
      </div>
    );
  }

  if (invalidToken) {
    return (
      <div className="fixed inset-0 z-50 bg-[#0A1220]/90 backdrop-blur-md flex items-center justify-center p-4">
        <div className="bg-[#0D1830] border border-rose-500/30 rounded-2xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl">
          <AlertTriangle className="w-12 h-12 text-rose-400 mx-auto" />
          <h3 className="text-xl font-serif font-bold text-white">Invalid or Expired Signing Link</h3>
          <p className="text-xs text-slate-300">
            The secure signing token <code className="text-amber-300 font-mono">{contractToken}</code> could not be verified in the Bloom Studio secure escrow vault, or the envelope has expired.
          </p>
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs transition cursor-pointer"
          >
            Close Portal
          </button>
        </div>
      </div>
    );
  }

  if (maintenance.enabled) {
    return (
      <div className="fixed inset-0 z-50 bg-[#070D18]/95 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-[#0D1830] border-2 border-amber-500/40 rounded-2xl max-w-lg w-full p-8 text-center space-y-5 shadow-2xl relative">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto shadow-inner">
            <Lock className="w-7 h-7" />
          </div>
          <div className="space-y-2">
            <div className="inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300">
              Contract Signing Suspended
            </div>
            <h2 className="text-2xl font-bold font-serif text-white">Platform In Maintenance Mode</h2>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
            {maintenance.reason ||
              "This platform is currently undergoing emergency maintenance and construction. Contract signing is temporarily locked by platform administration for security assurance."}
          </p>
          <div className="p-3 bg-[#111E33] border border-white/5 rounded-xl text-xs text-slate-400">
            Your contract dispatch token is held securely in escrow. Please check back shortly once maintenance is concluded.
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold cursor-pointer transition-all"
          >
            Close Notice
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-[#0A1220]/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-serif font-bold text-white">Bloom Studio Secure Legal Portal</h3>
              {matchedDispatch && <p className="text-xs text-[#7C8AA8] font-mono">Encrypted Envelope Ref: {matchedDispatch.id}</p>}
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-white/5 transition cursor-pointer"
          >
            ✕
          </button>
        </div>

        {requiresPin ? (
          /* PIN Entry Screen - Contract details remain withheld on server until correct PIN is sent */
          <form onSubmit={handleVerifyPinSubmit} className="space-y-4 py-4">
            <div className="bg-amber-950/40 border border-amber-500/30 rounded-xl p-5 space-y-3">
              <label className="text-sm font-mono font-bold text-amber-300 flex items-center gap-2">
                <Key className="w-5 h-5" />
                <span>Security PIN Required by Sender</span>
              </label>
              <p className="text-xs text-slate-300 leading-relaxed">
                The sender protected this agreement with a secure access PIN. Please enter your PIN code below to unlock and view the document details.
              </p>
              <input
                type="password"
                maxLength={6}
                value={enteredPin}
                onChange={(e) => {
                  setEnteredPin(e.target.value);
                  setPinError(false);
                }}
                placeholder="Enter 4-digit Access PIN"
                className={`w-full bg-[#0A1220] border rounded-xl px-4 py-3 text-white font-mono text-base tracking-widest ${
                  pinError ? 'border-rose-500' : 'border-white/10 focus:border-[#C9A46A]'
                }`}
              />
              {pinError && <p className="text-xs text-rose-400 font-medium">Incorrect Access PIN. Verification denied by server.</p>}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={verifyingPin || !enteredPin.trim()}
                className="px-6 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] disabled:opacity-50 text-[#0A1220] font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-lg"
              >
                {verifyingPin && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Verify &amp; Unlock Agreement</span>
              </button>
            </div>
          </form>
        ) : isSignedSuccess ? (
          <div className="py-12 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-500/20 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h4 className="text-2xl font-serif font-bold text-white">Execution Complete &amp; Logged</h4>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              This contract has been cryptographically signed and sealed. A copy of the audit certificate has been dispatched to <span className="text-[#C9A46A] font-mono">{matchedDispatch?.recipientEmail || 'your email'}</span>.
            </p>
            <div className="pt-4">
              <button
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl bg-[#C9A46A] text-[#0A1220] font-bold text-xs hover:bg-[#E3C48F] transition cursor-pointer"
              >
                Return to Dashboard
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Agreement Summary Box */}
            <div className="bg-[#111E33] border border-white/10 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase text-[#C9A46A] tracking-wider">Document Summary</span>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-mono">
                  {matchedContract?.status || 'Pending Signature'}
                </span>
              </div>
              <h4 className="text-base font-bold text-white font-serif">{matchedContract?.name || matchedContract?.title || 'Agency Representation Agreement'}</h4>
              <p className="text-xs text-slate-300 leading-relaxed bg-[#0A1220] p-4 rounded-lg border border-white/5 font-mono">
                {matchedDispatch?.coverNote || 'Please review and execute the attached talent representation and campaign deliverables contract under Bloom Studio guidelines.'}
              </p>
              <div className="grid grid-cols-2 gap-4 pt-2 text-xs font-mono">
                <div>
                  <span className="text-[#7C8AA8]">Counterparty:</span> <span className="text-white font-bold">{matchedContract?.party}</span>
                </div>
                <div>
                  <span className="text-[#7C8AA8]">Revenue Terms:</span> <span className="text-emerald-400 font-bold">{matchedContract?.revenueSplit || matchedContract?.terms || 'Standard Agency Split'}</span>
                </div>
              </div>
            </div>

            {/* Signature Form */}
            <form onSubmit={handleExecuteSigning} className="space-y-4 pt-2">
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-[#7C8AA8] uppercase">Legal Name (Electronic Signatory)</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3 w-4 h-4 text-[#7C8AA8]" />
                  <input
                    type="text"
                    required
                    value={signerName}
                    onChange={(e) => setSignerName(e.target.value)}
                    placeholder="e.g. Jane Doe (Managing Director / Talent)"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-white text-xs font-sans focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div className="flex items-start gap-3 pt-2">
                <input
                  type="checkbox"
                  id="confirm_sign"
                  checked={signatureConfirmed}
                  onChange={(e) => setSignatureConfirmed(e.target.checked)}
                  className="mt-1 rounded bg-[#111E33] border-white/20 text-[#C9A46A] focus:ring-0 cursor-pointer"
                />
                <label htmlFor="confirm_sign" className="text-xs text-slate-300 cursor-pointer leading-relaxed">
                  I understand and agree that checking this box and entering my legal name constitutes my electronic signature, having the same legal effect as a handwritten signature under electronic commerce laws.
                </label>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingSign}
                  className="px-6 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] disabled:opacity-50 text-[#0A1220] font-bold text-xs flex items-center gap-2 transition cursor-pointer shadow-lg"
                >
                  {submittingSign ? <Loader2 className="w-4 h-4 animate-spin" /> : <PenTool className="w-4 h-4" />}
                  <span>Execute &amp; Sign Legally</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
