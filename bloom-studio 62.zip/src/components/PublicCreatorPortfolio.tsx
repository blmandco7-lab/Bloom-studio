import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Sparkles, 
  Tag, 
  Video, 
  Users, 
  TrendingUp, 
  Eye, 
  ShieldCheck, 
  CheckCircle2, 
  Download, 
  ArrowRight,
  ArrowLeft,
  ChevronDown,
  ExternalLink,
  Layers,
  Heart,
  ChevronRight,
  Plus,
  X,
  Lock,
  Copy,
  Check,
  Trash2,
  ListFilter,
  Shield,
  Search,
  Edit3,
  UserPlus,
  DollarSign,
  Clock,
  Mail,
  Upload,
  Star
} from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Creator, Contract, Deal } from '../types';
import { getStoredDirectorDelegation, saveStoredDirectorDelegation, DirectorDelegationSettings } from './DirectorDelegationControls';
import DynamicCreatorMediaKit, { CreatorPortfolioProfile } from './DynamicCreatorMediaKit';
import { getPortfolioViewMode } from '../utils/portfolioViewMode';
import { safeStorage } from '../utils/safeStorage';

interface PublicCreatorPortfolioProps {
  initialCreatorHandle?: string;
  onNavigateHome?: () => void;
  currentRole?: string;
  currentUser?: any;
  creators?: Creator[];
  delegationSettings?: DirectorDelegationSettings;
  onLogin?: (email: string, role: string) => void;
  onStartAgencySignup?: () => void;
  onSignUp?: () => void;
}

export const TALENT_CODE_MAP: Record<string, string> = {
  '@elenarostova': 'Creator #101',
  '@kai_lifestyle': 'Creator #102',
  '@golden_leo': 'Creator #103',
  '@marcus_vfx': 'Creator #104',
  '@sarah_fits': 'Creator #105'
};

const INITIAL_SAMPLE_PORTFOLIOS: Record<string, CreatorPortfolioProfile> = {
  '@elenarostova': {
    id: "creator_elena",
    name: "Elena Rostova",
    handle: "@elenarostova",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
    platform: "Instagram",
    niche: "Beauty",
    totalReach: "485,000",
    avgVelocity: "142,500",
    engagementRate: "5.8%",
    bio: "Luxury skincare & clean beauty specialist creating aesthetic UGC tutorials, routine breakdowns, and science-backed formula reviews.",
    nicheParameters: [
      { label: "Skin Profile", value: "Combination • Fitzpatrick Type II" },
      { label: "Key Specialty", value: "Barrier Repair & Peptide Serums" },
      { label: "Studio Lighting", value: "4K Daylight Balanced (5600K)" },
      { label: "Audience Demographics", value: "84% Female • 22-38 Age Cohort" }
    ],
    topUgcShorts: [
      {
        id: "ugc_elena_01",
        title: "Morning Barrier Repair Routine (Macro Texture)",
        views: "420K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        tags: ["Skincare UGC", "Macro 4K", "FTC Cleared"]
      },
      {
        id: "ugc_elena_02",
        title: "Ceramide Cream 7-Day Hydration Test",
        views: "310K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        tags: ["Product Test", "Clean Beauty", "Ad Whitelisted"]
      },
      {
        id: "ugc_elena_03",
        title: "Peptide Lip Gloss Swatch & Wear Test",
        views: "185K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        tags: ["Beauty Swatch", "Aesthetic Glow", "Spark Ads Ready"]
      }
    ]
  },
  '@kai_lifestyle': {
    id: "creator_kai",
    name: "Kai Lindqvist",
    handle: "@kai_lifestyle",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80",
    platform: "TikTok",
    niche: "Lifestyle",
    totalReach: "720,000",
    avgVelocity: "285,000",
    engagementRate: "7.1%",
    bio: "Nordic lifestyle, interior minimalism, and smart desk setup architect crafting calming vertical video experiences and high-conversion tech UGC.",
    nicheParameters: [
      { label: "Aesthetic Matrix", value: "Minimalist Scandinavian / Warm Nordic" },
      { label: "Studio Lighting", value: "Diffused Daylight • Soft Tungsten Accents" },
      { label: "Color Story", value: "Slate, Oatmeal & Natural Oak Palettes" },
      { label: "Audience Geo", value: "North America (62%) • Europe (28%)" }
    ],
    topUgcShorts: [
      {
        id: "ugc_kai_01",
        title: "Nordic Minimalist Morning Routine UGC",
        views: "580K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        tags: ["Morning Routine", "Nordic Aesthetic", "4K UGC"]
      },
      {
        id: "ugc_kai_02",
        title: "Clean Desk Setup & Ambient Lighting Integration",
        views: "340K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        tags: ["Desk Tour", "Clean Lighting", "Product Integration"]
      },
      {
        id: "ugc_kai_03",
        title: "Sustainable Home Fragrance Unboxing & Mood",
        views: "275K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        tags: ["Aroma Mood", "Macro Unbox", "FTC Cleared"]
      }
    ]
  },
  '@golden_leo': {
    id: "creator_leo",
    name: "Leo & Chloe",
    handle: "@golden_leo",
    avatar: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=400&auto=format&fit=crop&q=80",
    platform: "TikTok",
    niche: "Pets",
    totalReach: "950,000",
    avgVelocity: "415,000",
    engagementRate: "8.2%",
    bio: "Top dog wellness creator featuring Leo the purebred Golden Retriever testing functional dog chews, canine calming routines, and smart pet gear.",
    nicheParameters: [
      { label: "Pet Breed Metrics", value: "Purebred Golden Retriever (AKC Certified)" },
      { label: "Age & Weight", value: "3.5 Years Old • 68 lbs Active Athletic" },
      { label: "Diet Category", value: "Organic Raw & Functional Joint Chews" },
      { label: "Household Type", value: "Suburban Dog-Friendly Home & Fenced Yard" }
    ],
    topUgcShorts: [
      {
        id: "ugc_leo_01",
        title: "Calming Chews 30-Minute Reaction & Taste Test",
        views: "920K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        tags: ["Dog Wellness", "Taste Test", "FTC Cleared"]
      },
      {
        id: "ugc_leo_02",
        title: "Smart GPS Collar Real-World Trail Test",
        views: "640K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        tags: ["Smart Gear", "Outdoor Trail", "Commercial UGC"]
      },
      {
        id: "ugc_leo_03",
        title: "Grooming & Coat Shine Oil Routine (ASMR)",
        views: "480K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        tags: ["Grooming Routine", "ASMR", "Dog Care"]
      }
    ]
  },
  '@marcus_vfx': {
    id: "creator_marcus",
    name: "Marcus Miller",
    handle: "@marcus_vfx",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80",
    platform: "YouTube",
    niche: "Tech",
    totalReach: "640,000",
    avgVelocity: "245,000",
    engagementRate: "7.2%",
    bio: "Cinematography specialist & consumer hardware reviewer creating ultra-sharp 4K vertical macro showcases, product tear-downs, and commercial tech UGC.",
    nicheParameters: [
      { label: "Primary Rig", value: "Sony FX3 Cinema Line • 4K 120p" },
      { label: "Macro Optics", value: "90mm f/2.8 Macro & Anamorphic Glass" },
      { label: "Audio Environment", value: "Custom Foley & Spatial Sound Design" },
      { label: "Audience Demo", value: "81% Male • 22-38 Tech Enthusiasts" }
    ],
    topUgcShorts: [
      {
        id: "ugc_marcus_01",
        title: "Noise-Canceling Wireless Earbuds Macro Acoustic Test",
        views: "780K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        tags: ["Hardware UGC", "Macro 4K", "FTC Cleared"]
      },
      {
        id: "ugc_marcus_02",
        title: "Smart Workspace Mechanical Keyboard Build & Sound",
        views: "490K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        tags: ["Desk Tech", "ASMR Sound", "Spark Ads Ready"]
      },
      {
        id: "ugc_marcus_03",
        title: "4K Action Camera Low-Light Night Ride",
        views: "340K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        tags: ["Camera Gear", "Night Video", "Ad Whitelisted"]
      }
    ]
  },
  '@sarah_fits': {
    id: "creator_sarah",
    name: "Sarah Jenkins",
    handle: "@sarah_fits",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
    platform: "TikTok",
    niche: "Fitness",
    totalReach: "580,000",
    avgVelocity: "210,000",
    engagementRate: "7.6%",
    bio: "Certified functional strength trainer and athletic wear reviewer producing high-energy sweat tests, pre-workout supplement evaluations, and gym routine UGC.",
    nicheParameters: [
      { label: "Athletic Focus", value: "Functional Strength & Mobility Training" },
      { label: "Wear Durability", value: "Squat-Proof & High-Impact Sweat Tested" },
      { label: "Filming Space", value: "Private Functional Training Studio" },
      { label: "Audience Cohort", value: "78% Female • 18-34 Active Demographic" }
    ],
    topUgcShorts: [
      {
        id: "ugc_sarah_01",
        title: "Seamless Gym Set 30-Day High-Impact Wear Test",
        views: "690K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1518611012118-696072aa579a?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        tags: ["Activewear UGC", "Wear Test", "FTC Cleared"]
      },
      {
        id: "ugc_sarah_02",
        title: "Electrolyte Hydration Powder Honest Review",
        views: "440K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        tags: ["Supplements", "Taste Test", "Spark Ads Ready"]
      },
      {
        id: "ugc_sarah_03",
        title: "Recovery Massage Gun 14-Day Post-Workout Routine",
        views: "315K views",
        format: "9:16 Vertical UHD",
        thumbnail: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=500&auto=format&fit=crop&q=80",
        videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        tags: ["Recovery Gear", "Daily Routine", "Ad Whitelisted"]
      }
    ]
  }
};

export default function PublicCreatorPortfolio({
  initialCreatorHandle = '@elenarostova',
  onNavigateHome,
  currentRole,
  currentUser,
  creators = [],
  delegationSettings: propDelegationSettings,
  onLogin,
  onStartAgencySignup,
  onSignUp,
}: PublicCreatorPortfolioProps) {
  const [portfolios, setPortfolios] = useState<Record<string, CreatorPortfolioProfile>>(() => {
    try {
      const saved = localStorage.getItem('wl_public_portfolios');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Object.keys(parsed).length > 0) return { ...INITIAL_SAMPLE_PORTFOLIOS, ...parsed };
      }
    } catch (e) {}
    return INITIAL_SAMPLE_PORTFOLIOS;
  });

  // Photo upload helper for Director
  const handleDirectPhotoUpload = (handle: string, file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file (PNG, JPG, WebP).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('File size exceeds 5MB limit. Please choose a smaller image.');
      return;
    }
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      if (base64) {
        setPortfolios(prev => {
          const existing = prev[handle];
          if (!existing) return prev;
          const updated = { ...prev, [handle]: { ...existing, avatar: base64 } };
          try {
            localStorage.setItem('wl_public_portfolios', JSON.stringify(updated));
          } catch (err) {}
          return updated;
        });
        try {
          const cleanDocId = handle.replace(/^@/, '');
          await setDoc(doc(db, 'studio-creators', cleanDocId), {
            avatar: base64,
            avatarUrl: base64,
            updatedAt: new Date().toISOString()
          }, { merge: true });
        } catch (err) {
          console.warn('Firestore studio-creators photo write note:', err);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const [talentCodes, setTalentCodes] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('wl_talent_code_map');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Object.keys(parsed).length > 0) return { ...TALENT_CODE_MAP, ...parsed };
      }
    } catch (e) {}
    return TALENT_CODE_MAP;
  });

  // Feature on Brand Share Link curation state
  const [featuredBrandCreators, setFeaturedBrandCreators] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('wl_featured_brand_creators');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed === 'object' && parsed !== null) return parsed;
      }
    } catch (e) {}
    // Default featured set
    return {
      '@elenarostova': true,
      '@kai_lifestyle': true,
      '@golden_leo': true,
      '@marcus_vfx': true,
      '@sarah_fits': true
    };
  });
  const [showCurateModal, setShowCurateModal] = useState<boolean>(false);
  const [curateSearch, setCurateSearch] = useState<string>('');

  const toggleCreatorFeaturedOnBrandLink = async (handleToToggle: string) => {
    if (!handleToToggle) return;
    
    let isNowFeatured = false;

    setFeaturedBrandCreators(prev => {
      const isCurrentlyFeatured = !!prev[handleToToggle];
      isNowFeatured = !isCurrentlyFeatured;
      const updated = { ...prev, [handleToToggle]: isNowFeatured };
      try {
        localStorage.setItem('wl_featured_brand_creators', JSON.stringify(updated));
      } catch (err) {}
      return updated;
    });

    try {
      const cleanDocId = handleToToggle.replace(/^@/, '');
      await setDoc(doc(db, 'studio-creators', cleanDocId), {
        featuredOnBrandLink: isNowFeatured,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore featured toggle write note:', err);
    }
  };

  // Single source of truth for role & permissions
  const { effectiveRole, isBrandShareView: isBrandShare, isDirectorRole, isCreatorRole } = getPortfolioViewMode(currentUser, currentRole);
  const isDirector = isDirectorRole;

  // Strict Assignment Scoping for Restricted Roles
  const visiblePortfolios = React.useMemo(() => {
    // Creator role: Strictly only see their own portfolio
    if (isCreatorRole) {
      const myHandle = (currentUser?.handle || initialCreatorHandle || '').toLowerCase().replace(/^@/, '');
      const myName = (currentUser?.name || '').toLowerCase();

      // Look in existing portfolios
      const matchedKey = Object.keys(portfolios).find((k) => {
        const kClean = k.toLowerCase().replace(/^@/, '');
        const pName = (portfolios[k]?.name || '').toLowerCase();
        return (myHandle && kClean === myHandle) || (myName && pName === myName) || (myHandle && kClean.includes(myHandle));
      });

      if (matchedKey) {
        return { [matchedKey]: portfolios[matchedKey] };
      }

      // Check roster creators
      const rosterCreator = creators?.find((c) => {
        const cHandle = (c.handle || '').toLowerCase().replace(/^@/, '');
        const cName = (c.name || '').toLowerCase();
        return (myHandle && cHandle === myHandle) || (myName && cName === myName);
      });

      const effectiveHandle = currentUser?.handle || (rosterCreator?.handle ? rosterCreator.handle : `@${myHandle || 'creator'}`);
      const synthesized: CreatorPortfolioProfile = {
        id: rosterCreator?.id || currentUser?.id || 'creator_my_portfolio',
        name: rosterCreator?.name || currentUser?.name || 'Creator Portfolio',
        handle: effectiveHandle,
        avatar: rosterCreator?.avatar || currentUser?.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
        platform: "TikTok",
        niche: (rosterCreator?.niche as any) || "Lifestyle",
        totalReach: rosterCreator?.followers || "350,000",
        avgVelocity: "95,000",
        engagementRate: rosterCreator?.eng || "5.4%",
        bio: rosterCreator?.bio || "Verified content creator specializing in authentic UGC, short-form storytelling, and high-converting brand partnerships.",
        nicheParameters: [
          { label: "Content Focus", value: rosterCreator?.niche || "Short-Form Video & UGC" },
          { label: "Platform Specialization", value: "TikTok • Instagram Reels" },
          { label: "Resolution & Specs", value: "9:16 Vertical UHD 4K" },
          { label: "FTC Clear Status", value: "Verified Compliant" }
        ],
        topUgcShorts: [
          {
            id: "ugc_my_01",
            title: "Product Review & Morning Routine",
            views: "180K views",
            format: "9:16 Vertical UHD",
            thumbnail: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&auto=format&fit=crop&q=80",
            videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
            tags: ["UGC", "Routine", "FTC Cleared"]
          },
          {
            id: "ugc_my_02",
            title: "Unboxing & First Impressions",
            views: "125K views",
            format: "9:16 Vertical UHD",
            thumbnail: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&auto=format&fit=crop&q=80",
            videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
            tags: ["Unboxing", "High Conversion", "Product Demo"]
          }
        ]
      };

      return { [effectiveHandle]: synthesized };
    }

    const isRestrictedStaff = ['agentmgr', 'agent', 'coordinator'].includes(effectiveRole);
    if (!isRestrictedStaff) return portfolios;

    const userName = (currentUser?.name || '').toLowerCase();
    if (!userName) return portfolios;

    const filtered: Record<string, CreatorPortfolioProfile> = {};
    Object.keys(portfolios).forEach((handle) => {
      const p = portfolios[handle];
      const creatorName = (p.name || '').toLowerCase();
      
      // Match against creators roster if provided
      if (creators && creators.length > 0) {
        const matchingCreator = creators.find(c => c.handle.toLowerCase() === handle.toLowerCase() || c.name.toLowerCase() === creatorName);
        if (matchingCreator) {
          const ag = (matchingCreator.assignedAgent || (matchingCreator as any).agent || '').toLowerCase();
          const mgr = (matchingCreator.assignedManager || '').toLowerCase();
          const coord = (matchingCreator.assignedCoordinator || matchingCreator.coordinator || '').toLowerCase();
          const isAssigned = (
            ag.includes(userName) || userName.includes(ag) ||
            mgr.includes(userName) || userName.includes(mgr) ||
            coord.includes(userName) || userName.includes(coord) ||
            (userName.includes('marcus') && (ag.includes('marcus') || mgr.includes('marcus'))) ||
            (userName.includes('alex') && (ag.includes('alex') || coord.includes('alex')))
          );
          if (isAssigned) {
            filtered[handle] = p;
          }
        }
      } else {
        // Standalone fallback
        const handleClean = handle.replace(/^@/, '').toLowerCase();
        const matchesAlex = userName.includes('alex') && (handleClean.includes('elena') || handleClean.includes('kai'));
        const matchesMarcus = userName.includes('marcus') && (handleClean.includes('leo') || handleClean.includes('marcus'));
        if (matchesAlex || matchesMarcus) {
          filtered[handle] = p;
        }
      }
    });

    if (Object.keys(filtered).length === 0) {
      return {};
    }
    return filtered;
  }, [portfolios, effectiveRole, isCreatorRole, currentUser, creators, initialCreatorHandle]);

  // Genuinely anonymized portfolio dataset for brand viewers (curated by featured creators)
  const activePortfolios = React.useMemo(() => {
    if (!isBrandShare) return visiblePortfolios;

    let entries = Object.entries(visiblePortfolios);

    // Filter to ONLY featured creators if any creator has been explicitly featured
    const activeFeaturedHandles = Object.keys(featuredBrandCreators).filter(h => featuredBrandCreators[h]);
    if (activeFeaturedHandles.length > 0) {
      const featuredEntries = entries.filter(([realHandle, p]) => {
        const cleanKey = realHandle.toLowerCase();
        const profileHandle = (p.handle || '').toLowerCase();
        return activeFeaturedHandles.some(fh => fh.toLowerCase() === cleanKey || fh.toLowerCase() === profileHandle);
      });
      if (featuredEntries.length > 0) {
        entries = featuredEntries;
      }
    }

    // If an initial or URL creator was requested, ensure it is within the shown creators
    const targetHandle = (initialCreatorHandle || '').toLowerCase().replace(/^@/, '');
    if (targetHandle) {
      const foundIdx = entries.findIndex(([k, p]) => 
        k.toLowerCase().replace(/^@/, '') === targetHandle ||
        (p.handle && p.handle.toLowerCase().replace(/^@/, '') === targetHandle)
      );
      if (foundIdx > 0) {
        const [targetEntry] = entries.splice(foundIdx, 1);
        entries.unshift(targetEntry);
      }
    }

    // Limit brand view entries
    const limitedEntries = entries.slice(0, 10);

    const result: Record<string, CreatorPortfolioProfile> = {};

    limitedEntries.forEach(([realHandle, profile], idx) => {
      const code = talentCodes[realHandle] || `Creator #${101 + idx}`;
      const anonKey = `anon_${101 + idx}`;

      result[anonKey] = {
        ...profile,
        id: anonKey,
        _realHandle: realHandle,
        name: `${code} (${profile.niche || 'Specialist'})`,
        handle: code,
        bio: (profile.bio || '')
          .replace(new RegExp(profile.name || '_____', 'gi'), code)
          .replace(new RegExp(realHandle || '_____', 'gi'), code),
      };
    });

    return result;
  }, [visiblePortfolios, talentCodes, isBrandShare, initialCreatorHandle, featuredBrandCreators]);

  // Strip real mapping table in brand mode
  const activeTalentCodes = React.useMemo(() => {
    if (isBrandShare) return {};
    return talentCodes;
  }, [talentCodes, isBrandShare]);

  const [isFooterVisible, setIsFooterVisible] = useState(false);

  // Helper to match creator handle or alias in activePortfolios
  const findMatchingKey = (requestedHandle: string, portfoliosObj: Record<string, CreatorPortfolioProfile>) => {
    if (!requestedHandle) return undefined;
    const clean = requestedHandle.toLowerCase().replace(/^@/, '');
    return Object.keys(portfoliosObj).find(k => {
      const kClean = k.toLowerCase().replace(/^@/, '');
      if (kClean === clean) return true;
      const p = portfoliosObj[k];
      if (p) {
        if ((p as any)._realHandle && (p as any)._realHandle.toLowerCase().replace(/^@/, '') === clean) return true;
        if (p.handle && p.handle.toLowerCase().replace(/^@/, '') === clean) return true;
        if (p.id && p.id.toLowerCase() === clean) return true;
        if (p.id && (p.id === requestedHandle || p.id === `creator_${clean}`)) return true;
        const code = talentCodes[`@${clean}`] || talentCodes[clean];
        if (code && (p.handle === code || p.name.includes(code))) return true;
        // Match anon_101, anon_102... to corresponding portfolio index
        if (clean.startsWith('anon_')) {
          const idx = parseInt(clean.replace('anon_', ''), 10) - 101;
          const keys = Object.keys(portfoliosObj);
          if (idx >= 0 && idx < keys.length && keys[idx] === k) return true;
        }
      }
      return false;
    });
  };

  // Parse creator query/hash if requested
  const [activeHandle, setActiveHandle] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const qCreator = searchParams.get('creator');
      if (qCreator) {
        const match = findMatchingKey(decodeURIComponent(qCreator), activePortfolios);
        if (match) return match;
      }
      const hash = window.location.hash;
      const hashCreatorMatch = hash.match(/creator=([^&]+)/);
      if (hashCreatorMatch && hashCreatorMatch[1]) {
        const match = findMatchingKey(decodeURIComponent(hashCreatorMatch[1]), activePortfolios);
        if (match) return match;
      }
      const kitMatch = hash.match(/#kit-([a-zA-Z0-9_-]+)/);
      if (kitMatch && kitMatch[1]) {
        const match = findMatchingKey(decodeURIComponent(kitMatch[1]), activePortfolios);
        if (match) return match;
      }
    }
    const keys = Object.keys(activePortfolios);
    const initialMatch = findMatchingKey(initialCreatorHandle, activePortfolios);
    if (initialMatch) return initialMatch;
    return keys[0] || (isBrandShare ? 'anon_101' : initialCreatorHandle);
  });

  // Track last URL hash so hashchange listener only updates state when URL hash changes
  const lastHashRef = React.useRef<string>(typeof window !== 'undefined' ? window.location.hash : '');

  // Sync active handle on URL hash change or initial mount
  useEffect(() => {
    const handleUrlSync = () => {
      if (typeof window === 'undefined') return;
      const currentHash = window.location.hash;
      const searchParams = new URLSearchParams(window.location.search);
      const qCreator = searchParams.get('creator');
      let requested = qCreator ? decodeURIComponent(qCreator) : null;
      if (!requested) {
        const hashCreatorMatch = currentHash.match(/creator=([^&]+)/);
        if (hashCreatorMatch && hashCreatorMatch[1]) {
          requested = decodeURIComponent(hashCreatorMatch[1]);
        }
      }
      if (!requested) {
        const kitMatch = currentHash.match(/#kit-([a-zA-Z0-9_-]+)/);
        if (kitMatch && kitMatch[1]) {
          requested = decodeURIComponent(kitMatch[1]);
        }
      }

      if (requested) {
        const match = findMatchingKey(requested, activePortfolios);
        if (match) {
          setActiveHandle(match);
          lastHashRef.current = currentHash;
          return;
        }
      }

      const keys = Object.keys(activePortfolios);
      if (keys.length > 0 && !keys.includes(activeHandle)) {
        setActiveHandle(keys[0]);
      }
      lastHashRef.current = currentHash;
    };

    handleUrlSync();
    window.addEventListener('hashchange', handleUrlSync);
    return () => window.removeEventListener('hashchange', handleUrlSync);
  }, [activePortfolios]);

  // Monitor visibility of #portfolio-contact-footer so sticky bar hides at bottom
  useEffect(() => {
    let observer: IntersectionObserver | null = null;
    const timeoutId = setTimeout(() => {
      const footerElem = document.getElementById('portfolio-contact-footer');
      if (!footerElem) return;

      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            setIsFooterVisible(entry.isIntersecting);
          });
        },
        { threshold: 0.05, rootMargin: '100px 0px 0px 0px' }
      );

      observer.observe(footerElem);
    }, 100);

    return () => {
      clearTimeout(timeoutId);
      if (observer) observer.disconnect();
    };
  }, [activeHandle, activePortfolios]);
  
  // Director delegation settings state
  const [delegationSettings, setDelegationSettings] = useState<DirectorDelegationSettings>(() => {
    if (propDelegationSettings) return propDelegationSettings;
    return getStoredDirectorDelegation();
  });

  useEffect(() => {
    if (propDelegationSettings) {
      setDelegationSettings(propDelegationSettings);
    }
  }, [propDelegationSettings]);

  useEffect(() => {
    const handleUpdate = (e: any) => {
      if (e.detail) setDelegationSettings(e.detail);
    };
    window.addEventListener('director_delegation_updated', handleUpdate);
    return () => window.removeEventListener('director_delegation_updated', handleUpdate);
  }, []);

  const isAgentMgr = effectiveRole === 'agentmgr' || effectiveRole.includes('manager');

  // Permission logic for adding to Public Portfolio:
  // User requirement: "They are not to add to the public portfolio that button also should not show and have a switch in director navigation"
  const canAddCreator = isDirector
    ? true
    : isAgentMgr
      ? delegationSettings.agentManagerCanAddToPortfolio
      : !isCreatorRole && !isBrandShare;

  // Anti-poaching protection: Default to showing talent code (Creator #101) so brands route bookings through the agency
  const [useTalentCodeMode, setUseTalentCodeMode] = useState<boolean>(() => !isDirectorRole && (!isCreatorRole || isBrandShare));
  const [showFreeAccountModal, setShowFreeAccountModal] = useState<boolean>(false);
  const [freeAccountForm, setFreeAccountForm] = useState({
    brandName: '',
    contactName: '',
    email: ''
  });
  const [isAddCreatorOpen, setIsAddCreatorOpen] = useState<boolean>(false);
  const [showDirectorMappingPanel, setShowDirectorMappingPanel] = useState<boolean>(false);
  const [mappingSearch, setMappingSearch] = useState<string>('');

  const [viewState, setViewState] = useState<'Director' | 'Agent' | 'Public'>(
    isBrandShare || isAgentMgr ? 'Public' : 'Director'
  );

  // New Creator Form State
  const [newCreatorName, setNewCreatorName] = useState('');
  const [newCreatorHandle, setNewCreatorHandle] = useState('');
  const [newCreatorNiche, setNewCreatorNiche] = useState('Beauty');
  const [newCreatorPlatform, setNewCreatorPlatform] = useState('TikTok');
  const [newCreatorReach, setNewCreatorReach] = useState('520,000');
  const [newCreatorBio, setNewCreatorBio] = useState('');
  const [newCreatorAvatar, setNewCreatorAvatar] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80');

  // Sync with Local Storage
  useEffect(() => {
    if (isBrandShare) return;
    try {
      localStorage.setItem('wl_public_portfolios', JSON.stringify(portfolios));
      localStorage.setItem('wl_talent_code_map', JSON.stringify(talentCodes));
    } catch (e) {}
  }, [portfolios, talentCodes, isBrandShare]);

  const handleDeleteCreator = (handleToDelete: string, creatorName: string) => {
    if (isBrandShare) return;
    const updated = { ...portfolios };
    delete updated[handleToDelete];
    setPortfolios(updated);

    const keys = Object.keys(updated);
    if (activeHandle === handleToDelete) {
      if (keys.length > 0) {
        setActiveHandle(keys[0]);
      }
    }
  };

  const handleAddCreatorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isBrandShare || !newCreatorHandle.trim() || !newCreatorName.trim()) return;

    let handleClean = newCreatorHandle.trim();
    if (!handleClean.startsWith('@')) {
      handleClean = `@${handleClean}`;
    }

    const newProfile: CreatorPortfolioProfile = {
      id: `creator_${Date.now()}`,
      name: newCreatorName.trim(),
      handle: handleClean,
      avatar: newCreatorAvatar.trim() || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
      platform: newCreatorPlatform,
      niche: newCreatorNiche,
      totalReach: newCreatorReach.trim() || "500,000",
      avgVelocity: "180,000",
      engagementRate: "6.5%",
      bio: newCreatorBio.trim() || "Exclusive agency-represented creator with verified FTC compliance and high-converting vertical UGC assets.",
      nicheParameters: [
        { label: "Content Focus", value: `${newCreatorNiche} Vertical UGC` },
        { label: "Format Standard", value: "9:16 Vertical 4K UHD" },
        { label: "Audience Target", value: "Primary 18-34 Core Demographics" },
        { label: "Agency Clearance", value: "100% Whitelist & Spark Ads Cleared" }
      ],
      topUgcShorts: [
        {
          id: `ugc_${Date.now()}_1`,
          title: `${newCreatorNiche} High-Converting Showcase`,
          views: "340K views",
          format: "9:16 Vertical UHD",
          thumbnail: newCreatorAvatar || "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=500&auto=format&fit=crop&q=80",
          videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
          tags: [newCreatorNiche, "4K UGC", "Ad Whitelisted"]
        }
      ]
    };

    setPortfolios(prev => ({
      ...prev,
      [handleClean]: newProfile
    }));

    // Auto-map talent code
    const nextCodeNum = 100 + Object.keys(portfolios).length + 1;
    const newCode = `Creator #${nextCodeNum}`;
    setTalentCodes(prev => ({
      ...prev,
      [handleClean]: newCode
    }));

    setActiveHandle(handleClean);
    setIsAddCreatorOpen(false);

    // Reset form
    setNewCreatorName('');
    setNewCreatorHandle('');
    setNewCreatorBio('');
  };

  const fallbackCopyToClipboard = (text: string) => {
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).catch(() => {});
      }
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-9999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    } catch (e) {
      console.warn('Clipboard fallback error:', e);
    }
  };



  // Resolve active profile from activePortfolios
  const ANONYMOUS_BRAND_FALLBACK: CreatorPortfolioProfile = {
    id: 'anon_101',
    name: 'Creator #101 (Beauty & Lifestyle)',
    handle: 'Creator #101',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    platform: 'TikTok',
    niche: 'Beauty & Lifestyle',
    totalReach: '1.2M',
    avgVelocity: '145K',
    engagementRate: '6.8%',
    bio: 'Top-tier agency creator specializing in luxury beauty, skincare routines, and high-converting UGC brand integrations.',
    nicheParameters: [
      { label: 'Content Focus', value: 'Beauty & Skincare UGC' },
      { label: 'Platform Specialization', value: 'TikTok • Instagram Reels' },
      { label: 'Resolution & Specs', value: '9:16 Vertical UHD 4K' },
      { label: 'FTC Clear Status', value: 'Verified Compliant' }
    ],
    topUgcShorts: [
      {
        id: 'ugc_101_01',
        title: 'Hydrating Serum Morning Routine',
        views: '340K views',
        format: '9:16 Vertical UHD',
        thumbnail: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&auto=format&fit=crop&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        tags: ['Skincare', 'Unboxing', 'FTC Cleared']
      }
    ]
  };

  const rawProfile = activePortfolios[activeHandle] || Object.values(activePortfolios)[0] || (isBrandShare ? ANONYMOUS_BRAND_FALLBACK : INITIAL_SAMPLE_PORTFOLIOS['@elenarostova']);

  // Anonymized profile for anti-poaching if enabled
  const currentProfile: CreatorPortfolioProfile = (useTalentCodeMode && !isBrandShare)
    ? {
        ...rawProfile,
        name: `${activeTalentCodes[rawProfile?.handle] || rawProfile?.name || 'Exclusive Creator'} (${rawProfile?.niche || 'Specialist'})`,
        handle: `${activeTalentCodes[rawProfile?.handle] || rawProfile?.handle || 'Talent #101'}`
      }
    : rawProfile;

  const effectiveViewState = isBrandShare || currentRole === 'agentmgr' || isCreatorRole ? 'Public' : viewState;

  // Detect if opened via creator share link for anti-bypass audit & monitoring
  const [isCreatorSharedLink] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const hash = window.location.hash;
      return searchParams.get('ref') === 'creator_share' || hash.includes('ref=creator_share');
    }
    return false;
  });

  useEffect(() => {
    if (isCreatorSharedLink && typeof window !== 'undefined') {
      try {
        const logs = JSON.parse(safeStorage.getItem('bloom_brand_bypass_logs') || '[]');
        const logEntry = {
          id: `bypass_${Date.now()}`,
          creatorHandle: activeHandle,
          timestamp: new Date().toISOString(),
          source: 'Creator Shared Link Visit',
          status: 'Protected by Agency Shield'
        };
        if (!logs.some((l: any) => l.creatorHandle === activeHandle && Date.now() - new Date(l.timestamp).getTime() < 60000)) {
          logs.unshift(logEntry);
          safeStorage.setItem('bloom_brand_bypass_logs', JSON.stringify(logs.slice(0, 50)));
        }
      } catch (e) {}
    }
  }, [isCreatorSharedLink, activeHandle]);

  return (
    <div className="min-h-screen min-h-[100dvh] bg-agency-navy text-agency-textLight selection:bg-agency-gold selection:text-agency-navy w-full max-w-full overflow-x-hidden">
      {/* Agency Anti-Bypass Protection Banner */}
      {isCreatorSharedLink && (
        <div className="w-full bg-amber-950/90 border-b border-amber-500/50 px-4 py-3 text-center text-xs text-amber-200 font-mono flex items-center justify-center gap-2 shadow-lg z-50 sticky top-0">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            🛡️ <strong>BloomStudio Agency Anti-Bypass Protection:</strong> This portfolio was accessed via an authorized creator share link. All brand inquiries, bookings, and contracts are routed exclusively through BloomStudio Agency to prevent circumvention and ensure escrow safety.
          </span>
        </div>
      )}
      {/* Top Navigation Header */}
      <nav className="w-full bg-agency-navyLight/90 backdrop-blur-md border-b border-agency-gold/20 sticky top-0 z-40 px-3 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 w-full">
          
          {/* Logo & Agency Badge */}
          <div className="flex items-center justify-between w-full lg:w-auto gap-3 shrink-0">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-agency-gold text-agency-navy flex items-center justify-center font-serif font-bold text-base sm:text-lg shadow-md shrink-0">
                B
              </div>
              <div className="min-w-0">
                <span className="text-white font-serif font-bold text-sm sm:text-base tracking-wide block truncate">
                  Bloom Talent Showcase
                </span>
                <span className="text-[10px] font-mono text-agency-gold uppercase tracking-wider block truncate">
                  {useTalentCodeMode ? 'Anti-Poaching Talent Code Mode' : 'Direct Creator Portfolio'}
                </span>
              </div>
            </div>

            {/* Prominent Return to Agency Dashboard Button in Top Nav */}
            {onNavigateHome && (
              <button
                type="button"
                id="btn-nav-return-dashboard"
                onClick={onNavigateHome}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-agency-gold text-agency-navy font-bold text-xs hover:brightness-110 transition shadow cursor-pointer font-sans shrink-0"
                title={currentUser ? "Return to Agency Dashboard" : "Back to Home"}
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{currentUser ? "Agency" : "Back to"}</span>
                <span>{currentUser ? "Dashboard" : "Home"}</span>
              </button>
            )}

            {/* Mobile Add Creator Button */}
            {!isBrandShare && !isCreatorRole && canAddCreator && (
              <div className="flex items-center gap-1.5 md:hidden shrink-0">
                <button
                  type="button"
                  onClick={() => setShowDirectorMappingPanel(!showDirectorMappingPanel)}
                  className="px-2 py-1.5 rounded-lg bg-white/10 text-slate-200 text-xs font-mono"
                >
                  Codes
                </button>
                <button
                  type="button"
                  id="btn-mobile-add-creator"
                  onClick={() => setIsAddCreatorOpen(true)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#C9A46A] text-[#070D18] font-bold text-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add</span>
                </button>
              </div>
            )}
          </div>

          {/* Center Roster Selector - Hidden for creator role so creators only see their own portfolio */}
          {!isCreatorRole && (
            <div className="flex items-center gap-2 justify-center w-full lg:w-auto overflow-hidden min-w-0">
              <div className="flex items-center gap-1 bg-[#091122] border border-white/10 p-1 rounded-xl overflow-x-auto max-w-full scrollbar-thin scrollbar-thumb-agency-gold/30">
                {Object.keys(activePortfolios).map((handle) => {
                  const isSelected = activeHandle === handle;
                  const p = activePortfolios[handle];
                  const label = useTalentCodeMode ? (activeTalentCodes[handle] || p?.handle || handle) : (p?.handle || handle);

                  return (
                    <div key={handle} className="flex items-center group shrink-0 gap-0.5">
                      <button
                        type="button"
                        onClick={() => setActiveHandle(handle)}
                        className={`px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-lg text-xs font-mono transition cursor-pointer whitespace-nowrap ${
                          isSelected
                            ? 'bg-agency-gold text-agency-navy font-bold shadow-md'
                            : 'text-slate-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        {label}
                      </button>
                      


                      {/* Delete button on portfolio roster selector for Director / Agent */}
                      {!isBrandShare && isDirector && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteCreator(handle, p?.name || handle);
                          }}
                          className="text-slate-500 hover:text-rose-400 p-1 transition cursor-pointer"
                          title={`Delete ${p?.name || handle} from portfolio`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 flex-wrap justify-end shrink-0 w-full lg:w-auto">
            {/* Director Code Mapping Panel Toggle - Internal Agency Only */}
            {!isBrandShare && !isCreatorRole && (
              <button
                type="button"
                onClick={() => setShowDirectorMappingPanel(!showDirectorMappingPanel)}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-[11px] font-mono transition cursor-pointer shrink-0 ${
                  showDirectorMappingPanel
                    ? 'bg-[#C9A46A] text-[#0A1220] font-bold border-[#C9A46A]'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
                }`}
                title="View Director's Creator Number Mapping Ledger (who belongs to which Creator #)"
              >
                <Shield className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Creator # Directory</span>
                <span className="sm:hidden">Codes</span>
              </button>
            )}

            {/* Anti-Poaching / Number Switcher Toggle - Internal Agency Only */}
            {!isBrandShare && !isCreatorRole && (
              <button
                type="button"
                onClick={() => setUseTalentCodeMode(!useTalentCodeMode)}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-[11px] font-mono transition cursor-pointer shrink-0 ${
                  useTalentCodeMode
                    ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:text-white'
                }`}
                title="Toggle between Creator #ID codes (prevents direct contact) and public handles"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{useTalentCodeMode ? 'Talent #ID Mask' : 'Show Names'}</span>
              </button>
            )}

            {/* Copy Portfolio Link - Strictly restricted to Agency & Creator (Never Brands) */}
            {!isBrandShare && (
              <button
                type="button"
                onClick={() => {
                  const url = `${window.location.origin}/#portfolio?creator=${encodeURIComponent(activeHandle)}&ref=creator_share`;
                  navigator.clipboard.writeText(url);
                  alert(`Copied secure trackable link for ${activeHandle}! All visits & brand inquiries will be monitored by BloomStudio Agency.`);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-[#C9A46A] border border-[#C9A46A]/30 font-mono font-bold text-xs transition cursor-pointer shadow shrink-0"
                title="Copy secure shareable link for this creator portfolio"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Link</span>
              </button>
            )}

            {/* Add Creator Modal Trigger - Gated by Director switch */}
            {!isBrandShare && !isCreatorRole && canAddCreator && (
              <button
                type="button"
                id="btn-add-creator-portfolio"
                onClick={() => setIsAddCreatorOpen(true)}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-agency-gold text-agency-navy font-mono font-bold text-xs uppercase tracking-wider hover:brightness-110 transition cursor-pointer shadow shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Creator</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* DIRECTOR PANEL: Creator Number Mapping Ledger */}
      {showDirectorMappingPanel && !isBrandShare && (
        <section className="bg-[#091122] border-b border-[#C9A46A]/30 p-3 sm:p-6 shadow-2xl animate-fade-in w-full max-w-full overflow-hidden">
          <div className="max-w-7xl mx-auto space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#C9A46A]" />
                  <h2 className="text-sm font-serif font-bold text-white uppercase tracking-wider">
                    [🔒 Director Panel: Talent Code &amp; Identity Mapping Directory]
                  </h2>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Internal mapping showing which anonymous Creator # corresponds to each creator's real identity, handle, and metrics.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by code, name, handle..."
                    value={mappingSearch}
                    onChange={e => setMappingSearch(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setShowDirectorMappingPanel(false)}
                  className="text-slate-400 hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Mapping Table */}
            <div className="overflow-x-auto rounded-xl border border-white/10 bg-black/30">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#0D1830] text-slate-300 border-b border-white/10">
                  <tr>
                    <th className="p-3 text-[#C9A46A]">Talent Code #</th>
                    <th className="p-3">Real Creator Name</th>
                    <th className="p-3">Handle</th>
                    <th className="p-3">Niche &amp; Platform</th>
                    <th className="p-3">Reach &amp; Velocity</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {Object.keys(visiblePortfolios)
                    .filter(handle => {
                      if (!mappingSearch.trim()) return true;
                      const q = mappingSearch.toLowerCase();
                      const p = visiblePortfolios[handle];
                      const code = (talentCodes[handle] || '').toLowerCase();
                      return (
                        code.includes(q) ||
                        handle.toLowerCase().includes(q) ||
                        (p?.name || '').toLowerCase().includes(q) ||
                        (p?.niche || '').toLowerCase().includes(q)
                      );
                    })
                    .map(handle => {
                      const p = visiblePortfolios[handle];
                      const code = talentCodes[handle] || 'Creator #101';
                      const isCurrent = activeHandle === handle;

                      return (
                        <tr key={handle} className={`hover:bg-white/5 transition ${isCurrent ? 'bg-[#C9A46A]/10' : ''}`}>
                          <td className="p-3 font-bold text-[#C9A46A] whitespace-nowrap">
                            <span className="px-2.5 py-1 rounded-md bg-[#C9A46A]/10 border border-[#C9A46A]/30">
                              {code}
                            </span>
                          </td>
                          <td className="p-3 font-bold text-white">
                            <div className="flex items-center gap-2">
                              <div className="relative group shrink-0">
                                <img 
                                  src={p?.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100"} 
                                  alt={p?.name} 
                                  className="w-8 h-8 rounded-full object-cover border border-white/10" 
                                  referrerPolicy="no-referrer"
                                />
                                {isDirector && (
                                  <label className="absolute inset-0 bg-black/70 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer" title="Upload new profile photo">
                                    <Upload className="w-3.5 h-3.5 text-[#C9A46A]" />
                                    <input
                                      type="file"
                                      accept="image/*"
                                      className="hidden"
                                      onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) handleDirectPhotoUpload(handle, file);
                                      }}
                                    />
                                  </label>
                                )}
                              </div>
                              <span>{p?.name}</span>
                            </div>
                          </td>
                          <td className="p-3 text-slate-300">{handle}</td>
                          <td className="p-3 text-slate-400">
                            <span className="px-2 py-0.5 rounded bg-white/5 text-slate-300">
                              {p?.niche} • {p?.platform}
                            </span>
                          </td>
                          <td className="p-3 text-emerald-400 font-bold">
                            {p?.totalReach} reach • {p?.engagementRate} eng
                          </td>
                          <td className="p-3 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveHandle(handle);
                                  setShowDirectorMappingPanel(false);
                                }}
                                className="px-2.5 py-1 rounded bg-[#C9A46A]/20 hover:bg-[#C9A46A] text-[#C9A46A] hover:text-[#0A1220] transition font-bold"
                              >
                                View
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteCreator(handle, p?.name || handle)}
                                className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
                                title="Delete creator"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      {/* Main Dynamic Media Kit Display */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-12 pb-32 sm:pb-44">
        {rawProfile ? (
          <>


            <DynamicCreatorMediaKit 
              key={activeHandle}
              profile={currentProfile} 
              viewState={effectiveViewState}
              currentRole={currentRole}
              isBrandShare={isBrandShare}
            />

            {/* Brand Share Sign-Up CTA - Only rendered in brand-share limited mode */}
            {isBrandShare && (
              <div className="bg-gradient-to-r from-[#0E1B33] via-[#132446] to-[#0E1B33] border border-[#C9A46A]/40 rounded-3xl p-6 sm:p-10 text-center space-y-4 shadow-2xl relative overflow-hidden mt-8">
                <div className="absolute -top-12 -right-12 w-48 h-48 bg-[#C9A46A]/10 rounded-full blur-3xl pointer-events-none" />
                <div className="inline-flex items-center gap-2 text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-widest">
                  <Sparkles className="w-4 h-4" />
                  <span>Unlock Complete Creator Roster</span>
                </div>
                <h3 className="text-xl sm:text-2xl md:text-3xl font-serif font-bold text-white max-w-2xl mx-auto leading-tight">
                  Want to see our full creator roster? Create a free account to unlock the complete list.
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto font-sans leading-relaxed">
                  Gain immediate access to our 100+ talent database across Beauty, Pets, and Lifestyle, connect with agency managers for custom campaign proposals, and check live creator availability.
                </p>
                <div className="pt-3">
                  <button
                    type="button"
                    id="btn-brand-share-signup-cta"
                    onClick={() => {
                      setShowFreeAccountModal(true);
                      if (onStartAgencySignup) onStartAgencySignup();
                    }}
                    className="inline-flex items-center gap-2.5 px-8 py-3.5 rounded-2xl bg-[#C9A46A] hover:bg-amber-400 text-[#0A1220] font-mono font-bold text-xs sm:text-sm uppercase tracking-wider transition-all shadow-xl active:scale-95 cursor-pointer"
                  >
                    <span>Create Free Account</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-12 text-center space-y-4">
            <Users className="w-12 h-12 text-slate-500 mx-auto" />
            <h3 className="text-lg font-bold text-white">No Creator Profiles Found</h3>
            <p className="text-xs text-slate-400">
              {canAddCreator 
                ? 'Click "Add Creator" above to create a new talent media kit showcase.' 
                : 'No creator profiles matching current assignment filter.'}
            </p>
            {canAddCreator && (
              <button
                type="button"
                id="btn-empty-state-add-creator"
                onClick={() => setIsAddCreatorOpen(true)}
                className="px-6 py-2.5 rounded-xl bg-[#C9A46A] text-[#0A1220] font-bold text-xs cursor-pointer"
              >
                Add New Creator
              </button>
            )}
          </div>
        )}
      </main>

      {/* Modal: Add New Creator to Showcase */}
      {isAddCreatorOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/50 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl text-white space-y-5 animate-fade-in">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-lg font-serif font-bold text-white">Add Creator to Portfolio</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddCreatorOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCreatorSubmit} className="space-y-4 text-xs font-mono">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Creator Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Marcus Vance"
                    value={newCreatorName}
                    onChange={(e) => setNewCreatorName(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Social Handle *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. @marcus_vfx"
                    value={newCreatorHandle}
                    onChange={(e) => setNewCreatorHandle(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Niche</label>
                  <select
                    value={newCreatorNiche}
                    onChange={(e) => setNewCreatorNiche(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="Beauty">Beauty</option>
                    <option value="Lifestyle">Lifestyle</option>
                    <option value="Pets">Pets</option>
                    <option value="Tech">Tech</option>
                    <option value="Fitness">Fitness</option>
                    <option value="Food & Beverage">Food &amp; Beverage</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Platform</label>
                  <select
                    value={newCreatorPlatform}
                    onChange={(e) => setNewCreatorPlatform(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="TikTok">TikTok</option>
                    <option value="Instagram">Instagram</option>
                    <option value="YouTube">YouTube</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Total Reach</label>
                  <input
                    type="text"
                    placeholder="e.g. 740,000"
                    value={newCreatorReach}
                    onChange={(e) => setNewCreatorReach(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Avatar Image URL</label>
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/..."
                  value={newCreatorAvatar}
                  onChange={(e) => setNewCreatorAvatar(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Bio / Specialty</label>
                <textarea
                  rows={3}
                  placeholder="Describe creator's content specialty and audience resonance..."
                  value={newCreatorBio}
                  onChange={(e) => setNewCreatorBio(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddCreatorOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-white/10 text-slate-300 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#C9A46A] text-[#070D18] font-bold uppercase tracking-wider hover:brightness-110 cursor-pointer shadow-lg"
                >
                  Add Creator Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sticky Inbound Agency Call-to-Action Banner:
          Automatically hides when the user scrolls down to the Portfolio Contact Footer
          to avoid showing duplicate "Submit Booking" buttons.
          Agency Portal link is strictly removed when shared with brands. */}
      {rawProfile && !isFooterVisible && (
        <aside className="sticky bottom-0 z-30 w-full bg-agency-navyLight/95 backdrop-blur-lg border-t-2 border-agency-gold p-4 shadow-2xl transition-all duration-300">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-agency-gold shrink-0 animate-pulse" />
              <div>
                <span className="text-xs sm:text-sm font-serif font-bold text-white block">
                  Interested in collaborating with {currentProfile.name}?
                </span>
                <span className="text-[11px] font-mono text-slate-300">
                  100% FTC compliance, guaranteed usage rights, and seamless talent bookings.
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto shrink-0">
              <button
                type="button"
                id="btn-sticky-booking-inquiry"
                onClick={() => {
                  window.dispatchEvent(new CustomEvent('open-booking-modal'));
                  const el = document.getElementById('portfolio-contact-footer');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-agency-gold text-agency-navy text-xs font-mono font-bold uppercase tracking-wider hover:brightness-110 active:scale-95 transition shadow-lg cursor-pointer"
              >
                <Sparkles className="w-4 h-4 shrink-0" />
                <span>Submit Booking Inquiry</span>
              </button>

              {onNavigateHome && (
                <button
                  type="button"
                  onClick={onNavigateHome}
                  className="px-4 py-2.5 rounded-xl bg-agency-navy border border-white/20 text-slate-300 hover:text-white text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer"
                >
                  {currentUser ? "Agency Operations" : "Return Home"}
                </button>
              )}
            </div>
          </div>
        </aside>
      )}



      {/* Free Brand Account Modal */}
      {showFreeAccountModal && (
        <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0D1829] border border-[#C9A46A]/50 rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative text-left">
            <button
              type="button"
              onClick={() => setShowFreeAccountModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#C9A46A]/15 border border-[#C9A46A]/30 flex items-center justify-center text-[#C9A46A] shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white font-sans">Create Free Brand Account</h3>
                <p className="text-xs text-slate-400">Unlock complete creator roster & custom campaign proposals</p>
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const emailToUse = freeAccountForm.email.trim() || 'brand.partner@agency.com';
                try {
                  localStorage.setItem('bloom_free_brand_account', JSON.stringify({
                    brandName: freeAccountForm.brandName || 'Brand Partner',
                    contactName: freeAccountForm.contactName || 'Partner Lead',
                    email: emailToUse,
                    timestamp: new Date().toISOString()
                  }));
                } catch {}

                if (onLogin) {
                  onLogin(emailToUse, 'brand');
                } else {
                  if (typeof window !== 'undefined') {
                    // Remove brand=true restriction from location
                    const newPath = window.location.pathname + '#public-portfolio';
                    window.history.replaceState(null, '', newPath);
                    window.dispatchEvent(new CustomEvent('brand-account-created'));
                  }
                }
                setShowFreeAccountModal(false);
              }}
              className="space-y-4 pt-1"
            >
              <div>
                <label className="block text-xs font-mono text-[#C9A46A] uppercase tracking-wider mb-1.5">
                  Brand / Organization Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Glossier, Nike, or Brand Agency"
                  value={freeAccountForm.brandName}
                  onChange={(e) => setFreeAccountForm({ ...freeAccountForm, brandName: e.target.value })}
                  className="w-full bg-[#070D18] border border-white/20 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#C9A46A] uppercase tracking-wider mb-1.5">
                  Contact Person Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Sarah Chen (Partnership Lead)"
                  value={freeAccountForm.contactName}
                  onChange={(e) => setFreeAccountForm({ ...freeAccountForm, contactName: e.target.value })}
                  className="w-full bg-[#070D18] border border-white/20 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#C9A46A] uppercase tracking-wider mb-1.5">
                  Work Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="sarah@brand.com"
                  value={freeAccountForm.email}
                  onChange={(e) => setFreeAccountForm({ ...freeAccountForm, email: e.target.value })}
                  className="w-full bg-[#070D18] border border-white/20 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowFreeAccountModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-mono text-slate-400 hover:text-white transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-submit-free-account"
                  className="px-6 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-amber-400 text-[#0A1220] font-mono font-bold text-xs uppercase tracking-wider transition shadow-lg cursor-pointer"
                >
                  Create Free Account & Unlock Roster
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
