/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * StripeDebitCardController.tsx
 * 
 * Secure 'Lock-by-Default' Just-In-Time (JIT) corporate debit card architecture
 * integrated with Stripe Issuing endpoints. Manages creator production expense
 * unlock requests, managerial approval limits ($250 Agent Manager cap vs. Director),
 * webhook simulation cycles, and zero-trust fund isolation.
 */

import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  CreditCard,
  Lock,
  Unlock,
  ShieldCheck,
  ShieldAlert,
  Clock,
  DollarSign,
  FileText,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Send,
  Upload,
  Receipt,
  Eye,
  EyeOff,
  ChevronRight,
  Terminal,
  Zap,
  ArrowUpRight,
  Sparkles,
  Sliders,
  Check,
  User,
  Layers,
  HelpCircle,
} from "lucide-react";
import { collection, doc, setDoc, getDocs, onSnapshot, updateDoc, query, where } from "firebase/firestore";
import { db, auth } from "../lib/firebase";
import { Creator, Role } from "../types";
import { safeStorage } from "../utils/safeStorage";

export interface ExpenseRequest {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  purpose: string;
  amount: number;
  campaignId: string;
  campaignName: string;
  campaignNiche: string;
  status: "Awaiting_Manager_Clearance" | "Approved" | "Denied" | "Settled_Locked";
  createdAt: string;
  approvedAt?: string;
  approvedBy?: string;
  approverRole?: string;
  deniedReason?: string;
  receiptUrl?: string;
  receiptSubmittedAt?: string;
  cardLast4: string;
  stripeCardId: string;
  temporaryLimitExpiresAt?: string;
}

interface StripeDebitCardControllerProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: Role | string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: "success" | "info" | "warning" | "danger") => void;
}

const INITIAL_EXPENSE_REQUESTS: ExpenseRequest[] = [
  {
    id: "exp_req_101",
    creatorId: "c3",
    creatorName: "Chloe Bennett",
    creatorHandle: "@chloebennett",
    purpose: "Botanical Styling Oil Blend & Studio Lighting Props",
    amount: 145.50,
    campaignId: "camp_glow_2026",
    campaignName: "GlowBar Botanicals Summer Campaign",
    campaignNiche: "Cosmetics & Beauty",
    status: "Awaiting_Manager_Clearance",
    createdAt: "2026-08-31 06:15",
    cardLast4: "4829",
    stripeCardId: "ic_prod_card_4829",
  },
  {
    id: "exp_req_102",
    creatorId: "c2",
    creatorName: "Marcus Vance",
    creatorHandle: "@marcusvance",
    purpose: "High-Speed Carbon Tripod Mount & Gyro Stabilizer",
    amount: 320.00,
    campaignId: "camp_gym_2026",
    campaignName: "GymPulse High-Performance Athletic Reel",
    campaignNiche: "Fitness & Technology",
    status: "Awaiting_Manager_Clearance",
    createdAt: "2026-08-31 06:40",
    cardLast4: "4829",
    stripeCardId: "ic_prod_card_4829",
  },
  {
    id: "exp_req_103",
    creatorId: "c1",
    creatorName: "Sarah Jenkins",
    creatorHandle: "@sarahj_style",
    purpose: "Sample Wardrobe Backdrop & Color Chart Swatches",
    amount: 88.00,
    campaignId: "camp_nord_2026",
    campaignName: "Nordic Glow Autumn Showcase",
    campaignNiche: "Luxury & Apparel",
    status: "Approved",
    createdAt: "2026-08-31 05:30",
    approvedAt: "2026-08-31 05:45",
    approvedBy: "Director Admin",
    approverRole: "director",
    cardLast4: "4829",
    stripeCardId: "ic_prod_card_4829",
    temporaryLimitExpiresAt: new Date(Date.now() + 24 * 60 * 1000).toISOString(),
  },
];

export const StripeDebitCardController: React.FC<StripeDebitCardControllerProps> = ({
  creators = [],
  currentUser,
  currentRole = "director",
  onAddActivityLog,
  triggerNotification,
}) => {
  const roleLower = String(currentRole || "").toLowerCase();
  const isCreatorView = roleLower === "creator";
  const isAgentManager = roleLower === "agentmgr" || roleLower === "agentmanager";
  const isDirector = roleLower === "director" || roleLower === "owner";

  // Active View Tab (for Director/Manager to test Talent vs Management views)
  const [activePortalTab, setActivePortalTab] = useState<"talent_form" | "management_matrix" | "stripe_terminal">(
    isCreatorView ? "talent_form" : "management_matrix"
  );

  // Firestore & Local State
  const [requests, setRequests] = useState<ExpenseRequest[]>(() => {
    try {
      const saved = safeStorage.getItem("bloom_expense_requests");
      return saved ? JSON.parse(saved) : INITIAL_EXPENSE_REQUESTS;
    } catch {
      return INITIAL_EXPENSE_REQUESTS;
    }
  });

  // Sync to safeStorage
  useEffect(() => {
    try {
      safeStorage.setItem("bloom_expense_requests", JSON.stringify(requests));
    } catch {}
  }, [requests]);

  // Listen to Firestore if available
  useEffect(() => {
    try {
      const isOwner = !!currentUser?.isPlatformOwner && currentUser?.email === 'admin@bloom.studio';
      const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
      const userRoleLower = (currentRole || '').toLowerCase();
      const isStaffOrDirector = ['director', 'agentmgr', 'agency', 'subagency', 'owner'].includes(userRoleLower);

      let baseQuery;
      if (isOwner) {
        baseQuery = collection(db, "expense-requests");
      } else if (isStaffOrDirector) {
        baseQuery = query(
          collection(db, "expense-requests"),
          where("subagency", "==", userPod)
        );
      } else {
        baseQuery = query(
          collection(db, "expense-requests"),
          where("creatorId", "==", currentUser?.uid || currentUser?.id || "none")
        );
      }

      const unsubscribe = onSnapshot(
        baseQuery,
        (snapshot) => {
          if (!snapshot.empty) {
            const firestoreItems: ExpenseRequest[] = [];
            snapshot.forEach((d) => {
              firestoreItems.push({ id: d.id, ...(d.data() as any) });
            });
            if (firestoreItems.length > 0) {
              setRequests(firestoreItems);
            }
          }
        },
        (error) => {
          console.warn("[StripeDebitCardController] Firestore listener note:", error.message);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn("[StripeDebitCardController] Firestore init note:", e);
    }
  }, []);

  // Talent Expense Request Form State
  const [expensePurpose, setExpensePurpose] = useState("");
  const [requestedAmount, setRequestedAmount] = useState("");
  const [selectedCampaign, setSelectedCampaign] = useState("camp_glow_2026");
  const [selectedCreatorId, setSelectedCreatorId] = useState(
    isCreatorView && currentUser?.id ? currentUser.id : "c3"
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formSuccessMessage, setFormSuccessMessage] = useState<string | null>(null);

  // Stripe Issuing Card Simulation State
  const [cardStatus, setCardStatus] = useState<"inactive" | "active">("inactive");
  const [activeCardLimit, setActiveCardLimit] = useState<number>(0.0);
  const [activeAuthorizedPurpose, setActiveAuthorizedPurpose] = useState<string>("");
  const [activeRequestId, setActiveRequestId] = useState<string | null>(null);
  const [webhookLogs, setWebhookLogs] = useState<Array<{ time: string; event: string; payload: string; status: "success" | "warn" | "info" }>>([
    {
      time: "06:00:00",
      event: "card.spending_controls.lock",
      payload: '{"card_id":"ic_prod_card_4829","spending_limits":[{"amount":0,"interval":"per_authorization"}],"status":"inactive"}',
      status: "info",
    },
  ]);

  // Deny Modal State
  const [denyingRequestId, setDenyingRequestId] = useState<string | null>(null);
  const [denyReason, setDenyReason] = useState("");

  // Campaign Lookup List
  const availableCampaigns = useMemo(
    () => [
      { id: "camp_glow_2026", name: "GlowBar Botanicals Summer Campaign", niche: "Cosmetics & Beauty" },
      { id: "camp_gym_2026", name: "GymPulse High-Performance Athletic Reel", niche: "Fitness & Technology" },
      { id: "camp_nord_2026", name: "Nordic Glow Autumn Showcase", niche: "Luxury & Apparel" },
      { id: "camp_zen_2026", name: "Zenith Soundproofing UGC Blitz", niche: "Consumer Electronics" },
    ],
    []
  );

  // Active creator profile lookup
  const matchedCreator = useMemo(() => {
    return (
      creators.find((c) => c.id === selectedCreatorId) || {
        id: selectedCreatorId,
        name: currentUser?.name || "Chloe Bennett",
        handle: currentUser?.handle || "@chloebennett",
      }
    );
  }, [creators, selectedCreatorId, currentUser]);

  // Submit Expense Authorization Request
  const handleSubmitExpenseRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(requestedAmount);

    if (!expensePurpose.trim() || isNaN(numAmount) || numAmount <= 0) {
      alert("Please provide an itemized expense purpose and a valid numeric amount ($).");
      return;
    }

    setIsSubmitting(true);
    const targetCamp = availableCampaigns.find((c) => c.id === selectedCampaign) || availableCampaigns[0];
    const newId = `exp_req_${Date.now()}`;

    const newRequest: ExpenseRequest & { subagency?: string } = {
      id: newId,
      creatorId: matchedCreator.id,
      creatorName: matchedCreator.name,
      creatorHandle: (matchedCreator as any).handle || "@creator",
      purpose: expensePurpose.trim(),
      amount: parseFloat(numAmount.toFixed(2)),
      campaignId: targetCamp.id,
      campaignName: targetCamp.name,
      campaignNiche: targetCamp.niche,
      status: "Awaiting_Manager_Clearance",
      createdAt: new Date().toISOString().replace("T", " ").substring(0, 16),
      cardLast4: "4829",
      stripeCardId: "ic_prod_card_4829",
      subagency: currentUser?.subagency || currentUser?.tenantId || "pod_main",
    };

    try {
      // 1. Submit to server-side API with authentication token
      let serverSucceeded = false;
      try {
        const token = auth.currentUser ? await auth.currentUser.getIdToken() : null;
        if (token) {
          const resp = await fetch("/api/stripe/issuing/request-expense", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              purpose: expensePurpose.trim(),
              amount: numAmount,
              campaignId: targetCamp.id,
              campaignName: targetCamp.name,
              campaignNiche: targetCamp.niche,
              creatorId: matchedCreator.id,
              creatorName: matchedCreator.name,
              creatorHandle: (matchedCreator as any).handle || "@creator",
              subagency: currentUser?.subagency || currentUser?.tenantId || "pod_main",
            }),
          });
          const result = await resp.json();
          if (resp.ok && result.success) {
            serverSucceeded = true;
            if (result.request) {
              setRequests((prev) => [result.request, ...prev.filter((r) => r.id !== result.request.id)]);
            }
          } else {
            console.warn("[StripeDebitCardController] Server request-expense note:", result.error);
          }
        }
      } catch (srvErr) {
        console.warn("[StripeDebitCardController] Server call note:", srvErr);
      }

      if (!serverSucceeded) {
        // Fallback local & direct Firestore write
        setRequests((prev) => [newRequest, ...prev]);
        try {
          const docRef = doc(db, "expense-requests", newId);
          await setDoc(docRef, newRequest);
        } catch (err: any) {
          console.warn("[StripeDebitCardController] Firestore direct write note:", err.message);
        }
      }

      // 3. Log activity
      onAddActivityLog?.(
        currentUser?.name || matchedCreator.name,
        currentRole || "Creator",
        `Submitted Stripe JIT expense authorization request of $${numAmount.toFixed(2)} for ${expensePurpose.trim()}`
      );

      triggerNotification?.(
        "Expense Request Submitted",
        `Request for $${numAmount.toFixed(2)} (${expensePurpose}) logged with status: Awaiting_Manager_Clearance`,
        "info"
      );

      setFormSuccessMessage(`Request #${newId.slice(-6)} filed! Card will remain locked at $0.00 until manager approval.`);
      setExpensePurpose("");
      setRequestedAmount("");
      setTimeout(() => setFormSuccessMessage(null), 6000);
    } catch (error: any) {
      console.error("Error submitting expense request:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Management Approve & Unlock Stripe Limit
  const handleApproveRequest = async (req: ExpenseRequest) => {
    // Manager Limit Check: Agent Managers capped at $250.00
    if (isAgentManager && req.amount > 250.0) {
      alert(`Approval Blocked: Agent Managers are authorized up to a strict $250.00 ceiling. This request is for $${req.amount.toFixed(2)}. Director clearance required.`);
      return;
    }

    try {
      const token = auth.currentUser ? await auth.currentUser.getIdToken() : null;
      let serverSucceeded = false;
      let stripeLogData: any = null;

      if (!token) {
        alert("Authentication required to authorize corporate card limits.");
        return;
      }

      const resp = await fetch("/api/stripe/issuing/approve-expense", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ requestId: req.id }),
      });
      const result = await resp.json();
      if (resp.ok && result.success) {
        serverSucceeded = true;
        stripeLogData = result.stripeLog;
        if (result.updatedRequest) {
          setRequests((prev) => prev.map((item) => (item.id === req.id ? result.updatedRequest : item)));
        }
      } else {
        alert(`Server Error: ${result.error || "Failed to approve request."}`);
        return;
      }

      const expiry = new Date(Date.now() + 30 * 60 * 1000).toISOString();
      const updatedReq: ExpenseRequest = {
        ...req,
        status: "Approved",
        approvedAt: new Date().toISOString().replace("T", " ").substring(0, 16),
        approvedBy: currentUser?.name || (isDirector ? "Director HQ" : "Agent Manager"),
        approverRole: currentRole || (isDirector ? "director" : "agentmgr"),
        temporaryLimitExpiresAt: expiry,
      };

      setCardStatus("active");
      setActiveCardLimit(req.amount);
      setActiveAuthorizedPurpose(req.purpose);
      setActiveRequestId(req.id);

      const webhookEvent = {
        time: new Date().toTimeString().split(" ")[0],
        event: "issuing_card.updated",
        payload: JSON.stringify(
          stripeLogData || {
            card_id: req.stripeCardId,
            spending_controls: {
              spending_limits: [
                {
                  amount: Math.round(req.amount * 100),
                  currency: "usd",
                  interval: "per_authorization",
                },
              ],
            },
            status: "active",
            metadata: {
              expense_request_id: req.id,
              authorized_purpose: req.purpose,
              creator_handle: req.creatorHandle,
              approved_by: updatedReq.approvedBy,
              expires_at: expiry,
            },
          }
        ),
        status: "success" as const,
      };

      setWebhookLogs((prev) => [webhookEvent, ...prev]);

      onAddActivityLog?.(
        currentUser?.name || "Management",
        currentRole || "none",
        `Approved Stripe JIT Card unlock of $${req.amount.toFixed(2)} for ${req.creatorHandle} (${req.purpose})`
      );

      triggerNotification?.(
        "💳 Stripe Limit Unlocked",
        `Card ending in ${req.cardLast4} provisioned with exact limit of $${req.amount.toFixed(2)} (Active for 30m)`,
        "success"
      );
    } catch (err: any) {
      console.error("Error approving request:", err);
      alert(`Approval error: ${err.message}`);
    }
  };

  // Management Deny Request
  const handleDenyRequest = async () => {
    if (!denyingRequestId) return;
    const reason = denyReason.trim() || "Expense does not align with active campaign budget allocations.";

    const targetReq = requests.find((r) => r.id === denyingRequestId);
    if (!targetReq) return;

    try {
      const token = auth.currentUser ? await auth.currentUser.getIdToken() : null;
      let serverSucceeded = false;

      if (token) {
        const resp = await fetch("/api/stripe/issuing/deny-expense", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ requestId: denyingRequestId, reason }),
        });
        const result = await resp.json();
        if (resp.ok && result.success) {
          serverSucceeded = true;
          if (result.updatedRequest) {
            setRequests((prev) => prev.map((item) => (item.id === denyingRequestId ? result.updatedRequest : item)));
          }
        }
      }

      const updatedReq: ExpenseRequest = {
        ...targetReq,
        status: "Denied",
        deniedReason: reason,
      };

      if (!serverSucceeded) {
        setRequests((prev) => prev.map((item) => (item.id === denyingRequestId ? updatedReq : item)));
        try {
          const docRef = doc(db, "expense-requests", denyingRequestId);
          await setDoc(docRef, updatedReq, { merge: true });
        } catch (e: any) {
          console.warn("[StripeDebitCardController] Firestore update note:", e.message);
        }
      }

      onAddActivityLog?.(
        currentUser?.name || "Management",
        currentRole || "none",
        `Denied expense request #${denyingRequestId.slice(-6)}: ${reason}`
      );

      triggerNotification?.("Expense Request Denied", `Request #${denyingRequestId.slice(-6)} set to Denied`, "danger");

      setDenyingRequestId(null);
      setDenyReason("");
    } catch (err: any) {
      console.error("Error denying expense request:", err);
    }
  };

  // Simulate Instant Webhook Swipe & Auto-Reset Callback
  const handleSimulateSwipeAndLock = async () => {
    if (!activeRequestId || activeCardLimit <= 0) return;

    const targetReq = requests.find((r) => r.id === activeRequestId);
    const chargedAmount = activeCardLimit;

    // Reset card limit to zero ($0.00) & status to inactive
    setCardStatus("inactive");
    setActiveCardLimit(0.0);

    try {
      const token = auth.currentUser ? await auth.currentUser.getIdToken() : null;
      if (token) {
        const resp = await fetch("/api/stripe/issuing/simulate-card-swipe", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            requestId: activeRequestId,
            amount: chargedAmount,
          }),
        });
        const result = await resp.json();
        if (resp.ok && result.success && Array.isArray(result.events)) {
          setWebhookLogs((prev) => [...result.events, ...prev]);
          if (result.updatedRequest) {
            setRequests((prev) => prev.map((item) => (item.id === activeRequestId ? result.updatedRequest : item)));
          }
          triggerNotification?.(
            "🔒 Card Auto-Locked to $0.00",
            `Swipe of $${chargedAmount.toFixed(2)} captured. Stripe card immediately reset to $0.00 pending receipt PNG submission.`,
            "warning"
          );
          return;
        }
      }
    } catch (err) {
      console.warn("[StripeDebitCardController] Server swipe simulation note:", err);
    }

    const swipeTime = new Date().toTimeString().split(" ")[0];

    const authLog = {
      time: swipeTime,
      event: "issuing_authorization.request",
      payload: JSON.stringify({
        id: `iauth_${Date.now()}`,
        amount: Math.round(chargedAmount * 100),
        currency: "usd",
        approved: true,
        merchant_data: { name: "BEAUTY & STUDIO SUPPLIES CO", category: "cosmetics_and_supplies" },
        card_id: "ic_prod_card_4829",
      }),
      status: "info" as const,
    };

    const resetLog = {
      time: swipeTime,
      event: "issuing_card.instant_relock_callback",
      payload: JSON.stringify({
        card_id: "ic_prod_card_4829",
        spending_controls: { spending_limits: [{ amount: 0, interval: "per_authorization" }] },
        status: "inactive",
        reason: "authorization_captured_awaiting_receipt_blob",
      }),
      status: "warn" as const,
    };

    setWebhookLogs((prev) => [resetLog, authLog, ...prev]);

    triggerNotification?.(
      "🔒 Card Auto-Locked to $0.00",
      `Swipe of $${chargedAmount.toFixed(2)} captured. Stripe card immediately reset to $0.00 pending receipt PNG submission.`,
      "warning"
    );
  };

  return (
    <div id="stripe-debit-card-controller" className="w-full space-y-6 text-white font-sans">
      {/* Top Banner & Mode Selector */}
      <div className="bg-[#0B1B3D] border border-[#142850] rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-white/5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-[#142850] border border-[#D4AF37]/30 rounded-2xl text-[#D4AF37] shadow-lg shadow-[#D4AF37]/5">
                <CreditCard className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white font-serif">
                    Stripe Issuing JIT Controller
                  </h1>
                  <span className="px-2.5 py-0.5 bg-[#142850] border border-[#D4AF37]/40 text-[#D4AF37] text-[10px] font-bold tracking-widest uppercase rounded-full">
                    Lock-By-Default
                  </span>
                </div>
                <p className="text-xs text-[#7C8AA8] mt-0.5">
                  Automated $0.00 baseline corporate production card limits with JIT approval pipelines and instant webhook relock triggers.
                </p>
              </div>
            </div>
          </div>

          {/* Tab Switcher */}
          <div className="flex items-center gap-2 bg-[#142850] p-1.5 rounded-2xl border border-white/5 self-start lg:self-auto">
            <button
              onClick={() => setActivePortalTab("talent_form")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activePortalTab === "talent_form"
                  ? "bg-[#D4AF37] text-[#0B1B3D] shadow-lg shadow-[#D4AF37]/15"
                  : "text-[#7C8AA8] hover:text-white"
              }`}
            >
              <User className="w-3.5 h-3.5" />
              Talent Request Portal
            </button>
            <button
              onClick={() => setActivePortalTab("management_matrix")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activePortalTab === "management_matrix"
                  ? "bg-[#D4AF37] text-[#0B1B3D] shadow-lg shadow-[#D4AF37]/15"
                  : "text-[#7C8AA8] hover:text-white"
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              Manager Authorization Matrix
            </button>
            <button
              onClick={() => setActivePortalTab("stripe_terminal")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activePortalTab === "stripe_terminal"
                  ? "bg-[#D4AF37] text-[#0B1B3D] shadow-lg shadow-[#D4AF37]/15"
                  : "text-[#7C8AA8] hover:text-white"
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              Stripe Webhook Terminal
            </button>
          </div>
        </div>

        {/* Live Card Status Bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-[#142850] border border-white/5 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-bold uppercase tracking-wider">Default Baseline Limit</span>
              <p className="text-xl font-mono font-bold text-white mt-1">$0.00 USD</p>
            </div>
            <div className="p-2.5 bg-[#0B1B3D] border border-white/5 rounded-xl text-emerald-400">
              <Lock className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-[#142850] border border-white/5 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-bold uppercase tracking-wider">Active Authorized Limit</span>
              <p className="text-xl font-mono font-bold text-[#D4AF37] mt-1">
                ${activeCardLimit.toFixed(2)} USD
              </p>
            </div>
            <div className={`p-2.5 bg-[#0B1B3D] border rounded-xl ${cardStatus === "active" ? "text-emerald-400 border-emerald-500/30" : "text-slate-500 border-white/5"}`}>
              {cardStatus === "active" ? <Unlock className="w-5 h-5 animate-pulse" /> : <Lock className="w-5 h-5" />}
            </div>
          </div>

          <div className="bg-[#142850] border border-white/5 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-bold uppercase tracking-wider">Card Status</span>
              <p className={`text-sm font-bold uppercase tracking-wider mt-1.5 flex items-center gap-2 ${
                cardStatus === "active" ? "text-emerald-400" : "text-amber-400"
              }`}>
                <span className={`w-2 h-2 rounded-full ${cardStatus === "active" ? "bg-emerald-400 animate-ping" : "bg-amber-400"}`} />
                {cardStatus === "active" ? "TEMPORARY UNLOCK" : "HARDLOCKED (INACTIVE)"}
              </p>
            </div>
            <div className="p-2.5 bg-[#0B1B3D] border border-white/5 rounded-xl text-[#D4AF37]">
              <Zap className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-[#142850] border border-white/5 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#7C8AA8] font-bold uppercase tracking-wider">Manager Approval Ceiling</span>
              <p className="text-xl font-mono font-bold text-white mt-1">
                {isDirector ? "Unrestricted (Director)" : "$250.00 Cap"}
              </p>
            </div>
            <div className="p-2.5 bg-[#0B1B3D] border border-white/5 rounded-xl text-[#D4AF37]">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* TAB 1: CREATOR EXPENSE UNLOCK REQUEST FORM */}
      {activePortalTab === "talent_form" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Form */}
          <div className="lg:col-span-7 bg-[#0B1B3D] border border-[#142850] rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
            <div className="border-b border-white/5 pb-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-serif">
                <DollarSign className="w-5 h-5 text-[#D4AF37]" />
                Creator Expense Authorization Request
              </h2>
              <p className="text-xs text-[#7C8AA8] mt-1">
                Request temporary Just-In-Time purchasing authorization for physical studio props, beauty textures, or verified campaign line items.
              </p>
            </div>

            {formSuccessMessage && (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-emerald-400 text-xs flex items-center gap-3 animate-fade-in">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>{formSuccessMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmitExpenseRequest} className="space-y-5">
              {/* Creator Selector (if Director/Manager testing) */}
              {!isCreatorView && (
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-[#7C8AA8] uppercase tracking-wider">
                    Select Talent Profile
                  </label>
                  <select
                    value={selectedCreatorId}
                    onChange={(e) => setSelectedCreatorId(e.target.value)}
                    className="w-full bg-[#142850] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#D4AF37] transition-colors"
                  >
                    {creators.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({(c as any).handle || `@creator_${c.id}`})
                      </option>
                    ))}
                    {creators.length === 0 && (
                      <>
                        <option value="c3">Chloe Bennett (@chloebennett)</option>
                        <option value="c2">Marcus Vance (@marcusvance)</option>
                        <option value="c1">Sarah Jenkins (@sarahj_style)</option>
                      </>
                    )}
                  </select>
                </div>
              )}

              {/* Itemized Purpose */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-[#7C8AA8] uppercase tracking-wider">
                  Itemized Expense Purpose / Target Product Name
                </label>
                <input
                  type="text"
                  value={expensePurpose}
                  onChange={(e) => setExpensePurpose(e.target.value)}
                  placeholder="e.g., Botanical Styling Oil Blend & Studio Lighting Props"
                  className="w-full bg-[#142850] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white placeholder-[#7C8AA8]/50 focus:outline-none focus:border-[#D4AF37] transition-colors shadow-inner"
                  required
                />
              </div>

              {/* Exact Amount & Associated Campaign in Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-[#7C8AA8] uppercase tracking-wider">
                    Exact Amount Required ($)
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D4AF37] font-mono font-bold">$</span>
                    <input
                      type="number"
                      step="0.01"
                      min="1.00"
                      max="10000.00"
                      value={requestedAmount}
                      onChange={(e) => setRequestedAmount(e.target.value)}
                      placeholder="145.50"
                      className="w-full bg-[#142850] border border-white/10 rounded-2xl pl-9 pr-4 py-3 text-sm font-mono font-bold text-white placeholder-[#7C8AA8]/50 focus:outline-none focus:border-[#D4AF37] transition-colors shadow-inner"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-[#7C8AA8] uppercase tracking-wider">
                    Associated Active Campaign/Mission Link
                  </label>
                  <select
                    value={selectedCampaign}
                    onChange={(e) => setSelectedCampaign(e.target.value)}
                    className="w-full bg-[#142850] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#D4AF37] transition-colors"
                  >
                    {availableCampaigns.map((camp) => (
                      <option key={camp.id} value={camp.id}>
                        {camp.name} ({camp.niche})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Security Notice */}
              <div className="bg-[#142850]/60 border border-white/5 rounded-2xl p-4 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div className="text-[11px] text-[#7C8AA8] leading-relaxed">
                  <span className="text-white font-semibold">Strict 30-Minute Authorization Window: </span>
                  Upon manager approval, card ending in <span className="text-[#D4AF37] font-mono font-bold">4829</span> unlocks for the exact amount. The card relocks instantly once swiped, and a photo of your receipt must be uploaded within 24 hours.
                </div>
              </div>

              {/* Submit Gold Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-[#D4AF37] hover:bg-[#E5C358] active:scale-[0.99] disabled:opacity-50 text-[#0B1B3D] font-bold text-sm uppercase tracking-wider rounded-2xl transition-all shadow-xl shadow-[#D4AF37]/15 flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                <span>Submit Expense Authorization Request</span>
              </button>
            </form>
          </div>

          {/* Right Column: Visual Card Preview & Policy Status */}
          <div className="lg:col-span-5 space-y-6">
            {/* Visual Corporate Card Mockup */}
            <div className="relative aspect-[1.586/1] bg-gradient-to-br from-[#142850] via-[#0B1B3D] to-[#1E3A6E] rounded-3xl p-6 border border-[#D4AF37]/40 shadow-2xl flex flex-col justify-between overflow-hidden group">
              {/* Card Holographic / Circuit Overlay */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#D4AF37]/10 via-transparent to-transparent pointer-events-none" />
              <div className="absolute top-0 right-0 p-8 text-[#D4AF37]/10 pointer-events-none">
                <CreditCard className="w-32 h-32 -mr-10 -mt-10" />
              </div>

              {/* Top Row: Chip & Issuing Network */}
              <div className="flex items-center justify-between relative z-10">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-8 bg-gradient-to-r from-amber-200 via-amber-400 to-amber-500 rounded-md shadow-md flex items-center justify-center p-1 border border-amber-300">
                    <div className="w-full h-full border border-amber-800/40 rounded-sm grid grid-cols-2 gap-0.5 p-0.5">
                      <div className="border-r border-amber-800/30" />
                      <div />
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-[#D4AF37] font-bold uppercase tracking-widest">
                    JIT DEBIT
                  </span>
                </div>
                <span className="text-sm font-serif font-bold text-white tracking-widest">BLOOM STUDIO</span>
              </div>

              {/* Center Row: Card Number & Lock State */}
              <div className="space-y-1 relative z-10 my-auto">
                <div className="flex items-center justify-between">
                  <p className="font-mono text-lg md:text-xl text-white tracking-[0.25em] font-bold drop-shadow">
                    •••• •••• •••• 4829
                  </p>
                  <span className={`px-2.5 py-0.5 text-[9px] font-bold rounded-full border ${
                    cardStatus === "active"
                      ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40 animate-pulse"
                      : "bg-rose-500/20 text-rose-400 border-rose-500/40"
                  }`}>
                    {cardStatus === "active" ? "ACTIVE / PROVISIONED" : "LOCKED / $0.00 LIMIT"}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-[#7C8AA8]">
                  <span>EXP: 08/29</span>
                  <span>CVV: •••</span>
                </div>
              </div>

              {/* Bottom Row: Cardholder & Active Balance */}
              <div className="flex items-end justify-between relative z-10 pt-2 border-t border-white/10">
                <div>
                  <span className="text-[8px] text-[#7C8AA8] uppercase font-bold tracking-wider">Cardholder</span>
                  <p className="text-xs font-bold text-white tracking-wider uppercase">{matchedCreator.name}</p>
                </div>
                <div className="text-right">
                  <span className="text-[8px] text-[#7C8AA8] uppercase font-bold tracking-wider">Available Spend</span>
                  <p className="text-sm font-mono font-bold text-[#D4AF37]">
                    ${activeCardLimit.toFixed(2)} USD
                  </p>
                </div>
              </div>
            </div>

            {/* Privacy & Zero Trust Isolation Guarantee */}
            <div className="bg-[#0B1B3D] border border-[#142850] rounded-3xl p-6 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" /> Zero-Trust Account Isolation
              </h3>
              <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
                Talent and Agent Manager accounts operate in secure compartmentalized scopes. Master treasury cash deposits, company tax reserves, and director trust pools remain physically isolated and inaccessible from this workspace.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MANAGEMENT AUTHORIZATION CONTROL MATRIX */}
      {activePortalTab === "management_matrix" && (
        <div className="bg-[#0B1B3D] border border-[#142850] rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-serif">
                <Sliders className="w-5 h-5 text-[#D4AF37]" />
                Management Authorization Control Matrix
              </h2>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Review, verify, and approve incoming line-item production expenditures. Manager approvals capped at $250.00.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs text-[#7C8AA8]">
                Pending Requests: <strong className="text-[#D4AF37]">{requests.filter((r) => r.status === "Awaiting_Manager_Clearance").length}</strong>
              </span>
            </div>
          </div>

          {/* Scannable Data Grid Table */}
          <div className="overflow-x-auto rounded-2xl border border-[#142850] bg-[#0B1B3D]">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#142850] text-[#7C8AA8] uppercase text-[10px] tracking-wider border-b border-white/5">
                  <th className="py-3.5 px-4 font-bold">Creator Handle</th>
                  <th className="py-3.5 px-4 font-bold">Purpose Description</th>
                  <th className="py-3.5 px-4 font-bold">Target Campaign Niche</th>
                  <th className="py-3.5 px-4 font-bold text-right">Requested Amount</th>
                  <th className="py-3.5 px-4 font-bold text-center">Status</th>
                  <th className="py-3.5 px-4 font-bold text-right">Authorization Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-sans">
                {requests.map((req) => {
                  const exceedsManagerCap = req.amount > 250.0;
                  const isManagerBlocked = isAgentManager && exceedsManagerCap;

                  return (
                    <tr key={req.id} className="hover:bg-[#142850]/40 transition-colors">
                      {/* Creator */}
                      <td className="py-4 px-4">
                        <div className="font-bold text-white">{req.creatorName}</div>
                        <div className="text-[10px] text-[#D4AF37] font-mono">{req.creatorHandle}</div>
                      </td>

                      {/* Purpose Description */}
                      <td className="py-4 px-4 max-w-xs">
                        <p className="text-white line-clamp-2">{req.purpose}</p>
                        <span className="text-[10px] text-[#7C8AA8] flex items-center gap-1 mt-0.5">
                          <Clock className="w-3 h-3" /> {req.createdAt}
                        </span>
                      </td>

                      {/* Campaign Niche */}
                      <td className="py-4 px-4">
                        <div className="text-white font-medium">{req.campaignName}</div>
                        <span className="inline-block px-2 py-0.5 bg-[#142850] text-[#7C8AA8] text-[9px] font-bold rounded-md border border-white/5 mt-0.5">
                          {req.campaignNiche}
                        </span>
                      </td>

                      {/* Requested Amount */}
                      <td className="py-4 px-4 text-right">
                        <span className="font-mono text-sm font-bold text-[#D4AF37]">
                          ${req.amount.toFixed(2)}
                        </span>
                        {exceedsManagerCap && (
                          <div className="text-[9px] text-amber-400 font-bold tracking-tight mt-0.5">
                            &gt; $250 Cap
                          </div>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-4 px-4 text-center">
                        {req.status === "Awaiting_Manager_Clearance" && (
                          <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-full text-[10px] font-bold tracking-tight inline-flex items-center gap-1">
                            <Clock className="w-3 h-3" /> Awaiting Clearance
                          </span>
                        )}
                        {req.status === "Approved" && (
                          <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full text-[10px] font-bold tracking-tight inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Limit Active
                          </span>
                        )}
                        {req.status === "Denied" && (
                          <span className="px-2.5 py-1 bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-full text-[10px] font-bold tracking-tight inline-flex items-center gap-1">
                            <XCircle className="w-3 h-3" /> Denied
                          </span>
                        )}
                        {req.status === "Settled_Locked" && (
                          <span className="px-2.5 py-1 bg-blue-500/10 border border-blue-500/30 text-blue-300 rounded-full text-[10px] font-bold tracking-tight inline-flex items-center gap-1">
                            <Lock className="w-3 h-3" /> Settled &amp; Locked
                          </span>
                        )}
                      </td>

                      {/* Dual Button Framework */}
                      <td className="py-4 px-4 text-right">
                        {req.status === "Awaiting_Manager_Clearance" ? (
                          <div className="flex items-center justify-end gap-2">
                            {/* Approve & Unlock Button */}
                            <button
                              onClick={() => handleApproveRequest(req)}
                              disabled={isManagerBlocked}
                              title={
                                isManagerBlocked
                                  ? "Director Clearance Required (Exceeds $250.00 Agent Manager Limit)"
                                  : "Approve and provision temporary limit via Stripe Issuing"
                              }
                              className={`px-3 py-1.5 rounded-xl font-bold text-[11px] transition-all flex items-center gap-1.5 shadow cursor-pointer ${
                                isManagerBlocked
                                  ? "bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed"
                                  : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500 hover:text-white"
                              }`}
                            >
                              <Unlock className="w-3 h-3" />
                              <span>[ Approve &amp; Unlock Stripe Limit ]</span>
                            </button>

                            {/* Deny Button */}
                            <button
                              onClick={() => {
                                setDenyingRequestId(req.id);
                                setDenyReason("");
                              }}
                              className="px-2.5 py-1.5 rounded-xl text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 text-[11px] font-bold transition-all cursor-pointer"
                            >
                              [ Deny Request ]
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-[#7C8AA8]">
                            {req.status === "Approved" ? `Approved by ${req.approvedBy}` : "Resolution Recorded"}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Quick Simulation Trigger for Managers/Directors */}
          {cardStatus === "active" && (
            <div className="bg-[#142850] border border-emerald-500/30 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl">
                  <Zap className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Stripe Card Limit Active (${activeCardLimit.toFixed(2)})</h4>
                  <p className="text-xs text-[#7C8AA8]">
                    Card ending in 4829 is currently unlocked for {activeAuthorizedPurpose || "authorized production purchase"}.
                  </p>
                </div>
              </div>
              <button
                onClick={handleSimulateSwipeAndLock}
                className="px-5 py-2.5 bg-[#D4AF37] hover:bg-[#E5C358] text-[#0B1B3D] text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow cursor-pointer shrink-0"
              >
                Simulate Creator Swipe &amp; Instant Relock
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: STRIPE API WEBHOOK LOGIC SCHEMATIC */}
      {activePortalTab === "stripe_terminal" && (
        <div className="bg-[#0B1B3D] border border-[#142850] rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-white/5 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-serif">
                <Terminal className="w-5 h-5 text-[#D4AF37]" />
                Stripe Issuing Webhook Engine &amp; Event Stream
              </h2>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Real-time simulated telemetry for Stripe Issuing card limits, webhook HMAC signature validation, and auto-relock callbacks.
              </p>
            </div>
            <button
              onClick={() => {
                setWebhookLogs((prev) => [
                  {
                    time: new Date().toTimeString().split(" ")[0],
                    event: "webhook.healthcheck",
                    payload: '{"status":"connected","endpoint":"/api/webhooks/stripe-issuing","mode":"zero_trust_jit"}',
                    status: "success",
                  },
                  ...prev,
                ]);
              }}
              className="px-3 py-1.5 bg-[#142850] hover:bg-[#1C366B] text-xs font-bold text-[#D4AF37] border border-[#D4AF37]/30 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Ping Endpoint
            </button>
          </div>

          {/* Webhook Console */}
          <div className="bg-[#070F22] border border-white/10 rounded-2xl p-5 font-mono text-xs space-y-3 max-h-96 overflow-y-auto">
            <div className="flex items-center justify-between text-[11px] text-[#7C8AA8] border-b border-white/10 pb-2">
              <span>EVENT STREAM (LIVE)</span>
              <span>SIGNED: whsec_bloom_issuing_live_key</span>
            </div>

            {webhookLogs.map((log, idx) => (
              <div key={idx} className="p-3 bg-[#0B1B3D]/80 rounded-xl border border-white/5 space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className={`font-bold ${
                    log.status === "success"
                      ? "text-emerald-400"
                      : log.status === "warn"
                      ? "text-amber-400"
                      : "text-cyan-400"
                  }`}>
                    [{log.time}] {log.event}
                  </span>
                  <span className="text-[10px] text-[#7C8AA8]">HTTP 200 OK</span>
                </div>
                <pre className="text-[11px] text-slate-300 overflow-x-auto whitespace-pre-wrap break-all">
                  {log.payload}
                </pre>
              </div>
            ))}
          </div>

          {/* Endpoint Logic Flow Diagram */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#142850] border border-white/5 rounded-2xl p-4 space-y-2">
              <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider">Step 1: JIT Unlock</span>
              <h4 className="text-sm font-bold text-white">PATCH /v1/issuing/cards</h4>
              <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
                Manager approval authorizes temporary limit equal to the exact dollar amount requested. Card status toggles from inactive to active.
              </p>
            </div>
            <div className="bg-[#142850] border border-white/5 rounded-2xl p-4 space-y-2">
              <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider">Step 2: Swipe Callback</span>
              <h4 className="text-sm font-bold text-white">issuing_authorization.request</h4>
              <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
                Stripe evaluates real-time authorization. If amount matches approved purpose, swipe clears and instant relock hook triggers.
              </p>
            </div>
            <div className="bg-[#142850] border border-white/5 rounded-2xl p-4 space-y-2">
              <span className="text-[10px] text-[#D4AF37] font-bold uppercase tracking-wider">Step 3: Auto Relock</span>
              <h4 className="text-sm font-bold text-white">Baseline Reset to $0.00</h4>
              <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
                Card limit drops back to $0.00 within milliseconds of charge capture until matching receipt PNG image blob is filed.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Deny Reason Modal */}
      {denyingRequestId && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B1B3D] border border-[#142850] rounded-3xl p-6 md:p-8 max-w-md w-full space-y-5 shadow-2xl animate-fade-in">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-lg font-bold text-rose-400 flex items-center gap-2">
                <XCircle className="w-5 h-5" /> Deny Expense Request
              </h3>
              <button
                onClick={() => setDenyingRequestId(null)}
                className="text-[#7C8AA8] hover:text-white"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-[#7C8AA8]">
              Specify the operational reason for rejecting this production expense authorization request:
            </p>

            <textarea
              rows={3}
              value={denyReason}
              onChange={(e) => setDenyReason(e.target.value)}
              placeholder="e.g., Target product is out-of-scope for the agreed campaign deliverables."
              className="w-full bg-[#142850] border border-white/10 rounded-2xl p-4 text-xs text-white placeholder-[#7C8AA8]/50 focus:outline-none focus:border-[#D4AF37] transition-colors"
            />

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDenyingRequestId(null)}
                className="px-4 py-2 bg-[#142850] hover:bg-[#1E3A6E] text-xs font-bold text-white rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDenyRequest}
                className="px-5 py-2 bg-rose-500 hover:bg-rose-600 text-xs font-bold text-white rounded-xl transition-all cursor-pointer shadow"
              >
                Confirm Denial
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StripeDebitCardController;
