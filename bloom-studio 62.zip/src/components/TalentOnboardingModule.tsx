import React, { useState, useRef, useMemo } from 'react';
import { 
  User, 
  AtSign, 
  Compass, 
  Lock, 
  FileText, 
  UploadCloud, 
  AlertCircle, 
  CheckCircle2, 
  Loader2, 
  Eye, 
  X, 
  ShieldCheck, 
  Sparkles,
  RefreshCw
} from 'lucide-react';
import MultiFilePdfViewerModal, { ViewableFile } from './DocumentViewerModal';
import PrivacyPolicyModal from './PrivacyPolicyModal';
import { Role } from '../types';
import { safeStorage } from '../utils/safeStorage';

export interface UploadedFileInfo {
  file: File;
  name: string;
  size: string;
  dataUrl?: string;
  type: string;
}

export interface TalentOnboardingModuleProps {
  currentRole?: Role | string;
  userRole?: Role | string;
  onComplete?: (talentData: {
    realName: string;
    tikTokHandle: string;
    niche: string;
    w9File: File | null;
    w9FileName?: string;
    uploadedFiles?: UploadedFileInfo[];
    taxId?: string;
    taxClassification?: string;
    privacyAcknowledged?: boolean;
  }) => Promise<void> | void;
  className?: string;
}

interface FormErrors {
  realName?: string;
  tikTokHandle?: string;
  niche?: string;
  taxId?: string;
  privacy?: string;
  general?: string;
}

export default function TalentOnboardingModule({
  currentRole,
  userRole,
  onComplete,
  className = ''
}: TalentOnboardingModuleProps) {
  // Determine effective user role from props or stored session
  const effectiveRole = useMemo(() => {
    const directRole = userRole || currentRole;
    if (directRole && typeof directRole === 'string') {
      return directRole.toLowerCase().trim();
    }
    try {
      if (typeof window !== 'undefined') {
        const storedRole = safeStorage.getItem('bloom_user_role') || safeStorage.getItem('wl_active_role');
        if (storedRole) return storedRole.toLowerCase().trim();
        const storedUser = safeStorage.getItem('bloom_current_user');
        if (storedUser) {
          const parsed = JSON.parse(storedUser);
          if (parsed && parsed.role) return String(parsed.role).toLowerCase().trim();
        }
      }
    } catch {
      // Fallback
    }
    return 'creator';
  }, [currentRole, userRole]);

  // Role-based check: Sensitive tax fields (SSN/EIN, Tax Classification, IRS W-9 upload, PDF inspection) ONLY mount for 'director'
  const isDirector = effectiveRole === 'director';

  // Form Field State
  const [realName, setRealName] = useState('');
  const [tikTokHandle, setTikTokHandle] = useState('');
  const [niche, setNiche] = useState('');
  const [taxId, setTaxId] = useState('');
  const [taxClassification, setTaxClassification] = useState('Individual/Sole Proprietor');
  
  // File Upload State
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFileInfo[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileStatus, setFileStatus] = useState<{
    text: string;
    isUploaded: boolean;
  }>({
    text: 'W-9 submission is required before payouts are unlocked.',
    isUploaded: false
  });

  // Validation & Touched Tracking State
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  // Global Loading & Submission State (Immediate synchronous lockout to prevent duplicate profile creation)
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Privacy Policy Acknowledgment State
  const [privacyAcknowledged, setPrivacyAcknowledged] = useState(false);
  const [showPrivacyPolicyModal, setShowPrivacyPolicyModal] = useState(false);

  // Synchronous lock ref to block fast multi-clicks before state flush
  const isSubmittingRef = useRef(false);

  // Document Inspection Viewer State
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewerInitialIndex, setViewerInitialIndex] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Consolidated Field Validation Logic
  const validateField = (fieldName: string, value: string): string | undefined => {
    switch (fieldName) {
      case 'realName': {
        const trimmed = value.trim();
        if (!trimmed) return 'Full legal name is required';
        if (trimmed.length < 2) return 'Legal name must be at least 2 characters';
        if (!/^[a-zA-Z\s.'-]+$/.test(trimmed)) return 'Please enter a valid legal name (letters and spaces only)';
        return undefined;
      }
      case 'tikTokHandle': {
        const raw = value.trim().replace(/^@/, '');
        if (!raw) return 'TikTok handle is required';
        if (raw.length < 2) return 'Handle must be at least 2 characters';
        if (!/^[a-zA-Z0-9._]+$/.test(raw)) return 'Handle can only contain letters, numbers, dots, and underscores';
        return undefined;
      }
      case 'niche': {
        if (!value) return 'Please select a primary content niche';
        return undefined;
      }
      case 'taxId': {
        if (isDirector && value.trim()) {
          const digitsOnly = value.trim().replace(/[^0-9]/g, '');
          if (digitsOnly.length !== 9) {
            return 'Tax ID must be exactly 9 digits (SSN: XXX-XX-XXXX or EIN: XX-XXXXXXX)';
          }
        }
        return undefined;
      }
      default:
        return undefined;
    }
  };

  // Consolidated Form Validation
  const validateForm = (): { isValid: boolean; newErrors: FormErrors } => {
    const newErrors: FormErrors = {};

    const nameErr = validateField('realName', realName);
    if (nameErr) newErrors.realName = nameErr;

    const handleErr = validateField('tikTokHandle', tikTokHandle);
    if (handleErr) newErrors.tikTokHandle = handleErr;

    const nicheErr = validateField('niche', niche);
    if (nicheErr) newErrors.niche = nicheErr;

    if (isDirector && taxId) {
      const taxErr = validateField('taxId', taxId);
      if (taxErr) newErrors.taxId = taxErr;
    }

    if (!privacyAcknowledged) {
      newErrors.privacy = 'You must review and acknowledge the Master Privacy Policy to activate your talent profile.';
    }

    return {
      isValid: Object.keys(newErrors).length === 0,
      newErrors
    };
  };

  const handleBlur = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    let val = '';
    if (field === 'realName') val = realName;
    if (field === 'tikTokHandle') val = tikTokHandle;
    if (field === 'niche') val = niche;
    if (field === 'taxId') val = taxId;

    const err = validateField(field, val);
    setErrors(prev => ({ ...prev, [field]: err }));
  };

  const handleZoneClick = () => {
    if (!isDirector || isSubmitting || isSubmittingRef.current) return;
    if (fileInputRef.current) {
      fileInputRef.current.click();
    } else {
      const fallbackInput = document.getElementById('w9FileInput') as HTMLInputElement | null;
      if (fallbackInput) {
        fallbackInput.click();
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isDirector || isSubmitting || isSubmittingRef.current) return;
    const inputElement = e.target;
    if (!inputElement || !inputElement.files || inputElement.files.length === 0) return;

    const filesArray: File[] = Array.from(inputElement.files);

    filesArray.forEach((file: File) => {
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = typeof reader.result === 'string' ? reader.result : '';
        const fileInfo: UploadedFileInfo = {
          file,
          name: file.name || 'document.pdf',
          size: `${Math.round((file.size || 0) / 1024)} KB`,
          dataUrl,
          type: file.type || 'application/pdf'
        };

        setUploadedFiles(prev => {
          const filtered = prev.filter(f => f.name !== fileInfo.name);
          return [...filtered, fileInfo];
        });
      };
      reader.readAsDataURL(file);
    });

    const primaryFile = filesArray[0];
    setSelectedFile(primaryFile);

    const countText = filesArray.length > 1 
      ? `Selected ${filesArray.length} files (${filesArray.map((f: File) => f.name).join(', ')})`
      : `Selected: ${primaryFile.name}`;

    setFileStatus({
      text: countText,
      isUploaded: true
    });

    // Safely update DOM status text if present, using safe null checks
    const statusElem = document.getElementById('fileStatusText');
    if (statusElem) {
      statusElem.textContent = countText;
      statusElem.style.color = '#10B981';
    }
  };

  const handleRemoveFile = (fileName: string, e?: React.MouseEvent) => {
    if (!isDirector || isSubmitting || isSubmittingRef.current) return;
    if (e) e.stopPropagation();
    setUploadedFiles(prev => {
      const updated = prev.filter(f => f.name !== fileName);
      if (updated.length === 0) {
        setSelectedFile(null);
        setFileStatus({
          text: 'W-9 submission is required before payouts are unlocked.',
          isUploaded: false
        });
      } else {
        setSelectedFile(updated[0].file);
        setFileStatus({
          text: `Selected: ${updated.map(f => f.name).join(', ')}`,
          isUploaded: true
        });
      }
      return updated;
    });
  };

  const handlePreviewFile = (index: number, e?: React.MouseEvent) => {
    if (!isDirector) return;
    if (e) e.stopPropagation();
    setViewerInitialIndex(index);
    setViewerOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // STRICT LOCKOUT: Guard immediately against fast multi-clicks or duplicate submissions
    if (isSubmitting || isSubmittingRef.current) {
      return;
    }

    // Mark all fields as touched for comprehensive error display
    setTouched({
      realName: true,
      tikTokHandle: true,
      niche: true,
      taxId: true,
      privacy: true
    });

    // Run consolidated validation
    const { isValid, newErrors } = validateForm();
    setErrors(newErrors);

    if (!isValid) {
      // Focus first error field for smooth keyboard navigation
      if (newErrors.realName) {
        document.getElementById('talentRealName')?.focus();
      } else if (newErrors.tikTokHandle) {
        document.getElementById('talentTikTok')?.focus();
      } else if (newErrors.niche) {
        document.getElementById('talentNiche')?.focus();
      } else if (newErrors.taxId) {
        document.getElementById('talentTaxId')?.focus();
      }
      return;
    }

    // Immediately engage synchronous lock and update global loading state
    isSubmittingRef.current = true;
    setIsSubmitting(true);
    setErrors({});

    const formattedHandle = tikTokHandle.trim().startsWith('@') 
      ? tikTokHandle.trim() 
      : `@${tikTokHandle.trim()}`;

    try {
      if (onComplete) {
        const payload = {
          realName: realName.trim(),
          tikTokHandle: formattedHandle,
          niche,
          w9File: isDirector ? selectedFile : null,
          w9FileName: isDirector && selectedFile ? selectedFile.name : undefined,
          uploadedFiles: isDirector ? uploadedFiles : [],
          taxId: isDirector && taxId.trim() ? taxId.trim() : undefined,
          taxClassification: isDirector ? taxClassification : undefined,
          privacyAcknowledged: true
        };

        // Await asynchronous API execution with deliberate smooth transition
        await Promise.all([
          Promise.resolve(onComplete(payload)),
          new Promise(res => setTimeout(res, 600))
        ]);
      } else {
        await new Promise(res => setTimeout(res, 600));
      }

      setIsSuccess(true);
    } catch (err: any) {
      console.error('Onboarding profile activation error:', err);
      setErrors(prev => ({
        ...prev,
        general: err?.message || 'Failed to activate profile due to network issue. Please retry.'
      }));
    } finally {
      isSubmittingRef.current = false;
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    isSubmittingRef.current = false;
    setIsSubmitting(false);
    setIsSuccess(false);
    setRealName('');
    setTikTokHandle('');
    setNiche('');
    setTaxId('');
    setUploadedFiles([]);
    setSelectedFile(null);
    setErrors({});
    setTouched({});
    setFileStatus({
      text: 'W-9 submission is required before payouts are unlocked.',
      isUploaded: false
    });
  };

  const viewableFiles: ViewableFile[] = useMemo(() => {
    return uploadedFiles.map(uf => ({
      name: uf.name,
      dataUrl: uf.dataUrl,
      size: uf.size,
      type: uf.type,
      category: 'Talent Tax Compliance'
    }));
  }, [uploadedFiles]);

  if (isSuccess) {
    return (
      <div className={`onboarding-card text-center space-y-4 animate-fade-in ${className}`}>
        <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-950/40">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <div>
          <h2 className="form-title text-white flex items-center justify-center gap-2">
            <span>Talent Profile Activated</span>
            <Sparkles className="w-5 h-5 text-[#C9A46A]" />
          </h2>
          <p className="form-subtitle text-slate-300 !mb-2 max-w-md mx-auto">
            Welcome to the Bloom casting roster, <strong className="text-white">{realName}</strong> (<span className="text-[#C9A46A] font-mono">{tikTokHandle.startsWith('@') ? tikTokHandle : `@${tikTokHandle}`}</span>).
          </p>
        </div>

        <div className="bg-[#0A1128] border border-white/5 rounded-xl p-4 text-left space-y-2.5 max-w-md mx-auto">
          <div className="flex justify-between items-center text-xs pb-2 border-b border-white/5">
            <span className="text-[#7C8AA8] font-mono uppercase text-[10px]">Roster Activation</span>
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
              Active / Ready
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <div className="text-[10px] font-mono uppercase text-[#7C8AA8]">Legal Name</div>
              <div className="text-white font-medium truncate">{realName}</div>
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase text-[#7C8AA8]">Primary Niche</div>
              <div className="text-sky-300 font-medium capitalize">{niche}</div>
            </div>
          </div>

          {isDirector ? (
            <div className="pt-2 border-t border-white/5 text-xs">
              {uploadedFiles.length > 0 ? (
                <div className="flex items-center justify-between text-emerald-400 font-mono text-[11px]">
                  <span>✓ {uploadedFiles.length} Tax Document{uploadedFiles.length > 1 ? 's' : ''} Attached</span>
                  <button
                    type="button"
                    onClick={() => {
                      setViewerInitialIndex(0);
                      setViewerOpen(true);
                    }}
                    className="text-[#C9A46A] hover:underline flex items-center gap-1 cursor-pointer font-sans"
                  >
                    <Eye className="w-3 h-3" /> Inspect PDF
                  </button>
                </div>
              ) : (
                <div className="text-amber-300 font-mono text-[11px]">
                  ℹ Tax verification pending director dispatch
                </div>
              )}
            </div>
          ) : (
            <div className="pt-2 border-t border-white/5 text-[11px] text-[#7C8AA8] flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span>Tax records routed to Agency Lead secure inbox</span>
            </div>
          )}
        </div>

        <div className="pt-2">
          <button
            type="button"
            onClick={resetForm}
            className="w-full bg-[#111E33] hover:bg-[#16243F] border border-white/10 hover:border-white/20 text-slate-200 hover:text-white font-semibold text-xs py-3 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Update Details / Add Another Talent</span>
          </button>
        </div>

        {/* Multi-File PDF Viewer */}
        {isDirector && (
          <MultiFilePdfViewerModal
            isOpen={viewerOpen}
            onClose={() => setViewerOpen(false)}
            title={`Tax & Onboarding Documents — ${realName}`}
            files={viewableFiles}
            initialIndex={viewerInitialIndex}
          />
        )}
      </div>
    );
  }

  return (
    <div className={`onboarding-card relative overflow-hidden ${className}`}>
      {/* Top Active Loading Bar Indicator */}
      {isSubmitting && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-sky-950 overflow-hidden z-20">
          <div className="h-full bg-gradient-to-r from-[#38BDF8] via-[#C9A46A] to-[#34D399] animate-pulse w-full" />
        </div>
      )}

      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between gap-2 mb-1">
          <h2 className="form-title text-white !mb-0">Complete Your Talent Profile</h2>
          <span className="text-[10px] font-mono bg-sky-950/60 text-sky-400 border border-sky-500/20 px-2 py-0.5 rounded-full font-semibold">
            Onboarding v2.4
          </span>
        </div>
        <p className="form-subtitle !mb-0">Fill out your details to activate your profile on the casting dashboard.</p>
      </div>

      {/* Global Error Banner if any */}
      {errors.general && (
        <div className="mb-5 bg-rose-950/50 border border-rose-500/40 rounded-xl p-3 flex items-start gap-2.5 text-xs text-rose-200 animate-shake">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div>{errors.general}</div>
        </div>
      )}

      <form id="talentOnboardingForm" onSubmit={handleSubmit} noValidate>
        {/* Real Name Input Field */}
        <div className="input-group">
          <div className="flex justify-between items-center">
            <label className="input-label flex items-center gap-1.5" htmlFor="talentRealName">
              <User className="w-3 h-3 text-slate-400" />
              <span>REAL LEGAL NAME</span>
            </label>
            {touched.realName && !errors.realName && realName.trim() && (
              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-0.5">
                <CheckCircle2 className="w-3 h-3" /> Valid
              </span>
            )}
          </div>
          <div className="relative">
            <input
              type="text"
              id="talentRealName"
              disabled={isSubmitting}
              className={`bloom-input w-full ${
                touched.realName && errors.realName
                  ? '!border-rose-500/80 !bg-rose-950/20'
                  : touched.realName && realName.trim()
                  ? '!border-emerald-500/50'
                  : ''
              } disabled:opacity-50 disabled:cursor-not-allowed`}
              placeholder="e.g. Zack King"
              value={realName}
              onChange={(e) => {
                setRealName(e.target.value);
                if (touched.realName) {
                  const err = validateField('realName', e.target.value);
                  setErrors(prev => ({ ...prev, realName: err }));
                }
              }}
              onBlur={() => handleBlur('realName')}
              required
            />
          </div>
          {touched.realName && errors.realName && (
            <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1 mt-0.5">
              <AlertCircle className="w-3 h-3 shrink-0" />
              <span>{errors.realName}</span>
            </p>
          )}
        </div>

        {/* TikTok Handle Input Field */}
        <div className="input-group">
          <div className="flex justify-between items-center">
            <label className="input-label flex items-center gap-1.5" htmlFor="talentTikTok">
              <AtSign className="w-3 h-3 text-slate-400" />
              <span>TIKTOK HANDLE</span>
            </label>
            {touched.tikTokHandle && !errors.tikTokHandle && tikTokHandle.trim() && (
              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-0.5">
                <CheckCircle2 className="w-3 h-3" /> Valid
              </span>
            )}
          </div>
          <div className="relative">
            <input
              type="text"
              id="talentTikTok"
              disabled={isSubmitting}
              className={`bloom-input w-full ${
                touched.tikTokHandle && errors.tikTokHandle
                  ? '!border-rose-500/80 !bg-rose-950/20'
                  : touched.tikTokHandle && tikTokHandle.trim()
                  ? '!border-emerald-500/50'
                  : ''
              } disabled:opacity-50 disabled:cursor-not-allowed`}
              placeholder="@handle"
              value={tikTokHandle}
              onChange={(e) => {
                setTikTokHandle(e.target.value);
                if (touched.tikTokHandle) {
                  const err = validateField('tikTokHandle', e.target.value);
                  setErrors(prev => ({ ...prev, tikTokHandle: err }));
                }
              }}
              onBlur={() => handleBlur('tikTokHandle')}
              required
            />
          </div>
          {touched.tikTokHandle && errors.tikTokHandle && (
            <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1 mt-0.5">
              <AlertCircle className="w-3 h-3 shrink-0" />
              <span>{errors.tikTokHandle}</span>
            </p>
          )}
        </div>

        {/* Niche Selection Dropdown */}
        <div className="input-group">
          <div className="flex justify-between items-center">
            <label className="input-label flex items-center gap-1.5" htmlFor="talentNiche">
              <Compass className="w-3 h-3 text-slate-400" />
              <span>PRIMARY CONTENT NICHE</span>
            </label>
            {touched.niche && !errors.niche && niche && (
              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-0.5">
                <CheckCircle2 className="w-3 h-3" /> Selected
              </span>
            )}
          </div>
          <select
            id="talentNiche"
            disabled={isSubmitting}
            className={`bloom-select w-full ${
              touched.niche && errors.niche
                ? '!border-rose-500/80 !bg-rose-950/20'
                : touched.niche && niche
                ? '!border-emerald-500/50'
                : ''
            } disabled:opacity-50 disabled:cursor-not-allowed`}
            value={niche}
            onChange={(e) => {
              setNiche(e.target.value);
              if (touched.niche) {
                const err = validateField('niche', e.target.value);
                setErrors(prev => ({ ...prev, niche: err }));
              }
            }}
            onBlur={() => handleBlur('niche')}
            required
          >
            <option value="" disabled>Select your niche...</option>
            <option value="pets">Pets & Animals</option>
            <option value="beauty">Beauty & Skincare</option>
            <option value="lifestyle">Fashion & Lifestyle</option>
            <option value="gaming">Gaming & Tech</option>
            <option value="fitness">Health & Fitness</option>
            <option value="food">Food & Cooking</option>
            <option value="comedy">Comedy & Entertainment</option>
          </select>
          {touched.niche && errors.niche && (
            <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1 mt-0.5">
              <AlertCircle className="w-3 h-3 shrink-0" />
              <span>{errors.niche}</span>
            </p>
          )}
        </div>

        {/* CONDITIONAL ROLE-BASED CHECK: Tax Documents & SSN/EIN inputs only accessible to 'director' */}
        {isDirector ? (
          <>
            {/* SSN / EIN Input Field - Director Restricted */}
            <div className="input-group">
              <div className="flex justify-between items-center mb-1">
                <label className="input-label !mb-0 flex items-center gap-1.5" htmlFor="talentTaxId">
                  <Lock className="w-3 h-3 text-amber-400" />
                  <span>TAX IDENTIFICATION NUMBER (SSN / EIN)</span>
                </label>
                <span className="text-[10px] text-emerald-400 font-mono font-semibold bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  Director Access Only
                </span>
              </div>
              <input
                type="password"
                id="talentTaxId"
                disabled={isSubmitting}
                className={`bloom-input font-mono w-full ${
                  touched.taxId && errors.taxId
                    ? '!border-rose-500/80 !bg-rose-950/20'
                    : ''
                } disabled:opacity-50 disabled:cursor-not-allowed`}
                placeholder="XX-XXXXXXX or XXX-XX-XXXX"
                value={taxId}
                onChange={(e) => {
                  setTaxId(e.target.value);
                  if (touched.taxId) {
                    const err = validateField('taxId', e.target.value);
                    setErrors(prev => ({ ...prev, taxId: err }));
                  }
                }}
                onBlur={() => handleBlur('taxId')}
                autoComplete="off"
              />
              {touched.taxId && errors.taxId ? (
                <p className="text-[11px] text-rose-400 font-medium flex items-center gap-1 mt-0.5">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  <span>{errors.taxId}</span>
                </p>
              ) : (
                <span className="text-[10px] text-[#7C8AA8] mt-0.5">
                  Encrypted at rest. Masked and isolated from agents and sub-agency views.
                </span>
              )}
            </div>

            {/* Tax Classification Dropdown */}
            <div className="input-group">
              <label className="input-label flex items-center gap-1.5" htmlFor="talentTaxClassification">
                <FileText className="w-3 h-3 text-slate-400" />
                <span>FEDERAL TAX CLASSIFICATION</span>
              </label>
              <select
                id="talentTaxClassification"
                disabled={isSubmitting}
                className="bloom-select font-sans text-xs w-full disabled:opacity-50 disabled:cursor-not-allowed"
                value={taxClassification}
                onChange={(e) => setTaxClassification(e.target.value)}
              >
                <option value="Individual/Sole Proprietor">Individual / Sole Proprietor</option>
                <option value="C Corporation">C Corporation</option>
                <option value="S Corporation">S Corporation</option>
                <option value="Partnership">Partnership</option>
                <option value="LLC - Single Member">LLC (Single Member Disregarded)</option>
                <option value="LLC - C Corp">LLC (Classified as C Corp)</option>
                <option value="LLC - S Corp">LLC (Classified as S Corp)</option>
                <option value="LLC - Partnership">LLC (Classified as Partnership)</option>
                <option value="Other">Other / Non-US Entity (W-8BEN)</option>
              </select>
            </div>

            {/* W-9 Tax Upload Field Box (Multi-File & PDF Viewer Ready) */}
            <div className="input-group">
              <div className="flex justify-between items-center mb-1">
                <label className="input-label !mb-0 flex items-center gap-1.5">
                  <UploadCloud className="w-3 h-3 text-slate-400" />
                  <span>TAX COMPLIANCE (IRS FORM W-9 &amp; ATTACHMENTS)</span>
                </label>
                <a
                  href="https://www.irs.gov/pub/irs-pdf/fw9.pdf"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[10px] text-[#C9A46A] hover:underline font-mono"
                >
                  Official IRS W-9 PDF ↗
                </a>
              </div>

              <div
                className={`upload-dropzone transition-all ${
                  isSubmitting 
                    ? 'opacity-50 cursor-not-allowed pointer-events-none' 
                    : 'cursor-pointer hover:border-[#3B82F6]/60 hover:bg-[#3B82F6]/5'
                }`}
                id="uploadZone"
                onClick={handleZoneClick}
              >
                <UploadCloud className="upload-icon text-sky-400" />
                <span className="upload-text">
                  {uploadedFiles.length > 0
                    ? 'Click or drag to add more signed PDF files'
                    : 'Click to upload signed W-9 PDF (Supports multiple files)'}
                </span>
                <input
                  type="file"
                  id="w9FileInput"
                  ref={fileInputRef}
                  accept=".pdf,.png,.jpg,.jpeg"
                  multiple
                  disabled={isSubmitting}
                  style={{ display: 'none' }}
                  onChange={handleFileChange}
                />
              </div>

              {/* Uploaded Files Chips & PDF Inspection List */}
              {uploadedFiles.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  <div className="text-[10px] uppercase font-mono text-[#7C8AA8] font-semibold flex items-center justify-between">
                    <span>Uploaded Attached Documents ({uploadedFiles.length}):</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {uploadedFiles.map((file, idx) => (
                      <div
                        key={`${file.name}_${idx}`}
                        className="bg-[#111E33] border border-[#C9A46A]/30 rounded-lg px-2.5 py-1.5 flex items-center gap-2 text-xs text-white shadow-sm"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
                        <span className="max-w-[140px] truncate text-[11px] font-medium" title={file.name}>
                          {file.name}
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono">({file.size})</span>
                        <button
                          type="button"
                          disabled={isSubmitting}
                          onClick={(e) => handlePreviewFile(idx, e)}
                          className="text-[#C9A46A] hover:text-white p-0.5 rounded text-[10px] font-mono underline cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                          title="Inspect PDF Document"
                        >
                          View
                        </button>
                        <button
                          type="button"
                          disabled={isSubmitting}
                          onClick={(e) => handleRemoveFile(file.name, e)}
                          className="text-slate-400 hover:text-rose-400 p-0.5 rounded text-xs font-bold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                          title="Remove File"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <span
                className="file-status-sub block mt-1.5"
                id="fileStatusText"
                style={{ color: fileStatus.isUploaded ? '#10B981' : '#EF4444' }}
              >
                {fileStatus.text}
              </span>
            </div>
          </>
        ) : (
          /* Notice for sub-agency, agent, and creator roles when sensitive tax compliance is isolated */
          <div className="bg-[#0A1128] border border-white/5 rounded-xl p-3.5 space-y-1.5 mb-5">
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-400">
              <ShieldCheck className="w-4 h-4 text-sky-400" />
              <span>Protected Tax Compliance Routing</span>
            </div>
            <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
              Tax identification numbers and W-9 filings are protected by agency security policy. The Director will securely dispatch and verify official tax compliance records upon roster approval.
            </p>
          </div>
        )}

        {/* Master Privacy Policy & Data Protection Agreement */}
        <div className={`p-4 rounded-xl border transition-all space-y-2.5 mb-5 ${
          errors.privacy && touched.privacy 
            ? 'bg-rose-950/30 border-rose-500/50' 
            : privacyAcknowledged 
            ? 'bg-[#06182c] border-emerald-500/40' 
            : 'bg-[#0A1128] border-[#C9A46A]/30'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-[#C9A46A]">
              <ShieldCheck className="w-4 h-4 text-[#C9A46A]" />
              <span>Creator Privacy &amp; Data Rights Agreement</span>
            </div>
            <button
              type="button"
              onClick={() => setShowPrivacyPolicyModal(true)}
              className="text-[11px] font-mono text-[#C9A46A] hover:underline bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 px-2.5 py-1 rounded-lg border border-[#C9A46A]/30 flex items-center gap-1 cursor-pointer transition"
            >
              <span>Read Master Privacy Policy</span>
            </button>
          </div>
          <label className="flex items-start gap-2.5 cursor-pointer select-none">
            <input
              type="checkbox"
              id="talentPrivacyCheckbox"
              checked={privacyAcknowledged}
              onChange={(e) => {
                setPrivacyAcknowledged(e.target.checked);
                if (e.target.checked) {
                  setErrors(prev => ({ ...prev, privacy: undefined }));
                }
              }}
              className="mt-0.5 rounded text-[#C9A46A] focus:ring-[#C9A46A] cursor-pointer"
            />
            <span className="text-xs text-slate-300 leading-relaxed">
              I have reviewed, acknowledge, and agree to Bloom Studio’s <strong className="text-white">Master Privacy Policy &amp; GDPR / CCPA Compliance</strong>. I acknowledge how my legal identity, likeness data, and payment earnings are safely isolated and protected.
            </span>
          </label>
          {errors.privacy && touched.privacy && (
            <div className="text-[11px] text-rose-400 font-mono flex items-center gap-1.5 pt-1">
              <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span>{errors.privacy}</span>
            </div>
          )}
        </div>

        {/* Submit / Activation Button with Immediate Global Loading State and Duplicate Prevention */}
        <button
          type="submit"
          id="btnActivateTalentProfile"
          disabled={isSubmitting}
          aria-busy={isSubmitting}
          className={`btn-submit-onboarding relative flex items-center justify-center gap-2 transition-all cursor-pointer ${
            isSubmitting
              ? 'opacity-60 !cursor-not-allowed !pointer-events-none'
              : 'hover:brightness-110 active:scale-[0.99]'
          }`}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Activating Talent Profile...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-[#C9A46A]" />
              <span>Activate Talent Profile</span>
            </>
          )}
        </button>
      </form>

      {/* Global Privacy Policy Modal */}
      <PrivacyPolicyModal
        isOpen={showPrivacyPolicyModal}
        onClose={() => {
          setShowPrivacyPolicyModal(false);
          setPrivacyAcknowledged(true);
          setErrors(prev => ({ ...prev, privacy: undefined }));
        }}
      />

      {/* Multi-File PDF Viewer Modal (Only initialized for Director) */}
      {isDirector && (
        <MultiFilePdfViewerModal
          isOpen={viewerOpen}
          onClose={() => setViewerOpen(false)}
          title={`Tax & Onboarding Document Vault — ${realName || tikTokHandle || 'Talent'}`}
          files={viewableFiles}
          initialIndex={viewerInitialIndex}
        />
      )}
    </div>
  );
}
