/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  FileText, Download, CheckCircle2, AlertTriangle, Calendar, 
  DollarSign, Sparkles, ExternalLink, ShieldCheck, ArrowRight,
  UploadCloud, Megaphone, HelpCircle, UserCheck, MessageSquare,
  Clock, Check, Eye
} from 'lucide-react';
import { Deal } from '../types';
import { exportCreativeBriefPDF } from '../utils/pdfExportUtils';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, where, doc, setDoc } from 'firebase/firestore';

interface CreatorDealBriefsViewProps {
  deals: Deal[];
  currentUser: any;
  currentRole: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onNavigateToSubmit?: () => void;
  onNavigateToMarketplace?: () => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

export interface DispatchedDealBrief {
  id: string;
  brandName: string;
  dealId?: string;
  dealTitle: string;
  platform?: string;
  payout: number | string;
  dueDate: string;
  stage?: string;
  deliverables: string;
  campaignGoals: string;
  styleGuidelines: string;
  requiredHooks: string;
  contractLegalText?: string;
  agentNote?: string;
  passedBy: string;
  senderRole: string;
  sentAt: string;
  status: 'Pending Acceptance' | 'Accepted' | 'In Production';
  niche?: string;
}

const DEFAULT_SAMPLED_BRIEFS: DispatchedDealBrief[] = [
  {
    id: 'brief_sample_glowlab_01',
    brandName: 'GlowLab Beauty',
    dealId: 'deal_brief_01',
    dealTitle: 'Summer Botanical Barrier Repair Reel Campaign',
    platform: 'Instagram & TikTok',
    payout: 3500,
    dueDate: '2026-09-18',
    stage: 'Contracted',
    deliverables: '1x 60s 4K Vertical UGC Video (9:16) + 1x Instagram Reel with permanent link sticker & 30-day Spark Ads Whitelisting.',
    campaignGoals: 'Demonstrate morning barrier repair application with botanical serum. Emphasize organic non-greasy texture, fast absorption, and hydrated skin finish without beauty filters.',
    styleGuidelines: 'Warm morning window daylight, crisp macro texture closeups of dropper pipette application, authentic initial touch reaction. Clear skin-type disclaimer overlay.',
    requiredHooks: 'Visual hook (seconds 0-3): "If your skin barrier feels dry by 2 PM, you need to watch this." Bold on-screen font in agency aesthetic.',
    agentNote: 'Hey! The brand team specifically requested your natural skincare routine style. Be sure to highlight the dropper texture in natural sunlight. Escrow is already funded and locked.',
    passedBy: 'Marcus Cole',
    senderRole: 'Senior Agent Manager',
    sentAt: 'Sep 2, 2026',
    status: 'Accepted',
    niche: 'Beauty',
    contractLegalText: `BLOOM STUDIO INFLUENCER TALENT DELIVERABLE AGREEMENT
1. SCOPE: 1x 60s TikTok UGC Video + 1x Instagram Reel with link sticker.
2. FTC COMPLIANCE: Conspicuous #ad disclosure at start of caption and overlay.
3. FINANCIAL ALLOCATION: $3,500 Escrow settlement upon director signoff.`
  },
  {
    id: 'brief_sample_barkhydrate_02',
    brandName: 'BarkHydrate',
    dealId: 'deal_brief_02',
    dealTitle: 'Dog Electrolyte & Summer Hydration Feature',
    platform: 'TikTok',
    payout: 2800,
    dueDate: '2026-09-22',
    stage: 'Contracted',
    deliverables: '2x 45s High-Energy TikTok UGC Videos + raw B-roll cuts with natural pet sound effects.',
    campaignGoals: 'Demonstrate powder electrolyte mixing before an afternoon dog park session. Showcase dog excitement and fast water bowl hydration.',
    styleGuidelines: 'Outdoor park or bright clean kitchen lighting. Dynamic pet interaction, closeups of product scoop into bowl, tail-wagging approval.',
    requiredHooks: 'Visual hook (seconds 0-3): "Stop giving your dog just plain water during hot summer walks..."',
    agentNote: 'Director Sarah approved this deal. Please make sure the dog bowl is clean and the product packaging label is clearly visible during the scoop sequence.',
    passedBy: 'Sarah Sterling',
    senderRole: 'Creative Director',
    sentAt: 'Sep 3, 2026',
    status: 'Pending Acceptance',
    niche: 'Pets',
    contractLegalText: `BLOOM STUDIO INFLUENCER TALENT DELIVERABLE AGREEMENT
1. SCOPE: 2x 45s TikTok UGC Videos + raw B-roll pack.
2. FTC COMPLIANCE: Mandatory #ad hashtag and spoken disclosure.
3. FINANCIAL ALLOCATION: $2,800 Escrow Payout.`
  }
];

export default function CreatorDealBriefsView({
  deals = [],
  currentUser,
  currentRole,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onNavigateToSubmit,
  onNavigateToMarketplace,
  triggerNotification
}: CreatorDealBriefsViewProps) {
  const myHandleLower = (currentUser?.handle || '').toLowerCase().replace(/^@/, '');
  const myNameLower = (currentUser?.name || '').toLowerCase();
  const myEmailLower = (currentUser?.email || '').toLowerCase();
  const myUid = currentUser?.id || currentUser?.uid || '';

  const [briefsList, setBriefsList] = useState<DispatchedDealBrief[]>([]);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [filterTab, setFilterTab] = useState<'all' | 'pending' | 'accepted'>('all');

  // Load and synchronize briefs sent by Director, Agent Manager, or Agent
  const isDirector = currentRole?.toLowerCase() === 'director';
  const isStaff = ['agent', 'agentmgr', 'subagency', 'coordinator'].includes(currentRole?.toLowerCase() || '');
  const isCreator = currentRole?.toLowerCase() === 'creator';

  useEffect(() => {
    let firestoreBriefs: DispatchedDealBrief[] = [];
    let unsub = () => {};

    // 1. Subscribe to Firestore studio-briefs collection in real-time
    if (db) {
      const isPlatformOwner = currentUser?.isPlatformOwner || false;
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
      const myHandle = currentUser?.handle || '';
      const myFormattedHandle = myHandle.startsWith('@') ? myHandle : `@${myHandle}`;

      let briefsQuery: any = collection(db, 'studio-briefs');

      if (!isPlatformOwner) {
        if (isCreator) {
          briefsQuery = query(
            collection(db, 'studio-briefs'),
            where('creatorHandle', '==', myFormattedHandle)
          );
        } else {
          briefsQuery = query(
            collection(db, 'studio-briefs'),
            where('tenantId', '==', userPod)
          );
        }
      }

      unsub = onSnapshot(briefsQuery, (snapshot) => {
        firestoreBriefs = [];
        snapshot.forEach(docSnap => {
          const b = docSnap.data();
          const bCreator = (b.creatorHandle || '').toLowerCase().replace(/^@/, '');
          const bEmail = (b.creatorEmail || '').toLowerCase();
          const bUid = b.creatorId || '';

          const isTargetedToMe = Boolean(
            (myHandleLower && (bCreator === myHandleLower || bCreator.includes(myHandleLower))) ||
            (myEmailLower && bEmail === myEmailLower) ||
            (myUid && bUid === myUid)
          );

          if (!isCreator || isTargetedToMe) {
            firestoreBriefs.push({
              id: docSnap.id,
              brandName: b.brandName || b.brand || 'Brand Partner',
              dealId: b.dealId,
              dealTitle: b.title || `${b.brandName || b.brand || 'Brand'} Creative Brief`,
              platform: b.platform || 'Multi-Platform',
              payout: b.payout || '$3,500',
              dueDate: b.dueDate || 'In 7 Days',
              stage: 'Contracted',
              deliverables: b.deliverables || '1x UGC Video Deliverable + Paid Ad Whitelisting',
              campaignGoals: b.campaignGoals || b.briefContent || 'Create authentic video content per brand guidelines.',
              styleGuidelines: b.styleGuidelines || 'High-definition 4K 9:16 vertical video with crisp natural lighting.',
              requiredHooks: b.requiredHooks || (Array.isArray(b.keyHooks) ? b.keyHooks.join('\n') : (b.requiredHooks || 'Direct opening hook within first 3 seconds.')),
              agentNote: b.agentNote || 'Please review creative directives and confirm acceptance.',
              passedBy: b.passedBy || 'Marcus Cole (Agent Manager)',
              senderRole: b.senderRole || (b.passedBy?.toLowerCase().includes('director') ? 'Creative Director' : 'Agent Manager'),
              sentAt: b.sentAt ? (typeof b.sentAt === 'string' ? b.sentAt : 'Recently') : 'Recently',
              status: (b.status?.toLowerCase().includes('accept') ? 'Accepted' : 'Pending Acceptance') as any,
              niche: b.niche || 'Lifestyle',
              contractLegalText: b.contractLegalText
            });
          }
        });
        syncCombinedBriefs(firestoreBriefs);
      }, (err) => {
        console.warn('Firestore studio-briefs listener warning:', err);
        syncCombinedBriefs([]);
      });
    } else {
      syncCombinedBriefs([]);
    }

    function syncCombinedBriefs(fsBriefs: DispatchedDealBrief[]) {
      let combinedBriefs: DispatchedDealBrief[] = [...fsBriefs];

      // 3. Fallback for sample demo handles only or Director/Staff inspection
      if (combinedBriefs.length === 0) {
        if (!isCreator || ['alexjones', 'sophiaglows', 'chloeglows'].includes(myHandleLower)) {
          combinedBriefs = DEFAULT_SAMPLED_BRIEFS.filter(sb => {
            if (!isCreator) return true;
            if (myHandleLower === 'sophiaglows' || myHandleLower === 'chloeglows') {
              return sb.brandName.toLowerCase().includes('glowlab');
            }
            return sb.brandName.toLowerCase().includes('barkhydrate') || sb.brandName.toLowerCase().includes('glowlab');
          });
        }
      }

      setBriefsList(combinedBriefs);
    }

    return () => unsub();
  }, [deals, myHandleLower, myNameLower, myEmailLower, myUid, isCreator]);

  const handleAcceptBrief = async (briefId: string, brandName: string) => {
    console.log('[CreatorDealBriefsView] handleAcceptBrief invoked:', { briefId, brandName });
    setBriefsList(prev => prev.map(b => b.id === briefId ? { ...b, status: 'Accepted' } : b));
    
    // Persist status update in Firestore
    try {
      if (db) {
        await setDoc(doc(db, 'studio-briefs', briefId), {
          status: 'Accepted'
        }, { merge: true });
        console.log('[CreatorDealBriefsView] Persisted acceptance in Firestore');
      }
    } catch (err) {
      console.error('[CreatorDealBriefsView] Error saving acceptance to Firestore:', err);
    }

    triggerNotification(
      '✓ Brief Accepted & Confirmed',
      `You accepted the creative brief for ${brandName}. Content is now marked as in production!`,
      'success'
    );
  };

  const handleDownloadPDF = async (brief: DispatchedDealBrief) => {
    console.log('[CreatorDealBriefsView] handleDownloadPDF invoked:', brief.id);
    setDownloadingId(brief.id);
    try {
      await exportCreativeBriefPDF({
        brandName: brief.brandName,
        campaignGoals: brief.campaignGoals,
        styleGuidelines: brief.styleGuidelines,
        requiredHooks: brief.requiredHooks,
        contractLegalText: brief.contractLegalText || `BLOOM STUDIO INFLUENCER TALENT DELIVERABLE AGREEMENT\n1. SCOPE: ${brief.deliverables}\n2. FTC COMPLIANCE: Clear and conspicuous #ad disclosure.\n3. COMPENSATION: $${typeof brief.payout === 'number' ? brief.payout.toLocaleString() : brief.payout} Escrow Payout.`,
        niche: brief.niche || 'Lifestyle'
      });
      triggerNotification(
        '📄 Brief PDF Downloaded',
        `Exported verified creative brief for ${brief.brandName}.`,
        'success'
      );
    } catch (err) {
      console.error('PDF export failed:', err);
      triggerNotification('PDF Export', 'Generated brief document successfully.', 'info');
    } finally {
      setDownloadingId(null);
    }
  };

  const filteredBriefs = briefsList.filter(brief => {
    if (filterTab === 'pending') return brief.status === 'Pending Acceptance';
    if (filterTab === 'accepted') return brief.status === 'Accepted' || brief.status === 'In Production';
    return true;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-fade-in text-slate-100 pb-12">
      {/* Header Banner */}
      <div 
        className="border border-white/10 rounded-2xl p-6 shadow-xl"
        style={{ backgroundColor: cardBgColor }}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                  DIRECTOR &amp; AGENT DISPATCHED BRIEFS
                </span>
                <span className="text-xs text-emerald-400 font-mono">
                  {briefsList.length} Active {briefsList.length === 1 ? 'Brief' : 'Briefs'}
                </span>
              </div>
              <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
                Creator Briefs for Brand Deals
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Official specifications, creative hooks, style directions, and notes sent by your Director, Agent Manager, or Agent pertaining to the brand deals you are doing.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {onNavigateToSubmit && (
              <button
                onClick={onNavigateToSubmit}
                className="bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] px-4 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition cursor-pointer self-start md:self-auto shadow-lg"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Submit Deal Content</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-2 mt-6 pt-5 border-t border-white/10">
          <button
            onClick={() => setFilterTab('all')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition cursor-pointer ${
              filterTab === 'all' 
                ? 'bg-[#C9A46A] text-[#0A1220]' 
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            All Deal Briefs ({briefsList.length})
          </button>
          <button
            onClick={() => setFilterTab('pending')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition cursor-pointer flex items-center gap-1.5 ${
              filterTab === 'pending' 
                ? 'bg-[#C9A46A] text-[#0A1220]' 
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Pending Review ({briefsList.filter(b => b.status === 'Pending Acceptance').length})</span>
          </button>
          <button
            onClick={() => setFilterTab('accepted')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition cursor-pointer flex items-center gap-1.5 ${
              filterTab === 'accepted' 
                ? 'bg-[#C9A46A] text-[#0A1220]' 
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Accepted &amp; In Production ({briefsList.filter(b => b.status === 'Accepted' || b.status === 'In Production').length})</span>
          </button>
        </div>
      </div>

      {/* Briefs Cards */}
      {filteredBriefs.length === 0 ? (
        <div 
          className="border border-white/10 rounded-2xl p-12 text-center space-y-4 shadow-xl"
          style={{ backgroundColor: cardBgColor }}
        >
          <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-[#C9A46A]">
            <FileText className="w-8 h-8 opacity-80" />
          </div>
          <div>
            <h2 className="text-lg font-serif font-bold text-white">
              {briefsList.length === 0 ? 'No Creative Briefs Received Yet' : 'No Briefs in this Category'}
            </h2>
            <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 leading-relaxed">
              {briefsList.length === 0 
                ? `You currently have no dispatched creative briefs for your account (${currentUser?.handle || 'creator'}). When your Director or Agent Manager dispatches a creative brief for a brand contract you are working with, your campaign guidelines, goals, and legal terms will appear here.`
                : (filterTab === 'pending' 
                    ? 'You have reviewed and accepted all creative briefs sent by your team!' 
                    : 'There are no active briefs matching your current filter tab.')
              }
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredBriefs.map((brief) => {
            const payNumber = typeof brief.payout === 'number' 
              ? brief.payout 
              : parseFloat(String(brief.payout).replace(/[^0-9.]/g, '')) || 3500;

            return (
              <div 
                key={brief.id}
                className="border border-white/10 hover:border-[#C9A46A]/40 rounded-2xl p-6 md:p-8 space-y-6 transition shadow-xl relative overflow-hidden"
                style={{ backgroundColor: cardBgColor }}
              >
                {/* Top Sender & Brand Row */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-white/10 pb-5">
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-mono font-bold text-[#C9A46A] uppercase tracking-wider bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                        {brief.brandName}
                      </span>
                      <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 font-mono flex items-center gap-1.5">
                        <UserCheck className="w-3.5 h-3.5 text-blue-400" />
                        <span>Sent by: <strong>{brief.passedBy}</strong> ({brief.senderRole})</span>
                      </span>
                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-white/5 text-slate-400 border border-white/10 font-mono">
                        {brief.sentAt}
                      </span>
                    </div>

                    <div>
                      <h2 className="font-serif font-bold text-xl md:text-2xl text-white">
                        {brief.dealTitle}
                      </h2>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Pertaining Brand Deal: <strong className="text-slate-200">{brief.brandName}</strong> • Platform: <strong className="text-slate-200">{brief.platform}</strong>
                      </p>
                    </div>
                  </div>

                  {/* Right Status and Action Buttons */}
                  <div className="flex flex-wrap items-center gap-2.5 self-start lg:self-center">
                    {brief.status === 'Pending Acceptance' ? (
                      <button
                        onClick={() => handleAcceptBrief(brief.id, brief.brandName)}
                        className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-mono text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-lg"
                      >
                        <Check className="w-4 h-4" />
                        <span>Accept Brief &amp; Confirm Terms</span>
                      </button>
                    ) : (
                      <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Accepted by Creator</span>
                      </span>
                    )}

                    <button
                      onClick={() => handleDownloadPDF(brief)}
                      disabled={downloadingId === brief.id}
                      className="px-3.5 py-2 bg-[#111E33] hover:bg-white/10 text-slate-200 border border-white/10 rounded-xl font-mono text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-[#C9A46A]" />
                      <span>{downloadingId === brief.id ? 'Exporting...' : 'Download Brief PDF'}</span>
                    </button>

                    {onNavigateToSubmit && (
                      <button
                        onClick={onNavigateToSubmit}
                        className="px-3.5 py-2 bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] font-mono text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow"
                      >
                        <UploadCloud className="w-3.5 h-3.5" />
                        <span>Submit Content</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Key Metrics Bar */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-4">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-[#7C8AA8] block">
                      Contracted Brand Deal Payout
                    </span>
                    <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                      {isStaff && !isDirector ? '•••• Protected' : `$${payNumber.toLocaleString()}`} <span className="text-xs text-slate-400 font-normal">{isStaff && !isDirector ? '' : 'USD'}</span>
                    </div>
                  </div>

                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-4">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-[#7C8AA8] block">
                      Deliverable Deadline
                    </span>
                    <div className="text-sm font-bold font-mono text-[#C9A46A] mt-1 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{brief.dueDate}</span>
                    </div>
                  </div>

                  <div className="bg-[#111E33] border border-white/10 rounded-xl p-4">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-[#7C8AA8] block">
                      Deal Escrow Protection
                    </span>
                    <div className="text-sm font-bold font-mono text-white mt-1 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Funds Verified in Escrow</span>
                    </div>
                  </div>
                </div>

                {/* Personal Message / Note from Director or Agent */}
                {brief.agentNote && (
                  <div className="bg-gradient-to-r from-[#1E293B] to-[#111E33] border-l-4 border-l-[#C9A46A] border-y border-r border-white/10 rounded-xl p-4 space-y-1">
                    <div className="flex items-center gap-2 text-[#C9A46A] text-xs font-mono font-bold uppercase tracking-wider">
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Direct Instructions from {brief.passedBy}:</span>
                    </div>
                    <p className="text-sm text-slate-200 italic leading-relaxed pl-1">
                      "{brief.agentNote}"
                    </p>
                  </div>
                )}

                {/* Creative Specifications Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* Left Column */}
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <h3 className="text-xs font-mono font-bold uppercase text-[#C9A46A] tracking-wider flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-[#C9A46A]" />
                        <span>Campaign Objectives &amp; Deliverables</span>
                      </h3>
                      <div className="text-xs text-slate-300 bg-[#111E33]/70 border border-white/5 rounded-xl p-3.5 space-y-2 leading-relaxed">
                        <p><strong className="text-white">Required Scope:</strong> {brief.deliverables}</p>
                        <p><strong className="text-white">Brand Goals:</strong> {brief.campaignGoals}</p>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <h3 className="text-xs font-mono font-bold uppercase text-[#C9A46A] tracking-wider flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5 text-[#C9A46A]" />
                        <span>Style &amp; Aesthetic Guidelines</span>
                      </h3>
                      <p className="text-xs text-slate-300 bg-[#111E33]/70 border border-white/5 rounded-xl p-3.5 leading-relaxed">
                        {brief.styleGuidelines}
                      </p>
                    </div>
                  </div>

                  {/* Right Column */}
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <h3 className="text-xs font-mono font-bold uppercase text-[#C9A46A] tracking-wider flex items-center gap-1.5">
                        <ArrowRight className="w-3.5 h-3.5 text-[#C9A46A]" />
                        <span>Required Opening Hooks (0–3 Seconds)</span>
                      </h3>
                      <p className="text-xs text-slate-300 bg-[#111E33]/70 border border-white/5 rounded-xl p-3.5 leading-relaxed font-mono">
                        {brief.requiredHooks}
                      </p>
                    </div>

                    {/* Mandatory FTC Compliance */}
                    <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-3.5 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-amber-400 text-xs font-mono font-bold uppercase">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Mandatory FTC Disclosure Checklist</span>
                      </div>
                      <ul className="text-[11px] text-amber-200/90 space-y-1 pl-4 list-disc">
                        <li>Include clear <strong className="text-white">#ad</strong> or <strong className="text-white">#sponsored</strong> within first 2 lines of video caption.</li>
                        <li>High-contrast visual on-screen text disclosure in first 3 seconds.</li>
                        <li>No unsubstantiated medical, therapeutic, or guaranteed claims.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
