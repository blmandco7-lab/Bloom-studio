import React from 'react';
import { 
  Plus, DollarSign, Megaphone, UserPlus, FileText, 
  Send, Users, MessageSquare, Video, Shield, Zap, Target, Sparkles,
  Clapperboard, Music
} from 'lucide-react';
import { Role } from '../types';

interface QuickActionsBarProps {
  currentRole: Role;
  primaryBrandColor?: string;
  canLogCampaigns?: boolean;
  canCreateMissions?: boolean;
  agentMgrCanAnnounce?: boolean;
  onOpenAddCreator?: () => void;
  onOpenLogDeal?: () => void;
  onOpenBroadcast?: () => void;
  onOpenAssignAgent?: () => void;
  onOpenWaitlist?: () => void;
  onOpenCreatorProfile?: () => void;
  onNavigate?: (screen: string) => void;
}

export const QuickActionsBar: React.FC<QuickActionsBarProps> = ({
  currentRole,
  primaryBrandColor = '#C9A46A',
  canLogCampaigns = false,
  canCreateMissions = false,
  agentMgrCanAnnounce = false,
  onOpenAddCreator,
  onOpenLogDeal,
  onOpenBroadcast,
  onOpenAssignAgent,
  onOpenWaitlist,
  onOpenCreatorProfile,
  onNavigate
}) => {
  const role = (currentRole || 'none').toLowerCase();

  const renderRoleActions = () => {
    switch (role) {
      case 'director':
        return [
          {
            label: 'Sign Creator',
            icon: Plus,
            color: 'from-amber-500/20 to-amber-600/10 border-amber-500/40 text-amber-300',
            action: onOpenAddCreator
          },
          {
            label: 'Log Deal',
            icon: DollarSign,
            color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/40 text-emerald-300',
            action: onOpenLogDeal
          },
          {
            label: 'Broadcast',
            icon: Megaphone,
            color: 'from-sky-500/20 to-sky-600/10 border-sky-500/40 text-sky-300',
            action: onOpenBroadcast
          },
          {
            label: 'Assign Agent',
            icon: UserPlus,
            color: 'from-purple-500/20 to-purple-600/10 border-purple-500/40 text-purple-300',
            action: onOpenAssignAgent
          },
          {
            label: 'Add Waitlist',
            icon: FileText,
            color: 'from-indigo-500/20 to-indigo-600/10 border-indigo-500/40 text-indigo-300',
            action: onOpenWaitlist
          }
        ];

      case 'agentmgr': {
        const mgrActions: any[] = [
          {
            label: 'Suggest Creator',
            icon: Plus,
            color: 'from-amber-500/20 to-amber-600/10 border-amber-500/40 text-amber-300',
            action: onOpenAddCreator
          },
          {
            label: 'Assign Agent',
            icon: UserPlus,
            color: 'from-purple-500/20 to-purple-600/10 border-purple-500/40 text-purple-300',
            action: onOpenAssignAgent
          }
        ];
        if (canLogCampaigns) {
          mgrActions.splice(2, 0, {
            label: 'Log Deal / Campaign',
            icon: DollarSign,
            color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/40 text-emerald-300',
            action: onOpenLogDeal
          });
        }
        if (canCreateMissions) {
          mgrActions.splice(canLogCampaigns ? 3 : 2, 0, {
            label: 'Launch Mission',
            icon: Target,
            color: 'from-purple-500/20 to-purple-600/10 border-purple-500/40 text-purple-300',
            action: () => onNavigate && onNavigate('missions')
          });
        }
        if (agentMgrCanAnnounce) {
          mgrActions.push({
            label: 'Broadcast',
            icon: Megaphone,
            color: 'from-sky-500/20 to-sky-600/10 border-sky-500/40 text-sky-300',
            action: onOpenBroadcast
          });
        }
        return mgrActions;
      }

      case 'agent':
        return [
          {
            label: 'Suggest Creator',
            icon: Plus,
            color: 'from-amber-500/20 to-amber-600/10 border-amber-500/40 text-amber-300',
            action: onOpenAddCreator
          },
          {
            label: 'Review Reels',
            icon: Video,
            color: 'from-sky-500/20 to-sky-600/10 border-sky-500/40 text-sky-300',
            action: () => onNavigate && onNavigate('content-review')
          },
          {
            label: 'Messages',
            icon: MessageSquare,
            color: 'from-purple-500/20 to-purple-600/10 border-purple-500/40 text-purple-300',
            action: () => onNavigate && onNavigate('chat-system')
          }
        ];

      case 'brand':
        return [
          {
            label: 'Submit Inquiry',
            icon: Send,
            color: 'from-amber-500/20 to-amber-600/10 border-amber-500/40 text-amber-300',
            action: () => onNavigate && onNavigate('brand-crm')
          },
          {
            label: 'Pay Invoices',
            icon: DollarSign,
            color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/40 text-emerald-300',
            action: () => onNavigate && onNavigate('invoices')
          },
          {
            label: 'Review Content',
            icon: Video,
            color: 'from-sky-500/20 to-sky-600/10 border-sky-500/40 text-sky-300',
            action: () => onNavigate && onNavigate('brand-review-portal')
          }
        ];

      case 'creator':
        return [
          {
            label: 'Submit Reel',
            icon: Video,
            color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/40 text-emerald-300',
            action: () => onNavigate && onNavigate('content-library')
          },
          {
            label: 'Animate Video',
            icon: Clapperboard,
            color: 'from-purple-500/20 to-purple-600/10 border-purple-500/40 text-purple-300',
            action: () => onNavigate && onNavigate('animate-video')
          },
          {
            label: 'Generate Music',
            icon: Music,
            color: 'from-amber-500/20 to-amber-600/10 border-amber-500/40 text-amber-300',
            action: () => onNavigate && onNavigate('generate-music')
          },
          {
            label: 'Edit Profile',
            icon: FileText,
            color: 'from-blue-500/20 to-blue-600/10 border-blue-500/40 text-blue-300',
            action: () => {
              if (onOpenCreatorProfile) onOpenCreatorProfile();
              else if (onNavigate) onNavigate('creator-portal');
            }
          },
          {
            label: 'Message Agent',
            icon: MessageSquare,
            color: 'from-sky-500/20 to-sky-600/10 border-sky-500/40 text-sky-300',
            action: () => onNavigate && onNavigate('chat-system')
          }
        ];

      case 'subagency':
        return [
          {
            label: 'Add Sub-Creator',
            icon: Plus,
            color: 'from-amber-500/20 to-amber-600/10 border-amber-500/40 text-amber-300',
            action: onOpenAddCreator
          },
          {
            label: 'Log Sub-Deal',
            icon: DollarSign,
            color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/40 text-emerald-300',
            action: onOpenLogDeal
          },
          {
            label: 'Vault Contracts',
            icon: Shield,
            color: 'from-indigo-500/20 to-indigo-600/10 border-indigo-500/40 text-indigo-300',
            action: () => onNavigate && onNavigate('contracts')
          }
        ];

      default:
        return [];
    }
  };

  const actions = renderRoleActions();

  if (actions.length === 0) return null;

  return (
    <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-3.5 shadow-xl animate-fade-in relative overflow-hidden">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div 
            className="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-[#0A1220]"
            style={{ backgroundColor: primaryBrandColor }}
          >
            <Zap className="w-4 h-4 fill-current" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Quick Actions ({role.toUpperCase()})
            </h4>
            <p className="text-[10px] text-slate-400">1-tap shortcut tools scoped to your active permissions</p>
          </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {actions.map((act, idx) => {
            const Icon = act.icon;
            return (
              <button
                key={idx}
                onClick={act.action}
                className={`bg-gradient-to-r ${act.color} border hover:border-white/40 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all transform hover:-translate-y-0.5 cursor-pointer shadow-md`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{act.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
