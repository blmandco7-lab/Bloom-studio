import React, { useState } from 'react';
import { 
  DollarSign, 
  Sparkles, 
  Video, 
  Repeat, 
  PlusCircle, 
  ShieldCheck, 
  CheckCircle2, 
  Save,
  Lock,
  Layers,
  X,
  HelpCircle,
  Clock,
  Send,
  Share2,
  Copy,
  Check
} from 'lucide-react';

interface BrandContractUpsellManifestProps {
  userRole?: string; // Must be 'director' or 'owner'
  baseContractValue?: number;
  campaignId?: string;
  brandName?: string;
  onUpdateFinancials?: (newGrossTotal: number, selectedUpsells: UpsellItem[]) => void;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}

export interface UpsellItem {
  id: string;
  category: 'Rights' | 'Retainer' | 'Addon' | 'Exclusivity' | 'Production';
  status: 'Inquire' | 'Negotiating' | 'Approved & Billed' | 'Paid';
  title: string;
  description: string;
  defaultPrice: number;
  customPrice: number;
  enabled: boolean;
}

export default function BrandContractUpsellManifest({
  userRole = 'director',
  baseContractValue = 15000,
  campaignId = "camp_0912",
  brandName = "Lumina Cosmetics",
  onUpdateFinancials,
  triggerNotification,
  onAddActivityLog
}: BrandContractUpsellManifestProps) {
  // CRITICAL SECURITY ENFORCEMENT: Completely hidden from Agent, Manager, Coordinator roles
  const normalizedRole = userRole.toLowerCase();
  if (normalizedRole !== 'director' && normalizedRole !== 'owner' && normalizedRole !== 'agency') {
    return null;
  }

  const [selectedBrand, setSelectedBrand] = useState<string>(brandName || 'Lumina Cosmetics LLC');
  const [customBrandInput, setCustomBrandInput] = useState<string>('');
  const [showOptionsModal, setShowOptionsModal] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [basePrice, setBasePrice] = useState<number>(baseContractValue);
  const [upsells, setUpsells] = useState<UpsellItem[]>([
    {
      id: 'upsell_rights_buyout',
      category: 'Rights',
      status: 'Inquire',
      title: 'Full Commercial IP & Copyright Ownership Transfer',
      description: 'Allows the brand to run the UGC video as paid ads indefinitely across Meta, TikTok, YouTube, and digital web without expiration or royalty claims.',
      defaultPrice: 5000,
      customPrice: 5000,
      enabled: false
    },
    {
      id: 'upsell_creator_retainer',
      category: 'Retainer',
      status: 'Inquire',
      title: 'Monthly Creator Retainer Model (3-5 Deliverables / 30 Days)',
      description: 'Locks the influencer into producing 3 to 5 pieces of high-converting content every 30 days for continuous organic and paid brand pipeline flow.',
      defaultPrice: 8500,
      customPrice: 8500,
      enabled: false
    },
    {
      id: 'upsell_exclusivity',
      category: 'Exclusivity',
      status: 'Inquire',
      title: 'Category Exclusivity Lock (30–90 Days)',
      description: 'Prevents the creator from accepting sponsorships or producing content for competing brands in the same niche during the campaign window.',
      defaultPrice: 3500,
      customPrice: 3500,
      enabled: false
    },
    {
      id: 'upsell_hook_bundle',
      category: 'Production',
      status: 'Inquire',
      title: 'A/B Hook & Intro Variant Bundle (3x Alternative Intros)',
      description: 'Provides 3 unique 3-second visual and verbal hook variations for the video to test different ad angles and maximize click-through rate.',
      defaultPrice: 2200,
      customPrice: 2200,
      enabled: false
    },
    {
      id: 'upsell_extended_usage',
      category: 'Rights',
      status: 'Inquire',
      title: '12-Month Extended Paid Ad Usage License',
      description: 'Extends standard 30-day paid advertising permissions to a full 365-day worldwide usage window.',
      defaultPrice: 4500,
      customPrice: 4500,
      enabled: false
    },
    {
      id: 'upsell_rush_delivery',
      category: 'Production',
      status: 'Inquire',
      title: 'Rush 48-Hour Express Production & Turnaround',
      description: 'Fast-tracks script review, creator recording, and final asset delivery within 48 business hours.',
      defaultPrice: 2000,
      customPrice: 2000,
      enabled: false
    },
    {
      id: 'upsell_raw_footage',
      category: 'Addon',
      status: 'Inquire',
      title: 'Raw 4K Footage & B-Roll Master Access',
      description: 'Delivers raw unedited 4K camera files and alternate take reels directly to the brand internal creative editing team.',
      defaultPrice: 1500,
      customPrice: 1500,
      enabled: false
    },
    {
      id: 'upsell_crossposting',
      category: 'Addon',
      status: 'Inquire',
      title: 'Multi-Platform Cross-Posting (TikTok + IG Reels + YouTube Shorts)',
      description: 'Simultaneous synchronized posting across creator native high-engagement channels.',
      defaultPrice: 2000,
      customPrice: 2000,
      enabled: false
    },
    {
      id: 'upsell_whitelisting',
      category: 'Addon',
      status: 'Inquire',
      title: 'Paid Ads Whitelisting & Spark Ad Authorization',
      description: 'Provides 60-day Spark Ad code access and Meta advertiser access for brand ad accounts.',
      defaultPrice: 3000,
      customPrice: 3000,
      enabled: false
    },
    {
      id: 'upsell_whitelabel',
      category: 'Addon',
      status: 'Inquire',
      title: 'Whitelabel Ad Account Integration',
      description: 'Custom dark-posting configuration directly through Bloom Studio enterprise agency Ad accounts.',
      defaultPrice: 3500,
      customPrice: 3500,
      enabled: false
    },
    {
      id: 'upsell_dooh_broadcast',
      category: 'Rights',
      status: 'Inquire',
      title: 'Digital Out-of-Home (DOOH), Broadcast & OTT Rights',
      description: 'Clears rights for digital billboards, connected TV (CTV/OTT), streaming platforms, and retail display screens.',
      defaultPrice: 7500,
      customPrice: 7500,
      enabled: false
    },
    {
      id: 'upsell_event_hosting',
      category: 'Addon',
      status: 'Inquire',
      title: 'Creator Live Event Attendance & In-Person Launch Hosting',
      description: 'In-person creator appearance at brand pop-up events, product launches, or live Q&A streaming sessions.',
      defaultPrice: 6000,
      customPrice: 6000,
      enabled: false
    }
  ]);

  const [savedSuccess, setSavedSuccess] = useState(false);

  const toggleUpsell = (id: string) => {
    setUpsells(prev => prev.map(item => item.id === id ? { ...item, enabled: !item.enabled } : item));
    setSavedSuccess(false);
  };

  const updatePrice = (id: string, newPrice: number) => {
    setUpsells(prev => prev.map(item => item.id === id ? { ...item, customPrice: newPrice } : item));
    setSavedSuccess(false);
  };

  const updateStatus = (id: string, newStatus: UpsellItem['status']) => {
    setUpsells(prev => prev.map(item => item.id === id ? { ...item, status: newStatus } : item));
    setSavedSuccess(false);
  };

  const activeUpsellTotal = upsells
    .filter(u => u.enabled)
    .reduce((sum, u) => sum + (Number(u.customPrice) || 0), 0);

  const calculatedGrossTotal = basePrice + activeUpsellTotal;

  const handleSaveToContract = () => {
    if (onUpdateFinancials) {
      onUpdateFinancials(calculatedGrossTotal, upsells.filter(u => u.enabled));
    }
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleCopyShareLink = () => {
    const targetBrand = selectedBrand === 'Custom Brand' ? (customBrandInput || 'Brand') : selectedBrand;
    const shareUrl = `${window.location.origin}/#upsell-manifest?brand=${encodeURIComponent(targetBrand)}&campaign=${campaignId}`;
    navigator.clipboard.writeText(shareUrl).catch(() => {});
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);

    if (triggerNotification) {
      triggerNotification(
        "Brand Share Link Copied",
        `Share link for ${targetBrand} contract upsell manifest copied to clipboard.`,
        "success"
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        "Director",
        userRole,
        `Shared Brand Contract Upsell Manifest link for ${targetBrand}`
      );
    }
  };

  return (
    <div className="w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6 font-sans text-agency-textLight animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-white/10 gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
            <Lock className="w-4 h-4" />
            <span>Director Executive Tool • Gross Contract Manifest</span>
          </div>
          <h3 className="text-xl md:text-2xl font-serif font-bold text-white">
            Brand Contract Upsell &amp; Monetization Manifest
          </h3>
          <p className="text-xs text-slate-400">
            Monetization modules default to <strong className="text-amber-400 font-mono">Inquire</strong> until Director and Brand finalize payment terms. Custom prices can be logged anytime.
          </p>
        </div>

        {/* Real-time Calculation Badge */}
        <div className="p-4 bg-agency-navy rounded-2xl border border-agency-gold/30 text-right shrink-0">
          <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Updated Gross Contract Value</div>
          <div className="text-2xl font-mono font-bold text-agency-gold">${calculatedGrossTotal.toLocaleString()}</div>
          <div className="text-[10px] font-mono text-emerald-400">+${activeUpsellTotal.toLocaleString()} in added value</div>
        </div>
      </div>

      {/* Target Brand Dropdown Selector & Contract Controls */}
      <div className="p-5 bg-agency-navy rounded-2xl border border-agency-gold/30 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="space-y-1">
            <label className="text-xs font-mono font-bold uppercase tracking-wider text-agency-gold flex items-center gap-2">
              <Layers className="w-4 h-4 text-agency-gold" />
              Select Target Brand Client for Contract Update
            </label>
            <p className="text-[11px] text-slate-400">
              Choose the brand client this contract agreement and upsell manifest belongs to.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap self-start md:self-center shrink-0">
            <button
              type="button"
              onClick={handleCopyShareLink}
              className="px-4 py-2 bg-[#C9A46A] hover:bg-[#b89359] text-agency-navy font-bold rounded-xl text-xs font-mono transition cursor-pointer flex items-center gap-2 shadow-lg"
              title="Copy shareable link for this brand upsell manifest"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-agency-navy" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Link Copied!' : 'Copy Brand Share Link'}</span>
            </button>

            <button
              type="button"
              onClick={() => setShowOptionsModal(true)}
              className="px-4 py-2 bg-agency-navyLight hover:bg-agency-navy border border-agency-gold/40 text-agency-gold rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Preview Brand Upsell Pop-up</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div>
            <select
              value={selectedBrand}
              onChange={e => setSelectedBrand(e.target.value)}
              className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-2.5 text-xs font-mono text-white font-bold focus:outline-none focus:border-agency-gold cursor-pointer"
            >
              <option value="Lumina Cosmetics LLC">Lumina Cosmetics LLC</option>
              <option value="Bark Organics">Bark Organics</option>
              <option value="Sephora Beauty">Sephora Beauty</option>
              <option value="Nike Global Partnerships">Nike Global Partnerships</option>
              <option value="Gymshark Apparel">Gymshark Apparel</option>
              <option value="Glossier Skin">Glossier Skin</option>
              <option value="Custom Brand">-- Add Custom Brand --</option>
            </select>
          </div>

          {selectedBrand === 'Custom Brand' && (
            <div>
              <input
                type="text"
                placeholder="Type Custom Brand Client Name..."
                value={customBrandInput}
                onChange={e => setCustomBrandInput(e.target.value)}
                className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-4 py-2.5 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-agency-gold"
              />
            </div>
          )}
        </div>
      </div>

      {/* Base Contract Price Setting */}
      <div className="p-4 bg-agency-navy rounded-2xl border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">Base Campaign Booking Value ($)</span>
          <p className="text-[11px] text-slate-400">Fixed core campaign tier agreed in preliminary intake.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-agency-gold font-bold">$</span>
          <input
            type="number"
            value={basePrice}
            onChange={e => {
              setBasePrice(Number(e.target.value) || 0);
              setSavedSuccess(false);
            }}
            className="w-36 bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-xs font-mono text-white text-right focus:outline-none focus:border-agency-gold"
          />
        </div>
      </div>

      {/* Upsell Items Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-agency-gold">
            Selectable Monetization Add-on Modules
          </h4>
          <span className="text-[11px] font-mono text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full flex items-center gap-1">
            <HelpCircle className="w-3 h-3" /> Status defaults to Inquire
          </span>
        </div>

        <div className="grid grid-cols-1 gap-3.5">
          {upsells.map(item => (
            <div
              key={item.id}
              className={`p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                item.enabled 
                  ? 'bg-agency-gold/10 border-agency-gold/60 shadow-lg' 
                  : 'bg-agency-navy/60 border-white/5 hover:border-white/15'
              }`}
            >
              <div className="flex items-start gap-3 flex-1">
                <input
                  type="checkbox"
                  checked={item.enabled}
                  onChange={() => toggleUpsell(item.id)}
                  className="mt-1 w-4 h-4 text-agency-gold rounded focus:ring-agency-gold cursor-pointer"
                />
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-bold text-white font-serif">{item.title}</span>
                    
                    {/* Inquire Status Badge */}
                    <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase flex items-center gap-1 ${
                      item.status === 'Inquire' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                      item.status === 'Approved & Billed' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                      'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    }`}>
                      <Clock className="w-2.5 h-2.5" />
                      Status: {item.status}
                    </span>

                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase ${
                      item.category === 'Rights' ? 'bg-purple-500/20 text-purple-300' :
                      item.category === 'Retainer' ? 'bg-amber-500/20 text-amber-300' :
                      item.category === 'Exclusivity' ? 'bg-rose-500/20 text-rose-300' :
                      item.category === 'Production' ? 'bg-emerald-500/20 text-emerald-300' :
                      'bg-blue-500/20 text-blue-300'
                    }`}>
                      {item.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed max-w-2xl">{item.description}</p>
                </div>
              </div>

              {/* Status Selector & Price Modifier */}
              <div className="flex items-center gap-3 shrink-0 self-end sm:self-center flex-wrap">
                <select
                  value={item.status}
                  onChange={e => updateStatus(item.id, e.target.value as any)}
                  className="bg-agency-navy border border-white/10 rounded-xl px-2.5 py-1.5 text-[11px] font-mono text-slate-200 focus:outline-none focus:border-agency-gold cursor-pointer"
                >
                  <option value="Inquire">Inquire (Pending Discussion)</option>
                  <option value="Negotiating">Negotiating</option>
                  <option value="Approved & Billed">Approved &amp; Billed</option>
                  <option value="Paid">Paid</option>
                </select>

                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-mono text-slate-400">Starting at ($):</span>
                  <input
                    type="number"
                    value={item.customPrice}
                    onChange={e => updatePrice(item.id, Number(e.target.value) || 0)}
                    placeholder="Log price"
                    className="w-28 bg-agency-navy border border-agency-gold/40 text-agency-gold font-bold rounded-xl px-3 py-1.5 text-xs font-mono text-right transition focus:outline-none focus:border-agency-gold"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between pt-4 border-t border-white/10 gap-3">
        <div className="text-xs font-mono text-slate-400">
          Syncs directly to <span className="text-white font-mono">financials.brandContractValue</span>. Staff views remain masked.
        </div>

        <button
          type="button"
          onClick={handleSaveToContract}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs uppercase tracking-wider transition shadow-xl cursor-pointer"
        >
          {savedSuccess ? (
            <>
              <CheckCircle2 className="w-4 h-4" />
              <span>Upsell Manifest Saved &amp; Synced!</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>Save &amp; Update Gross Contract Value</span>
            </>
          )}
        </button>
      </div>

      {/* Pop-up Preview Modal */}
      {showOptionsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-agency-navy border border-agency-gold/40 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase">
                <Sparkles className="w-4 h-4" />
                <span>Brand Upsell Options Overview</span>
              </div>
              <button
                onClick={() => setShowOptionsModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              When brands review campaign terms, these high-margin add-ons are displayed in status <strong className="text-amber-400">"Inquire"</strong> so both sides align with the Director before charging.
            </p>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {upsells.map(u => (
                <div key={u.id} className="p-3 bg-agency-navyLight rounded-xl border border-white/5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white block">{u.title}</span>
                    <span className="text-[10px] text-amber-400 font-mono">Status: {u.status}</span>
                  </div>
                  <span className="font-mono font-bold text-agency-gold">${u.customPrice.toLocaleString()}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => setShowOptionsModal(false)}
              className="w-full py-2.5 rounded-xl bg-agency-gold text-agency-navy font-bold text-xs uppercase cursor-pointer"
            >
              Close Preview
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
