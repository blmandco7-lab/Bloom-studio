import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Clock, AlertTriangle, CheckCircle, Mail, Send, Check, Film, Eye, 
  MessageSquare, RefreshCw, Play, Pause, SkipBack, SkipForward, 
  Plus, Share2, Link2, Info, ChevronRight, Lock, Shield, LogOut
} from 'lucide-react';
import { ReviewItem, TimestampedComment } from '../types';

interface BrandReviewPortalProps {
  reviews?: ReviewItem[];
  onSaveReview?: (review: ReviewItem) => void;
  currentUser?: any;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  onExit?: () => void;
}

export default function BrandReviewPortal({
  reviews = [],
  onSaveReview,
  currentUser,
  triggerNotification,
  onAddActivityLog,
  onExit
}: BrandReviewPortalProps) {
  const brandName = currentUser?.name || 'DripRoom';

  // Requirement: Brands get content after it has been approved by director or agent manager.
  const brandApprovedReviews = reviews.filter(r => {
    const matchesBrand = r.brand.toLowerCase() === brandName.toLowerCase();
    const isApproved = r.status === 'Approved' || r.status === 'Approved with Warning' || r.status === 'Posted';
    const matchesDeliverable = currentUser?.activeDeliverableId ? r.id === currentUser.activeDeliverableId : true;
    
    return matchesBrand && isApproved && matchesDeliverable;
  });

  const [selectedReviewId, setSelectedReviewId] = useState<string>('');
  const [ticker, setTicker] = useState<number>(0);

  // Interactive Video States
  const videoRef = useRef<HTMLVideoElement>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showCommentInput, setShowCommentInput] = useState(false);
  const [timestampComment, setTimestampComment] = useState('');
  
  const activeReview = brandApprovedReviews.find(r => r.id === selectedReviewId);

  // Select the first review by default
  useEffect(() => {
    if (brandApprovedReviews.length > 0 && !selectedReviewId) {
      setSelectedReviewId(brandApprovedReviews[0].id);
    }
  }, [brandApprovedReviews, selectedReviewId]);

  // Requirement: Auto-start the 48h timer if it hasn't been started yet when the brand views it
  useEffect(() => {
    if (activeReview && !activeReview.brandReviewStartedAt) {
      const now = new Date();
      const updatedItem: ReviewItem = {
        ...activeReview,
        brandReviewStartedAt: now.toISOString(),
        brandReviewStatus: 'Active',
        comments: [
          ...activeReview.comments,
          `System: 48-hour Brand Review countdown initiated at ${now.toLocaleString()} (Guest Portal accessed).`
        ]
      };
      if (onSaveReview) {
        onSaveReview(updatedItem);
      }
    }
  }, [selectedReviewId, activeReview, onSaveReview]);

  // Real-time ticker to update countdown clocks every second
  useEffect(() => {
    const timer = setInterval(() => {
      setTicker(t => t + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Helper to calculate countdown time left in seconds
  const getRemainingSeconds = (review: ReviewItem) => {
    if (!review.brandReviewStartedAt) return 48 * 3600; // default 48h
    const startedTime = new Date(review.brandReviewStartedAt).getTime();
    const fortyEightHoursMs = 48 * 60 * 60 * 1000;
    const elapsedMs = Date.now() - startedTime;
    const remainingMs = fortyEightHoursMs - elapsedMs;
    return Math.max(0, Math.floor(remainingMs / 1000));
  };

  // Auto-approval logic
  useEffect(() => {
    brandApprovedReviews.forEach(r => {
      if (r.status === 'Posted') return; 

      const remainingSeconds = getRemainingSeconds(r);

      if (remainingSeconds <= 0 && r.brandReviewStatus !== 'Auto Approved') {
        const updatedItem: ReviewItem = {
          ...r,
          status: 'Posted',
          brandReviewStatus: 'Auto Approved',
          comments: [
            ...r.comments,
            `System (2-Day Timer): Feedback window expired. Content automatically marked as APPROVED per SLA.`
          ]
        };
        if (onSaveReview) onSaveReview(updatedItem);
        if (triggerNotification) {
          triggerNotification('Asset Auto-Approved 🔒', `2-day feedback window for ${r.creator}'s draft expired.`, 'success');
        }
      }
    });
  }, [ticker, brandApprovedReviews, onSaveReview]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h > 0 ? h + 'h ' : ''}${m.toString().padStart(2, '0')}m ${s.toString().padStart(2, '0')}s`;
  };

  const handleApproveAndLock = (review: ReviewItem) => {
    const updatedItem: ReviewItem = {
      ...review,
      status: 'Posted',
      brandReviewStatus: 'Feedback Received',
      comments: [
        ...review.comments,
        `System: Brand Partner approved and locked this asset.`
      ]
    };
    if (onSaveReview) onSaveReview(updatedItem);
    if (triggerNotification) {
      triggerNotification('Asset Approved ✓', 'You have approved and locked this asset for final publishing.', 'success');
    }
  };

  const handleRequestRevision = (review: ReviewItem) => {
    const feedback = prompt("Please specify your final revision instructions:");
    if (feedback === null) return;

    const updatedItem: ReviewItem = {
      ...review,
      status: 'Revision Requested',
      brandReviewStatus: undefined,
      comments: [
        ...review.comments,
        `Brand Partner: Requested revisions — ${feedback.trim()}`,
        `System: Content returned to Agency queue with ${review.timestampedComments?.length || 0} timestamped notes.`
      ]
    };
    if (onSaveReview) onSaveReview(updatedItem);
    if (triggerNotification) {
      triggerNotification('Revisions Dispatched', 'Your instructions have been returned to the agency.', 'warning');
    }
  };

  const handleCopyReviewLink = (review: ReviewItem) => {
    if (!review) return;
    try {
      const brandParam = encodeURIComponent(review.brand || 'Client');
      const subagencyParam = encodeURIComponent(currentUser?.subagency || 'pod_main');
      const token = `ROOM-${review.id.substring(0, 8).toUpperCase()}`;
      
      // Use origin + pathname to strip query/hash, then add parameters
      const baseUrl = window.location.origin + window.location.pathname;
      const url = `${baseUrl}?brand-room=true&brand=${brandParam}&token=${token}&deliverable=${review.id}&subagency=${subagencyParam}`;
      
      const copyToClipboard = (text: string) => {
        if (navigator?.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(text).then(() => {
            if (triggerNotification) triggerNotification("Link Copied", "Shareable review link copied to clipboard.", "success");
          }).catch(() => {
            window.prompt("Copy manually:", text);
          });
          return;
        }

        // Fallback for non-secure contexts (iframes)
        try {
          const textArea = document.createElement("textarea");
          textArea.value = text;
          textArea.style.position = "fixed";
          textArea.style.left = "-9999px";
          textArea.style.top = "-9999px";
          textArea.style.zIndex = "9999";
          document.body.appendChild(textArea);
          textArea.focus();
          textArea.select();
          const successful = document.execCommand('copy');
          textArea.remove();
          
          if (successful) {
            if (triggerNotification) triggerNotification("Link Copied", "Shareable review link copied to clipboard.", "success");
          } else {
            window.prompt("Copy manually:", text);
          }
        } catch (err) {
          window.prompt("Copy manually:", text);
        }
      };

      copyToClipboard(url);
    } catch (err) {
      console.error(err);
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  const handleAddTimestampNote = () => {
    if (!activeReview) return;
    if (videoRef.current) {
      videoRef.current.pause();
      setIsPlaying(false);
    }
    setShowCommentInput(true);
  };

  const saveTimestampComment = () => {
    if (!activeReview || !timestampComment.trim()) return;

    const newComment: TimestampedComment = {
      timestamp: currentTime,
      comment: timestampComment.trim(),
      author: brandName,
      createdAt: new Date().toISOString()
    };

    const updatedItem: ReviewItem = {
      ...activeReview,
      timestampedComments: [...(activeReview.timestampedComments || []), newComment],
      comments: [
        ...activeReview.comments,
        `Brand Partner: Added timestamp note at ${formatTime(currentTime)} — "${timestampComment.trim()}"`
      ]
    };

    if (onSaveReview) onSaveReview(updatedItem);
    setTimestampComment('');
    setShowCommentInput(false);
    if (videoRef.current) {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="bg-[#050b18] text-slate-100 font-sans selection:bg-[#D4AF37]/30 pb-20">
      {/* GLOBAL AUTO-APPROVAL TIMER BAR (STRETCHES AT TOP) */}
      {activeReview && activeReview.brandReviewStatus === 'Active' && (
        <div className="sticky top-0 z-[70] w-full bg-black/60 backdrop-blur-xl border-b border-[#D4AF37]/20 px-6 py-2 overflow-hidden">
          <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="flex flex-col">
                <span className="text-[9px] uppercase tracking-[0.2em] text-[#D4AF37] font-bold">Auto-Approval Countdown</span>
                <span className="text-xs text-slate-400">Review window expires in:</span>
              </div>
              <div className="flex items-center gap-2 bg-[#D4AF37]/10 px-3 py-1 rounded-lg border border-[#D4AF37]/30">
                <Clock className={`w-4 h-4 ${getRemainingSeconds(activeReview) <= 12 * 3600 ? 'text-rose-500 animate-pulse' : 'text-[#D4AF37]'}`} />
                <span className={`text-lg font-black font-mono tracking-tight ${getRemainingSeconds(activeReview) <= 12 * 3600 ? 'text-rose-500' : 'text-[#D4AF37]'}`}>
                  {formatTime(getRemainingSeconds(activeReview))}
                </span>
              </div>
            </div>
            
            <div className="flex-1 max-w-md w-full h-1.5 bg-slate-800 rounded-full overflow-hidden relative">
               <div 
                 className={`h-full transition-all duration-1000 ${getRemainingSeconds(activeReview) <= 12 * 3600 ? 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.5)]' : 'bg-gradient-to-r from-[#D4AF37] to-amber-200 shadow-[0_0_10px_rgba(212,175,55,0.3)]'}`}
                 style={{ width: `${Math.max(0, Math.min(100, (getRemainingSeconds(activeReview) / (48 * 3600)) * 100))}%` }}
               />
            </div>
            
            <div className="hidden lg:flex items-center gap-2 text-[10px] text-slate-500 font-mono">
              <Shield className="w-3 h-3" />
              SECURE REVIEW ROOM ACTIVE
            </div>
          </div>
        </div>
      )}

      {/* HEADER SECTION */}
      <header className="border-b border-white/5 bg-[#0b1320]/40 backdrop-blur-md px-6 py-6">
        <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-gradient-to-br from-[#D4AF37] to-[#B8860B] rounded-xl flex items-center justify-center shadow-lg shadow-[#D4AF37]/10">
              <Eye className="w-6 h-6 text-black" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                Brand Quality Control <span className="text-[#D4AF37] opacity-50">/</span> <span className="text-slate-400 font-mono text-sm">{brandName}</span>
              </h1>
              <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-medium">Bloom Studio Executive Portal</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-4 bg-black/40 border border-white/5 px-4 py-2 rounded-2xl">
              <div className="flex flex-col items-end">
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">SLA Compliance Window</span>
                <span className="text-xs font-mono font-bold text-emerald-400">48-Hour Feedback Policy Active</span>
              </div>
              <div className="w-px h-8 bg-white/10" />
              <div className="flex items-center gap-2 text-emerald-500">
                <CheckCircle className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Secure Access</span>
              </div>
            </div>

            {onExit && (
              <button
                type="button"
                onClick={onExit}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/10 hover:border-rose-500/30 text-xs font-mono font-semibold transition-all cursor-pointer"
                title="Exit Review Room and Lock Session"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Exit Review</span>
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto p-6 lg:p-8">
        {brandApprovedReviews.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-6">
            <div className="relative">
              <div className="absolute inset-0 bg-emerald-500/20 blur-3xl rounded-full animate-pulse" />
              <CheckCircle className="w-20 h-20 text-emerald-500/40 relative z-10" />
            </div>
            <div className="text-center max-w-lg space-y-3">
              <h2 className="text-2xl font-serif font-bold text-white">Review Queue Cleared</h2>
              <p className="text-slate-400 leading-relaxed text-sm">
                There are currently no deliverables awaiting your feedback. Assets appear here automatically after passing internal agency quality checks.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* SIDEBAR QUEUE */}
            <div className="lg:col-span-3 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-[#D4AF37] uppercase tracking-[0.2em]">Asset Queue</h3>
                <span className="bg-white/5 border border-white/10 px-2 py-0.5 rounded text-[10px] font-mono text-slate-400">{brandApprovedReviews.length} ITEMS</span>
              </div>

              <div className="space-y-4 max-h-[calc(100vh-250px)] overflow-y-auto pr-2 custom-scrollbar">
                {brandApprovedReviews.map(r => {
                  const isSelected = r.id === selectedReviewId;
                  const remainingSecs = getRemainingSeconds(r);
                  const isUrgent = remainingSecs <= 12 * 3600;
                  
                  return (
                    <motion.button
                      key={r.id}
                      whileHover={{ x: 4 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSelectedReviewId(r.id)}
                      className={`w-full group relative flex items-start gap-4 p-4 rounded-2xl border transition-all duration-300 text-left ${
                        isSelected 
                        ? 'bg-[#152238] border-[#D4AF37]/50 shadow-2xl shadow-[#D4AF37]/5' 
                        : 'bg-[#0b1320] border-white/5 hover:border-white/20'
                      }`}
                    >
                      <div className="relative shrink-0">
                        <div 
                          className="w-14 h-14 rounded-xl bg-cover bg-center border border-white/10 group-hover:scale-105 transition-transform duration-500" 
                          style={{ backgroundImage: `url(${r.mediaUrl})` }} 
                        />
                        {isSelected && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#D4AF37] rounded-full flex items-center justify-center shadow-lg border-2 border-[#152238]">
                            <ChevronRight className="w-3 h-3 text-black" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0 space-y-1.5">
                        <div className="flex justify-between items-start">
                          <span className="font-bold text-sm text-white truncate group-hover:text-[#D4AF37] transition-colors">{r.creator}</span>
                          <span className="text-[9px] font-mono text-slate-500 uppercase">{r.platform}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Clock className={`w-3 h-3 ${isUrgent ? 'text-rose-500' : 'text-slate-500'}`} />
                          <span className={`text-[10px] font-mono font-medium ${isUrgent ? 'text-rose-400' : 'text-slate-400'}`}>
                            {formatTime(remainingSecs)}
                          </span>
                        </div>

                        {/* Progress Bar for the 48h limit */}
                        <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden mt-1">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${(remainingSecs / (48 * 3600)) * 100}%` }}
                            className={`h-full ${isUrgent ? 'bg-rose-500' : 'bg-[#D4AF37]'}`}
                          />
                        </div>

                        {/* Quick Approve Action */}
                        {r.status !== 'Posted' && (
                          <div className="flex justify-end pt-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleApproveAndLock(r);
                              }}
                              className="text-[9px] font-bold text-emerald-500 hover:text-emerald-400 uppercase tracking-widest flex items-center gap-1 bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20 transition-colors"
                            >
                              <CheckCircle className="w-3 h-3" /> Approve Now
                            </button>
                          </div>
                        )}
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* MAIN PREVIEW AREA */}
            <div className="lg:col-span-9 space-y-6">
              <AnimatePresence mode="wait">
                {activeReview ? (
                  <motion.div
                    key={activeReview.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-6"
                  >
                    {/* SLA WARNING BANNER */}
                    <div className={`p-4 rounded-2xl border flex items-center justify-between gap-4 ${
                      getRemainingSeconds(activeReview) <= 12 * 3600 
                      ? 'bg-rose-500/10 border-rose-500/30' 
                      : 'bg-[#D4AF37]/5 border-[#D4AF37]/20'
                    }`}>
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${getRemainingSeconds(activeReview) <= 12 * 3600 ? 'bg-rose-500/20' : 'bg-[#D4AF37]/20'}`}>
                          <Clock className={`w-5 h-5 ${getRemainingSeconds(activeReview) <= 12 * 3600 ? 'text-rose-500' : 'text-[#D4AF37]'}`} />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-white">Review Deadline In Effect</h4>
                          <p className="text-[11px] text-slate-400">Feedback required within <span className="text-white font-bold">2 business days</span> of asset access to prevent automated approval sequence.</p>
                        </div>
                      </div>
                      <div className="text-right flex flex-col items-end">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Time Remaining</span>
                        <span className={`text-xl font-black font-mono tracking-tighter ${getRemainingSeconds(activeReview) <= 12 * 3600 ? 'text-rose-500' : 'text-[#D4AF37]'}`}>
                          {formatTime(getRemainingSeconds(activeReview))}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
                      {/* CINEMA STAGE */}
                      <div className="xl:col-span-7 space-y-6">
                        <div className="relative rounded-[2.5rem] bg-black border-4 border-white/5 overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,0,0,0.8)] group ring-1 ring-white/10">
                          {activeReview.contentType?.toLowerCase().includes('video') || activeReview.contentType?.toLowerCase().includes('reel') ? (
                            <div className="relative">
                              <video
                                ref={videoRef}
                                src={activeReview.mediaUrl}
                                className="w-full aspect-[9/16] object-cover max-h-[700px] cursor-pointer"
                                onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                                onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
                                onClick={togglePlay}
                                playsInline
                              />
                              
                              {/* PREMIUM CONTROLS */}
                              <div className="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-black/90 via-black/40 to-transparent pt-20 translate-y-2 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500">
                                <div className="space-y-4">
                                  {/* Progress bar */}
                                  <div className="relative h-1.5 w-full bg-white/20 rounded-full cursor-pointer overflow-hidden group/bar">
                                    <div 
                                      className="absolute inset-y-0 left-0 bg-[#D4AF37] shadow-[0_0_12px_#D4AF37]" 
                                      style={{ width: `${(currentTime / duration) * 100}%` }}
                                    />
                                  </div>

                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-4">
                                      <button onClick={togglePlay} className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center hover:bg-[#D4AF37] hover:text-black transition-all">
                                        {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-1" />}
                                      </button>
                                      <span className="text-[11px] font-mono font-bold text-white tabular-nums">
                                        {Math.floor(currentTime / 60)}:{(currentTime % 60).toFixed(0).padStart(2, '0')} / {Math.floor(duration / 60)}:{(duration % 60).toFixed(0).padStart(2, '0')}
                                      </span>
                                    </div>

                                    <button
                                      onClick={handleAddTimestampNote}
                                      className="bg-white text-black px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 hover:bg-[#D4AF37] transition-all active:scale-95"
                                    >
                                      <Plus className="w-3.5 h-3.5" /> Drop Marker
                                    </button>
                                  </div>
                                </div>
                              </div>

                              {/* PAUSE OVERLAY */}
                              {!isPlaying && (
                                <div className="absolute inset-0 flex items-center justify-center pointer-events-none bg-black/20 backdrop-blur-[2px]">
                                  <div className="w-20 h-20 rounded-full bg-white/10 backdrop-blur-lg flex items-center justify-center border border-white/20">
                                    <Play className="w-8 h-8 text-white ml-2 opacity-50" />
                                  </div>
                                </div>
                              )}
                            </div>
                          ) : (
                            <img src={activeReview.mediaUrl} alt="Asset preview" className="w-full h-auto max-h-[700px] object-contain" />
                          )}
                        </div>

                        {/* CAPTION BOX */}
                        <div className="bg-[#0b1320] border border-white/5 rounded-3xl p-6 space-y-4">
                          <div className="flex items-center justify-between">
                            <h5 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Caption Draft & Metadata</h5>
                            <button className="text-[10px] font-bold text-[#D4AF37] hover:underline">Copy Caption</button>
                          </div>
                          <div className="p-5 bg-black/40 rounded-2xl text-xs font-mono text-slate-300 leading-relaxed border border-white/5 shadow-inner">
                            {activeReview.captionDraft}
                          </div>
                        </div>
                      </div>

                      {/* FEEDBACK COLUMN */}
                      <div className="xl:col-span-5 space-y-6">
                        {/* ASSET INFO CARD */}
                        <div className="bg-gradient-to-br from-[#152238] to-[#0b1320] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-6">
                          <div className="flex justify-between items-start">
                            <div>
                              <h2 className="text-xl font-serif font-bold text-white">{activeReview.creator}</h2>
                              <p className="text-[10px] font-mono text-slate-500 uppercase mt-1">{activeReview.contentType} &middot; {activeReview.brand}</p>
                            </div>
                            <button 
                              onClick={() => handleCopyReviewLink(activeReview)}
                              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors group"
                            >
                              <Link2 className="w-4 h-4 text-slate-400 group-hover:text-[#D4AF37]" />
                            </button>
                          </div>

                          {/* INTERACTIVE MARKERS */}
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                                <MessageSquare className="w-3.5 h-3.5 text-[#D4AF37]" /> Quality Audit Notes
                              </h5>
                              <span className="text-[9px] font-mono bg-[#D4AF37]/10 text-[#D4AF37] px-2 py-0.5 rounded border border-[#D4AF37]/20">
                                {activeReview.timestampedComments?.length || 0} MARKERS
                              </span>
                            </div>

                            <div className="space-y-3 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar min-h-[100px]">
                              {(!activeReview.timestampedComments || activeReview.timestampedComments.length === 0) ? (
                                <div className="py-12 px-6 text-center border-2 border-dashed border-white/5 rounded-2xl">
                                  <Info className="w-6 h-6 text-slate-600 mx-auto mb-2" />
                                  <p className="text-[11px] text-slate-500 italic leading-relaxed">No revisions marked. Pause video and use "Drop Marker" to specify feedback.</p>
                                </div>
                              ) : (
                                activeReview.timestampedComments.map((note, i) => (
                                  <motion.div 
                                    initial={{ opacity: 0, x: 10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    key={i} 
                                    className="bg-black/30 border border-white/5 p-4 rounded-2xl space-y-2 hover:border-[#D4AF37]/30 transition-colors"
                                  >
                                    <div className="flex justify-between items-center">
                                      <span className="text-[10px] font-mono font-bold text-[#D4AF37]">TC: {Math.floor(note.timestamp / 60)}:{(note.timestamp % 60).toFixed(0).padStart(2, '0')}</span>
                                      <span className="text-[8px] text-slate-600 font-mono">{new Date(note.createdAt).toLocaleDateString()}</span>
                                    </div>
                                    <p className="text-xs text-slate-300 leading-relaxed font-serif">"{note.comment}"</p>
                                  </motion.div>
                                ))
                              )}
                            </div>
                          </div>

                          {/* ACTION BUTTONS */}
                          {activeReview.status !== 'Posted' ? (
                            <div className="grid grid-cols-1 gap-3 pt-4 border-t border-white/5">
                              <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => handleApproveAndLock(activeReview)}
                                className="w-full bg-[#D4AF37] hover:bg-[#B8860B] text-black py-4 rounded-2xl text-xs font-bold uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 shadow-xl shadow-[#D4AF37]/10"
                              >
                                <CheckCircle className="w-5 h-5" /> Approve Asset
                              </motion.button>
                              <button
                                onClick={() => handleRequestRevision(activeReview)}
                                className="w-full bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 py-3.5 rounded-2xl text-xs font-bold uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2"
                              >
                                <RefreshCw className="w-4 h-4 text-rose-500" /> Dispatch Changes
                              </button>
                            </div>
                          ) : (
                            <div className="bg-emerald-500/10 border border-emerald-500/20 p-6 rounded-3xl flex flex-col items-center justify-center gap-4 text-center">
                              <div className="w-12 h-12 bg-emerald-500/20 rounded-full flex items-center justify-center">
                                <Lock className="w-6 h-6 text-emerald-500" />
                              </div>
                              <div className="space-y-1">
                                <span className="text-sm font-bold text-white block uppercase tracking-widest">Release Locked</span>
                                <p className="text-[10px] text-emerald-500/60 font-mono uppercase">Asset cleared for publication</p>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* AUDIT CARD */}
                        <div className="bg-[#0b1320] border border-white/5 rounded-3xl p-6 space-y-4">
                          <h5 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                            <Info className="w-4 h-4" /> Version History
                          </h5>
                          <div className="space-y-2 max-h-[150px] overflow-y-auto pr-2 custom-scrollbar">
                            {activeReview.comments.map((comment, i) => (
                              <div key={i} className="p-3 rounded-xl bg-black/40 border border-white/5 text-[10px] font-mono text-slate-500 leading-relaxed">
                                {comment}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ) : null}
              </AnimatePresence>
            </div>
          </div>
        )}
      </main>

      {/* MODAL OVERLAY FOR TIMESTAMP COMMENT */}
      <AnimatePresence>
        {showCommentInput && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 backdrop-blur-xl bg-black/60">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#0b1320] border border-[#D4AF37]/50 w-full max-w-xl rounded-[2.5rem] shadow-[0_64px_128px_-32px_rgba(0,0,0,1)] overflow-hidden"
            >
              <div className="p-8 space-y-6">
                <div className="flex justify-between items-center">
                  <div className="space-y-1">
                    <h3 className="text-xl font-serif font-bold text-white">Add Revision Note</h3>
                    <p className="text-[10px] text-[#D4AF37] font-mono uppercase tracking-[0.2em]">Marker at {formatTime(currentTime)}</p>
                  </div>
                  <button onClick={() => setShowCommentInput(false)} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-slate-400 hover:text-white transition-colors">&times;</button>
                </div>

                <textarea
                  value={timestampComment}
                  onChange={(e) => setTimestampComment(e.target.value)}
                  placeholder="Describe the adjustment needed at this specific moment..."
                  className="w-full bg-black/40 border border-white/10 rounded-2xl p-5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-[#D4AF37] min-h-[160px] shadow-inner transition-colors"
                  autoFocus
                />

                <div className="flex gap-4">
                  <button 
                    onClick={() => setShowCommentInput(false)} 
                    className="flex-1 py-4 text-xs font-bold text-slate-400 hover:text-white uppercase tracking-[0.2em] transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={saveTimestampComment}
                    className="flex-[2] py-4 bg-[#D4AF37] text-black rounded-2xl text-xs font-bold uppercase tracking-[0.2em] hover:bg-[#B8860B] transition-all shadow-xl shadow-[#D4AF37]/10"
                  >
                    Save Marker
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
