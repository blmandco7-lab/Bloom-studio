import React, { useState } from 'react';
import { FileText, Download, CheckCircle2, Sparkles, Calendar, Layers, ShieldCheck } from 'lucide-react';
import { exportClientWrapUpPDF, ClientWrapUpData } from '../utils/pdfExportUtils';

export interface ClientCampaignReportItem {
  id: string;
  campaignName: string;
  brandName: string;
  date: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  totalViews: string;
  totalReach: string;
  engagementRate: string;
  ugcAssetYield: number;
}

interface ClientReportCenterProps {
  reports?: ClientCampaignReportItem[];
  currentRole?: string;
  userRole?: string;
}

/**
 * ClientReportCenter:
 * Dedicated portal block embedded in the Client Brand Login view.
 * Provides client brand partners with an isolated list of finalized campaign wrap-up summaries.
 * 
 * ZERO INTERNAL FINANCIAL VISIBILITY:
 * Only compiles brand-facing performance metrics and exports white-paper PDFs.
 */
export default function ClientReportCenter({
  reports = [
    {
      id: "rep_1",
      campaignName: "Organic Fur Shampoo & Pet Balm Launch",
      brandName: "BarkHydrate Eco",
      date: "August 2026",
      niche: "Pets",
      totalViews: "520,000 Views",
      totalReach: "980,000+",
      engagementRate: "8.1%",
      ugcAssetYield: 8
    },
    {
      id: "rep_2",
      campaignName: "Summer Glow Botanical Serum Whitelisting",
      brandName: "GlowLab Beauty",
      date: "July 2026",
      niche: "Beauty",
      totalViews: "842,500 Views",
      totalReach: "1,450,000+",
      engagementRate: "7.8%",
      ugcAssetYield: 12
    },
    {
      id: "rep_3",
      campaignName: "Velvet Aromatherapy Diffuser Influencer Seeding",
      brandName: "Velvet Home Botanics",
      date: "June 2026",
      niche: "Lifestyle",
      totalViews: "310,000 Views",
      totalReach: "620,000+",
      engagementRate: "6.9%",
      ugcAssetYield: 6
    }
  ],
  currentRole = 'director',
  userRole = 'director'
}: ClientReportCenterProps) {
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const effectiveRole = (currentRole || userRole || '').toLowerCase();
  const isDirectorOrBrand = effectiveRole === 'director' || effectiveRole === 'owner' || effectiveRole === 'agency' || effectiveRole === 'brand';

  const handleDownload = async (item: ClientCampaignReportItem) => {
    setDownloadingId(item.id);

    const pdfData: ClientWrapUpData = {
      brandName: item.brandName,
      campaignTitle: item.campaignName,
      date: item.date,
      niche: item.niche,
      totalReach: item.totalReach,
      totalViews: item.totalViews,
      engagementRate: item.engagementRate,
      ugcAssetYield: item.ugcAssetYield,
      ftcComplianceScore: "100% Compliant Caption Baseline Tracker",
      copyrightStatus: "Copyright & Audio Sync Security Passed",
      creatorDeliverables: [
        {
          creatorHandle: "@paws_and_palette",
          niche: `${item.niche} Creator`,
          deliverableType: "Hero 60s 4K Video Submission",
          views: "295,000",
          engagement: item.engagementRate,
          ftcTag: "Verified #ad"
        },
        {
          creatorHandle: "@glow_with_mia",
          niche: `${item.niche} Creator`,
          deliverableType: "Aesthetic Reel & Link Story",
          views: "225,000",
          engagement: "7.4%",
          ftcTag: "Verified #ad"
        }
      ]
    };

    try {
      await exportClientWrapUpPDF(pdfData);
    } catch (err) {
      console.error('Failed to download report PDF:', err);
    } finally {
      setTimeout(() => setDownloadingId(null), 1000);
    }
  };

  return (
    <div className="bg-agency-navyLight border border-agency-gold/20 rounded-3xl p-6 shadow-2xl text-agency-textLight space-y-6 max-w-4xl mx-auto">
      {/* Portal Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Client Portal Hub
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Formal Brand Reporting
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white mt-1.5">
            Campaign Wrap-Up Summaries
          </h2>
          <p className="text-xs text-slate-400">
            Download certified campaign performance white-papers and compliance certificates.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-300 bg-agency-navy px-3.5 py-1.5 rounded-xl border border-white/10">
          <ShieldCheck className="w-4 h-4 text-agency-gold" />
          <span>Audit-Verified Records</span>
        </div>
      </div>

      {/* Campaign List */}
      <div className="space-y-3">
        {reports.map((rep) => {
          const isDownloading = downloadingId === rep.id;

          return (
            <div
              key={rep.id}
              className="bg-agency-navy border border-white/10 hover:border-agency-gold/40 transition-all rounded-2xl p-4.5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md"
            >
              {/* Campaign Info */}
              <div className="flex items-start gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-agency-navyLight border border-agency-gold/30 flex items-center justify-center text-agency-gold">
                  <FileText className="w-5 h-5" />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white font-sans">{rep.campaignName}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-agency-navyLight border border-white/10 text-slate-300">
                      {rep.niche}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Client: <strong className="text-agency-gold">{rep.brandName}</strong> &bull; Date: {rep.date}
                  </p>
                  <div className="flex items-center gap-3 text-[11px] font-mono text-slate-300 pt-0.5">
                    <span>Views: <strong className="text-white">{rep.totalViews}</strong></span>
                    <span>&bull;</span>
                    <span>Engagement: <strong className="text-emerald-400">{rep.engagementRate}</strong></span>
                    <span>&bull;</span>
                    <span>Yield: <strong className="text-white">{rep.ugcAssetYield} UGC Videos</strong></span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div>
                {isDirectorOrBrand ? (
                  <button
                    type="button"
                    onClick={() => handleDownload(rep)}
                    disabled={isDownloading}
                    className="w-full md:w-auto inline-flex items-center justify-center gap-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-4.5 py-2.5 rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Download className="w-4 h-4" />
                    <span>{isDownloading ? 'Generating PDF...' : 'Download Formal Wrap-Up Report (PDF)'}</span>
                  </button>
                ) : (
                  <span className="text-xs font-mono text-agency-gold bg-agency-navy border border-agency-gold/30 px-3.5 py-2 rounded-xl block text-center">
                    🔒 Read-Only Overview (Director Export Restricted)
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
