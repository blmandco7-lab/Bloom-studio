import React, { useState } from 'react';
import { Sparkles, TrendingUp, Target, UserCheck, CheckCircle2, ChevronRight, FileText } from 'lucide-react';
import { getAuthHeaders } from '../lib/firebase';

interface GrowthPlanningGeneratorProps {
  currentRole: string;
  creators: any[];
}

export default function GrowthPlanningGenerator({ currentRole, creators }: GrowthPlanningGeneratorProps) {
  const isDirector = (currentRole || '').toLowerCase() === 'director';
  
  const [selectedCreator, setSelectedCreator] = useState<string>('');
  const [focusArea, setFocusArea] = useState<string>('Audience Expansion');
  const [timeline, setTimeline] = useState<string>('90 Days');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<string>('');
  
  const handleGeneratePlan = async () => {
    if (!selectedCreator) return;
    
    setIsGenerating(true);
    setGeneratedPlan('');
    
    try {
      const authHeaders = await getAuthHeaders();
      const res = await fetch('/api/generate-growth-plan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        body: JSON.stringify({
          selectedCreator,
          focusArea,
          timeline
        })
      });

      const data = await res.json();
      
      if (data.plan) {
        setGeneratedPlan(data.plan);
      } else {
        setGeneratedPlan('An error occurred while generating the growth plan. Please try again.');
      }
    } catch (err) {
      console.error(err);
      setGeneratedPlan('An error occurred while generating the growth plan. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#C9A46A]/20 rounded-2xl p-8 relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-radial-gradient(circle,rgba(201,164,106,0.05)_0%,transparent_70%) pointer-events-none"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider bg-[#C9A46A]/10 px-2.5 py-1 rounded-md border border-[#C9A46A]/20">
                AI Powered Strategy
              </span>
            </div>
            <h1 className="font-serif font-bold text-3xl text-white">Creator Growth Planning</h1>
            <p className="text-sm text-[#7C8AA8] mt-2 max-w-2xl">
              Generate actionable, data-driven growth strategies for your roster.
            </p>
          </div>
        </div>
      </div>

      {isDirector && (
        <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-2xl p-6">
          <h3 className="font-serif font-bold text-lg text-white mb-2">Director's Revenue Projections</h3>
          <p className="text-xs text-slate-400">
            Confidential quarterly projections for the agency's net commission block.
          </p>
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
              <span className="text-[10px] text-[#7C8AA8] font-mono uppercase">Q3 Projection</span>
              <div className="text-2xl font-bold text-white mt-1">$450K</div>
            </div>
            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
              <span className="text-[10px] text-[#7C8AA8] font-mono uppercase">YoY Growth</span>
              <div className="text-2xl font-bold text-emerald-400 mt-1">+24%</div>
            </div>
            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl">
              <span className="text-[10px] text-[#7C8AA8] font-mono uppercase">Active Retainers</span>
              <div className="text-2xl font-bold text-white mt-1">12</div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Generator Controls */}
        <div className="lg:col-span-1 bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5">
          <h3 className="font-bold text-white flex items-center gap-2 mb-4">
            <Target className="w-4 h-4 text-[#C9A46A]" /> Strategy Configurator
          </h3>
          
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Target Creator</label>
            <select
              value={selectedCreator}
              onChange={(e) => setSelectedCreator(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-[#C9A46A] outline-none"
            >
              <option value="">Select a creator...</option>
              {creators.map(c => (
                <option key={c.handle} value={c.handle}>{c.name} ({c.handle})</option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Primary Focus Area</label>
            <select
              value={focusArea}
              onChange={(e) => setFocusArea(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-[#C9A46A] outline-none"
            >
              <option value="Audience Expansion">Audience Expansion</option>
              <option value="Monetization & Brand Deals">Monetization & Brand Deals</option>
              <option value="Content Repurposing">Content Repurposing</option>
              <option value="Community Engagement">Community Engagement</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Execution Timeline</label>
            <div className="grid grid-cols-2 gap-2">
              {['30 Days', '60 Days', '90 Days', '6 Months'].map(t => (
                <button
                  key={t}
                  onClick={() => setTimeline(t)}
                  className={`text-xs py-2 rounded-xl transition-all border ${
                    timeline === t 
                      ? 'bg-[#C9A46A]/20 border-[#C9A46A]/50 text-[#C9A46A] font-bold'
                      : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleGeneratePlan}
            disabled={!selectedCreator || isGenerating}
            className="w-full mt-4 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-sm px-4 py-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 animate-spin" /> Synthesizing...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" /> Generate Plan
              </span>
            )}
          </button>
        </div>

        {/* Generated Output */}
        <div className="lg:col-span-2 bg-[#0D1830] border border-white/5 rounded-2xl p-6 min-h-[400px]">
          {generatedPlan ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/5 pb-4">
                <h3 className="font-bold text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#C9A46A]" /> Action Plan: {selectedCreator}
                </h3>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-1 rounded border border-emerald-500/20 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Ready
                </span>
              </div>
              <div className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap font-mono">
                {generatedPlan}
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-[#C9A46A]" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">No active plan generated</p>
                <p className="text-xs text-slate-400 mt-1">Select a creator and configure the strategy parameters to begin.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
