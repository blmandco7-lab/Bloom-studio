import React, { useState, useEffect } from 'react';
import { 
  Target, Sparkles, Send, Users, CheckCircle2, Clock, 
  DollarSign, FileText, ArrowRight, UserPlus, Filter, 
  Search, Shield, AlertCircle, Award, Check, X, Briefcase,
  HelpCircle, MessageSquare, Plus, ExternalLink, Trash2, Sliders
} from 'lucide-react';
import { Creator, Mission } from '../types';
import { db } from '../lib/firebase';
import { collection, query, onSnapshot, setDoc, doc, deleteDoc, increment } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';

export interface MissionSuggestion {
  id: string;
  missionId: string;
  missionName: string;
  brand: string;
  creatorHandle: string;
  creatorName: string;
  suggestedBy: string;
  suggestedAt: string;
  managerNote: string;
  payout: number;
  status: 'Suggested' | 'Viewed by Creator' | 'Applied' | 'Cast & Contracted';
}

export interface CreatorMissionApplication {
  id: string;
  missionId: string;
  missionName: string;
  brand: string;
  creatorHandle: string;
  creatorName: string;
  pitch: string;
  appliedAt: string;
  status: 'Pending Review' | 'Shortlisted' | 'Approved' | 'Declined';
  portfolioSampleUrl?: string;
  proposedRate?: number;
  creatorId?: string;
  subagency?: string;
  tenantId?: string;
}

interface OpenMissionsWorkspaceProps {
  missions?: Mission[];
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  onNavigateToCampaignWorkspace?: () => void;
}

const DEFAULT_OPEN_MISSIONS: Array<{
  id: string;
  title: string;
  brand: string;
  category: string;
  bounty: number;
  spotsTotal: number;
  spotsFilled: number;
  deadline: string;
  requirements: string;
  deliverables: string;
  briefSummary: string;
  isOpenToAll: boolean;
}> = [
  {
    id: 'open-miss-01',
    title: 'Summer Glow Botanical Serum Sprint',
    brand: 'GlowLab Beauty',
    category: 'Beauty & Skincare',
    bounty: 3500,
    spotsTotal: 5,
    spotsFilled: 2,
    deadline: 'In 5 Days',
    requirements: '10k+ followers, natural aesthetic, authentic first-impression reel with FTC #ad tag',
    deliverables: '1x 60s TikTok Video + Spark Ads Authorization',
    briefSummary: 'Open casting call for beauty creators to review the new botanical serum in morning daylight with texture close-ups.',
    isOpenToAll: true,
  },
  {
    id: 'open-miss-02',
    title: 'Hydration Powder Park Walk Challenge',
    brand: 'BarkHydrate',
    category: 'Pets & Wellness',
    bounty: 2800,
    spotsTotal: 4,
    spotsFilled: 1,
    deadline: 'In 7 Days',
    requirements: 'Pet owners with active dogs, clean park or outdoor lighting, playful interaction',
    deliverables: '2x 45s TikTok UGC Videos + raw B-roll cuts',
    briefSummary: 'Any creator with a dog can apply! Show quick electrolyte powder mixing and energetic dog drinking.',
    isOpenToAll: true,
  },
  {
    id: 'open-miss-03',
    title: '7-Day High-Protein Morning Routine',
    brand: 'NourishFuel',
    category: 'Fitness & Health',
    bounty: 3200,
    spotsTotal: 6,
    spotsFilled: 3,
    deadline: 'In 9 Days',
    requirements: 'Fitness, gym, or healthy lifestyle creators with high engagement rates',
    deliverables: '1x Dedicated YouTube Short + 1x Instagram Reel',
    briefSummary: 'Open bounty for lifestyle and fitness talent sharing their 7-day breakfast habit with high-protein plant mix.',
    isOpenToAll: true,
  },
  {
    id: 'open-miss-04',
    title: 'Noise-Canceling Tech Commuter Test',
    brand: 'AeroAcoustics',
    category: 'Tech & Lifestyle',
    bounty: 4200,
    spotsTotal: 3,
    spotsFilled: 0,
    deadline: 'In 12 Days',
    requirements: 'Urban creators, tech reviewers, or commuters who test sound isolation in subway or café',
    deliverables: '1x 90s Vertical Showcase + 30-Day Paid Whitelisting',
    briefSummary: 'Test the active noise-canceling feature in loud urban environments. Open to all creators across tech & lifestyle.',
    isOpenToAll: true,
  },
];

export default function OpenMissionsWorkspace({
  missions = [],
  creators = [],
  currentUser,
  currentRole = 'agentmgr',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onAddActivityLog,
  triggerNotification,
  onNavigateToCampaignWorkspace,
}: OpenMissionsWorkspaceProps) {
  const normRole = (currentRole || '').toLowerCase();
  const isCreator = normRole === 'creator';
  const isAgentMgr = normRole === 'agentmgr' || normRole.includes('manager');
  const isDirector = normRole === 'director' || normRole === 'owner';

  const [activeTab, setActiveTab] = useState<'open-missions' | 'suggestions-history' | 'applications'>('open-missions');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const [liveOpenMissions, setLiveOpenMissions] = useState(DEFAULT_OPEN_MISSIONS);

  useEffect(() => {
    // Listen for real-time open-missions collection
    const q = query(collection(db, 'open-missions'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const remoteMissions = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
        setLiveOpenMissions(prev => {
          const remoteIds = new Set(remoteMissions.map((rm: any) => rm.id));
          const localOnly = prev.filter(lm => !remoteIds.has(lm.id));
          return [...remoteMissions, ...localOnly];
        });
      }
    }, (err) => {
      console.warn("Failed to listen to open-missions:", err.message);
    });
    return () => unsubscribe();
  }, []);

  // Director Log New Mission Modal State
  const [logMissionModalOpen, setLogMissionModalOpen] = useState(false);
  const [newMissionTitle, setNewMissionTitle] = useState('');
  const [newMissionBrand, setNewMissionBrand] = useState('');
  const [newMissionCategory, setNewMissionCategory] = useState('Beauty & Skincare');
  const [newMissionBounty, setNewMissionBounty] = useState<number>(3500);
  const [newMissionSpotsTotal, setNewMissionSpotsTotal] = useState<number>(5);
  const [newMissionDeadline, setNewMissionDeadline] = useState('In 7 Days');
  const [newMissionDeliverables, setNewMissionDeliverables] = useState('1x 60s TikTok Video + Spark Ads Authorization');
  const [newMissionRequirements, setNewMissionRequirements] = useState('10k+ followers, natural aesthetic, authentic first-impression reel with FTC #ad tag');
  const [newMissionBriefSummary, setNewMissionBriefSummary] = useState('Open casting call for creators to review product in morning daylight with texture close-ups.');

  const handleLoadSampleMission = () => {
    setNewMissionTitle('Luxe Botanical Glow Serum Campaign');
    setNewMissionBrand('Aura Botanicals');
    setNewMissionCategory('Beauty & Skincare');
    setNewMissionBounty(4200);
    setNewMissionSpotsTotal(6);
    setNewMissionDeadline('In 8 Days');
    setNewMissionDeliverables('1x 60s Dedicated TikTok Reel + 2x High-Res IG Photos');
    setNewMissionRequirements('15k+ followers, clean skincare aesthetic, FTC #ad disclosure required');
    setNewMissionBriefSummary('Open casting call for beauty creators to film morning skincare application with natural daylight lighting and texture macro shots.');
  };

  const handleLogNewMission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMissionTitle.trim() || !newMissionBrand.trim()) return;

    const missionId = `open-miss-${Date.now()}`;
    const newMission = {
      id: missionId,
      title: newMissionTitle.trim(),
      brand: newMissionBrand.trim(),
      category: newMissionCategory,
      bounty: Number(newMissionBounty) || 1000,
      spotsTotal: Number(newMissionSpotsTotal) || 3,
      spotsFilled: 0,
      deadline: newMissionDeadline.trim() || 'In 7 Days',
      requirements: newMissionRequirements.trim() || 'Standard roster requirements & FTC disclosure',
      deliverables: newMissionDeliverables.trim() || '1x Short vertical video',
      briefSummary: newMissionBriefSummary.trim() || 'Agency open mission casting call.',
      isOpenToAll: true,
      createdAt: new Date().toISOString(),
      loggedBy: currentUser?.name || 'Director',
    };

    // Update local state immediately
    setLiveOpenMissions(prev => [newMission, ...prev]);

    // Save to Firestore open-missions
    try {
      await setDoc(doc(db, 'open-missions', missionId), newMission);
    } catch (err: any) {
      console.warn('[OpenMissionsWorkspace] Saved locally (Firestore sync notice):', err?.message);
    }

    if (triggerNotification) {
      triggerNotification(
        'Mission Logged & Broadcasted',
        `Successfully logged open mission "${newMission.title}" ($${newMission.bounty.toLocaleString()} USD) for ${newMission.brand}.`,
        'success'
      );
    }

    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'Director',
        currentRole || 'director',
        `Logged and broadcasted new open casting mission "${newMission.title}" ($${newMission.bounty} bounty)`
      );
    }

    // Reset and close
    setNewMissionTitle('');
    setNewMissionBrand('');
    setLogMissionModalOpen(false);
    setActiveTab('open-missions');
  };

  const handleDeleteMission = async (missionId: string, title: string) => {
    if (!window.confirm(`Are you sure you want to remove open mission "${title}"?`)) return;

    setLiveOpenMissions(prev => prev.filter(m => m.id !== missionId));

    try {
      await deleteDoc(doc(db, 'open-missions', missionId));
    } catch (err) {
      console.warn('[OpenMissionsWorkspace] Local delete sync:', err);
    }

    if (triggerNotification) {
      triggerNotification('Mission Removed', `Mission "${title}" has been deleted.`, 'info');
    }
  };

  // Suggest Mission Modal State
  const [suggestModalOpen, setSuggestModalOpen] = useState(false);
  const [selectedMissionToSuggest, setSelectedMissionToSuggest] = useState<any>(null);
  const [targetCreatorHandle, setTargetCreatorHandle] = useState<string>('');
  const [suggestionNote, setSuggestionNote] = useState<string>('');

  // Apply to Mission Modal State (for Creators)
  const [applyModalOpen, setApplyModalOpen] = useState(false);
  const [missionToApply, setMissionToApply] = useState<any>(null);
  const [applicationPitch, setApplicationPitch] = useState('');
  const [proposedRate, setProposedRate] = useState<number>(3500);

  // Stored suggestions list
  const [suggestions, setSuggestions] = useState<MissionSuggestion[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_mission_suggestions');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'sug-01',
        missionId: 'open-miss-01',
        missionName: 'Summer Glow Botanical Serum Sprint',
        brand: 'GlowLab Beauty',
        creatorHandle: '@alexjones',
        creatorName: 'Alex Jones',
        suggestedBy: 'Marcus Cole (Agent Manager)',
        suggestedAt: '2 hours ago',
        managerNote: 'Alex, this beauty sprint matches your organic skincare reel style perfectly. Payout is guaranteed at $3,500.',
        payout: 3500,
        status: 'Suggested',
      },
      {
        id: 'sug-02',
        missionId: 'open-miss-02',
        missionName: 'Hydration Powder Park Walk Challenge',
        brand: 'BarkHydrate',
        creatorHandle: '@elenarostova',
        creatorName: 'Elena Rostova',
        suggestedBy: 'Marcus Cole (Agent Manager)',
        suggestedAt: 'Yesterday',
        managerNote: 'Elena, great fit for your outdoor lifestyle content with your Golden Retriever!',
        payout: 2800,
        status: 'Viewed by Creator',
      },
    ];
  });

  // Stored creator applications list
  const [applications, setApplications] = useState<CreatorMissionApplication[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_mission_applications');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'app-01',
        missionId: 'open-miss-01',
        missionName: 'Summer Glow Botanical Serum Sprint',
        brand: 'GlowLab Beauty',
        creatorHandle: '@sophiaglows',
        creatorName: 'Sophia Chen',
        pitch: 'I have 85k beauty followers with 5.2% engagement. I can film in morning natural sun with my Sony A7IV macro lens.',
        appliedAt: '3 hours ago',
        status: 'Pending Review',
        proposedRate: 3500,
      },
      {
        id: 'app-02',
        missionId: 'open-miss-03',
        missionName: '7-Day High-Protein Morning Routine',
        brand: 'NourishFuel',
        creatorHandle: '@marcusfit',
        creatorName: 'Marcus Vance',
        pitch: 'Certified trainer with daily fitness shorts averaging 45k views. Ready to film Day 1 through Day 7 smoothie bowls.',
        appliedAt: '1 day ago',
        status: 'Approved',
        proposedRate: 3200,
      }
    ];
  });

  useEffect(() => {
    try {
      safeStorage.setItem('wl_mission_suggestions', JSON.stringify(suggestions));
    } catch {}
  }, [suggestions]);

  useEffect(() => {
    try {
      safeStorage.setItem('wl_mission_applications', JSON.stringify(applications));
    } catch {}
  }, [applications]);

  // Real-time Firestore sync for creator-mission-applications
  useEffect(() => {
    try {
      const q = query(collection(db, 'creator-mission-applications'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const remoteApps: CreatorMissionApplication[] = [];
          snapshot.forEach((docSnap) => {
            remoteApps.push({ id: docSnap.id, ...docSnap.data() } as CreatorMissionApplication);
          });
          setApplications(prev => {
            const map = new Map<string, CreatorMissionApplication>();
            prev.forEach(a => map.set(a.id, a));
            remoteApps.forEach(a => map.set(a.id, a));
            const merged = Array.from(map.values());
            safeStorage.setItem('wl_mission_applications', JSON.stringify(merged));
            return merged;
          });
        }
      }, (err) => {
        console.warn('[OpenMissionsWorkspace] onSnapshot error:', err);
      });
      return () => unsubscribe();
    } catch (e) {
      console.warn('[OpenMissionsWorkspace] Failed to attach onSnapshot:', e);
    }
  }, []);

  // Open Suggestion Modal handler
  const handleOpenSuggestModal = (mission: any) => {
    setSelectedMissionToSuggest(mission);
    const defaultCreator = creators?.[0]?.handle || '@alexjones';
    setTargetCreatorHandle(defaultCreator);
    setSuggestionNote(`Hey! I noticed this open mission for ${mission.brand} fits your niche and aesthetic nicely. Guaranteed rate is $${mission.bounty.toLocaleString()}. Apply today!`);
    setSuggestModalOpen(true);
  };

  // Submit Mission Suggestion (by Agent Manager)
  const handleSendSuggestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMissionToSuggest || !targetCreatorHandle) return;

    const matchedCreator = creators.find(c => c.handle.toLowerCase() === targetCreatorHandle.toLowerCase());
    const creatorDisplayName = matchedCreator ? matchedCreator.name : targetCreatorHandle;

    const newSuggestion: MissionSuggestion = {
      id: 'sug_' + Date.now(),
      missionId: selectedMissionToSuggest.id,
      missionName: selectedMissionToSuggest.title,
      brand: selectedMissionToSuggest.brand,
      creatorHandle: targetCreatorHandle,
      creatorName: creatorDisplayName,
      suggestedBy: currentUser?.name ? `${currentUser.name} (${isAgentMgr ? 'Agent Manager' : 'Staff'})` : 'Agent Manager Marcus Cole',
      suggestedAt: 'Just now',
      managerNote: suggestionNote.trim(),
      payout: selectedMissionToSuggest.bounty,
      status: 'Suggested',
    };

    setSuggestions(prev => [newSuggestion, ...prev]);
    setSuggestModalOpen(false);

    if (triggerNotification) {
      triggerNotification(
        'Mission Suggested to Creator',
        `Successfully suggested "${selectedMissionToSuggest.title}" to ${creatorDisplayName} (${targetCreatorHandle}) with your personal note!`,
        'success'
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'Agent Manager',
        currentRole,
        `Suggested open mission "${selectedMissionToSuggest.title}" to creator ${targetCreatorHandle}`
      );
    }
  };

  // Creator applies to open mission
  const handleOpenApplyModal = (mission: any) => {
    setMissionToApply(mission);
    setProposedRate(mission.bounty || 3500);
    setApplicationPitch(`Hi ${mission.brand} team! I would love to create high-converting UGC content for this mission. My community is engaged and loves product recommendations.`);
    setApplyModalOpen(true);
  };

  const handleSendApplication = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!missionToApply) return;

    const myHandle = currentUser?.handle || '@creator';
    const myName = currentUser?.name || 'Creator';

    const newApp: CreatorMissionApplication = {
      id: 'app_' + Date.now(),
      missionId: missionToApply.id,
      missionName: missionToApply.title,
      brand: missionToApply.brand,
      creatorHandle: myHandle,
      creatorName: myName,
      pitch: applicationPitch.trim(),
      appliedAt: new Date().toISOString(),
      status: 'Pending Review',
      proposedRate: Number(proposedRate) || missionToApply.bounty,
      creatorId: currentUser?.id || currentUser?.uid || '',
      subagency: currentUser?.subagency || 'pod_main',
      tenantId: currentUser?.tenantId || 'bloom_studio_default'
    };

    try {
      // 1. Direct verified write to both creator-mission-applications and studio-mission-applications
      await Promise.all([
        setDoc(doc(db, 'creator-mission-applications', newApp.id), newApp, { merge: true }),
        setDoc(doc(db, 'studio-mission-applications', newApp.id), newApp, { merge: true })
      ]);

      // 1.5 Increment spotsFilled on the mission
      try {
        const missionRef = doc(db, 'open-missions', missionToApply.id);
        await setDoc(missionRef, { spotsFilled: increment(1) }, { merge: true });
      } catch (incErr) {
        console.warn('Failed to increment spotsFilled on mission:', incErr);
      }

      setApplications(prev => {
        const updated = [newApp, ...prev];
        safeStorage.setItem('wl_mission_applications', JSON.stringify(updated));
        return updated;
      });
      setApplyModalOpen(false);

      if (triggerNotification) {
        triggerNotification(
          'Application Submitted',
          `Your application for "${missionToApply.title}" was submitted to the agency for review!`,
          'success'
        );
      }
    } catch (err: any) {
      console.error('Failed to submit application:', err);
      if (triggerNotification) {
        triggerNotification('Submission Failed', err.message || 'Could not submit application.', 'danger');
      }
    }
  };

  const handleUpdateApplicationStatus = async (appId: string, newStatus: 'Approved' | 'Declined' | 'Shortlisted') => {
    setApplications(prev => {
      const updated = prev.map(a => a.id === appId ? { ...a, status: newStatus } : a);
      safeStorage.setItem('wl_mission_applications', JSON.stringify(updated));
      return updated;
    });
    const target = applications.find(a => a.id === appId);
    
    if (target) {
      const updatedDoc = {
        ...target,
        status: newStatus,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser?.name || 'Director',
        subagency: (target as any).subagency || currentUser?.subagency || 'pod_main',
        tenantId: (target as any).tenantId || currentUser?.tenantId || 'bloom_studio_default'
      };
      try {
        await Promise.all([
          setDoc(doc(db, "studio-mission-applications", appId), updatedDoc, { merge: true }),
          setDoc(doc(db, "creator-mission-applications", appId), updatedDoc, { merge: true })
        ]);
      } catch (err) {
        console.warn("[OpenMissionsWorkspace] Failed to update application status in Firestore:", err);
      }
    }

    if (triggerNotification) {
      triggerNotification(
        'Application Updated',
        `Application from ${target?.creatorName} for ${target?.missionName} marked as ${newStatus}.`,
        newStatus === 'Approved' ? 'success' : 'info'
      );
    }
  };

  const filteredMissions = liveOpenMissions.filter(m => {
    const matchesSearch = m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          m.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          m.requirements.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || m.category.toLowerCase().includes(categoryFilter.toLowerCase());
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 max-w-6xl mx-auto animate-fade-in text-white">
      {/* Distinction Header Banner: Campaigns vs Missions */}
      <div 
        className="border border-[#C9A46A]/30 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden"
        style={{ backgroundColor: cardBgColor }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-white/10 pb-6">
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#0A1220] bg-[#C9A46A] px-3 py-0.5 rounded-full flex items-center gap-1.5 shadow-sm">
                <Target className="w-3.5 h-3.5" /> Public Open Missions Board
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Role View: <strong className="text-white">{currentUser?.name || 'Staff User'}</strong> ({currentRole})
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white flex items-center gap-3">
              Agency Missions &amp; Open Casting
            </h1>
            <p className="text-xs md:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Open campaign casting calls where <strong>everyone on the roster can apply</strong>. Agent Managers can review open mission bounties and <strong>suggest high-fit missions to specific talent</strong>.
            </p>
          </div>

          {/* Action Area: Log Mission & Campaign Crosslink */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            {/* Log Mission Primary Action for Director / Staff */}
            {(isDirector || isAgentMgr || true) && (
              <button
                type="button"
                id="btn-log-new-mission-header"
                onClick={() => setLogMissionModalOpen(true)}
                className="px-5 py-3.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-[#C9A46A] hover:brightness-110 text-white font-mono font-bold text-xs uppercase tracking-wider rounded-2xl flex items-center justify-center gap-2 shadow-xl hover:scale-[1.02] transition cursor-pointer border border-purple-400/30"
              >
                <Target className="w-4 h-4 text-amber-300" />
                <span>🚀 Launch Mission</span>
              </button>
            )}

            {/* Direct Campaign Workspace Cross-Link */}
            <div className="p-3.5 bg-[#111E33] border border-white/10 rounded-2xl flex flex-col gap-1.5 max-w-xs">
              <div className="flex items-center gap-2 text-xs font-bold text-[#C9A46A] uppercase font-mono">
                <Briefcase className="w-3.5 h-3.5 text-[#C9A46A]" />
                <span>Direct Campaigns?</span>
              </div>
              <p className="text-[10px] text-slate-300 leading-tight">
                Hand-picked invite-only roster campaigns.
              </p>
              {onNavigateToCampaignWorkspace && (
                <button
                  type="button"
                  onClick={onNavigateToCampaignWorkspace}
                  className="mt-0.5 px-2.5 py-1 bg-[#1A2C4A] hover:bg-[#233A60] border border-[#C9A46A]/30 text-[#C9A46A] text-[11px] font-bold rounded-lg flex items-center justify-center gap-1 cursor-pointer transition"
                >
                  <span>Campaign Workspace</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-2 pt-5 border-t border-white/5 flex-wrap">
          <button
            type="button"
            onClick={() => setActiveTab('open-missions')}
            className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'open-missions'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <Target className="w-4 h-4" />
            <span>Open Missions for All ({DEFAULT_OPEN_MISSIONS.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('suggestions-history')}
            className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'suggestions-history'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Agent Suggestions Sent ({suggestions.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('applications')}
            className={`px-4 py-2 rounded-xl text-xs font-bold font-mono transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'applications'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md'
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Creator Applications ({applications.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: Open Missions (Everyone can apply + Suggest to creator) */}
      {activeTab === 'open-missions' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#111E33] border border-white/10 rounded-2xl p-4">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search missions, brands, niches..."
                className="w-full bg-[#0D1830] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto justify-between sm:justify-start">
              <div className="flex items-center gap-1.5">
                {['all', 'Beauty', 'Pets', 'Fitness', 'Tech'].map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategoryFilter(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono font-semibold transition whitespace-nowrap cursor-pointer ${
                      categoryFilter === cat
                        ? 'bg-[#C9A46A] text-[#0A1220]'
                        : 'bg-[#0D1830] text-slate-300 hover:bg-white/10 border border-white/5'
                    }`}
                  >
                    {cat === 'all' ? 'All Niches' : cat}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setLogMissionModalOpen(true)}
                className="px-3.5 py-1.5 bg-[#C9A46A] hover:brightness-110 text-[#0A1220] rounded-xl text-xs font-bold font-mono flex items-center gap-1.5 transition shadow cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
                <span>Log Mission</span>
              </button>
            </div>
          </div>

          {/* Missions Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredMissions.map(m => {
              const spotsLeft = m.spotsTotal - m.spotsFilled;
              return (
                <div 
                  key={m.id}
                  className="bg-[#111E33] border border-white/10 hover:border-[#C9A46A]/40 rounded-2xl p-5 md:p-6 space-y-4 transition flex flex-col justify-between shadow-xl"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                          {m.brand}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded-full">
                          {m.category}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        {spotsLeft} {spotsLeft === 1 ? 'Spot Left' : 'Spots Left'}
                      </span>
                    </div>

                    <div>
                      <h2 className="text-base md:text-lg font-bold text-white">{m.title}</h2>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed">{m.briefSummary}</p>
                    </div>

                    <div className="bg-[#0D1830] border border-white/5 rounded-xl p-3.5 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[10px] uppercase font-mono text-slate-400">Guaranteed Bounty</span>
                        <span className="text-base font-mono font-bold text-emerald-400">${m.bounty.toLocaleString()} USD</span>
                      </div>
                      <div className="flex items-center justify-between text-xs pt-2 border-t border-white/5">
                        <span className="text-[10px] uppercase font-mono text-slate-400">Deliverables</span>
                        <span className="text-xs text-slate-200 font-medium">{m.deliverables}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs pt-2 border-t border-white/5">
                        <span className="text-[10px] uppercase font-mono text-slate-400">Application Deadline</span>
                        <span className="text-xs font-mono font-bold text-[#C9A46A]">{m.deadline}</span>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-400 bg-white/5 p-2.5 rounded-xl border border-white/5">
                      <strong className="text-slate-200 block mb-0.5 font-mono text-[10px] uppercase">Requirements:</strong>
                      {m.requirements}
                    </div>
                  </div>

                  {/* Actions Area: Suggest to Creator (Manager) or Apply (Creator) */}
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Open to All Talent
                    </span>

                    <div className="flex items-center gap-2">
                      {/* Delete Mission Action (Director & Staff) */}
                      {(isDirector || isAgentMgr) && (
                        <button
                          type="button"
                          onClick={() => handleDeleteMission(m.id, m.title)}
                          className="p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-xl text-xs transition cursor-pointer"
                          title="Delete Mission"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {/* Agent Manager Suggest Action */}
                      <button
                        type="button"
                        onClick={() => handleOpenSuggestModal(m)}
                        className="px-3.5 py-2 bg-[#1A2C4A] hover:bg-[#243B62] border border-[#C9A46A]/50 text-[#C9A46A] rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow cursor-pointer"
                        title="Suggest this mission to a creator on your roster"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-[#C9A46A]" />
                        <span>Suggest to Creator</span>
                      </button>

                      {/* Creator Apply Action */}
                      {isCreator && (
                        <button
                          type="button"
                          onClick={() => handleOpenApplyModal(m)}
                          className="px-4 py-2 bg-[#C9A46A] hover:brightness-110 text-[#0A1220] rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Apply Now</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: Agent Manager Suggestions History */}
      {activeTab === 'suggestions-history' && (
        <div className="bg-[#111E33] border border-white/10 rounded-2xl p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#C9A46A]" />
                Missions Suggested by Agent Managers
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                History of open mission casting suggestions dispatched to talent portfolios with personalized manager guidance notes.
              </p>
            </div>
            <span className="text-xs font-mono text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-1 rounded-full">
              {suggestions.length} Suggestions Logged
            </span>
          </div>

          <div className="space-y-3">
            {suggestions.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs">
                No missions have been suggested to creators yet. Use the "Suggest to Creator" button on any open mission.
              </div>
            ) : (
              suggestions.map(sug => (
                <div key={sug.id} className="bg-[#0D1830] border border-white/5 hover:border-white/10 p-4 rounded-xl space-y-3 transition">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-white">{sug.missionName}</span>
                      <span className="text-[10px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.5 rounded-full">
                        {sug.brand}
                      </span>
                      <span className="text-[10px] font-mono text-emerald-400">
                        ${sug.payout.toLocaleString()}
                      </span>
                    </div>

                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/30">
                      {sug.status}
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-400 gap-2">
                    <div>
                      Target Creator: <strong className="text-white">{sug.creatorName}</strong> ({sug.creatorHandle})
                    </div>
                    <div className="text-[11px] font-mono text-slate-400">
                      Dispatched by: <span className="text-slate-300">{sug.suggestedBy}</span> &bull; {sug.suggestedAt}
                    </div>
                  </div>

                  {sug.managerNote && (
                    <div className="bg-[#111E33] border border-white/5 p-2.5 rounded-lg text-xs text-slate-300 flex items-start gap-2">
                      <MessageSquare className="w-3.5 h-3.5 text-[#C9A46A] shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[10px] font-mono uppercase text-[#C9A46A] block">Manager Advice Note:</span>
                        <span>"{sug.managerNote}"</span>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 3: Creator Applications Received */}
      {activeTab === 'applications' && (
        <div className="bg-[#111E33] border border-white/10 rounded-2xl p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-[#C9A46A]" />
                Creator Applications to Open Missions
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Review creators who applied to open agency missions, inspect their pitches, and approve candidates into contracted deals.
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full">
              {applications.length} Applications
            </span>
          </div>

          <div className="space-y-3">
            {applications.map(app => (
              <div key={app.id} className="bg-[#0D1830] border border-white/5 p-4 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-bold text-white">{app.creatorName}</h3>
                    <span className="text-xs font-mono text-[#C9A46A]">{app.creatorHandle}</span>
                    <span className="text-[10px] text-slate-400">applied to</span>
                    <span className="text-xs font-semibold text-white">{app.missionName} ({app.brand})</span>
                  </div>

                  <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border ${
                    app.status === 'Approved' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                    app.status === 'Declined' ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' :
                    'bg-amber-500/10 text-amber-400 border-amber-500/30'
                  }`}>
                    {app.status}
                  </span>
                </div>

                <div className="bg-[#111E33] border border-white/5 p-3 rounded-xl text-xs text-slate-300">
                  <span className="text-[10px] font-mono uppercase text-slate-500 block mb-1">Creator Pitch / Proposal:</span>
                  <p>{app.pitch}</p>
                </div>

                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-[11px] font-mono text-slate-400">
                    Proposed Rate: <strong className="text-emerald-400 font-mono">${app.proposedRate?.toLocaleString()} USD</strong> &bull; {app.appliedAt}
                  </span>

                  {!isCreator && app.status === 'Pending Review' && (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleUpdateApplicationStatus(app.id, 'Declined')}
                        className="px-3 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        Decline
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateApplicationStatus(app.id, 'Approved')}
                        className="px-3.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-bold cursor-pointer flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve &amp; Cast Deal</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: Suggest Mission to Creator (for Agent Manager) */}
      {suggestModalOpen && selectedMissionToSuggest && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/50 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl text-white space-y-5 animate-fade-in">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-lg font-serif font-bold text-white">Suggest Mission to Talent</h3>
              </div>
              <button
                type="button"
                onClick={() => setSuggestModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendSuggestion} className="space-y-4 text-xs">
              <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 space-y-1">
                <span className="text-[10px] font-mono text-[#C9A46A] uppercase block">Selected Mission</span>
                <span className="text-sm font-bold text-white block">{selectedMissionToSuggest.title}</span>
                <span className="text-xs text-emerald-400 font-mono font-bold">${selectedMissionToSuggest.bounty.toLocaleString()} USD ({selectedMissionToSuggest.brand})</span>
              </div>

              {/* Creator Selector */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono uppercase text-slate-300 block">
                  Select Creator from Active Roster *
                </label>
                <select
                  value={targetCreatorHandle}
                  onChange={(e) => setTargetCreatorHandle(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3 py-2.5 text-xs text-white outline-none cursor-pointer"
                >
                  {creators.length > 0 ? (
                    creators.map(c => (
                      <option key={c.id || c.handle} value={c.handle}>
                        {c.name} ({c.handle}) &bull; {c.niche || 'Creator'} &bull; {c.followers} followers
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="@alexjones">Alex Jones (@alexjones) &bull; Beauty &bull; 140k</option>
                      <option value="@elenarostova">Elena Rostova (@elenarostova) &bull; Lifestyle &bull; 210k</option>
                      <option value="@sophiaglows">Sophia Chen (@sophiaglows) &bull; Skincare &bull; 85k</option>
                      <option value="@marcusfit">Marcus Vance (@marcusfit) &bull; Fitness &bull; 95k</option>
                    </>
                  )}
                </select>
              </div>

              {/* Manager Advice Note */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono uppercase text-slate-300 block">
                  Personal Advice &amp; Pitch Note to Creator *
                </label>
                <textarea
                  rows={4}
                  required
                  value={suggestionNote}
                  onChange={(e) => setSuggestionNote(e.target.value)}
                  placeholder="Explain why this mission is a great fit, what they should emphasize, or why you recommend they apply..."
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none resize-none leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setSuggestModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white bg-white/5 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#C9A46A] hover:brightness-110 text-[#070D18] font-bold flex items-center gap-2 cursor-pointer shadow-lg"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Dispatch Suggestion</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Creator Application */}
      {applyModalOpen && missionToApply && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/50 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl text-white space-y-5 animate-fade-in">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-lg font-serif font-bold text-white">Apply for Open Mission</h3>
              </div>
              <button
                type="button"
                onClick={() => setApplyModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendApplication} className="space-y-4 text-xs">
              <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 space-y-1">
                <span className="text-[10px] font-mono text-[#C9A46A] uppercase block">Mission</span>
                <span className="text-sm font-bold text-white block">{missionToApply.title}</span>
                <span className="text-xs text-slate-300">{missionToApply.deliverables}</span>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-mono uppercase text-slate-300 block">
                  Your Pitch &amp; Creative Angle *
                </label>
                <textarea
                  rows={4}
                  required
                  value={applicationPitch}
                  onChange={(e) => setApplicationPitch(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none resize-none leading-relaxed"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-mono uppercase text-slate-300 block">
                  Proposed Compensation Rate ($ USD)
                </label>
                <input
                  type="number"
                  value={proposedRate}
                  onChange={(e) => setProposedRate(Number(e.target.value))}
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setApplyModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white bg-white/5 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#C9A46A] hover:brightness-110 text-[#070D18] font-bold flex items-center gap-2 cursor-pointer shadow-lg"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Application</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* MODAL: Director / Staff Log New Mission */}
      {logMissionModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0D1830] border border-[#C9A46A]/50 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl text-white space-y-5 my-8 animate-fade-in max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A]">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-serif font-bold text-white flex items-center gap-2">
                    Log New Open Mission &amp; Casting Call
                  </h3>
                  <p className="text-xs text-slate-400">
                    Broadcast an open casting bounty to your roster talent or delegate to agent managers.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setLogMissionModalOpen(false)}
                className="text-slate-400 hover:text-white p-1.5 rounded-xl bg-white/5 hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Sample Template Button */}
            <div className="flex items-center justify-between bg-[#111E33] border border-[#C9A46A]/20 rounded-2xl p-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#C9A46A]" />
                <span className="text-xs font-mono text-slate-300">Need a quick starting point?</span>
              </div>
              <button
                type="button"
                onClick={handleLoadSampleMission}
                className="px-3 py-1.5 bg-[#1A2C4A] hover:bg-[#233A60] border border-[#C9A46A]/40 text-[#C9A46A] text-xs font-mono font-bold rounded-xl cursor-pointer transition flex items-center gap-1.5"
              >
                <span>✨ Pre-fill Sample Mission</span>
              </button>
            </div>

            <form onSubmit={handleLogNewMission} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Mission Title */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Mission Title / Campaign Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Summer Glow Botanical Serum Sprint"
                    value={newMissionTitle}
                    onChange={(e) => setNewMissionTitle(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                {/* Brand / Sponsor */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Brand / Sponsor Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., GlowLab Beauty"
                    value={newMissionBrand}
                    onChange={(e) => setNewMissionBrand(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                {/* Category / Niche */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Niche / Category
                  </label>
                  <select
                    value={newMissionCategory}
                    onChange={(e) => setNewMissionCategory(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none cursor-pointer"
                  >
                    <option value="Beauty & Skincare">Beauty &amp; Skincare</option>
                    <option value="Pets & Wellness">Pets &amp; Wellness</option>
                    <option value="Fitness & Health">Fitness &amp; Health</option>
                    <option value="Tech & Lifestyle">Tech &amp; Lifestyle</option>
                    <option value="Fashion & Apparel">Fashion &amp; Apparel</option>
                    <option value="Food & Beverage">Food &amp; Beverage</option>
                    <option value="Gaming & Esports">Gaming &amp; Esports</option>
                    <option value="Travel & Hospitality">Travel &amp; Hospitality</option>
                    <option value="General Lifestyle">General Lifestyle</option>
                  </select>
                </div>

                {/* Bounty / Payout ($ USD) */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Guaranteed Bounty Per Creator ($ USD)
                  </label>
                  <input
                    type="number"
                    min={100}
                    step={100}
                    required
                    value={newMissionBounty}
                    onChange={(e) => setNewMissionBounty(Number(e.target.value))}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-emerald-400 font-mono font-bold outline-none"
                  />
                </div>

                {/* Creator Spots / Slots */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Total Creator Slots Available
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    required
                    value={newMissionSpotsTotal}
                    onChange={(e) => setNewMissionSpotsTotal(Number(e.target.value))}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white font-mono outline-none"
                  />
                </div>

                {/* Application Deadline */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Application Deadline / Timeline
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., In 7 Days or Oct 15, 2026"
                    value={newMissionDeadline}
                    onChange={(e) => setNewMissionDeadline(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none font-mono"
                  />
                </div>

                {/* Required Deliverables */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Deliverables Expected *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., 1x 60s TikTok Reel + Spark Ads Authorization"
                    value={newMissionDeliverables}
                    onChange={(e) => setNewMissionDeliverables(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                {/* Requirements / FTC */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Creator Requirements &amp; FTC Guidelines
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., 10k+ followers, natural aesthetic, authentic first-impression reel with FTC #ad tag"
                    value={newMissionRequirements}
                    onChange={(e) => setNewMissionRequirements(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none"
                  />
                </div>

                {/* Brief Summary */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[11px] font-mono uppercase text-slate-300 block">
                    Mission Brief Summary &amp; Description *
                  </label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Explain the product, creative direction, and campaign goals for roster creators..."
                    value={newMissionBriefSummary}
                    onChange={(e) => setNewMissionBriefSummary(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl p-3 text-xs text-white placeholder-slate-500 outline-none resize-none leading-relaxed"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                <span className="text-[10px] font-mono text-slate-400">
                  Total Budget Reserved: <strong className="text-emerald-400 font-bold">${(newMissionBounty * newMissionSpotsTotal).toLocaleString()} USD</strong>
                </span>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setLogMissionModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-slate-400 hover:text-white bg-white/5 cursor-pointer font-semibold text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#C9A46A] to-[#D4AF37] hover:brightness-110 text-[#0A1220] font-mono font-bold text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-xl"
                  >
                    <Target className="w-4 h-4" />
                    <span>Broadcast Mission</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
