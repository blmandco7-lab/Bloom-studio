import React, { useState } from 'react';
import { 
  CreditCard, Shield, Lock, Unlock, Copy, Check, Eye, EyeOff, 
  Zap, Smartphone, RefreshCw, Sparkles, CheckCircle2, ChevronRight,
  TrendingUp, Download, ArrowUpRight, Award, DollarSign, QrCode, X, Share2, ExternalLink
} from 'lucide-react';
import { Creator } from '../types';

interface AgencyDebitCardProps {
  creator?: Creator | null;
  creatorName?: string;
  creatorHandle?: string;
  agencyName?: string;
  primaryColor?: string;
  cardLast4?: string;
  cardExpiry?: string;
  balance?: number;
  onTriggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  compact?: boolean;
}

export type CardTheme = 'midnight-gold' | 'obsidian-gold' | 'champagne-bronze' | 'emerald-syndicate';

export const AgencyDebitCard: React.FC<AgencyDebitCardProps> = ({
  creator,
  creatorName,
  creatorHandle,
  agencyName = 'Bloom & Co.',
  primaryColor = '#C9A46A',
  cardLast4 = '4242',
  cardExpiry = '08/29',
  balance = 8450,
  onTriggerNotification,
  onAddActivityLog,
  compact = false
}) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isFrozen, setIsFrozen] = useState(false);
  const [showFullNumber, setShowFullNumber] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [selectedTheme, setSelectedTheme] = useState<CardTheme>('midnight-gold');
  const [activeTab, setActiveTab] = useState<'card' | 'controls' | 'photomockup'>('card');
  const [onlineSpendLimit, setOnlineSpendLimit] = useState(10000);
  const [atmLimit, setAtmLimit] = useState(2500);
  const [appleWalletAdded, setAppleWalletAdded] = useState(false);
  const [showAppleWalletModal, setShowAppleWalletModal] = useState(false);

  const displayName = (creator?.name || creatorName || 'Alex Jones').toUpperCase();
  const displayHandle = creator?.handle || creatorHandle || '@alexjones';
  const effectiveLast4 = creator?.stripeCardLast4 || cardLast4 || '4242';
  const effectiveExpiry = creator?.stripeCardExpiry || cardExpiry || '08/29';
  const effectiveCvv = '849'; // Mockup literal for visual prototype

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(label);
    if (onTriggerNotification) {
      onTriggerNotification("Copied to Clipboard", `${label} copied successfully.`, "success");
    }
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleToggleFreeze = () => {
    const nextState = !isFrozen;
    setIsFrozen(nextState);
    if (onTriggerNotification) {
      onTriggerNotification(
        nextState ? "Card Frozen" : "Card Unfrozen",
        nextState 
          ? `Your Agency Debit Card (•••• ${effectiveLast4}) has been temporarily locked for security.` 
          : `Your Agency Debit Card (•••• ${effectiveLast4}) is now unlocked and active for purchases and instant escrow payouts.`,
        nextState ? "warning" : "success"
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        displayName, 
        'creator', 
        nextState ? `Frozen Agency Debit Card (•••• ${effectiveLast4})` : `Unfrozen Agency Debit Card (•••• ${effectiveLast4})`
      );
    }
  };

  const handleAddToAppleWallet = () => {
    setAppleWalletAdded(true);
    setShowAppleWalletModal(true);
    if (onTriggerNotification) {
      onTriggerNotification(
        "Apple Wallet Ready",
        `Agency Debit Card (•••• ${effectiveLast4}) digital pass opened. Add to Apple Pay on iOS & Apple Watch.`,
        "success"
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(displayName, 'creator', `Opened Apple Wallet pass for Agency Debit Card (•••• ${effectiveLast4})`);
    }
  };

  const handleDownloadApplePass = () => {
    // Generate a downloadable digital pass manifest bundle JSON / .pkpass simulation
    const passData = {
      formatVersion: 1,
      passTypeIdentifier: "pass.com.bloom.agencycard",
      serialNumber: `BLM-${effectiveLast4}-${Date.now()}`,
      teamIdentifier: "BLOOMAGENCY",
      organizationName: agencyName,
      description: "Bloom & Co. Agency Talent Corporate Card",
      logoText: "Bloom & Co.",
      foregroundColor: "rgb(255, 255, 255)",
      backgroundColor: "rgb(13, 24, 48)",
      labelColor: "rgb(201, 164, 106)",
      storeCard: {
        headerFields: [
          { key: "balance", label: "AVAILABLE BALANCE", value: `$${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}` }
        ],
        primaryFields: [
          { key: "cardholder", label: "CARDHOLDER", value: displayName }
        ],
        secondaryFields: [
          { key: "cardNum", label: "CARD NUMBER", value: `•••• ${effectiveLast4}` },
          { key: "expires", label: "EXPIRES", value: effectiveExpiry }
        ],
        auxiliaryFields: [
          { key: "type", label: "TYPE", value: "Visa Corporate Debit" },
          { key: "network", label: "ISSUER", value: "Stripe Issuing" }
        ],
        backFields: [
          { key: "terms", label: "TERMS OF USE", value: "Official corporate debit card issued for Bloom & Co. roster talent. Usable worldwide with zero foreign transaction fees. Auto-funded from escrow settlements." },
          { key: "support", label: "24/7 CONCIERGE", value: "support@bloom.co" }
        ]
      },
      nfc: {
        message: `BLOOM_VISA_DEBIT_${effectiveLast4}`
      },
      barcode: {
        message: `BLOOM-VISA-400012345678${effectiveLast4}`,
        format: "PKBarcodeFormatQR",
        messageEncoding: "iso-8859-1",
        altText: `4000 1234 5678 ${effectiveLast4}`
      }
    };

    const blob = new Blob([JSON.stringify(passData, null, 2)], { type: 'application/vnd.apple.pkpass' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Bloom_Agency_Debit_Pass_${effectiveLast4}.pkpass`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (onTriggerNotification) {
      onTriggerNotification(
        "Pass Downloaded",
        `Downloaded Bloom_Agency_Debit_Pass_${effectiveLast4}.pkpass for Apple Wallet.`,
        "success"
      );
    }
  };

  // Theme Gradients & Styling
  const themeStyles: Record<CardTheme, {
    bgGradient: string;
    borderStyle: string;
    textPrimary: string;
    textAccent: string;
    logoColor: string;
    chipGradient: string;
    glowColor: string;
    name: string;
  }> = {
    'midnight-gold': {
      bgGradient: 'bg-gradient-to-tr from-[#050B14] via-[#0D1B33] to-[#172D54]',
      borderStyle: 'border-[#C9A46A]/50 shadow-[0_20px_50px_rgba(201,164,106,0.15)]',
      textPrimary: 'text-white',
      textAccent: 'text-[#C9A46A]',
      logoColor: '#C9A46A',
      chipGradient: 'from-amber-200 via-amber-400 to-amber-600',
      glowColor: 'bg-[#C9A46A]/15',
      name: 'Signature Midnight & Gold'
    },
    'obsidian-gold': {
      bgGradient: 'bg-gradient-to-tr from-[#020408] via-[#0A0D14] to-[#151922]',
      borderStyle: 'border-amber-400/60 shadow-[0_20px_50px_rgba(245,158,11,0.2)]',
      textPrimary: 'text-white',
      textAccent: 'text-amber-400',
      logoColor: '#F59E0B',
      chipGradient: 'from-[#F3E5AB] via-[#D4AF37] to-[#AA771C]',
      glowColor: 'bg-amber-500/10',
      name: 'Obsidian Black & Gold Foil'
    },
    'champagne-bronze': {
      bgGradient: 'bg-gradient-to-tr from-[#120D08] via-[#241B12] to-[#3B2C1D]',
      borderStyle: 'border-[#E0C097]/50 shadow-[0_20px_50px_rgba(224,192,151,0.15)]',
      textPrimary: 'text-white',
      textAccent: 'text-[#E0C097]',
      logoColor: '#E0C097',
      chipGradient: 'from-orange-200 via-amber-300 to-amber-600',
      glowColor: 'bg-[#E0C097]/15',
      name: 'Champagne Bronze & Velvet'
    },
    'emerald-syndicate': {
      bgGradient: 'bg-gradient-to-tr from-[#03140E] via-[#08291D] to-[#124230]',
      borderStyle: 'border-emerald-400/50 shadow-[0_20px_50px_rgba(16,185,129,0.15)]',
      textPrimary: 'text-white',
      textAccent: 'text-emerald-300',
      logoColor: '#34D399',
      chipGradient: 'from-emerald-200 via-[#D4AF37] to-amber-600',
      glowColor: 'bg-emerald-500/15',
      name: 'Emerald Syndicate VIP'
    }
  };

  const currentTheme = themeStyles[selectedTheme];

  return (
    <div className="space-y-6">
      {/* Top Header & Mode Navigation */}
      {!compact && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div className="relative group">
            <div className="flex items-center gap-2">
              <h3 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-[#C9A46A]" /> 
                Agency Debit Card &bull; Stripe Issuing
              </h3>
              <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                isFrozen 
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' 
                  : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
              }`}>
                {isFrozen ? '❄️ FROZEN' : '⚡ INSTANT PAYOUTS READY'}
              </span>
              <span className="text-[9px] bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2 py-0.5 rounded-full font-mono font-bold">
                MOCKUP
              </span>
            </div>
            <p className="text-xs text-[#7C8AA8] mt-1">
              Official Bloom &amp; Co. creator corporate card. Escrow milestones and sponsor deals settle directly to this card balance.
            </p>
            {/* Disclaimer Overlay for Security Audit Awareness */}
            <div className="mt-2 p-2 bg-amber-500/10 border border-amber-500/20 rounded-lg text-[10px] text-amber-200/80 leading-tight">
              <span className="font-bold text-amber-400">DEVELOPER NOTICE:</span> This interface is a high-fidelity visual prototype. Card numbers, CVVs, and balance settlement logic are simulated for demonstration of the Stripe Issuing roadmap and are not yet linked to live financial accounts.
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('card')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'card' 
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md' 
                  : 'bg-[#111E33] text-slate-300 hover:text-white border border-white/10'
              }`}
            >
              Interactive 3D Card
            </button>
            <button
              onClick={() => setActiveTab('photomockup')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'photomockup' 
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md' 
                  : 'bg-[#111E33] text-slate-300 hover:text-white border border-white/10'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" /> High-Res Render
            </button>
            <button
              onClick={() => setActiveTab('controls')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'controls' 
                  ? 'bg-[#C9A46A] text-[#0A1220] shadow-md' 
                  : 'bg-[#111E33] text-slate-300 hover:text-white border border-white/10'
              }`}
            >
              Card Controls
            </button>
          </div>
        </div>
      )}

      {/* TAB 1: INTERACTIVE 3D DEBIT CARD */}
      {activeTab === 'card' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Card Showcase Column */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center space-y-4">
            
            {/* Card Container with 3D Flip */}
            <div 
              className="relative w-full max-w-[380px] h-[235px] cursor-pointer perspective-1000 group select-none"
              onClick={() => setIsFlipped(!isFlipped)}
              title="Click card to flip between front and back"
            >
              {/* Card Inner with 3D Flip Transform */}
              <div 
                className={`w-full h-full duration-700 transition-all transform-gpu preserve-3d relative rounded-2xl ${
                  isFlipped ? 'rotate-y-180' : ''
                }`}
                style={{ transformStyle: 'preserve-3d', transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)' }}
              >
                
                {/* ========================================================
                    FRONT OF CARD
                   ======================================================== */}
                <div 
                  className={`absolute inset-0 w-full h-full rounded-2xl p-6 flex flex-col justify-between border ${currentTheme.borderStyle} ${currentTheme.bgGradient} backface-hidden overflow-hidden shadow-2xl`}
                  style={{ backfaceVisibility: 'hidden' }}
                >
                  {/* Subtle Luxury Watermark Pattern */}
                  <div className="absolute inset-0 opacity-[0.07] pointer-events-none flex items-center justify-center">
                    <svg viewBox="0 0 200 200" className="w-80 h-80 text-white" fill="currentColor">
                      <path d="M100 15 C105 50, 150 95, 185 100 C150 105, 105 150, 100 185 C95 150, 50 105, 15 100 C50 95, 95 50, 100 15 Z" />
                      <circle cx="100" cy="100" r="30" fill="none" stroke="currentColor" strokeWidth="4" />
                    </svg>
                  </div>

                  {/* Ambient Glow */}
                  <div className={`absolute -top-16 -right-16 w-48 h-48 ${currentTheme.glowColor} rounded-full blur-3xl pointer-events-none`}></div>
                  <div className={`absolute -bottom-16 -left-16 w-48 h-48 ${currentTheme.glowColor} rounded-full blur-3xl pointer-events-none`}></div>

                  {/* Top Header: Brand Logo & NFC Contactless */}
                  <div className="flex items-center justify-between z-10">
                    <div className="flex items-center gap-2.5">
                      {/* Geometric Blooming Lotus / Star Emblem SVG Logo */}
                      <div className="w-8 h-8 rounded-lg bg-black/40 border border-[#C9A46A]/60 flex items-center justify-center shadow-md backdrop-blur-sm">
                        <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none">
                          <path 
                            d="M12 2L14.2 8.5L21 9.2L15.8 13.6L17.5 20.2L12 16.5L6.5 20.2L8.2 13.6L3 9.2L9.8 8.5L12 2Z" 
                            fill="url(#goldGradientLotus)" 
                            stroke="#C9A46A" 
                            strokeWidth="0.5" 
                          />
                          <circle cx="12" cy="12" r="2.5" fill="#0A1220" stroke="#C9A46A" strokeWidth="0.8" />
                          <defs>
                            <linearGradient id="goldGradientLotus" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#FFF2D6" />
                              <stop offset="50%" stopColor="#C9A46A" />
                              <stop offset="100%" stopColor="#8A642B" />
                            </linearGradient>
                          </defs>
                        </svg>
                      </div>

                      <div>
                        <div className="font-serif font-bold text-sm tracking-wider text-white flex items-center gap-1.5">
                          {agencyName}
                          <span className="text-[8px] bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/40 px-1.5 py-0.2 rounded font-mono font-bold tracking-normal">
                            DEBIT
                          </span>
                        </div>
                        <div className="text-[8px] font-mono uppercase tracking-widest text-[#7C8AA8]">
                          TALENT NETWORK
                        </div>
                      </div>
                    </div>

                    {/* Contactless Wave Symbol */}
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <svg className="w-5 h-5 opacity-80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M8.5 16.5a5 5 0 0 1 0-9" />
                        <path d="M12 19a8.5 8.5 0 0 0 0-14" />
                        <path d="M15.5 21.5a12 12 0 0 0 0-19" />
                      </svg>
                    </div>
                  </div>

                  {/* Middle Row: EMV Gold Smart Chip & Card Status */}
                  <div className="flex items-center justify-between z-10 my-1">
                    {/* Metallic Smart Chip */}
                    <div className="w-11 h-8 rounded-md bg-gradient-to-br from-amber-100 via-amber-300 to-amber-600 border border-amber-700/60 p-1 flex flex-col justify-between shadow-md relative overflow-hidden">
                      <div className="w-full h-full border border-amber-900/30 rounded flex items-center justify-center">
                        <div className="w-full h-[1px] bg-amber-900/40 absolute top-2.5"></div>
                        <div className="w-full h-[1px] bg-amber-900/40 absolute bottom-2.5"></div>
                        <div className="h-full w-[1px] bg-amber-900/40 absolute left-4"></div>
                        <div className="h-full w-[1px] bg-amber-900/40 absolute right-4"></div>
                      </div>
                    </div>

                    {/* Security Hologram & Status */}
                    <div className="flex items-center gap-1.5 bg-black/40 border border-white/10 px-2.5 py-1 rounded-full backdrop-blur-sm">
                      <div className={`w-2 h-2 rounded-full ${isFrozen ? 'bg-rose-400 animate-pulse' : 'bg-emerald-400'}`}></div>
                      <span className="text-[9px] font-mono font-semibold text-slate-200">
                        {isFrozen ? 'CARD FROZEN' : 'ESCROW ACTIVE'}
                      </span>
                    </div>
                  </div>

                  {/* Card Number */}
                  <div className="z-10 pt-1">
                    <div className="font-mono text-base tracking-[0.22em] text-white font-bold drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] flex items-center justify-between">
                      {showFullNumber ? (
                        <>
                          <span>4000</span>
                          <span>1234</span>
                          <span>5678</span>
                          <span className={currentTheme.textAccent}>{effectiveLast4}</span>
                        </>
                      ) : (
                        <>
                          <span>••••</span>
                          <span>••••</span>
                          <span>••••</span>
                          <span className={currentTheme.textAccent}>{effectiveLast4}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Bottom Row: Cardholder Name, Expiration, Visa & Stripe Logo */}
                  <div className="flex items-end justify-between z-10 pt-1 border-t border-white/10">
                    <div className="max-w-[170px]">
                      <div className="text-[7px] uppercase tracking-widest text-[#7C8AA8] font-mono">CARDHOLDER</div>
                      <div className="text-[11px] font-bold text-white tracking-wider uppercase font-mono truncate">
                        {displayName}
                      </div>
                    </div>

                    <div className="text-center px-2">
                      <div className="text-[7px] uppercase tracking-widest text-[#7C8AA8] font-mono">GOOD THRU</div>
                      <div className="text-[10px] font-bold text-slate-200 font-mono tracking-wider">{effectiveExpiry}</div>
                    </div>

                    <div className="text-right flex flex-col items-end">
                      <div className="font-extrabold text-sm tracking-wider text-white italic drop-shadow">
                        VISA
                      </div>
                      <div className="text-[7px] font-mono text-[#C9A46A] tracking-tight font-semibold">
                        DEBIT &bull; STRIPE
                      </div>
                    </div>
                  </div>
                </div>

                {/* ========================================================
                    BACK OF CARD
                   ======================================================== */}
                <div 
                  className={`absolute inset-0 w-full h-full rounded-2xl flex flex-col justify-between border ${currentTheme.borderStyle} ${currentTheme.bgGradient} backface-hidden overflow-hidden shadow-2xl`}
                  style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
                >
                  {/* Magnetic Stripe */}
                  <div className="w-full h-10 bg-[#06080C] mt-4 border-y border-white/10 shadow-inner"></div>

                  {/* Signature Strip & CVC Box */}
                  <div className="px-6 space-y-2">
                    <div className="flex items-center gap-3">
                      {/* White Signature Box */}
                      <div className="flex-1 h-8 bg-slate-200 rounded flex items-center justify-between px-3 relative overflow-hidden">
                        {/* Fake Signature Script */}
                        <span className="font-serif italic text-slate-800 text-xs font-bold tracking-wider select-none transform -rotate-1">
                          {displayName.toLowerCase()}
                        </span>
                        <span className="text-[8px] font-mono text-slate-500 font-semibold uppercase">Authorized Signature</span>
                      </div>

                      {/* CVV Box */}
                      <div className="bg-white border border-slate-300 rounded px-2.5 py-1 text-center shadow-inner">
                        <div className="text-[7px] text-slate-500 font-mono">CVV</div>
                        <div className="text-xs font-mono font-bold text-slate-900 tracking-widest">{effectiveCvv}</div>
                      </div>
                    </div>

                    {/* Legal / FDIC / Stripe Issuing Disclosures */}
                    <div className="text-[7px] text-[#7C8AA8] leading-tight font-mono space-y-1">
                      <p>
                        This card is issued by Bloom &amp; Co. pursuant to a license by Visa U.S.A. Inc. and Stripe Payments Company. Direct escrow settlements and talent funds held in FDIC-insured partner banks.
                      </p>
                      <p>
                        24/7 Agency Cardholder Concierge: <span className="text-slate-300">support@bloom.co</span> &bull; Worldwide Visa ATM &amp; POS Network.
                      </p>
                    </div>
                  </div>

                  {/* Network Badges on Back */}
                  <div className="px-6 pb-4 flex items-center justify-between border-t border-white/5 pt-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono font-bold text-[#C9A46A] tracking-wider">STRIPE ISSUING</span>
                      <span className="text-[8px] text-slate-400 font-mono">&bull; ZERO LIABILITY</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="font-bold text-xs text-white italic">VISA</div>
                    </div>
                  </div>

                </div>

              </div>
            </div>

            {/* Click to Flip Prompt */}
            <div className="flex items-center gap-3 text-xs text-[#7C8AA8]">
              <button
                type="button"
                onClick={() => setIsFlipped(!isFlipped)}
                className="hover:text-white flex items-center gap-1.5 font-mono text-[11px] bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg border border-white/10 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-[#C9A46A]" />
                {isFlipped ? 'Flip to Front' : 'Flip to Back (CVV & Stripe)'}
              </button>

              <button
                type="button"
                onClick={() => setShowFullNumber(!showFullNumber)}
                className="hover:text-white flex items-center gap-1.5 font-mono text-[11px] bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg border border-white/10 transition-colors cursor-pointer"
              >
                {showFullNumber ? <EyeOff className="w-3.5 h-3.5 text-amber-400" /> : <Eye className="w-3.5 h-3.5 text-emerald-400" />}
                {showFullNumber ? 'Hide Digits' : 'Reveal Digits'}
              </button>
            </div>

          </div>

          {/* Quick Actions & Live Balances Column */}
          <div className="lg:col-span-6 space-y-4">
            
            {/* Live Instant Escrow Available Balance */}
            <div className="bg-[#0b1628] border border-[#C9A46A]/30 rounded-2xl p-5 shadow-lg relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#C9A46A]/10 rounded-full blur-2xl pointer-events-none"></div>
              
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-[#7C8AA8] uppercase font-mono font-semibold tracking-wider">
                    Instant Card Available Balance
                  </span>
                  <div className="text-2xl sm:text-3xl font-serif font-bold text-white mt-0.5 flex items-baseline gap-1">
                    <span className="text-emerald-400 font-mono">${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                    <span className="text-xs text-slate-400 font-mono">USD</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2.5 py-1 rounded-lg font-mono font-bold flex items-center gap-1">
                    <Zap className="w-3 h-3 text-emerald-400" /> 0s Payout Lag
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">Auto-Funded from Escrow</div>
                </div>
              </div>

              {/* Quick Copy Action Bar */}
              <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-white/10 text-center">
                <button
                  type="button"
                  onClick={() => copyToClipboard(`400012345678${effectiveLast4}`, 'Card Number')}
                  className="bg-[#111E33] hover:bg-[#172744] p-2 rounded-xl border border-white/5 transition-colors cursor-pointer flex flex-col items-center gap-1"
                >
                  <div className="text-[9px] text-[#7C8AA8] uppercase font-mono">Card Number</div>
                  <div className="text-xs font-mono font-bold text-white flex items-center gap-1">
                    {copiedField === 'Card Number' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-[#C9A46A]" />}
                    •••• {effectiveLast4}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => copyToClipboard(effectiveExpiry, 'Expiration')}
                  className="bg-[#111E33] hover:bg-[#172744] p-2 rounded-xl border border-white/5 transition-colors cursor-pointer flex flex-col items-center gap-1"
                >
                  <div className="text-[9px] text-[#7C8AA8] uppercase font-mono">Expires</div>
                  <div className="text-xs font-mono font-bold text-white flex items-center gap-1">
                    {copiedField === 'Expiration' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-[#C9A46A]" />}
                    {effectiveExpiry}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => copyToClipboard(effectiveCvv, 'CVV')}
                  className="bg-[#111E33] hover:bg-[#172744] p-2 rounded-xl border border-white/5 transition-colors cursor-pointer flex flex-col items-center gap-1"
                >
                  <div className="text-[9px] text-[#7C8AA8] uppercase font-mono">CVV Code</div>
                  <div className="text-xs font-mono font-bold text-white flex items-center gap-1">
                    {copiedField === 'CVV' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-[#C9A46A]" />}
                    {effectiveCvv}
                  </div>
                </button>
              </div>
            </div>

            {/* Card Action Buttons (Freeze, Apple Pay, Limits) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              
              {/* Apple Pay / Google Wallet */}
              <button
                type="button"
                onClick={handleAddToAppleWallet}
                className="bg-black hover:bg-zinc-900 border border-white/20 p-3.5 rounded-2xl flex items-center justify-between text-left transition-all cursor-pointer shadow-md group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-zinc-800 flex items-center justify-center text-white">
                    <Smartphone className="w-4 h-4 text-slate-200" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1">
                      {appleWalletAdded ? 'Added to Wallet' : 'Add to Apple Wallet'}
                      {appleWalletAdded && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <div className="text-[10px] text-[#7C8AA8]">Apple Pay &amp; Google Wallet</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
              </button>

              {/* Live Freeze / Unfreeze Switch */}
              <button
                type="button"
                onClick={handleToggleFreeze}
                className={`p-3.5 rounded-2xl flex items-center justify-between text-left transition-all cursor-pointer shadow-md border ${
                  isFrozen 
                    ? 'bg-rose-950/60 border-rose-500/50 hover:bg-rose-900/60' 
                    : 'bg-[#111E33] border-white/10 hover:bg-[#162742]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    isFrozen ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                  }`}>
                    {isFrozen ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">
                      {isFrozen ? 'Card Frozen (Locked)' : 'Card Unlocked (Active)'}
                    </div>
                    <div className="text-[10px] text-[#7C8AA8]">
                      {isFrozen ? 'Tap to enable purchases' : 'Tap to lock immediately'}
                    </div>
                  </div>
                </div>
                <div className={`w-3 h-3 rounded-full ${isFrozen ? 'bg-rose-400' : 'bg-emerald-400'}`}></div>
              </button>

            </div>

            {/* Theme Selector Pill Bar */}
            <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A46A]" /> Card Aesthetics &amp; Color Finish
                </span>
                <span className="text-[10px] text-[#7C8AA8] font-mono">{currentTheme.name}</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                {(Object.keys(themeStyles) as CardTheme[]).map((themeKey) => {
                  const t = themeStyles[themeKey];
                  const isSelected = selectedTheme === themeKey;
                  return (
                    <button
                      key={themeKey}
                      type="button"
                      onClick={() => {
                        setSelectedTheme(themeKey);
                        if (onTriggerNotification) {
                          onTriggerNotification("Card Theme Updated", `Applied "${t.name}" aesthetic to your debit card.`, "info");
                        }
                      }}
                      className={`p-2 rounded-xl text-left border transition-all cursor-pointer flex flex-col justify-between h-14 ${
                        isSelected 
                          ? 'border-[#C9A46A] bg-[#162742] ring-1 ring-[#C9A46A]' 
                          : 'border-white/5 bg-[#111E33] hover:bg-[#14223A]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className={`w-3.5 h-3.5 rounded-full ${t.bgGradient} border border-white/20`}></div>
                        {isSelected && <Check className="w-3 h-3 text-[#C9A46A]" />}
                      </div>
                      <span className="text-[9px] font-semibold text-slate-200 truncate">{t.name.split('&')[0]}</span>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* TAB 2: HIGH RESOLUTION PRODUCT RENDER */}
      {activeTab === 'photomockup' && (
        <div className="bg-[#0b1628] border border-[#C9A46A]/30 rounded-2xl p-6 space-y-5 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="font-serif font-bold text-base text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#C9A46A]" /> Official Luxury Product Showcase
              </h4>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Studio photograph render of the physical Bloom &amp; Co. embossed metallic agency debit card with custom luxury gold foil finish.
              </p>
            </div>
            <span className="text-xs bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/40 px-3 py-1 rounded-xl font-mono font-bold shrink-0">
              FedEx Tracked Physical Card
            </span>
          </div>

          {/* Generated Luxury Card Asset Display */}
          <div className="w-full rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-black relative group">
            <img 
              src="/src/assets/images/agency_debit_card_1785957524486.jpg" 
              alt="Bloom & Co. Luxury Agency Debit Card" 
              className="w-full h-auto max-h-[440px] object-cover object-center group-hover:scale-[1.01] transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            
            {/* Overlay Specs Badge */}
            <div className="absolute bottom-4 left-4 right-4 bg-black/70 backdrop-blur-md border border-white/10 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
                <div>
                  <div className="text-xs font-bold text-white">Bloom Studio Signature Debit Card (Visa)</div>
                  <div className="text-[10px] text-[#7C8AA8]">Heavyweight 16g Brushed Metal Finish &bull; Stripe Issuing Core</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (onTriggerNotification) {
                      onTriggerNotification("Physical Card Shipped", "Your physical debit card has been dispatched via FedEx Express. Tracking: FX-84920481", "success");
                    }
                  }}
                  className="bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] text-xs font-bold px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <TrendingUp className="w-3.5 h-3.5" /> Track Physical Delivery
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CARD LIMITS & SECURITY CONTROLS */}
      {activeTab === 'controls' && (
        <div className="bg-[#0b1628] border border-white/10 rounded-2xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h4 className="font-serif font-bold text-base text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" /> Stripe Issuing Security &amp; Spend Controls
              </h4>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Set autonomous rules, merchant categories, daily ATM cash withdrawal limits, and fraud protection.
              </p>
            </div>
            <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-xl font-mono">
              FDIC Insured
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Daily Online Limit Slider */}
            <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200">Daily Online &amp; POS Spend Limit</span>
                <span className="text-xs font-mono font-bold text-emerald-400">${onlineSpendLimit.toLocaleString()} USD</span>
              </div>
              <input 
                type="range" 
                min="1000" 
                max="50000" 
                step="1000"
                value={onlineSpendLimit} 
                onChange={(e) => setOnlineSpendLimit(Number(e.target.value))}
                className="w-full accent-[#C9A46A] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7C8AA8] font-mono">
                <span>$1,000</span>
                <span>$25,000</span>
                <span>$50,000 Max</span>
              </div>
            </div>

            {/* ATM Withdrawal Limit Slider */}
            <div className="bg-[#111E33] p-4 rounded-xl border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200">Daily ATM Cash Withdrawal Limit</span>
                <span className="text-xs font-mono font-bold text-[#C9A46A]">${atmLimit.toLocaleString()} USD</span>
              </div>
              <input 
                type="range" 
                min="500" 
                max="5000" 
                step="500"
                value={atmLimit} 
                onChange={(e) => setAtmLimit(Number(e.target.value))}
                className="w-full accent-[#C9A46A] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7C8AA8] font-mono">
                <span>$500</span>
                <span>$2,500</span>
                <span>$5,000 Max</span>
              </div>
            </div>

          </div>

          {/* Security Features Checkpoints */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-[#111E33]/60 p-3.5 rounded-xl border border-white/5 space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-white">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Zero-Liability Guarantee
              </div>
              <p className="text-[11px] text-[#7C8AA8]">
                Protected against unauthorized purchases with immediate reimbursement via Stripe.
              </p>
            </div>

            <div className="bg-[#111E33]/60 p-3.5 rounded-xl border border-white/5 space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-white">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                International Roaming
              </div>
              <p className="text-[11px] text-[#7C8AA8]">
                Accepted across 190+ countries with zero foreign transaction exchange fees.
              </p>
            </div>

            <div className="bg-[#111E33]/60 p-3.5 rounded-xl border border-white/5 space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-white">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Real-Time SMS Alerts
              </div>
              <p className="text-[11px] text-[#7C8AA8]">
                Instant notification whenever brand milestone payments deposit or card swipes occur.
              </p>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => {
                if (onTriggerNotification) {
                  onTriggerNotification("Card Security Limits Saved", `Online limit set to $${onlineSpendLimit.toLocaleString()} and ATM limit set to $${atmLimit.toLocaleString()}.`, "success");
                }
              }}
              className="bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] text-xs font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer"
            >
              Save Card Security Preferences
            </button>
          </div>
        </div>
      )}

      {/* =========================================================================
          APPLE WALLET & GOOGLE PAY PASS PROVISIONING MODAL
         ========================================================================= */}
      {showAppleWalletModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-[#0b1628] border border-[#C9A46A]/40 rounded-3xl max-w-md w-full p-6 space-y-6 shadow-2xl relative overflow-hidden">
            {/* Modal Ambient Glow */}
            <div className="absolute top-0 right-0 w-40 h-40 bg-[#C9A46A]/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4 relative z-10">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-black border border-white/20 flex items-center justify-center">
                  <Smartphone className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-base leading-tight">Apple Wallet &amp; Apple Pay</h4>
                  <p className="text-[11px] text-[#7C8AA8]">Digital Pass &bull; Stripe Issuing Token</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAppleWalletModal(false)}
                className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Apple Wallet Pass Visual Preview */}
            <div className="space-y-3 relative z-10">
              <div className="bg-gradient-to-br from-[#060a12] via-[#0e172a] to-[#15233d] border border-[#C9A46A]/50 rounded-2xl p-4.5 text-white shadow-xl relative overflow-hidden space-y-3.5">
                {/* Top Pass Row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded bg-black/60 border border-[#C9A46A]/60 flex items-center justify-center">
                      <Sparkles className="w-3 h-3 text-[#C9A46A]" />
                    </div>
                    <span className="text-xs font-serif font-bold text-white tracking-wider">Bloom &amp; Co.</span>
                  </div>
                  <span className="text-[9px] font-mono font-bold bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30 px-2 py-0.5 rounded-full">
                    APPLE WALLET PASS
                  </span>
                </div>

                {/* Balance & Cardholder */}
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/10">
                  <div>
                    <span className="text-[8px] uppercase tracking-wider text-[#7C8AA8] font-mono block">Available Balance</span>
                    <span className="text-lg font-bold text-emerald-400 font-mono">${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[8px] uppercase tracking-wider text-[#7C8AA8] font-mono block">Cardholder</span>
                    <span className="text-xs font-bold text-white font-mono uppercase truncate block">{displayName}</span>
                  </div>
                </div>

                {/* Card Number & Contactless Wave */}
                <div className="flex items-center justify-between pt-1">
                  <div className="font-mono text-xs text-slate-300 tracking-widest font-semibold">
                    •••• •••• •••• <span className="text-[#C9A46A]">{effectiveLast4}</span>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                    <span>NFC Ready</span>
                    <Zap className="w-3 h-3 text-emerald-400" />
                  </div>
                </div>

                {/* Apple Wallet Barcode / QR Simulation */}
                <div className="bg-white rounded-xl p-2.5 flex flex-col items-center justify-center shadow-inner gap-1">
                  <div className="w-32 h-32 bg-white flex items-center justify-center p-1 border border-slate-200 rounded-lg">
                    {/* SVG Stylized QR Code */}
                    <svg viewBox="0 0 100 100" className="w-full h-full text-slate-950" fill="currentColor">
                      <rect x="0" y="0" width="30" height="30" rx="3" />
                      <rect x="5" y="5" width="20" height="20" fill="white" />
                      <rect x="9" y="9" width="12" height="12" />
                      
                      <rect x="70" y="0" width="30" height="30" rx="3" />
                      <rect x="75" y="5" width="20" height="20" fill="white" />
                      <rect x="79" y="79" width="12" height="12" />
                      
                      <rect x="0" y="70" width="30" height="30" rx="3" />
                      <rect x="5" y="75" width="20" height="20" fill="white" />
                      <rect x="9" y="79" width="12" height="12" />

                      <rect x="40" y="10" width="20" height="10" />
                      <rect x="10" y="40" width="10" height="20" />
                      <rect x="40" y="40" width="20" height="20" />
                      <rect x="70" y="40" width="20" height="10" />
                      <rect x="40" y="70" width="10" height="20" />
                      <rect x="60" y="65" width="30" height="10" />
                      <rect x="70" y="70" width="30" height="30" rx="3" fill="transparent" />
                    </svg>
                  </div>
                  <span className="text-[9px] font-mono text-slate-600 font-bold tracking-widest">
                    PKPASS-BLOOM-{effectiveLast4}
                  </span>
                </div>
              </div>

              {/* Instructions Guide */}
              <div className="bg-[#111E33] border border-white/5 rounded-xl p-3.5 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-[11px]">
                  <CheckCircle2 className="w-4 h-4" /> Ready for Instant Contactless Pay
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Tap the button below to download the official <strong>.pkpass</strong> file for iOS Apple Wallet, or scan the QR code using your iPhone camera to instantly add your Bloom &amp; Co. card.
                </p>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="space-y-2 relative z-10">
              <button
                type="button"
                onClick={handleDownloadApplePass}
                className="w-full bg-black hover:bg-zinc-900 border border-white/20 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
              >
                <Download className="w-4 h-4 text-[#C9A46A]" />
                <span>Download Apple Wallet Pass (.pkpass)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowAppleWalletModal(false);
                  if (onTriggerNotification) {
                    onTriggerNotification("Apple Pay Active", "Your card is active and ready for in-store & online Apple Pay transactions.", "success");
                  }
                }}
                className="w-full bg-[#16243F] hover:bg-[#1f3050] text-slate-300 hover:text-white py-2 px-4 rounded-xl text-xs font-semibold transition-colors cursor-pointer text-center"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
