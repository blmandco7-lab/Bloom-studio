/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { AlertTriangle, Trash2, X, ShieldAlert, RotateCcw, AlertOctagon } from 'lucide-react';

export interface DeleteConfirmConfig {
  isOpen: boolean;
  title: string;
  itemName?: string;
  itemType?: string;
  isPermanent?: boolean;
  message?: string;
  confirmButtonText?: string;
  confirmButtonVariant?: 'danger' | 'warning';
  onConfirm: () => void;
}

interface DeleteConfirmationModalProps {
  config: DeleteConfirmConfig | null;
  onClose: () => void;
  primaryBrandColor?: string;
}

export const DeleteConfirmationModal: React.FC<DeleteConfirmationModalProps> = ({
  config,
  onClose,
  primaryBrandColor = '#C9A46A'
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!config?.isOpen) return;
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [config?.isOpen, onClose]);

  if (!config || !config.isOpen) return null;

  const isPermanent = !!config.isPermanent;
  const itemType = config.itemType || 'item';
  const confirmText = config.confirmButtonText || (isPermanent ? 'Purge Permanently' : 'Move to Trash');

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-md bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-2xl overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top accent bar */}
        <div 
          className={`absolute top-0 left-0 right-0 h-1.5 ${
            isPermanent ? 'bg-gradient-to-r from-rose-600 via-red-500 to-rose-600' : 'bg-gradient-to-r from-amber-500 via-rose-500 to-amber-500'
          }`} 
        />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
          aria-label="Cancel and close dialog"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header with Icon */}
        <div className="flex items-start gap-4 mb-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
            isPermanent 
              ? 'bg-rose-500/15 border border-rose-500/30 text-rose-400' 
              : 'bg-amber-500/15 border border-amber-500/30 text-amber-400'
          }`}>
            {isPermanent ? (
              <AlertOctagon className="w-6 h-6 animate-pulse" />
            ) : (
              <Trash2 className="w-6 h-6" />
            )}
          </div>

          <div className="space-y-1 pr-6">
            <h3 className="text-lg font-bold text-white font-sans tracking-tight">
              {config.title || (isPermanent ? 'Confirm Permanent Deletion' : 'Confirm Move to Trash')}
            </h3>
            <span className={`inline-block text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
              isPermanent
                ? 'bg-rose-950/60 text-rose-300 border border-rose-500/40'
                : 'bg-amber-950/60 text-amber-300 border border-amber-500/40'
            }`}>
              {isPermanent ? 'Permanent Destruction' : '30-Day Safe Recoverable'}
            </span>
          </div>
        </div>

        {/* Target Item Pill (if provided) */}
        {config.itemName && (
          <div className="mb-4 p-3 rounded-xl bg-[#081220] border border-white/10 flex items-center justify-between gap-3">
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-mono text-slate-400 block uppercase tracking-wider">
                Target {itemType.toUpperCase()}
              </span>
              <p className="text-sm font-semibold text-white truncate">
                {config.itemName}
              </p>
            </div>
            <div className="text-right shrink-0">
              <span className="text-[11px] font-mono text-[#C9A46A] capitalize">
                {itemType}
              </span>
            </div>
          </div>
        )}

        {/* Informational Warning Box */}
        <div className="mb-6 space-y-3">
          <p className="text-xs text-slate-300 leading-relaxed">
            {config.message || (
              isPermanent
                ? `Are you sure you want to permanently delete this ${itemType}? This action cannot be reversed, and all associated logs, files, and links will be completely removed.`
                : `Are you sure you want to delete this ${itemType}? It will be relocated to the Recoup Trash Bin where it will remain recoverable for 30 days before auto-purge.`
            )}
          </p>

          {!isPermanent && (
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-500/20 text-[11px] text-emerald-300">
              <RotateCcw className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>You can restore this item anytime from the <strong>Recoup Trash Bin</strong>.</span>
            </div>
          )}
        </div>

        {/* Actions Footer */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-white/5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-[#111E33] hover:bg-[#16243F] border border-white/10 transition-colors cursor-pointer"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={() => {
              config.onConfirm();
              onClose();
            }}
            className={`px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-lg cursor-pointer flex items-center gap-1.5 ${
              isPermanent
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/30'
                : 'bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/40 shadow-rose-950/20'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{confirmText}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteConfirmationModal;
