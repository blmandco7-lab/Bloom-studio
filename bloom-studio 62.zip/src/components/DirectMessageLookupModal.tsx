/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Search, 
  X, 
  MessageSquare, 
  Lock, 
  ShieldCheck, 
  User, 
  Users, 
  Sparkles, 
  Send, 
  Check, 
  Building2, 
  ArrowRight,
  ShieldAlert,
  Smartphone
} from 'lucide-react';
import { Role, Creator, Deal } from '../types';
import { getRecipientsForRole, isAllowedToMessage, DirectoryPerson } from '../lib/messagingRules';

interface DirectMessageLookupModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: Role;
  currentUser: any;
  creators: Creator[];
  deals: Deal[];
  campaigns?: any[];
  onSendDirectMessage: (recipientName: string, recipientRole: string, messageText: string, recipientHandle?: string) => void;
  onOpenThreadInChat?: (recipientName: string, recipientRole: string) => void;
}

export const DirectMessageLookupModal: React.FC<DirectMessageLookupModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  currentUser,
  creators,
  deals,
  campaigns = [],
  onSendDirectMessage,
  onOpenThreadInChat
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'creators' | 'team' | 'brands'>('all');
  const [selectedPerson, setSelectedPerson] = useState<DirectoryPerson | null>(null);
  const [messageText, setMessageText] = useState('');
  const [sendSmsAlso, setSendSmsAlso] = useState(true);
  const [isSentSuccess, setIsSentSuccess] = useState(false);

  // Retrieve authorized recipients
  const authorizedRecipients = useMemo(() => {
    return getRecipientsForRole(currentRole, currentUser, creators, deals, campaigns);
  }, [currentRole, currentUser, creators, deals, campaigns]);

  // Filter list based on search and category tab
  const filteredPeople = useMemo(() => {
    let list = authorizedRecipients;

    // Exclude broadcast group channels from 1-on-1 direct message lookup
    list = list.filter(p => {
      const roleLower = (p.role || '').toLowerCase();
      const nameLower = (p.name || '').toLowerCase();
      return !roleLower.includes('broadcast') && !nameLower.includes('broadcast') && !nameLower.includes('everyone');
    });

    if (selectedFilter === 'creators') {
      list = list.filter(p => (p.role || '').toLowerCase().includes('creator') || p.handle?.startsWith('@'));
    } else if (selectedFilter === 'team') {
      list = list.filter(p => {
        const r = (p.role || '').toLowerCase();
        return r.includes('director') || r.includes('agent') || r.includes('manager') || r.includes('coordinator') || r.includes('staff');
      });
    } else if (selectedFilter === 'brands') {
      list = list.filter(p => (p.role || '').toLowerCase().includes('brand'));
    }

    if (!searchQuery.trim()) return list;

    const q = searchQuery.toLowerCase().trim();
    return list.filter(p => 
      p.name.toLowerCase().includes(q) || 
      (p.handle && p.handle.toLowerCase().includes(q)) || 
      p.role.toLowerCase().includes(q) ||
      (p.category && p.category.toLowerCase().includes(q)) ||
      (p.relationshipNote && p.relationshipNote.toLowerCase().includes(q))
    );
  }, [authorizedRecipients, selectedFilter, searchQuery]);

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPerson || !messageText.trim()) return;

    onSendDirectMessage(
      selectedPerson.name,
      selectedPerson.role,
      messageText.trim(),
      selectedPerson.handle
    );

    setIsSentSuccess(true);
    setTimeout(() => {
      setIsSentSuccess(false);
      setMessageText('');
      setSelectedPerson(null);
      onClose();
    }, 1200);
  };

  const getRoleBadgeColor = (roleStr: string) => {
    const r = roleStr.toLowerCase();
    if (r.includes('director')) return 'bg-amber-500/10 text-amber-300 border-amber-500/30';
    if (r.includes('manager')) return 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30';
    if (r.includes('agent')) return 'bg-purple-500/10 text-purple-300 border-purple-500/30';
    if (r.includes('coordinator')) return 'bg-sky-500/10 text-sky-300 border-sky-500/30';
    if (r.includes('brand')) return 'bg-rose-500/10 text-rose-300 border-rose-500/30';
    return 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30';
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in font-sans">
      <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#111E33]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#C9A46A]/10 border border-[#C9A46A]/30 flex items-center justify-center text-[#C9A46A]">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Direct Message Lookup
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold inline-flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Private 1-on-1
                </span>
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Look up any creator, agent, or staff member to send a private direct message visible only to them.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/5 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Category Filter */}
        <div className="p-4 border-b border-white/5 bg-[#0D1830] space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              autoFocus
              placeholder="Search by name, @handle, role, or talent team..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 outline-none focus:border-[#C9A46A] transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFilter === 'all'
                  ? 'bg-[#C9A46A] text-[#0A1220]'
                  : 'bg-[#111E33] text-slate-300 hover:bg-[#16243F] border border-white/5'
              }`}
            >
              All Directory ({authorizedRecipients.filter(p => !p.name.toLowerCase().includes('broadcast')).length})
            </button>
            <button
              onClick={() => setSelectedFilter('creators')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFilter === 'creators'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-[#111E33] text-slate-300 hover:bg-[#16243F] border border-white/5'
              }`}
            >
              ⭐ Creators ({creators.length})
            </button>
            <button
              onClick={() => setSelectedFilter('team')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFilter === 'team'
                  ? 'bg-indigo-500 text-white'
                  : 'bg-[#111E33] text-slate-300 hover:bg-[#16243F] border border-white/5'
              }`}
            >
              👥 Team &amp; Agents
            </button>
            <button
              onClick={() => setSelectedFilter('brands')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFilter === 'brands'
                  ? 'bg-rose-500 text-white'
                  : 'bg-[#111E33] text-slate-300 hover:bg-[#16243F] border border-white/5'
              }`}
            >
              🏢 Brands
            </button>
          </div>
        </div>

        {/* Content Body: Two columns if person selected, or list */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {!selectedPerson ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 uppercase tracking-wider px-1 pb-1">
                <span>Select recipient to start private chat</span>
                <span>{filteredPeople.length} contacts available</span>
              </div>

              {filteredPeople.length === 0 ? (
                <div className="text-center py-10 bg-[#111E33]/50 rounded-xl border border-white/5 space-y-2">
                  <User className="w-8 h-8 text-slate-500 mx-auto" />
                  <p className="text-xs text-slate-300 font-semibold">No matching recipients found</p>
                  <p className="text-[11px] text-slate-500">Try searching for a different name, handle, or role category.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {filteredPeople.map((person, idx) => (
                    <div
                      key={idx}
                      onClick={() => setSelectedPerson(person)}
                      className="p-3 bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl transition cursor-pointer flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center text-sm font-bold text-white shrink-0 group-hover:border-[#C9A46A]/50 transition">
                          {person.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <h4 className="text-xs font-bold text-white truncate group-hover:text-[#C9A46A] transition">
                              {person.name}
                            </h4>
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" title="Active" />
                          </div>
                          {person.handle && (
                            <p className="text-[11px] font-mono text-[#C9A46A] truncate">
                              {person.handle}
                            </p>
                          )}
                          <span className={`inline-block mt-1 text-[9px] font-mono px-1.5 py-0.5 rounded border ${getRoleBadgeColor(person.role)}`}>
                            {person.role}
                          </span>
                        </div>
                      </div>

                      <div className="shrink-0 text-slate-500 group-hover:text-[#C9A46A] group-hover:translate-x-0.5 transition">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            /* Selected Person Composer */
            <form onSubmit={handleSend} className="space-y-4">
              {/* Recipient Profile Card */}
              <div className="p-3.5 bg-[#111E33] border border-[#C9A46A]/30 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-slate-800 border border-[#C9A46A]/40 flex items-center justify-center text-sm font-bold text-[#C9A46A]">
                    {selectedPerson.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white">{selectedPerson.name}</h4>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${getRoleBadgeColor(selectedPerson.role)}`}>
                        {selectedPerson.role}
                      </span>
                    </div>
                    {selectedPerson.handle && (
                      <p className="text-xs font-mono text-[#C9A46A]">{selectedPerson.handle}</p>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedPerson(null)}
                  className="text-xs text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 transition cursor-pointer"
                >
                  Change User
                </button>
              </div>

              {/* Isolation Security Notice */}
              <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-xl flex items-start gap-2.5 text-xs text-emerald-300">
                <Lock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Encrypted Direct Message:</strong> This conversation is private between you and <strong>{selectedPerson.name}</strong>. Outside talent, other brands, and unrelated agents cannot access this feed.
                </div>
              </div>

              {/* Message Composer */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono text-slate-400 uppercase">
                  Message to {selectedPerson.name}
                </label>
                <textarea
                  rows={4}
                  required
                  autoFocus
                  placeholder={`Write your direct message to ${selectedPerson.name}...`}
                  value={messageText}
                  onChange={e => setMessageText(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-[#C9A46A] resize-none"
                />
              </div>

              {/* Checkbox for simulated SMS alert */}
              <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={sendSmsAlso}
                  onChange={e => setSendSmsAlso(e.target.checked)}
                  className="rounded border-white/20 text-[#C9A46A] focus:ring-0 bg-[#111E33]"
                />
                <span className="flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-[#C9A46A]" />
                  Simulate instant SMS notification to {selectedPerson.name}'s mobile device
                </span>
              </label>

              {/* Submit Buttons */}
              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedPerson(null)}
                  className="px-4 py-2.5 rounded-xl bg-[#111E33] hover:bg-[#16243F] text-slate-300 text-xs font-semibold transition cursor-pointer border border-white/5"
                >
                  Back to List
                </button>
                
                {onOpenThreadInChat && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenThreadInChat(selectedPerson.name, selectedPerson.role);
                      onClose();
                    }}
                    className="px-4 py-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold transition cursor-pointer"
                  >
                    Open in Full Chat
                  </button>
                )}

                <button
                  type="submit"
                  disabled={!messageText.trim() || isSentSuccess}
                  className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                    isSentSuccess
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220]'
                  }`}
                >
                  {isSentSuccess ? (
                    <>
                      <Check className="w-4 h-4" /> Message Dispatched Privately!
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" /> Send Direct Message
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-white/5 bg-[#111E33] flex items-center justify-between text-[11px] text-slate-400">
          <span className="font-mono">🔒 Confidential Agency Messaging Mesh</span>
          <span>Tip: Press ESC or click outside to close</span>
        </div>

      </div>
    </div>
  );
};
