import React, { useState } from 'react';
import { 
  Archive, 
  Video, 
  Download, 
  FileText, 
  CheckCircle2, 
  Calendar, 
  ShieldCheck, 
  Sparkles, 
  ExternalLink,
  Search,
  Filter,
  Layers,
  Copy,
  Check
} from 'lucide-react';
import { downloadCopyrightClearancePDF } from '../utils/pdfExportUtils';
import { getSafeUrl } from '../utils/security';

export interface HistoricalCampaignItem {
  id: string;
  campaignTitle: string;
  creatorHandle: string;
  creatorName: string;
  niche: 'Beauty' | 'Pets' | 'Lifestyle' | string;
  completionDate: string;
  totalViews: string;
  engagementRate: string;
  ugcAssetCount: number;
  finalVideoUrl: string;
  rawBrollZipUrl?: string;
  clearanceCertificateId: string;
  isActive: boolean;
}

interface HistoricalCampaignVaultProps {
  brandName?: string;
  campaigns?: HistoricalCampaignItem[];
  className?: string;
}

const DEFAULT_HISTORICAL_CAMPAIGNS: HistoricalCampaignItem[] = [
  {
    id: "camp_hist_001",
    campaignTitle: "Lumina Peptide Glow Q1 Master Campaign",
    creatorHandle: "@elenarostova",
    creatorName: "Elena Rostova",
    niche: "Beauty",
    completionDate: "2026-06-15",
    totalViews: "428,900",
    engagementRate: "6.2%",
    ugcAssetCount: 4,
    finalVideoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    rawBrollZipUrl: "https://bloomstudio.agency/vault/downloads/broll_lumina_glow_4k.zip",
    clearanceCertificateId: "BSM-CR-89A4B29E",
    isActive: false
  },
  {
    id: "camp_hist_002",
    campaignTitle: "PureHydrate Mineral Dew Launch",
    creatorHandle: "@chloe_aesthetics",
    creatorName: "Chloe Davenport",
    niche: "Beauty",
    completionDate: "2026-05-20",
    totalViews: "312,400",
    engagementRate: "5.4%",
    ugcAssetCount: 3,
    finalVideoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    rawBrollZipUrl: "https://bloomstudio.agency/vault/downloads/broll_purehydrate_4k.zip",
    clearanceCertificateId: "BSM-CR-77D1F44C",
    isActive: false
  },
  {
    id: "camp_hist_003",
    campaignTitle: "Nordic Minimalist Morning Routine UGC",
    creatorHandle: "@kai_lifestyle",
    creatorName: "Kai Lindqvist",
    niche: "Lifestyle",
    completionDate: "2026-04-10",
    totalViews: "580,200",
    engagementRate: "7.1%",
    ugcAssetCount: 5,
    finalVideoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    rawBrollZipUrl: "https://bloomstudio.agency/vault/downloads/broll_nordic_morning_4k.zip",
    clearanceCertificateId: "BSM-CR-55B9E11A",
    isActive: false
  }
];

export default function HistoricalCampaignVault({
  brandName = "Lumina Cosmetics LLC",
  campaigns = DEFAULT_HISTORICAL_CAMPAIGNS,
  className = ""
}: HistoricalCampaignVaultProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedNiche, setSelectedNiche] = useState<string>("all");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Security Filter: Strictly list campaigns where status is inactive / completed
  const filteredCampaigns = campaigns
    .filter(c => c.isActive === false)
    .filter(c => {
      const matchSearch = c.campaignTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.creatorHandle.toLowerCase().includes(searchQuery.toLowerCase());
      const matchNiche = selectedNiche === "all" || c.niche.toLowerCase() === selectedNiche.toLowerCase();
      return matchSearch && matchNiche;
    });

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleDownloadCertificate = async (item: HistoricalCampaignItem) => {
    await downloadCopyrightClearancePDF({
      campaignName: item.campaignTitle,
      brandName: brandName,
      creatorHandle: item.creatorHandle,
      creatorLegalName: item.creatorName,
      creatorRightsPayout: 1500, // Masked standalone parameter for legal certificate wording only
      verificationHash: item.clearanceCertificateId,
      effectiveDate: new Date(item.completionDate).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
    });
  };

  return (
    <div className={`w-full bg-agency-navy font-sans text-agency-textLight space-y-6 animate-fadeIn ${className}`}>
      {/* Header Banner */}
      <div className="bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase tracking-widest">
            <Archive className="w-4 h-4" />
            <span>Permanent Compliance & Asset Repository</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-white mt-1">
            Historical Campaign Vault
          </h2>
          <p className="text-xs text-slate-300 font-mono mt-1">
            Archived production timelines, finalized 4K master files, and immutable legal certificates.
          </p>
        </div>

        {/* Search & Filter Tools */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search historical campaigns..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-agency-navy border border-white/10 rounded-xl pl-9 pr-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-agency-gold"
            />
          </div>

          <div className="flex items-center gap-1.5 bg-agency-navy border border-white/10 rounded-xl p-1">
            {['all', 'Beauty', 'Pets', 'Lifestyle'].map((niche) => (
              <button
                key={niche}
                type="button"
                onClick={() => setSelectedNiche(niche)}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-mono uppercase font-bold transition cursor-pointer ${
                  selectedNiche === niche
                    ? 'bg-agency-gold text-agency-navy shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {niche}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Safety Notice Badge */}
      <div className="bg-emerald-500/10 border border-emerald-400/30 rounded-2xl p-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-300 block">
              Direct Enterprise Client Silo Active
            </span>
            <span className="text-[11px] text-slate-300 font-sans">
              All deliverables below include full perpetual commercial whitelisting & FTC endorsement clearance.
            </span>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-[10px] font-mono text-slate-400">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          <span>Status: Archived (isActive: false)</span>
        </div>
      </div>

      {/* Structured Grid Cards */}
      {filteredCampaigns.length === 0 ? (
        <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-12 text-center space-y-3">
          <Archive className="w-10 h-10 text-slate-500 mx-auto" />
          <h3 className="text-base font-serif font-bold text-white">No Historical Campaigns Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Completed campaigns will automatically archive to this vault once final assets are delivered and approved.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredCampaigns.map((item) => (
            <div 
              key={item.id}
              className="bg-agency-navyLight border border-agency-gold/20 hover:border-agency-gold/50 transition duration-300 rounded-3xl p-6 shadow-xl flex flex-col justify-between space-y-5 relative overflow-hidden group"
            >
              {/* Card Top Details */}
              <div>
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <span className="bg-agency-gold/15 text-agency-gold text-[10px] font-mono uppercase font-bold px-2.5 py-1 rounded-lg border border-agency-gold/30 inline-block mb-2">
                      {item.niche} Vertical
                    </span>
                    <h3 className="text-lg font-serif font-bold text-white group-hover:text-agency-gold transition">
                      {item.campaignTitle}
                    </h3>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400 bg-agency-navy px-2.5 py-1 rounded-lg border border-white/10 shrink-0">
                    <Calendar className="w-3.5 h-3.5 text-agency-gold" />
                    <span>Completed {item.completionDate}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-300 font-mono mb-4 pb-4 border-b border-white/10">
                  <span className="font-bold text-white">{item.creatorName}</span>
                  <span>({item.creatorHandle})</span>
                  <span>•</span>
                  <span className="text-agency-gold">{item.ugcAssetCount} Final 4K Deliverables</span>
                </div>

                {/* Campaign Analytics Metrics (Public/Brand Reach Only) */}
                <div className="grid grid-cols-2 gap-3 bg-agency-navy/90 border border-white/5 rounded-2xl p-3.5 mb-4">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
                      Total Audience Reach
                    </span>
                    <span className="text-sm font-mono font-bold text-white">
                      {item.totalViews} Views
                    </span>
                  </div>
                  <div className="border-l border-white/10 pl-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
                      Engagement Rate
                    </span>
                    <span className="text-sm font-mono font-bold text-emerald-400">
                      {item.engagementRate}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons & Download Shortcuts */}
              <div className="space-y-3 pt-2 border-t border-white/10">
                <div className="flex flex-col gap-2.5">
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
                    {/* Final Video MP4 Download */}
                    <a
                      href={getSafeUrl(item.finalVideoUrl)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-agency-gold text-agency-navy text-xs font-mono font-bold uppercase tracking-wider hover:brightness-110 transition shadow-md cursor-pointer"
                    >
                      <Video className="w-4 h-4 shrink-0" />
                      <span>Download 4K Master MP4</span>
                    </a>

                    {/* White Paper Copyright Clearance Certificate */}
                    <button
                      type="button"
                      onClick={() => handleDownloadCertificate(item)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-agency-navy border border-agency-gold/40 text-agency-gold text-xs font-mono font-bold uppercase tracking-wider hover:bg-agency-gold/10 transition cursor-pointer"
                    >
                      <FileText className="w-4 h-4 shrink-0" />
                      <span>Clearance Certificate (PDF)</span>
                    </button>
                  </div>

                  {/* Raw B-Roll ZIP Download */}
                  {item.rawBrollZipUrl && (
                    <a
                      href={getSafeUrl(item.rawBrollZipUrl)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 hover:bg-slate-700/80 hover:border-white/20 text-white text-xs font-mono font-bold uppercase tracking-wider transition cursor-pointer"
                    >
                      <Download className="w-4 h-4 shrink-0" />
                      <span>Download Raw B-Roll Assets (.zip)</span>
                    </a>
                  )}
                </div>

                {/* Direct Link & Token Info */}
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1">
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    <span>Token: {item.clearanceCertificateId}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleCopy(item.finalVideoUrl, item.id)}
                    className="flex items-center gap-1 text-slate-300 hover:text-white transition cursor-pointer"
                  >
                    {copiedId === item.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">URL Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy CDN Link</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
