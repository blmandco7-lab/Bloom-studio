import React, { useState } from 'react';
import { 
  Shield, Download, Trash2, Search, FileText, CheckCircle2, 
  AlertTriangle, Database, Lock, UserCheck, Eye, ShieldCheck, HelpCircle, ExternalLink 
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, getDocs, doc, deleteDoc, query, where } from 'firebase/firestore';
import PrivacyPolicyModal from './PrivacyPolicyModal';
import AccessibilityStatementModal from './AccessibilityStatementModal';

interface PrivacyComplianceCenterProps {
  currentUser?: any;
  currentRole?: string;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog: (user: string, role: string, action: string) => void;
}

export default function PrivacyComplianceCenter({
  currentUser,
  currentRole = 'none',
  triggerNotification,
  onAddActivityLog
}: PrivacyComplianceCenterProps) {
  const [searchTarget, setSearchTarget] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [showPrivacyPolicyModal, setShowPrivacyPolicyModal] = useState(false);
  const [showAccessibilityModal, setShowAccessibilityModal] = useState(false);
  const [foundRecords, setFoundRecords] = useState<{
    creatorDoc?: any;
    w9Form?: any;
    contracts: any[];
    activityLogs: any[];
    deals: any[];
  } | null>(null);


  const [confirmErasureOpen, setConfirmErasureOpen] = useState(false);
  const [erasureReason, setErasureReason] = useState('GDPR Article 17 / CCPA Data Subject Erasure Request');

  const handleSearchSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTarget.trim()) return;

    setIsSearching(true);
    try {
      const targetQuery = searchTarget.trim().toLowerCase();
      const currentTenantId = currentUser?.tenantId || 'bloom_studio_default';
      const currentSubagency = currentUser?.subagency || 'pod_main';
      const isPlatformOwner = currentUser?.isPlatformOwner === true;
      
      let creatorMatch = null;
      let w9Match = null;
      const matchedContracts: any[] = [];
      const matchedLogs: any[] = [];
      const matchedDeals: any[] = [];

      try {
        const creatorsQuery = isPlatformOwner
          ? collection(db, 'studio-creators')
          : query(collection(db, 'studio-creators'), where('subagency', '==', currentSubagency));
        const creatorsSnap = await getDocs(creatorsQuery);
        creatorsSnap.forEach(docSnap => {
          const c = docSnap.data();
          if (isPlatformOwner || c.tenantId === currentTenantId || c.subagency === currentSubagency) {
             if (
                (c.name && c.name.toLowerCase().includes(targetQuery)) ||
                (c.handle && c.handle.toLowerCase().includes(targetQuery)) ||
                (c.email && c.email.toLowerCase().includes(targetQuery))
             ) {
                creatorMatch = { id: docSnap.id, ...c };
             }
          }
        });
      } catch (e) { console.warn("Failed scanning creators", e); }

      try {
        const w9Query = isPlatformOwner
          ? collection(db, 'studio-w9-forms')
          : query(collection(db, 'studio-w9-forms'), where('subagency', '==', currentSubagency));
        const w9Snap = await getDocs(w9Query);
        w9Snap.forEach(docSnap => {
          const w = docSnap.data();
          if (isPlatformOwner || w.tenantId === currentTenantId || w.subagency === currentSubagency) {
             if (
                (w.creatorName && w.creatorName.toLowerCase().includes(targetQuery)) ||
                (w.email && w.email.toLowerCase().includes(targetQuery))
             ) {
                w9Match = { id: docSnap.id, ...w };
             }
          }
        });
      } catch (e) { console.warn("Failed scanning w9 forms", e); }

      try {
        const contractsQuery = isPlatformOwner
          ? collection(db, 'studio-contracts')
          : query(collection(db, 'studio-contracts'), where('subagency', '==', currentSubagency));
        const contractsSnap = await getDocs(contractsQuery);
        contractsSnap.forEach(docSnap => {
          const con = docSnap.data();
          if (isPlatformOwner || con.tenantId === currentTenantId || con.subagency === currentSubagency) {
             if (
                (con.creatorHandle && con.creatorHandle.toLowerCase().includes(targetQuery)) ||
                (con.title && con.title.toLowerCase().includes(targetQuery)) ||
                (con.partyName && con.partyName.toLowerCase().includes(targetQuery))
             ) {
                matchedContracts.push({ id: docSnap.id, ...con });
             }
          }
        });
      } catch (e) { console.warn("Failed scanning contracts", e); }

      try {
        const logsQuery = isPlatformOwner
          ? collection(db, 'studio-activity-log')
          : query(collection(db, 'studio-activity-log'), where('subagency', '==', currentSubagency));
        const logsSnap = await getDocs(logsQuery);
        logsSnap.forEach(docSnap => {
          const l = docSnap.data();
          if (isPlatformOwner || l.tenantId === currentTenantId || l.subagency === currentSubagency) {
             if (l.user && l.user.toLowerCase().includes(targetQuery)) {
                matchedLogs.push({ id: docSnap.id, ...l });
             }
          }
        });
      } catch (e) { console.warn("Failed scanning activity logs", e); }

      try {
        const dealsQuery = isPlatformOwner
          ? collection(db, 'studio-deals')
          : query(collection(db, 'studio-deals'), where('subagency', '==', currentSubagency));
        const dealsSnap = await getDocs(dealsQuery);
        dealsSnap.forEach(docSnap => {
          const d = docSnap.data();
          if (isPlatformOwner || d.tenantId === currentTenantId || d.subagency === currentSubagency) {
             if (
               (d.creator && d.creator.toLowerCase().includes(targetQuery)) ||
               (d.brand && d.brand.toLowerCase().includes(targetQuery)) ||
               (d.dealName && d.dealName.toLowerCase().includes(targetQuery))
             ) {
                matchedDeals.push({ id: docSnap.id, ...d });
             }
          }
        });
      } catch (e) { console.warn("Failed scanning deals", e); }

      setFoundRecords({
        creatorDoc: creatorMatch || null,
        w9Form: w9Match || null,
        contracts: matchedContracts,
        activityLogs: matchedLogs,
        deals: matchedDeals
      });

      onAddActivityLog(currentUser?.name || 'Director', currentRole, `Performed privacy subject search in Firestore for "${searchTarget}"`);
      triggerNotification('Subject Located', `Relational Firestore scan completed for ${searchTarget}.`, 'success');
    } catch (err) {
      triggerNotification('Search Failed', 'Unable to complete multi-collection compliance scan.', 'danger');
    } finally {
      setIsSearching(false);
    }
  };

  const handleExportDataPortability = () => {
    if (!foundRecords) return;
    const exportBundle = {
      exportTimestamp: new Date().toISOString(),
      regulation: 'GDPR Article 20 (Data Portability)',
      subjectQuery: searchTarget,
      records: foundRecords
    };

    const blob = new Blob([JSON.stringify(exportBundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `privacy-data-export-${searchTarget.replace(/[@\s]/g, '_')}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onAddActivityLog(currentUser?.name || 'Director', currentRole, `Exported GDPR Data Portability package for "${searchTarget}"`);
    triggerNotification('Export Complete', 'Machine-readable JSON data portability package downloaded.', 'success');
  };

  const executeRelationalErasure = async () => {
    if (!foundRecords) return;

    try {
      // 1. Delete Creator Profile
      if (foundRecords.creatorDoc?.id) {
        await deleteDoc(doc(db, 'studio-creators', foundRecords.creatorDoc.id));
      }
      
      // 2. Delete W9
      if (foundRecords.w9Form?.id) {
        await deleteDoc(doc(db, 'studio-w9-forms', foundRecords.w9Form.id));
      }
      
      // 3. Delete Contracts
      if (foundRecords.contracts && foundRecords.contracts.length > 0) {
        for (const con of foundRecords.contracts) {
          if (con.id) {
            await deleteDoc(doc(db, 'studio-contracts', con.id));
          }
        }
      }
      
      // 4. Delete Deals
      if (foundRecords.deals && foundRecords.deals.length > 0) {
        for (const deal of foundRecords.deals) {
          if (deal.id) {
            await deleteDoc(doc(db, 'studio-deals', deal.id));
          }
        }
      }
      
      // 5. Delete Activity Logs
      if (foundRecords.activityLogs && foundRecords.activityLogs.length > 0) {
        for (const al of foundRecords.activityLogs) {
          if (al.id) {
            await deleteDoc(doc(db, 'studio-activity-log', al.id));
          }
        }
      }

      onAddActivityLog(currentUser?.name || 'Director', currentRole, `Executed GDPR Article 17 Relational Erasure in Firestore for "${searchTarget}". Reason: ${erasureReason}`);
      triggerNotification('Erasure Executed', `All discoverable PII records for ${searchTarget} have been permanently deleted from Firestore.`, 'success');
      setFoundRecords(null);
      setSearchTarget('');
      setConfirmErasureOpen(false);
    } catch (e) {
      triggerNotification('Erasure Error', 'Failed to complete cascading deletion across Firestore collections.', 'danger');
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-[#1E2D4A] p-6 rounded-2xl shadow-xl">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Shield className="w-6 h-6" aria-hidden="true" />
            </div>
            <h1 className="text-xl font-bold text-white tracking-tight">Privacy &amp; Data Compliance Center</h1>
          </div>
          <p className="text-xs text-gray-400 max-w-2xl leading-relaxed">
            Manage data subject rights (GDPR Articles 15, 17, and 20 / CCPA). Perform relational cross-collection data discovery, machine-readable JSON portability exports, and cascading PII erasure.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowPrivacyPolicyModal(true)}
            className="px-3.5 py-2 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition"
            title="Read Complete Privacy Policy"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Master Privacy Policy</span>
          </button>
          <button
            onClick={() => setShowAccessibilityModal(true)}
            className="px-3.5 py-2 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition"
            title="Read WCAG 2.1 AA Accessibility Statement"
          >
            <Eye className="w-3.5 h-3.5 text-blue-400" />
            <span>Accessibility (WCAG 2.1 AA)</span>
          </button>
          <span className="px-3 py-1.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-medium rounded-xl flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" /> Engine Active
          </span>
        </div>
      </div>

      {/* Search Subject Card */}
      <div className="bg-[#0D1830] border border-[#1E2D4A] p-6 rounded-2xl shadow-xl">
        <h2 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
          <Search className="w-4 h-4 text-indigo-400" aria-hidden="true" /> Data Subject Lookup (Relational Cascade Engine)
        </h2>
        <form onSubmit={handleSearchSubject} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <label htmlFor="privacy-search-target" className="sr-only">Data Subject Handle, Email, or Full Legal Name</label>
            <input
              id="privacy-search-target"
              type="text"
              value={searchTarget}
              onChange={(e) => setSearchTarget(e.target.value)}
              placeholder="Enter creator handle (e.g. @sarah_beauty), email, or full name..."
              aria-label="Enter creator handle, email, or full name"
              className="w-full bg-[#14223E] border border-[#233559] rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>
          <button
            type="submit"
            disabled={isSearching || !searchTarget.trim()}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors shadow-lg shadow-indigo-600/20"
          >
            {isSearching ? 'Scanning Collections...' : 'Scan & Inspect Records'}
          </button>
        </form>
      </div>

      {/* Inspection Results */}
      {foundRecords && (
        <div className="bg-[#0D1830] border border-[#1E2D4A] p-6 rounded-2xl shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-[#1E2D4A] pb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Subject Inspection Results: <span className="text-indigo-400">{searchTarget}</span></h3>
              <p className="text-[11px] text-gray-400 mt-0.5">Identified records across roster, tax vaults, contracts, and activity ledgers.</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handleExportDataPortability}
                className="px-4 py-2 bg-[#14223E] hover:bg-[#1E2D4A] border border-[#233559] text-gray-200 font-semibold text-xs rounded-xl flex items-center gap-2 transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-indigo-400" /> Export JSON (Art. 20)
              </button>
              <button
                onClick={() => setConfirmErasureOpen(true)}
                className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 font-semibold text-xs rounded-xl flex items-center gap-2 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Request Erasure (Art. 17)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#14223E]/60 border border-[#233559] p-4 rounded-xl">
              <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Roster Profile (`studio-creators`)</div>
              <div className="text-sm font-bold text-white">{foundRecords.creatorDoc?.name || 'N/A'}</div>
              <div className="text-xs text-indigo-300 font-mono mt-0.5">{foundRecords.creatorDoc?.handle || searchTarget}</div>
              <div className="text-[11px] text-emerald-400 mt-2 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Status: {foundRecords.creatorDoc?.status || 'Active'}
              </div>
            </div>

            <div className="bg-[#14223E]/60 border border-[#233559] p-4 rounded-xl">
              <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Tax Vault (`studio-w9-forms`)</div>
              <div className="text-sm font-bold text-white">{foundRecords.w9Form ? 'W-9 Form Verified' : 'No Tax Form on File'}</div>
              <div className="text-xs text-gray-400 mt-0.5">{foundRecords.w9Form?.taxClassification || 'Standard Contractor'}</div>
              <div className="text-[11px] text-amber-400 mt-2 flex items-center gap-1">
                <Lock className="w-3 h-3" /> IRS Statutory Retention Hold
              </div>
            </div>

            <div className="bg-[#14223E]/60 border border-[#233559] p-4 rounded-xl">
              <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">Contracts &amp; Logs</div>
              <div className="text-sm font-bold text-white">{foundRecords.contracts.length} Contracts, {foundRecords.activityLogs.length} Logs</div>
              <div className="text-xs text-gray-400 mt-0.5">Relational references found</div>
              <div className="text-[11px] text-indigo-300 mt-2 flex items-center gap-1">
                <Database className="w-3 h-3" /> Cascade ready
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Erasure */}
      {confirmErasureOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm animate-fade-in p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="erasure-confirm-title"
        >
          <div className="w-full max-w-lg bg-[#0D1830] border border-red-500/30 p-6 rounded-2xl shadow-2xl space-y-5 text-left">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-red-500/10 text-red-500 rounded-xl">
                <AlertTriangle className="w-6 h-6" aria-hidden="true" />
              </div>
              <div>
                <h3 id="erasure-confirm-title" className="text-base font-bold text-white">Confirm GDPR Article 17 Relational Erasure</h3>
                <p className="text-xs text-red-300">This action will cascade and purge PII across all studio collections.</p>
              </div>
            </div>

            <div className="space-y-3">
              <label htmlFor="erasure-reason-input" className="block text-xs font-medium text-gray-300">Legal Justification / Request Reason:</label>
              <input
                id="erasure-reason-input"
                type="text"
                value={erasureReason}
                onChange={(e) => setErasureReason(e.target.value)}
                className="w-full bg-[#14223E] border border-[#233559] rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-red-500"
              />
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Note: Financial tax records subject to statutory IRS retention windows will be pseudonymized rather than permanently destroyed, satisfying legal hold requirements.
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-2 border-t border-[#1E2D4A]">
              <button
                onClick={() => setConfirmErasureOpen(false)}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold text-xs rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={executeRelationalErasure}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-semibold text-xs rounded-xl transition-colors shadow-lg shadow-red-600/20"
              >
                Confirm &amp; Execute Cascade Erasure
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Embedded Modals */}
      <PrivacyPolicyModal
        isOpen={showPrivacyPolicyModal}
        onClose={() => setShowPrivacyPolicyModal(false)}
        triggerNotification={triggerNotification}
      />

      <AccessibilityStatementModal
        isOpen={showAccessibilityModal}
        onClose={() => setShowAccessibilityModal(false)}
        triggerNotification={triggerNotification}
      />
    </div>
  );
}
