import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Clock,
  AlertTriangle,
  Filter,
  Trash2,
  CheckCircle,
  XCircle,
  Sparkles,
  Users,
  Search,
  Check,
  Lock,
  Sun,
  Plane,
  ShieldCheck,
  Tag
} from 'lucide-react';
import { Creator, Role } from '../types';

export interface AvailabilityEntry {
  id: string;
  creator: string;
  creatorHandle?: string;
  creatorName?: string;
  type: 'availability' | 'blockout' | 'vacation' | 'booking_hold';
  status: 'Available' | 'Limited' | 'Booked' | 'Blackout' | 'Vacation';
  date: string; // YYYY-MM-DD
  dayNum: number;
  month: number; // 0-11
  year: number;
  title: string;
  notes?: string;
  subagency?: string;
}

interface TalentAvailabilityCalendarProps {
  agencySchedules?: any[];
  setAgencySchedules?: React.Dispatch<React.SetStateAction<any[]>>;
  creators?: Creator[];
  currentRole?: Role | string;
  currentUser?: any;
  onAddActivityLog?: (actorName: string, actorRole: string, actionDetail: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'info' | 'warning' | 'success' | 'danger') => void;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onNavigateToScreen?: (screenId: string) => void;
  myHandles?: string[];
}

export const TalentAvailabilityCalendar: React.FC<TalentAvailabilityCalendarProps> = ({
  agencySchedules = [],
  setAgencySchedules,
  creators = [],
  currentRole = 'director',
  currentUser,
  onAddActivityLog,
  triggerNotification,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onNavigateToScreen,
  myHandles = []
}) => {
  const isCreator = (currentRole || '').toLowerCase() === 'creator';
  const isRestrictedRole = ['agentmgr', 'agent', 'coordinator'].includes((currentRole || '').toLowerCase());
  const myHandle = (currentUser?.handle || '').toLowerCase().replace('@', '');
  const myName = (currentUser?.name || '').toLowerCase();

  // Compute allowed creator handles for staff members
  const allowedCreatorHandles = useMemo(() => {
    if (!isRestrictedRole) return [];
    const fromCreators = (creators || []).map(c => (c.handle || '').toLowerCase());
    const fromMyHandles = (myHandles || []).map(h => (h || '').toLowerCase());
    const fromUser = (currentUser?.assignedCreators || currentUser?.assignedHandles || []).map((h: string) => h.toLowerCase());
    return Array.from(new Set([...fromCreators, ...fromMyHandles, ...fromUser]));
  }, [isRestrictedRole, creators, myHandles, currentUser]);

  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<number | null>(new Date().getDate());
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [creatorFilter, setCreatorFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Add Slot Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCreator, setNewCreator] = useState(isCreator ? (currentUser?.handle || '@creator') : (creators[0]?.handle || '@alexjones'));
  const [newTitle, setNewTitle] = useState('Available for Brand Shoots');
  const [newStatus, setNewStatus] = useState<'Available' | 'Limited' | 'Booked' | 'Blackout' | 'Vacation'>('Available');
  const [newDate, setNewDate] = useState(() => {
    const today = new Date();
    return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  });
  const [newNotes, setNewNotes] = useState('');

  const calendarYear = currentDate.getFullYear();
  const calendarMonthIndex = currentDate.getMonth();
  const calendarMonthName = currentDate.toLocaleString('default', { month: 'long' });

  // Default seed availability entries if none
  const defaultEntries: AvailabilityEntry[] = useMemo(() => {
    const y = new Date().getFullYear();
    const m = new Date().getMonth();
    return [
      {
        id: 'avail_seed_1',
        creator: '@alexjones',
        creatorHandle: '@alexjones',
        creatorName: 'Alex Jones',
        type: 'availability',
        status: 'Available',
        date: `${y}-${String(m + 1).padStart(2, '0')}-02`,
        dayNum: 2,
        month: m,
        year: y,
        title: '@alexjones • Full Day Shoot Availability',
        notes: 'Open for LA on-location or studio commercial filming.'
      },
      {
        id: 'avail_seed_2',
        creator: '@sophiaglows',
        creatorHandle: '@sophiaglows',
        creatorName: 'Sophia Chen',
        type: 'blockout',
        status: 'Blackout',
        date: `${y}-${String(m + 1).padStart(2, '0')}-06`,
        dayNum: 6,
        month: m,
        year: y,
        title: '@sophiaglows • University Exams Blackout',
        notes: 'Strict blackout day — no brand shoots.'
      },
      {
        id: 'avail_seed_3',
        creator: '@marcusfit',
        creatorHandle: '@marcusfit',
        creatorName: 'Marcus Miller',
        type: 'vacation',
        status: 'Vacation',
        date: `${y}-${String(m + 1).padStart(2, '0')}-12`,
        dayNum: 12,
        month: m,
        year: y,
        title: '@marcusfit • Traveling to Miami Fitness Expo',
        notes: 'Available for Miami on-site creator meetups only.'
      },
      {
        id: 'avail_seed_4',
        creator: '@elena_art',
        creatorHandle: '@elena_art',
        creatorName: 'Elena Rostova',
        type: 'availability',
        status: 'Limited',
        date: `${y}-${String(m + 1).padStart(2, '0')}-18`,
        dayNum: 18,
        month: m,
        year: y,
        title: '@elena_art • Half-Day Morning Slot (9am - 1pm)',
        notes: 'Afternoon reserved for gallery exhibition.'
      }
    ];
  }, []);

  // Merge custom schedules and defaults
  const allAvailabilityEvents = useMemo(() => {
    const rawList = (agencySchedules || []).filter(
      e => e.type === 'availability' || e.type === 'blockout' || e.type === 'vacation' || e.type === 'booking_hold' || e.status
    );

    const merged = [...rawList];
    defaultEntries.forEach(def => {
      if (!merged.some(m => m.id === def.id || (m.date === def.date && m.creator === def.creator))) {
        merged.push(def);
      }
    });

    return merged.map(evt => {
      const d = evt.date ? new Date(evt.date) : new Date(evt.year || calendarYear, evt.month || calendarMonthIndex, evt.dayNum || 1);
      return {
        ...evt,
        year: evt.year !== undefined ? evt.year : d.getFullYear(),
        month: evt.month !== undefined ? evt.month : d.getMonth(),
        dayNum: evt.dayNum !== undefined ? evt.dayNum : d.getDate(),
        date: evt.date || `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
      };
    });
  }, [agencySchedules, defaultEntries, calendarYear, calendarMonthIndex]);

  // Filter events for role & query
  const filteredEvents = useMemo(() => {
    return allAvailabilityEvents.filter(evt => {
      // Month & Year Filter
      if (evt.month !== calendarMonthIndex || evt.year !== calendarYear) {
        return false;
      }

      // Creator Isolation Filter: Creators only see their own availability
      if (isCreator) {
        const cHandle = (evt.creator || evt.creatorHandle || '').toLowerCase().replace('@', '');
        const cName = (evt.creatorName || evt.title || '').toLowerCase();
        const isSelf = (myHandle && (cHandle === myHandle || cHandle.includes(myHandle) || myHandle.includes(cHandle))) ||
                       (myName && (cName.includes(myName) || evt.title.toLowerCase().includes(myName)));
        if (!isSelf && (myHandle || myName)) {
          return false;
        }
      } else if (isRestrictedRole) {
        // Staff Isolation Filter: Staff only sees creators in their assigned roster
        const cHandle = (evt.creator || evt.creatorHandle || '').toLowerCase();
        const extractedHandle = cHandle.includes('@') ? '@' + cHandle.split('@')[1].split(')')[0] : cHandle;
        const cleanHandle = extractedHandle.replace('@', '').trim();
        
        if (allowedCreatorHandles.length > 0) {
          const isAssigned = allowedCreatorHandles.some(h => {
            const cleanH = h.replace('@', '').trim();
            return cleanH === cleanHandle || cleanH.includes(cleanHandle) || cleanHandle.includes(cleanH) ||
                   (evt.title || '').toLowerCase().includes(cleanH);
          });
          if (!isAssigned) return false;
        }
      }

      // Status filter
      if (statusFilter !== 'all' && (evt.status || '').toLowerCase() !== statusFilter.toLowerCase()) {
        return false;
      }

      // Creator dropdown filter (for director/staff)
      if (!isCreator && creatorFilter !== 'all') {
        const cHandle = (evt.creator || evt.creatorHandle || '').toLowerCase();
        if (cHandle !== creatorFilter.toLowerCase()) {
          return false;
        }
      }

      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = (evt.title || '').toLowerCase().includes(q);
        const matchesCreator = (evt.creator || evt.creatorName || '').toLowerCase().includes(q);
        const matchesNotes = (evt.notes || '').toLowerCase().includes(q);
        if (!matchesTitle && !matchesCreator && !matchesNotes) {
          return false;
        }
      }

      return true;
    });
  }, [allAvailabilityEvents, calendarMonthIndex, calendarYear, isCreator, myHandle, myName, statusFilter, creatorFilter, searchQuery]);

  // Calendar Grid calculations
  const daysInMonth = new Date(calendarYear, calendarMonthIndex + 1, 0).getDate();
  const firstDayOfWeek = new Date(calendarYear, calendarMonthIndex, 1).getDay();

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    const d = new Date(newDate);
    const day = d.getDate();
    const m = d.getMonth();
    const y = d.getFullYear();

    const newSlot: AvailabilityEntry = {
      id: `avail_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      creator: isCreator ? (currentUser?.handle || '@creator') : newCreator,
      creatorHandle: isCreator ? (currentUser?.handle || '@creator') : newCreator,
      creatorName: isCreator ? (currentUser?.name || 'Talent') : (creators.find(c => c.handle === newCreator)?.name || newCreator),
      type: newStatus === 'Blackout' ? 'blockout' : newStatus === 'Vacation' ? 'vacation' : 'availability',
      status: newStatus,
      date: newDate,
      dayNum: day,
      month: m,
      year: y,
      title: `${newCreator} • ${newTitle}`,
      notes: newNotes
    };

    if (setAgencySchedules) {
      setAgencySchedules(prev => [newSlot, ...prev]);
    }

    if (triggerNotification) {
      triggerNotification(
        'Availability Updated',
        `Successfully logged ${newStatus} entry for ${newSlot.creator} on ${newDate}.`,
        'success'
      );
    }

    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'User',
        currentRole || 'none',
        `Added availability calendar slot: ${newStatus} for ${newSlot.creator}`
      );
    }

    setShowAddModal(false);
    setNewNotes('');
    setNewTitle('Available for Brand Shoots');
  };

  const handleDeleteSlot = (id: string, title: string) => {
    if (setAgencySchedules) {
      setAgencySchedules(prev => prev.filter(e => e.id !== id));
    }
    if (triggerNotification) {
      triggerNotification('Slot Removed', `Removed availability entry: ${title}`, 'info');
    }
  };

  const getStatusBadge = (status?: string) => {
    switch (status?.toLowerCase()) {
      case 'available':
        return { bg: 'bg-emerald-500/15', border: 'border-emerald-500/30', text: 'text-emerald-400', label: '🟢 Available' };
      case 'limited':
        return { bg: 'bg-amber-500/15', border: 'border-amber-500/30', text: 'text-amber-400', label: '🟡 Limited' };
      case 'booked':
        return { bg: 'bg-blue-500/15', border: 'border-blue-500/30', text: 'text-blue-400', label: '🔵 Booked' };
      case 'blackout':
        return { bg: 'bg-rose-500/15', border: 'border-rose-500/30', text: 'text-rose-400', label: '🔴 Blackout' };
      case 'vacation':
        return { bg: 'bg-purple-500/15', border: 'border-purple-500/30', text: 'text-purple-400', label: '🟣 Travel / Hold' };
      default:
        return { bg: 'bg-emerald-500/15', border: 'border-emerald-500/30', text: 'text-emerald-400', label: '🟢 Available' };
    }
  };

  const dayEvents = selectedDay !== null
    ? filteredEvents.filter(e => e.dayNum === selectedDay)
    : [];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl p-6 shadow-xl relative overflow-hidden" style={{ backgroundColor: cardBgColor }}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-[#C9A46A]/20 border border-[#C9A46A]/40 text-[#C9A46A] px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
                <CalendarIcon className="w-3.5 h-3.5" />
                {isCreator ? 'My Live Availability Desk' : 'Talent Availability & Booking Matrix'}
              </span>
              <span className="bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold">
                Live Agency Synced
              </span>
            </div>
            <h2 className="text-2xl font-serif font-bold text-white tracking-tight">
              {isCreator ? 'My Availability & Blackout Calendar' : 'Roster Availability, Blackouts & Shoot Holds'}
            </h2>
            <p className="text-xs text-[#7C8AA8] mt-1 max-w-2xl leading-relaxed">
              {isCreator
                ? 'Manage your available shooting dates, exam blackouts, vacation holds, and sync booking windows with agency representation.'
                : 'Inspect creator open filming windows, manage creator blackout dates, and verify booking capacity across the representation roster.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                if (onNavigateToScreen) onNavigateToScreen('production-calendar');
              }}
              className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-slate-300 hover:text-white px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-sm"
            >
              <Tag className="w-3.5 h-3.5 text-[#C9A46A]" />
              <span>Switch to Production Calendar &rarr;</span>
            </button>

            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{isCreator ? 'Log Hold / Blackout' : 'Add Availability Slot'}</span>
            </button>
          </div>
        </div>

        {/* Month Selector Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 mt-6 pt-5 border-t border-white/10">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentDate(new Date(calendarYear, calendarMonthIndex - 1, 1))}
              className="p-2 text-slate-300 hover:text-white bg-[#111E33] hover:bg-white/10 border border-white/10 rounded-xl transition-all cursor-pointer"
              title="Previous Month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-serif text-base font-bold text-white px-3">
              {calendarMonthName} <span className="text-[#C9A46A] font-mono">{calendarYear}</span>
            </span>
            <button
              onClick={() => setCurrentDate(new Date(calendarYear, calendarMonthIndex + 1, 1))}
              className="p-2 text-slate-300 hover:text-white bg-[#111E33] hover:bg-white/10 border border-white/10 rounded-xl transition-all cursor-pointer"
              title="Next Month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setCurrentDate(new Date());
                setSelectedDay(new Date().getDate());
              }}
              className="ml-2 px-3 py-1.5 text-xs font-mono bg-[#111E33] border border-white/10 text-slate-300 hover:text-white rounded-xl cursor-pointer"
            >
              Today
            </button>
          </div>

          {/* Quick Filters */}
          <div className="flex flex-wrap items-center gap-2.5">
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="bg-[#111E33] border border-white/10 text-slate-200 text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#C9A46A]"
            >
              <option value="all">All Statuses</option>
              <option value="Available">🟢 Available</option>
              <option value="Limited">🟡 Limited</option>
              <option value="Booked">🔵 Booked</option>
              <option value="Blackout">🔴 Blackout</option>
              <option value="Vacation">🟣 Travel / Hold</option>
            </select>

            {!isCreator && (
              <select
                value={creatorFilter}
                onChange={e => setCreatorFilter(e.target.value)}
                className="bg-[#111E33] border border-white/10 text-slate-200 text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="all">All Talent</option>
                {creators.map(c => (
                  <option key={c.id || c.handle} value={c.handle}>
                    {c.name} ({c.handle})
                  </option>
                ))}
              </select>
            )}

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#7C8AA8] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search slots..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-2 bg-[#111E33] border border-white/10 rounded-xl text-xs text-white placeholder-[#7C8AA8] focus:outline-none focus:border-[#C9A46A]"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Calendar Matrix + Selected Day Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Calendar Day Matrix (2 cols on lg) */}
        <div className="lg:col-span-2 bg-[#0D1830] border border-white/10 rounded-2xl p-5 shadow-lg" style={{ backgroundColor: cardBgColor }}>
          {/* Day of Week Headers */}
          <div className="grid grid-cols-7 gap-2 mb-2 text-center text-[11px] font-mono font-bold text-[#7C8AA8] uppercase">
            <div>Sun</div>
            <div>Mon</div>
            <div>Tue</div>
            <div>Wed</div>
            <div>Thu</div>
            <div>Fri</div>
            <div>Sat</div>
          </div>

          {/* Month Days Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Empty offset days */}
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`offset-${i}`} className="h-24 bg-black/10 rounded-xl border border-white/5 opacity-30 pointer-events-none" />
            ))}

            {/* Actual Month Days */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const dayNum = i + 1;
              const dateStr = `${calendarYear}-${String(calendarMonthIndex + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
              const eventsForDay = filteredEvents.filter(e => e.dayNum === dayNum);
              const isToday = new Date().getDate() === dayNum && new Date().getMonth() === calendarMonthIndex && new Date().getFullYear() === calendarYear;
              const isSelected = selectedDay === dayNum;

              const hasAvailable = eventsForDay.some(e => e.status === 'Available');
              const hasBlackout = eventsForDay.some(e => e.status === 'Blackout');
              const hasLimited = eventsForDay.some(e => e.status === 'Limited');
              const hasVacation = eventsForDay.some(e => e.status === 'Vacation');

              return (
                <div
                  key={`day-${dayNum}`}
                  onClick={() => setSelectedDay(dayNum)}
                  className={`h-24 p-2 rounded-xl border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden group ${
                    isSelected
                      ? 'bg-[#16243F] border-[#C9A46A] shadow-md scale-[1.02]'
                      : 'bg-[#111E33] border-white/5 hover:border-white/20 hover:bg-[#152540]'
                  } ${isToday ? 'ring-1 ring-emerald-500' : ''}`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-mono font-bold ${isToday ? 'text-emerald-400' : isSelected ? 'text-[#C9A46A]' : 'text-slate-300'}`}>
                      {dayNum}
                    </span>
                    {isToday && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    )}
                  </div>

                  {/* Badges / Indicators */}
                  <div className="space-y-1 overflow-hidden">
                    {eventsForDay.slice(0, 2).map((evt, idx) => {
                      const badge = getStatusBadge(evt.status);
                      return (
                        <div
                          key={evt.id || idx}
                          className={`text-[9px] px-1.5 py-0.5 rounded truncate font-medium border ${badge.bg} ${badge.border} ${badge.text}`}
                        >
                          {evt.status === 'Available' ? '✓ Open' : evt.status === 'Blackout' ? '✕ Block' : evt.status}
                        </div>
                      );
                    })}
                    {eventsForDay.length > 2 && (
                      <div className="text-[8px] font-mono text-[#7C8AA8] text-right">
                        +{eventsForDay.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Day Inspector Panel */}
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 shadow-lg flex flex-col justify-between" style={{ backgroundColor: cardBgColor }}>
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase text-[#C9A46A] block">
                  Schedule Details
                </span>
                <h3 className="text-base font-serif font-bold text-white mt-0.5">
                  {selectedDay !== null
                    ? `${calendarMonthName} ${selectedDay}, ${calendarYear}`
                    : 'Select a Day'}
                </h3>
              </div>
              <span className="px-2.5 py-1 bg-[#111E33] border border-white/10 rounded-lg text-xs font-mono text-slate-300">
                {dayEvents.length} {dayEvents.length === 1 ? 'Slot' : 'Slots'}
              </span>
            </div>

            {dayEvents.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-[#7C8AA8]">
                  <CalendarIcon className="w-6 h-6" />
                </div>
                <p className="text-xs text-slate-300 font-semibold">No availability slots or blackouts logged for this date.</p>
                <p className="text-[11px] text-[#7C8AA8] max-w-xs mx-auto">
                  {isCreator
                    ? 'Log your availability or blackout dates to let the agency know your open shoot times.'
                    : 'Click "Add Availability Slot" to log open filming dates or blackouts for roster talent.'}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    if (selectedDay !== null) {
                      const dStr = `${calendarYear}-${String(calendarMonthIndex + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`;
                      setNewDate(dStr);
                    }
                    setShowAddModal(true);
                  }}
                  className="px-4 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Slot for This Day</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
                {dayEvents.map(evt => {
                  const badge = getStatusBadge(evt.status);
                  return (
                    <div
                      key={evt.id}
                      className="bg-[#111E33] border border-white/10 rounded-xl p-3.5 space-y-2 hover:border-white/20 transition-all"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-0.5 min-w-0">
                          <span className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${badge.bg} ${badge.border} ${badge.text}`}>
                            {badge.label}
                          </span>
                          <h4 className="text-xs font-bold text-white truncate mt-1">
                            {evt.title || evt.creator}
                          </h4>
                          <p className="text-[10px] text-[#7C8AA8] font-mono">
                            Talent: <strong className="text-slate-300">{evt.creator}</strong>
                          </p>
                        </div>
                        <button
                          onClick={() => handleDeleteSlot(evt.id, evt.title)}
                          className="text-slate-500 hover:text-rose-400 p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                          title="Delete slot"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {evt.notes && (
                        <p className="text-xs text-slate-300 bg-black/20 p-2 rounded-lg border border-white/5 leading-relaxed">
                          {evt.notes}
                        </p>
                      )}

                      <div className="pt-1.5 border-t border-white/5 flex flex-wrap items-center gap-1.5 text-[9px] font-mono text-[#C9A46A]">
                        <span className="text-slate-400">Broadcasted to:</span>
                        <span className="px-2 py-0.5 rounded bg-[#C9A46A]/10 border border-[#C9A46A]/30">Coordinator</span>
                        <span className="px-2 py-0.5 rounded bg-[#C9A46A]/10 border border-[#C9A46A]/30">Agent</span>
                        <span className="px-2 py-0.5 rounded bg-[#C9A46A]/10 border border-[#C9A46A]/30">Agent Manager</span>
                        <span className="px-2 py-0.5 rounded bg-[#C9A46A]/10 border border-[#C9A46A]/30">Director</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Quick Legend */}
          <div className="pt-4 border-t border-white/10 mt-4">
            <span className="text-[9px] font-mono uppercase text-[#7C8AA8] block mb-2">Matrix Key</span>
            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span> Available
              </div>
              <div className="flex items-center gap-1.5 text-amber-400">
                <span className="w-2 h-2 rounded-full bg-amber-400"></span> Limited Slot
              </div>
              <div className="flex items-center gap-1.5 text-rose-400">
                <span className="w-2 h-2 rounded-full bg-rose-400"></span> Strict Blackout
              </div>
              <div className="flex items-center gap-1.5 text-purple-400">
                <span className="w-2 h-2 rounded-full bg-purple-400"></span> Travel / Hold
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Slot Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl animate-scale-up">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                <CalendarIcon className="w-5 h-5 text-[#C9A46A]" />
                {isCreator ? 'Log Availability / Blackout' : 'Add Roster Availability Slot'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-[#7C8AA8] hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSlot} className="space-y-4">
              {!isCreator ? (
                <div>
                  <label className="block text-[10px] font-mono text-[#7C8AA8] uppercase mb-1">Roster Creator</label>
                  <select
                    value={newCreator}
                    onChange={e => setNewCreator(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    {creators.map(c => (
                      <option key={c.id || c.handle} value={c.handle}>
                        {c.name} ({c.handle})
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="bg-[#111E33] p-2.5 rounded-xl border border-white/5">
                  <span className="text-[10px] font-mono text-[#7C8AA8] uppercase block">Talent Handle</span>
                  <span className="text-xs font-bold text-white">{currentUser?.handle || '@creator'}</span>
                </div>
              )}

              <div>
                <label className="block text-[10px] font-mono text-[#7C8AA8] uppercase mb-1">Availability Status</label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value as any)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Available">🟢 Available (Open for Commercial Shoots)</option>
                  <option value="Limited">🟡 Limited (Half Day / Specific Windows)</option>
                  <option value="Booked">🔵 Booked (Committed to Existing Shoot)</option>
                  <option value="Blackout">🔴 Blackout (Strict Off-Limits / No Brand Work)</option>
                  <option value="Vacation">🟣 Vacation / Travel Hold</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-[#7C8AA8] uppercase mb-1">Date</label>
                <input
                  type="date"
                  value={newDate}
                  onChange={e => setNewDate(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-[#7C8AA8] uppercase mb-1">Title / Summary</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="e.g. Open for LA Commercial Shoots or Exam Week Blackout"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-[#7C8AA8] focus:outline-none focus:border-[#C9A46A]"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-[#7C8AA8] uppercase mb-1">Internal Notes</label>
                <textarea
                  value={newNotes}
                  onChange={e => setNewNotes(e.target.value)}
                  placeholder="Specific details, locations, hours or restrictions..."
                  rows={3}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-[#7C8AA8] focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
