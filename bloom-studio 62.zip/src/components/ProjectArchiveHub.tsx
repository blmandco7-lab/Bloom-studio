import React, { useState } from 'react';
import { History, Database, Search, ArrowRight, Download, Filter, FileCheck, CheckCircle2 } from 'lucide-react';

export default function ProjectArchiveHub() {
  const [archiving, setArchiving] = useState(false);
  const [isArchived, setIsArchived] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<'All' | 'WithAssets' | 'WithContracts'>('All');
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);

  const triggerDownloadNotice = (msg: string) => {
    setDownloadNotice(msg);
    setTimeout(() => setDownloadNotice(null), 3500);
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      {downloadNotice && (
        <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs font-mono font-bold flex items-center justify-between">
          <span>{downloadNotice}</span>
          <button onClick={() => setDownloadNotice(null)} className="text-white hover:text-emerald-200">✕</button>
        </div>
      )}

      <div className="relative bg-[#0b1320] border-2 border-indigo-500/30 rounded-2xl p-6 overflow-hidden shadow-2xl">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-[0.2em] font-mono">
                Cold Storage Operations
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5">
              Automated Project Archiving
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Non-destructive cold storage tools that sweep completed campaigns off daily active dashboard screens.
            </p>
          </div>
          <div className="bg-[#050d18] border border-blue-900/60 rounded-xl p-3 flex items-center gap-3">
             <Database className="w-8 h-8 text-indigo-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#0b1320] border border-white/5 rounded-2xl p-6 space-y-5">
          <h3 className="text-sm font-bold font-mono text-[#D4AF37] uppercase">Archive Completed Campaigns</h3>
          
          <div className="space-y-4">
            <div className="bg-[#050e1a] border border-white/10 rounded-xl p-4 flex items-start gap-4">
              <input type="checkbox" className="mt-1" defaultChecked />
              <div className="flex-1">
                <h4 className="text-sm font-bold text-white">Lumina Skin Barrier Serum Launch</h4>
                <p className="text-xs text-slate-400 mt-1">Completed. All final deliverables published and brand invoices fully settled.</p>
              </div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-mono px-2 py-1 rounded">100% DONE</span>
            </div>

            <div className="bg-[#050e1a] border border-white/10 rounded-xl p-4 flex items-start gap-4">
              <input type="checkbox" className="mt-1" defaultChecked />
              <div className="flex-1">
                <h4 className="text-sm font-bold text-white">Urban Streetwear Q3 Drops</h4>
                <p className="text-xs text-slate-400 mt-1">Completed. Assets transferred, creators paid via escrow.</p>
              </div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-mono px-2 py-1 rounded">100% DONE</span>
            </div>
          </div>

          <button 
            onClick={() => {
              setArchiving(true);
              setTimeout(() => {
                setArchiving(false);
                setIsArchived(true);
              }, 1500);
            }}
            disabled={isArchived}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            {archiving ? 'Sweeping to Cold Storage...' : isArchived ? 'Projects Archived' : 'Archive Selected Projects'}
          </button>
        </div>

        <div className="bg-[#0b1320] border border-white/5 rounded-2xl p-6 flex flex-col h-full">
          <h3 className="text-sm font-bold font-mono text-white uppercase mb-4 flex items-center gap-2">
            <History className="w-4 h-4 text-indigo-400" /> Cold Storage Vault
          </h3>
          
          <div className="flex gap-2 mb-4">
            <input 
              type="text" 
              placeholder="Search archives..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 bg-[#050e1a] border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none focus:border-indigo-500" 
            />
            <button 
              onClick={() => setActiveFilter(prev => prev === 'All' ? 'WithAssets' : prev === 'WithAssets' ? 'WithContracts' : 'All')}
              className={`border rounded-lg px-3 py-2 text-xs transition cursor-pointer flex items-center gap-1 ${
                activeFilter !== 'All' ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-[#050e1a] border-white/10 text-slate-400 hover:text-white'
              }`}
              title="Toggle filter"
            >
              <Filter className="w-4 h-4" />
              <span className="text-[10px] font-mono">{activeFilter}</span>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto pr-2 space-y-3">
            {isArchived && (
              <div className="bg-[#050e1a] border border-indigo-500/30 rounded-xl p-4 animate-fade-in">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-sm font-bold text-white">Lumina Skin Barrier Serum Launch</h4>
                  <span className="text-[9px] font-mono text-slate-500">Archived Today</span>
                </div>
                <div className="flex gap-2 mt-3">
                  <button 
                    onClick={() => triggerDownloadNotice("Downloading archived raw video assets (.zip bundle)...")}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-white/5 hover:bg-white/10 text-xs py-1.5 rounded transition text-slate-300 cursor-pointer"
                  >
                    <Download className="w-3 h-3" /> Assets
                  </button>
                  <button 
                    onClick={() => triggerDownloadNotice("Exporting executed brand & creator contracts (.pdf)...")}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-white/5 hover:bg-white/10 text-xs py-1.5 rounded transition text-slate-300 cursor-pointer"
                  >
                    <FileCheck className="w-3 h-3" /> Contracts
                  </button>
                </div>
              </div>
            )}
            
            <div className="bg-[#050e1a] border border-white/10 rounded-xl p-4 opacity-75">
              <div className="flex justify-between items-start mb-2">
                <h4 className="text-sm font-bold text-white">Spring Wellness Retreat</h4>
                <span className="text-[9px] font-mono text-slate-500">Archived Mar 2026</span>
              </div>
              <div className="flex gap-2 mt-3">
                <button 
                  onClick={() => triggerDownloadNotice("Downloading archived raw video assets (.zip bundle)...")}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-white/5 hover:bg-white/10 text-xs py-1.5 rounded transition text-slate-300 cursor-pointer"
                >
                  <Download className="w-3 h-3" /> Assets
                </button>
                <button 
                  onClick={() => triggerDownloadNotice("Exporting executed brand & creator contracts (.pdf)...")}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-white/5 hover:bg-white/10 text-xs py-1.5 rounded transition text-slate-300 cursor-pointer"
                >
                  <FileCheck className="w-3 h-3" /> Contracts
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
