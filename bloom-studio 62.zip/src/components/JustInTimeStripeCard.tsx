import React, { useState, useEffect, useMemo } from 'react';
import { 
  CreditCard, Shield, Lock, Unlock, Zap, Clock, CheckCircle2, AlertTriangle, 
  Upload, FileText, ArrowUpRight, RefreshCw, Sparkles, Check, DollarSign, 
  X, Eye, EyeOff, Receipt, Building, ShoppingBag, Camera, ChevronRight,
  ShieldCheck, AlertCircle, HelpCircle, FileCheck
} from 'lucide-react';
import { Creator, JitExpenseRequest } from '../types';

interface JustInTimeStripeCardProps {
  creator?: Creator | null;
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

const PRESET_EXPENSE_ITEMS = [
  { category: 'Beauty Textures & Swatches', name: 'Luxe Skin Glow Foundation Palette', avgCost: 145, brand: 'Sephora / Fenty' },
  { category: 'Studio Lighting & Props', name: 'Bi-Color Softbox Dome & Backdrop Stand', avgCost: 280, brand: 'Nike Studio' },
  { category: 'Pet Accessories & Nutrition', name: 'Organic Bark Truffles & Silk Collar Set', avgCost: 95, brand: 'BarkBox Deluxe' },
  { category: 'Wardrobe & Styling', name: 'Monochrome Editorial Trench & Gloves', avgCost: 320, brand: 'Zara Editorial' },
  { category: 'Camera & Rigging', name: 'Wireless Lavalier Mic & ND Filter Kit', avgCost: 210, brand: 'Rode Audio' },
  { category: 'Location Rental', name: 'Natural Light Daylight Studio (2 Hours)', avgCost: 450, brand: 'Dyson Commercial' }
];

export const JustInTimeStripeCard: React.FC<JustInTimeStripeCardProps> = ({
  creator,
  currentUser,
  currentRole = 'creator',
  onAddActivityLog,
  triggerNotification
}) => {
  const isDirector = currentRole.toLowerCase() === 'director' || currentRole.toLowerCase() === 'owner';
  const isCreator = currentRole.toLowerCase() === 'creator';
  const creatorName = creator?.name || currentUser?.name || 'Alex Jones';
  const creatorHandle = creator?.handle || currentUser?.handle || '@alexjones';
  const creatorId = creator?.id || currentUser?.uid || 'creator-default';

  // JIT Card States
  const [currentBalance, setCurrentBalance] = useState<number>(0.00);
  const [cardStatus, setCardStatus] = useState<'HARDLOCKED_ZERO' | 'AUTHORIZED_WINDOW' | 'SWIPED_PENDING_RECEIPT'>('HARDLOCKED_ZERO');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(0);
  const [activeRequest, setActiveRequest] = useState<JitExpenseRequest | null>(null);
  
  // Expense Request Modal State
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<any>('Beauty Textures & Swatches');
  const [itemTitle, setItemTitle] = useState('');
  const [requestedAmount, setRequestedAmount] = useState<number>(145);
  const [brandAssociation, setBrandAssociation] = useState('Sephora Glow Campaign');
  const [justification, setJustification] = useState('Required high-definition product texture swatch props for 4K macro video shoot.');
  
  // Simulation Terminal & Receipt Upload State
  const [showTerminalModal, setShowTerminalModal] = useState(false);
  const [terminalSwipeAmount, setTerminalSwipeAmount] = useState<number>(145);
  const [uploadedReceiptName, setUploadedReceiptName] = useState<string | null>(null);
  const [receiptMatchingStatus, setReceiptMatchingStatus] = useState<'IDLE' | 'MATCHING' | 'RECONCILED'>('IDLE');
  
  // Mock Past Ledgers
  const [historyLedger, setHistoryLedger] = useState<JitExpenseRequest[]>([
    {
      id: 'jit-req-001',
      creatorId,
      creatorName,
      creatorHandle,
      itemCategory: 'Studio Lighting & Props',
      itemTitle: 'RGB Prism Color Gels & Diffusion Paper',
      requestedAmount: 85.00,
      brandAssociation: 'Red Bull Energy',
      justification: 'High-speed action color wash background lighting.',
      status: 'SWIPE_RECONCILED',
      requestedAt: '2026-08-28 14:10',
      approvedAt: '2026-08-28 14:12',
      unlockedLimit: 85.00,
      currentBalance: 0.00,
      receiptFileName: 'Receipt_StudioDepot_85.pdf',
      swipeMerchantName: 'Studio Lighting Depot #402',
      swipeAmount: 85.00,
      reconciliationAuditId: 'AUD-88392-JIT'
    },
    {
      id: 'jit-req-002',
      creatorId,
      creatorName,
      creatorHandle,
      itemCategory: 'Pet Accessories & Nutrition',
      itemTitle: 'Ultra-Hydrating Fur Balm & Chew Rings',
      requestedAmount: 62.50,
      brandAssociation: 'Chewy Naturals',
      justification: 'Unboxing B-roll prop accessories.',
      status: 'SWIPE_RECONCILED',
      requestedAt: '2026-08-25 11:30',
      approvedAt: '2026-08-25 11:32',
      unlockedLimit: 62.50,
      currentBalance: 0.00,
      receiptFileName: 'Chewy_PetStore_Receipt.jpg',
      swipeMerchantName: 'PetCare Store #18',
      swipeAmount: 62.50,
      reconciliationAuditId: 'AUD-67412-JIT'
    }
  ]);

  // Countdown timer for active 30-minute JIT window
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (cardStatus === 'AUTHORIZED_WINDOW' && secondsRemaining > 0) {
      interval = setInterval(() => {
        setSecondsRemaining(prev => {
          if (prev <= 1) {
            // Auto-drop balance back to 0 on expiration
            setCurrentBalance(0.00);
            setCardStatus('HARDLOCKED_ZERO');
            triggerNotification?.(
              '⚠️ JIT Window Expired',
              '30-minute authorization window closed. Balance hardlocked back to $0.00.',
              'warning'
            );
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [cardStatus, secondsRemaining, triggerNotification]);

  // Format seconds to mm:ss
  const formattedCountdown = useMemo(() => {
    const mins = Math.floor(secondsRemaining / 60);
    const secs = secondsRemaining % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, [secondsRemaining]);

  // Submit Expense Request
  const handleSubmitExpenseRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemTitle || requestedAmount <= 0) return;

    const newRequest: JitExpenseRequest = {
      id: `jit-req-${Date.now().toString().slice(-4)}`,
      creatorId,
      creatorName,
      creatorHandle,
      itemCategory: selectedCategory,
      itemTitle,
      requestedAmount,
      brandAssociation,
      justification,
      status: 'PENDING_APPROVAL',
      requestedAt: new Date().toLocaleString(),
      unlockedLimit: requestedAmount,
      currentBalance: 0.00
    };

    setActiveRequest(newRequest);
    setShowRequestModal(false);

    triggerNotification?.(
      'Expense Request Submitted',
      `Requested $${requestedAmount.toFixed(2)} for ${itemTitle} (${brandAssociation}). Awaiting JIT unlock.`,
      'info'
    );

    onAddActivityLog?.(
      creatorName,
      'creator',
      `Submitted JIT Expense Request: $${requestedAmount.toFixed(2)} for "${itemTitle}" (${brandAssociation})`
    );

    // If Director or Instant Webhook Auto-Approval simulation:
    setTimeout(() => {
      handleApproveJitWebhook(newRequest);
    }, 1800);
  };

  // Instant Webhook Approval: Unlocks limit for 30 minutes
  const handleApproveJitWebhook = (req: JitExpenseRequest) => {
    const unlockedReq: JitExpenseRequest = {
      ...req,
      status: 'APPROVED_UNLOCKED',
      approvedAt: new Date().toLocaleString(),
      windowExpiresAt: new Date(Date.now() + 30 * 60 * 1000).toLocaleTimeString(),
      currentBalance: req.requestedAmount
    };

    setActiveRequest(unlockedReq);
    setCurrentBalance(req.requestedAmount);
    setTerminalSwipeAmount(req.requestedAmount);
    setCardStatus('AUTHORIZED_WINDOW');
    setSecondsRemaining(30 * 60); // 30 minutes in seconds

    triggerNotification?.(
      '⚡ JIT Webhook: Card Unlocked ($' + req.requestedAmount.toFixed(2) + ')',
      'Production allowance active for 30 minutes. Balance will drop to $0.00 upon receipt reconciliation.',
      'success'
    );

    onAddActivityLog?.(
      'Stripe Issuing Webhook',
      'system',
      `JIT Dynamic Limit Unlocked: $${req.requestedAmount.toFixed(2)} granted to ${creatorName} for 30m window.`
    );
  };

  // Terminal Swipe Simulation
  const handleSimulateSwipe = () => {
    if (cardStatus !== 'AUTHORIZED_WINDOW') return;
    setCardStatus('SWIPED_PENDING_RECEIPT');
    setShowTerminalModal(true);
    triggerNotification?.(
      'Card Swiped: $' + terminalSwipeAmount.toFixed(2),
      'Swipe recorded. Reconcile by uploading target receipt file to drop balance to $0.00.',
      'info'
    );
  };

  // Reconcile Swipe with Target Receipt File
  const handleReconcileReceipt = (fileName: string) => {
    setReceiptMatchingStatus('MATCHING');
    setUploadedReceiptName(fileName);

    setTimeout(() => {
      setReceiptMatchingStatus('RECONCILED');

      // The instant swipe matches target receipt file: drop balance back to $0.00
      setCurrentBalance(0.00);
      setCardStatus('HARDLOCKED_ZERO');
      setSecondsRemaining(0);

      const reconciledRequest: JitExpenseRequest = {
        ...(activeRequest || {
          id: `jit-req-${Date.now()}`,
          creatorId,
          creatorName,
          creatorHandle,
          itemCategory: selectedCategory,
          itemTitle: itemTitle || 'Production Item',
          requestedAmount: terminalSwipeAmount,
          brandAssociation: brandAssociation || 'Brand Shoot',
          justification: justification || 'Verified Receipt',
          status: 'SWIPE_RECONCILED',
          requestedAt: new Date().toLocaleString(),
          unlockedLimit: terminalSwipeAmount,
          currentBalance: 0
        }),
        status: 'SWIPE_RECONCILED',
        currentBalance: 0.00,
        receiptFileName: fileName,
        receiptUploadedAt: new Date().toLocaleString(),
        swipeMerchantName: 'Verified Production Merchant',
        swipeAmount: terminalSwipeAmount,
        swipeTimestamp: new Date().toLocaleString(),
        reconciliationAuditId: `AUD-${Math.floor(10000 + Math.random() * 90000)}-JIT`
      };

      setHistoryLedger(prev => [reconciledRequest, ...prev]);
      setActiveRequest(null);

      triggerNotification?.(
        '✔ Swipe Matched & Reconciled — Balance: $0.00',
        'Receipt audit verified. Card balance immediately reset to $0.00 to protect capital pools.',
        'success'
      );

      onAddActivityLog?.(
        creatorName,
        'creator',
        `JIT Receipt Reconciled: ${fileName} ($${terminalSwipeAmount.toFixed(2)}). Card balance reset to $0.00.`
      );

      setTimeout(() => {
        setShowTerminalModal(false);
        setReceiptMatchingStatus('IDLE');
        setUploadedReceiptName(null);
      }, 2000);
    }, 1500);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#0E1C38] via-[#142850] to-[#0A162B] border border-[#D4AF37]/20 rounded-3xl p-6 shadow-2xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#D4AF37]/10 rounded-xl text-[#D4AF37]">
              <Zap className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white tracking-wide">
              Just-in-Time (JIT) Stripe Issuing Policy
            </h1>
          </div>
          <p className="text-xs text-[#B8C0D4] max-w-2xl">
            Every creator debit card is hardlocked to a strict <span className="text-[#D4AF37] font-semibold">$0.00 balance</span> by default. 
            Production expense approvals dynamically open a 30-minute window, instantly dropping back to zero upon receipt reconciliation.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowRequestModal(true)}
            className="px-5 py-3 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] hover:from-[#E3C48F] hover:to-[#FFF0D4] text-[#0B1B3D] font-bold rounded-2xl text-xs transition-all shadow-lg shadow-[#D4AF37]/20 flex items-center gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Request Production Expense</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Card & Active Policy Controller */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Physical & Virtual Luxury Card (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="relative w-full aspect-[1.586/1] bg-gradient-to-br from-[#1E293B] via-[#0B1B3D] to-[#020617] rounded-3xl p-7 shadow-2xl border border-white/10 flex flex-col justify-between overflow-hidden group">
            {/* Ambient Lighting FX */}
            <div className={`absolute -top-20 -right-20 w-48 h-48 rounded-full blur-3xl transition-all duration-700 ${
              cardStatus === 'AUTHORIZED_WINDOW' 
                ? 'bg-emerald-500/20' 
                : 'bg-[#D4AF37]/10'
            }`} />

            {/* Top Row: Brand & Hologram */}
            <div className="flex justify-between items-start z-10">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-[0.25em] text-[#D4AF37]">
                  Bloom Studio Syndicate
                </span>
                <p className="text-xs text-white/50 font-mono mt-0.5">Corporate Production Debit</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-9 h-6 bg-gradient-to-tr from-amber-400/80 to-amber-200/40 rounded border border-amber-300/40 shadow-inner flex items-center justify-center">
                  <div className="w-5 h-3 border border-amber-900/30 rounded-sm opacity-60"></div>
                </div>
                <div className="flex -space-x-2">
                  <div className="w-5 h-5 rounded-full bg-rose-500/80" />
                  <div className="w-5 h-5 rounded-full bg-amber-400/80" />
                </div>
              </div>
            </div>

            {/* Middle Row: Card Number & Chip */}
            <div className="space-y-2 z-10 my-auto">
              <div className="flex items-center gap-3">
                <div className="w-10 h-7 bg-gradient-to-br from-amber-100 to-amber-300 rounded-md border border-amber-400/40 shadow-sm flex items-center justify-center">
                  <div className="w-8 h-5 border border-amber-600/30 rounded grid grid-cols-2 gap-0.5 p-0.5 opacity-70">
                    <div className="border-r border-amber-600/30"></div>
                    <div></div>
                  </div>
                </div>
                <span className="text-sm font-mono tracking-[0.25em] text-white/90 font-medium">
                  •••• •••• •••• 4242
                </span>
              </div>
            </div>

            {/* Bottom Row: Balance & Live Policy Status */}
            <div className="flex justify-between items-end z-10 pt-2 border-t border-white/5">
              <div>
                <p className="text-[9px] uppercase font-mono text-white/40 tracking-wider">Cardholder</p>
                <p className="text-xs font-bold text-white tracking-wide uppercase">{creatorName}</p>
              </div>

              <div className="text-right space-y-0.5">
                <p className="text-[9px] uppercase font-mono text-white/40 tracking-wider">Current Spending Balance</p>
                <div className="flex items-center justify-end gap-1.5">
                  <span className={`text-xl font-mono font-bold ${
                    currentBalance > 0 ? 'text-emerald-400 animate-pulse' : 'text-[#D4AF37]'
                  }`}>
                    ${currentBalance.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Status Pill on Card */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2">
              {cardStatus === 'HARDLOCKED_ZERO' ? (
                <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full flex items-center gap-1.5 backdrop-blur-md">
                  <Lock className="w-3 h-3 text-amber-400" />
                  <span className="text-[9px] font-bold text-amber-300 uppercase tracking-widest">
                    Hardlocked $0.00 (Zero Risk)
                  </span>
                </div>
              ) : cardStatus === 'AUTHORIZED_WINDOW' ? (
                <div className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/40 rounded-full flex items-center gap-1.5 backdrop-blur-md animate-pulse">
                  <Zap className="w-3 h-3 text-emerald-400" />
                  <span className="text-[9px] font-bold text-emerald-300 uppercase tracking-widest">
                    JIT Auth Active: {formattedCountdown}
                  </span>
                </div>
              ) : (
                <div className="px-3 py-1 bg-blue-500/20 border border-blue-500/40 rounded-full flex items-center gap-1.5 backdrop-blur-md">
                  <Receipt className="w-3 h-3 text-blue-400" />
                  <span className="text-[9px] font-bold text-blue-300 uppercase tracking-widest">
                    Swipe Pending Receipt
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Simulation Controls */}
          <div className="bg-[#142850] border border-white/5 rounded-2xl p-5 space-y-4 shadow-xl">
            <h3 className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> Live Policy Interactivity
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  const req: JitExpenseRequest = {
                    id: `jit-req-${Date.now().toString().slice(-4)}`,
                    creatorId,
                    creatorName,
                    creatorHandle,
                    itemCategory: 'Beauty Textures & Swatches',
                    itemTitle: 'Fenty Hydrating Texture Palette',
                    requestedAmount: 145.00,
                    brandAssociation: 'Sephora Summer Glow',
                    justification: 'Macro video swatches for approved campaign board brief.',
                    status: 'APPROVED_UNLOCKED',
                    requestedAt: new Date().toLocaleString(),
                    unlockedLimit: 145.00,
                    currentBalance: 145.00
                  };
                  handleApproveJitWebhook(req);
                }}
                disabled={cardStatus === 'AUTHORIZED_WINDOW'}
                className="p-3 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/10 hover:border-emerald-500/40 disabled:opacity-40 rounded-xl text-left transition-all"
              >
                <div className="flex items-center justify-between">
                  <Zap className="w-4 h-4 text-emerald-400" />
                  <span className="text-[10px] font-bold text-emerald-400">Unlock 30m</span>
                </div>
                <p className="text-xs font-bold text-white mt-1">Simulate $145 JIT Unlock</p>
                <p className="text-[10px] text-slate-400">Triggers dynamic webhook</p>
              </button>

              <button
                onClick={handleSimulateSwipe}
                disabled={cardStatus !== 'AUTHORIZED_WINDOW'}
                className="p-3 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/10 hover:border-[#D4AF37]/40 disabled:opacity-40 rounded-xl text-left transition-all"
              >
                <div className="flex items-center justify-between">
                  <CreditCard className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-[10px] font-bold text-[#D4AF37]">Swipe Terminal</span>
                </div>
                <p className="text-xs font-bold text-white mt-1">Simulate Card Swipe</p>
                <p className="text-[10px] text-slate-400">Match receipt & drop to $0</p>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Live JIT Telemetry & Policy Rules (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Active Authorization Window Monitor */}
          <div className="bg-[#142850] border border-white/5 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Stripe Capital Protection Engine
                </h3>
                <p className="text-xs text-[#7C8AA8] mt-0.5">
                  Real-time webhook synchronization & zero-liability debit provisioning
                </p>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-white/40 uppercase font-mono">Policy Status</span>
                <p className="text-xs font-bold text-emerald-400">ENFORCED (Strict $0.00)</p>
              </div>
            </div>

            {/* Policy Metric Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#0B1B3D] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono text-[#D4AF37] uppercase tracking-wider">Default Balance</span>
                <p className="text-xl font-bold text-white font-mono">$0.00</p>
                <p className="text-[10px] text-slate-400">Capital pools 100% shielded</p>
              </div>

              <div className="bg-[#0B1B3D] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider">Active JIT Limit</span>
                <p className="text-xl font-bold text-emerald-400 font-mono">
                  ${currentBalance.toFixed(2)}
                </p>
                <p className="text-[10px] text-slate-400">
                  {cardStatus === 'AUTHORIZED_WINDOW' ? `Expires in ${formattedCountdown}` : 'No active window'}
                </p>
              </div>

              <div className="bg-[#0B1B3D] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider">Reconciliation Rate</span>
                <p className="text-xl font-bold text-cyan-400 font-mono">100.0%</p>
                <p className="text-[10px] text-slate-400">Automatic drop-to-zero verified</p>
              </div>
            </div>

            {/* Step-by-step Policy Visualizer */}
            <div className="bg-[#0B1B3D] border border-white/5 rounded-2xl p-5 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Automated JIT Workflow Protocol
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#D4AF37]">
                    <span className="w-5 h-5 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[10px]">1</span>
                    Expense Request
                  </div>
                  <p className="text-[10px] text-slate-400 leading-relaxed">
                    Creator details item, vendor & approved brand shoot justification.
                  </p>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-[10px]">2</span>
                    30-Minute Dynamic Limit
                  </div>
                  <p className="text-[10px] text-slate-400 leading-relaxed">
                    Webhook unlocks exact amount for a strict 30-minute countdown window.
                  </p>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 flex items-center justify-center text-[10px]">3</span>
                    Instant $0.00 Reset
                  </div>
                  <p className="text-[10px] text-slate-400 leading-relaxed">
                    Swipe matches receipt file, immediately dropping card balance back to $0.00.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Audit Ledger of Reconciled JIT Transactions */}
          <div className="bg-[#142850] border border-white/5 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Receipt className="w-4 h-4 text-[#D4AF37]" />
                Reconciled JIT Expense History
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">Immutable Audit Track</span>
            </div>

            <div className="space-y-3">
              {historyLedger.map((item) => (
                <div 
                  key={item.id}
                  className="p-4 bg-[#0B1B3D] border border-white/5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-white/10 transition-all"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">{item.itemTitle}</span>
                      <span className="px-2 py-0.5 rounded-full bg-white/5 text-[9px] font-mono text-slate-400">
                        {item.itemCategory}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Campaign: <span className="text-[#D4AF37] font-semibold">{item.brandAssociation}</span> • Merchant: {item.swipeMerchantName || 'Storefront'}
                    </p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500">
                      <FileCheck className="w-3 h-3 text-emerald-400" />
                      <span>{item.receiptFileName}</span>
                      <span>•</span>
                      <span className="font-mono">{item.reconciliationAuditId}</span>
                    </div>
                  </div>

                  <div className="text-right space-y-1">
                    <div className="text-sm font-bold font-mono text-white">
                      ${item.requestedAmount.toFixed(2)}
                    </div>
                    <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[9px] font-bold text-emerald-400">
                      <Check className="w-3 h-3" />
                      <span>Dropped to $0.00</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* MODAL 1: Expense Request Form */}
      {showRequestModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-8 shadow-2xl max-h-[90vh] overflow-y-auto space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-[#D4AF37]/10 rounded-2xl">
                  <ShoppingBag className="w-6 h-6 text-[#D4AF37]" />
                </div>
                <div>
                  <h3 className="text-xl font-serif font-bold text-white">Production Expense Request</h3>
                  <p className="text-xs text-[#7C8AA8]">Request temporary 30-minute JIT allowance for approved items</p>
                </div>
              </div>
              <button 
                onClick={() => setShowRequestModal(false)}
                className="p-2 rounded-xl text-white/40 hover:text-white hover:bg-white/5 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Presets Selector */}
            <div className="space-y-2">
              <label className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest px-1">
                Quick Production Presets
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PRESET_EXPENSE_ITEMS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setSelectedCategory(preset.category as any);
                      setItemTitle(preset.name);
                      setRequestedAmount(preset.avgCost);
                      setBrandAssociation(preset.brand);
                    }}
                    className="p-2.5 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/5 hover:border-[#D4AF37]/40 rounded-xl text-left transition-all"
                  >
                    <p className="text-[10px] font-bold text-white truncate">{preset.name}</p>
                    <p className="text-[9px] text-[#D4AF37]">${preset.avgCost} • {preset.brand.split('/')[0]}</p>
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSubmitExpenseRequest} className="space-y-4">
              {/* Category */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest px-1">Item Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value as any)}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none"
                >
                  <option value="Beauty Textures & Swatches">Beauty Textures & Swatches</option>
                  <option value="Studio Lighting & Props">Studio Lighting & Props</option>
                  <option value="Pet Accessories & Nutrition">Pet Accessories & Nutrition</option>
                  <option value="Wardrobe & Styling">Wardrobe & Styling</option>
                  <option value="Camera & Rigging">Camera & Rigging</option>
                  <option value="Location Rental">Location Rental</option>
                  <option value="Other Production Gear">Other Production Gear</option>
                </select>
              </div>

              {/* Title & Amount */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2 space-y-1.5">
                  <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest px-1">Item Description</label>
                  <input
                    type="text"
                    required
                    value={itemTitle}
                    onChange={(e) => setItemTitle(e.target.value)}
                    placeholder="e.g. Matte Bronzer & Foundation Swatches"
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest px-1">Amount ($ USD)</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D4AF37]" />
                    <input
                      type="number"
                      required
                      min={1}
                      max={5000}
                      step={0.01}
                      value={requestedAmount}
                      onChange={(e) => setRequestedAmount(parseFloat(e.target.value) || 0)}
                      className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl pl-8 pr-3 py-3 text-sm text-white font-mono focus:border-[#D4AF37] outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Brand Association */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest px-1">Brand Campaign Association</label>
                <input
                  type="text"
                  required
                  value={brandAssociation}
                  onChange={(e) => setBrandAssociation(e.target.value)}
                  placeholder="e.g. Sephora Summer Glow 2026"
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none"
                />
              </div>

              {/* Justification */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest px-1">Production Justification</label>
                <textarea
                  rows={3}
                  required
                  value={justification}
                  onChange={(e) => setJustification(e.target.value)}
                  placeholder="Detail why this item is essential for campaign deliverables..."
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowRequestModal(false)}
                  className="flex-1 py-3.5 bg-white/5 hover:bg-white/10 text-white rounded-2xl text-xs font-bold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-2 py-3.5 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] rounded-2xl text-xs font-bold transition-all shadow-lg flex items-center justify-center gap-2"
                >
                  <Zap className="w-4 h-4" />
                  <span>Submit for 30m JIT Unlock</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Terminal Swipe & Receipt Reconciliation Simulator */}
      {showTerminalModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-[#142850] border border-emerald-500/30 rounded-3xl p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/10 rounded-2xl text-emerald-400">
                  <CreditCard className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Merchant Swipe Terminal</h3>
                  <p className="text-xs text-slate-400">Drop balance to $0.00 with target receipt file</p>
                </div>
              </div>
              <button 
                onClick={() => setShowTerminalModal(false)}
                className="p-2 rounded-xl text-white/40 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-[#0B1B3D] border border-white/10 rounded-2xl p-5 space-y-3 text-center">
              <p className="text-xs text-slate-400 uppercase font-mono">Target Swipe Transaction</p>
              <p className="text-3xl font-mono font-bold text-emerald-400">
                ${terminalSwipeAmount.toFixed(2)}
              </p>
              <p className="text-xs text-white/70">
                Authorized for: {activeRequest?.itemTitle || 'Production Item'}
              </p>
            </div>

            {/* Receipt Upload Dropzone */}
            <div className="space-y-2">
              <label className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest px-1">
                Upload Target Receipt File
              </label>

              <div className="border-2 border-dashed border-white/10 hover:border-emerald-500/50 rounded-2xl p-6 text-center space-y-3 bg-[#0B1B3D]/50 transition-all">
                <Upload className="w-8 h-8 text-emerald-400 mx-auto" />
                <div className="space-y-1">
                  <p className="text-xs text-white font-semibold">
                    {uploadedReceiptName || 'Drag and drop receipt image or PDF'}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Matches swipe amount (${terminalSwipeAmount.toFixed(2)})
                  </p>
                </div>

                <div className="flex flex-wrap justify-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => handleReconcileReceipt('Receipt_Sephora_482.pdf')}
                    className="px-3 py-1.5 bg-white/10 hover:bg-emerald-500/20 text-white hover:text-emerald-300 rounded-lg text-xs font-mono transition-all"
                  >
                    + Attach Sephora_482.pdf
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReconcileReceipt('StudioLighting_Receipt.jpg')}
                    className="px-3 py-1.5 bg-white/10 hover:bg-emerald-500/20 text-white hover:text-emerald-300 rounded-lg text-xs font-mono transition-all"
                  >
                    + Attach Lighting_Receipt.jpg
                  </button>
                </div>
              </div>
            </div>

            {receiptMatchingStatus === 'MATCHING' && (
              <div className="p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-xl flex items-center gap-2 text-cyan-300 text-xs animate-pulse">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Reconciling swipe with target receipt file...</span>
              </div>
            )}

            {receiptMatchingStatus === 'RECONCILED' && (
              <div className="p-3 bg-emerald-500/20 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-emerald-300 text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Swipe Reconciled! Card balance hardlocked back to $0.00.</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default JustInTimeStripeCard;
