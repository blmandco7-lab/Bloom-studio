import React, { useState } from 'react';
import { CreditCard, ShieldCheck, Zap, ArrowUpRight, Plus, User, DollarSign, Wallet, Lock, Loader2 } from 'lucide-react';

interface StripeProductionCardWidgetProps {
  cashBalance: string;
}

const StripeProductionCardWidget: React.FC<StripeProductionCardWidgetProps> = ({ cashBalance }) => {
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [isIssuing, setIsIssuing] = useState(false);

  // 4. Administrative Action Trigger
  const handleIssueCard = async () => {
    setIsIssuing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsIssuing(false);
    setShowIssueModal(false);
  };

  return (
    <div className="w-full space-y-6">
      {/* 1. LUXURY STYLING TOKENS */}
      <div className="bg-[#142850] border border-[#D4AF37]/20 rounded-3xl p-8 shadow-2xl relative overflow-hidden group">
        {/* Background decorative element */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#D4AF37]/5 rounded-full blur-3xl group-hover:bg-[#D4AF37]/10 transition-colors" />
        
        <div className="relative flex flex-col lg:flex-row gap-10 items-center">
          {/* 2. Live Card Display Grid */}
          <div className="relative w-full max-w-[400px] aspect-[1.586/1] bg-gradient-to-br from-[#1E3A8A] via-[#0B1B3D] to-[#050B1A] rounded-2xl p-8 shadow-2xl border border-white/10 flex flex-col justify-between group/card overflow-hidden">
            {/* Card Shimmer */}
            <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover/card:translate-x-full transition-transform duration-1000" />
            
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <p className="text-[10px] text-[#D4AF37] font-bold tracking-[0.2em] uppercase opacity-80">Bloom Studio Executive Card</p>
                <div className="w-12 h-8 bg-gradient-to-br from-amber-200/40 to-amber-500/20 rounded-md border border-amber-200/20 shadow-inner" />
              </div>
              <div className="flex flex-col items-end">
                <div className="flex gap-1">
                  <div className="w-6 h-6 bg-rose-500/80 rounded-full mix-blend-screen" />
                  <div className="w-6 h-6 bg-amber-500/80 rounded-full -ml-3 mix-blend-screen" />
                </div>
                <p className="text-[8px] text-white/40 mt-1 uppercase font-bold">Stripe Issuing</p>
              </div>
            </div>

            <div className="space-y-1">
              <p className="text-xl text-white font-mono tracking-[0.3em] font-medium">•••• •••• •••• 4829</p>
              <div className="flex justify-between items-end">
                <div className="space-y-0.5">
                  <p className="text-[8px] text-white/30 uppercase tracking-tighter">Card Holder</p>
                  <p className="text-xs text-white/80 font-bold uppercase">Executive Director</p>
                </div>
                <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 px-2 py-1 rounded-lg">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="text-[8px] text-emerald-400 font-bold uppercase tracking-widest">Instant Provisioning Active</span>
                </div>
              </div>
            </div>
          </div>

          {/* 3. Real-Time Balance Readouts */}
          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
            <div className="bg-[#0B1B3D] border border-white/5 rounded-2xl p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/10 rounded-xl">
                  <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
                </div>
                <div>
                  <p className="text-[10px] text-[#7C8AA8] uppercase font-bold tracking-widest">Available Production Credit Line</p>
                  <p className="text-2xl font-serif font-bold text-[#D4AF37]">$5,000.00</p>
                </div>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                <div className="w-1/3 h-full bg-[#D4AF37]" />
              </div>
              <p className="text-[10px] text-white/40">Secured against corporate assets</p>
            </div>

            <div className="bg-[#0B1B3D] border border-white/5 rounded-2xl p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-500/10 rounded-xl">
                  <DollarSign className="w-5 h-5 text-emerald-500" />
                </div>
                <div>
                  <p className="text-[10px] text-[#7C8AA8] uppercase font-bold tracking-widest">Current Account Cash Balance</p>
                  <p className="text-2xl font-serif font-bold text-white">{cashBalance}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-3.5 h-3.5 text-emerald-500" />
                <p className="text-[10px] text-emerald-500 font-bold">Real-time ledger synchronized</p>
              </div>
              <p className="text-[10px] text-white/40">Available for instant withdrawal</p>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-10 flex justify-end">
          <button 
            onClick={() => setShowIssueModal(true)}
            className="flex items-center gap-2 bg-[#D4AF37] hover:bg-[#E3C48F] text-[#0B1B3D] px-6 py-3 rounded-2xl font-bold transition-all shadow-lg shadow-[#D4AF37]/10"
          >
            <Plus className="w-5 h-5" />
            <span>Issue New Instant Virtual Production Card</span>
          </button>
        </div>
      </div>

      {/* 4. Overlay Modal */}
      {showIssueModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-8 shadow-2xl">
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 bg-[#D4AF37]/10 rounded-2xl">
                <CreditCard className="w-6 h-6 text-[#D4AF37]" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Issue Virtual Card</h3>
                <p className="text-xs text-[#7C8AA8]">Provision instant spending for agents</p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest px-1">Agent / Payee Name</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                  <input
                    type="text"
                    placeholder="Enter agent name..."
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white outline-none focus:border-[#D4AF37] transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-widest px-1">Temporary Operational Spending Cap</label>
                <div className="relative">
                  <Wallet className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                  <input
                    type="number"
                    placeholder="e.g. 500"
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white outline-none focus:border-[#D4AF37] transition-all"
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => setShowIssueModal(false)}
                  className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-white font-bold rounded-2xl transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleIssueCard}
                  disabled={isIssuing}
                  className="flex-2 py-4 bg-[#D4AF37] hover:bg-[#E3C48F] text-[#0B1B3D] font-bold rounded-2xl transition-all flex items-center justify-center gap-2"
                >
                  {isIssuing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Provisioning...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5" />
                      <span>Issue Card</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. ABSOLUTE SYSTEM PRIVACY BOUNDS - Handled by parent container mount/unmount */}
      <div className="flex items-center gap-3 p-4 bg-amber-500/5 border border-amber-500/10 rounded-2xl">
        <Lock className="w-4 h-4 text-amber-500" />
        <p className="text-[10px] text-amber-200/60 leading-relaxed font-mono">
          [RESTRICTED ACCESS] Top-tier corporate funding limits. Unauthorized access attempts are logged and flagged to Director Security Logs.
        </p>
      </div>
    </div>
  );
};

export default StripeProductionCardWidget;
