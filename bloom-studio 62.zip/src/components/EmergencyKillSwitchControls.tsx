import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, Power, CheckCircle, Lock, Wrench, X } from 'lucide-react';
import { MaintenanceConfig, saveStoredMaintenanceConfig } from '../lib/maintenanceConfig';

interface EmergencyKillSwitchProps {
  config: MaintenanceConfig;
  currentUser?: any;
  onUpdateConfig?: (updated: MaintenanceConfig) => void;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

export const EmergencyKillSwitchPanel: React.FC<EmergencyKillSwitchProps> = ({
  config,
  currentUser,
  onUpdateConfig,
  triggerNotification,
}) => {
  const [customReason, setCustomReason] = useState(config.reason || '');
  const [isSaving, setIsSaving] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [pendingAction, setPendingAction] = useState<'activate' | 'deactivate' | null>(null);

  const isPlatformOwner = Boolean(
    currentUser?.isPlatformOwner ||
    currentUser?.email === 'lilbitnd06@gmail.com' ||
    currentUser?.role === 'owner'
  );

  // Platform owner restriction: hidden for normal staff or non-platform owners
  if (!isPlatformOwner) {
    return null;
  }

  const handleOpenConfirm = (action: 'activate' | 'deactivate') => {
    setPendingAction(action);
    setShowConfirmModal(true);
  };

  const handleExecuteToggle = async () => {
    if (!pendingAction) return;
    setIsSaving(true);
    const targetState = pendingAction === 'activate';

    try {
      const updated = await saveStoredMaintenanceConfig(
        {
          enabled: targetState,
          reason: customReason.trim() || undefined,
        },
        currentUser?.email
      );

      if (onUpdateConfig) {
        onUpdateConfig(updated);
      }

      if (triggerNotification) {
        if (targetState) {
          triggerNotification(
            '🚨 Emergency Kill Switch Activated',
            'The site has been locked down into Maintenance / Construction mode. Public navigation and contract signing are suspended.',
            'danger'
          );
        } else {
          triggerNotification(
            '✅ Platform Restored Live',
            'Emergency Kill Switch deactivated. Normal public navigation and contract signing have resumed.',
            'success'
          );
        }
      }
    } catch (e: any) {
      console.error('Failed to toggle emergency kill switch:', e);
      if (triggerNotification) {
        triggerNotification('Toggle Error', e?.message || 'Failed to update maintenance state', 'danger');
      }
    } finally {
      setIsSaving(false);
      setShowConfirmModal(false);
      setPendingAction(null);
    }
  };

  const handleSaveReasonOnly = async () => {
    setIsSaving(true);
    try {
      const updated = await saveStoredMaintenanceConfig(
        {
          reason: customReason.trim(),
        },
        currentUser?.email
      );
      if (onUpdateConfig) onUpdateConfig(updated);
      if (triggerNotification) {
        triggerNotification('Notice Updated', 'Site-wide construction notice updated successfully.', 'info');
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-[#0A1220] border-2 border-rose-500/30 rounded-2xl p-5 sm:p-6 space-y-6 shadow-xl relative overflow-hidden">
      {/* Background Warning Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-rose-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center border shadow-inner ${
            config.enabled
              ? 'bg-rose-500/20 border-rose-500 text-rose-400 animate-pulse'
              : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
          }`}>
            <Power className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-serif font-bold text-lg text-white">
                Platform Emergency Kill Switch
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 border border-rose-500/40 text-rose-300">
                Platform Owner Only
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Instantly lock down the entire agency platform, show a site-wide construction notice, and block all contract signing.
            </p>
          </div>
        </div>

        {/* Current State Pill */}
        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-between sm:justify-end">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold ${
            config.enabled
              ? 'bg-rose-950/60 border-rose-500/50 text-rose-300 shadow-[0_0_15px_rgba(244,63,94,0.2)]'
              : 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
          }`}>
            <span className={`w-2 h-2 rounded-full ${
              config.enabled ? 'bg-rose-500 animate-ping' : 'bg-emerald-400'
            }`} />
            <span>{config.enabled ? 'KILL SWITCH ACTIVE (SITE LOCKED)' : 'SITE OPERATIONAL (NORMAL)'}</span>
          </div>

          <button
            onClick={() => handleOpenConfirm(config.enabled ? 'deactivate' : 'activate')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md ${
              config.enabled
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-rose-600 hover:bg-rose-500 text-white'
            }`}
          >
            <Power className="w-4 h-4" />
            <span>{config.enabled ? 'Deactivate Kill Switch (Go Live)' : 'Activate Emergency Kill Switch'}</span>
          </button>
        </div>
      </div>

      {/* Details & Explanation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#0D1830] border border-white/5 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-rose-400">
            <Lock className="w-3.5 h-3.5" />
            <span>Contract Signing Guard</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Blocks external users and signers from executing digital contracts or agreements while active.
          </p>
        </div>

        <div className="bg-[#0D1830] border border-white/5 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
            <Wrench className="w-3.5 h-3.5" />
            <span>Site-Wide Construction Gate</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Hides main navigation from visitors and shows a branded "Site Under Construction" maintenance barrier.
          </p>
        </div>

        <div className="bg-[#0D1830] border border-white/5 rounded-xl p-4 space-y-1.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Platform Owner Bypass</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Platform Owners retain privileged administrative visibility to patch issues, audit logs, and restore service.
          </p>
        </div>
      </div>

      {/* Customizable Construction Notice */}
      <div className="space-y-2 bg-[#0D1830] border border-white/5 rounded-xl p-4">
        <label className="block text-xs font-semibold text-slate-200">
          Public Construction Notice Message (Displayed to users when Kill Switch is Active)
        </label>
        <textarea
          rows={3}
          value={customReason}
          onChange={(e) => setCustomReason(e.target.value)}
          placeholder="Enter the explanation shown to visitors and signers..."
          className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] placeholder:text-slate-500"
        />
        <div className="flex items-center justify-between pt-1">
          <span className="text-[11px] text-slate-400">
            {config.activatedAt
              ? `Last activated: ${new Date(config.activatedAt).toLocaleString()} by ${config.activatedBy || 'Platform Owner'}`
              : 'Currently in stand-by mode.'}
          </span>
          <button
            onClick={handleSaveReasonOnly}
            disabled={isSaving}
            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white text-xs font-medium transition-all disabled:opacity-50 cursor-pointer"
          >
            {isSaving ? 'Updating...' : 'Update Notice Text'}
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border-2 border-rose-500/60 rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
            <button
              onClick={() => setShowConfirmModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 text-rose-400">
              <AlertTriangle className="w-7 h-7 shrink-0" />
              <h3 className="font-serif font-bold text-xl text-white">
                {pendingAction === 'activate' ? 'Confirm Emergency Kill Switch' : 'Restore Platform Live'}
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {pendingAction === 'activate'
                ? 'Are you sure you want to activate the Platform Emergency Kill Switch? This will instantly lock down the entire agency site, hide main navigation for normal users, display the "Site Under Construction" screen, and prevent anyone from signing contracts or submitting transactions.'
                : 'Are you sure you want to deactivate the Kill Switch? This will immediately take the site out of maintenance mode and restore full public navigation and contract signing.'}
            </p>

            <div className="bg-[#111E33] border border-white/5 rounded-xl p-3 text-xs text-slate-300">
              <span className="font-semibold text-rose-400">Notice displayed:</span>{' '}
              {customReason.trim() || config.reason}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                disabled={isSaving}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-white/5"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteToggle}
                disabled={isSaving}
                className={`px-5 py-2 rounded-xl text-xs font-bold text-white transition-all shadow-lg ${
                  pendingAction === 'activate'
                    ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30'
                    : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
                }`}
              >
                {isSaving
                  ? 'Executing...'
                  : pendingAction === 'activate'
                  ? 'Confirm & Lock Down Site'
                  : 'Confirm & Restore Live'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const EmergencyKillSwitchNavButton: React.FC<{
  config: MaintenanceConfig;
  currentUser?: any;
  onOpenPanel: () => void;
}> = ({ config, currentUser, onOpenPanel }) => {
  const isPlatformOwner = Boolean(
    currentUser?.isPlatformOwner ||
    currentUser?.email === 'lilbitnd06@gmail.com' ||
    currentUser?.role === 'owner'
  );

  if (!isPlatformOwner) return null;

  return (
    <button
      onClick={onOpenPanel}
      className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all cursor-pointer shadow-sm ${
        config.enabled
          ? 'bg-rose-950/80 border-rose-500 text-rose-200 animate-pulse'
          : 'bg-[#111E33] hover:bg-[#162742] border-rose-500/30 hover:border-rose-500/60 text-rose-300'
      }`}
      title={
        config.enabled
          ? '🚨 KILL SWITCH ACTIVE: Platform locked in maintenance mode'
          : 'Platform Emergency Kill Switch (Platform Owner Control)'
      }
    >
      <Power className={`w-3.5 h-3.5 ${config.enabled ? 'text-rose-400 animate-spin' : 'text-rose-400'}`} />
      <span className="hidden md:inline font-mono">
        {config.enabled ? 'KILL SWITCH ACTIVE' : 'Kill Switch'}
      </span>
    </button>
  );
};
