import React, { useState } from 'react';
import { Copy, CheckCircle2, Users, Gift, ExternalLink, Send, X, ShieldCheck, DollarSign, Award, Clock, ArrowRight } from 'lucide-react';
import { Referral } from '../types';
import { safeStorage } from '../utils/safeStorage';

interface CreatorReferralTrackerProps {
  creatorHandle?: string;
  creatorName?: string;
  referrals?: Referral[];
  onAddReferral?: (newRef: Referral) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  primaryBrandColor?: string;
}

const DEFAULT_REFERRED_CREATORS: Array<{
  id: string;
  name: string;
  handle: string;
  date: string;
  status: 'Pending review' | 'Approved' | 'Paid';
  directorReward: string;
  rewardValue: number;
  niche: string;
}> = [
  {
    id: 'ref_sample_1',
    name: 'Chloe Bennett',
    handle: '@chloeglows',
    date: '2026-08-14',
    status: 'Paid',
    directorReward: 'Verified',
    rewardValue: 0,
    niche: 'Beauty & Skincare'
  },
  {
    id: 'ref_sample_2',
    name: 'Marcus Brody',
    handle: '@brody_wellness',
    date: '2026-08-20',
    status: 'Approved',
    directorReward: 'Verified',
    rewardValue: 0,
    niche: 'Fitness & Lifestyle'
  },
  {
    id: 'ref_sample_3',
    name: 'Maya Lin',
    handle: '@maya_pets',
    date: '2026-08-27',
    status: 'Pending review',
    directorReward: 'Verified',
    rewardValue: 0,
    niche: 'Pets & Animals'
  }
];

export default function CreatorReferralTracker({
  creatorHandle = "@elenarostova",
  creatorName = "Elena Rostova",
  referrals = [],
  onAddReferral,
  triggerNotification = () => {},
  onAddActivityLog = () => {},
  primaryBrandColor = '#C9A46A'
}: CreatorReferralTrackerProps) {
  const [copied, setCopied] = useState(false);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const cleanHandle = (creatorHandle || '').replace('@', '').trim();
  const referralUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/#referrals?ref=${cleanHandle || 'creator'}`
    : `https://bloomstudio.agency/join?ref=${cleanHandle || 'creator'}`;

  // Form states
  const [newHandle, setNewHandle] = useState('');
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newNiche, setNewNiche] = useState('Beauty');
  const [newNotes, setNewNotes] = useState('');

  // Merge external referrals matching this creator with state
  const myReferrals = React.useMemo(() => {
    const handleLower = (creatorHandle || '').toLowerCase().replace('@', '');
    const nameLower = (creatorName || '').toLowerCase();

    const matched = (referrals || []).filter(r => {
      const refLower = (r.referrer || '').toLowerCase().replace('@', '');
      return refLower.includes(handleLower) || (nameLower && refLower.includes(nameLower));
    });

    if (matched.length > 0) {
      return matched.map(r => ({
        id: r.id,
        name: r.newclient || 'Referred Creator',
        handle: r.newclient.startsWith('@') ? r.newclient : `@${r.newclient.toLowerCase().replace(/\s+/g, '')}`,
        date: r.date || 'Recent',
        status: r.status,
        directorReward: r.reward || 'Verified',
        rewardValue: r.value || 0,
        niche: r.what || 'Creator Roster'
      }));
    }

    return DEFAULT_REFERRED_CREATORS;
  }, [referrals, creatorHandle, creatorName]);

  // Find who referred this creator to the agency
  const myReferrerRecord = React.useMemo(() => {
    const handleLower = (creatorHandle || '').toLowerCase().replace('@', '');
    const nameLower = (creatorName || '').toLowerCase();

    return (referrals || []).find(r => {
      const clientLower = (r.newclient || '').toLowerCase();
      return clientLower.includes(handleLower) || (nameLower && clientLower.includes(nameLower));
    });
  }, [referrals, creatorHandle, creatorName]);

  const totalEarnedFromReferrals = myReferrals
    .filter(r => r.status === 'Paid' || r.status === 'Approved')
    .reduce((acc, curr) => acc + curr.rewardValue, 0);

  const handleCopy = () => {
    navigator.clipboard.writeText(referralUrl);
    setCopied(true);
    triggerNotification('Link Copied!', 'Personalized creator referral link copied to clipboard.', 'success');
    setTimeout(() => setCopied(false), 3000);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHandle.trim()) return;

    let cleanH = newHandle.trim();
    if (!cleanH.startsWith('@')) cleanH = `@${cleanH}`;

    const newRef: Referral = {
      id: 'ref_' + Date.now(),
      referrer: creatorHandle,
      type: 'Creator',
      what: newNiche,
      newclient: `${newName.trim() || cleanH} (${cleanH})`,
      value: 0,
      reward: 'Director Discretion (Pending Review)',
      date: new Date().toISOString().split('T')[0],
      status: 'Pending review',
      notes: newNotes.trim() ? `Email: ${newEmail}. Notes: ${newNotes}` : `Email: ${newEmail}`
    };

    if (onAddReferral) {
      onAddReferral(newRef);
    }

    // Update local storage referrals
    try {
      const saved = JSON.parse(safeStorage.getItem('wl_referrals') || '[]');
      safeStorage.setItem('wl_referrals', JSON.stringify([newRef, ...saved]));
    } catch {}

    triggerNotification(
      'Creator Referral Dispatched',
      `Referred ${cleanH} directly to Agency Director for review.`,
      'success'
    );
    onAddActivityLog(creatorName, 'creator', `Submitted referral for creator ${cleanH} to Director for review.`);

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setIsApplyModalOpen(false);
      setNewHandle('');
      setNewName('');
      setNewEmail('');
      setNewNotes('');
    }, 2000);
  };

  return (
    <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl space-y-6 animate-fade-in">
      {/* Header with Director Reward Policy */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <div>
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
              Director-Approved Referral Program
            </span>
          </div>
          <h2 className="font-serif font-bold text-xl text-white mt-1.5 flex items-center gap-2">
            <Gift className="w-5 h-5 text-[#C9A46A]" /> Creator Referral Portal
          </h2>
          <p className="text-xs text-[#7C8AA8] mt-1">
            Share your personal referral link with creators you recommend. Submissions go directly to the Director for roster review.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsApplyModalOpen(true)}
          className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2.5 rounded-xl text-xs font-bold font-mono inline-flex items-center gap-2 transition-all shrink-0 cursor-pointer shadow-md"
        >
          <Send className="w-3.5 h-3.5" /> Refer a Creator
        </button>
      </div>

      {/* Who Referred You Banner */}
      <div className="bg-[#111E33] border border-[#C9A46A]/30 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] font-bold shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-mono uppercase font-bold text-[#C9A46A] block">
              Your Roster Referral Origin
            </span>
            <h4 className="text-sm font-serif font-bold text-white mt-0.5">
              {myReferrerRecord ? (
                <>Referred to Bloom Studio by <span className="text-[#C9A46A]">{myReferrerRecord.referrerName || myReferrerRecord.referrer}</span></>
              ) : (
                <>Direct Application / Organic Roster Onboarding</>
              )}
            </h4>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              {myReferrerRecord ? (
                <>Date Referred: <strong>{myReferrerRecord.date}</strong></>
              ) : (
                <>Signed to Bloom &amp; Co. Exclusive Roster.</>
              )}
            </p>
          </div>
        </div>
        <div className="shrink-0 bg-[#091122] px-3.5 py-1.5 rounded-lg border border-white/10 text-right">
          <span className="text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Verified Talent
          </span>
        </div>
      </div>

      {/* Referral Link & Quick Copy Card */}
      <div className="bg-[#111E33] border border-white/10 rounded-xl p-4 sm:p-5 space-y-2">
        <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
          Your Personalized Roster Referral Link
        </label>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <input
            type="text"
            readOnly
            value={referralUrl}
            className="w-full bg-[#091122] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-[#C9A46A] font-mono outline-none select-all"
          />
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center justify-center gap-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs px-5 py-2.5 rounded-xl transition-all cursor-pointer shadow-md shrink-0"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-[#0A1220]" />
                <span>Link Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Link</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Who You Referred Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-slate-300 flex items-center gap-2">
            <Users className="w-4 h-4 text-[#C9A46A]" /> Who You Referred
          </h3>
          <span className="text-xs font-mono text-[#C9A46A] font-bold bg-[#C9A46A]/10 border border-[#C9A46A]/20 px-3 py-1 rounded-lg">
            Total Referred: {myReferrals.length} Creators
          </span>
        </div>

        <div className="bg-[#111E33] border border-white/10 rounded-xl overflow-hidden shadow-md">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="bg-white/5 text-[#7C8AA8] border-b border-white/10 text-[10px] uppercase">
                  <th className="py-3 px-4">Referred Creator</th>
                  <th className="py-3 px-4">Niche</th>
                  <th className="py-3 px-4">Date Referred</th>
                  <th className="py-3 px-4 text-right">Referral Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {myReferrals.map((ref) => (
                  <tr key={ref.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4">
                      <div>
                        <p className="font-bold text-white font-sans text-sm">{ref.name}</p>
                        <span className="text-[11px] text-[#C9A46A]">{ref.handle}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300">{ref.niche}</td>
                    <td className="py-3.5 px-4 text-slate-400">{ref.date}</td>
                    <td className="py-3.5 px-4 text-right">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                        ref.status === 'Paid'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : ref.status === 'Approved'
                          ? 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                          : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                      }`}>
                        {ref.status === 'Paid' ? 'Signed & Active' : ref.status === 'Approved' ? 'Approved by Director' : 'Pending Director Review'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Refer a Creator Modal */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 text-white">
          <div className="bg-[#0D1830] border-2 border-[#C9A46A]/50 rounded-2xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5 animate-fade-in max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Gift className="w-5 h-5 text-[#C9A46A]" />
                  <h3 className="text-lg font-serif font-bold text-white">Refer Creator to Director</h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Submit creator recommendations directly to agency management.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsApplyModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {submitted ? (
              <div className="p-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="font-serif text-lg font-bold text-white">Referral Dispatched!</h4>
                <p className="text-xs text-slate-300">
                  Your referral has been sent directly to the Agency Director for roster review.
                </p>
              </div>
            ) : (
              <form onSubmit={handleFormSubmit} className="space-y-4 text-xs font-mono">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Creator Handle</label>
                    <input
                      type="text"
                      required
                      placeholder="@creator_handle"
                      value={newHandle}
                      onChange={(e) => setNewHandle(e.target.value)}
                      className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Creator Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Jordan Miller"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Contact Email</label>
                    <input
                      type="email"
                      placeholder="creator@example.com"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Niche Category</label>
                    <select
                      value={newNiche}
                      onChange={(e) => setNewNiche(e.target.value)}
                      className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                    >
                      <option value="Beauty & Skincare">Beauty &amp; Skincare</option>
                      <option value="Pets & Animals">Pets &amp; Animals</option>
                      <option value="Lifestyle & Fashion">Lifestyle &amp; Fashion</option>
                      <option value="Tech & Gaming">Tech &amp; Gaming</option>
                      <option value="Food & Wellness">Food &amp; Wellness</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Notes / Why You Recommend Them</label>
                  <textarea
                    rows={2}
                    placeholder="e.g. Great video retention, works well with luxury skincare brands..."
                    value={newNotes}
                    onChange={(e) => setNewNotes(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>

                <div className="bg-[#091122] border border-white/10 rounded-xl p-3 flex items-center gap-2 text-[11px] text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-[#C9A46A] shrink-0" />
                  <span>Referral details are sent directly to the Agency Director for review.</span>
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsApplyModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-white/10 text-slate-300 hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-[#C9A46A] text-[#0A1220] font-bold uppercase tracking-wider hover:brightness-110 cursor-pointer shadow-lg flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Submit Referral</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
