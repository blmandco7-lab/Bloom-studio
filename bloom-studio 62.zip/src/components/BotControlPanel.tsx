import React, { useState, useEffect } from 'react';
import { 
  Bot, Play, Pause, RefreshCw, Zap, ShieldCheck, Activity, 
  Settings, CheckCircle2, AlertTriangle, Clock, Terminal, 
  Sliders, Send, Search, Eye, Filter, Sparkles, Cpu, Radio
} from 'lucide-react';

export interface AutonomousBot {
  id: string;
  name: string;
  codename: string;
  type: 'Outreach' | 'Compliance' | 'Scraper' | 'Analytics';
  description: string;
  status: 'Running' | 'Paused' | 'Error';
  lastRun: string;
  nextRun: string;
  actionsToday: number;
  dailyLimit: number;
  successRate: string;
  frequency: 'Real-time (Stream)' | 'Every 15 mins' | 'Every 1 hour' | 'Daily Sweep';
  safetyMode: boolean;
}

export interface BotEventLog {
  id: string;
  timestamp: string;
  botCodename: string;
  botName: string;
  eventType: 'INFO' | 'ACTION' | 'WARNING' | 'SUCCESS';
  message: string;
  target?: string;
}

const INITIAL_BOTS: AutonomousBot[] = [
  {
    id: 'bot-1',
    name: 'Outreach & Prospecting Bot',
    codename: 'BOT-TITAN-OUTREACH',
    type: 'Outreach',
    description: 'Autonomous multi-channel outreach engine targeting vetted beauty, pet, and lifestyle brand CMOs with personalized pitch decks.',
    status: 'Running',
    lastRun: '2 mins ago',
    nextRun: 'In 13 mins',
    actionsToday: 48,
    dailyLimit: 100,
    successRate: '98.4%',
    frequency: 'Every 15 mins',
    safetyMode: true
  },
  {
    id: 'bot-2',
    name: 'FTC Compliance Guardian Bot',
    codename: 'BOT-VERITAS-FTC',
    type: 'Compliance',
    description: 'Real-time video and caption audit scanner verifying #ad, #sponsored, and clean FTC disclosures across all live creator deliverables.',
    status: 'Running',
    lastRun: 'Just now',
    nextRun: 'Real-time (Stream)',
    actionsToday: 184,
    dailyLimit: 500,
    successRate: '99.9%',
    frequency: 'Real-time (Stream)',
    safetyMode: true
  },
  {
    id: 'bot-3',
    name: 'Talent Authenticity Scraper Bot',
    codename: 'BOT-AEGIS-VETTING',
    type: 'Scraper',
    description: 'Deep engagement verification bot inspecting audience demographics, ghost follower percentage, and comment authenticity ratios.',
    status: 'Running',
    lastRun: '18 mins ago',
    nextRun: 'In 42 mins',
    actionsToday: 62,
    dailyLimit: 150,
    successRate: '97.2%',
    frequency: 'Every 1 hour',
    safetyMode: true
  },
  {
    id: 'bot-4',
    name: 'Social Metrics & ROI Telemetry Bot',
    codename: 'BOT-PULSE-METRICS',
    type: 'Analytics',
    description: 'Continuous view count, click-through-rate, and ROAS synchronizer for all active campaign deliverables and Spark Ads whitelists.',
    status: 'Running',
    lastRun: '4 mins ago',
    nextRun: 'In 26 mins',
    actionsToday: 310,
    dailyLimit: 1000,
    successRate: '100%',
    frequency: 'Every 15 mins',
    safetyMode: true
  }
];

const INITIAL_LOGS: BotEventLog[] = [
  {
    id: 'log-1',
    timestamp: new Date(Date.now() - 1000 * 45).toLocaleTimeString(),
    botCodename: 'BOT-VERITAS-FTC',
    botName: 'FTC Compliance Guardian',
    eventType: 'SUCCESS',
    message: 'Verified FTC #ad disclosure in @elenarostova 60s Reel draft. Audio and visual tags compliant.',
    target: '@elenarostova'
  },
  {
    id: 'log-2',
    timestamp: new Date(Date.now() - 1000 * 120).toLocaleTimeString(),
    botCodename: 'BOT-TITAN-OUTREACH',
    botName: 'Outreach & Prospecting Bot',
    eventType: 'ACTION',
    message: 'Dispatched custom UGC proposal to partnerships@aurabeauty.com (Brand CMO).',
    target: 'Aura Glow Cosmetics'
  },
  {
    id: 'log-3',
    timestamp: new Date(Date.now() - 1000 * 240).toLocaleTimeString(),
    botCodename: 'BOT-PULSE-METRICS',
    botName: 'Social Metrics & ROI Telemetry',
    eventType: 'INFO',
    message: 'Synchronized 142,500 organic views on DripRoom TikTok Campaign. ROAS calculated at 3.4x.',
    target: 'Campaign DripRoom-Q3'
  },
  {
    id: 'log-4',
    timestamp: new Date(Date.now() - 1000 * 360).toLocaleTimeString(),
    botCodename: 'BOT-AEGIS-VETTING',
    botName: 'Talent Authenticity Scraper',
    eventType: 'SUCCESS',
    message: 'Completed authenticity scan for waitlist candidate @siennaglows. Real follower ratio: 94.8%.',
    target: '@siennaglows'
  }
];

interface BotControlPanelProps {
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: string) => void;
}

export default function BotControlPanel({
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}: BotControlPanelProps) {
  const [bots, setBots] = useState<AutonomousBot[]>(() => {
    const saved = localStorage.getItem('wl_autonomous_bots');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_BOTS;
  });

  const [logs, setLogs] = useState<BotEventLog[]>(() => {
    const saved = localStorage.getItem('wl_bot_event_logs');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error(e); }
    }
    return INITIAL_LOGS;
  });

  const [isExecutingSweep, setIsExecutingSweep] = useState(false);
  const [selectedBotFilter, setSelectedBotFilter] = useState<string>('All');

  useEffect(() => {
    localStorage.setItem('wl_autonomous_bots', JSON.stringify(bots));
  }, [bots]);

  useEffect(() => {
    localStorage.setItem('wl_bot_event_logs', JSON.stringify(logs));
  }, [logs]);

  // Periodic heartbeat adding simulated activity
  useEffect(() => {
    const interval = setInterval(() => {
      const activeBots = bots.filter(b => b.status === 'Running');
      if (activeBots.length === 0) return;

      const randomBot = activeBots[Math.floor(Math.random() * activeBots.length)];
      const sampleActions: Record<string, string[]> = {
        'Outreach': [
          'Pinged CRM lead: GlowSkin Media. Pitch queue updated.',
          'Personalized brief delivered to partnerships@petwellness.co.',
          'Logged open rate confirmation from Brand VP Marketing.'
        ],
        'Compliance': [
          'Live deliverable scan passed: #ad disclosure verified in caption and first 3 seconds.',
          'Audio watermark inspected for licensed sound compliance.',
          'FTC disclaimer audit clear for Spark Ads whitelist payload.'
        ],
        'Scraper': [
          'Scraped follower growth velocity for top 10 creator roster.',
          'Audience demographic check completed: 82% US/UK Tier-1 geo.',
          'Calculated 7.4% average engagement rate for Beauty creators.'
        ],
        'Analytics': [
          'Telemetry synced: TikTok Reel crossed 250k impressions.',
          'ROAS calculation updated across 4 active beauty campaigns.',
          'Escrow payout trigger confirmed: Milestone 2 verified.'
        ]
      };

      const pool = sampleActions[randomBot.type] || ['Task completed successfully.'];
      const actionMsg = pool[Math.floor(Math.random() * pool.length)];

      const newLog: BotEventLog = {
        id: 'log-' + Date.now(),
        timestamp: new Date().toLocaleTimeString(),
        botCodename: randomBot.codename,
        botName: randomBot.name,
        eventType: 'ACTION',
        message: actionMsg
      };

      setLogs(prev => [newLog, ...prev.slice(0, 40)]);
      setBots(prev => prev.map(b => b.id === randomBot.id ? { ...b, actionsToday: b.actionsToday + 1, lastRun: 'Just now' } : b));
    }, 12000);

    return () => clearInterval(interval);
  }, [bots]);

  const handleToggleBot = (botId: string) => {
    const bot = bots.find(b => b.id === botId);
    const newStatus = bot?.status === 'Running' ? 'Paused' : 'Running';
    
    setBots(prev => prev.map(b => b.id === botId ? { ...b, status: newStatus } : b));

    triggerNotification?.(
      `${bot?.name} ${newStatus}`,
      `Autonomous bot is now ${newStatus.toLowerCase()}.`,
      newStatus === 'Running' ? 'success' : 'info'
    );
    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Toggled bot ${bot?.name} (${bot?.codename}) to ${newStatus}`
    );
  };

  const handleRunManualSweep = (botId?: string) => {
    setIsExecutingSweep(true);
    triggerNotification?.('Manual Sweep Dispatched', 'Executing immediate high-priority audit cycle across autonomous agents.', 'info');

    setTimeout(() => {
      setIsExecutingSweep(false);
      const sweepLog: BotEventLog = {
        id: 'log-' + Date.now(),
        timestamp: new Date().toLocaleTimeString(),
        botCodename: botId ? (bots.find(b => b.id === botId)?.codename || 'BOT-DIRECTOR-OVERRIDE') : 'BOT-CLUSTER-SWEEP',
        botName: botId ? (bots.find(b => b.id === botId)?.name || 'Target Bot') : 'Master Bot Cluster',
        eventType: 'SUCCESS',
        message: 'Manual sweep finished. 100% telemetry verified, 0 anomalies detected.'
      };
      setLogs(prev => [sweepLog, ...prev]);
      triggerNotification?.('Sweep Completed', 'All target bot routines executed and synchronized successfully.', 'success');
    }, 2000);
  };

  const filteredLogs = logs.filter(l => {
    if (selectedBotFilter === 'All') return true;
    return l.botCodename === selectedBotFilter;
  });

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      {/* Top Banner */}
      <div className="relative bg-[#0b1320] border-2 border-cyan-500/30 rounded-3xl p-6 md:p-8 overflow-hidden shadow-2xl">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-[0.2em] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center gap-1.5">
                <Cpu className="w-3 h-3" /> Autonomous Agent Cluster
              </span>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
              Autonomous Bot Control Panel & Telemetry
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl">
              Monitor, calibrate, and orchestrate automated outreach, FTC disclosure scanners, scraper engines, and real-time metric synchronizers.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => handleRunManualSweep()}
              disabled={isExecutingSweep}
              className="bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-mono text-xs font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-cyan-900/30 flex items-center gap-2 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isExecutingSweep ? 'animate-spin' : ''}`} />
              {isExecutingSweep ? 'Sweeping Cluster...' : 'Execute Instant Sweep'}
            </button>
          </div>
        </div>
      </div>

      {/* Bot Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {bots.map(bot => {
          const isRunning = bot.status === 'Running';
          return (
            <div 
              key={bot.id}
              className="bg-[#0b1320] border border-white/10 rounded-2xl p-5 space-y-4 relative overflow-hidden group hover:border-cyan-500/40 transition-all"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center border font-mono font-bold text-sm ${
                    isRunning 
                      ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30' 
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-white">{bot.name}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase ${
                        isRunning 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {bot.status}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">{bot.codename} • {bot.type}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleToggleBot(bot.id)}
                  className={`p-2 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                    isRunning 
                      ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20' 
                      : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'
                  }`}
                >
                  {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {bot.description}
              </p>

              <div className="grid grid-cols-3 gap-2 bg-[#050e1a] p-2.5 rounded-xl border border-white/5 text-[10px] font-mono">
                <div>
                  <span className="text-slate-500 block">ACTIONS TODAY</span>
                  <span className="text-white font-bold">{bot.actionsToday} / {bot.dailyLimit}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">SUCCESS RATE</span>
                  <span className="text-emerald-400 font-bold">{bot.successRate}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">FREQUENCY</span>
                  <span className="text-cyan-400 font-bold">{bot.frequency}</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1 text-[10px] font-mono text-slate-400">
                <span>Last run: <strong className="text-slate-300">{bot.lastRun}</strong></span>
                <button
                  onClick={() => handleRunManualSweep(bot.id)}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer font-bold"
                >
                  <Zap className="w-3 h-3" /> Trigger Single Run
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Real-time Activity Stream */}
      <div className="bg-[#0b1320] border border-white/10 rounded-2xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider">
              Autonomous Event Log & Diagnostic Stream
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-slate-400">Filter Bot:</span>
            <select
              value={selectedBotFilter}
              onChange={e => setSelectedBotFilter(e.target.value)}
              className="bg-[#050e1a] border border-white/10 rounded-xl px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
            >
              <option value="All">All Bot Streams</option>
              {bots.map(b => (
                <option key={b.id} value={b.codename}>{b.codename}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="bg-[#050e1a] border border-cyan-950/60 rounded-xl p-3 font-mono text-xs max-h-72 overflow-y-auto space-y-2">
          {filteredLogs.length === 0 ? (
            <div className="text-slate-500 text-center py-6">No diagnostic events for selected filter.</div>
          ) : (
            filteredLogs.map(log => (
              <div 
                key={log.id}
                className="flex items-start gap-3 p-2 rounded-lg bg-black/30 border border-white/5 hover:border-cyan-500/30 transition-colors"
              >
                <span className="text-[10px] text-slate-500 shrink-0 mt-0.5">{log.timestamp}</span>
                <span className={`px-2 py-0.2 rounded text-[9px] font-bold shrink-0 ${
                  log.eventType === 'SUCCESS' ? 'bg-emerald-500/20 text-emerald-300' :
                  log.eventType === 'WARNING' ? 'bg-amber-500/20 text-amber-300' :
                  log.eventType === 'ACTION' ? 'bg-cyan-500/20 text-cyan-300' :
                  'bg-slate-700 text-slate-300'
                }`}>
                  [{log.eventType}]
                </span>
                <span className="text-cyan-400 font-bold shrink-0 text-[10px]">{log.botCodename}:</span>
                <span className="text-slate-200 text-[11px] leading-relaxed flex-1">{log.message}</span>
                {log.target && (
                  <span className="text-[9px] text-[#C9A46A] bg-[#C9A46A]/10 px-1.5 py-0.5 rounded border border-[#C9A46A]/20 shrink-0">
                    {log.target}
                  </span>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
