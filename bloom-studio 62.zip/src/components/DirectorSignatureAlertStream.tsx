import React, { useState } from 'react';
import { 
  Bell, 
  FileCheck, 
  Download, 
  ShieldCheck, 
  ExternalLink, 
  CheckCircle2,
  Clock,
  Lock,
  Sparkles
} from 'lucide-react';
import { downloadCopyrightClearancePDF } from '../utils/pdfExportUtils';

interface DirectorSignatureAlertStreamProps {
  userRole?: string;
  onViewVaultAsset?: (alertId: string) => void;
}

interface SignatureAlertItem {
  id: string;
  creatorHandle: string;
  creatorLegalName: string;
  campaignName: string;
  brandName: string;
  rightsBuyoutSold: number;
  creatorRightsPayout: number;
  signedAt: string;
  verificationHash: string;
  isRead: boolean;
}

export default function DirectorSignatureAlertStream({
  userRole = 'director',
  onViewVaultAsset
}: DirectorSignatureAlertStreamProps) {
  // CRITICAL ACCESS CONTROL: Director Only
  const normalizedRole = userRole.toLowerCase();
  if (normalizedRole !== 'director' && normalizedRole !== 'owner') {
    return null;
  }

  const [alerts, setAlerts] = useState<SignatureAlertItem[]>([
    {
      id: 'sig_alert_01',
      creatorHandle: '@olivia.glows',
      creatorLegalName: 'Olivia Sterling',
      campaignName: 'Barrier Balance Serum Launch',
      brandName: 'Lumina Cosmetics LLC',
      rightsBuyoutSold: 3500,
      creatorRightsPayout: 1200,
      signedAt: 'Today at 09:42 AM',
      verificationHash: `CERTIFIED_RECORD_01_${Math.random().toString(36).substring(7).toUpperCase()}`,
      isRead: false
    },
    {
      id: 'sig_alert_02',
      creatorHandle: '@charlotte.skincare',
      creatorLegalName: 'Charlotte Vance',
      campaignName: 'Ceramide Infusion Q3',
      brandName: 'Lumina Cosmetics LLC',
      rightsBuyoutSold: 2800,
      creatorRightsPayout: 1000,
      signedAt: 'Yesterday at 04:15 PM',
      verificationHash: `CERTIFIED_RECORD_02_${Math.random().toString(36).substring(7).toUpperCase()}`,
      isRead: true
    }
  ]);

  const handleDownloadSealedCertificate = async (alert: SignatureAlertItem) => {
    await downloadCopyrightClearancePDF({
      campaignName: alert.campaignName,
      brandName: alert.brandName,
      creatorHandle: alert.creatorHandle,
      creatorLegalName: alert.creatorLegalName,
      creatorRightsPayout: alert.creatorRightsPayout,
      creatorSignature: alert.creatorLegalName,
      signedAt: alert.signedAt,
      verificationHash: alert.verificationHash
    });
  };

  return (
    <div className="w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 shadow-2xl space-y-5 font-sans text-agency-textLight animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-agency-gold" />
          <h3 className="text-base font-serif font-bold text-white">
            Director IP Vault: Real-Time Commercial Signature Stream
          </h3>
        </div>
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-agency-gold/15 text-agency-gold border border-agency-gold/30">
          Executive Telemetry
        </span>
      </div>

      <div className="space-y-3">
        {alerts.map(alert => (
          <div
            key={alert.id}
            className={`p-4 rounded-2xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
              !alert.isRead
                ? 'bg-agency-navy border-agency-gold/50 shadow-lg'
                : 'bg-agency-navy/60 border-white/5'
            }`}
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-bold text-white font-serif">
                  Creator <span className="text-agency-gold font-mono">{alert.creatorHandle}</span> has authorized Commercial Usage &amp; Copyright Buyout Agreement
                </span>
              </div>

              <p className="text-xs text-slate-300">
                Campaign: <strong className="text-white">{alert.campaignName}</strong> ({alert.brandName})
              </p>

              <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400 pt-1">
                <span>Signed: <span className="text-white">{alert.signedAt}</span></span>
                <span className="text-agency-gold">Gross: ${alert.rightsBuyoutSold.toLocaleString()}</span>
                <span className="text-emerald-400">Creator Payout: ${alert.creatorRightsPayout.toLocaleString()}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <button
                type="button"
                onClick={() => onViewVaultAsset && onViewVaultAsset(alert.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-agency-navy border border-white/10 hover:border-agency-gold text-white text-xs font-mono font-bold rounded-xl transition cursor-pointer"
              >
                <FileCheck className="w-3.5 h-3.5 text-agency-gold" />
                <span>View in Vault</span>
              </button>

              <button
                type="button"
                onClick={() => handleDownloadSealedCertificate(alert)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy text-xs font-mono font-bold uppercase tracking-wider rounded-xl transition shadow-lg cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Sealed PDF</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
