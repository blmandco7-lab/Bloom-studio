import React from 'react';
import { UserProfile } from './RoleGuardedCampaignWorkspace';
import { Briefcase, CheckCircle, Clock, AlertCircle, Sparkles, FileText, UserCheck, ShieldCheck } from 'lucide-react';

export interface ManagerDeliverableItem {
  id: string;
  creatorHandle: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  contractStatus: 'Pending Signature' | 'Active' | 'Under Review' | 'Completed';
  currentMilestone: string;
  dueDate: string;
  complianceChecked: boolean;
}

interface ManagerCampaignViewProps {
  user: UserProfile;
  campaignTitle?: string;
  brandName?: string;
  deliverables?: ManagerDeliverableItem[];
  onUpdateStatus?: (deliverableId: string, newStatus: ManagerDeliverableItem['contractStatus']) => void;
}

/**
 * ManagerCampaignView:
 * Dedicated portal for staff & campaign managers.
 * Completely isolates manager commissions and creator workflows
 * without rendering any gross brand contract numbers, profit margins, or master agency ledgers.
 */
export default function ManagerCampaignView({
  user,
  campaignTitle = "Summer Glow & Pet Hydration Push",
  brandName = "GlowLab Beauty & BarkHydrate",
  deliverables = [
    {
      id: "del_1",
      creatorHandle: "@ava",
      niche: "Beauty",
      contractStatus: "Active",
      currentMilestone: "Raw UGC Hook & Script Review",
      dueDate: "Aug 26, 2026",
      complianceChecked: true
    },
    {
      id: "del_2",
      creatorHandle: "@paws_and_palette",
      niche: "Pets",
      contractStatus: "Pending Signature",
      currentMilestone: "Agreement Dispatch & Product Sample",
      dueDate: "Aug 28, 2026",
      complianceChecked: false
    },
    {
      id: "del_3",
      creatorHandle: "@velvet_botanics",
      niche: "Lifestyle",
      contractStatus: "Active",
      currentMilestone: "Live UGC Video Link Submission",
      dueDate: "Sep 01, 2026",
      complianceChecked: true
    }
  ],
  onUpdateStatus
}: ManagerCampaignViewProps) {
  const managerPay = user.managerCompensation?.amount ?? 500.00;
  const payType = user.managerCompensation?.payType ?? 'Per Campaign';

  const formatUSD = (val: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  return (
    <div className="bg-agency-navyLight border border-agency-gold/25 rounded-3xl p-6 shadow-2xl text-agency-textLight space-y-6 max-w-4xl mx-auto">
      {/* 1. Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Manager Campaign Portal
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Assigned Active
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white mt-1.5">
            {campaignTitle}
          </h2>
          <p className="text-xs text-slate-400">
            Brand Client: <strong className="text-agency-gold">{brandName}</strong> &bull; Coordinator: <strong className="text-white">{user.name}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2 bg-agency-navy border border-white/10 px-3.5 py-2 rounded-2xl">
          <UserCheck className="w-4 h-4 text-agency-gold" />
          <div className="text-left">
            <span className="text-[10px] text-slate-400 uppercase font-mono block">Role Status</span>
            <span className="text-xs font-bold text-white">Manager Verified</span>
          </div>
        </div>
      </div>

      {/* 2. Personal Compensation Block */}
      <div className="bg-agency-navy border border-agency-gold/35 rounded-2xl p-5 shadow-inner flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-agency-gold/15 border border-agency-gold/30 flex items-center justify-center text-agency-gold">
            <Briefcase className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] uppercase font-mono tracking-wider text-slate-400 block">
              Your Allocated Campaign Pay
            </span>
            <span className="text-2xl font-bold font-mono text-agency-gold">
              {formatUSD(managerPay)}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-agency-navyLight border border-white/10 px-3 py-1.5 rounded-xl text-xs font-mono">
          <span className="text-slate-400">Pay Structure:</span>
          <span className="text-emerald-400 font-bold">{payType}</span>
        </div>
      </div>

      {/* 3. Creator Deliverable Tracker */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-agency-gold" /> Active Creator Deliverable Tracker
          </h3>
          <span className="text-[11px] font-mono text-slate-400">
            {deliverables.length} Talent Rows
          </span>
        </div>

        <div className="space-y-2.5">
          {deliverables.map((del) => {
            const isPending = del.contractStatus === 'Pending Signature';
            const isActive = del.contractStatus === 'Active';

            return (
              <div
                key={del.id}
                className="bg-agency-navy border border-white/10 hover:border-agency-gold/40 transition-all rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-md"
              >
                <div className="flex items-start sm:items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-agency-navyLight border border-white/10 flex items-center justify-center text-agency-gold font-mono font-bold text-sm">
                    {del.creatorHandle.slice(1, 3).toUpperCase()}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white font-mono">{del.creatorHandle}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-agency-navyLight border border-white/10 text-slate-300">
                        {del.niche}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      Content Deliverable Contract: <strong className={isActive ? 'text-emerald-400' : 'text-amber-400'}>{del.contractStatus}</strong>
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs">
                  <div className="bg-agency-navyLight px-3 py-1.5 rounded-xl border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Milestone</span>
                    <span className="text-white font-medium">{del.currentMilestone}</span>
                  </div>

                  <div className="bg-agency-navyLight px-3 py-1.5 rounded-xl border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Target Due</span>
                    <span className="text-agency-gold font-mono font-semibold">{del.dueDate}</span>
                  </div>

                  <span
                    className={`text-[11px] font-mono px-3 py-1 rounded-full border ${
                      del.complianceChecked
                        ? 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30'
                        : 'bg-amber-950/60 text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {del.complianceChecked ? 'FTC Compliant' : 'Pending Review'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
