import React, { useState, useMemo } from 'react';
import { 
  ShieldAlert, AlertTriangle, BellRing, BellOff, MessageSquare, 
  ArrowRight, CheckCircle, Smartphone, UserCheck, RefreshCw, 
  Sparkles, ExternalLink, FileCheck, FolderLock, Eye
} from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';
import { Creator, Deal } from '../types';
import { DEFAULT_DEALS, DEFAULT_CREATORS } from '../data/defaultAgencyData';

interface MetricAlert {
  id: string;
  creator: string;
  dealBrand: string;
  type: 'Engagement Drop' | 'SOP Deadline Miss' | 'Flagged Content' | 'Compliance Flag' | 'Inactive Roster' | 'High-Value Contract' | 'Live Campaign Pacing' | 'Deliverable Required' | 'Active Deal Milestone' | 'Multi-Deal Concurrency';
  severity: 'Critical' | 'Warning' | 'Low';
  description: string;
  triggeredAt: string;
  dismissed: boolean;
  engagementStats?: { past: string; current: string };
  budget?: number;
  dealStage?: string;
  deliverable?: string;
  dealId?: string;
}

interface PerformanceAlertsProps {
  creators?: Creator[];
  deals?: any[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onNavigate?: (screen: string) => void;
  reviewsList?: any[];
}

export default function PerformanceAlerts({ 
  creators = [], 
  deals = [], 
  currentUser, 
  currentRole, 
  onAddActivityLog, 
  triggerNotification,
  onNavigate,
  reviewsList
}: PerformanceAlertsProps) {
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const isAgent = (currentRole || '').toLowerCase() === 'agent';
  const isCreator = (currentRole || '').toLowerCase() === 'creator';
  const isDirector = ['director', 'agency', 'admin'].includes((currentRole || '').toLowerCase()) || !!currentUser?.isPlatformOwner;
  const isRestrictedRole = (isAgentMgr || isAgent) && !isDirector;
  
  const mgrName = currentUser?.name || 'Marcus Cole';
  const activeCreators = creators.length > 0 ? creators : DEFAULT_CREATORS;
  const activeDeals = deals.length > 0 ? deals : DEFAULT_DEALS;

  const myCreators = activeCreators.filter(c => 
    c.assignedAgent?.toLowerCase() === mgrName.toLowerCase() &&
    c.name.toLowerCase() !== mgrName.toLowerCase() &&
    c.handle.toLowerCase() !== (currentUser?.handle || '').toLowerCase()
  );
  
  const myHandles = myCreators.length > 0 ? myCreators.map(c => c.handle.toLowerCase().replace('@', '')) : [];

  const [dismissedIds, setDismissedIds] = useState<string[]>(() => {
    try {
      const raw = safeStorage.getItem('wl_dismissed_performance_alerts');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [filterCategory, setFilterCategory] = useState<'All' | 'Brand Deals' | 'Engagement' | 'Compliance'>('All');
  const [activeTab, setActiveTab] = useState<'active' | 'dismissed'>('active');
  const [showAllCreatorsView, setShowAllCreatorsView] = useState<boolean>(true);

  const normalize = (str?: string) => (str || '').toLowerCase().replace('@', '').trim();

  // Dynamically compute performance alerts across every creator and their brand deals
  const allComputedAlerts: MetricAlert[] = useMemo(() => {
    const list: MetricAlert[] = [];
    const seenAlertIds = new Set<string>();

    // 1. Scan EVERY creator in the roster for brand deals
    activeCreators.forEach((c, ci) => {
      const cHandle = c.handle || `@creator_${ci}`;
      const normHandle = normalize(cHandle);
      const normName = normalize(c.name);

      // Find all deals belonging to this creator
      const creatorDeals = activeDeals.filter((d: any) => {
        const dCreator = normalize(d.creator || d.creatorHandle);
        return dCreator === normHandle || dCreator === normName || dCreator.includes(normHandle) || normHandle.includes(dCreator);
      });

      // If this creator has brand deals happening, generate alerts for each deal!
      creatorDeals.forEach((deal: any, di: number) => {
        const budgetVal = typeof deal.budget === 'number' 
          ? deal.budget 
          : parseFloat(String(deal.budget || deal.value || '0').replace(/[^0-9.]/g, '')) || 5000;
        const stage = (deal.stage || 'In Production').trim();
        const deliverable = deal.deliverable || '1x Sponsored Reel / TikTok & IG Story';
        const dealId = deal.id || `deal_${normHandle}_${di}`;
        const brandName = deal.brand || 'Brand Partner';

        // A. Live Campaign Pacing Alert (When deal is actively Live)
        if (stage === 'Live' || stage === 'Live & Published') {
          const alertId = `al_live_${dealId}`;
          if (!seenAlertIds.has(alertId)) {
            seenAlertIds.add(alertId);
            list.push({
              id: alertId,
              creator: cHandle,
              dealBrand: brandName,
              dealId: deal.id,
              type: 'Live Campaign Pacing',
              severity: 'Critical',
              description: `Live Campaign Running: ${brandName} ($${budgetVal.toLocaleString()}) on ${deal.platform || 'Social'}. Deliverable "${deliverable}" is live. Live pacing metrics, FTC disclosure audit, and audience reach tracking active.`,
              triggeredAt: 'Live Campaign Active',
              dismissed: dismissedIds.includes(alertId),
              budget: budgetVal,
              dealStage: stage,
              deliverable
            });
          }
        }
        // B. Deliverable Required Alert (Contracted / Draft Submitted / In Production / Revisions)
        else if (['Contracted', 'Draft Submitted', 'In Production', 'Scheduled', 'Revisions', 'Pending Review'].includes(stage)) {
          const alertId = `al_deliv_${dealId}`;
          if (!seenAlertIds.has(alertId)) {
            seenAlertIds.add(alertId);
            list.push({
              id: alertId,
              creator: cHandle,
              dealBrand: brandName,
              dealId: deal.id,
              type: 'Deliverable Required',
              severity: stage === 'Revisions' ? 'Critical' : 'Warning',
              description: `Brand Deal in Motion: ${brandName} ($${budgetVal.toLocaleString()}) status is "${stage}". Deliverable: ${deliverable}. Due: ${deal.due || deal.dueDate || 'Milestone Pending'}. Content draft turnaround and agency review required before brand launch.`,
              triggeredAt: 'Production Milestone',
              dismissed: dismissedIds.includes(alertId),
              budget: budgetVal,
              dealStage: stage,
              deliverable
            });
          }
        }
        // C. Active Deal Negotiation Milestone (Lead / Pitched / Negotiating)
        else if (['Negotiating', 'Pitched', 'Lead', 'Offer Received'].includes(stage)) {
          const alertId = `al_pipe_${dealId}`;
          if (!seenAlertIds.has(alertId)) {
            seenAlertIds.add(alertId);
            list.push({
              id: alertId,
              creator: cHandle,
              dealBrand: brandName,
              dealId: deal.id,
              type: 'Active Deal Milestone',
              severity: 'Low',
              description: `Pipeline Deal Active: ${brandName} ($${budgetVal.toLocaleString()}) in "${stage}" stage. Deliverable: ${deliverable}. Rate card verification & contract brief alignment in progress.`,
              triggeredAt: 'Pipeline Update',
              dismissed: dismissedIds.includes(alertId),
              budget: budgetVal,
              dealStage: stage,
              deliverable
            });
          }
        }

        // D. High-Value Contract Threshold Check (>$25,000)
        if (budgetVal >= 25000) {
          const alertId = `al_hv_${dealId}`;
          if (!seenAlertIds.has(alertId)) {
            seenAlertIds.add(alertId);
            list.push({
              id: alertId,
              creator: cHandle,
              dealBrand: brandName,
              dealId: deal.id,
              type: 'High-Value Contract',
              severity: 'Warning',
              description: `High-value enterprise campaign with ${brandName} ($${budgetVal.toLocaleString()}). Agency 20% Net: $${Math.round(budgetVal * 0.2).toLocaleString()}. Director review and milestone escrow oversight active.`,
              triggeredAt: 'Enterprise Value Flag',
              dismissed: dismissedIds.includes(alertId),
              budget: budgetVal,
              dealStage: stage,
              deliverable
            });
          }
        }

        // E. Crisis Hold Check
        if (stage === 'Paused — crisis hold') {
          const alertId = `al_crisis_${dealId}`;
          if (!seenAlertIds.has(alertId)) {
            seenAlertIds.add(alertId);
            list.push({
              id: alertId,
              creator: cHandle,
              dealBrand: brandName,
              dealId: deal.id,
              type: 'Compliance Flag',
              severity: 'Critical',
              description: `Campaign Hold: Deal with ${brandName} ($${budgetVal.toLocaleString()}) is on crisis hold. Deliverable production frozen pending agency legal & brand review.`,
              triggeredAt: 'Crisis Flag',
              dismissed: dismissedIds.includes(alertId),
              budget: budgetVal,
              dealStage: stage,
              deliverable
            });
          }
        }
      });

      // F. Multi-Deal Concurrency Alert (if creator has multiple concurrent deals happening)
      if (creatorDeals.length >= 2) {
        const totalVolume = creatorDeals.reduce((acc, d) => acc + (typeof d.budget === 'number' ? d.budget : parseFloat(String(d.budget || 0)) || 0), 0);
        const alertId = `al_multi_${normHandle}`;
        if (!seenAlertIds.has(alertId)) {
          seenAlertIds.add(alertId);
          list.push({
            id: alertId,
            creator: cHandle,
            dealBrand: creatorDeals.map(d => d.brand).join(' & '),
            type: 'Multi-Deal Concurrency',
            severity: 'Warning',
            description: `${cHandle} is concurrently managing ${creatorDeals.length} active brand campaigns with combined portfolio budget of $${totalVolume.toLocaleString()}. Monitor deliverable calendar to prevent burn-out and overlapping turn-in deadlines.`,
            triggeredAt: 'Portfolio Concurrency',
            dismissed: dismissedIds.includes(alertId),
            budget: totalVolume
          });
        }
      }

      // G. Creator Engagement Metric Monitoring
      const engNum = parseFloat(String(c.eng || '0').replace(/[^0-9.]/g, '')) || 0;
      if (engNum > 0 && engNum < 3.5) {
        const alertId = `al_eng_${ci}`;
        if (!seenAlertIds.has(alertId)) {
          seenAlertIds.add(alertId);
          list.push({
            id: alertId,
            creator: cHandle,
            dealBrand: creatorDeals[0]?.brand || 'Active Roster',
            type: 'Engagement Drop',
            severity: 'Warning',
            description: `Average post engagement rate for ${cHandle} is currently at ${c.eng}, below the 3.5% agency performance threshold. Recommend optimizing hook timing and thumbnail call-to-actions before next brand drop.`,
            triggeredAt: 'Engagement Scan',
            dismissed: dismissedIds.includes(alertId),
            engagementStats: { past: '4.5%', current: c.eng || '0.0%' }
          });
        }
      }

      // H. Inactive or Audit Status
      if (c.status === 'Inactive' || c.status === 'Needs Audit') {
        const alertId = `al_stat_${ci}`;
        if (!seenAlertIds.has(alertId)) {
          seenAlertIds.add(alertId);
          list.push({
            id: alertId,
            creator: cHandle,
            dealBrand: creatorDeals[0]?.brand || 'Active Roster',
            type: 'Inactive Roster',
            severity: c.status === 'Needs Audit' ? 'Critical' : 'Low',
            description: `Creator ${cHandle} profile status is "${c.status}". Roster re-verification and media kit refresh recommended.`,
            triggeredAt: 'Roster Audit',
            dismissed: dismissedIds.includes(alertId)
          });
        }
      }
    });

    return list;
  }, [activeCreators, activeDeals, dismissedIds]);

  // Combined Role Scoping & Category Filtering
  const filteredAlerts = useMemo(() => {
    return allComputedAlerts.filter(al => {
      const alCreatorNorm = normalize(al.creator);

      // 1. Role Scoping (if user wants to restrict to their assigned roster)
      if (!showAllCreatorsView) {
        if (isCreator) {
          const myHandle = normalize(currentUser?.handle);
          const myName = normalize(currentUser?.name);
          const isMine = alCreatorNorm === myHandle || alCreatorNorm === myName || !myHandle;
          if (!isMine) return false;
        } else if (isRestrictedRole && myHandles.length > 0) {
          if (!myHandles.includes(alCreatorNorm)) return false;
        }
      }

      // 2. Category Filtering
      if (filterCategory === 'Brand Deals') {
        return ['Live Campaign Pacing', 'Deliverable Required', 'Active Deal Milestone', 'High-Value Contract', 'Multi-Deal Concurrency'].includes(al.type);
      }
      if (filterCategory === 'Engagement') {
        return al.type === 'Engagement Drop' || al.type === 'Inactive Roster';
      }
      if (filterCategory === 'Compliance') {
        return al.type === 'Compliance Flag' || al.type === 'High-Value Contract';
      }

      return true;
    });
  }, [allComputedAlerts, isCreator, isRestrictedRole, myHandles, currentUser, filterCategory, showAllCreatorsView]);

  const visibleAlerts = filteredAlerts.filter(al => activeTab === 'active' ? !al.dismissed : al.dismissed);

  const handleRemindCreator = (alert: MetricAlert) => {
    triggerNotification(
      'Notification Dispatched',
      `Auto-scouted DM reminder dispatched to creator ${alert.creator}: "Campaign milestone check for ${alert.dealBrand}. Please review your deliverables queue."`,
      'success'
    );
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Sent campaign performance notification to ${alert.creator} for ${alert.dealBrand}`);
  };

  const handleContactBrand = (alert: MetricAlert) => {
    triggerNotification(
      'Brand Coordination Thread',
      `Brand CRM channel opened with ${alert.dealBrand} team regarding ${alert.creator}'s deliverable milestone.`,
      'info'
    );
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Initiated brand coordination thread for ${alert.dealBrand}`);
  };

  const handleDismissAlert = (id: string) => {
    const updated = [...dismissedIds, id];
    setDismissedIds(updated);
    try {
      safeStorage.setItem('wl_dismissed_performance_alerts', JSON.stringify(updated));
    } catch {}
    triggerNotification('Alert Archived', 'Alert moved to archived audit log.', 'info');
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Archived alert ID: ${id.toUpperCase()}`);
  };

  const handleRestoreAlert = (id: string) => {
    const updated = dismissedIds.filter(item => item !== id);
    setDismissedIds(updated);
    try {
      safeStorage.setItem('wl_dismissed_performance_alerts', JSON.stringify(updated));
    } catch {}
    triggerNotification('Alert Restored', 'Alert restored to active queue.', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden">
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider">
              Risk &amp; Performance
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              Roster &amp; Metric Alerts
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
              Real-time monitoring across all creators with active brand deals, live deliverable pacing, FTC disclosures, and engagement thresholds.
            </p>
          </div>

          {/* Scope Toggle & Stats */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="bg-[#0B1528] border border-white/10 p-1 rounded-xl flex items-center gap-1">
              <button
                type="button"
                onClick={() => setShowAllCreatorsView(true)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  showAllCreatorsView 
                    ? 'bg-[#C9A46A] text-[#0A1220] shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                All Agency Creators ({activeCreators.length})
              </button>
              <button
                type="button"
                onClick={() => setShowAllCreatorsView(false)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  !showAllCreatorsView 
                    ? 'bg-[#C9A46A] text-[#0A1220] shadow-sm' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                My Roster ({isCreator ? 'Me' : myCreators.length})
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Menu & Category Pills */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/5 pb-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('active')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
              activeTab === 'active'
                ? 'bg-[#16243F] text-[#C9A46A]'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            Active Alerts ({filteredAlerts.filter(a => !a.dismissed).length})
          </button>
          <button
            onClick={() => setActiveTab('dismissed')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
              activeTab === 'dismissed'
                ? 'bg-[#16243F] text-[#C9A46A]'
                : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            Archived Logs ({filteredAlerts.filter(a => a.dismissed).length})
          </button>

          <div className="h-4 w-px bg-white/10 hidden md:block mx-1" />

          {/* Category Quick Filter */}
          <div className="flex items-center gap-1.5 bg-[#0B1528] p-1 rounded-xl border border-white/5">
            {(['All', 'Brand Deals', 'Engagement', 'Compliance'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-2.5 py-1 text-[11px] font-medium rounded-lg transition-all ${
                  filterCategory === cat
                    ? 'bg-[#C9A46A] text-[#0A1220] font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => {
            triggerNotification('Diagnostic Sync Complete', 'Scanned all creator brand deals and engagement metrics successfully.', 'info');
            onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', 'Triggered full social APIs and deals sync');
          }}
          className="bg-[#111E33] border border-white/10 text-[11px] text-[#C9A46A] hover:bg-[#16243F] px-3.5 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Re-scan Roster Metrics
        </button>
      </div>

      {/* Alerts Feed */}
      <div className="space-y-4">
        {visibleAlerts.length === 0 ? (
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-12 text-center text-[#7C8AA8] space-y-2">
            <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
            <h3 className="text-sm font-semibold text-white">All systems are nominal</h3>
            <p className="text-xs max-w-sm mx-auto leading-relaxed">No performance issues, overdue review deadlines, or FTC compliance warnings detected for the selected roster filter.</p>
          </div>
        ) : (
          visibleAlerts.map(alert => (
            <div
              key={alert.id}
              className={`bg-[#0D1830] border rounded-2xl p-5 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 transition-all shadow-sm ${
                alert.severity === 'Critical' ? 'border-rose-500/20 hover:border-rose-500/40 bg-gradient-to-r from-rose-950/10 to-[#0D1830]' :
                alert.severity === 'Warning' ? 'border-amber-500/20 hover:border-amber-500/40 bg-gradient-to-r from-amber-950/10 to-[#0D1830]' :
                'border-white/5 hover:border-white/15'
              }`}
            >
              {/* Left Details */}
              <div className="flex gap-4 items-start flex-1 min-w-0">
                <div className={`p-2.5 rounded-xl mt-0.5 shrink-0 ${
                  alert.type === 'High-Value Contract' ? 'bg-amber-950 text-amber-300 border border-amber-500/30' :
                  alert.type === 'Live Campaign Pacing' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' :
                  alert.type === 'Multi-Deal Concurrency' ? 'bg-indigo-950 text-indigo-300 border border-indigo-500/30' :
                  alert.severity === 'Critical' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                  alert.severity === 'Warning' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                  'bg-slate-800 text-slate-300'
                }`}>
                  {alert.type === 'High-Value Contract' ? (
                    <Sparkles className="w-5 h-5 shrink-0 text-amber-300" />
                  ) : alert.type === 'Live Campaign Pacing' ? (
                    <BellRing className="w-5 h-5 shrink-0 text-emerald-400" />
                  ) : alert.type === 'Multi-Deal Concurrency' ? (
                    <UserCheck className="w-5 h-5 shrink-0 text-indigo-300" />
                  ) : (
                    <ShieldAlert className="w-5 h-5 shrink-0" />
                  )}
                </div>
                
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-white text-sm">{alert.creator}</span>
                    <span className="text-slate-400 text-xs">&middot;</span>
                    <span className="text-[11px] font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20">
                      {alert.dealBrand}
                    </span>
                    <span className="text-slate-400 text-xs">&middot;</span>
                    <span className="text-[10px] text-[#7C8AA8] font-mono">{alert.triggeredAt}</span>
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                      alert.severity === 'Critical' ? 'bg-rose-950 text-rose-400 border border-rose-500/20' :
                      alert.severity === 'Warning' ? 'bg-amber-950 text-amber-400 border border-amber-500/20' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {alert.severity}
                    </span>
                  </div>

                  <p className="text-xs text-white/90 font-semibold">{alert.type}</p>
                  <p className="text-xs text-[#7C8AA8] leading-relaxed max-w-2xl">{alert.description}</p>

                  {/* Supplemental Metric Info */}
                  {alert.engagementStats && (
                    <div className="flex items-center gap-2 text-[10px] font-mono text-[#C9A46A] pt-1">
                      <span>Baseline: {alert.engagementStats.past}</span>
                      <ArrowRight className="w-3 h-3" />
                      <span>Current: <strong className="text-rose-400 font-bold">{alert.engagementStats.current}</strong></span>
                    </div>
                  )}

                  {/* Direct Workflow Jump Links */}
                  {onNavigate && (
                    <div className="flex flex-wrap items-center gap-2 pt-1.5">
                      {['Deliverable Required', 'Live Campaign Pacing', 'High-Value Contract'].includes(alert.type) && (
                        <>
                          {(isDirector || isAgentMgr) ? (
                            <button
                              type="button"
                              onClick={() => onNavigate('content-review')}
                              className="text-[10px] font-semibold text-[#C9A46A] hover:text-white bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 border border-[#C9A46A]/30 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                            >
                              <FileCheck className="w-3 h-3" /> Go to Content Review &amp; Approval Desk &rarr;
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => onNavigate('submit-content')}
                              className="text-[10px] font-semibold text-[#C9A46A] hover:text-white bg-[#C9A46A]/10 hover:bg-[#C9A46A]/20 border border-[#C9A46A]/30 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                            >
                              <FileCheck className="w-3 h-3" /> Open Submit Content Desk &rarr;
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => onNavigate('content-library')}
                            className="text-[10px] font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <FolderLock className="w-3 h-3" /> View Content Vault &amp; Library &rarr;
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Right Action Menu */}
              <div className="flex items-center gap-2 w-full lg:w-auto self-end lg:self-center justify-end">
                {activeTab === 'active' ? (
                  <>
                    <button
                      onClick={() => handleRemindCreator(alert)}
                      className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-[#7C8AA8] hover:text-white px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Smartphone className="w-3.5 h-3.5" /> Nudge Creator
                    </button>
                    {alert.dealBrand !== 'Unassigned' && (
                      <button
                        onClick={() => handleContactBrand(alert)}
                        className="bg-[#16243F] hover:bg-[#1f3050] text-[#C9A46A] border border-[#rgba(201,164,106,0.14)] px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> Chat Brand
                      </button>
                    )}
                    <button
                      onClick={() => handleDismissAlert(alert.id)}
                      className="text-slate-500 hover:text-white p-2 hover:bg-white/5 rounded-xl transition-all cursor-pointer"
                      title="Archive Alert"
                    >
                      <BellOff className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => handleRestoreAlert(alert.id)}
                    className="bg-[#16243F] hover:bg-[#1f3050] text-[#C9A46A] border border-[#rgba(201,164,106,0.14)] px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    Restore Alert
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
