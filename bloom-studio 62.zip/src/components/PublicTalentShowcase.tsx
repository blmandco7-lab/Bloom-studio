import React, { useState, useEffect } from 'react';
import { Sparkles, Users, Star, ArrowRight, ShieldCheck, Instagram, Video, CheckCircle2, X, Zap, Upload, Copy } from 'lucide-react';
import { DAPSContainer } from './DigitalAssetProtectionSystem';
import { getAppCheckToken, db } from '../lib/firebase';
import { doc, setDoc, collection, query, where, onSnapshot } from 'firebase/firestore';
import PortfolioContactFooter from './PortfolioContactFooter';


export interface PublicCreatorProfile {
  id: string;
  handle: string;
  name: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  followers: string;
  engagement: string;
  avatarUrl: string;
  galleryImages?: string[];
  tags: string[];
  specialty: string;
  verifiedFtc: boolean;
  contractRevenue?: string;
  agencyProfitMargin?: string;
  managerPayroll?: string;
}

interface PublicTalentShowcaseProps {
  creators?: any[];
  initialCreators?: PublicCreatorProfile[];
  currentRole?: string;
  currentUser?: any;
  onStartAgencySignup?: () => void;
  onSignUp?: () => void;
}

/**
 * PublicTalentShowcase:
 * Public-facing, read-only creator showcase grid.
 * 
 * SECURITY: Decoupled 100% from internal campaigns, client contracts, and financial ledgers.
 * Role Protection: YTD revenue, net margin, and manager payroll are ONLY visible to authorized Directors/Managers.
 * LEAD CAPTURE: Modal form writes submissions directly to Firestore 'leads' collection.
 */
export default function PublicTalentShowcase({
  initialCreators = [
    {
      id: "c_1",
      handle: "@ava_glow",
      name: "Ava Sterling",
      niche: "Beauty",
      followers: "420K",
      engagement: "8.4%",
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80",
      galleryImages: [
        "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1522338221030-42102726c17c?w=400&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1522337660859-02fbefce4ff4?w=400&auto=format&fit=crop&q=80"
      ],
      tags: ["Clean Skincare", "Morning Routine", "Cruelty-Free"],
      specialty: "Macro skin texture UGC & botanical serums",
      verifiedFtc: true,
      contractRevenue: "$145,000",
      agencyProfitMargin: "35%",
      managerPayroll: "$8,500"
    },
    {
      id: "c_2",
      handle: "@paws_and_palette",
      name: "Chloe & Jasper (Golden)",
      niche: "Pets",
      followers: "680K",
      engagement: "9.2%",
      avatarUrl: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=400&auto=format&fit=crop&q=80",
      tags: ["Dog Wellness", "Eco Grooming", "Canine Nutrition"],
      specialty: "High-energy pet story reels & organic balms",
      verifiedFtc: true,
      contractRevenue: "$210,000",
      agencyProfitMargin: "40%",
      managerPayroll: "$12,000"
    },
    {
      id: "c_3",
      handle: "@velvet_botanics",
      name: "Marcus Chen",
      niche: "Lifestyle",
      followers: "310K",
      engagement: "7.1%",
      avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80",
      tags: ["Aesthetic Living", "Home Diffusers", "Slow Luxury"],
      specialty: "Cinematic 4K home tours & mood lighting",
      verifiedFtc: true,
      contractRevenue: "$95,000",
      agencyProfitMargin: "30%",
      managerPayroll: "$6,200"
    },
    {
      id: "c_4",
      handle: "@mia_skinlab",
      name: "Dr. Mia Patel",
      niche: "Beauty",
      followers: "540K",
      engagement: "8.9%",
      avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80",
      tags: ["Derm-Approved", "Barrier Repair", "Science-Led"],
      specialty: "Ingredient breakdowns & clinical proofing",
      verifiedFtc: true,
      contractRevenue: "$180,000",
      agencyProfitMargin: "35%",
      managerPayroll: "$9,500"
    },
    {
      id: "c_5",
      handle: "@hound_and_haven",
      name: "Sam & Barnaby",
      niche: "Pets",
      followers: "280K",
      engagement: "8.0%",
      avatarUrl: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=400&auto=format&fit=crop&q=80",
      tags: ["Outdoor Canine", "Adventure", "Pet Gear"],
      specialty: "Outdoor adventure testing & durable pet goods",
      verifiedFtc: true,
      contractRevenue: "$115,000",
      agencyProfitMargin: "32%",
      managerPayroll: "$7,100"
    },
    {
      id: "c_6",
      handle: "@sol_living",
      name: "Aria Thorne",
      niche: "Lifestyle",
      followers: "490K",
      engagement: "7.6%",
      avatarUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80",
      tags: ["Mindful Living", "Interior Design", "Ceramics"],
      specialty: "High-converting lifestyle unboxing reels",
      verifiedFtc: true,
      contractRevenue: "$130,000",
      agencyProfitMargin: "38%",
      managerPayroll: "$8,900"
    }
  ],
  currentRole,
  currentUser,
  onStartAgencySignup,
  onSignUp,
}: PublicTalentShowcaseProps) {
  const isDirectorOnly = (currentRole || '').toLowerCase() === 'director';
  const isExecutiveManager = isDirectorOnly || (currentRole || '').toLowerCase() === 'agentmgr';
  const isAgent = (currentRole || '').toLowerCase() === 'agent';
  const userName = (currentUser?.name || '').toLowerCase();

  const [selectedNiche, setSelectedNiche] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddCreatorOpen, setIsAddCreatorOpen] = useState(false);
  const [galleryCreator, setGalleryCreator] = useState<PublicCreatorProfile | null>(null);
  const [assignBriefCreator, setAssignBriefCreator] = useState<PublicCreatorProfile | null>(null);
  const [selectedBriefTitle, setSelectedBriefTitle] = useState('Fall Luxe Skincare Campaign');
  const [assignSuccessMsg, setAssignSuccessMsg] = useState<string>('');
  const [viewState, setViewState] = useState<'Director' | 'Brand' | 'Public'>('Public');
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [isUnregisteredVisitor, setIsUnregisteredVisitor] = useState(!currentUser);
  const [creatorsList, setCreatorsList] = useState<PublicCreatorProfile[]>(initialCreators);
  const [newCreator, setNewCreator] = useState({
    name: '',
    handle: '',
    niche: 'Beauty' as 'Beauty' | 'Pets' | 'Lifestyle',
    followers: '100K',
    engagement: '5.0%',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    tags: [] as string[],
    galleryImages: [] as string[],
    specialty: '',
    contractRevenue: '$50,000',
    agencyProfitMargin: '30%',
    managerPayroll: '$3,500'
  });
  const [brandLead, setBrandLead] = useState({
    brandName: '',
    contactName: '',
    email: '',
    nicheInterest: 'Beauty',
    budgetTier: '$10k - $25k',
    campaignGoals: ''
  });

  const visibleCreators = creatorsList;

  const filteredCreators = selectedNiche === 'All'
    ? visibleCreators
    : visibleCreators.filter(c => c.niche === selectedNiche);

  // Limit preview to 5 creators ONLY for unregistered visitors (not signed up)
  const displayedCreators = isUnregisteredVisitor ? filteredCreators.slice(0, 5) : filteredCreators;

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      // 0. Retrieve App Check token (Finding #102-AppCheck)
      const appCheckToken = await getAppCheckToken();

      // 1. Submit through throttled server API (Finding #102)
      const res = await fetch('/api/submit-brand-inquiry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Firebase-AppCheck': appCheckToken || ''
        },
        body: JSON.stringify({
          ...brandLead,
          source: 'Public Talent Showcase',
          targetCollection: 'inboundLeads'
        })
      });

      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit inquiry');
      }

      setSubmitSuccess(true);
      setTimeout(() => {
        setIsModalOpen(false);
        setSubmitSuccess(false);
        setBrandLead({
          brandName: '',
          contactName: '',
          email: '',
          nicheInterest: 'Beauty',
          budgetTier: '$10k - $25k',
          campaignGoals: ''
        });
      }, 2500);
    } catch (err: any) {
      console.error('Failed to submit brand lead:', err);
      // Fallback or warning could be added here if needed
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DAPSContainer title="Public Talent Showcase & Creator Portfolios" isShieldActive={true}>
      <div className="bg-agency-navy min-h-screen text-agency-textLight pb-28">
      {/* Top Banner Navigation */}
      <header className="border-b border-agency-gold/20 bg-agency-navy/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span 
              className="w-9 h-9 rounded-xl bg-agency-navyLight border border-agency-gold/40 flex items-center justify-center font-serif font-bold text-agency-gold text-lg cursor-pointer"
              onDoubleClick={() => setViewState('Director')}
              title="Double click to reset to Director view"
            >
              B
            </span>
            <div>
              <h1 className="font-serif font-bold text-lg text-white">BLOOM STUDIO</h1>
              <span className="text-[10px] font-mono text-agency-gold uppercase tracking-widest block">
                Exclusive Talent Network
              </span>
            </div>
          </div>
          {/* Top CTA */}
          <div className="flex items-center gap-3">
            {currentRole !== 'brand' && (
              <button
                type="button"
                onClick={() => {
                  const url = `${window.location.origin}/#showcase&ref=showcase_share`;
                  navigator.clipboard.writeText(url);
                  alert('Copied Talent Showcase share link to clipboard!');
                }}
                className="inline-flex items-center gap-1.5 bg-agency-navyLight hover:bg-agency-navyLight/80 text-agency-gold border border-agency-gold/30 font-bold text-xs px-3.5 py-2.5 rounded-xl shadow-lg transition-all cursor-pointer"
                title="Copy direct share link for this showcase"
              >
                <Copy className="w-4 h-4" />
                <span>Copy Showcase Link</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="hidden sm:inline-flex items-center gap-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Inquire About a Brand Campaign</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-12 pb-8 text-center space-y-4">
        <div className="inline-flex items-center gap-2 bg-agency-navyLight border border-agency-gold/30 px-3.5 py-1 rounded-full text-xs font-mono text-agency-gold">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Vetted &bull; FTC Compliant &bull; High-Engagement Talent</span>
        </div>

        <h2 className="font-serif font-bold text-3xl sm:text-5xl text-white max-w-3xl mx-auto leading-tight">
          Handcrafted Creator Talent for Pet, Beauty &amp; Luxury Lifestyle Brands
        </h2>

        <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Bloom Studio manages an exclusive roster of verified digital storytellers with proven organic reach, authentic engagement, and strict commercial whitelisting safety.
        </p>

        {/* Niche Filter Pills */}
        <div className="flex items-center justify-center gap-2 pt-4">
          {(['All', 'Beauty', 'Pets', 'Lifestyle'] as const).map((niche) => (
            <button
              key={niche}
              type="button"
              onClick={() => setSelectedNiche(niche)}
              className={`px-4 py-2 rounded-xl text-xs font-mono transition-all border cursor-pointer ${
                selectedNiche === niche
                  ? 'bg-agency-gold text-agency-navy border-agency-gold font-bold shadow-lg'
                  : 'bg-agency-navyLight text-slate-300 border-white/10 hover:border-white/30'
              }`}
            >
              {niche === 'All' ? 'All Creators' : `${niche} Roster`}
            </button>
          ))}
          {isExecutiveManager && (
            <button
              onClick={() => setIsAddCreatorOpen(true)}
              className="px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all border border-emerald-500/50 text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 shadow-lg cursor-pointer ml-4"
            >
              + Add Creator
            </button>
          )}
        </div>
      </section>

      {/* Talent Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedCreators.map((creator) => (
            <div
              key={creator.id}
              className="bg-agency-navyLight border border-agency-gold/20 hover:border-agency-gold/60 rounded-3xl p-5 shadow-xl transition-all hover:scale-[1.01] flex flex-col justify-between space-y-4 group"
            >
              <div className="space-y-4">
                {/* Creator Avatar & Basic Info */}
                <div className="flex items-center gap-3.5">
                  <div className="relative group">
                    <img
                      src={creator.avatarUrl}
                      alt={creator.name}
                      className="w-14 h-14 rounded-2xl object-cover border border-agency-gold/40 shadow-md"
                    />
                    {isDirectorOnly && viewState === 'Director' && (
                      <label className="absolute inset-0 bg-black/75 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition text-[9px] font-mono text-white text-center p-1" title="Upload creator photo">
                        <div className="flex flex-col items-center gap-0.5">
                          <Upload className="w-3.5 h-3.5 text-agency-gold" />
                          <span>Upload</span>
                        </div>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            if (!file.type.startsWith('image/')) {
                              alert('Please select a valid image file (PNG, JPG, WebP).');
                              return;
                            }
                            if (file.size > 5 * 1024 * 1024) {
                              alert('File size exceeds 5MB limit. Please choose a smaller image.');
                              return;
                            }
                            const reader = new FileReader();
                            reader.onload = async (evt) => {
                              const base64 = evt.target?.result as string;
                              if (base64) {
                                setCreatorsList(prev => prev.map(c => c.id === creator.id ? { ...c, avatarUrl: base64 } : c));
                                try {
                                  await setDoc(doc(db, 'studio-creators', creator.id), {
                                    avatarUrl: base64,
                                    avatar: base64,
                                    updatedAt: new Date().toISOString()
                                  }, { merge: true });
                                } catch (err) {
                                  console.warn('Firestore photo update note:', err);
                                }
                              }
                            };
                            reader.readAsDataURL(file);
                          }}
                        />
                      </label>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-white text-base">{creator.name}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-agency-gold/15 text-agency-gold border border-agency-gold/30">
                        {creator.niche}
                      </span>
                    </div>
                    <span className="text-xs font-mono text-agency-gold">{creator.handle}</span>
                  </div>
                </div>

                {/* Metrics Badges */}
                <div className="grid grid-cols-2 gap-2 bg-agency-navy p-3 rounded-2xl border border-white/5 font-mono text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Followers</span>
                    <span className="text-sm font-bold text-white">{creator.followers}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase">Avg Engagement</span>
                    <span className="text-sm font-bold text-emerald-400">{creator.engagement}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  {creator.specialty}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5">
                  {creator.tags.map((t, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] font-mono bg-agency-navy px-2.5 py-1 rounded-lg text-slate-300 border border-white/10"
                    >
                      #{t}
                    </span>
                  ))}
                </div>

                {/* Internal Dashboards Views - Strictly restricted to Director */}
                {isDirectorOnly && viewState === 'Director' && (
                  <div className="mt-3 bg-[#111E33] border border-agency-gold/20 p-3 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider">Internal Routing</span>
                      <span className="text-[10px] text-agency-gold font-bold">bookings@bloomstudio.com</span>
                    </div>
                    
                    <div className="border-t border-white/5 pt-2 mt-2 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">YTD Revenue</span>
                        <span className="text-emerald-400 font-mono font-bold">{creator.contractRevenue}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Net Margin</span>
                        <span className="text-white font-mono font-bold">{creator.agencyProfitMargin}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Manager Payroll</span>
                        <span className="text-slate-300 font-mono">{creator.managerPayroll}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Card Action */}
              <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setGalleryCreator(creator)}
                    className="flex-1 text-center py-2.5 rounded-xl text-xs font-bold font-mono text-agency-gold bg-agency-navy hover:bg-agency-gold hover:text-agency-navy border border-agency-gold/30 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Star className="w-3.5 h-3.5" />
                    <span>View Gallery</span>
                  </button>

                <button
                  type="button"
                  onClick={() => {
                    if (viewState === 'Public') {
                      setIsModalOpen(true);
                    } else {
                      setAssignBriefCreator(creator);
                      setAssignSuccessMsg('');
                    }
                  }}
                  className="flex-1 text-center py-2.5 rounded-xl text-xs font-bold font-mono text-agency-gold bg-agency-navy hover:bg-agency-gold hover:text-agency-navy border border-agency-gold/30 transition-all cursor-pointer"
                >
                  {viewState !== 'Public' ? 'Assign to Brief' : 'Request Availability'}
                </button>

                {viewState !== 'Public' && (
                  <button
                    type="button"
                    onClick={() => {
                      setCreatorsList(prev => prev.filter(c => c.id !== creator.id));
                    }}
                    className="px-3 py-2.5 rounded-xl text-xs font-bold font-mono text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer"
                    title="Delete Creator"
                  >
                    Delete
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Brand Share / Public Showcase Sign-Up CTA - Only shown to unregistered visitors */}
        {isUnregisteredVisitor && (
          <div className="mt-12 bg-gradient-to-r from-agency-navyLight via-[#13223f] to-agency-navyLight border border-agency-gold/40 rounded-3xl p-6 sm:p-10 text-center space-y-4 shadow-2xl relative overflow-hidden">
            <div className="absolute -top-12 -right-12 w-48 h-48 bg-agency-gold/10 rounded-full blur-3xl pointer-events-none" />
            <div className="inline-flex items-center gap-2 text-agency-gold bg-agency-gold/10 border border-agency-gold/30 px-3.5 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-widest">
              <Sparkles className="w-4 h-4" />
              <span>Unlock Complete Talent Roster</span>
            </div>
            <h3 className="text-xl sm:text-2xl md:text-3xl font-serif font-bold text-white max-w-2xl mx-auto leading-tight">
              Want to see our full creator roster? Create a free account to unlock the complete list.
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto font-sans leading-relaxed">
              Register your brand account to connect directly with agency management for custom campaign proposals, direct talent availability, and tailored licensing terms.
            </p>
            <div className="pt-3">
              <button
                type="button"
                id="btn-showcase-signup-cta"
                onClick={() => {
                  setIsModalOpen(true);
                  if (onStartAgencySignup) onStartAgencySignup();
                }}
                className="inline-flex items-center gap-2.5 px-8 py-3.5 rounded-2xl bg-agency-gold hover:bg-amber-400 text-agency-navy font-mono font-bold text-xs sm:text-sm uppercase tracking-wider transition-all shadow-xl active:scale-95 cursor-pointer"
              >
                <span>Create Free Account</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Sticky Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-agency-navyLight/95 backdrop-blur-md border-t border-agency-gold/30 p-4 shadow-2xl">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <span className="text-xs font-bold text-white block">Ready to cast your next beauty, pet, or lifestyle campaign?</span>
            <span className="text-[11px] text-slate-400">Request bespoke creator proposals & tailored campaign quotes with complete legal compliance.</span>
          </div>

          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="inline-flex items-center gap-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-6 py-3 rounded-xl shadow-xl transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Inquire About a Brand Campaign</span>
          </button>
        </div>
      </div>

      {/* Lead Capture Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-agency-navy border border-agency-gold/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5 text-agency-textLight relative">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div>
              <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navyLight border border-agency-gold/30 px-3 py-0.5 rounded-full">
                Brand Campaign Inquiry
              </span>
              <h3 className="font-serif font-bold text-2xl text-white mt-1.5">
                Partner with Bloom Studio Talent
              </h3>
              <p className="text-xs text-slate-400">
                Submit your project specifications to receive custom creator match decks and availability.
              </p>
            </div>

            {submitSuccess ? (
              <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs p-5 rounded-2xl space-y-2 text-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <h4 className="font-bold text-sm text-white">Inquiry Received</h4>
                <p>Our talent director will review your campaign details and deliver a tailored casting match deck within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleLeadSubmit} className="space-y-3.5 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">Brand / Company Name</label>
                    <input
                      type="text"
                      required
                      value={brandLead.brandName}
                      onChange={e => setBrandLead({ ...brandLead, brandName: e.target.value })}
                      className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl px-3 py-2 text-white outline-none"
                      placeholder="e.g., PureGlow Organics"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">Contact Name</label>
                    <input
                      type="text"
                      required
                      value={brandLead.contactName}
                      onChange={e => setBrandLead({ ...brandLead, contactName: e.target.value })}
                      className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl px-3 py-2 text-white outline-none"
                      placeholder="e.g., Jane Doe"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Corporate Work Email</label>
                  <input
                    type="email"
                    required
                    value={brandLead.email}
                    onChange={e => setBrandLead({ ...brandLead, email: e.target.value })}
                    className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl px-3 py-2 text-white outline-none"
                    placeholder="marketing@brand.com"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">Target Vertical</label>
                    <select
                      value={brandLead.nicheInterest}
                      onChange={e => setBrandLead({ ...brandLead, nicheInterest: e.target.value })}
                      className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl px-3 py-2 text-white outline-none"
                    >
                      <option value="Beauty">Beauty / Skincare</option>
                      <option value="Pets">Pets / Canine Wellness</option>
                      <option value="Lifestyle">Luxury Lifestyle</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-300 font-semibold">Estimated Budget</label>
                    <select
                      value={brandLead.budgetTier}
                      onChange={e => setBrandLead({ ...brandLead, budgetTier: e.target.value })}
                      className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl px-3 py-2 text-white outline-none"
                    >
                      <option value="Under $10k">Under $10k</option>
                      <option value="$10k - $25k">$10k - $25k</option>
                      <option value="$25k - $50k">$25k - $50k</option>
                      <option value="$50k+">$50k+ Enterprise</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Campaign Scope &amp; Goals</label>
                  <textarea
                    rows={3}
                    value={brandLead.campaignGoals}
                    onChange={e => setBrandLead({ ...brandLead, campaignGoals: e.target.value })}
                    className="w-full bg-agency-navyLight border border-white/10 focus:border-agency-gold rounded-xl p-3 text-white outline-none"
                    placeholder="Briefly describe target deliverables, launch timeline, and whitelisting requirements..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs shadow-lg transition-all cursor-pointer disabled:opacity-50 mt-2"
                >
                  {submitting ? 'Submitting Inquiry...' : 'Submit Campaign Inquiry'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Creator Gallery Modal */}
      {galleryCreator && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">
          <div className="bg-agency-navy border border-agency-gold/40 rounded-3xl p-6 sm:p-8 max-w-4xl w-full shadow-2xl space-y-6 text-agency-textLight relative animate-fade-in">
            <button
              type="button"
              onClick={() => setGalleryCreator(null)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-2 bg-white/5 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-4 border-b border-white/10 pb-4">
              <img src={galleryCreator.avatarUrl} alt="" className="w-12 h-12 rounded-xl object-cover border border-agency-gold/30" />
              <div>
                <h3 className="font-serif font-bold text-2xl text-white">{galleryCreator.name}</h3>
                <p className="text-xs font-mono text-agency-gold">{galleryCreator.handle} &bull; {galleryCreator.niche} Roster</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
              {(galleryCreator.galleryImages && galleryCreator.galleryImages.length > 0) ? (
                galleryCreator.galleryImages.map((img, idx) => (
                  <div key={idx} className="relative group aspect-[4/5] rounded-2xl overflow-hidden border border-white/10 shadow-lg">
                    <img src={img} alt={`${galleryCreator.name} gallery ${idx + 1}`} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                      <span className="text-[10px] font-mono text-white/80">Photo {idx + 1}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-full py-12 text-center space-y-3">
                  <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto">
                    <Star className="w-8 h-8 text-slate-600" />
                  </div>
                  <p className="text-slate-400 font-mono text-xs">No gallery images uploaded for this creator yet.</p>
                </div>
              )}
            </div>

            {/* Director Upload in Gallery View */}
            {isExecutiveManager && viewState === 'Director' && (
              <div className="bg-agency-navyLight border border-agency-gold/20 p-5 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-agency-gold" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Director Asset Controls</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">Add up to 5 photos for the public showcase</span>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  <label className="flex-1 min-w-[200px] group relative bg-agency-navy border-2 border-dashed border-white/10 hover:border-agency-gold/50 rounded-xl p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all">
                    <Video className="w-5 h-5 text-agency-gold" />
                    <span className="text-[10px] font-mono text-slate-400 group-hover:text-agency-gold transition-colors">Upload New Asset</span>
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = (evt) => {
                          if (evt.target?.result) {
                            const newImg = String(evt.target?.result);
                            setCreatorsList(prev => prev.map(c => 
                              c.id === galleryCreator.id 
                                ? { ...c, galleryImages: [...(c.galleryImages || []), newImg].slice(0, 5) } 
                                : c
                            ));
                            // Update the currently viewed gallery data too
                            setGalleryCreator(prev => prev ? { 
                              ...prev, 
                              galleryImages: [...(prev.galleryImages || []), newImg].slice(0, 5) 
                            } : null);
                          }
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                  
                  {(galleryCreator.galleryImages || []).length > 0 && (
                    <button 
                      onClick={() => {
                        setCreatorsList(prev => prev.map(c => c.id === galleryCreator.id ? { ...c, galleryImages: [] } : c));
                        setGalleryCreator(prev => prev ? { ...prev, galleryImages: [] } : null);
                      }}
                      className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 text-[10px] font-mono rounded-xl transition-all h-full self-center"
                    >
                      Clear All Assets
                    </button>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-center pt-2">
              <button
                type="button"
                onClick={() => {
                  setGalleryCreator(null);
                  setIsModalOpen(true);
                }}
                className="inline-flex items-center gap-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-8 py-3.5 rounded-2xl shadow-xl transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Cast {galleryCreator.name} for Your Brand</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Creator Modal */}
      {isAddCreatorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-agency-navy border border-emerald-500/40 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5 text-agency-textLight relative">
            <button
              type="button"
              onClick={() => setIsAddCreatorOpen(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-emerald-400 bg-emerald-950 border border-emerald-500/30 px-3 py-0.5 rounded-full">
                Internal Talent Management
              </span>
              <h3 className="font-serif font-bold text-2xl text-white mt-1.5">
                Add New Creator Profile
              </h3>
            </div>
            
            <form onSubmit={(e) => {
              e.preventDefault();
              setCreatorsList([
                ...creatorsList,
                {
                  id: `c_${Date.now()}`,
                  name: newCreator.name || '',
                  handle: newCreator.handle || '',
                  niche: (newCreator.niche as 'Beauty' | 'Pets' | 'Lifestyle') || 'Beauty',
                  followers: newCreator.followers || '0',
                  engagement: newCreator.engagement || '0%',
                  avatarUrl: newCreator.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
                  tags: newCreator.tags || [],
                  specialty: newCreator.specialty || '',
                  verifiedFtc: true,
                  contractRevenue: "$0",
                  agencyProfitMargin: "0%",
                  managerPayroll: "$0"
                }
              ]);
              setIsAddCreatorOpen(false);
              setNewCreator({ name: '', handle: '', niche: 'Beauty', followers: '', engagement: '', specialty: '', avatarUrl: '', tags: [], galleryImages: [], contractRevenue: '$0', agencyProfitMargin: '0%', managerPayroll: '$0' });
            }} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Creator Name</label>
                  <input type="text" required value={newCreator.name} onChange={e => setNewCreator({...newCreator, name: e.target.value})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="e.g. Jane Doe" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Social Handle</label>
                  <input type="text" required value={newCreator.handle} onChange={e => setNewCreator({...newCreator, handle: e.target.value})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="@handle" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Niche</label>
                  <select value={newCreator.niche} onChange={e => setNewCreator({...newCreator, niche: e.target.value as any})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500">
                    <option value="Beauty">Beauty</option>
                    <option value="Pets">Pets</option>
                    <option value="Lifestyle">Lifestyle</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Followers</label>
                  <input type="text" required value={newCreator.followers} onChange={e => setNewCreator({...newCreator, followers: e.target.value})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="e.g. 500K" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-300 font-semibold">Engagement</label>
                  <input type="text" required value={newCreator.engagement} onChange={e => setNewCreator({...newCreator, engagement: e.target.value})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="e.g. 5.2%" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Avatar Image URL</label>
                <input type="url" value={newCreator.avatarUrl} onChange={e => setNewCreator({...newCreator, avatarUrl: e.target.value})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="https://..." />
              </div>
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Gallery Images (comma separated URLs)</label>
                <textarea rows={2} value={newCreator.galleryImages?.join(', ')} onChange={e => setNewCreator({...newCreator, galleryImages: e.target.value.split(',').map(t => t.trim()).filter(Boolean)})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="https://url1.com, https://url2.com" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Specialty / Bio</label>
                <textarea rows={2} required value={newCreator.specialty} onChange={e => setNewCreator({...newCreator, specialty: e.target.value})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="Brief description of their content style..." />
              </div>
              <div className="space-y-1">
                <label className="text-slate-300 font-semibold">Tags (comma separated)</label>
                <input type="text" value={newCreator.tags?.join(', ')} onChange={e => setNewCreator({...newCreator, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean)})} className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white outline-none focus:border-emerald-500" placeholder="Skincare, GRWM, Routine" />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-agency-navy font-bold text-xs shadow-lg transition-all cursor-pointer mt-2"
              >
                Add Creator to Roster
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Assign to Brief Modal */}
      {assignBriefCreator && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-[#0D1830] border border-agency-gold/40 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase text-agency-gold bg-agency-gold/10 px-2.5 py-0.5 rounded-full border border-agency-gold/30">
                  Brief Assignment Dispatch
                </span>
                <h3 className="text-lg font-serif font-bold text-white mt-1">
                  Assign {assignBriefCreator.name} to Brief
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setAssignBriefCreator(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {assignSuccessMsg ? (
              <div className="bg-emerald-950/50 border border-emerald-500/40 p-4 rounded-2xl text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <p className="text-xs font-bold text-white">{assignSuccessMsg}</p>
                <button
                  type="button"
                  onClick={() => setAssignBriefCreator(null)}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl cursor-pointer mt-2"
                >
                  Close
                </button>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                <div className="bg-[#111E33] p-3 rounded-xl border border-white/10 flex items-center gap-3">
                  <img src={assignBriefCreator.avatarUrl} alt="" className="w-10 h-10 rounded-xl object-cover" />
                  <div>
                    <div className="font-bold text-white">{assignBriefCreator.name}</div>
                    <div className="text-[10px] text-agency-gold font-mono">{assignBriefCreator.handle} &bull; {assignBriefCreator.niche}</div>
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-mono block mb-1">Select Active Campaign Brief</label>
                  <select
                    value={selectedBriefTitle}
                    onChange={e => setSelectedBriefTitle(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2.5 text-white font-mono outline-none focus:border-agency-gold cursor-pointer"
                  >
                    <option value="Summer Glow Skincare UGC">Summer Glow Skincare UGC (Brand: Botanical Beauty)</option>
                    <option value="Organic Pet Balm Seeding">Organic Pet Balm Seeding (Brand: Paws & Co)</option>
                    <option value="Aesthetic Home Diffuser Campaign">Aesthetic Home Diffuser Campaign (Brand: Velvet Home)</option>
                    <option value="Q3 Athleisure Launch">Q3 Athleisure Launch (Brand: Alo Men)</option>
                  </select>
                </div>

                <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setAssignBriefCreator(null)}
                    className="px-4 py-2 bg-[#111E33] hover:bg-[#16243F] text-slate-300 rounded-xl font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAssignSuccessMsg(`Successfully assigned ${assignBriefCreator.name} to brief "${selectedBriefTitle}". Creator notified.`);
                    }}
                    className="px-5 py-2 bg-agency-gold hover:bg-amber-400 text-slate-950 font-bold rounded-xl cursor-pointer shadow-lg transition-all"
                  >
                    Confirm Assignment
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      <PortfolioContactFooter />
      </div>
    </DAPSContainer>
  );
}
