import React, { useState } from 'react';
import { Mail, Copy, CheckCircle2, ShieldCheck, Sparkles, Send, Clock } from 'lucide-react';

interface EmailTemplateProps {
  campaignName?: string;
  brandName?: string;
  contactName?: string;
  managerName?: string;
  directorName?: string;
  portalUrl?: string;
  creatorHandle?: string;
}

/**
 * 1. ManagerClientEmailTemplate:
 * Copy-and-paste outreach template for staff/managers to deliver finalized campaign wrap-up reports.
 * 100% free of internal jargon, payouts, or sensitive pricing data.
 */
export function ManagerClientEmailTemplate({
  campaignName = "Summer Glow & Pet Hydration Push",
  brandName = "GlowLab Beauty & BarkHydrate",
  contactName = "Brand Marketing Team",
  managerName = "Sarah J.",
  portalUrl = "https://bloomstudio.agency/portal/glowlab"
}: EmailTemplateProps) {
  const [copied, setCopied] = useState(false);

  const subjectLine = `Bloom Studio Campaign Wrap-Up Report: ${campaignName}`;
  const bodyText = `Dear ${contactName},

On behalf of the entire team at Bloom Studio, thank you for collaborating with us on the ${campaignName} campaign! It has been an absolute pleasure partnering with ${brandName} to bring this creative vision to life across our dedicated pet, beauty, and lifestyle creator network.

We are thrilled to share that all campaign milestones and content deliverables have been successfully finalized. Attached to this email, you will find your official Bloom Studio White-Paper Wrap-Up Report. 

This comprehensive executive briefing details:
• Total Campaign Reach & Cumulative Video Impressions across TikTok & Instagram
• Audience Engagement Benchmarks & Creator Conversion Performance
• Verified 100% FTC Caption Compliance Checkmark Scores & Content Safety Audits

In addition to the attached PDF, you are warmly invited to log into your customized Bloom Studio Brand Portal at any time to stream high-resolution 4K asset masters, review creator copy transcripts, or access historical campaign archives:
${portalUrl}

Thank you once again for your partnership and trust in Bloom Studio. Please let us know if you need any additional asset cutdowns or whitelisting authorizations.

Warm regards,

${managerName}
Campaign Account Coordinator | Bloom Studio
${portalUrl}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(`Subject: ${subjectLine}\n\n${bodyText}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-5 space-y-4 shadow-lg text-agency-textLight">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <Mail className="w-4 h-4 text-agency-gold" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-white">
            Manager Client Wrap-Up Outreach Template
          </h4>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 text-xs font-mono font-bold bg-agency-gold hover:bg-[#b89359] text-agency-navy px-3.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-md"
        >
          {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied to Clipboard!' : 'Copy Template'}</span>
        </button>
      </div>

      <div className="space-y-2 text-xs font-mono">
        <div className="bg-agency-navy p-2.5 rounded-xl border border-white/5">
          <span className="text-slate-400 font-bold">Subject: </span>
          <span className="text-agency-gold">{subjectLine}</span>
        </div>
        <pre className="bg-agency-navy p-3.5 rounded-xl border border-white/5 whitespace-pre-wrap font-sans text-slate-300 text-xs leading-relaxed">
          {bodyText}
        </pre>
      </div>
    </div>
  );
}

/**
 * 2. DirectorClientEmailTemplate:
 * Authoritative, executive outreach template reserved exclusively for the Agency Principal / Director.
 */
export function DirectorClientEmailTemplate({
  brandName = "GlowLab Beauty & BarkHydrate",
  contactName = "Executive Leadership & Brand Counsel",
  directorName = "Agency Principal",
  portalUrl = "https://bloomstudio.agency/director-review"
}: EmailTemplateProps) {
  const [copied, setCopied] = useState(false);

  const subjectLine = `Executive Review & Compliance Briefing: ${brandName} x Bloom Studio`;
  const bodyText = `Dear ${contactName},

I am writing to personally present the executive performance and legal audit briefing for our recent campaign collaboration with ${brandName}.

At Bloom Studio, our foremost commitment is ensuring that every creative deployment simultaneously drives measurable consumer resonance while safeguarding your corporate brand integrity. Through our rigorous pre-broadcast screening, our talent executions maintained an absolute 100% FTC disclosure scoring alongside comprehensive copyright and commercial audio synchronization clearances—ensuring zero regulatory exposure and total safety for your paid digital ad whitelisting.

Attached below, please find your formal, print-ready Campaign Executive Brief and Wrap-Up Report detailing verified reach metrics, engagement yield, and safety certifications.

As we look toward the upcoming seasonal casting cycles in the beauty, pet, and luxury lifestyle sectors, I would welcome the opportunity to schedule a brief 15-minute strategic alignment call next week to review emerging talent rosters and tailored audience scaling strategies.

Thank you for your ongoing partnership with Bloom Studio.

With highest regards,

${directorName}
Studio Director & Principal | Bloom Studio
director@bloomstudio.com`;

  const handleCopy = () => {
    navigator.clipboard.writeText(`Subject: ${subjectLine}\n\n${bodyText}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="bg-agency-navyLight border border-agency-gold/30 rounded-2xl p-5 space-y-4 shadow-xl text-agency-textLight">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-agency-gold" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-agency-gold">
            Director Executive C-Level Outreach Template
          </h4>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 text-xs font-mono font-bold bg-agency-gold hover:bg-[#b89359] text-agency-navy px-3.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-md"
        >
          {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied to Clipboard!' : 'Copy Executive Template'}</span>
        </button>
      </div>

      <div className="space-y-2 text-xs font-mono">
        <div className="bg-agency-navy p-2.5 rounded-xl border border-agency-gold/20">
          <span className="text-slate-400 font-bold">Subject: </span>
          <span className="text-agency-gold">{subjectLine}</span>
        </div>
        <pre className="bg-agency-navy p-3.5 rounded-xl border border-white/5 whitespace-pre-wrap font-sans text-slate-300 text-xs leading-relaxed">
          {bodyText}
        </pre>
      </div>
    </div>
  );
}

/**
 * 3. InboundBrandWelcomeEmail:
 * Formal confirmation email dispatched upon brand campaign intake submission.
 */
export function InboundBrandWelcomeEmail({
  brandName = "Lumina Cosmetics LLC",
  contactName = "Brand Marketing Lead",
  portalUrl = "https://bloomstudio.agency/brand-portal"
}: EmailTemplateProps) {
  const [copied, setCopied] = useState(false);

  const subjectLine = `Campaign Intake Received: Welcome to Bloom Studio x ${brandName}`;
  const bodyText = `Dear ${contactName},

Thank you for submitting your campaign briefing to Bloom Studio. We have successfully logged ${brandName} into our secure talent routing matrix.

Our Studio Director and Senior Agent Managers are currently reviewing your vertical targeting parameters, deliverable scope, and target flight window. We are matching your brief against verified creators in our Pet, Cosmetics & Beauty, and Luxury Lifestyle rosters who demonstrate:
• 100% Verified FTC Compliance track records
• High-converting audience demographic alignment
• Proven brand engagement benchmarks

NEXT STEPS:
1. Dossier Matching: Within 24-48 business hours, you will receive a tailored Creator Casting Deck featuring pre-screened talent options.
2. Secure Sandbox Access: You can monitor progress and review live deliverables via your dedicated Brand Portal:
   ${portalUrl}
3. Escrow Safeguards: All financial disbursements remain held under programmatic escrow until content delivery is approved.

If you have any urgent timing adjustments, please reply directly to this briefing. We look forward to executing a high-impact campaign together.

Sincerely,

The Bloom Studio Brand Partnerships Team
director@bloomstudio.agency`;

  const handleCopy = () => {
    navigator.clipboard.writeText(`Subject: ${subjectLine}\n\n${bodyText}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-5 space-y-4 shadow-lg text-agency-textLight">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <Send className="w-4 h-4 text-agency-gold" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-white">
            Inbound Brand Welcome &amp; Intake Confirmation Email
          </h4>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 text-xs font-mono font-bold bg-agency-gold hover:bg-[#b89359] text-agency-navy px-3.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-md"
        >
          {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied to Clipboard!' : 'Copy Welcome Email'}</span>
        </button>
      </div>

      <div className="space-y-2 text-xs font-mono">
        <div className="bg-agency-navy p-2.5 rounded-xl border border-white/5">
          <span className="text-slate-400 font-bold">Subject: </span>
          <span className="text-agency-gold">{subjectLine}</span>
        </div>
        <pre className="bg-agency-navy p-3.5 rounded-xl border border-white/5 whitespace-pre-wrap font-sans text-slate-300 text-xs leading-relaxed">
          {bodyText}
        </pre>
      </div>
    </div>
  );
}

/**
 * 4. DirectorMasterBrandPitch:
 * High-touch B2B outreach email template with vertical-specific variations (Cosmetics, Pet, Luxury Lifestyle).
 */
export function DirectorMasterBrandPitch({
  brandName = "Brand Executive Team",
  contactName = "VP of Brand Marketing",
  directorName = "Agency Principal"
}: EmailTemplateProps) {
  const [selectedVertical, setSelectedVertical] = useState<'Cosmetics' | 'Pet' | 'Lifestyle'>('Cosmetics');
  const [copied, setCopied] = useState(false);

  const verticalHooks = {
    Cosmetics: {
      subject: `Exclusive Roster Casting: Next-Gen Clean Beauty & Cosmetics Creators x ${brandName}`,
      angle: `I am reaching out regarding ${brandName}'s recent product innovations in clean cosmetics. Bloom Studio represents a curated, top-tier roster of beauty innovators specializing in high-converting 4K video tutorials, visual shade matching, and viral TikTok formula deep-dives.`
    },
    Pet: {
      subject: `Strategic Talent Alignment: Premium Pet Wellness & Nutrition Creators x ${brandName}`,
      angle: `I am reaching out regarding ${brandName}'s leadership in premium pet wellness. Bloom Studio manages an exclusive roster of dedicated canine/feline nutrition and pet lifestyle creators whose audiences actively invest in premium, organic pet care solutions.`
    },
    Lifestyle: {
      subject: `Curated Creator Partnership: Luxury Lifestyle & Wellness Integrations x ${brandName}`,
      angle: `I am reaching out regarding ${brandName}'s luxury lifestyle footprint. Bloom Studio represents high-aesthetic creators who seamlessly weave premium product placements into daily morning routines, travel vlogs, and architectural interior showcases.`
    }
  };

  const currentHook = verticalHooks[selectedVertical];
  const subjectLine = currentHook.subject;
  const bodyText = `Dear ${contactName},

${currentHook.angle}

Unlike standard talent agencies, Bloom Studio operates on a closed, software-governed architecture designed specifically for enterprise brand protection:
• 100% Verified FTC Compliance: Every deliverable passes pre-broadcast legal scanning ensuring zero regulatory exposure.
• Programmatic Escrow & Milestone Safety: Campaign budgets are safeguarded until deliverables are fully verified.
• Commercial Whitelisting & Spark Ad Clearances: Raw 4K master files and ad authorization codes ready for paid amplification.

We are currently locking in Q3/Q4 campaign flights for our primary roster. I would welcome a 10-minute introductory conversation next Tuesday or Thursday to share a private talent match deck customized for ${brandName}.

Please let me know if either day suits your schedule.

Warm regards,

${directorName}
Studio Director & Managing Partner | Bloom Studio
director@bloomstudio.agency`;

  const handleCopy = () => {
    navigator.clipboard.writeText(`Subject: ${subjectLine}\n\n${bodyText}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="bg-agency-navyLight border border-agency-gold/30 rounded-2xl p-5 space-y-4 shadow-xl text-agency-textLight">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-3 gap-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-agency-gold" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-agency-gold">
            Director Master B2B Brand Pitch Outreach
          </h4>
        </div>

        {/* Vertical Switcher */}
        <div className="flex items-center gap-1 bg-agency-navy p-1 rounded-xl border border-white/10">
          {(['Cosmetics', 'Pet', 'Lifestyle'] as const).map(vert => (
            <button
              type="button"
              key={vert}
              onClick={() => setSelectedVertical(vert)}
              className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition cursor-pointer ${
                selectedVertical === vert
                  ? 'bg-agency-gold text-agency-navy'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {vert}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2 text-xs font-mono">
        <div className="bg-agency-navy p-2.5 rounded-xl border border-agency-gold/20">
          <span className="text-slate-400 font-bold">Subject: </span>
          <span className="text-agency-gold">{subjectLine}</span>
        </div>
        <pre className="bg-agency-navy p-3.5 rounded-xl border border-white/5 whitespace-pre-wrap font-sans text-slate-300 text-xs leading-relaxed">
          {bodyText}
        </pre>
      </div>
    </div>
  );
}

/**
 * 5. BrandReviewUrgentWarningEmail:
 * 12-hour urgent expiration warning email template notifying brand clients of review window lock.
 */
export function BrandReviewUrgentWarningEmail({
  brandName = "Brand Marketing Team",
  campaignName = "Summer Clean Beauty Flight",
  creatorHandle = "@olivia.glows",
  managerName = "Lead Campaign Manager"
}: EmailTemplateProps) {
  const [copied, setCopied] = useState(false);

  const subjectLine = `URGENT ACTION REQUIRED: 12 Hours Remaining on Campaign Review Window [${campaignName}]`;
  const bodyText = `Dear ${brandName},

This is an automated priority notification from Bloom Studio Campaign Logistics regarding your active project: ${campaignName} featuring ${creatorHandle}.

Your 2-business-day content review window will formally conclude in precisely 12 hours. 

CURRENT ASSET STATUS:
• Deliverable Asset: 4K 9:16 Video Master + FTC Pre-Scanned Caption
• Review Portal: Bloom Studio Brand Client Console
• Current Status: Awaiting Brand Revision Log or Final Authorization

AUTOMATIC PRODUCTION LOCK NOTICE:
In strict alignment with Section 4.2 of our Master Production Agreement, if no timestamped revision requests are registered within your Brand Review Console within the next 12 hours, this deliverable will automatically lock and transition to Scheduled Live Publication to protect creator release calendars.

ACTION REQUIRED:
Please access your private Bloom Studio Brand Console immediately to either log timestamp modifications or click 'Approve Draft for Live Release':
👉 https://portal.bloomstudio.agency/review/${campaignName.toLowerCase().replace(/[^a-z0-9]/g, '-')}

If you require an emergency window extension, please reply directly to this notice with your revised submission timeframe.

Sincerely,

${managerName}
Campaign Operations & Talent Delivery | Bloom Studio
campaigns@bloomstudio.agency`;

  const handleCopy = () => {
    navigator.clipboard.writeText(`Subject: ${subjectLine}\n\n${bodyText}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="bg-agency-navyLight border border-amber-500/40 rounded-2xl p-5 space-y-4 shadow-xl text-agency-textLight">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
          <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
            Urgent 12-Hour Review Window Expiration Warning
          </h4>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 text-xs font-mono font-bold bg-agency-gold hover:bg-[#b89359] text-agency-navy px-3.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-md"
        >
          {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied to Clipboard!' : 'Copy Urgent Notice'}</span>
        </button>
      </div>

      <div className="space-y-2 text-xs font-mono">
        <div className="bg-agency-navy p-2.5 rounded-xl border border-amber-500/20">
          <span className="text-slate-400 font-bold">Subject: </span>
          <span className="text-amber-300">{subjectLine}</span>
        </div>
        <pre className="bg-agency-navy p-3.5 rounded-xl border border-white/5 whitespace-pre-wrap font-sans text-slate-300 text-xs leading-relaxed">
          {bodyText}
        </pre>
      </div>
    </div>
  );
}

