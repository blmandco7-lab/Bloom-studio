import React, { useState, useEffect, useMemo } from 'react';
import { getSafeUrl } from '../utils/security';
import { 
  Megaphone, Plus, Search, Filter, CheckCircle, Clock, X, 
  User, DollarSign, MapPin, Calendar, Sparkles, FileText, 
  Send, Award, Star, Check, AlertCircle, ChevronRight, Briefcase, Link as LinkIcon
, Lock } from 'lucide-react';
import { Creator, Deal } from '../types';
import { db } from '../lib/firebase';
import { collection, onSnapshot, setDoc, doc, query, where } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';
import { checkBrandBlacklist } from '../lib/blacklistService';

export interface CastingApplication {
  id: string;
  creatorHandle: string;
  creatorName?: string;
  avatarUrl?: string;
  appliedAt?: string;
  pitchNote?: string;
  status: 'Pending' | 'Shortlisted' | 'Accepted' | 'Declined' | 'pending' | 'approved' | 'rejected' | 'shortlisted' | 'accepted' | 'declined';
  // Firestore casting application fields
  castingCallId?: string;
  creatorId?: string;
  pitch?: string;
  link?: string;
  submittedAt?: string;
  subagency?: string;
}

function cleanUndefinedForFirestore(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;
  const copy = { ...obj };
  Object.keys(copy).forEach(key => {
    if (copy[key] === undefined) {
      delete copy[key];
    }
  });
  return copy;
}

function isCallDeadlinePassed(deadlineStr: string): boolean {
  if (!deadlineStr) return false;
  const lower = deadlineStr.toLowerCase().trim();
  if (lower.includes('expired') || lower.includes('past') || lower.includes('closed')) {
    return true;
  }
  const parsed = new Date(deadlineStr);
  if (!isNaN(parsed.getTime())) {
    const now = new Date();
    parsed.setHours(23, 59, 59, 999);
    return now.getTime() > parsed.getTime();
  }
  return false;
}

export interface CastingCall {
  id: string;
  title: string;
  brand: string;
  type: 'Commercial' | 'Runway' | 'Modeling' | 'Event' | 'Brand Ambassador';
  pay: string;
  requirements: string;
  location: string;
  deadline: string;
  status: 'Open' | 'Closed';
  createdAt: string;
  applications: CastingApplication[];
}

interface CastingCallsProps {
  currentRole: string;
  currentUser: any;
  creators: Creator[];
  deals: Deal[];
  setDeals: React.Dispatch<React.SetStateAction<Deal[]>>;
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  primaryBrandColor?: string;
}

const DEFAULT_CASTING_CALLS: CastingCall[] = [
  {
    id: 'cast_1',
    title: 'Autumn Fashion Week Runway & Lookbook Lead Model',
    brand: 'Vogue Milano & Bloom Fashion',
    type: 'Runway',
    pay: '$4,500 / Day Shoot',
    requirements: 'Editorial / Runway modeling experience. Must be available for NYC / Milan multi-day shoots and lookbook stills.',
    location: 'New York, NY (In-Person)',
    deadline: '2026-09-30',
    status: 'Open',
    createdAt: new Date().toISOString(),
    applications: []
  },
  {
    id: 'cast_2',
    title: 'National Television & Streaming Commercial Lead Talent',
    brand: 'Equinox Luxury Wellness',
    type: 'Commercial',
    pay: '$6,000 + SAG-AFTRA Residuals',
    requirements: 'High athletic fitness, expressive on-camera presence, speaking role with 30s broadcast commercial script.',
    location: 'Los Angeles, CA',
    deadline: '2026-10-15',
    status: 'Open',
    createdAt: new Date().toISOString(),
    applications: []
  },
  {
    id: 'cast_3',
    title: 'Sephora Global Beauty Billboard & Print Campaign',
    brand: 'Sephora Collection',
    type: 'Modeling',
    pay: '$5,200 + Global Print Rights',
    requirements: 'High-definition macro beauty skin shots, luminous smile, clear natural skin texture.',
    location: 'Miami, FL',
    deadline: '2026-09-25',
    status: 'Open',
    createdAt: new Date().toISOString(),
    applications: []
  },
  {
    id: 'cast_4',
    title: 'Luxury Automotive Brand Ambassador & Event Host',
    brand: 'Porsche Studio Live',
    type: 'Brand Ambassador',
    pay: '$3,800 Weekend Retainer',
    requirements: 'Polished presenter, VIP client engagement experience, event hosting background.',
    location: 'Austin, TX',
    deadline: '2026-10-05',
    status: 'Open',
    createdAt: new Date().toISOString(),
    applications: []
  }
];

export default function CastingCalls({
  currentRole,
  currentUser,
  creators,
  deals,
  setDeals,
  onAddActivityLog,
  triggerNotification,
  primaryBrandColor = '#c7a77d'
}: CastingCallsProps) {
  const userRoleLower = currentRole.toLowerCase();
  const isRealDirector = userRoleLower === 'director' || userRoleLower === 'agency';
  const isAgentMgr = userRoleLower === 'agentmgr';
  
  const [allowManagerCasting, setAllowManagerCasting] = useState<boolean>(() => {
    return safeStorage.getItem('wl_allow_manager_casting') === 'true';
  });

  const canCreateCasting = isRealDirector || (isAgentMgr && allowManagerCasting);
  const isDirector = ['director', 'agentmgr', 'agency', 'subagency'].includes(userRoleLower);

  const toggleManagerCastingPermission = () => {
    const nextVal = !allowManagerCasting;
    setAllowManagerCasting(nextVal);
    safeStorage.setItem('wl_allow_manager_casting', String(nextVal));
    triggerNotification?.(
      nextVal ? 'Manager Casting Unlocked' : 'Manager Casting Locked',
      nextVal ? 'Agent Managers are now permitted to create casting calls.' : 'Casting creation restricted to Director only.',
      nextVal ? 'success' : 'info'
    );
    onAddActivityLog?.(currentUser?.name || 'User', currentRole, `Toggled Manager Casting Permission to ${nextVal}`);
  };
  const creatorHandle = currentUser?.handle || creators?.[0]?.handle || '@creator';

  const [castingCalls, setCastingCalls] = useState<CastingCall[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_casting_calls');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_CASTING_CALLS;
  });

  useEffect(() => {
    try {
      safeStorage.setItem('wl_casting_calls', JSON.stringify(castingCalls));
    } catch {}
  }, [castingCalls]);

  useEffect(() => {
    const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
    const isOwner = !!currentUser?.isPlatformOwner;
    const isCreatorRole = userRoleLower === 'creator';
    
    let baseQuery;
    if (isOwner) {
      baseQuery = collection(db, 'studio-casting-applications');
    } else if (isCreatorRole) {
      baseQuery = query(
        collection(db, 'studio-casting-applications'),
        where('creatorId', '==', currentUser?.id || currentUser?.uid || '')
      );
    } else {
      baseQuery = query(
        collection(db, 'studio-casting-applications'),
        where('subagency', '==', userPod)
      );
    }

    const unsub = onSnapshot(baseQuery, (snapshot) => {
      if (!snapshot.empty) {
        const firestoreApps: CastingApplication[] = [];
        snapshot.forEach(docSnap => {
          const data = docSnap.data();
          firestoreApps.push({
            id: docSnap.id,
            castingCallId: data.castingCallId,
            creatorId: data.creatorId,
            creatorHandle: data.creatorHandle || '@creator',
            creatorName: data.creatorName || data.creatorHandle || 'Creator',
            avatarUrl: data.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
            appliedAt: data.appliedAt || (data.submittedAt ? new Date(data.submittedAt).toLocaleDateString() : 'Today'),
            submittedAt: data.submittedAt,
            pitchNote: data.pitchNote || data.pitch || '',
            pitch: data.pitch || data.pitchNote || '',
            link: data.link || '',
            status: data.status || 'pending',
            subagency: data.subagency || 'pod_main'
          });
        });

        setCastingCalls(prev => {
          return prev.map(call => {
            const mergedApps = [...call.applications];
            firestoreApps.forEach(fApp => {
              if (fApp.castingCallId === call.id) {
                const idx = mergedApps.findIndex(a => a.id === fApp.id || (a.creatorHandle && fApp.creatorHandle && a.creatorHandle.toLowerCase() === fApp.creatorHandle.toLowerCase()));
                if (idx >= 0) {
                  mergedApps[idx] = { ...mergedApps[idx], ...fApp };
                } else {
                  mergedApps.push(fApp);
                }
              }
            });
            return { ...call, applications: mergedApps };
          });
        });
      }
    }, (err) => {
      console.warn('Error listening to studio-casting-applications:', err?.message || err);
    });

    return () => unsub();
  }, []);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<'Active' | 'Expired' | 'All'>('Active');
  const [selectedCallId, setSelectedCallId] = useState<string | null>(null);

  const isExpiredCall = (call: CastingCall) => call.status === 'Closed' || isCallDeadlinePassed(call.deadline);

  // Modal states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [applyCall, setApplyCall] = useState<CastingCall | null>(null);
  const [pitchNote, setPitchNote] = useState('');
  const [portfolioLink, setPortfolioLink] = useState('');

  // Create form state
  const [newCall, setNewCall] = useState({
    title: '',
    brand: '',
    type: 'Commercial' as CastingCall['type'],
    pay: '',
    requirements: '',
    location: 'Remote',
    deadline: ''
  });

  // Handle Create Casting Call
  const handleCreateCall = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCall.title || !newCall.brand || !newCall.pay) {
      triggerNotification('Missing Fields', 'Title, Brand, and Pay are required.', 'danger');
      return;
    }

    const cleanBrand = newCall.brand.trim();
    const blCheck = await checkBrandBlacklist(cleanBrand, currentUser?.tenantId);
    if (blCheck.isBlacklisted) {
      triggerNotification(
        'Casting Call Blocked',
        `Brand '${blCheck.matchedBrand || cleanBrand}' is on the Global Blacklist (${blCheck.reason}). Cannot create casting calls for blacklisted brands.`,
        'danger'
      );
      return;
    }

    const created: CastingCall = {
      id: 'cast_' + Date.now(),
      title: newCall.title,
      brand: newCall.brand,
      type: newCall.type,
      pay: newCall.pay,
      requirements: newCall.requirements || 'No specific requirements outlined.',
      location: newCall.location || 'Remote',
      deadline: newCall.deadline || new Date(Date.now() + 14 * 24 * 3600 * 1000).toISOString().slice(0, 10),
      status: 'Open',
      createdAt: 'Just now',
      applications: []
    };

    const updated = [created, ...castingCalls];
    setCastingCalls(updated);
    setIsCreateModalOpen(false);
    setNewCall({ title: '', brand: '', type: 'Commercial', pay: '', requirements: '', location: 'Remote', deadline: '' });

    onAddActivityLog(currentUser?.name || 'User', currentRole, `Created new casting call: "${created.title}" for ${created.brand}`);
    triggerNotification('Casting Call Published', `"${created.title}" is now live for creator applications.`, 'success');
  };

  // Handle Apply to Casting Call (Creator)
  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyCall) return;

    const nowIso = new Date().toISOString();
    const appId = 'app_' + Date.now();
    const newApp: CastingApplication = {
      id: appId,
      castingCallId: applyCall.id,
      creatorId: currentUser?.id || currentUser?.uid || 'creator_user',
      creatorHandle: creatorHandle,
      creatorName: currentUser?.name || 'Alex Jones',
      avatarUrl: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      appliedAt: 'Just now',
      submittedAt: nowIso,
      pitchNote: pitchNote.trim() || 'Excited to collaborate on this campaign!',
      pitch: pitchNote.trim() || 'Excited to collaborate on this campaign!',
      link: getSafeUrl(portfolioLink.trim()),
      status: 'pending',
      subagency: 'pod_main'
    };

    const updated = castingCalls.map(c => {
      if (c.id === applyCall.id) {
        // Prevent duplicate application
        const exists = c.applications.some(a => a.creatorHandle.toLowerCase() === creatorHandle.toLowerCase() || (a.creatorId && a.creatorId === (currentUser?.id || currentUser?.uid)));
        if (exists) return c;
        return { ...c, applications: [newApp, ...c.applications] };
      }
      return c;
    });

    setCastingCalls(updated);
    setIsApplyModalOpen(false);
    setPitchNote('');
    setPortfolioLink('');
    setApplyCall(null);

    // Write application to Firestore studio-casting-applications collection
    const docRef = doc(db, 'studio-casting-applications', appId);
    setDoc(docRef, cleanUndefinedForFirestore({
      id: appId,
      castingCallId: applyCall.id,
      creatorId: currentUser?.id || currentUser?.uid || 'creator_user',
      creatorHandle: creatorHandle,
      pitch: pitchNote.trim() || 'Excited to collaborate on this campaign!',
      link: getSafeUrl(portfolioLink.trim()),
      portfolioUrl: getSafeUrl(portfolioLink.trim()),
      status: 'pending',
      submittedAt: nowIso,
      subagency: currentUser?.subagency || currentUser?.tenantId || 'pod_main',
      creatorName: currentUser?.name || 'Alex Jones',
      avatarUrl: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      appliedAt: 'Just now'
    }), { merge: true }).catch(err => {
      console.warn('Could not save casting application to Firestore studio-casting-applications (permission denied under current rules):', err);
    });

    onAddActivityLog(currentUser?.name || 'Creator', 'creator', `Applied to casting call: "${applyCall.title}"`);
    triggerNotification('Application Submitted', `Your pitch for "${applyCall.title}" was submitted to agency directors.`, 'success');
  };

  // Handle Application Status Update (Director / Staff)
  const handleUpdateAppStatus = async (callId: string, appId: string, newStatus: string) => {
    const targetCall = castingCalls.find(c => c.id === callId);
    const targetApp = targetCall?.applications.find(a => a.id === appId);

    if (!targetCall || !targetApp) return;

    const normalizedStatus: any = 
      (newStatus === 'approved' || newStatus === 'Accepted') ? 'approved' :
      (newStatus === 'rejected' || newStatus === 'Declined') ? 'rejected' :
      (newStatus === 'shortlisted' || newStatus === 'Shortlisted') ? 'shortlisted' : 'pending';

    if (normalizedStatus === 'approved') {
      const blCheck = await checkBrandBlacklist(targetCall.brand, currentUser?.tenantId);
      if (blCheck.isBlacklisted) {
        triggerNotification(
          'Placement Blocked',
          `Brand '${blCheck.matchedBrand || targetCall.brand}' is on the Global Blacklist (${blCheck.reason}). Contract placement is barred.`,
          'danger'
        );
        return;
      }
    }

    const updated = castingCalls.map(c => {
      if (c.id === callId) {
        return {
          ...c,
          applications: c.applications.map(a => a.id === appId ? { ...a, status: normalizedStatus } : a)
        };
      }
      return c;
    });

    setCastingCalls(updated);

    // Save status change to Firestore studio-casting-applications
    const docRef = doc(db, 'studio-casting-applications', targetApp.id);
    setDoc(docRef, { status: normalizedStatus }, { merge: true }).catch(err => {
      console.warn('Could not update status in studio-casting-applications:', err);
    });

    if (normalizedStatus === 'approved' || normalizedStatus === 'Accepted') {
      // Auto-create deal in pipeline!
      const numericPay = parseInt(targetCall.pay.replace(/[^0-9]/g, '')) || 0;
      const newDeal: Deal = {
        id: 'deal_cast_' + Date.now(),
        brand: targetCall.brand,
        creator: targetApp.creatorHandle,
        agent: 'Marcus Cole',
        budget: numericPay,
        platform: (targetCall.type as string) === 'UGC' ? 'TikTok' : 'Instagram',
        stage: 'Contracted',
        due: targetCall.deadline,
        notes: `Awarded from Casting Call: "${targetCall.title}". Pitch: ${targetApp.pitchNote || targetApp.pitch || ''}`,
        invoiceGenerated: false
      };
      setDeals(prev => [...prev, newDeal]);

      if (numericPay >= 25000) {
        triggerNotification(
          '💎 High-Value Contract Alert ($25,000+ Threshold)',
          `Major talent placement: ${targetApp.creatorName || targetApp.creatorHandle} placed with ${targetCall.brand} for $${numericPay.toLocaleString()}. Agency 20% margin: $${Math.round(numericPay * 0.2).toLocaleString()}. Director review & legal contract oversight required.`,
          'warning'
        );
        onAddActivityLog(currentUser?.name || 'User', currentRole, `💎 THRESHOLD TRIGGERED: High-Value Casting Placement for ${targetApp.creatorHandle} with ${targetCall.brand} ($${numericPay.toLocaleString()}) - Director alerted.`);
      } else {
        onAddActivityLog(currentUser?.name || 'User', currentRole, `Approved ${targetApp.creatorHandle} for casting call "${targetCall.title}" and created campaign deal`);
        triggerNotification('Talent Placed & Deal Created!', `Approved ${targetApp.creatorName || targetApp.creatorHandle} for ${targetCall.brand}. Deal logged in pipeline!`, 'success');
      }
    } else {
      onAddActivityLog(currentUser?.name || 'User', currentRole, `Updated application status for ${targetApp.creatorHandle} to ${normalizedStatus}`);
      triggerNotification('Status Updated', `Application marked as ${normalizedStatus}. Creator notified.`, normalizedStatus === 'shortlisted' ? 'info' : 'warning');
    }
  };

  // Toggle Casting Call Open/Closed
  const handleToggleCallStatus = (callId: string) => {
    const updated = castingCalls.map(c => c.id === callId ? { ...c, status: (c.status === 'Open' ? 'Closed' : 'Open') as 'Open' | 'Closed' } : c);
    setCastingCalls(updated);
    triggerNotification('Status Toggled', 'Casting call visibility updated.', 'info');
  };

  // Filtered list
  const filteredCalls = castingCalls.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchTerm.toLowerCase()) || c.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'All' || c.type === filterType;
    if (!matchesSearch || !matchesType) return false;

    const expired = isExpiredCall(c);
    if (!isDirector) {
      // Creators never see expired calls (past deadline or status Closed)
      return !expired;
    } else {
      // Directors can filter Active vs Expired
      if (filterStatus === 'Active') return !expired;
      if (filterStatus === 'Expired') return expired;
      return true; // All
    }
  });

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-amber-500/20 rounded-2xl p-6 overflow-hidden shadow-xl" style={{ borderColor: `${primaryBrandColor}30` }}>
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-amber-500/5 rounded-full blur-2xl pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider block font-mono" style={{ color: primaryBrandColor }}>
              TALENT PLACEMENT ENGINE
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5 flex items-center gap-2">
              <Megaphone className="w-7 h-7 text-[#C9A46A]" /> Modeling, Commercial &amp; Runway Casting Calls
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed max-w-3xl">
              {isDirector 
                ? 'Issue casting calls for fashion modeling, TV commercials, lookbooks, runway, and luxury brand ambassador roles. Review talent applications, shortlist candidates, and award deals.'
                : 'Browse verified high-fashion modeling, television commercial, and brand ambassador casting calls, pitch your talent with one tap, and get booked.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {isRealDirector && (
              <button
                onClick={toggleManagerCastingPermission}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border cursor-pointer ${
                  allowManagerCasting
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                    : 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                }`}
                title="Director Master Switch: Toggle whether Agent Managers can post casting calls"
              >
                <div className={`p-1.5 rounded-lg ${allowManagerCasting ? 'bg-emerald-500/20' : 'bg-amber-500/20'}`}>
                  <Lock className="w-4 h-4" />
                </div>
                {allowManagerCasting ? 'Manager Casting: Allowed' : 'Manager Casting: Director Locked'}
              </button>
            )}

            {canCreateCasting ? (
              <button
                onClick={() => setIsCreateModalOpen(true)}
                className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg transition-all shrink-0 cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Issue Casting Call
              </button>
            ) : isAgentMgr ? (
              <span className="bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs px-3 py-2 rounded-xl flex items-center gap-1.5">
                <div className="p-1 rounded-lg bg-amber-500/20">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                </div>
                Casting creation locked by Director
              </span>
            ) : null}
          </div>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search casting calls or brands..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-[#111E33] border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 overflow-x-auto w-full sm:w-auto">
          {isDirector && (
            <div className="flex items-center gap-1 bg-[#111E33] p-1 rounded-xl border border-white/5 mr-2">
              {(['Active', 'Expired', 'All'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setFilterStatus(status)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    filterStatus === status 
                      ? 'bg-[#C9A46A]/20 border border-[#C9A46A]/40 text-[#C9A46A]' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          )}
          {['All', 'Commercial', 'Runway', 'Modeling', 'Brand Ambassador', 'Event'].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                filterType === t 
                  ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300' 
                  : 'bg-[#111E33] border border-white/5 text-slate-400 hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Casting Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCalls.length === 0 ? (
          <div className="col-span-full bg-[#0D1830] border border-white/5 rounded-2xl p-12 text-center text-slate-400 space-y-3">
            <Megaphone className="w-10 h-10 text-slate-500 mx-auto" />
            <p className="font-serif font-bold text-white text-base">No Active Casting Calls Found</p>
            <p className="text-xs text-slate-400">Try adjusting your search terms or filter categories.</p>
          </div>
        ) : (
          filteredCalls.map((call) => {
            const hasApplied = call.applications.some(a => a.creatorHandle.toLowerCase() === creatorHandle.toLowerCase());
            const myApp = call.applications.find(a => a.creatorHandle.toLowerCase() === creatorHandle.toLowerCase());
            const isExpired = isExpiredCall(call);

            return (
              <div 
                key={call.id}
                className="bg-[#0D1830] border border-white/10 hover:border-amber-500/30 rounded-2xl p-5 flex flex-col justify-between space-y-4 transition-all shadow-lg hover:shadow-2xl"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2 border-b border-white/5 pb-3">
                    <div>
                      <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded uppercase">
                        {call.brand}
                      </span>
                      <h3 className="font-serif font-bold text-base text-white mt-1.5 leading-snug">
                        {call.title}
                      </h3>
                    </div>

                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border shrink-0 ${
                      !isExpired ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                    }`}>
                      {!isExpired ? 'Open' : 'Expired'}
                    </span>
                  </div>

                  {/* Metadata Chips */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-[#111E33] p-2 rounded-xl flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase block font-mono">Budget / Pay</span>
                        <span className="font-bold text-white text-xs">{call.pay}</span>
                      </div>
                    </div>

                    <div className="bg-[#111E33] p-2 rounded-xl flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-sky-400 shrink-0" />
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase block font-mono">Location</span>
                        <span className="font-bold text-white text-xs truncate max-w-[110px] block">{call.location}</span>
                      </div>
                    </div>
                  </div>

                  {/* Requirements Brief */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold">Requirements Brief:</span>
                    <p className="text-xs text-slate-300 leading-relaxed bg-[#111E33]/60 p-3 rounded-xl border border-white/5 line-clamp-3">
                      {call.requirements}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5 text-amber-400" /> Deadline: {call.deadline}</span>
                    <span className="flex items-center gap-1"><User className="w-3.5 h-3.5 text-indigo-400" /> {call.applications.length} Applicants</span>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="border-t border-white/5 pt-3 flex items-center justify-between gap-2">
                  {isDirector ? (
                    <>
                      <button
                        onClick={() => setSelectedCallId(selectedCallId === call.id ? null : call.id)}
                        className="w-full bg-[#111E33] hover:bg-white/10 text-white font-semibold text-xs py-2 px-3 rounded-xl border border-white/10 transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <User className="w-3.5 h-3.5 text-amber-400" /> 
                        {selectedCallId === call.id ? 'Hide Applications' : `View Applications (${call.applications.length})`}
                      </button>

                      <button
                        onClick={() => handleToggleCallStatus(call.id)}
                        className="text-[10px] text-slate-400 hover:text-white px-2 py-1 rounded hover:bg-white/5 transition-all cursor-pointer whitespace-nowrap"
                      >
                        {call.status === 'Open' ? 'Close Call' : 'Reopen Call'}
                      </button>
                    </>
                  ) : (
                    <>
                      {(() => {
                        const isClosed = call.status === 'Closed';
                        const isPastDeadline = isCallDeadlinePassed(call.deadline);
                        const isDisabled = hasApplied || isClosed || isPastDeadline;

                        return (
                          <div className="w-full space-y-1.5">
                            <button
                              onClick={() => {
                                if (isDisabled) return;
                                setApplyCall(call);
                                setIsApplyModalOpen(true);
                              }}
                              disabled={isDisabled}
                              className={`w-full font-bold text-xs py-2.5 px-4 rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5 ${
                                isDisabled
                                  ? 'bg-[#111E33] text-slate-400 border border-white/10 cursor-not-allowed opacity-80'
                                  : 'bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] cursor-pointer'
                              }`}
                            >
                              {hasApplied ? (
                                <>
                                  <CheckCircle className="w-3.5 h-3.5 text-amber-400" /> Applied ({myApp?.status || 'Pending'})
                                </>
                              ) : (
                                <>
                                  <Send className="w-3.5 h-3.5" /> Apply
                                </>
                              )}
                            </button>

                            {hasApplied && (
                              <p className="text-[10px] text-amber-400 text-center font-medium">
                                You have already applied to this casting call ({myApp?.status || 'Pending'}).
                              </p>
                            )}
                            {!hasApplied && isClosed && (
                              <p className="text-[10px] text-rose-400 text-center font-medium">
                                This casting call is closed to new applications.
                              </p>
                            )}
                            {!hasApplied && !isClosed && isPastDeadline && (
                              <p className="text-[10px] text-rose-400 text-center font-medium">
                                The deadline for this casting call has passed ({call.deadline}).
                              </p>
                            )}
                          </div>
                        );
                      })()}
                    </>
                  )}
                </div>

                {/* Director Drawer: Expanded Applications List */}
                {isDirector && selectedCallId === call.id && (
                  <div className="bg-[#111E33] border border-amber-500/20 rounded-xl p-4 mt-3 space-y-3 animate-fadeIn">
                    <h4 className="font-serif font-bold text-xs text-amber-300 flex items-center justify-between border-b border-white/5 pb-2">
                      <span>Applications for {call.title}</span>
                      <span className="font-mono text-[10px] text-slate-400">{call.applications.length} Total</span>
                    </h4>

                    {call.applications.length === 0 ? (
                      <p className="text-xs text-slate-400 text-center py-4 italic">No talent applications submitted yet.</p>
                    ) : (
                      <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                        {call.applications.map((app) => (
                          <div key={app.id} className="bg-[#0D1830] border border-white/5 p-3 rounded-xl space-y-2">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <img src={app.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'} alt={app.creatorName} className="w-7 h-7 rounded-full object-cover border border-amber-500/30" />
                                <div>
                                  <p className="font-bold text-white text-xs">{app.creatorName}</p>
                                  <p className="text-[10px] text-amber-400 font-mono">{app.creatorHandle}</p>
                                </div>
                              </div>

                              <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${
                                (app.status === 'Accepted' || app.status === 'approved') ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                                (app.status === 'Shortlisted' || app.status === 'shortlisted') ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                                (app.status === 'Declined' || app.status === 'rejected') ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                                'bg-slate-700/40 text-slate-300'
                              }`}>
                                {app.status}
                              </span>
                            </div>

                            <p className="text-xs text-slate-300 bg-[#111E33] p-2 rounded-lg italic">
                              "{app.pitchNote || app.pitch || ''}"
                            </p>

                            {app.link && getSafeUrl(app.link) !== '#' && (
                              <a
                                href={getSafeUrl(app.link)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[11px] text-sky-400 hover:text-sky-300 underline flex items-center gap-1 mt-1"
                              >
                                <LinkIcon className="w-3 h-3" /> View Portfolio / Sample Content
                              </a>
                            )}

                            <div className="flex items-center justify-end gap-1.5 pt-1">
                              <button
                                onClick={() => handleUpdateAppStatus(call.id, app.id, 'shortlisted')}
                                className="bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-md border border-amber-500/30 transition-all cursor-pointer flex items-center gap-1"
                              >
                                <Star className="w-3 h-3" /> Shortlist
                              </button>

                              <button
                                onClick={() => handleUpdateAppStatus(call.id, app.id, 'approved')}
                                className="bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 text-[10px] font-bold px-2.5 py-1 rounded-md border border-emerald-500/30 transition-all cursor-pointer flex items-center gap-1"
                              >
                                <Check className="w-3 h-3" /> Approve &amp; Award
                              </button>

                              <button
                                onClick={() => handleUpdateAppStatus(call.id, app.id, 'rejected')}
                                className="bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-[10px] font-bold px-2.5 py-1 rounded-md border border-rose-500/30 transition-all cursor-pointer"
                              >
                                Reject
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Modal: Create Casting Call (Director) */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <h3 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-amber-400" /> Issue New Casting Call
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCall} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Campaign Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Summer Beach Glow UGC Reel"
                  value={newCall.title}
                  onChange={e => setNewCall({ ...newCall, title: e.target.value })}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Brand Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. GlowLab"
                    value={newCall.brand}
                    onChange={e => setNewCall({ ...newCall, brand: e.target.value })}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Casting Category</label>
                  <select
                    value={newCall.type}
                    onChange={e => setNewCall({ ...newCall, type: e.target.value as any })}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                  >
                    <option value="Commercial">Commercial (TV / Digital)</option>
                    <option value="Runway">Runway &amp; High Fashion</option>
                    <option value="Modeling">Modeling / Lookbook</option>
                    <option value="Brand Ambassador">Brand Ambassador</option>
                    <option value="Event">On-site Event / Host</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Pay Rate / Compensation</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. $2,500 + Product Kit"
                    value={newCall.pay}
                    onChange={e => setNewCall({ ...newCall, pay: e.target.value })}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Location / Shoot Type</label>
                  <input
                    type="text"
                    placeholder="e.g. Remote or Los Angeles, CA"
                    value={newCall.location}
                    onChange={e => setNewCall({ ...newCall, location: e.target.value })}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Requirements Brief &amp; Deliverables</label>
                <textarea
                  rows={3}
                  placeholder="Outline video length, resolution, key talking points, FTC requirements..."
                  value={newCall.requirements}
                  onChange={e => setNewCall({ ...newCall, requirements: e.target.value })}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                ></textarea>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Application Deadline</label>
                <input
                  type="date"
                  value={newCall.deadline}
                  onChange={e => setNewCall({ ...newCall, deadline: e.target.value })}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 bg-[#111E33] text-slate-300 rounded-xl font-semibold hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold rounded-xl shadow-lg cursor-pointer"
                >
                  Publish Casting Call
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Apply to Casting Call (Creator) */}
      {isApplyModalOpen && applyCall && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] text-amber-400 font-mono font-bold uppercase">{applyCall.brand}</span>
                <h3 className="font-serif font-bold text-lg text-white mt-0.5">
                  Apply: {applyCall.title}
                </h3>
              </div>
              <button onClick={() => setIsApplyModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-[#111E33] p-3 rounded-xl space-y-1 text-xs text-slate-300">
              <p><strong className="text-white">Pay:</strong> {applyCall.pay}</p>
              <p><strong className="text-white">Location:</strong> {applyCall.location}</p>
              <p><strong className="text-white">Deadline:</strong> {applyCall.deadline}</p>
            </div>

            <form onSubmit={handleApply} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Talent Pitch &amp; Availability Note</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Explain why you're a great fit for this campaign, highlight recent relevant metrics, and confirm shoot availability..."
                  value={pitchNote}
                  onChange={e => setPitchNote(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500/50"
                ></textarea>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Portfolio or Sample Link (Optional)</label>
                <input
                  type="text"
                  placeholder="https://tiktok.com/@yourhandle or portfolio URL..."
                  value={portfolioLink}
                  onChange={e => setPortfolioLink(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-4 py-2 bg-[#111E33] text-slate-300 rounded-xl font-semibold hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold rounded-xl shadow-lg cursor-pointer flex items-center gap-2"
                >
                  <Send className="w-4 h-4" /> Submit Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
