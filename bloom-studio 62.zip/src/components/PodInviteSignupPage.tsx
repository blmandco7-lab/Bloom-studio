import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, CheckCircle2, Sparkles, ArrowLeft, Building2, Key, Lock, Mail, User, AtSign, Briefcase, LogIn, FileText, Loader2 } from 'lucide-react';
import { signInWithGoogle, submitPodInviteApplication, getDoc, doc, db } from '../lib/firebase';
import TalentOnboardingModule from './TalentOnboardingModule';
import { safeStorage } from '../utils/safeStorage';

interface PodInviteSignupPageProps {
  inviteCode: string;
  onExitInvite: () => void;
  agencyName?: string;
}

export default function PodInviteSignupPage({
  inviteCode,
  onExitInvite,
  agencyName = 'Bloom & Co. Studio'
}: PodInviteSignupPageProps) {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSigningInGoogle, setIsSigningInGoogle] = useState(false);
  const [googleError, setGoogleError] = useState('');
  const [activeMode, setActiveMode] = useState<'profileForm' | 'express'>('profileForm');
  const [remoteInviteCodes, setRemoteInviteCodes] = useState<any[]>([]);

  // Form State
  const [fullName, setFullName] = useState('');
  const [handle, setHandle] = useState('');
  const [email, setEmail] = useState('');
  const [bioOrSpecialty, setBioOrSpecialty] = useState('');
  const [submissionReceipt, setSubmissionReceipt] = useState('');

  const cleanCode = (inviteCode || '').trim().toUpperCase();

  useEffect(() => {
    async function fetchCode() {
      if (!cleanCode) return;
      try {
        const codeSnap = await getDoc(doc(db, "studio-invite-codes", cleanCode));
        if (codeSnap.exists()) {
          setRemoteInviteCodes([codeSnap.data()]);
        }
      } catch (e) {
        console.warn("Error fetching invite code:", e);
      }
    }
    fetchCode();
  }, [cleanCode]);

  // Lookup code from Firestore, then localStorage, with intelligent fallback heuristics
  const codeDetails = useMemo(() => {
    // 1. Check live Firestore codes
    if (remoteInviteCodes.length > 0) {
      const foundRemote = remoteInviteCodes.find(
        (c: any) => c.code?.toUpperCase() === cleanCode && c.status === 'Active'
      );
      if (foundRemote) {
        return {
          code: foundRemote.code,
          role: foundRemote.role || 'creator',
          pod: foundRemote.pod || 'Main Agency',
          purpose: foundRemote.purpose || 'Official Pod Registration Token'
        };
      }
    }

    // 2. Check safeStorage access codes
    try {
      const savedCodes = JSON.parse(safeStorage.getItem('wl_access_codes') || '[]');
      const matched = savedCodes.find((c: any) => c.code?.toUpperCase() === cleanCode && c.status === 'Active');
      if (matched) {
        return {
          code: matched.code,
          role: matched.role || 'creator',
          pod: matched.pod || 'Main Agency',
          purpose: matched.purpose || 'Official Pod Registration Token'
        };
      }
    } catch (e) {
      console.error('Error loading invite codes:', e);
    }

    // 3. Default heuristics if code wasn't found in lists
    let inferredRole = 'creator';
    let inferredPod = 'Bloom & Co';
    if (cleanCode.includes('SPORTS') || cleanCode.includes('VIRAL')) inferredPod = 'Bloom & Co';
    else if (cleanCode.includes('SUBAGENCY') || cleanCode.includes('OWNER')) inferredRole = 'subagency';
    else if (cleanCode.includes('MGR')) inferredRole = 'agentmgr';
    else if (cleanCode.includes('AGENT')) inferredRole = 'agent';

    return {
      code: cleanCode,
      role: inferredRole,
      pod: inferredPod,
      purpose: `Pod Registration Code (${inferredPod})`
    };
  }, [inviteCode, remoteInviteCodes]);

  const roleLabels: Record<string, string> = {
    creator: 'Creator Partner',
    subagency: 'Sub-Agency Owner',
    agentmgr: 'Agent Manager',
    agent: 'Agency Agent',
    brand: 'Brand Partner',
    coordinator: 'Campaign Coordinator',
    director: 'Agency Director'
  };

  const handleDirectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email) return;

    setIsSubmitting(true);

    const finalHandle = handle.trim().startsWith('@') 
      ? handle.trim() 
      : handle.trim() 
        ? `@${handle.trim()}` 
        : `@${fullName.toLowerCase().replace(/[^a-z0-9]/g, '')}`;

    try {
      const result = await submitPodInviteApplication({
        name: fullName.trim(),
        email: email.trim().toLowerCase(),
        handle: finalHandle,
        requestedRole: codeDetails.role,
        pod: codeDetails.pod,
        invitedByCode: codeDetails.code,
        bio: bioOrSpecialty.trim(),
        source: 'direct_form'
      });

      setSubmissionReceipt(result.id);

      // Also record pending invite in safeStorage for device local state
      safeStorage.setItem('wl_pending_invite_code', codeDetails.code);
      safeStorage.setItem('wl_pending_invite_id', result.id);
    } catch (err) {
      console.error('Error submitting application:', err);
    } finally {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }
  };

  const handleGoogleSignup = async () => {
    setGoogleError('');
    setIsSigningInGoogle(true);
    try {
      safeStorage.setItem('wl_pending_invite_code', codeDetails.code);
      const cred = await signInWithGoogle();
      const googleUser = cred;
      
      const gName = googleUser?.displayName || fullName || 'Google User';
      const gEmail = googleUser?.email || email || '';
      const gHandle = handle.trim()
        ? (handle.startsWith('@') ? handle : `@${handle}`)
        : `@${gName.toLowerCase().replace(/[^a-z0-9]/g, '')}`;

      const result = await submitPodInviteApplication({
        uid: googleUser?.uid,
        name: gName,
        email: gEmail,
        handle: gHandle,
        requestedRole: codeDetails.role,
        pod: codeDetails.pod,
        invitedByCode: codeDetails.code,
        bio: bioOrSpecialty.trim(),
        source: 'google_auth'
      });

      setSubmissionReceipt(result.id);
      setIsSubmitted(true);
    } catch (err: any) {
      if (err?.code === 'auth/popup-closed-by-user' || err?.message?.includes('popup-closed-by-user') || err?.code === 'auth/cancelled-popup-request') {
        console.info('[Auth] Google sign-up window was closed by user.');
        setGoogleError('Google sign-up window was closed. Please try again or fill in the details below.');
        return;
      }
      console.error('Google sign-up error:', err);
      setGoogleError(err.message || 'Google sign-in failed. Please try entering your details below.');
    } finally {
      setIsSigningInGoogle(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-[#060B14] text-white font-sans flex flex-col items-center justify-center p-6 select-none">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-lg w-full bg-[#0D1628] border border-[#C9A46A]/40 rounded-2xl p-8 shadow-2xl text-center space-y-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-48 h-48 bg-[#C9A46A]/10 rounded-full blur-3xl -z-10 pointer-events-none" />
          
          <div className="w-16 h-16 rounded-full bg-[#C9A46A]/20 border border-[#C9A46A]/50 text-[#C9A46A] flex items-center justify-center mx-auto shadow-lg">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 bg-[#16243F] border border-[#C9A46A]/30 rounded-full text-[11px] font-mono text-[#C9A46A] uppercase tracking-wider">
              Application Dispatched &amp; Queued
            </span>
            <h2 className="text-2xl font-serif font-bold text-white pt-1">
              Application Submitted to Bloom &amp; Co.
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Thank you for applying to Bloom &amp; Co. Talent Management. Your application for <span className="text-[#C9A46A] font-semibold">{fullName || email}</span> has been securely written to our shared database and queued for staff review.
            </p>
          </div>

          <div className="bg-[#111E33]/60 border border-white/10 rounded-xl p-4 space-y-2.5 text-xs text-left">
            <div className="flex justify-between border-b border-white/10 pb-2">
              <span className="text-slate-400">Applicant:</span>
              <span className="text-white font-semibold">{fullName || email}</span>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-2">
              <span className="text-slate-400">Target Pod &amp; Role:</span>
              <span className="text-slate-300 font-medium">{codeDetails.pod} — {roleLabels[codeDetails.role] || codeDetails.role}</span>
            </div>
            <div className="flex justify-between border-b border-white/10 pb-2">
              <span className="text-slate-400">Handle / Stage Name:</span>
              <span className="text-slate-300 font-mono">{handle || 'Not specified'}</span>
            </div>
            {submissionReceipt && (
              <div className="flex justify-between border-b border-white/10 pb-2">
                <span className="text-slate-400">Application Reference:</span>
                <span className="text-[#C9A46A] font-mono text-[11px]">{submissionReceipt}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-slate-400">Database Status:</span>
              <span className="text-amber-400 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                Pending Staff Approval
              </span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed bg-[#111E33]/30 p-3 rounded-lg border border-white/5">
            Our talent management and pod operations team reviews applications live in the Operation Board. Once approved by agency leadership, your role permissions will unlock automatically.
          </p>

          <button
            type="button"
            onClick={onExitInvite}
            className="w-full py-3.5 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer transition-all shadow-lg font-sans flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" /> Return to Studio Login
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-[#060B14] text-white font-sans flex flex-col items-center justify-center p-6 relative overflow-y-auto">
      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#C9A46A]/10 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* Top Bar with Exit option */}
      <div className="w-full max-w-xl flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#111E33] border border-[#C9A46A]/30 flex items-center justify-center text-[#C9A46A]">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-serif font-bold tracking-wider text-white uppercase block">
              {agencyName}
            </span>
            <span className="text-[10px] text-[#C9A46A] font-mono tracking-wider">
              CREATOR APPLICATION PORTAL
            </span>
          </div>
        </div>

        <button
          onClick={onExitInvite}
          className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-white/10 hover:border-white/30 transition-all flex items-center gap-1.5 cursor-pointer bg-[#0D1628]"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Exit
        </button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-xl w-full bg-[#0D1628] border border-white/10 rounded-2xl p-8 shadow-2xl space-y-6"
      >
        {/* Header */}
        <div className="border-b border-white/10 pb-5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="px-3 py-1 bg-[#16243F] border border-[#C9A46A]/40 rounded-full text-xs font-bold text-[#C9A46A] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> BLOOM &amp; CO. TALENT MANAGEMENT
            </span>
            <span className="px-2.5 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full text-[10px] font-mono uppercase">
              Token: {codeDetails.code}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
            Apply to Bloom &amp; Co.
          </h1>
          <p className="text-xs text-slate-300 leading-relaxed">
            Joining pod <strong className="text-white">{codeDetails.pod}</strong> as <strong className="text-[#C9A46A]">{roleLabels[codeDetails.role] || codeDetails.role}</strong>. Submit your profile below for immediate review by agency leadership.
          </p>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="flex bg-[#111E33] p-1 rounded-xl border border-white/5 gap-1">
          <button
            type="button"
            onClick={() => setActiveMode('profileForm')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeMode === 'profileForm'
                ? 'bg-[#3B82F6] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Complete Talent Profile
          </button>
          <button
            type="button"
            onClick={() => setActiveMode('express')}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeMode === 'express'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-md font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Express Pod Signup
          </button>
        </div>

        {activeMode === 'profileForm' ? (
          <div className="flex justify-center">
            <TalentOnboardingModule
              className="w-full max-w-full !p-0 !bg-transparent !border-0 !shadow-none"
              onComplete={async (talentData) => {
                setIsSubmitting(true);
                try {
                  const result = await submitPodInviteApplication({
                    name: talentData.realName,
                    email: (talentData as any).email || `${talentData.tikTokHandle.replace('@', '').toLowerCase()}@talent.bloom.co`,
                    handle: talentData.tikTokHandle,
                    requestedRole: 'creator',
                    pod: codeDetails.pod,
                    invitedByCode: codeDetails.code,
                    bio: talentData.niche,
                    w9Status: talentData.w9FileName ? 'Submitted' : 'Pending',
                    w9FileName: talentData.w9FileName,
                    source: 'talent_onboarding'
                  });

                  setSubmissionReceipt(result.id);
                  setFullName(talentData.realName);
                  setHandle(talentData.tikTokHandle);
                  setEmail((talentData as any).email || '');
                } catch (err) {
                  console.error('Error submitting onboarding application:', err);
                } finally {
                  setIsSubmitting(false);
                  setIsSubmitted(true);
                }
              }}
            />
          </div>
        ) : (
          <>
            {/* Google Sign Up Option */}
            <div className="space-y-3">
              <button
                type="button"
                onClick={handleGoogleSignup}
                disabled={isSigningInGoogle || isSubmitting}
                className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold py-3.5 px-4 rounded-xl text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2.5 shadow-md cursor-pointer disabled:opacity-60"
              >
                {isSigningInGoogle ? (
                  <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                ) : (
                  <LogIn className="w-4 h-4 text-indigo-600" />
                )}
                {isSigningInGoogle ? 'Connecting Google Identity...' : 'Sign Up with Google OAuth'}
              </button>
              {googleError && (
                <p className="text-[11px] text-rose-400 text-center font-sans">{googleError}</p>
              )}
              <div className="flex items-center gap-3 py-2">
                <div className="flex-1 h-px bg-white/10" />
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">Or Apply Directly</span>
                <div className="flex-1 h-px bg-white/10" />
              </div>
            </div>

            {/* Direct Application Form */}
            <form onSubmit={handleDirectSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-[#C9A46A]" /> Full Name / Talent Name *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Serena Williams"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-sm text-white outline-none focus:border-[#C9A46A] transition-colors"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#C9A46A]" /> Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. serena@talent.com"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-sm text-white outline-none focus:border-[#C9A46A] transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <AtSign className="w-3.5 h-3.5 text-[#C9A46A]" /> Stage Handle / Username
                  </label>
                  <input
                    type="text"
                    value={handle}
                    onChange={(e) => setHandle(e.target.value)}
                    placeholder="e.g. @serenawilliams"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-sm text-white font-mono outline-none focus:border-[#C9A46A] transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5 text-[#C9A46A]" /> Specialty / Bio
                </label>
                <input
                  type="text"
                  value={bioOrSpecialty}
                  onChange={(e) => setBioOrSpecialty(e.target.value)}
                  placeholder="e.g. Pro Athlete & Content Creator — 15M followers across platforms"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-sm text-white outline-none focus:border-[#C9A46A] transition-colors"
                />
              </div>

              <div className="p-3 bg-[#111E33]/80 border border-white/10 rounded-xl text-xs text-slate-300 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  Your application will be securely submitted to Bloom &amp; Co. talent management database for staff review.
                </span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer transition-all shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Submitting to Agency Database...</span>
                  </>
                ) : (
                  <>
                    <span>Submit Application</span>
                    <Sparkles className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </motion.div>
    </div>
  );
}
