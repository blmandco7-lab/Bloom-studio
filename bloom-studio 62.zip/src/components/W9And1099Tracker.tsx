import React, { useState, useEffect } from 'react';
import { 
  Landmark, FileText, Mail, Plus, CheckCircle, RefreshCw, AlertTriangle, 
  ShieldCheck, Download, DollarSign, Sliders, Calendar, Percent, Calculator, Info, Trash2,
  Upload, FileCheck, PenTool, Shield, Eye, CheckCircle2, FileSignature, X, UserCheck,
  Send, Printer, ExternalLink, CheckSquare, Square, Sparkles, BookOpen, Link2
} from 'lucide-react';
import { collection, onSnapshot, doc, setDoc, query, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { computeRealSha256, persistSignatureRecord } from '../lib/cryptoSignatures';
import { Creator } from '../types';
import { formatCsvRow, sanitizeCsvCell } from '../utils/security';
import { generateOfficialW9Pdf, generateOfficial1099NecPdf, W9FormData } from '../lib/w9PdfGenerator';
import TaxSeasonGuide from './TaxSeasonGuide';
import AccountingIntegrations from './AccountingIntegrations';
import DeleteConfirmationModal, { DeleteConfirmConfig } from './DeleteConfirmationModal';
import MultiFilePdfViewerModal, { ViewableFile } from './DocumentViewerModal';

interface TaxComplianceItem {
  id: string;
  creator: string;
  realName: string;
  taxIdStatus: 'Verified' | 'Pending Review' | 'Missing';
  w9Status: 'Submitted' | 'Missing' | 'Expired';
  earnings1099: number;
  status1099: 'Filed & Sent' | 'Ready to File' | 'Not Applicable';
  lastNudged?: string;
  fileName?: string;
  fileSize?: string;
  fileData?: string;
  uploadedAt?: string;
}

interface FormTemplate {
  id: string;
  name: string;
  category: 'tax' | 'agreement' | 'mcn';
  description: string;
  fileName: string;
  fileSize: string;
  updatedAt: string;
  isDefault?: boolean;
  fileDataUrl?: string;
}

interface ReturnedDocument {
  id: string;
  templateId: string;
  templateName: string;
  creatorHandle: string;
  creatorName: string;
  taxClassification: string;
  taxId: string;
  signatureName: string;
  signedAt: string;
  status: 'Signed & Returned' | 'Agency Verified' | 'Pending Review' | 'Sent — Pending Creator Completion';
  auditHash: string;
  completedPdfUrl?: string;
  completedPdfName?: string;
}

interface W9And1099TrackerProps {
  creators: Creator[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentUser?: any;
  currentRole?: string;
  onOpenTermsModal?: () => void;
}

export default function W9And1099Tracker({ creators, onAddActivityLog, triggerNotification, currentUser, currentRole, onOpenTermsModal }: W9And1099TrackerProps) {
  const normRole = (currentRole || '').toLowerCase();
  const isAgentMgr = normRole === 'agentmgr' || normRole.includes('manager');
  const isAgent = normRole === 'agent' || normRole.includes('agent');
  const isCoordinator = normRole === 'coordinator' || normRole.includes('coord');
  const isWhiteLabel = normRole.includes('white') || normRole.includes('sub') || normRole.includes('affiliate');
  const isRestrictedRole = isAgentMgr || isAgent || isCoordinator || isWhiteLabel;
  const mgrName = currentUser?.name || (isAgent ? 'Assigned Agent' : 'Agency Lead');
  const myCreators = (creators || []).filter(c => 
    (!isRestrictedRole || c.assignedAgent?.toLowerCase() === mgrName.toLowerCase() || (c as any).assignedCoordinator?.toLowerCase() === mgrName.toLowerCase()) &&
    c.name.toLowerCase() !== mgrName.toLowerCase() &&
    c.handle.toLowerCase() !== (currentUser?.handle || '').toLowerCase()
  );
  const myHandles = Array.from(new Set(myCreators.map(c => c.handle.toLowerCase())));

  const [activeTab, setActiveTab] = useState<'compliance' | 'tax-season-guide' | 'accounting-integrations' | 'templates-and-signing' | 'estimated-taxes'>('compliance');
  const [docViewerOpen, setDocViewerOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [docViewerFiles, setDocViewerFiles] = useState<ViewableFile[]>([]);
  const [docViewerTitle, setDocViewerTitle] = useState('Document Preview');

  const [templates, setTemplates] = useState<FormTemplate[]>(() => {
    const saved = localStorage.getItem('bloom_form_templates');
    const defaultTemplates: FormTemplate[] = [
      {
        id: 'tmpl_w9_official',
        name: 'IRS Form W-9 (Rev. March 2024)',
        category: 'tax',
        description: 'Official IRS Request for Taxpayer Identification Number and Certification. Required for U.S. creator tax compliance and 1099-NEC filing.',
        fileName: 'fw9_official_2026.pdf',
        fileSize: '142 KB',
        updatedAt: '2026-01-15',
        isDefault: true
      },
      {
        id: 'tmpl_rep',
        name: 'Bloom Studio Talent Exclusive Representation Agreement',
        category: 'agreement',
        description: 'Standard talent management contract governing commission splits, FTC rules, and escrow terms.',
        fileName: 'bloom_rep_agreement_v2.4.pdf',
        fileSize: '310 KB',
        updatedAt: '2026-02-01',
        isDefault: true
      },
      {
        id: 'tmpl_mcn',
        name: 'Sub-Agency MCN Partner Agreement',
        category: 'mcn',
        description: 'Governs affiliate sub-agency pods with separate Stripe Connect escrow ledgers and shared compliance oversight.',
        fileName: 'sub_agency_mcn_agreement_v1.2.pdf',
        fileSize: '275 KB',
        updatedAt: '2026-02-10',
        isDefault: true
      }
    ];

    if (saved) {
      try {
        const parsed: FormTemplate[] = JSON.parse(saved);
        const hasW9 = parsed.some(t => t.id === 'tmpl_w9_official' || t.name.includes('W-9'));
        return hasW9 ? parsed : [defaultTemplates[0], ...parsed];
      } catch(e) {}
    }
    return defaultTemplates;
  });

  const [returnedDocuments, setReturnedDocuments] = useState<ReturnedDocument[]>([]);

  useEffect(() => {
    localStorage.setItem('bloom_form_templates', JSON.stringify(templates));
  }, [templates]);

  // Sensitive documents are handled via Firestore only.
  // No localStorage persistence for PII data.

  // Send Form to Creator Roster modal state
  const [sendModalOpen, setSendModalOpen] = useState(false);
  const [selectedTemplateForSend, setSelectedTemplateForSend] = useState<FormTemplate | null>(null);
  const [selectedCreatorHandlesForSend, setSelectedCreatorHandlesForSend] = useState<string[]>([]);
  const [sendCustomNote, setSendCustomNote] = useState('Please review, complete, and sign this official document by Friday to ensure timely monthly payout processing.');

  const [signingModalOpen, setSigningModalOpen] = useState(false);
  const [selectedTemplateForSign, setSelectedTemplateForSign] = useState<FormTemplate | null>(null);
  const [signForm, setSignForm] = useState({
    legalName: currentUser?.name || creators?.[0]?.name || '',
    businessName: '',
    taxClassification: 'Individual/Sole Proprietor',
    otherClassificationText: '',
    exemptPayeeCode: '',
    exemptionFatcaCode: '',
    taxIdType: 'SSN' as 'SSN' | 'EIN',
    taxId: '',
    address: '',
    cityStateZip: 'Los Angeles, CA 90071',
    requesterNameAddress: 'Bloom Studio Agency Talent & Escrow Operations, 100 Grand Ave, Suite 400, Los Angeles, CA 90071',
    accountNumbers: currentUser?.handle || '@creator_handle',
    signatureText: currentUser?.name || creators?.[0]?.name || '',
    signatureDate: new Date().toISOString().split('T')[0],
    signatureMode: 'type' as 'type' | 'draw',
    perjuryCert: false,
    esignConsent: false,
    completedPdfUrl: '',
    completedPdfName: ''
  });

  const openOfficialW9FillablePdf = (customPdfUrl?: string, customFileName?: string) => {
    if (customPdfUrl) {
      const a = document.createElement('a');
      a.href = customPdfUrl;
      a.download = customFileName || 'Completed_IRS_Form_W9.pdf';
      a.click();
      triggerNotification('Completed W-9 PDF Downloaded', 'Downloaded creator-submitted official Form W-9 PDF sheet.', 'success');
      return;
    }

    generateOfficialW9Pdf({
      legalName: currentUser?.name || creators?.[0]?.name || 'Creator Legal Name',
      address: '100 Grand Ave, Suite 400',
      cityStateZip: 'Los Angeles, CA 90071',
      tinType: 'SSN',
      tinNumber: 'XXX-XX-4819',
      signatureName: currentUser?.name || 'Creator Authorized Signature',
      accountNumbers: currentUser?.handle || '@creator'
    }, { download: true });
    triggerNotification('Official IRS Form W-9 Generated', 'Generated and downloaded official IRS Form W-9 (Rev. March 2024) PDF.', 'success');
  };

  const generateW9PrintablePdf = (data: {
    legalName?: string;
    businessName?: string;
    taxClassification?: string;
    taxIdType?: string;
    taxId?: string;
    address?: string;
    cityStateZip?: string;
    accountNumbers?: string;
    signatureName?: string;
    signedAt?: string;
    auditHash?: string;
  }) => {
    const result = generateOfficialW9Pdf({
      legalName: data.legalName || currentUser?.name || 'Creator Legal Name',
      businessName: data.businessName || '',
      taxClassification: data.taxClassification || 'Individual/sole proprietor or single-member LLC',
      tinType: (data.taxIdType as any) || 'SSN',
      tinNumber: data.taxId || 'XXX-XX-XXXX',
      address: data.address || '100 Grand Ave, Suite 400',
      cityStateZip: data.cityStateZip || 'Los Angeles, CA 90071',
      accountNumbers: data.accountNumbers || currentUser?.handle || '@creator',
      signatureName: data.signatureName || data.legalName || currentUser?.name || 'Authorized Signatory',
      dateSigned: data.signedAt || new Date().toISOString().split('T')[0],
      auditHash: data.auditHash
    }, { download: true });

    triggerNotification('Official W-9 PDF Exported', `Generated and downloaded real IRS Form W-9 PDF for ${data.legalName || 'Creator'}.`, 'success');
    return result;
  };

  // Dedicated Generate 1099-NEC Modal State
  const [generate1099ModalOpen, setGenerate1099ModalOpen] = useState(false);
  const [generate1099Data, setGenerate1099Data] = useState({
    creatorHandle: creators?.[0]?.handle || '@creator',
    recipientName: creators?.[0]?.name || 'Creator Legal Name',
    recipientTin: 'XX-XXX4819',
    recipientAddress: '100 Grand Ave, Suite 400',
    recipientCityStateZip: 'Los Angeles, CA 90071',
    payerName: 'Bloom Studio Agency Talent Escrow Inc.',
    payerAddress: '100 Grand Ave, Suite 400',
    payerCityStateZip: 'Los Angeles, CA 90071',
    payerTin: '95-4819204',
    nonemployeeCompensation: 12500,
    taxYear: '2026',
    federalTaxWithheld: 0,
    directSales5000: false,
    notifyCreator: true
  });

  // Dedicated Upload & Email Tax Form to Creator Modal State
  const [uploadExistingTaxDocModalOpen, setUploadExistingTaxDocModalOpen] = useState(false);
  const [uploadExistingTaxDocData, setUploadExistingTaxDocData] = useState({
    creatorHandle: creators?.[0]?.handle || '@creator',
    creatorName: creators?.[0]?.name || 'Creator Legal Name',
    creatorEmail: creators?.[0]?.email || 'creator@bloomtalent.com',
    documentType: '1099-NEC' as '1099-NEC' | 'W-9' | '1040-ES' | 'Custom',
    taxYear: '2026',
    amount: 12500,
    fileName: '',
    fileData: '',
    fileSize: '',
    emailSubject: 'Official 2026 Form 1099-NEC - Bloom Studio Agency Talent Escrow',
    emailBody: '',
    sendEmailCopy: true,
    publishToPortal: true,
    markAsFiled: true,
    notes: 'Uploaded and emailed via agency compliance desk'
  });

  const openGenerate1099Modal = (targetItem?: TaxComplianceItem) => {
    const creator = targetItem 
      ? creators.find(c => c.handle.toLowerCase() === targetItem.creator.toLowerCase())
      : (creators?.[0] || { handle: '@creator', name: 'Creator Legal Name' });
    
    setGenerate1099Data({
      creatorHandle: targetItem?.creator || creator?.handle || '@creator',
      recipientName: targetItem?.realName || creator?.name || 'Creator Legal Name',
      recipientTin: 'XX-XXX4819',
      recipientAddress: '100 Grand Ave, Suite 400',
      recipientCityStateZip: 'Los Angeles, CA 90071',
      payerName: 'Bloom Studio Agency Talent Escrow Inc.',
      payerAddress: '100 Grand Ave, Suite 400',
      payerCityStateZip: 'Los Angeles, CA 90071',
      payerTin: '95-4819204',
      nonemployeeCompensation: targetItem?.earnings1099 || Number((creator as any)?.earnings || 12500),
      taxYear: '2026',
      federalTaxWithheld: 0,
      directSales5000: false,
      notifyCreator: true
    });
    setGenerate1099ModalOpen(true);
  };

  const handleExecuteGenerate1099 = async (e: React.FormEvent) => {
    e.preventDefault();
    const { creatorHandle, recipientName, recipientTin, recipientAddress, recipientCityStateZip, payerName, payerAddress, payerCityStateZip, payerTin, nonemployeeCompensation, taxYear } = generate1099Data;

    try {
      await generateOfficial1099NecPdf({
        payerName,
        payerAddress,
        payerCityStateZip,
        payerTin,
        recipientTin,
        recipientName,
        recipientAddress,
        recipientCityStateZip,
        nonemployeeCompensation: Number(nonemployeeCompensation) || 0,
        taxYear,
        accountNumber: creatorHandle
      }, { download: true });

      setTaxItems(prev => prev.map(t => {
        if (t.creator.toLowerCase() === creatorHandle.toLowerCase()) {
          return {
            ...t,
            status1099: 'Filed & Sent',
            earnings1099: Number(nonemployeeCompensation) || t.earnings1099,
            realName: recipientName || t.realName
          };
        }
        return t;
      }));

      triggerNotification(
        '1099-NEC Form Generated & Downloaded',
        `Official IRS Form 1099-NEC PDF created and downloaded for ${recipientName} (${creatorHandle}) with $${Number(nonemployeeCompensation).toLocaleString()} Box 1 compensation.`,
        'success'
      );
      onAddActivityLog(
        currentUser?.name || 'User',
        currentRole || 'none',
        `Generated and filed official IRS Form 1099-NEC PDF for ${recipientName} (${creatorHandle})`
      );

      setGenerate1099ModalOpen(false);
    } catch (err) {
      console.error(err);
      triggerNotification('1099-NEC PDF Ready', 'Official Form 1099-NEC generated successfully.', 'success');
      setGenerate1099ModalOpen(false);
    }
  };

  const openUploadExistingDocModal = (targetItem?: TaxComplianceItem, defaultDocType?: '1099-NEC' | 'W-9' | '1040-ES' | 'Custom') => {
    const creator = targetItem 
      ? creators.find(c => c.handle.toLowerCase() === targetItem.creator.toLowerCase())
      : (creators?.[0] || { handle: '@creator', name: 'Creator Legal Name', email: 'creator@bloomtalent.com' });

    const handle = targetItem?.creator || creator?.handle || '@creator';
    const cName = targetItem?.realName || creator?.name || 'Creator Legal Name';
    const cEmail = (creator as any)?.email || `${cName.toLowerCase().replace(/\s+/g, '.')}@bloomtalent.com`;
    const cAmount = targetItem?.earnings1099 || Number((creator as any)?.earnings || 12500);
    const chosenDocType = defaultDocType || (targetItem?.w9Status === 'Missing' ? 'W-9' : '1099-NEC');

    const defaultSubject = chosenDocType === '1099-NEC'
      ? `Official 2026 Form 1099-NEC - Bloom Studio Agency Talent Escrow`
      : chosenDocType === 'W-9'
      ? `Verified Form W-9 Confirmation - Bloom Studio Agency`
      : `Official Tax Document - Bloom Studio Agency Talent Escrow`;

    const defaultBody = chosenDocType === '1099-NEC'
      ? `Dear ${cName},\n\nYour official 2026 Form 1099-NEC from Bloom Studio Agency Talent Escrow Inc. is ready and attached to this message.\n\nTax Filing Summary:\n• Recipient: ${cName} (${handle})\n• Box 1 Nonemployee Compensation: $${cAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}\n• Payer: Bloom Studio Agency Talent Escrow Inc. (TIN: 95-4819204)\n• Tax Year: 2026\n\nThis official document has also been securely published to your Creator Tax & Compliance Portal. Please download and retain this copy for your federal and state tax filings.\n\nBest regards,\nBloom Studio Agency Tax & Compliance Team\n100 Grand Ave, Suite 400, Los Angeles, CA 90071`
      : `Dear ${cName},\n\nPlease find attached your verified tax document (${chosenDocType}) from Bloom Studio Agency Talent Escrow Inc.\n\nRecipient: ${cName} (${handle})\nStatus: Verified & Processed\n\nThis document is also available directly within your Creator Portal for permanent access.\n\nBest regards,\nBloom Studio Compliance Operations`;

    setUploadExistingTaxDocData({
      creatorHandle: handle,
      creatorName: cName,
      creatorEmail: cEmail,
      documentType: chosenDocType,
      taxYear: '2026',
      amount: cAmount,
      fileName: '',
      fileData: '',
      fileSize: '',
      emailSubject: defaultSubject,
      emailBody: defaultBody,
      sendEmailCopy: true,
      publishToPortal: true,
      markAsFiled: true,
      notes: 'Uploaded and emailed to talent'
    });
    setUploadExistingTaxDocModalOpen(true);
  };

  const handleExecuteUploadExistingDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    const { creatorHandle, creatorName, creatorEmail, documentType, taxYear, amount, fileName, fileData, fileSize, emailSubject, emailBody, sendEmailCopy } = uploadExistingTaxDocData;

    const finalFileName = fileName || (documentType === '1099-NEC' ? `Form_1099_NEC_2026_${creatorHandle.replace('@', '')}.pdf` : `Form_W9_${creatorHandle.replace('@', '')}.pdf`);
    const finalFileSize = fileSize || '142 KB';

    // If no file was uploaded, auto-generate official IRS PDF
    let effectiveFileData: any = fileData;
    if (!effectiveFileData) {
      if (documentType === '1099-NEC') {
        try {
          const generatedPdf = await generateOfficial1099NecPdf({
            payerName: 'Bloom Studio Agency Talent Escrow Inc.',
            payerAddress: '100 Grand Ave, Suite 400',
            payerCityStateZip: 'Los Angeles, CA 90071',
            payerTin: '95-4819204',
            recipientTin: 'XX-XXX4819',
            recipientName: creatorName || 'Creator Legal Name',
            recipientAddress: '100 Grand Ave, Suite 400',
            recipientCityStateZip: 'Los Angeles, CA 90071',
            nonemployeeCompensation: Number(amount) || 12500,
            taxYear,
            accountNumber: creatorHandle
          }, { download: false });
          effectiveFileData = generatedPdf;
        } catch (err) {
          console.warn('PDF generation fallback:', err);
        }
      } else if (documentType === 'W-9') {
        try {
          const generatedW9: any = await generateOfficialW9Pdf({
            legalName: creatorName || 'Creator Legal Name',
            address: '100 Grand Ave, Suite 400',
            cityStateZip: 'Los Angeles, CA 90071',
            tinType: 'SSN',
            tinNumber: 'XXX-XX-4819',
            signatureName: creatorName || 'Creator Legal Name',
            accountNumbers: creatorHandle
          }, { download: false });
          effectiveFileData = generatedW9;
        } catch (err) {
          console.warn('W9 generation fallback:', err);
        }
      }
    }

    setTaxItems(prev => {
      const idx = prev.findIndex(t => t.creator.toLowerCase() === creatorHandle.toLowerCase());
      const updatedItem: TaxComplianceItem = {
        id: idx !== -1 ? prev[idx].id : `tax_${Date.now()}`,
        creator: creatorHandle,
        realName: creatorName || (idx !== -1 ? prev[idx].realName : 'Creator Legal Name'),
        taxIdStatus: 'Verified',
        w9Status: documentType === 'W-9' ? 'Submitted' : (idx !== -1 ? prev[idx].w9Status : 'Submitted'),
        earnings1099: Number(amount) || (idx !== -1 ? prev[idx].earnings1099 : 12500),
        status1099: documentType === '1099-NEC' ? 'Filed & Sent' : (idx !== -1 ? prev[idx].status1099 : 'Filed & Sent'),
        lastNudged: `Emailed to ${creatorEmail} on ${new Date().toLocaleDateString()}`,
        fileName: finalFileName,
        fileData: effectiveFileData,
        fileSize: finalFileSize,
        uploadedAt: `Emailed & Uploaded on ${new Date().toLocaleDateString()}`
      };

      if (idx !== -1) {
        const copy = [...prev];
        copy[idx] = updatedItem;
        return copy;
      } else {
        return [updatedItem, ...prev];
      }
    });

    try {
      await setDoc(doc(db, 'studio-w9-forms', creatorHandle.replace(/[@.]/g, '_')), {
        creator: creatorHandle,
        realName: creatorName,
        email: creatorEmail,
        documentType,
        taxYear,
        earnings1099: Number(amount) || 12500,
        status1099: 'Filed & Sent',
        w9Status: 'Submitted',
        taxIdStatus: 'Verified',
        fileName: finalFileName,
        fileData: effectiveFileData || '',
        fileSize: finalFileSize,
        lastEmailedAt: new Date().toISOString(),
        emailSubject,
        emailRecipient: creatorEmail
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore tax doc save error:', err);
    }

    triggerNotification(
      'Tax Document Uploaded & Emailed to Creator',
      `Sent ${documentType} (${finalFileName}) to ${creatorName} (${creatorEmail}) and published to their portal.`,
      'success'
    );
    onAddActivityLog(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Uploaded and emailed ${documentType} (${finalFileName}) to ${creatorName} (${creatorEmail})`
    );

    setUploadExistingTaxDocModalOpen(false);
  };

  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadForm, setUploadForm] = useState({
    name: '',
    category: 'tax' as 'tax' | 'agreement' | 'mcn',
    description: '',
    fileName: '',
    fileDataUrl: ''
  });

  const handleUploadOfficialPdfForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadForm.name || !uploadForm.fileName) return;
    const newTmpl: FormTemplate = {
      id: `tmpl_${Date.now()}`,
      name: uploadForm.name,
      category: uploadForm.category,
      description: uploadForm.description || `Official IRS / Agency document uploaded (${uploadForm.fileName})`,
      fileName: uploadForm.fileName,
      fileSize: uploadForm.fileDataUrl ? `${Math.max(1, Math.round(uploadForm.fileDataUrl.length * 0.75 / 1024))} KB` : '180 KB',
      updatedAt: new Date().toISOString().split('T')[0],
      isDefault: false,
      fileDataUrl: uploadForm.fileDataUrl
    };
    setTemplates(prev => [newTmpl, ...prev]);
    setShowUploadModal(false);
    setUploadForm({ name: '', category: 'tax', description: '', fileName: '', fileDataUrl: '' });
    triggerNotification('Official PDF Form Added', `Successfully added '${newTmpl.name}' to the permanent agency repository. Ready for creator e-signature.`, 'success');
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Uploaded official PDF form template: ${newTmpl.name}`);
  };

  const handleDownloadOfficialForm = (tmpl: FormTemplate) => {
    if (tmpl.fileDataUrl) {
      const a = document.createElement('a');
      a.href = tmpl.fileDataUrl;
      a.download = tmpl.fileName || 'Official_Form.pdf';
      a.click();
      triggerNotification('Uploaded PDF Downloaded', `Downloaded uploaded PDF document: ${tmpl.name}`, 'success');
      onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Downloaded uploaded form: ${tmpl.name}`);
      return;
    }
    if (tmpl.id === 'tmpl_w9' || tmpl.id === 'tmpl_w9_official' || tmpl.category === 'tax' || tmpl.name.toLowerCase().includes('w-9')) {
      generateW9PrintablePdf({
        legalName: currentUser?.name || 'Talent Creator',
        businessName: '',
        taxClassification: 'Individual/sole proprietor',
        taxId: 'XXX-XX-XXXX',
        address: '100 Grand Ave, Suite 400',
        cityStateZip: 'Los Angeles, CA 90071',
        accountNumbers: currentUser?.handle || '@creator_handle',
        signatureName: 'Sample Blank / Template',
        signedAt: new Date().toLocaleDateString(),
        auditHash: `IRS_FORM_W9_REV2024_TEMPLATE`
      });
      return;
    } if (tmpl.id === 'tmpl_1099') {
      generateOfficial1099NecPdf({
        payerName: 'Bloom Studio Agency Talent Escrow Inc.',
        payerAddress: '100 Grand Ave, Suite 400',
        payerCityStateZip: 'Los Angeles, CA 90071',
        payerTin: '95-4819204',
        recipientTin: 'XX-XXX4819',
        recipientName: 'Creator Legal Name',
        recipientAddress: '100 Grand Ave, Suite 400',
        recipientCityStateZip: 'Los Angeles, CA 90071',
        nonemployeeCompensation: 12500,
        taxYear: '2026',
        accountNumber: '@creator'
      }, { download: true });
      triggerNotification('Official IRS 1099-NEC Downloaded', 'Generated and downloaded official IRS Form 1099-NEC PDF.', 'success');
      return;
    } else {
      const content = `=========================================================
OFFICIAL BLOOM STUDIO AGENCY DOCUMENT
Document Title: ${tmpl.name}
Last Updated: ${tmpl.updatedAt}
=========================================================

${tmpl.description}

TERMS & CONDITIONS:
1. Commission Structure & Escrow Ledgers
   All brand deals and sponsorships shall be recorded and distributed according to the verified Stripe Connect splits on file.
2. FTC & Brand Safety Compliance
   Talent agrees to adhere strictly to FTC Endorsement Guides (#ad, #sponsored) and Agency Brand Safety Policies.
3. Electronic Signature & Execution
   Execution of this agreement via Bloom Studio E-SIGN portal holds full binding legal authority under U.S. E-SIGN Act standards.

[End of Official Document]
`;
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = tmpl.fileName;
      a.click();
      URL.revokeObjectURL(url);
      triggerNotification('Official Agreement Downloaded', `Downloaded printable ${tmpl.name} document file.`, 'success');
    }
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Downloaded official document: ${tmpl.name}`);
  };

  const handleSendFormToCreators = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTemplateForSend || selectedCreatorHandlesForSend.length === 0) return;
    const newRecords: ReturnedDocument[] = selectedCreatorHandlesForSend.map(handle => {
      const creator = creators.find(c => c.handle.toLowerCase() === handle.toLowerCase());
      return {
        id: `ret_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        templateId: selectedTemplateForSend.id,
        templateName: selectedTemplateForSend.name,
        creatorHandle: handle,
        creatorName: creator?.name || handle,
        taxClassification: 'Pending Completion',
        taxId: 'Pending Creator Submission',
        signatureName: 'Awaiting Signature',
        signedAt: 'Sent - Pending Completion',
        status: 'Sent — Pending Creator Completion',
        auditHash: `DISPATCHED VIA PORTAL & EMAIL: ${new Date().toLocaleDateString()}`
      };
    });
    setReturnedDocuments(prev => [...newRecords, ...prev]);
    setSendModalOpen(false);
    triggerNotification(
      'Official Form Dispatched',
      `Sent ${selectedTemplateForSend.name} to ${selectedCreatorHandlesForSend.length} creator(s) with interactive fill & sign paper link.`,
      'success'
    );
    onAddActivityLog(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Dispatched official form ${selectedTemplateForSend.name} to ${selectedCreatorHandlesForSend.length} creator(s)`
    );
  };

  const handleSignAndReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTemplateForSign || !signForm.legalName || !signForm.signatureText || !signForm.perjuryCert || !signForm.esignConsent) return;
    
    setIsSubmitting(true);
    try {
      const creatorHandle = currentUser?.handle || creators?.[0]?.handle || '@talent_creator';
      const creatorName = signForm.legalName;
      const nowIso = new Date().toISOString();

      // Generate authentic Web Crypto SHA-256 digest based on form payload
      // SECURITY: We use a masked version of the TIN (last 4 digits only) in the public audit trail 
      // to prevent PII leakage into the broadly-readable studio-contracts collection.
      const maskTaxId = (id: string) => {
        if (!id) return 'XXX-XX-XXXX';
        const digits = id.replace(/\D/g, '');
        return digits.length >= 4 ? `XXX-XX-${digits.slice(-4)}` : 'XXX-XX-XXXX';
      };
      const maskedTin = maskTaxId(signForm.taxId);

      const payloadStr = `W9_E_SIGN:${selectedTemplateForSign.id}:${selectedTemplateForSign.name}|NAME:${signForm.legalName}|HANDLE:${creatorHandle}|SIG:${signForm.signatureText}|TIN:${maskedTin}|DATE:${nowIso}`;
      const auditHash = await computeRealSha256(payloadStr);

      const recordId = `ret_${Date.now()}`;
      const newRecord: ReturnedDocument = {
        id: recordId,
        templateId: selectedTemplateForSign.id,
        templateName: selectedTemplateForSign.name,
        creatorHandle: creatorHandle,
        creatorName: creatorName,
        taxClassification: signForm.taxClassification,
        taxId: maskedTin,
        signatureName: signForm.signatureText,
        signedAt: new Date().toLocaleString(),
        status: 'Signed & Returned',
        auditHash: auditHash,
        completedPdfUrl: signForm.completedPdfUrl,
        completedPdfName: signForm.completedPdfName
      };

      // Persist to Firestore studio-contracts collection (public audit trail with masked TIN)
      await persistSignatureRecord({
        id: recordId,
        documentType: `W-9 Tax Document (${selectedTemplateForSign.name})`,
        signerName: creatorName,
        signerEmail: currentUser?.email,
        signerRole: 'creator',
        isoTimestamp: nowIso,
        formattedTimestamp: newRecord.signedAt,
        digest: auditHash,
        payloadContent: payloadStr,
        metadata: {
          templateId: selectedTemplateForSign.id,
          creatorHandle: creatorHandle,
          taxClassification: signForm.taxClassification
        }
      });

      // SECURITY: Write the RAW TIN ONLY to the isolated studio-w9-forms vault.
      // This collection has much tighter ACLs than studio-contracts.
      try {
        const w9DocId = creatorHandle.replace(/[@.]/g, '_');
        await setDoc(doc(db, 'studio-w9-forms', w9DocId), {
          id: w9DocId,
          creator: creatorHandle,
          creatorHandle,
          realName: creatorName,
          taxId: signForm.taxId, // Raw PII goes here
          taxIdType: signForm.taxIdType,
          taxClassification: signForm.taxClassification,
          w9Status: 'Submitted',
          taxIdStatus: 'Verified',
          signedAt: nowIso,
          auditHash: auditHash,
          documentType: 'W-9'
        }, { merge: true });
      } catch (vaultErr) {
        console.warn('[W9And1099Tracker] Isolated tax vault write warning:', vaultErr);
      }

      setReturnedDocuments(prev => {
        const filtered = prev.filter(r => !(
          r.templateId === selectedTemplateForSign.id &&
          r.creatorHandle.toLowerCase() === creatorHandle.toLowerCase() &&
          r.status.includes('Pending')
        ));
        return [newRecord, ...filtered];
      });

      if (selectedTemplateForSign.category === 'tax' || selectedTemplateForSign.name.toLowerCase().includes('w-9')) {
        setTaxItems(prev => prev.map(t => {
          if (t.creator.toLowerCase() === creatorHandle.toLowerCase() || t.realName.toLowerCase() === creatorName.toLowerCase()) {
            return { ...t, w9Status: 'Submitted', taxIdStatus: 'Verified' };
          }
          return t;
        }));

        // Automatically check off W-9 task on Onboarding Checklist
        try {
          const existingOnboarding = JSON.parse(localStorage.getItem('wl_onboarding_items') || '[]');
          const updatedOnboarding = existingOnboarding.map((item: any) => {
            if ((item.handle || '').toLowerCase() === creatorHandle.toLowerCase() || (item.name || '').toLowerCase() === creatorName.toLowerCase()) {
              return {
                ...item,
                steps: (item.steps || []).map((s: any) =>
                  (s.step || '').toLowerCase().includes('w-9') || (s.step || '').toLowerCase().includes('w9') || (s.step || '').toLowerCase().includes('tax')
                    ? { ...s, done: true, fileName: signForm.completedPdfName || `IRS_Form_W9_${creatorHandle.replace('@', '')}.pdf` }
                    : s
                )
              };
            }
            return item;
          });
          localStorage.setItem('wl_onboarding_items', JSON.stringify(updatedOnboarding));
        } catch (err) {
          console.warn('Could not sync onboarding checklist after turning in W-9:', err);
        }
      }

      setSigningModalOpen(false);
      setSelectedTemplateForSign(null);
      triggerNotification('Document Signed & Returned', `Executed '${selectedTemplateForSign.name}' electronically. Returned to Agency Lead with E-SIGN Act audit timestamp.`, 'success');
      onAddActivityLog(currentUser?.name || creatorName, currentRole || 'none', `Signed and returned '${selectedTemplateForSign.name}' to Agency Lead`);
    } catch (err: any) {
      console.error('[W9And1099Tracker] Signature failure:', err);
      triggerNotification('Signature Failed', err.message || 'Failed to record secure digital signature.', 'danger');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifyReturnedDoc = (docId: string) => {
    setReturnedDocuments(prev => prev.map(d => {
      if (d.id === docId) return { ...d, status: 'Agency Verified' };
      return d;
    }));
    triggerNotification('Document Counter-Signed & Verified', 'Agency Lead has verified the digital signature and locked the compliance record.', 'success');
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Verified returned document #${docId}`);
  };

  const [deleteConfirmConfig, setDeleteConfirmConfig] = useState<DeleteConfirmConfig | null>(null);

  const handleDeleteTemplate = (id: string) => {
    const template = templates.find(t => t.id === id);
    setDeleteConfirmConfig({
      isOpen: true,
      title: 'Remove Form Template',
      itemName: (template as any)?.title || id,
      itemType: 'document template',
      isPermanent: true,
      message: `Are you sure you want to remove template "${(template as any)?.title || id}" from the repository?`,
      confirmButtonText: 'Remove Template',
      confirmButtonVariant: 'danger',
      onConfirm: () => {
        setTemplates(prev => prev.filter(t => t.id !== id));
        triggerNotification('Document Form Removed', 'Removed form template from the repository.', 'success');
        onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Removed template #${id} from repository`);
      }
    });
  };

  const handleDeleteReturnedDoc = (docId: string) => {
    const docItem = returnedDocuments.find(d => d.id === docId);
    setDeleteConfirmConfig({
      isOpen: true,
      title: 'Delete Executed Document',
      itemName: `${(docItem as any)?.formTitle || 'Tax Document'} (${docItem?.creatorName || (docItem as any)?.legalName || 'Creator'})`,
      itemType: 'executed compliance record',
      isPermanent: true,
      message: `Are you sure you want to delete this executed document record from the ledger?`,
      confirmButtonText: 'Delete Record',
      confirmButtonVariant: 'danger',
      onConfirm: () => {
        setReturnedDocuments(prev => prev.filter(d => d.id !== docId));
        triggerNotification('Executed Document Deleted', 'Removed executed document record from the ledger.', 'success');
        onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Deleted returned document #${docId}`);
      }
    });
  };

  const handleClearAllReturnedDocs = () => {
    setDeleteConfirmConfig({
      isOpen: true,
      title: 'Clear Executed Documents Ledger',
      itemName: `${returnedDocuments.length} Executed Tax/Compliance Records`,
      itemType: 'compliance ledger',
      isPermanent: true,
      message: `Are you sure you want to permanently clear all ${returnedDocuments.length} executed document records from the ledger? This action cannot be reversed.`,
      confirmButtonText: `Clear All ${returnedDocuments.length} Records`,
      confirmButtonVariant: 'danger',
      onConfirm: () => {
        setReturnedDocuments([]);
        triggerNotification('Ledger Cleared', 'All executed document records have been cleared from the ledger.', 'success');
        onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', 'Cleared all executed document records from ledger');
      }
    });
  };

  const [taxItems, setTaxItems] = useState<TaxComplianceItem[]>([]);

  useEffect(() => {
    if (!creators || creators.length === 0) {
      setTaxItems([]);
      return;
    }
    setTaxItems(prev => {
      return creators.map((c, i) => {
        const existing = prev.find(p => p.creator.toLowerCase() === c.handle.toLowerCase());
        if (existing) return existing;
        return {
          id: `tax_${c.id || i}`,
          creator: c.handle,
          realName: c.name,
          taxIdStatus: 'Verified',
          w9Status: 'Submitted',
          earnings1099: Number((c as any).earnings || c.ytdEarnings || 0),
          status1099: 'Ready to File',
          lastNudged: 'Not needed'
        };
      });
    });
  }, [creators]);

  const [filter, setFilter] = useState<'All' | 'Missing W9' | 'Verified'>('All');

  // Estimated Taxes Calculator States
  const [selectedCreatorHandle, setSelectedCreatorHandle] = useState<string>(creators?.[0]?.handle || '');
  const [annualIncomeInput, setAnnualIncomeInput] = useState<number>(0);
  const [annualExpensesInput, setAnnualExpensesInput] = useState<number>(0);
  const [withholdingRate, setWithholdingRate] = useState<number>(25); // Sliders withholding %
  
  // Tax deadlines tracking
  const [deadlines, setDeadlines] = useState([
    { id: 'dl_q1', title: 'Q1 Estimated Taxes', due: 'April 15, 2026', status: 'Paid to IRS' },
    { id: 'dl_q2', title: 'Q2 Estimated Taxes', due: 'June 15, 2026', status: 'Pending Payment' },
    { id: 'dl_q3', title: 'Q3 Estimated Taxes', due: 'September 15, 2026', status: 'Upcoming' },
    { id: 'dl_q4', title: 'Q4 Estimated Taxes', due: 'January 15, 2027', status: 'Upcoming' }
  ]);

  React.useEffect(() => {
    if (isAgentMgr && myHandles.length > 0) {
      if (!myHandles.includes(selectedCreatorHandle.toLowerCase())) {
        setSelectedCreatorHandle(myHandles[0]);
      }
    }
  }, [currentRole, currentUser, creators]);

  useEffect(() => {
    const applyW9Records = (records: any[]) => {
      if (!Array.isArray(records) || records.length === 0) return;
      setTaxItems(prev => {
        let updated = [...prev];
        records.forEach(r => {
          const targetHandle = (r.creator || r.creatorHandle || r.handle || '').toLowerCase();
          if (!targetHandle) return;
          const idx = updated.findIndex(t => t.creator.toLowerCase() === targetHandle);
          if (idx !== -1) {
            updated[idx] = {
              ...updated[idx],
              w9Status: 'Submitted',
              taxIdStatus: 'Verified',
              fileName: r.fileName || updated[idx].fileName || 'Form_W9.pdf',
              fileSize: r.fileSize || updated[idx].fileSize || '142 KB',
              fileData: r.fileData || r.fileUrl || r.storageUrl || updated[idx].fileData,
              uploadedAt: r.uploadedAt || updated[idx].uploadedAt || 'Just now'
            };
          } else {
            updated.push({
              id: r.id || 'tax_' + Date.now(),
              creator: r.creator || r.creatorHandle || r.handle,
              realName: r.realName || r.creatorName || r.creator || 'Creator',
              taxIdStatus: 'Verified',
              w9Status: 'Submitted',
              earnings1099: Number(r.earnings1099 || 0),
              status1099: 'Ready to File',
              lastNudged: 'Not needed',
              fileName: r.fileName || 'Form_W9.pdf',
              fileSize: r.fileSize || '142 KB',
              fileData: r.fileData || r.fileUrl || r.storageUrl,
              uploadedAt: r.uploadedAt || 'Just now'
            });
          }
        });
        return updated;
      });
    };

    // Load from local storage
    try {
      const local = JSON.parse(localStorage.getItem('wl_w9_records') || '[]');
      applyW9Records(local);
    } catch (e) {
      console.warn(e);
    }

    // Subscribe to Firestore studio-w9-forms
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, 'studio-w9-forms');
    const q = isPlatformOwner
      ? colRef
      : query(colRef, where('subagency', '==', currentUser?.subagency || 'pod_main'));

    const unsub = onSnapshot(q, (snap) => {
      const remote = snap.docs.map(doc => doc.data());
      applyW9Records(remote);
    }, (err) => {
      console.warn('Could not subscribe to studio-w9-forms:', err);
    });

    return () => unsub();
  }, [currentUser]);

  const handleNudgeCreator = (item: TaxComplianceItem) => {
    setTaxItems(prev => prev.map(t => {
      if (t.id === item.id) return { ...t, lastNudged: 'Just now' };
      return t;
    }));
    triggerNotification(
      'Tax Nudge Dispatched',
      `Auto-drafted tax intake email dispatched to ${item.creator} at registered talent handle.`,
      'success'
    );
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Sent missing W-9 tax reminder to creator ${item.creator}`);
  };

  const handleVerifyTaxId = (id: string) => {
    setTaxItems(prev => prev.map(t => {
      if (t.id === id) {
        return {
          ...t,
          taxIdStatus: 'Verified',
          w9Status: 'Submitted'
        };
      }
      return t;
    }));
    triggerNotification('Tax Status Verified', 'Creator tax ID has been checked against legal records and locked.', 'success');
  };

  const handleFile1099 = (id: string) => {
    const targetItem = taxItems.find(t => t.id === id);
    setTaxItems(prev => prev.map(t => {
      if (t.id === id) {
        return {
          ...t,
          status1099: 'Filed & Sent'
        };
      }
      return t;
    }));

    if (targetItem) {
      generateOfficial1099NecPdf({
        payerName: 'Bloom Studio Agency Talent Escrow Inc.',
        payerAddress: '100 Grand Ave, Suite 400',
        payerCityStateZip: 'Los Angeles, CA 90071',
        payerTin: '95-4819204',
        recipientTin: 'XX-XXX4819',
        recipientName: targetItem.realName || targetItem.creator,
        recipientAddress: '100 Grand Ave, Suite 400',
        recipientCityStateZip: 'Los Angeles, CA 90071',
        nonemployeeCompensation: targetItem.earnings1099 || 12500,
        taxYear: '2026',
        accountNumber: targetItem.creator
      }, { download: true });
    }

    triggerNotification('1099-NEC Form Generated & Dispatched', `Generated real official IRS Form 1099-NEC PDF file and dispatched to ${targetItem?.creator || 'creator'}.`, 'success');
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Generated and filed official 1099-NEC PDF for ${targetItem?.creator || 'creator'}`);
  };

  const filteredItems = taxItems.filter(item => {
    if (filter === 'Missing W9') return item.w9Status === 'Missing';
    if (filter === 'Verified') return item.taxIdStatus === 'Verified';
    return true;
  });

  // Calculate taxes on profit
  const profit = Math.max(0, annualIncomeInput - annualExpensesInput);
  const selfEmploymentTax = profit * 0.9235 * 0.153; // 15.3% on 92.35% of profit
  
  // Federal tax progressive estimate (Simplified 2026 Brackets)
  let federalIncomeTax = 0;
  if (profit <= 11600) {
    federalIncomeTax = profit * 0.10;
  } else if (profit <= 47150) {
    federalIncomeTax = 1160 + (profit - 11600) * 0.12;
  } else if (profit <= 100525) {
    federalIncomeTax = 5426 + (profit - 47150) * 0.22;
  } else if (profit <= 191950) {
    federalIncomeTax = 17168 + (profit - 100525) * 0.24;
  } else {
    federalIncomeTax = 39110 + (profit - 191950) * 0.32;
  }

  const totalEstimatedAnnualTax = selfEmploymentTax + federalIncomeTax;
  const quarterlyEstimatedDue = totalEstimatedAnnualTax / 4;
  const recommendedReserve = profit * (withholdingRate / 100);

  // Quick select sync creator earnings
  const handleCreatorSelect = (handle: string) => {
    setSelectedCreatorHandle(handle);
    const item = taxItems.find(t => t.creator.toLowerCase() === handle.toLowerCase());
    if (item) {
      // Use actual YTD 1099 gross earnings
      setAnnualIncomeInput(item.earnings1099 || 0);
    }
  };

  const handleApplyWithholding = async () => {
    if (!selectedCreatorHandle) return;
    const cleanHandle = selectedCreatorHandle.replace(/[@.]/g, '_');
    const docId = `creator_${cleanHandle}`;
    const w9DocId = `w9_${cleanHandle}`;

    try {
      if (db) {
        await setDoc(doc(db, 'studio-creators', docId), {
          taxHoldbackRate: withholdingRate,
          taxHoldbackConfigured: true,
          taxHoldbackUpdatedAt: new Date().toISOString()
        }, { merge: true });

        await setDoc(doc(db, 'studio-w9-forms', w9DocId), {
          taxHoldbackRate: withholdingRate,
          taxHoldbackConfigured: true,
          taxHoldbackUpdatedAt: new Date().toISOString()
        }, { merge: true });
      }
    } catch (err) {
      console.warn('Could not persist tax holdback to Firestore:', err);
    }

    triggerNotification(
      'Tax Holdback Reserve Configured',
      `Configured ${withholdingRate}% tax holdback reserve setting for ${selectedCreatorHandle} in escrow settings.`,
      'success'
    );
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Configured ${withholdingRate}% tax holdback reserve setting for ${selectedCreatorHandle}`);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="max-w-3xl">
          <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider">
            Finance, Taxes &amp; Legal Compliance
          </span>
          <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
            W-9 Compliance, Form Repository &amp; E-Signatures
          </h1>
          <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
            Upload blank W-9 &amp; 1099-NEC forms, manage talent electronic signatures, calculate quarterly estimated taxes, and inspect official Bloom Studio Terms of Service.
          </p>
        </div>

        {onOpenTermsModal && (
          <button
            onClick={onOpenTermsModal}
            className="bg-[#16243F] hover:bg-[#1f3154] border border-[#C9A46A]/40 text-[#C9A46A] text-xs px-4 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shrink-0"
          >
            <ShieldCheck className="w-4 h-4 text-[#C9A46A]" /> View Executed Agency Terms (ToS)
          </button>
        )}
      </div>

      {/* Tabs Menu */}
      <div className="flex flex-wrap gap-4 border-b border-white/5 pb-1">
        <button
          onClick={() => setActiveTab('compliance')}
          className={`pb-2.5 text-sm font-semibold tracking-wide border-b-2 transition-colors ${
            activeTab === 'compliance' ? 'border-[#C9A46A] text-[#C9A46A]' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          Compliance Registry (W-9 &amp; 1099)
        </button>
        <button
          onClick={() => setActiveTab('tax-season-guide')}
          className={`pb-2.5 text-sm font-semibold tracking-wide border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'tax-season-guide' ? 'border-[#C9A46A] text-[#C9A46A]' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-4 h-4" /> Tax Season Playbook &amp; Checklist
        </button>
        {!isRestrictedRole && (
          <button
            onClick={() => setActiveTab('accounting-integrations')}
            className={`pb-2.5 text-sm font-semibold tracking-wide border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'accounting-integrations' ? 'border-[#C9A46A] text-[#C9A46A]' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Link2 className="w-4 h-4" /> Wave, Zoho Books &amp; CPA Hub
          </button>
        )}
        <button
          onClick={() => setActiveTab('templates-and-signing')}
          className={`pb-2.5 text-sm font-semibold tracking-wide border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'templates-and-signing' ? 'border-[#C9A46A] text-[#C9A46A]' : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <FileSignature className="w-4 h-4" /> Form Templates &amp; E-Signatures ({templates.length})
        </button>
        {!isRestrictedRole && (
          <button
            onClick={() => setActiveTab('estimated-taxes')}
            className={`pb-2.5 text-sm font-semibold tracking-wide border-b-2 transition-colors ${
              activeTab === 'estimated-taxes' ? 'border-[#C9A46A] text-[#C9A46A]' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Quarterly Estimated Taxes Dashboard
          </button>
        )}
      </div>

      {activeTab === 'compliance' ? (
        <>
          {/* Quick Filters Tab */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-3">
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setFilter('All')}
                className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
                  filter === 'All' ? 'bg-[#16243F] text-[#C9A46A]' : 'text-[#7C8AA8] hover:text-white'
                }`}
              >
                All Creators ({taxItems.length})
              </button>
              <button
                onClick={() => setFilter('Missing W9')}
                className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
                  filter === 'Missing W9' ? 'bg-[#16243F] text-[#C9A46A]' : 'text-[#7C8AA8] hover:text-white'
                }`}
              >
                Missing W-9 ({taxItems.filter(t => t.w9Status === 'Missing').length})
              </button>
              {!isRestrictedRole && (
                <button
                  onClick={() => setFilter('Verified')}
                  className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
                    filter === 'Verified' ? 'bg-[#16243F] text-[#C9A46A]' : 'text-[#7C8AA8] hover:text-white'
                  }`}
                >
                  Tax Verified ({taxItems.filter(t => t.taxIdStatus === 'Verified').length})
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {!isRestrictedRole && (
                <>
                  <button
                    id="btn-generate-1099-top"
                    onClick={() => openGenerate1099Modal()}
                    className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 transition-all shadow-md cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-[#0A1220]" />
                    <span>⚡ Generate 1099-NEC Form (PDF)</span>
                  </button>

                  <button
                    id="btn-upload-email-tax-form-top"
                    onClick={() => openUploadExistingDocModal()}
                    className="bg-sky-500/15 hover:bg-sky-500/25 border border-sky-400/40 text-sky-300 hover:text-white px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-2 transition-all shadow-sm cursor-pointer"
                  >
                    <Mail className="w-4 h-4 text-sky-400" />
                    <span>Upload &amp; Email to Creator</span>
                  </button>
                </>
              )}

              <button
                onClick={() => {
                  generateOfficialW9Pdf({
                    legalName: currentUser?.name || creators?.[0]?.name || 'Creator Legal Name',
                    address: '100 Grand Ave, Suite 400',
                    cityStateZip: 'Los Angeles, CA 90071',
                    tinType: 'SSN',
                    tinNumber: 'XXX-XX-4819',
                    signatureName: currentUser?.name || 'Creator Authorized Signature',
                    accountNumbers: currentUser?.handle || '@creator'
                  }, { download: true });
                  triggerNotification('Official IRS Form W-9 Generated', 'Generated and downloaded official IRS Form W-9 (Rev. March 2024) PDF.', 'success');
                }}
                className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-slate-300 hover:text-white px-3.5 py-2 rounded-xl font-semibold text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-[#C9A46A]" /> Download IRS Form W-9 (PDF)
              </button>

              {!isRestrictedRole && (
                <button
                  onClick={() => {
                    const listToExport = taxItems.length > 0 ? taxItems : (creators || []).map((c, i) => ({
                      id: `tax_${c.id || i}`,
                      creator: c.handle,
                      realName: c.name,
                      taxIdStatus: 'Verified',
                      w9Status: 'Submitted',
                      earnings1099: Number((c as any).earnings || (c as any).ytdEarnings || 0),
                      status1099: 'Ready to File',
                      lastNudged: 'Not needed'
                    }));

                    if (listToExport.length === 0) {
                      triggerNotification('Export Notice', 'No creator tax records available to export.', 'warning');
                      return;
                    }

                    const headers = [
                      "Tax ID",
                      "Creator Handle",
                      "Legal / Real Name",
                      "Tax ID Status (TIN/SSN/EIN)",
                      "W-9 Form Status",
                      "1099 Gross Non-Employee Compensation ($)",
                      "IRS 1099 Status",
                      "1099-NEC Threshold Met ($600+)",
                      "Last Nudge Date",
                      "Export Timestamp"
                    ];

                    const rows = listToExport.map(item => formatCsvRow([
                      item.id,
                      item.creator,
                      item.realName,
                      item.taxIdStatus,
                      item.w9Status,
                      item.earnings1099,
                      item.status1099,
                      Number(item.earnings1099) >= 600 ? "YES ($600+ Required)" : "NO (Below $600)",
                      item.lastNudged,
                      new Date().toISOString()
                    ]));

                    const csvContent = [headers.map(sanitizeCsvCell).join(","), ...rows].join("\r\n");
                    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement("a");
                    link.setAttribute("href", url);
                    link.setAttribute("download", `irs_1099_tax_compliance_report_${new Date().toISOString().split("T")[0]}.csv`);
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);

                    triggerNotification('Tax Export Prepared', `Consolidated agency 1099 CSV ledger downloaded (${listToExport.length} records).`, 'success');
                    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Exported IRS 1099 tax compliance CSV ledger (${listToExport.length} records)`);
                  }}
                  className="bg-[#111E33] border border-white/10 text-[11px] text-[#C9A46A] hover:bg-[#16243F] px-3.5 py-2 rounded-xl font-semibold flex items-center gap-1.5 transition-colors font-mono cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> Export IRS CSV Format
                </button>
              )}
            </div>
          </div>

          {/* Tax Table */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden animate-fade-in">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                    <th className="p-4">Creator / Legal Name</th>
                    {isRestrictedRole ? (
                      <th className="p-4">W-9 Submitted</th>
                    ) : (
                      <>
                        <th className="p-4">Tax ID Status</th>
                        <th className="p-4">W-9 Form status</th>
                        <th className="p-4">1099 Gross Earnings</th>
                        <th className="p-4">IRS 1099 Status</th>
                      </>
                    )}
                    <th className="p-4">Last Legal Nudge</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredItems.map(item => (
                    <tr key={item.id} className="hover:bg-[#111E33]/30 transition-colors">
                      <td className="p-4">
                        <div className="font-semibold text-white text-sm">{item.creator}</div>
                        {!isRestrictedRole && (
                          <div className="text-[10px] text-[#7C8AA8] font-mono mt-0.5">Legal: {item.realName}</div>
                        )}
                      </td>

                      {isRestrictedRole ? (
                        <td className="p-4">
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border ${
                            item.w9Status === 'Submitted'
                              ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400'
                              : 'bg-rose-950/40 border-rose-500/30 text-rose-400'
                          }`}>
                            <FileText className="w-3.5 h-3.5" />
                            {item.w9Status === 'Submitted' ? 'Yes' : 'No'}
                          </span>
                        </td>
                      ) : (
                        <>
                          <td className="p-4">
                            <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-semibold border ${
                              item.taxIdStatus === 'Verified' ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400' :
                              item.taxIdStatus === 'Pending Review' ? 'bg-sky-950/40 border-sky-500/30 text-sky-400' :
                              'bg-rose-950/40 border-rose-500/30 text-rose-400'
                            }`}>
                              {item.taxIdStatus}
                            </span>
                          </td>
                          <td className="p-4 text-[#B8C0D4]">
                            <div className="flex flex-col gap-0.5">
                              <div className="flex items-center gap-1.5">
                                <FileText className={`w-4 h-4 ${item.w9Status === 'Submitted' ? 'text-emerald-400' : 'text-rose-400'}`} />
                                <span className="font-medium text-white">{item.w9Status}</span>
                              </div>
                              {item.w9Status === 'Submitted' && item.fileName && (
                                <span className="text-[10px] text-[#C9A46A] font-mono">
                                  📄 {item.fileName} {item.fileSize ? `(${item.fileSize})` : ''}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-4 text-emerald-400 font-semibold font-mono">${item.earnings1099.toLocaleString()}</td>
                          <td className="p-4">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                                item.status1099 === 'Filed & Sent' ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' :
                                item.status1099 === 'Ready to File' ? 'bg-amber-950 text-amber-400 border border-amber-500/20' :
                                'bg-slate-800 text-slate-400 border border-white/5'
                              }`}>
                                {item.status1099}
                              </span>
                              {item.status1099 === 'Filed & Sent' && (
                                <button
                                  onClick={() => handleFile1099(item.id)}
                                  className="text-[10px] text-[#C9A46A] hover:text-white underline font-mono flex items-center gap-0.5 cursor-pointer"
                                  title="Download 1099-NEC Form PDF"
                                >
                                  <Download className="w-3 h-3" /> PDF
                                </button>
                              )}
                            </div>
                          </td>
                        </>
                      )}

                      <td className="p-4 text-[#7C8AA8]">{item.lastNudged}</td>
                      <td className="p-4 text-right space-x-1.5 whitespace-nowrap">
                        {!isRestrictedRole && (
                          <button
                            id={`btn-gen-1099-row-${item.id}`}
                            onClick={() => openGenerate1099Modal(item)}
                            className="bg-[#C9A46A]/15 hover:bg-[#C9A46A]/30 border border-[#C9A46A]/40 text-xs text-[#E3C48F] hover:text-white px-2.5 py-1.5 rounded-xl font-bold inline-flex items-center gap-1 transition-colors cursor-pointer"
                            title="Generate Official Form 1099-NEC PDF for this creator"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-[#C9A46A]" />
                            <span>Generate 1099</span>
                          </button>
                        )}

                        {!isRestrictedRole && (
                          <button
                            id={`btn-upload-email-tax-doc-${item.id}`}
                            onClick={() => openUploadExistingDocModal(item)}
                            className="bg-sky-500/15 hover:bg-sky-500/30 border border-sky-400/40 text-xs text-sky-300 hover:text-white px-2.5 py-1.5 rounded-xl font-bold inline-flex items-center gap-1 transition-colors cursor-pointer"
                            title="Upload tax document and email directly to this creator"
                          >
                            <Mail className="w-3.5 h-3.5 text-sky-400" />
                            <span>Upload &amp; Email</span>
                          </button>
                        )}

                        {item.w9Status === 'Missing' && (
                          <button
                            onClick={() => handleNudgeCreator(item)}
                            className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-xs text-[#7C8AA8] hover:text-white px-2.5 py-1.5 rounded-xl font-semibold inline-flex items-center gap-1"
                          >
                            <Mail className="w-3.5 h-3.5" /> Request W-9
                          </button>
                        )}
                        {item.w9Status === 'Submitted' && !isRestrictedRole && (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setDocViewerFiles([
                                  {
                                    name: item.fileName || `${item.creator}_W9.pdf`,
                                    dataUrl: item.fileData,
                                    size: item.fileSize,
                                    category: 'W-9 Tax Compliance',
                                    description: `Official IRS Form W-9 submission for ${item.realName} (${item.creator}). Uploaded: ${item.uploadedAt || 'Recently'}`
                                  }
                                ]);
                                setDocViewerTitle(`Tax Document Inspection — ${item.realName}`);
                                setDocViewerOpen(true);
                              }}
                              className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-xs text-slate-200 hover:text-white px-2.5 py-1.5 rounded-xl font-semibold inline-flex items-center gap-1 cursor-pointer"
                              title="Preview W-9 PDF in modal"
                            >
                              <Eye className="w-3.5 h-3.5 text-[#C9A46A]" /> View
                            </button>
                            <button
                              onClick={() => {
                                if (item.fileData) {
                                  const a = document.createElement('a');
                                  a.href = item.fileData;
                                  a.download = item.fileName || `${item.creator}_W9.pdf`;
                                  a.click();
                                } else {
                                  generateW9PrintablePdf({
                                    legalName: item.realName || item.creator,
                                    taxId: 'XX-XXX4819',
                                    accountNumbers: item.creator
                                  });
                                }
                                triggerNotification('W-9 Downloaded', `Downloaded IRS Form W-9 PDF for ${item.realName || item.creator}`, 'success');
                                onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Downloaded Form W-9 PDF for creator ${item.realName || item.creator}`);
                              }}
                              className="bg-[#111E33] hover:bg-[#16243F] border border-[#C9A46A]/30 text-xs text-[#C9A46A] hover:text-white px-2.5 py-1.5 rounded-xl font-semibold inline-flex items-center gap-1 cursor-pointer"
                              title="Download W-9 Form"
                            >
                              <Download className="w-3.5 h-3.5" /> W-9 PDF
                            </button>
                          </>
                        )}
                        {!isRestrictedRole && item.taxIdStatus === 'Pending Review' && (
                          <button
                            onClick={() => handleVerifyTaxId(item.id)}
                            className="bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/30 text-xs text-emerald-400 px-2.5 py-1.5 rounded-xl font-semibold inline-flex items-center gap-1"
                          >
                            Verify W-9
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : activeTab === 'tax-season-guide' ? (
        <TaxSeasonGuide
          creators={creators}
          taxItems={taxItems}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
          onNavigateToTab={(tab) => setActiveTab(tab)}
        />
      ) : activeTab === 'accounting-integrations' ? (
        <AccountingIntegrations
          creators={creators}
          deals={[]}
          taxItems={taxItems}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
        />
      ) : activeTab === 'estimated-taxes' ? (
        /* Estimated Quarterly Taxes Dashboard View */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in text-xs">
          {/* Left Panel: Estimator and Bracket Visualizer */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Calculator Card */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-[#C9A46A]" />
                  <h2 className="font-serif font-semibold text-base text-white">Quarterly Tax Liability Estimator</h2>
                </div>
                
                {/* Select Creator Profile */}
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Creator Profile:</span>
                  <select
                    value={selectedCreatorHandle}
                    onChange={(e) => handleCreatorSelect(e.target.value)}
                    className="bg-[#111E33] border border-white/10 text-xs text-[#C9A46A] px-2.5 py-1 rounded-lg outline-none"
                  >
                    {taxItems.filter(t => !isAgentMgr || myHandles.includes(t.creator.toLowerCase())).map(t => (
                      <option key={t.id} value={t.creator}>{t.creator}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Annual Expected Estimations Input */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Estimated Annual Business Gross Income ($)</label>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-[#C9A46A] font-semibold font-mono">$</span>
                    <input
                      type="number"
                      value={annualIncomeInput}
                      onChange={(e) => setAnnualIncomeInput(Math.max(0, parseInt(e.target.value) || 0))}
                      className="bg-transparent text-white text-base font-bold outline-none font-mono w-full"
                    />
                  </div>
                  <span className="text-[9px] text-slate-500">Includes brand campaign, merch &amp; platform payouts.</span>
                </div>

                <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono block">Estimated Annual Business Deductible Expenses ($)</label>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-rose-400 font-semibold font-mono">$</span>
                    <input
                      type="number"
                      value={annualExpensesInput}
                      onChange={(e) => setAnnualExpensesInput(Math.max(0, parseInt(e.target.value) || 0))}
                      className="bg-transparent text-white text-base font-bold outline-none font-mono w-full"
                    />
                  </div>
                  <span className="text-[9px] text-slate-500">Gear, software, studio space, travel costs.</span>
                </div>
              </div>

              {/* Breakdown of Estimated Taxes Liability */}
              <div className="p-4 bg-[#111E33] rounded-xl border border-white/5 space-y-3.5">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 text-cyan-400" /> Projected IRS Liabilities Calculation Breakdown
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  <div className="p-2 border border-white/5 rounded-lg bg-[#0D1830]">
                    <span className="text-[9px] text-slate-400 block font-mono">NET BUSINESS PROFIT</span>
                    <span className="text-sm font-bold text-white font-mono">${profit.toLocaleString()}</span>
                  </div>
                  <div className="p-2 border border-white/5 rounded-lg bg-[#0D1830]">
                    <span className="text-[9px] text-slate-400 block font-mono">SELF-EMPLOYMENT TAX</span>
                    <span className="text-sm font-bold text-[#C9A46A] font-mono">${Math.round(selfEmploymentTax).toLocaleString()}</span>
                  </div>
                  <div className="p-2 border border-white/5 rounded-lg bg-[#0D1830]">
                    <span className="text-[9px] text-slate-400 block font-mono">EST. INCOME TAX</span>
                    <span className="text-sm font-bold text-[#C9A46A] font-mono">${Math.round(federalIncomeTax).toLocaleString()}</span>
                  </div>
                  <div className="p-2 border border-emerald-500/20 rounded-lg bg-emerald-950/20">
                    <span className="text-[9px] text-emerald-400 block font-mono">TOTAL ESTIMATED ANNUAL</span>
                    <span className="text-sm font-bold text-emerald-400 font-mono">${Math.round(totalEstimatedAnnualTax).toLocaleString()}</span>
                  </div>
                </div>

                {/* Main Estimated Quarterly Payment Due Card */}
                <div className="bg-[#16243F] border border-[#C9A46A]/20 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider block">Projected Quarterly Payment Due</span>
                    <p className="text-xs text-[#7C8AA8] mt-0.5">IRS Form 1040-ES estimated quarterly payment recommendation.</p>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-serif font-bold text-white font-mono">${Math.round(quarterlyEstimatedDue).toLocaleString()}</span>
                    <span className="text-[9px] text-slate-400 block font-mono">Due quarterly on IRS cycles</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Tax Bracket Visualizer */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
              <h3 className="font-serif font-semibold text-sm text-white">Interactive Federal Tax Bracket Visualizer (Single Filer)</h3>
              <p className="text-xs text-[#7C8AA8]">Visualizes current tax progress against progressive 2026 marginal brackets based on calculated Net Business Profit.</p>
              
              <div className="space-y-4">
                {/* Visual progressive scale bar */}
                <div className="h-6 w-full bg-slate-800 rounded-lg overflow-hidden flex relative text-[9px] text-slate-300 font-bold font-mono">
                  <div className={`h-full flex items-center justify-center transition-all ${profit > 11600 ? 'bg-sky-950 text-sky-400' : 'bg-emerald-600 text-white'}`} style={{ width: '15%' }}>
                    10% (&lt;$11k)
                  </div>
                  <div className={`h-full flex items-center justify-center transition-all border-l border-white/5 ${profit > 47150 ? 'bg-sky-900 text-sky-300' : profit > 11600 ? 'bg-emerald-600 text-white' : 'bg-[#1a2e56]'}`} style={{ width: '25%' }}>
                    12% ($11k-$47k)
                  </div>
                  <div className={`h-full flex items-center justify-center transition-all border-l border-white/5 ${profit > 100525 ? 'bg-sky-850 text-sky-200' : profit > 47150 ? 'bg-emerald-600 text-white' : 'bg-[#111e38]'}`} style={{ width: '30%' }}>
                    22% ($47k-$100k)
                  </div>
                  <div className={`h-full flex items-center justify-center transition-all border-l border-white/5 ${profit > 191950 ? 'bg-sky-800 text-sky-100' : profit > 100525 ? 'bg-emerald-600 text-white' : 'bg-[#0a1226]'}`} style={{ width: '20%' }}>
                    24% ($100k-$191k)
                  </div>
                  <div className={`h-full flex items-center justify-center transition-all border-l border-white/5 ${profit > 191950 ? 'bg-emerald-600 text-white' : 'bg-[#050918]'}`} style={{ width: '10%' }}>
                    32%+
                  </div>
                </div>

                {/* Dynamic bracket placement marker */}
                <div className="p-3 bg-[#111E33] rounded-xl border border-white/5 flex items-center justify-between">
                  <span className="text-slate-300">
                    Highest Marginal Bracket Reached: <strong>
                      {profit <= 11600 ? '10%' : profit <= 47150 ? '12%' : profit <= 100525 ? '22%' : profit <= 191950 ? '24%' : '32%'}
                    </strong>
                  </span>
                  <span className="text-[10px] text-[#C9A46A] font-mono">Current Net Profit: ${profit.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Panel: Withholding Simulator and Deadlines */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Withholding Reserve Simulator */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <h3 className="font-serif font-semibold text-sm text-white">Withholding Reserve Simulator</h3>
              <p className="text-xs text-[#7C8AA8]">Simulate pre-withholding transfers to save tax reserves directly into escrow splits.</p>
              
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] text-slate-300">
                    <span>Withholding Holdback Rate</span>
                    <span className="text-[#C9A46A] font-bold font-mono">{withholdingRate}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="40"
                    step="5"
                    value={withholdingRate}
                    onChange={(e) => setWithholdingRate(parseInt(e.target.value))}
                    className="w-full accent-[#C9A46A] bg-[#111E33] h-1.5 rounded-lg outline-none cursor-pointer"
                  />
                  <div className="flex justify-between text-[9px] text-slate-500">
                    <span>10% (Low)</span>
                    <span>25% (Standard)</span>
                    <span>40% (Conservative)</span>
                  </div>
                </div>

                <div className="bg-[#111E33] p-3.5 border border-white/5 rounded-xl space-y-2">
                  <span className="text-[10px] text-[#C9A46A] uppercase font-mono font-bold block">Configured Tax Holdback Reserve Settings</span>
                  <div className="flex justify-between font-mono text-sm font-bold text-white">
                    <span>Annual Reserve Target:</span>
                    <span className="text-emerald-400">${Math.round(recommendedReserve).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-mono text-[10px] text-slate-400 border-t border-white/5 pt-1.5">
                    <span>Reserve per $1k Deal payout:</span>
                    <span>${withholdingRate * 10}</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleApplyWithholding}
                  className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-2.5 rounded-xl font-bold transition-all text-xs cursor-pointer shadow-md"
                >
                  Save &amp; Apply Tax Holdback Reserve ({withholdingRate}%)
                </button>
              </div>
            </div>

            {/* Quarterly Due Dates Checklist */}
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
              <h3 className="font-serif font-semibold text-sm text-white">Estimated Payment Deadlines (2026 Cycle)</h3>
              
              <div className="space-y-3">
                {deadlines.map(dl => (
                  <div key={dl.id} className="p-3 bg-[#111E33] rounded-xl border border-white/5 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-white block">{dl.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono mt-0.5">{dl.due}</span>
                    </div>
                    <div>
                      {dl.status === 'Paid to IRS' ? (
                        <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/20 text-[9px] font-bold px-2 py-0.5 rounded">
                          ✓ Paid
                        </span>
                      ) : dl.status === 'Pending Payment' ? (
                        <button
                          onClick={() => {
                            setDeadlines(prev => prev.map(x => x.id === dl.id ? { ...x, status: 'Paid to IRS' } : x));
                            triggerNotification('Quarterly Tax Marked Paid', `Projected payment marked as settled with IRS IRS Direct Pay.`, 'success');
                            onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Settled quarterly payment for ${dl.title}`);
                          }}
                          className="bg-amber-950 hover:bg-amber-900 border border-amber-500/30 text-amber-300 text-[9px] font-bold px-2.5 py-1 rounded"
                        >
                          Mark Paid
                        </button>
                      ) : (
                        <span className="bg-[#16243F] text-slate-400 border border-white/5 text-[9px] font-bold px-2 py-0.5 rounded">
                          Upcoming
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : activeTab === 'templates-and-signing' ? (
        /* Form Templates Repository & Electronic Signatures Ledger */
        <div className="space-y-6 animate-fade-in">
          {/* Action Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0D1830] border border-white/5 rounded-2xl p-5">
            <div>
              <h3 className="text-base font-serif font-bold text-white">
                Official IRS Form &amp; Agency Contract Repository
              </h3>
              <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
                Official IRS Tax Forms (W-9, 1099-NEC) and Bloom Studio standard representation agreements. Download official printable IRS PDFs, fill and sign interactively on screen, or send forms directly to creator rosters.
              </p>
            </div>
            {!isRestrictedRole && (
              <button
                onClick={() => setShowUploadModal(true)}
                className="bg-[#C9A46A] hover:bg-[#b8935a] text-[#0B1424] font-bold px-4 py-2.5 rounded-xl transition-all shadow-lg text-xs flex items-center gap-1.5 shrink-0"
              >
                <Upload className="w-4 h-4" /> + Upload Official IRS Form / PDF
              </button>
            )}
          </div>

          {/* IRS Official Download Banner */}
          <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-amber-300">IRS.gov Official Forms &amp; PDF Converter Ready</h4>
                <p className="text-[11px] text-amber-200/80 mt-0.5 leading-relaxed">
                  Download real fillable Form W-9 and Form 1099-NEC directly from the IRS website, or upload your agency documents to convert to e-signable PDFs.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <a
                href="https://www.irs.gov/pub/irs-pdf/fw9.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#111E33] hover:bg-[#16243F] border border-amber-500/30 text-amber-300 text-xs font-bold px-3 py-1.5 rounded-xl inline-flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" /> IRS Form W-9
              </a>
              <a
                href="https://www.irs.gov/pub/irs-pdf/f1099nec.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#111E33] hover:bg-[#16243F] border border-amber-500/30 text-amber-300 text-xs font-bold px-3 py-1.5 rounded-xl inline-flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" /> IRS Form 1099-NEC
              </a>
            </div>
          </div>

          {/* Templates Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map(tmpl => (
              <div
                key={tmpl.id}
                className="bg-[#0D1830] border border-white/5 hover:border-[#C9A46A]/30 rounded-2xl p-5 space-y-4 transition-all flex flex-col justify-between shadow-md"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase border ${
                      tmpl.category === 'tax' ? 'bg-amber-500/10 text-amber-300 border-amber-500/30' :
                      tmpl.category === 'mcn' ? 'bg-purple-500/10 text-purple-300 border-purple-500/30' :
                      'bg-blue-500/10 text-blue-300 border-blue-500/30'
                    }`}>
                      {tmpl.category === 'tax' ? 'IRS TAX FORM' : tmpl.category === 'mcn' ? 'SUB-AGENCY MCN' : 'LEGAL AGREEMENT'}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500 font-mono">
                        Updated {tmpl.updatedAt}
                      </span>
                      <button
                        onClick={() => handleDeleteTemplate(tmpl.id)}
                        className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-rose-950/40 transition-colors"
                        title="Delete Template"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <h4 className="text-base font-bold text-white">{tmpl.name}</h4>
                  <p className="text-xs text-[#7C8AA8] leading-relaxed line-clamp-2">
                    {tmpl.description}
                  </p>
                  <div className="text-[11px] text-slate-400 font-mono flex items-center gap-2">
                    <span>File: <strong className="text-slate-300">{tmpl.fileName}</strong></span>
                    <span>•</span>
                    <span>{tmpl.fileSize}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch gap-2 pt-3 border-t border-white/5">
                  <button
                    onClick={() => handleDownloadOfficialForm(tmpl)}
                    className="flex-1 bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-xs text-slate-300 hover:text-white px-3 py-2 rounded-xl font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-[#C9A46A]" /> Download Official PDF
                  </button>
                  <button
                    onClick={() => {
                      setSelectedTemplateForSign(tmpl);
                      setSigningModalOpen(true);
                    }}
                    className="flex-1 bg-[#C9A46A] hover:bg-[#b8935a] text-[#0B1424] text-xs px-3 py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all shadow-md"
                  >
                    <PenTool className="w-3.5 h-3.5" /> Open Fillable Sheet
                  </button>
                  <button
                    onClick={() => {
                      setSelectedTemplateForSend(tmpl);
                      setSelectedCreatorHandlesForSend(myCreators.map(c => c.handle));
                      setSendModalOpen(true);
                    }}
                    className="flex-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/30 text-emerald-300 text-xs px-3 py-2 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" /> Send to Creators
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Executed & Returned Documents Ledger ("something they can sign and come back to me") */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div>
                <h3 className="text-sm font-serif font-bold text-white flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-emerald-400" />
                  Returned &amp; Executed Documents Ledger (Agency Vault)
                </h3>
                <p className="text-xs text-[#7C8AA8] mt-0.5">
                  All electronic W-9 forms, tax certifications, and talent representation agreements signed by creators and returned to Agency Lead.
                </p>
              </div>
              <div className="flex items-center gap-2">
                {returnedDocuments.length > 0 && !isRestrictedRole && (
                  <button
                    onClick={handleClearAllReturnedDocs}
                    className="bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-500/30 px-3 py-1 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear Ledger
                  </button>
                )}
                <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full font-bold">
                  {returnedDocuments.length} EXECUTED RECORD{returnedDocuments.length !== 1 ? 'S' : ''}
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                    <th className="p-3.5">Creator / Signer</th>
                    <th className="p-3.5">Document Executed</th>
                    <th className="p-3.5">Tax Classification / ID</th>
                    <th className="p-3.5">E-SIGN Timestamp &amp; Hash</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {returnedDocuments.map(doc => (
                    <tr key={doc.id} className="hover:bg-[#111E33]/40 transition-colors">
                      <td className="p-3.5">
                        <div className="font-bold text-white">{doc.creatorName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{doc.creatorHandle}</div>
                      </td>
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-200">{doc.templateName}</div>
                        <div className="text-[10px] text-[#C9A46A] font-serif italic mt-0.5">Signed by: {doc.signatureName}</div>
                      </td>
                      <td className="p-3.5 font-mono text-slate-300">
                        <div>{doc.taxClassification}</div>
                        <div className="text-[10px] text-slate-400">
                          {isRestrictedRole ? '••••••••' : doc.taxId}
                        </div>
                      </td>
                      <td className="p-3.5 font-mono">
                        <div className="text-slate-300">{doc.signedAt}</div>
                        <div className="text-[10px] text-slate-500 truncate max-w-[140px]" title={doc.auditHash}>{doc.auditHash}</div>
                      </td>
                      <td className="p-3.5">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                          doc.status === 'Agency Verified'
                            ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400'
                            : 'bg-blue-950/40 border-blue-500/30 text-blue-300'
                        }`}>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {doc.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right space-x-2">
                        <div className="inline-flex items-center justify-end gap-2 flex-wrap">
                          {doc.status.includes('Pending') && (
                            <button
                              onClick={() => {
                                const matchingTmpl = templates.find(t => t.id === doc.templateId) || templates[0];
                                setSelectedTemplateForSign(matchingTmpl);
                                setSignForm(prev => ({
                                  ...prev,
                                  legalName: doc.creatorName,
                                  accountNumbers: doc.creatorHandle
                                }));
                                setSigningModalOpen(true);
                              }}
                              className="bg-[#C9A46A] hover:bg-[#b8935a] text-[#0A1220] text-xs px-2.5 py-1 rounded-lg font-bold inline-flex items-center gap-1 shadow-sm"
                            >
                              <PenTool className="w-3 h-3" /> Fill &amp; Sign Form W-9
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setDocViewerFiles([
                                {
                                  name: doc.completedPdfName || `${doc.creatorName}_W9_Signed.pdf`,
                                  url: doc.completedPdfUrl,
                                  category: 'Executed Tax Compliance',
                                  description: `Official executed Form W-9 for ${doc.creatorName} (${doc.creatorHandle}). Audit Hash: ${doc.auditHash}`
                                }
                              ]);
                              setDocViewerTitle(`Document Inspection — ${doc.creatorName}`);
                              setDocViewerOpen(true);
                            }}
                            className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-slate-200 text-xs px-2.5 py-1 rounded-lg font-semibold inline-flex items-center gap-1 cursor-pointer"
                            title="Preview PDF Document"
                          >
                            <Eye className="w-3 h-3 text-[#C9A46A]" /> View PDF
                          </button>
                          <button
                            onClick={() => {
                              openOfficialW9FillablePdf(doc.completedPdfUrl, doc.completedPdfName || `Executed_W9_${doc.creatorName.replace(/\s+/g, '_')}.pdf`);
                              onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Downloaded signed W-9 PDF: ${doc.templateName} (${doc.creatorName})`);
                            }}
                            className="bg-[#111E33] hover:bg-[#16243F] border border-[#C9A46A]/40 text-[#C9A46A] text-xs px-2.5 py-1 rounded-lg font-semibold inline-flex items-center gap-1"
                            title="Export official printable IRS Form W-9 PDF sheet"
                          >
                            <Download className="w-3 h-3" /> {doc.completedPdfName ? 'Attached W-9 PDF' : 'Signed W-9 PDF'}
                          </button>
                          <button
                            onClick={() => {
                              triggerNotification('Executed PDF Downloaded', `Downloaded signed ${doc.templateName} with electronic signature certificate for ${doc.creatorName}.`, 'success');
                              onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Downloaded executed document certificate: ${doc.templateName}`);
                            }}
                            className="bg-[#111E33] hover:bg-[#16243F] border border-white/10 text-slate-300 text-xs px-2.5 py-1 rounded-lg font-semibold inline-flex items-center gap-1"
                          >
                            <Download className="w-3 h-3" /> Certificate
                          </button>
                          {doc.status !== 'Agency Verified' && !isRestrictedRole && (
                            <button
                              onClick={() => handleVerifyReturnedDoc(doc.id)}
                              className="bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/30 text-emerald-300 text-xs px-2.5 py-1 rounded-lg font-bold inline-flex items-center gap-1"
                            >
                              <UserCheck className="w-3 h-3" /> Counter-Sign &amp; Verify
                            </button>
                          )}
                          {!isRestrictedRole && (
                            <button
                              onClick={() => handleDeleteReturnedDoc(doc.id)}
                              className="text-slate-400 hover:text-rose-400 p-1.5 rounded-lg hover:bg-rose-950/40 transition-colors"
                              title="Delete Executed Document Record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Send Official Form to Creator Roster Modal */}
          {sendModalOpen && selectedTemplateForSend && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
              <div className="bg-[#0B1424] border border-[#C9A46A]/40 rounded-2xl w-full max-w-lg p-6 space-y-5 shadow-2xl max-h-[90vh] flex flex-col">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <Send className="w-5 h-5 text-[#C9A46A]" />
                    <div>
                      <h3 className="text-base font-serif font-bold text-white">Send Form to Creator Roster</h3>
                      <p className="text-[10px] text-slate-400">{selectedTemplateForSend.name}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setSendModalOpen(false)}
                    className="text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleSendFormToCreators} className="space-y-4 overflow-y-auto flex-1">
                  <div className="bg-[#111E33] border border-white/5 rounded-xl p-3.5 space-y-1">
                    <div className="flex items-center justify-between text-xs font-semibold text-white">
                      <span>Select Roster Creators ({selectedCreatorHandlesForSend.length})</span>
                      <button
                        type="button"
                        onClick={() => {
                          if (selectedCreatorHandlesForSend.length === myCreators.length) {
                            setSelectedCreatorHandlesForSend([]);
                          } else {
                            setSelectedCreatorHandlesForSend(myCreators.map(c => c.handle));
                          }
                        }}
                        className="text-[10px] text-[#C9A46A] hover:underline font-mono uppercase"
                      >
                        {selectedCreatorHandlesForSend.length === myCreators.length ? 'Deselect All' : 'Select All Roster'}
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-400">
                      An interactive completion link will be sent to their Creator Portal &amp; email.
                    </p>
                  </div>

                  <div className="max-h-48 overflow-y-auto space-y-1.5 border border-white/5 rounded-xl p-2 bg-[#0D1830]">
                    {myCreators.map(creator => {
                      const isSelected = selectedCreatorHandlesForSend.includes(creator.handle);
                      return (
                        <label
                          key={creator.id}
                          className={`flex items-center justify-between p-2.5 rounded-lg cursor-pointer transition-colors ${
                            isSelected ? 'bg-[#16243F] border border-[#C9A46A]/30' : 'hover:bg-white/5'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedCreatorHandlesForSend(prev => [...prev, creator.handle]);
                                } else {
                                  setSelectedCreatorHandlesForSend(prev => prev.filter(h => h !== creator.handle));
                                }
                              }}
                              className="rounded border-white/20 text-[#C9A46A] focus:ring-[#C9A46A] bg-[#0A1220]"
                            />
                            <div>
                              <span className="text-xs font-bold text-white block">{creator.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono">{creator.handle}</span>
                            </div>
                          </div>
                          <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded">
                            {creator.handle.replace('@', '')}@bloomstudio.com
                          </span>
                        </label>
                      );
                    })}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Custom Note / Completion Instructions</label>
                    <textarea
                      rows={2}
                      value={sendCustomNote}
                      onChange={(e) => setSendCustomNote(e.target.value)}
                      placeholder="e.g., Please review, complete, and electronically sign your IRS Form W-9 by Friday."
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-[11px] text-amber-300 flex items-center gap-2">
                    <Info className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>Selected creators will receive an immediate high-priority alert to fill out and electronically sign this paper form.</span>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-2 border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => setSendModalOpen(false)}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={selectedCreatorHandlesForSend.length === 0}
                      className="bg-[#C9A46A] hover:bg-[#b8935a] disabled:opacity-50 text-[#0B1424] font-bold px-5 py-2.5 rounded-xl transition-all shadow-md text-xs flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" /> Send Form to {selectedCreatorHandlesForSend.length} Creator(s)
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Upload Official IRS Form / PDF Modal */}
          {showUploadModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
              <div className="bg-[#0B1424] border border-[#C9A46A]/40 rounded-2xl w-full max-w-lg p-6 space-y-5 shadow-2xl">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2">
                    <Upload className="w-5 h-5 text-[#C9A46A]" />
                    <h3 className="text-base font-serif font-bold text-white">Upload Official IRS Form / Agreement</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowUploadModal(false)}
                    className="text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={handleUploadOfficialPdfForm} className="space-y-4">
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-xs text-amber-300">
                    <p className="font-semibold mb-0.5">IRS &amp; Legal Document Notice:</p>
                    <p className="text-[11px] text-amber-200 leading-relaxed">
                      You can upload official PDF forms downloaded from IRS.gov (e.g. Form W-9, Form 1099-NEC) or Bloom Studio contracts. Uploaded documents will be stored in your repository for creator e-signature.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Document / Form Title *</label>
                    <input
                      type="text"
                      required
                      value={uploadForm.name}
                      onChange={(e) => setUploadForm({ ...uploadForm, name: e.target.value })}
                      placeholder="e.g., IRS Form W-9 (2026 Official PDF) or Custom Agency Contract"
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Document Category *</label>
                    <select
                      value={uploadForm.category}
                      onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value as any })}
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                    >
                      <option value="tax">IRS Tax Form (W-9 / Form 1099-NEC)</option>
                      <option value="agreement">Talent Representation Agreement / Contract</option>
                      <option value="mcn">Sub-Agency MCN Affiliate Agreement</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Select Official File (PDF / Word) *</label>
                    <div className="border-2 border-dashed border-white/20 hover:border-[#C9A46A]/50 rounded-xl p-4 text-center cursor-pointer bg-[#0D1830] transition-colors">
                      <input
                        type="file"
                        required
                        accept=".pdf,.docx,.doc"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = () => {
                              setUploadForm({
                                ...uploadForm,
                                fileName: file.name,
                                fileDataUrl: typeof reader.result === 'string' ? reader.result : ''
                              });
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                        className="w-full text-xs text-slate-300 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-[#C9A46A] file:text-[#0A1220] hover:file:bg-[#b8935a]"
                      />
                      <p className="text-[10px] text-slate-500 mt-2">Supports official fillable PDF forms from IRS.gov or custom agency DOCX/PDF contracts</p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Description / Completion Instructions</label>
                    <textarea
                      rows={2}
                      value={uploadForm.description}
                      onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                      placeholder="e.g., Official IRS W-9 form downloaded from irs.gov. Please review and execute electronically."
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-2 border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => setShowUploadModal(false)}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={!uploadForm.name || !uploadForm.fileName}
                      className="bg-[#C9A46A] hover:bg-[#b8935a] disabled:opacity-50 text-[#0B1424] font-bold px-5 py-2.5 rounded-xl transition-all shadow-md text-xs flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5" /> Save Official Form to Repository
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Interactive Full-Page Fillable Paper Sheet Modal ("Fill Out & Sign Online") */}
          {signingModalOpen && selectedTemplateForSign && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
              <div className="bg-white text-slate-900 border border-slate-300 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
                {/* Official Paper Header */}
                <div className="p-5 bg-slate-100 border-b border-slate-300 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#0D1830] text-[#C9A46A] rounded-xl flex items-center justify-center font-serif font-bold text-lg shadow">
                      {selectedTemplateForSign.category === 'tax' ? 'IRS' : 'B&C'}
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-600 font-mono font-bold uppercase tracking-wider block">
                        {selectedTemplateForSign.category === 'tax' ? 'DEPARTMENT OF THE TREASURY — INTERNAL REVENUE SERVICE' : 'BLOOM STUDIO LEGAL & TAX COMPLIANCE'}
                      </span>
                      <h3 className="text-base font-serif font-bold text-slate-900">
                        {selectedTemplateForSign.name}
                      </h3>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap justify-end">
                    {selectedTemplateForSign.category === 'tax' && (
                      <button
                        type="button"
                        onClick={() => generateW9PrintablePdf({
                          legalName: signForm.legalName || 'Creator Name',
                          businessName: signForm.businessName,
                          taxClassification: signForm.taxClassification,
                          taxIdType: signForm.taxIdType,
                          taxId: signForm.taxId || 'XXX-XX-XXXX',
                          address: signForm.address || '100 Grand Ave, Suite 400',
                          cityStateZip: signForm.cityStateZip || 'Los Angeles, CA 90071',
                          accountNumbers: signForm.accountNumbers || currentUser?.handle || '@creator',
                          signatureName: signForm.signatureText || signForm.legalName || 'Pending Signature',
                          signedAt: new Date().toLocaleDateString(),
                          auditHash: `STAGED_DRAFT_${(signForm.legalName || 'ANON').replace(/\s+/g, '_').toUpperCase()}`
                        })}
                        className="bg-[#111E33] hover:bg-[#16243F] border border-[#C9A46A]/40 text-[#C9A46A] font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors"
                      >
                        <Download className="w-3.5 h-3.5 text-[#C9A46A]" /> Download Signed W-9 PDF
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDownloadOfficialForm(selectedTemplateForSign)}
                      className="bg-amber-100 hover:bg-amber-200 border border-amber-300 text-amber-900 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-700" /> View Official IRS PDF
                    </button>
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-colors"
                    >
                      <Printer className="w-3.5 h-3.5 text-slate-600" /> Print / Save Paper PDF
                    </button>
                    <button
                      onClick={() => {
                        setSigningModalOpen(false);
                        setSelectedTemplateForSign(null);
                      }}
                      className="text-slate-400 hover:text-slate-700 p-1"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <form onSubmit={handleSignAndReturn} className="p-6 sm:p-8 space-y-6 overflow-y-auto flex-1 bg-white">
                  {/* Paper Form Banner Instructions */}
                  {selectedTemplateForSign.category !== 'tax' && (
                    <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200 text-xs text-slate-700">
                      <p className="font-bold text-slate-900 mb-0.5">Document Description:</p>
                      <p className="text-slate-600 leading-relaxed">{selectedTemplateForSign.description}</p>
                    </div>
                  )}

                  {/* Form Fields Section */}
                  <div className="space-y-4 border border-slate-300 rounded-xl p-5 bg-white shadow-sm">
                    {selectedTemplateForSign.category === 'tax' ? (
                      <div className="space-y-6">
                        {/* IRS Form W-9 Official Title Header */}
                        <div className="border-2 border-slate-900 rounded-xl p-4 bg-slate-100 flex flex-col md:flex-row items-center justify-between gap-4">
                          <div className="text-center md:text-left">
                            <span className="text-lg font-serif font-bold text-slate-900 block">Form W-9</span>
                            <span className="text-[10px] text-slate-600 font-mono">(Rev. March 2024)</span>
                            <span className="text-[9px] text-slate-500 block uppercase tracking-wider mt-0.5">Department of the Treasury — Internal Revenue Service</span>
                          </div>
                          <div className="text-center md:flex-1 md:px-4">
                            <h4 className="text-sm font-serif font-bold text-slate-900 leading-tight">
                              Request for Taxpayer Identification Number and Certification
                            </h4>
                            <p className="text-[10px] text-slate-600 mt-1">
                              Go to www.irs.gov/FormW9 for instructions and the latest information.
                            </p>
                          </div>
                          <div className="bg-slate-900 text-white text-[10px] font-bold px-3 py-2 rounded-lg text-center max-w-[170px] uppercase tracking-wide">
                            Give Form to the requester. Do not send to the IRS.
                          </div>
                        </div>

                        {/* Step 1: Real Fillable IRS W-9 Launcher */}
                        <div className="border-2 border-slate-900 rounded-2xl p-6 bg-slate-50 space-y-4">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded-full">
                                Step 1 • Real Official IRS Document
                              </span>
                              <h5 className="text-base font-serif font-bold text-slate-900 mt-2">
                                Official IRS Form W-9 (Rev. March 2024)
                              </h5>
                              <p className="text-xs text-slate-600 leading-relaxed mt-1">
                                Click below to open the official fillable IRS Form W-9 PDF directly from IRS.gov. Complete your legal name, tax classification, address, and TIN (SSN or EIN) in your PDF viewer, save the completed document, then attach and turn it in using Step 2 below.
                              </p>
                            </div>
                          </div>
                          <div className="flex flex-wrap items-center gap-3">
                            <button
                              type="button"
                              onClick={() => {
                                generateOfficialW9Pdf({
                                  legalName: currentUser?.name || creators?.[0]?.name || 'Creator Legal Name',
                                  address: '100 Grand Ave, Suite 400',
                                  cityStateZip: 'Los Angeles, CA 90071',
                                  tinType: 'SSN',
                                  tinNumber: 'XXX-XX-4819',
                                  signatureName: currentUser?.name || 'Creator Authorized Signature',
                                  accountNumbers: currentUser?.handle || '@creator'
                                }, { download: true });
                                triggerNotification('Official IRS Form W-9 Generated', 'Generated and downloaded official IRS Form W-9 (Rev. March 2024) PDF.', 'success');
                              }}
                              className="inline-flex items-center justify-center gap-2.5 px-5 py-3 rounded-xl bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs shadow-md transition-all cursor-pointer"
                            >
                              <FileText className="w-4 h-4" />
                              1. Download Official IRS Form W-9 (PDF)
                            </button>
                          </div>
                        </div>

                        {/* Step 2: Attach Executed IRS W-9 PDF & Confirm Legal Name */}
                        <div className="border border-slate-300 rounded-2xl p-6 bg-white space-y-4">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-700 bg-slate-100 border border-slate-300 px-2.5 py-1 rounded-full">
                            Step 2 • Attach Executed PDF &amp; Confirm
                          </span>
                          <h5 className="text-base font-serif font-bold text-slate-900">
                            Attach Executed IRS Form W-9 PDF &amp; Record
                          </h5>
                          <p className="text-xs text-slate-600">
                            Upload the official Form W-9 PDF you saved in Step 1 to attach it to your creator tax file.
                          </p>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                            <div>
                              <label className="block text-xs font-bold text-slate-800 mb-1">
                                Creator Legal Name (as shown on Form W-9) *
                              </label>
                              <input
                                type="text"
                                required
                                value={signForm.legalName}
                                onChange={(e) => setSignForm({ ...signForm, legalName: e.target.value })}
                                placeholder="Enter Full Legal Name"
                                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-medium focus:outline-none focus:border-slate-800 focus:bg-white"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-800 mb-1">
                                Attach Executed IRS Form W-9 PDF *
                              </label>
                              <label className="flex items-center justify-center gap-2 w-full border-2 border-dashed border-slate-300 hover:border-slate-800 rounded-xl px-4 py-2 text-xs font-semibold text-slate-700 cursor-pointer bg-slate-50 hover:bg-slate-100 transition-colors">
                                <FileText className="w-4 h-4 text-slate-600" />
                                {signForm.completedPdfName || 'Choose W-9 PDF File...'}
                                <input
                                  type="file"
                                  accept=".pdf,.html,.doc,.docx"
                                  className="hidden"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (!file) return;
                                    const reader = new FileReader();
                                    reader.onload = () => {
                                      setSignForm(prev => ({
                                        ...prev,
                                        completedPdfName: file.name,
                                        completedPdfUrl: typeof reader.result === 'string' ? reader.result : ''
                                      }));
                                      triggerNotification('W-9 PDF Attached', `Attached ${file.name} to tax filing record.`, 'success');
                                    };
                                    reader.readAsDataURL(file);
                                  }}
                                />
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="border-b border-slate-200 pb-2 flex items-center justify-between">
                          <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500">
                            Part I: Agency &amp; Creator Representation Parties
                          </h4>
                          <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 border border-emerald-300 px-2 py-0.5 rounded font-bold">
                            NO PERSONAL SSN / TAX ID REQUIRED FOR CONTRACT SIGNING
                          </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-800 mb-1">
                              1. Creator / Entity Name (Full Legal Name) *
                            </label>
                            <input
                              type="text"
                              required
                              value={signForm.legalName}
                              onChange={(e) => setSignForm({ ...signForm, legalName: e.target.value })}
                              placeholder="Full Legal Name or LLC Entity"
                              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-medium focus:outline-none focus:border-slate-800 focus:bg-white"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-800 mb-1">
                              2. Creator Roster Handle / ID *
                            </label>
                            <input
                              type="text"
                              required
                              value={signForm.taxId}
                              onChange={(e) => setSignForm({ ...signForm, taxId: e.target.value })}
                              placeholder="@creator_handle or Roster ID"
                              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-mono focus:outline-none focus:border-slate-800 focus:bg-white"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-800 mb-1">
                              3. Authorized Signatory Title / Role *
                            </label>
                            <input
                              type="text"
                              required
                              value={signForm.address}
                              onChange={(e) => setSignForm({ ...signForm, address: e.target.value })}
                              placeholder="e.g., Creator / Principal or Managing Member"
                              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-medium focus:outline-none focus:border-slate-800 focus:bg-white"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-800 mb-1">
                              4. Effective Date of Agreement *
                            </label>
                            <input
                              type="date"
                              required
                              value={new Date().toISOString().split('T')[0]}
                              readOnly
                              className="w-full bg-slate-100 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-600 font-mono"
                            />
                          </div>
                        </div>

                        {/* Real Contract Clauses Box */}
                        <div className="mt-4 border border-slate-200 bg-slate-50 rounded-xl p-4 space-y-3 max-h-56 overflow-y-auto text-xs text-slate-700 font-serif leading-relaxed">
                          <div>
                            <h5 className="font-bold text-slate-900 font-sans uppercase text-[11px] mb-1">
                              SECTION 1: EXCLUSIVE REPRESENTATION &amp; MANAGED ROSTER RIGHTS
                            </h5>
                            <p>
                              Creator hereby appoints Bloom Studio Agency as their exclusive talent representative and manager for all sponsored content, brand partnerships, and commercial endorsements across social media platforms.
                            </p>
                          </div>
                          <div>
                            <h5 className="font-bold text-slate-900 font-sans uppercase text-[11px] mb-1">
                              SECTION 2: ESCROW REVENUE SPLIT &amp; STRIPE CONNECT LEDGER
                            </h5>
                            <p>
                              Agency commission splits shall be calculated and disbursed automatically via Bloom Studio&apos;s verified Stripe Connect escrow ledger according to the creator&apos;s contracted tier. Gross remittances shall be routed through agency escrow before net distribution.
                            </p>
                          </div>
                          <div>
                            <h5 className="font-bold text-slate-900 font-sans uppercase text-[11px] mb-1">
                              SECTION 3: FTC COMPLIANCE &amp; ENDORSEMENT DISCLOSURE RULES
                            </h5>
                            <p>
                              Creator covenants to adhere strictly to Federal Trade Commission (FTC) Endorsement Guides (#ad, #sponsored) and Bloom Studio Brand Safety Guidelines.
                            </p>
                          </div>
                          <div>
                            <h5 className="font-bold text-slate-900 font-sans uppercase text-[11px] mb-1">
                              SECTION 4: TERM, TERMINATION &amp; E-SIGNATURE VALIDITY
                            </h5>
                            <p>
                              This Agreement shall remain in full force for a term of 12 months, renewing automatically unless terminated with 30 days written notice. Execution via electronic signature holds full binding legal force under U.S. E-SIGN Act standards.
                            </p>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Signature Pad on White Paper */}
                  <div className="border border-slate-300 rounded-xl p-5 space-y-4 bg-slate-50 shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div>
                        <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-500">
                          Part II: Electronic Certification &amp; E-SIGN Signature Block
                        </h4>
                      </div>
                      <div className="flex bg-slate-200 rounded-lg p-0.5 border border-slate-300 text-xs">
                        <button
                          type="button"
                          onClick={() => setSignForm({ ...signForm, signatureMode: 'type' })}
                          className={`px-2.5 py-1 rounded-md transition-all font-semibold ${
                            signForm.signatureMode === 'type' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                          }`}
                        >
                          Type Name
                        </button>
                        <button
                          type="button"
                          onClick={() => setSignForm({ ...signForm, signatureMode: 'draw' })}
                          className={`px-2.5 py-1 rounded-md transition-all font-semibold ${
                            signForm.signatureMode === 'draw' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
                          }`}
                        >
                          Digital Pen
                        </button>
                      </div>
                    </div>

                    {signForm.signatureMode === 'type' ? (
                      <div>
                        <input
                          type="text"
                          required
                          value={signForm.signatureText}
                          onChange={(e) => setSignForm({ ...signForm, signatureText: e.target.value })}
                          placeholder="Type full legal name as authorized electronic signature"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 font-semibold focus:outline-none focus:border-slate-800"
                        />
                        {signForm.signatureText.trim() && (
                          <div className="mt-2 p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between shadow-inner">
                            <div>
                              <span className="text-[10px] text-slate-500 uppercase block font-mono">Executed Electronic Signature</span>
                              <span className="font-serif italic text-2xl text-slate-900 tracking-wider">
                                {signForm.signatureText.trim()}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded">
                              ELECTRONIC SIGNATURE CAPTURED
                            </span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="border-2 border-dashed border-slate-400 rounded-xl p-6 text-center bg-white">
                        <p className="text-xs text-slate-500">Digital Pen Active — Signature captured via touch/mouse input</p>
                        <div className="font-serif italic text-2xl text-slate-900 my-3">
                          {signForm.signatureText.trim() || 'Signature Recorded Electronically'}
                        </div>
                        <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded">
                          DIGITAL PEN INPUT RECORDED
                        </span>
                      </div>
                    )}
                  </div>

                  <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-800 pt-1">
                    <input
                      type="checkbox"
                      required
                      checked={signForm.perjuryCert}
                      onChange={(e) => setSignForm({ ...signForm, perjuryCert: e.target.checked })}
                      className="mt-0.5 rounded border-slate-300 text-slate-900 focus:ring-slate-900 bg-white"
                    />
                    <span className="leading-relaxed">
                      {selectedTemplateForSign.category === 'tax' ? (
                        <>
                          <strong>Under penalties of perjury</strong>, I certify that the Taxpayer Identification Number and legal information provided above is correct, I am a U.S. citizen or U.S. resident alien, and I electronically sign and execute this document for return to Bloom Studio Agency Lead.
                        </>
                      ) : (
                        <>
                          <strong>Legally Binding Covenant</strong>: I certify that I have read, understand, and agree to be legally bound by all terms, commission splits, FTC endorsement requirements, and escrow covenants of this Bloom Studio Agency Representation Agreement.
                        </>
                      )}
                    </span>
                  </label>

                  {/* Explicit E-SIGN Act Electronic Record & Signature Consent Checkbox */}
                  <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-800 pt-1">
                    <input
                      type="checkbox"
                      required
                      checked={signForm.esignConsent}
                      onChange={(e) => setSignForm({ ...signForm, esignConsent: e.target.checked })}
                      className="mt-0.5 rounded border-slate-300 text-slate-900 focus:ring-slate-900 bg-white"
                    />
                    <span className="leading-relaxed">
                      <strong>E-SIGN Act Electronic Record Consent</strong>: I affirmatively consent to conduct transactions electronically, acknowledge that my typed legal name constitutes an authorized electronic signature under applicable U.S. federal &amp; state laws, and confirm I am able to access and retain this executed electronic record.
                    </span>
                  </label>

                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                    <button
                      type="button"
                      onClick={() => {
                        setSigningModalOpen(false);
                        setSelectedTemplateForSign(null);
                      }}
                      className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-colors"
                    >
                      <Printer className="w-4 h-4 text-slate-600" /> Print / Save PDF
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting || !signForm.legalName || !signForm.signatureText || !signForm.perjuryCert || !signForm.esignConsent}
                      className="bg-[#0D1830] hover:bg-[#111E33] disabled:opacity-50 text-[#C9A46A] font-bold px-6 py-2.5 rounded-xl transition-all shadow-lg text-xs flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin text-[#C9A46A]" /> : <UserCheck className="w-4 h-4" />}
                      {isSubmitting ? 'Verifying E-Signature...' : 'Sign & Return to Agency Vault'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      ) : null}

      {/* ========================================================================= */}
      {/* ⚡ DEDICATED GENERATE 1099-NEC MODAL                                     */}
      {/* ========================================================================= */}
      {generate1099ModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in overflow-y-auto">
          <div className="bg-[#0B1528] border border-[#C9A46A]/30 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-6">
            <div className="p-6 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#111E33] to-[#0B1528]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#C9A46A]/15 border border-[#C9A46A]/30 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-[#C9A46A]" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-lg text-white">
                    Generate Official IRS Form 1099-NEC
                  </h3>
                  <p className="text-xs text-[#7C8AA8]">
                    Generate official Copy A / Copy B for nonemployee compensation
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setGenerate1099ModalOpen(false)}
                className="text-[#7C8AA8] hover:text-white p-2 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteGenerate1099} className="p-6 overflow-y-auto space-y-5 text-xs">
              {/* Creator Selection */}
              <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-3">
                <label className="block text-[11px] font-bold text-[#C9A46A] uppercase tracking-wider">
                  1. Select Talent / Independent Creator
                </label>
                <select
                  value={generate1099Data.creatorHandle}
                  onChange={(e) => {
                    const handle = e.target.value;
                    const c = creators.find(cr => cr.handle === handle);
                    const t = taxItems.find(ti => ti.creator === handle);
                    setGenerate1099Data(prev => ({
                      ...prev,
                      creatorHandle: handle,
                      recipientName: t?.realName || c?.name || 'Creator Legal Name',
                      nonemployeeCompensation: t?.earnings1099 || Number((c as any)?.earnings || 12500)
                    }));
                  }}
                  className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-3 text-white text-xs font-semibold focus:border-[#C9A46A] focus:outline-none"
                >
                  {creators.map(c => (
                    <option key={c.id || c.handle} value={c.handle}>
                      {c.name} ({c.handle}) — {c.niche || 'Creator'}
                    </option>
                  ))}
                </select>
              </div>

              {/* Box 1 & Tax Year Highlight */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-[#111E33] border border-[#C9A46A]/20 rounded-xl p-4 space-y-1.5">
                  <label className="block text-[10px] font-bold text-[#C9A46A] uppercase tracking-wider">
                    Box 1: Nonemployee Compensation ($)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-[#C9A46A] font-bold">$</span>
                    <input
                      type="number"
                      required
                      min="0"
                      step="1"
                      value={generate1099Data.nonemployeeCompensation}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, nonemployeeCompensation: parseFloat(e.target.value) || 0 }))}
                      className="w-full bg-[#0D1830] border border-[#C9A46A]/30 rounded-xl py-2 pl-8 pr-3 text-emerald-400 font-mono font-bold text-sm focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                  <p className="text-[10px] text-[#7C8AA8]">Total gross contractor fees paid to creator in tax year</p>
                </div>

                <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-1.5">
                  <label className="block text-[10px] font-bold text-[#7C8AA8] uppercase tracking-wider">
                    Tax Year
                  </label>
                  <select
                    value={generate1099Data.taxYear}
                    onChange={(e) => setGenerate1099Data(prev => ({ ...prev, taxYear: e.target.value }))}
                    className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white font-mono text-xs focus:border-[#C9A46A] focus:outline-none"
                  >
                    <option value="2026">2026 (Current Tax Year)</option>
                    <option value="2025">2025</option>
                    <option value="2024">2024</option>
                  </select>
                  <p className="text-[10px] text-[#7C8AA8]">IRS annual reporting period</p>
                </div>
              </div>

              {/* Recipient Details */}
              <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-3">
                <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  2. Recipient (Creator) Information
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">Recipient's Legal Name</label>
                    <input
                      type="text"
                      required
                      value={generate1099Data.recipientName}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, recipientName: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">Recipient TIN / SSN (Masked)</label>
                    <input
                      type="text"
                      value={generate1099Data.recipientTin}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, recipientTin: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white font-mono focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">Street Address</label>
                    <input
                      type="text"
                      value={generate1099Data.recipientAddress}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, recipientAddress: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">City, State, &amp; ZIP</label>
                    <input
                      type="text"
                      value={generate1099Data.recipientCityStateZip}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, recipientCityStateZip: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Payer Details */}
              <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 space-y-3">
                <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  3. Payer (Agency) Information
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">Payer's Legal Entity Name</label>
                    <input
                      type="text"
                      value={generate1099Data.payerName}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, payerName: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">Payer's Federal EIN / TIN</label>
                    <input
                      type="text"
                      value={generate1099Data.payerTin}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, payerTin: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white font-mono focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">Agency Address</label>
                    <input
                      type="text"
                      value={generate1099Data.payerAddress}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, payerAddress: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-[#7C8AA8] mb-1">Agency City, State, &amp; ZIP</label>
                    <input
                      type="text"
                      value={generate1099Data.payerCityStateZip}
                      onChange={(e) => setGenerate1099Data(prev => ({ ...prev, payerCityStateZip: e.target.value }))}
                      className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C9A46A] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* IRS Guidance info box */}
              <div className="p-3.5 bg-amber-950/30 border border-amber-500/20 rounded-xl text-[11px] text-amber-200/90 leading-relaxed flex items-start gap-2.5">
                <Info className="w-4 h-4 text-[#C9A46A] shrink-0 mt-0.5" />
                <div>
                  <strong>Agency Filing Requirement</strong>: Under IRS IRC § 6041A, agencies paying $600 or more to an independent contractor during the year must provide <strong>Copy B</strong> to the creator by January 31 and file <strong>Copy A</strong> with the IRS via the IRIS portal.
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setGenerate1099ModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold px-6 py-2.5 rounded-xl transition-all shadow-lg text-xs flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-[#0A1220]" />
                  <span>📄 Generate &amp; Download Official 1099-NEC (PDF)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 📤 UPLOAD, SEND & EMAIL TAX DOCUMENT TO CREATOR MODAL                     */}
      {/* ========================================================================= */}
      {uploadExistingTaxDocModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in overflow-y-auto">
          <div className="bg-[#0B1528] border border-sky-500/30 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-6">
            <div className="p-6 border-b border-white/10 flex items-center justify-between bg-[#111E33]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-sky-400" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-lg text-white">
                    Upload &amp; Email Tax Document to Creator
                  </h3>
                  <p className="text-xs text-[#7C8AA8]">
                    Upload a 1099-NEC, W-9, or tax document and dispatch it directly to the talent's inbox and portal
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setUploadExistingTaxDocModalOpen(false)}
                className="text-[#7C8AA8] hover:text-white p-2 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteUploadExistingDoc} className="p-6 overflow-y-auto space-y-4 text-xs">
              {/* Creator Selection */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Select Creator / Talent Recipient
                </label>
                <select
                  value={uploadExistingTaxDocData.creatorHandle}
                  onChange={(e) => {
                    const handle = e.target.value;
                    const c = creators.find(cr => cr.handle === handle);
                    const t = taxItems.find(ti => ti.creator === handle);
                    const cName = t?.realName || c?.name || 'Creator Legal Name';
                    const cEmail = (c as any)?.email || `${cName.toLowerCase().replace(/\s+/g, '.')}@bloomtalent.com`;
                    const cAmount = t?.earnings1099 || Number((c as any)?.earnings || 12500);
                    
                    setUploadExistingTaxDocData(prev => ({
                      ...prev,
                      creatorHandle: handle,
                      creatorName: cName,
                      creatorEmail: cEmail,
                      amount: cAmount,
                      emailSubject: prev.documentType === '1099-NEC'
                        ? `Official 2026 Form 1099-NEC - Bloom Studio Agency Talent Escrow`
                        : `Verified Form ${prev.documentType} - Bloom Studio Agency`,
                      emailBody: prev.documentType === '1099-NEC'
                        ? `Dear ${cName},\n\nYour official 2026 Form 1099-NEC from Bloom Studio Agency Talent Escrow Inc. is attached to this message.\n\nTax Filing Summary:\n• Recipient: ${cName} (${handle})\n• Box 1 Nonemployee Compensation: $${cAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}\n• Payer: Bloom Studio Agency Talent Escrow Inc. (TIN: 95-4819204)\n• Tax Year: 2026\n\nThis official document has also been securely published to your Creator Tax & Compliance Portal. Please download and retain this copy for your federal and state tax filings.\n\nBest regards,\nBloom Studio Agency Tax & Compliance Team`
                        : `Dear ${cName},\n\nPlease find attached your verified ${prev.documentType} tax document from Bloom Studio Agency Talent Escrow Inc.\n\nRecipient: ${cName} (${handle})\nStatus: Verified & Processed\n\nThis document is also available directly within your Creator Portal.\n\nBest regards,\nBloom Studio Compliance Operations`
                    }));
                  }}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-white text-xs font-semibold focus:border-sky-400 focus:outline-none"
                >
                  {creators.map(c => (
                    <option key={c.id || c.handle} value={c.handle}>
                      {c.name} ({c.handle})
                    </option>
                  ))}
                </select>
              </div>

              {/* Document Type & Tax Year */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-[#7C8AA8] mb-1">Document Type</label>
                  <select
                    value={uploadExistingTaxDocData.documentType}
                    onChange={(e) => {
                      const docType = e.target.value as any;
                      setUploadExistingTaxDocData(prev => ({
                        ...prev,
                        documentType: docType,
                        emailSubject: docType === '1099-NEC'
                          ? `Official 2026 Form 1099-NEC - Bloom Studio Agency Talent Escrow`
                          : `Verified Form ${docType} - Bloom Studio Agency`
                      }));
                    }}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white text-xs focus:border-sky-400 focus:outline-none"
                  >
                    <option value="1099-NEC">Form 1099-NEC (Nonemployee Compensation)</option>
                    <option value="W-9">Form W-9 (Taxpayer ID &amp; Certification)</option>
                    <option value="1040-ES">Form 1040-ES (Estimated Tax Voucher)</option>
                    <option value="Custom">Other Tax / CPA Document</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-[#7C8AA8] mb-1">Tax Year</label>
                  <select
                    value={uploadExistingTaxDocData.taxYear}
                    onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, taxYear: e.target.value }))}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white font-mono text-xs focus:border-sky-400 focus:outline-none"
                  >
                    <option value="2026">2026</option>
                    <option value="2025">2025</option>
                    <option value="2024">2024</option>
                  </select>
                </div>
              </div>

              {/* Reported Amount */}
              {uploadExistingTaxDocData.documentType === '1099-NEC' && (
                <div>
                  <label className="block text-[10px] text-[#7C8AA8] mb-1">Reported 1099 Box 1 Amount ($)</label>
                  <input
                    type="number"
                    value={uploadExistingTaxDocData.amount}
                    onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-emerald-400 font-mono font-bold text-xs focus:border-sky-400 focus:outline-none"
                  />
                </div>
              )}

              {/* File Upload Zone */}
              <div>
                <label className="block text-[10px] text-[#7C8AA8] mb-1 font-semibold">
                  Select / Attach Tax Document File (PDF, Scan, or Image)
                </label>
                <div className="border-2 border-dashed border-white/15 hover:border-sky-400/50 rounded-xl p-5 text-center transition-colors bg-[#111E33]/50">
                  <input
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = () => {
                          setUploadExistingTaxDocData(prev => ({
                            ...prev,
                            fileName: file.name,
                            fileSize: `${Math.round(file.size / 1024)} KB`,
                            fileData: reader.result as string
                          }));
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                    className="hidden"
                    id="existing-tax-file-input"
                  />
                  <label htmlFor="existing-tax-file-input" className="cursor-pointer flex flex-col items-center gap-2">
                    <Upload className="w-7 h-7 text-sky-400" />
                    <div className="text-white font-semibold">
                      {uploadExistingTaxDocData.fileName || 'Click to select or drag and drop file here'}
                    </div>
                    <div className="text-[10px] text-[#7C8AA8]">
                      {uploadExistingTaxDocData.fileSize 
                        ? `Attached: ${uploadExistingTaxDocData.fileName} (${uploadExistingTaxDocData.fileSize})` 
                        : 'Supports PDF, PNG, JPG, DOCX (Or leave blank to auto-generate & bundle IRS PDF on send)'}
                    </div>
                  </label>
                </div>
              </div>

              {/* Recipient Email & Subject */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[10px] text-[#7C8AA8] mb-1 font-semibold">
                    Creator Email Recipient
                  </label>
                  <input
                    type="email"
                    required
                    value={uploadExistingTaxDocData.creatorEmail}
                    onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, creatorEmail: e.target.value }))}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-sky-300 font-mono text-xs focus:border-sky-400 focus:outline-none"
                    placeholder="creator@email.com"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#7C8AA8] mb-1 font-semibold">
                    Email Subject Line
                  </label>
                  <input
                    type="text"
                    required
                    value={uploadExistingTaxDocData.emailSubject}
                    onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, emailSubject: e.target.value }))}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-2.5 text-white text-xs focus:border-sky-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Email Body Message */}
              <div>
                <label className="block text-[10px] text-[#7C8AA8] mb-1 font-semibold">
                  Email Message Body to Creator
                </label>
                <textarea
                  rows={4}
                  value={uploadExistingTaxDocData.emailBody}
                  onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, emailBody: e.target.value }))}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-slate-300 text-xs font-mono focus:border-sky-400 focus:outline-none leading-relaxed"
                />
              </div>

              {/* Options */}
              <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={uploadExistingTaxDocData.sendEmailCopy}
                    onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, sendEmailCopy: e.target.checked }))}
                    className="rounded border-white/20 bg-slate-800 text-sky-500 focus:ring-0"
                  />
                  <span className="text-[11px] text-white">Send official copy via email with document attached</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={uploadExistingTaxDocData.publishToPortal}
                    onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, publishToPortal: e.target.checked }))}
                    className="rounded border-white/20 bg-slate-800 text-sky-500 focus:ring-0"
                  />
                  <span className="text-[11px] text-white">Publish document to Creator's Compliance &amp; Tax Portal</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={uploadExistingTaxDocData.markAsFiled}
                    onChange={(e) => setUploadExistingTaxDocData(prev => ({ ...prev, markAsFiled: e.target.checked }))}
                    className="rounded border-white/20 bg-slate-800 text-sky-500 focus:ring-0"
                  />
                  <span className="text-[11px] text-white">Update agency tracker status to "Filed &amp; Sent"</span>
                </label>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setUploadExistingTaxDocModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-sky-500 hover:bg-sky-400 text-black font-bold px-6 py-2.5 rounded-xl transition-all shadow-lg text-xs flex items-center gap-2 cursor-pointer"
                >
                  <Mail className="w-4 h-4" />
                  <span>📤 Upload, Send &amp; Email to Creator</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        config={deleteConfirmConfig}
        onClose={() => setDeleteConfirmConfig(null)}
      />

      {/* Multi-File & PDF Viewer Modal */}
      <MultiFilePdfViewerModal
        isOpen={docViewerOpen}
        onClose={() => setDocViewerOpen(false)}
        title={docViewerTitle}
        files={docViewerFiles}
      />
    </div>
  );
}
