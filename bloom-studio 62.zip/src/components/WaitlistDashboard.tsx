import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, UserPlus, Clock, CheckCircle2, XCircle, Search, Filter, 
  Sparkles, Star, ArrowUpRight, Mail, Phone, Instagram, Send,
  ShieldCheck, AlertCircle, TrendingUp, Download, Eye, Check, X, RefreshCw
} from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, onSnapshot, doc, setDoc, updateDoc, query, where } from 'firebase/firestore';
import { generateSecureInviteCode } from '../utils/cryptoUtils';
import { safeStorage } from '../utils/safeStorage';

export interface WaitlistEntry {
  id: string;
  name: string;
  handle: string;
  email: string;
  phone?: string;
  type: 'Creator' | 'Brand';
  niche: 'Beauty' | 'Pets' | 'Lifestyle' | 'Tech' | 'Fashion' | 'Food';
  followers?: string;
  followerCount?: number;
  engagementRate?: string;
  platform?: 'TikTok' | 'Instagram' | 'YouTube';
  budget?: string; // For brands
  priority: 'VIP Fast-Track' | 'High Priority' | 'Standard' | 'Reviewing';
  status: 'Pending' | 'Approved' | 'Invited' | 'Waitlisted' | 'Declined';
  appliedDate: string;
  notes?: string;
  inviteCode?: string;
}

const DEFAULT_WAITLIST: WaitlistEntry[] = [
  {
    id: 'wl-101',
    name: 'Sienna Rivera',
    handle: '@siennaglows',
    email: 'sienna.rivera@gmail.com',
    phone: '+1 (310) 555-0192',
    type: 'Creator',
    niche: 'Beauty',
    followers: '485K',
    followerCount: 485000,
    engagementRate: '6.4%',
    platform: 'TikTok',
    priority: 'VIP Fast-Track',
    status: 'Pending',
    appliedDate: '2026-08-28',
    notes: 'High conversion beauty creator with viral skincare routine series. Top candidate for upcoming botanical serum campaigns.'
  },
  {
    id: 'wl-102',
    name: 'Marcus Vance',
    handle: '@marcusbarklife',
    email: 'marcus.vance@barkmedia.com',
    phone: '+1 (415) 555-0144',
    type: 'Creator',
    niche: 'Pets',
    followers: '290K',
    followerCount: 290000,
    engagementRate: '7.8%',
    platform: 'Instagram',
    priority: 'High Priority',
    status: 'Pending',
    appliedDate: '2026-08-27',
    notes: 'Pet parent creator with 2 golden retrievers. Strong visual aesthetic and consistent 4K video quality.'
  },
  {
    id: 'wl-103',
    name: 'Lumina Pet Nutrition',
    handle: '@luminapets',
    email: 'partnerships@luminapets.co',
    phone: '+1 (212) 555-0831',
    type: 'Brand',
    niche: 'Pets',
    budget: '$35,000 / month',
    priority: 'VIP Fast-Track',
    status: 'Approved',
    appliedDate: '2026-08-26',
    notes: 'Premium organic pet food brand looking for 15+ recurring creator retainers for Q4 holiday push.',
    inviteCode: 'BLOOM-VIP-LUMINA'
  },
  {
    id: 'wl-104',
    name: 'Chloe Zhang',
    handle: '@chloezhangstyle',
    email: 'chloe@zhangcreatives.com',
    phone: '+1 (646) 555-0129',
    type: 'Creator',
    niche: 'Lifestyle',
    followers: '175K',
    followerCount: 175000,
    engagementRate: '5.1%',
    platform: 'TikTok',
    priority: 'Standard',
    status: 'Waitlisted',
    appliedDate: '2026-08-24',
    notes: 'Minimalist city living & fashion staples. Steady growth rate.'
  },
  {
    id: 'wl-105',
    name: 'Drip & Glow Botanicals',
    handle: '@dripglowofficial',
    email: 'media@dripglow.io',
    type: 'Brand',
    niche: 'Beauty',
    budget: '$20,000 / month',
    priority: 'High Priority',
    status: 'Pending',
    appliedDate: '2026-08-28',
    notes: 'Eco-conscious clean cosmetics brand expanding UGC paid advertising pipeline.'
  }
];

interface WaitlistDashboardProps {
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: string) => void;
}

export default function WaitlistDashboard({
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}: WaitlistDashboardProps) {
  const [waitlist, setWaitlist] = useState<WaitlistEntry[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_waitlist_entries');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_WAITLIST;
  });

  const [selectedType, setSelectedType] = useState<'All' | 'Creator' | 'Brand'>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [nicheFilter, setNicheFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEntry, setSelectedEntry] = useState<WaitlistEntry | null>(null);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [customInviteCode, setCustomInviteCode] = useState('');
  const [isDispatching, setIsDispatching] = useState(false);

  // Local storage persistence
  useEffect(() => {
    try {
      safeStorage.setItem('wl_waitlist_entries', JSON.stringify(waitlist));
    } catch {}
  }, [waitlist]);

  // Firestore sync if available
  useEffect(() => {
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, 'studio_waitlist');
    const q = isPlatformOwner
      ? colRef
      : query(colRef, where('subagency', '==', currentUser?.subagency || 'pod_main'));

    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const firestoreList: WaitlistEntry[] = [];
        snapshot.forEach(docSnap => {
          firestoreList.push({ id: docSnap.id, ...docSnap.data() } as WaitlistEntry);
        });
        setWaitlist(prev => {
          const merged = [...prev];
          firestoreList.forEach(fItem => {
            const idx = merged.findIndex(m => m.id === fItem.id);
            if (idx >= 0) merged[idx] = fItem;
            else merged.unshift(fItem);
          });
          return merged;
        });
      }
    }, (err) => console.log('Firestore waitlist sync (local fallback active):', err));

    return () => unsub();
  }, [currentUser]);

  const handleUpdateStatus = async (id: string, newStatus: WaitlistEntry['status'], note?: string) => {
    const entry = waitlist.find(e => e.id === id);
    const code = newStatus === 'Approved' || newStatus === 'Invited' 
      ? entry?.inviteCode || generateSecureInviteCode('BLOOM-VIP-')
      : entry?.inviteCode;

    const now = new Date().toISOString();
    const updated = waitlist.map(item => {
      if (item.id === id) {
        return {
          ...item,
          status: newStatus,
          inviteCode: code
        };
      }
      return item;
    });

    setWaitlist(updated);
    if (selectedEntry?.id === id) {
      setSelectedEntry(updated.find(e => e.id === id) || null);
    }

    try {
      await setDoc(doc(db, 'studio_waitlist', id), {
        status: newStatus,
        inviteCode: code || null,
        subagency: currentUser?.subagency || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        updatedAt: now
      }, { merge: true });

      // If approved or invited with a code, ensure the code is registered in studio-invite-codes
      if ((newStatus === 'Approved' || newStatus === 'Invited') && code && entry) {
        await setDoc(doc(db, 'studio-invite-codes', code), {
          code,
          role: entry.type === 'Brand' ? 'brand' : 'creator',
          subagency: currentUser?.subagency || 'pod_main',
          tenantId: currentUser?.tenantId || 'bloom_studio_default',
          usesLeft: 1,
          status: 'Active',
          issuedTo: entry.name,
          issuedEmail: entry.email,
          handle: entry.handle,
          waitlistId: id,
          createdAt: now,
          updatedAt: now,
          issuedBy: currentUser?.name || currentUser?.email || 'Director'
        }, { merge: true });
      }
    } catch (err) {
      console.warn('Failed to sync waitlist status to Firestore:', err);
    }

    triggerNotification?.(
      'Waitlist Updated',
      `${entry?.name || 'Applicant'} status updated to ${newStatus}.`,
      newStatus === 'Approved' || newStatus === 'Invited' ? 'success' : 'info'
    );
    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole || 'none',
      `Updated waitlist applicant ${entry?.name} (@${entry?.handle}) to ${newStatus}`
    );
  };

  const handleSendInvite = async (entry: WaitlistEntry) => {
    if (isDispatching) return;
    const code = customInviteCode || entry.inviteCode || generateSecureInviteCode('BLOOM-VIP-');
    setIsDispatching(true);

    try {
      // 1. Send invite through backend API (verifies staff role, manages SendGrid dispatch & Firestore invite code)
      const token = await auth.currentUser?.getIdToken();
      const res = await fetch('/api/send-waitlist-invite', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          email: entry.email,
          name: entry.name,
          handle: entry.handle,
          inviteCode: code,
          type: entry.type,
          entryId: entry.id
        })
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to dispatch VIP invite');
      }

      // 2. Direct client-side Firestore fallback to ensure instant sync
      try {
        const now = new Date().toISOString();
        await setDoc(doc(db, 'studio-invite-codes', code), {
          code,
          role: entry.type === 'Brand' ? 'brand' : 'creator',
          subagency: currentUser?.subagency || 'pod_main',
          tenantId: currentUser?.tenantId || 'bloom_studio_default',
          usesLeft: 1,
          status: 'Active',
          issuedTo: entry.name,
          issuedEmail: entry.email,
          handle: entry.handle,
          waitlistId: entry.id,
          createdAt: now,
          updatedAt: now,
          issuedBy: currentUser?.name || currentUser?.email || 'Director'
        }, { merge: true });

        await setDoc(doc(db, 'studio_waitlist', entry.id), {
          status: 'Invited',
          inviteCode: code,
          inviteSentAt: now,
          inviteSentBy: currentUser?.name || currentUser?.email || 'Director',
          subagency: currentUser?.subagency || 'pod_main',
          tenantId: currentUser?.tenantId || 'bloom_studio_default',
          updatedAt: now
        }, { merge: true });
      } catch (fbErr) {
        console.warn('[Waitlist] Client-side Firestore write fallback notice:', fbErr);
      }

      // 3. Update local state
      const updated = waitlist.map(item => {
        if (item.id === entry.id) {
          return {
            ...item,
            status: 'Invited' as const,
            inviteCode: code
          };
        }
        return item;
      });
      setWaitlist(updated);
      if (selectedEntry?.id === entry.id) {
        setSelectedEntry({ ...selectedEntry, status: 'Invited', inviteCode: code });
      }

      // 4. Honest notification based on actual dispatch channel
      if (data.isSimulated) {
        triggerNotification?.(
          'VIP Invite Registered',
          `VIP access code ${code} activated in Firestore. (Email gateway in simulated mode — SendGrid credentials pending in environment).`,
          'info'
        );
      } else {
        triggerNotification?.(
          'VIP Invite Email Dispatched',
          `VIP invite link & access code ${code} successfully delivered via SendGrid to ${entry.email}.`,
          'success'
        );
      }

      onAddActivityLog?.(
        currentUser?.name || 'User',
        currentRole || 'none',
        `Dispatched VIP intake invite code ${code} to ${entry.name} (${entry.email})`
      );

      setIsInviteModalOpen(false);
      setCustomInviteCode('');
    } catch (err: any) {
      console.error('[Waitlist] Error sending invite:', err);
      triggerNotification?.(
        'Invite Dispatch Notice',
        err.message || 'Could not dispatch VIP invite. Please verify network and permissions.',
        'warning'
      );
    } finally {
      setIsDispatching(false);
    }
  };

  const filteredEntries = useMemo(() => {
    return waitlist.filter(item => {
      if (selectedType !== 'All' && item.type !== selectedType) return false;
      if (statusFilter !== 'All' && item.status !== statusFilter) return false;
      if (nicheFilter !== 'All' && item.niche !== nicheFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesHandle = item.handle.toLowerCase().includes(q);
        const matchesEmail = item.email.toLowerCase().includes(q);
        if (!matchesName && !matchesHandle && !matchesEmail) return false;
      }
      return true;
    });
  }, [waitlist, selectedType, statusFilter, nicheFilter, searchQuery]);

  const stats = useMemo(() => {
    const total = waitlist.length;
    const pending = waitlist.filter(w => w.status === 'Pending').length;
    const approved = waitlist.filter(w => w.status === 'Approved' || w.status === 'Invited').length;
    const vip = waitlist.filter(w => w.priority === 'VIP Fast-Track').length;
    return { total, pending, approved, vip };
  }, [waitlist]);

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      {/* Header Banner */}
      <div className="relative bg-[#0b1320] border-2 border-[#C9A46A]/30 rounded-3xl p-6 md:p-8 overflow-hidden shadow-2xl">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-[0.2em] font-mono px-2.5 py-0.5 rounded-full bg-[#C9A46A]/10 border border-[#C9A46A]/20">
                Talent & Brand Intake Queue
              </span>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
              Agency Waitlist & Intake Pipeline
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl">
              Screen, vet, and fast-track top creator talent and high-budget brand partnerships before full onboarding to Bloom Studio.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#050d18] border border-blue-900/60 p-3 rounded-2xl">
            <div className="text-center px-3 py-1">
              <span className="text-[10px] font-mono text-slate-400 block uppercase">Total Queue</span>
              <span className="text-lg font-bold text-white font-mono">{stats.total}</span>
            </div>
            <div className="text-center px-3 py-1 border-l border-white/5">
              <span className="text-[10px] font-mono text-amber-400 block uppercase">Pending</span>
              <span className="text-lg font-bold text-amber-400 font-mono">{stats.pending}</span>
            </div>
            <div className="text-center px-3 py-1 border-l border-white/5">
              <span className="text-[10px] font-mono text-emerald-400 block uppercase">Approved</span>
              <span className="text-lg font-bold text-emerald-400 font-mono">{stats.approved}</span>
            </div>
            <div className="text-center px-3 py-1 border-l border-white/5">
              <span className="text-[10px] font-mono text-purple-400 block uppercase">VIP Fast-Track</span>
              <span className="text-lg font-bold text-purple-400 font-mono">{stats.vip}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Action Bar */}
      <div className="bg-[#0b1320] border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Type Toggle Tabs */}
        <div className="flex items-center gap-1.5 bg-[#050e1a] p-1 rounded-xl border border-white/5">
          {(['All', 'Creator', 'Brand'] as const).map(t => (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold font-mono transition-all cursor-pointer ${
                selectedType === t 
                  ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-md' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {t === 'All' ? 'All Applicants' : `${t}s`}
            </button>
          ))}
        </div>

        {/* Search & Status Filter */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search name, handle, email..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-[#050e1a] border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#C9A46A] w-56"
            />
          </div>

          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="bg-[#050e1a] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
          >
            <option value="All">All Statuses</option>
            <option value="Pending">Pending Review</option>
            <option value="Approved">Approved</option>
            <option value="Invited">Invited / Active Code</option>
            <option value="Waitlisted">Waitlisted</option>
            <option value="Declined">Declined</option>
          </select>

          <select
            value={nicheFilter}
            onChange={e => setNicheFilter(e.target.value)}
            className="bg-[#050e1a] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
          >
            <option value="All">All Niches</option>
            <option value="Beauty">Beauty</option>
            <option value="Pets">Pets</option>
            <option value="Lifestyle">Lifestyle</option>
            <option value="Fashion">Fashion</option>
            <option value="Tech">Tech</option>
          </select>
        </div>
      </div>

      {/* Main Table / Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Applicants List */}
        <div className="lg:col-span-8 space-y-3">
          {filteredEntries.length === 0 ? (
            <div className="bg-[#0b1320] border border-white/10 rounded-2xl p-12 text-center space-y-3">
              <Users className="w-10 h-10 text-slate-500 mx-auto opacity-50" />
              <h3 className="text-sm font-bold text-white">No waitlist applicants found</h3>
              <p className="text-xs text-slate-400">Try adjusting your filters or search terms.</p>
            </div>
          ) : (
            filteredEntries.map(entry => {
              const isSelected = selectedEntry?.id === entry.id;
              return (
                <div
                  key={entry.id}
                  onClick={() => setSelectedEntry(entry)}
                  className={`bg-[#0b1320] border rounded-2xl p-4 transition-all cursor-pointer hover:border-[#C9A46A]/50 ${
                    isSelected ? 'border-[#C9A46A] bg-[#0c182b] shadow-xl' : 'border-white/10'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#050e1a] border border-white/10 flex items-center justify-center font-mono font-bold text-sm text-[#C9A46A] shrink-0">
                        {entry.name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-white">{entry.name}</h4>
                          <span className="text-[10px] text-slate-400 font-mono">{entry.handle}</span>
                          <span className={`px-2 py-0.2 text-[9px] font-bold font-mono uppercase rounded-full ${
                            entry.type === 'Creator' ? 'bg-purple-500/10 text-purple-300 border border-purple-500/20' : 'bg-blue-500/10 text-blue-300 border border-blue-500/20'
                          }`}>
                            {entry.type}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {entry.email} • {entry.niche} • Applied {entry.appliedDate}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <span className={`px-2.5 py-1 text-[10px] font-bold font-mono rounded-lg border ${
                        entry.priority === 'VIP Fast-Track' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' :
                        entry.priority === 'High Priority' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                        'bg-slate-500/10 text-slate-400 border-white/10'
                      }`}>
                        {entry.priority}
                      </span>

                      <span className={`px-2.5 py-1 text-[10px] font-bold font-mono rounded-lg border ${
                        entry.status === 'Approved' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                        entry.status === 'Invited' ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' :
                        entry.status === 'Waitlisted' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                        entry.status === 'Declined' ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' :
                        'bg-slate-500/10 text-slate-300 border-white/10'
                      }`}>
                        {entry.status}
                      </span>
                    </div>
                  </div>

                  {entry.notes && (
                    <p className="text-[11px] text-slate-300 mt-2.5 line-clamp-1 bg-[#050e1a] px-3 py-1.5 rounded-lg border border-white/5 font-sans">
                      {entry.notes}
                    </p>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Selected Applicant Details Drawer */}
        <div className="lg:col-span-4">
          {selectedEntry ? (
            <div className="bg-[#0b1320] border border-[#C9A46A]/40 rounded-3xl p-6 space-y-6 sticky top-6 shadow-2xl">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider">
                    Applicant Dossier
                  </span>
                  <h3 className="text-base font-bold text-white mt-1">{selectedEntry.name}</h3>
                  <span className="text-xs text-slate-400 font-mono">{selectedEntry.handle}</span>
                </div>
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-slate-400">Application Type:</span>
                  <span className="font-bold text-white font-mono">{selectedEntry.type}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-slate-400">Category Niche:</span>
                  <span className="font-bold text-[#C9A46A] font-mono">{selectedEntry.niche}</span>
                </div>
                {selectedEntry.followers && (
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Follower Reach:</span>
                    <span className="font-bold text-white font-mono">{selectedEntry.followers} ({selectedEntry.platform})</span>
                  </div>
                )}
                {selectedEntry.engagementRate && (
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Verified Engagement:</span>
                    <span className="font-bold text-emerald-400 font-mono">{selectedEntry.engagementRate}</span>
                  </div>
                )}
                {selectedEntry.budget && (
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Brand Budget:</span>
                    <span className="font-bold text-emerald-400 font-mono">{selectedEntry.budget}</span>
                  </div>
                )}
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-slate-400">Email:</span>
                  <span className="font-mono text-slate-200">{selectedEntry.email}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-slate-400">Applied Date:</span>
                  <span className="font-mono text-slate-200">{selectedEntry.appliedDate}</span>
                </div>
                {selectedEntry.inviteCode && (
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">VIP Access Code:</span>
                    <span className="font-mono text-purple-300 font-bold bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                      {selectedEntry.inviteCode}
                    </span>
                  </div>
                )}
              </div>

              {selectedEntry.notes && (
                <div className="space-y-1.5 bg-[#050e1a] p-3.5 rounded-xl border border-white/5">
                  <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest block">
                    Vetting & Intake Notes
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    {selectedEntry.notes}
                  </p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleUpdateStatus(selectedEntry.id, 'Approved')}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-900/30"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Approve
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(selectedEntry.id, 'Waitlisted')}
                    className="w-full bg-amber-600 hover:bg-amber-500 text-white py-2.5 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-amber-900/30"
                  >
                    <Clock className="w-4 h-4" /> Waitlist
                  </button>
                </div>

                <button
                  onClick={() => setIsInviteModalOpen(true)}
                  className="w-full bg-[#C9A46A] hover:bg-[#D4AF37] text-[#0A1220] py-2.5 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#C9A46A]/20"
                >
                  <Send className="w-4 h-4" /> Dispatch VIP Onboarding Invite
                </button>

                <button
                  onClick={() => handleUpdateStatus(selectedEntry.id, 'Declined')}
                  className="w-full bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <XCircle className="w-4 h-4" /> Decline Applicant
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-[#0b1320] border border-white/10 rounded-3xl p-8 text-center space-y-3 sticky top-6">
              <Sparkles className="w-8 h-8 text-[#C9A46A] mx-auto opacity-75" />
              <h4 className="text-xs font-bold text-white">No applicant selected</h4>
              <p className="text-[11px] text-slate-400">
                Click any talent or brand application on the left to review dossier details, approve intake, and issue VIP access codes.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Invite Modal */}
      {isInviteModalOpen && selectedEntry && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b1320] border-2 border-[#C9A46A] rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white">Send VIP Invite & Code</h3>
                <p className="text-[11px] text-slate-400">Issue direct access pass to {selectedEntry.name}</p>
              </div>
              <button
                onClick={() => setIsInviteModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
                  Recipient Email
                </label>
                <input
                  type="text"
                  disabled
                  value={selectedEntry.email}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3 py-2 text-slate-300 font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">
                  Custom VIP Access Pass Code
                </label>
                <input
                  type="text"
                  placeholder="e.g. BLOOM-VIP-PASS"
                  value={customInviteCode}
                  onChange={e => setCustomInviteCode(e.target.value.toUpperCase())}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3 py-2 text-white font-mono text-xs focus:border-[#C9A46A] outline-none"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsInviteModalOpen(false)}
                disabled={isDispatching}
                className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-2.5 rounded-xl text-xs font-bold cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleSendInvite(selectedEntry)}
                disabled={isDispatching}
                className="flex-1 bg-[#C9A46A] hover:bg-[#D4AF37] text-[#0A1220] py-2.5 rounded-xl text-xs font-bold font-mono cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isDispatching ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Dispatching...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Confirm & Dispatch</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
