import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  Video,
  Clock,
  Filter,
  CheckCircle,
  Users,
  Shield,
  Layers,
  Sparkles,
  ChevronRight,
  Plus
} from 'lucide-react';
import { Creator, Deal, Role } from '../types';
import { ProductionCalendar } from './ProductionCalendar';
import { TalentAvailabilityCalendar } from './TalentAvailabilityCalendar';

interface UnifiedCalendarHubProps {
  agencySchedules?: any[];
  setAgencySchedules?: React.Dispatch<React.SetStateAction<any[]>>;
  creators?: Creator[];
  deals?: Deal[];
  currentRole?: Role | string;
  currentUser?: any;
  defaultTab?: 'production' | 'availability';
  onAddActivityLog?: (actorName: string, actorRole: string, actionDetail: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'info' | 'warning' | 'success' | 'danger') => void;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onNavigateToScreen?: (screenId: string) => void;
  myHandles?: string[];
}

export const UnifiedCalendarHub: React.FC<UnifiedCalendarHubProps> = ({
  agencySchedules = [],
  setAgencySchedules,
  creators = [],
  deals = [],
  currentRole = 'director',
  currentUser,
  defaultTab = 'production',
  onAddActivityLog,
  triggerNotification,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onNavigateToScreen,
  myHandles = []
}) => {
  const [activeTab, setActiveTab] = useState<'production' | 'availability'>(defaultTab);

  const isDirector = (currentRole || '').toLowerCase() === 'director' || 
                     (currentRole || '').toLowerCase() === 'super_admin' || 
                     !!currentUser?.isPlatformOwner;
  const isCreator = (currentRole || '').toLowerCase() === 'creator';
  const isStaff = ['agentmgr', 'agent', 'coordinator'].includes((currentRole || '').toLowerCase());

  // Dynamic role scope label
  const roleScopeLabel = useMemo(() => {
    if (isDirector) {
      return {
        badge: 'Executive Directorial View',
        desc: 'Unrestricted visibility across all talent shoots, production milestones & availability slots agency-wide.',
        color: 'text-[#C9A46A] border-[#C9A46A]/30 bg-[#C9A46A]/10'
      };
    }
    if (isCreator) {
      return {
        badge: 'Personal Schedule & Shoots',
        desc: 'Scoped strictly to your confirmed shoots, draft deadlines, and personal blockout calendar.',
        color: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'
      };
    }
    if (isStaff) {
      return {
        badge: 'Assigned Roster Pod View',
        desc: 'Scoped to productions and availability schedules for creators in your active roster.',
        color: 'text-sky-400 border-sky-500/30 bg-sky-500/10'
      };
    }
    return {
      badge: 'Standard Calendar Access',
      desc: 'Deliverables tracking & availability schedule.',
      color: 'text-slate-300 border-white/10 bg-white/5'
    };
  }, [isDirector, isCreator, isStaff]);

  // High-level month summary counts for tabs
  const summaryCounts = useMemo(() => {
    const curMonth = new Date().getMonth();
    const curYear = new Date().getFullYear();

    // Production shoots / milestones
    const prodCount = (agencySchedules || []).filter(e => {
      const isProdType = e.type !== 'availability' && e.type !== 'blockout' && e.type !== 'vacation';
      return isProdType && !e.isDeleted;
    }).length + (deals || []).length;

    // Availability slots
    const availCount = (agencySchedules || []).filter(e => {
      return e.type === 'availability' || e.type === 'blockout' || e.type === 'vacation' || e.status;
    }).length;

    return {
      production: prodCount,
      availability: availCount > 0 ? availCount : 4
    };
  }, [agencySchedules, deals]);

  return (
    <div className="space-y-6 animate-fade-in" id="unifiedCalendarHubContainer">
      {/* Top Header & Navigation Banner */}
      <div 
        className="rounded-2xl p-6 border shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6"
        style={{
          backgroundColor: cardBgColor,
          borderColor: `${primaryBrandColor}30`
        }}
      >
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className={`text-[10px] font-mono uppercase tracking-wider font-bold px-2.5 py-1 rounded-full border flex items-center gap-1.5 ${roleScopeLabel.color}`}>
              <Shield className="w-3 h-3" />
              {roleScopeLabel.badge}
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
              Dual-Channel Calendar Hub
            </span>
          </div>

          <h1 className="text-2xl lg:text-3xl font-serif font-bold text-white tracking-tight flex items-center gap-3">
            <CalendarIcon className="w-7 h-7 text-[#C9A46A]" style={{ color: primaryBrandColor }} />
            <span>Master Production &amp; Availability Hub</span>
          </h1>

          <p className="text-xs text-slate-300 leading-relaxed">
            {roleScopeLabel.desc} Seamlessly toggle between client campaign shoot milestones and real-time talent booking holds &amp; blackout dates.
          </p>
        </div>

        {/* Tab Switching Pill Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-2.5 shrink-0 bg-[#070D18] p-1.5 rounded-2xl border border-white/10 shadow-inner">
          <button
            type="button"
            id="tabBtnProductionCalendar"
            onClick={() => setActiveTab('production')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeTab === 'production'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
            style={activeTab === 'production' ? { backgroundColor: primaryBrandColor } : {}}
          >
            <Video className="w-4 h-4" />
            <span>Production Deliverables</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
              activeTab === 'production' ? 'bg-[#0A1220]/20 text-[#0A1220]' : 'bg-white/10 text-slate-400'
            }`}>
              {summaryCounts.production}
            </span>
          </button>

          <button
            type="button"
            id="tabBtnAvailabilityCalendar"
            onClick={() => setActiveTab('availability')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeTab === 'availability'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
            style={activeTab === 'availability' ? { backgroundColor: primaryBrandColor } : {}}
          >
            <CalendarIcon className="w-4 h-4" />
            <span>Talent Availability &amp; Blackouts</span>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
              activeTab === 'availability' ? 'bg-[#0A1220]/20 text-[#0A1220]' : 'bg-white/10 text-slate-400'
            }`}>
              {summaryCounts.availability}
            </span>
          </button>
        </div>
      </div>

      {/* Render Active Calendar View */}
      <div className="transition-all">
        {activeTab === 'production' ? (
          <ProductionCalendar
            agencySchedules={agencySchedules}
            setAgencySchedules={setAgencySchedules}
            creators={creators}
            deals={deals}
            currentRole={currentRole}
            currentUser={currentUser}
            isEmbeddedInDirectorDash={false}
            onAddActivityLog={onAddActivityLog}
            triggerNotification={triggerNotification}
            primaryBrandColor={primaryBrandColor}
            cardBgColor={cardBgColor}
            onNavigateToScreen={onNavigateToScreen}
          />
        ) : (
          <TalentAvailabilityCalendar
            agencySchedules={agencySchedules}
            setAgencySchedules={setAgencySchedules}
            creators={creators}
            currentRole={currentRole}
            currentUser={currentUser}
            myHandles={myHandles}
            onAddActivityLog={onAddActivityLog}
            triggerNotification={triggerNotification}
            primaryBrandColor={primaryBrandColor}
            cardBgColor={cardBgColor}
            onNavigateToScreen={onNavigateToScreen}
          />
        )}
      </div>
    </div>
  );
};
