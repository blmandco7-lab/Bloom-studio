/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Users, MonitorPlay, FileText, Wand2, ChevronDown, CheckCircle2, Loader2, Sparkles, UserCheck, Upload, ScanFace, ImagePlus } from 'lucide-react';

interface StockAvatar {
  id: string;
  name: string;
  niche: string;
  image: string;
  fallbackColor?: string;
}

const STOCK_AVATARS: StockAvatar[] = [
  { id: 'sa1', name: 'Sarah', niche: 'Cosmetics & Beauty', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-amber-600 to-rose-700' },
  { id: 'sa2', name: 'Marcus', niche: 'Tech & Gadgets', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-blue-600 to-cyan-700' },
  { id: 'sa3', name: 'Elena', niche: 'Luxury & Lifestyle', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-purple-600 to-amber-600' },
  { id: 'sa4', name: 'David', niche: 'Business & Finance', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-slate-700 to-emerald-800' },
  { id: 'sa5', name: 'Chloe', niche: 'Health & Wellness', image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-emerald-600 to-teal-700' },
  { id: 'sa6', name: 'Jordan', niche: 'Home & Interior', image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-indigo-600 to-amber-700' },
  { id: 'sa7', name: 'Aaliyah', niche: 'Apparel & Streetwear', image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-fuchsia-600 to-rose-700' },
  { id: 'sa8', name: 'Kaito', niche: 'Gaming & Esport', image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-violet-600 to-cyan-700' },
  { id: 'sa9', name: 'Sofia', niche: 'Travel & Adventure', image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=400&fit=crop&auto=format', fallbackColor: 'from-amber-600 to-orange-700' }
];

const StockAvatarStudio: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'stock' | 'custom'>('stock');
  const [customAvatarImage, setCustomAvatarImage] = useState<string | null>(null);
  const [customAvatarName, setCustomAvatarName] = useState<string>('My Custom Twin');
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(STOCK_AVATARS[0].id);
  const [script, setScript] = useState('');
  const [voiceProfile, setVoiceProfile] = useState('american-natural');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [generatedOutput, setGeneratedOutput] = useState<{avatarImage: string, avatarName: string, scriptText: string} | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
    const [accent, setAccent] = useState('Professional');

  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  const handleGenerate = async () => {
    if (!selectedAvatar || !script.trim()) return;

    setIsGenerating(true);
    setGeneratedOutput(null);
    window.speechSynthesis.cancel();
    setIsPlaying(false);
    
    const steps = [
      'Analyzing Linguistic Nuances...',
      'Mapping Neural Phonemes...',
      'Synthesizing Facial Geometry...',
      'Rendering 9:16 Creative Output...'
    ];

    try {
      for (const step of steps) {
        setGenerationStep(step);
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      
      const avatar = activeTab === 'stock' 
        ? STOCK_AVATARS.find(a => a.id === selectedAvatar) 
        : { id: 'custom', name: customAvatarName, image: customAvatarImage || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop', niche: 'Custom' };
      
      const isMale = avatar ? ['Marcus', 'David', 'Jordan', 'Kaito'].includes(avatar.name) : false;
      
      if (avatar) {
        // --- Open-Source Video Rendering Pipeline Integration ---
        // Payload structure for talking-head video animation nodes (e.g., SadTalker / Wav2Lip)
        const pipelineUrl = (import.meta as any).env.VITE_OPEN_SOURCE_PIPELINE_URL;
        
        if (pipelineUrl) {
          try {
            const apiPayload = {
              node_architecture: "talking-head",
              source_image_url: avatar.image,
              tts_config: {
                script_text: script,
                voice_profile: isMale ? "en-US-Journey-D" : "en-US-Journey-F",
                audio_buffer_sync: true,
                pitch: isMale ? -2.0 : 2.0,
                speed: 1.0
              },
              render_settings: {
                resolution: "1080x1920",
                fps: 30,
                enhancer: "gfpgan", // facial enhancement node
                expression_scale: 1.2
              }
            };
            
            console.log("Transmitting payload to open-source pipeline:", apiPayload);
            
            // Uncomment to perform actual fetch when endpoint is live:
            /*
            const response = await fetch(`${pipelineUrl}/v1/render/synthetic-avatar`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(apiPayload)
            });
            const data = await response.json();
            if (data.video_url) {
               // Render actual video returned by pipeline
               return;
            }
            */
          } catch (e) {
             console.warn("Pipeline integration failed, falling back to client-side simulation", e);
          }
        }
        // --- End Pipeline Integration ---

        setGeneratedOutput({
          avatarImage: avatar.image,
          avatarName: avatar.name,
          scriptText: script,
        });
      }
    } catch (err) {
      console.error('Generation Error:', err);
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
    }
  };

  return (
    <div className="min-h-screen bg-[#0B1B3D] text-white p-6 md:p-12 space-y-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-[#D4AF37] flex items-center gap-3">
            <MonitorPlay className="w-8 h-8" /> Stock Avatar Studio
          </h1>
          <p className="text-[#7C8AA8] mt-2 max-w-2xl">
            Library of non-human computer-generated stock actors for rapid ad scripting and synthetic UGC generation.
          </p>
        </div>
        <div className="flex items-center gap-4 bg-[#142850] px-4 py-2 rounded-2xl border border-white/5 shadow-xl">
          <div className="flex -space-x-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="w-8 h-8 rounded-full border-2 border-[#142850] bg-[#0B1B3D] overflow-hidden">
                <img src={`https://i.pravatar.cc/100?u=${i}`} alt="Avatar" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
          <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">Asset Compilation Mode</span>
        </div>
      </div>

      <div className="flex border-b border-white/10 mb-8">
        <button 
          onClick={() => { setActiveTab('stock'); setGeneratedOutput(null); }}
          className={`px-6 py-3 font-bold text-sm tracking-widest uppercase transition-colors border-b-2 ${activeTab === 'stock' ? 'text-[#D4AF37] border-[#D4AF37]' : 'text-slate-500 border-transparent hover:text-slate-300'}`}
        >
          Stock Catalog
        </button>
        <button 
          onClick={() => { setActiveTab('custom'); setGeneratedOutput(null); }}
          className={`px-6 py-3 font-bold text-sm tracking-widest uppercase transition-colors border-b-2 ${activeTab === 'custom' ? 'text-[#D4AF37] border-[#D4AF37]' : 'text-slate-500 border-transparent hover:text-slate-300'}`}
        >
          Custom Generator
        </button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Main Interface */}
        <div className="lg:col-span-8 space-y-8">
          {activeTab === 'stock' ? (
            <>
              {/* Actor Selection Grid */}
              <section className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-sm font-bold text-[#D4AF37] uppercase tracking-widest flex items-center gap-2">
                <Users className="w-4 h-4" /> General Actor Selection Grid
              </h2>
              <span className="text-[10px] text-[#7C8AA8] bg-white/5 px-2 py-1 rounded-full uppercase">Neural Catalog</span>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {STOCK_AVATARS.map((avatar) => (
                <button
                  key={avatar.id}
                  onClick={() => setSelectedAvatar(avatar.id)}
                  className={`group relative aspect-square bg-[#142850] rounded-3xl overflow-hidden border-2 transition-all duration-300 ${
                    selectedAvatar === avatar.id ? 'border-[#D4AF37] shadow-2xl shadow-[#D4AF37]/10 scale-95' : 'border-white/5 hover:border-white/10'
                  }`}
                >
                  <img 
                    src={avatar.image} 
                    alt={avatar.name} 
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      // Fallback to UI Avatar generator if external image fails
                      (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(avatar.name)}&background=142850&color=D4AF37&bold=true&size=400`;
                    }}
                    className={`w-full h-full object-cover transition-transform duration-700 ${selectedAvatar === avatar.id ? 'scale-110 grayscale-0' : 'grayscale-[0.5] group-hover:grayscale-0 group-hover:scale-105'}`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#142850] via-transparent to-transparent opacity-90" />
                  <div className="absolute bottom-0 inset-x-0 p-4 text-left">
                    <p className="text-sm font-bold text-white">{avatar.name}</p>
                    <div className="inline-block px-2 py-0.5 mt-1 bg-[#0B1B3D]/80 border border-[#D4AF37]/30 rounded-md">
                      <span className="text-[8px] font-bold text-[#D4AF37] uppercase tracking-tighter">{avatar.niche}</span>
                    </div>
                  </div>
                  {selectedAvatar === avatar.id && (
                    <div className="absolute top-4 right-4 p-1.5 bg-[#D4AF37] rounded-full shadow-lg animate-in zoom-in-50">
                      <UserCheck className="w-4 h-4 text-[#0B1B3D]" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </section>

            </>
          ) : (
            <>
              <section className="space-y-6">
                <div className="flex items-center justify-between px-2">
                  <h2 className="text-sm font-bold text-[#D4AF37] uppercase tracking-widest flex items-center gap-2">
                    <ScanFace className="w-4 h-4" /> Custom Identity Mesh
                  </h2>
                  <span className="text-[10px] text-[#7C8AA8] bg-white/5 px-2 py-1 rounded-full uppercase">Local Mockup</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Upload Area */}
                  <div 
                    onClick={() => setCustomAvatarImage('https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop')}
                    className={`border-2 border-dashed ${customAvatarImage ? 'border-[#D4AF37]' : 'border-white/20 hover:border-[#D4AF37]/50'} rounded-2xl p-6 flex flex-col items-center justify-center gap-4 cursor-pointer transition-all bg-[#142850]/30 min-h-[200px] relative overflow-hidden group`}
                  >
                    {customAvatarImage ? (
                      <>
                        <img src={customAvatarImage} className="absolute inset-0 w-full h-full object-cover opacity-60" alt="Custom Base" />
                        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-colors flex items-center justify-center">
                          <ImagePlus className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-[#7C8AA8] group-hover:text-[#D4AF37] transition-colors">
                          <Upload className="w-8 h-8" />
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-bold text-white">Upload Face Source</p>
                          <p className="text-[10px] text-slate-400 mt-1">JPEG/PNG up to 10MB</p>
                          <p className="text-[10px] text-[#D4AF37] mt-2 italic">(Click to load placeholder)</p>
                        </div>
                      </>
                    )}
                  </div>
                  
                  {/* Configuration */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avatar Name</label>
                      <input 
                        type="text" 
                        value={customAvatarName}
                        onChange={(e) => setCustomAvatarName(e.target.value)}
                        className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#D4AF37] transition-colors"
                        placeholder="e.g. CEO Message"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Voice Synthesis Profile</label>
                      <div className="relative">
                        <select className="w-full appearance-none bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#D4AF37] transition-colors">
                          <option>Premium Female (US-Journey-F)</option>
                          <option>Premium Male (US-Journey-D)</option>
                          <option>British Professional (UK-News)</option>
                          <option>Australian Casual (AU-Vlog)</option>
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7C8AA8] pointer-events-none" />
                      </div>
                    </div>
                    
                    <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                       <p className="text-[10px] text-emerald-400 font-medium flex items-center gap-1.5">
                         <CheckCircle2 className="w-3.5 h-3.5" /> 
                         Likeness rights verified (Mock)
                       </p>
                    </div>
                  </div>
                </div>
              </section>
            </>
          )}

          {/* Script Conversion Form */}
          <section className="bg-[#142850] border border-white/5 rounded-3xl p-8 space-y-6 shadow-2xl">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Script Topic</label>
                  <input type="text" placeholder="e.g. Benefits of Bananas" className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none" id="scriptTopic" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Tone</label>
                  <input type="text" placeholder="e.g. Enthusiastic" className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none" id="scriptTone" />
                </div>
              </div>
              <button
                onClick={async () => {
                  const topic = (document.getElementById('scriptTopic') as HTMLInputElement).value;
                  const tone = (document.getElementById('scriptTone') as HTMLInputElement).value;
                  if (!topic) return;
                  setIsGenerating(true);
                  setGenerationStep('Generating script with Gemini...');
                  const res = await fetch('/api/generate-avatar-script', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ topic, tone })
                  });
                  const data = await res.json();
                  if (data.script) setScript(data.script);
                  setIsGenerating(false);
                  setGenerationStep('');
                }}
                className="w-full py-3 bg-[#142850] border border-[#D4AF37]/30 text-[#D4AF37] rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-[#D4AF37]/10 transition-all"
              >
                Generate Script with Gemini
              </button>
              
              <div className="flex items-center gap-2 px-1 pt-4">
                <FileText className="w-5 h-5 text-[#D4AF37]" />
                <label className="text-sm font-bold text-white uppercase tracking-wider">Input Synthetic Script Prose</label>
              </div>
              <textarea
                value={script}
                onChange={(e) => setScript(e.target.value)}
                placeholder="Paste your ad copy script here..."
                rows={6}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-6 py-4 text-white placeholder:text-white/20 focus:border-[#D4AF37] outline-none transition-all resize-none shadow-inner"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-bold tracking-widest px-1">Select Native Voice Profile</label>
                <div className="relative">
                  <select 
                    value={voiceProfile}
                    onChange={(e) => setVoiceProfile(e.target.value)}
                    className="w-full bg-[#0B1B3D] border border-white/10 text-white rounded-2xl px-5 py-3 appearance-none focus:border-[#D4AF37] outline-none cursor-pointer"
                  >
                    <option value="american-natural">American - Natural Male</option>
                    <option value="american-soft">American - Soft Female</option>
                    <option value="british-r">British - Received Pronunciation</option>
                    <option value="australian-n">Australian - Narrative</option>
                  </select>
                  <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7C8AA8] pointer-events-none" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-bold tracking-widest px-1">Accent Multipliers</label>
                <div className="flex gap-2">
                  {['Excited', 'Professional', 'Whisper'].map(mode => (
                    <button key={mode} onClick={() => setAccent(mode)} className={`flex-1 py-3 bg-[#0B1B3D] border ${accent === mode ? 'border-[#D4AF37] text-[#D4AF37]' : 'border-white/5 hover:border-[#D4AF37]/30 text-[#7C8AA8] hover:text-[#D4AF37]'} rounded-2xl text-[10px] font-bold transition-all`}>
                      {mode}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !selectedAvatar || !script.trim()}
              className="w-full py-5 bg-[#D4AF37] hover:bg-[#E3C48F] disabled:bg-white/5 disabled:text-[#7C8AA8] text-[#0B1B3D] font-black text-sm uppercase tracking-[0.2em] rounded-2xl transition-all flex items-center justify-center gap-3 shadow-xl shadow-[#D4AF37]/10 group"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span className="animate-pulse">{generationStep || 'Processing Neural Frames...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 group-hover:animate-pulse" />
                  <span>🚀 Generate Stock Avatar Ad Variation</span>
                </>
              )}
            </button>
          </section>
        </div>

        {/* Sidebar: 9:16 Preview Container */}
        <div className="lg:col-span-4 sticky top-6 space-y-6">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest">Synthetic Output Preview</h3>
            <div className="px-2 py-0.5 bg-rose-500/10 border border-rose-500/30 rounded text-[8px] text-rose-500 font-bold uppercase">9:16 Vertical</div>
          </div>
          
          <div className="aspect-[9/16] bg-[#142850] rounded-[2.5rem] border-8 border-[#0B1B3D] shadow-2xl overflow-hidden relative group ring-1 ring-white/10">
            {generatedOutput ? (
              <div className="relative w-full h-full overflow-hidden group/video bg-[#0B1B3D]">
                {/* Avatar Image with talking animation */}
                <img 
                   src={generatedOutput.avatarImage} 
                   alt={generatedOutput.avatarName}
                   className={`w-full h-full object-cover transition-transform duration-[10000ms] ${isPlaying ? 'scale-110' : 'scale-100'} ${isPlaying ? 'animate-pulse' : ''}`}
                />
                
                {/* Talking Indicator / Lipsync simulation overlay */}
                {isPlaying && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-30 mix-blend-overlay">
                     <div className="w-32 h-32 bg-white rounded-full blur-3xl animate-ping" style={{ animationDuration: '0.5s' }} />
                  </div>
                )}
                
                {/* Simulated Captions */}
                <div className="absolute bottom-32 left-4 right-4 flex flex-col items-center justify-end text-center pointer-events-none">
                  {isPlaying && (
                    <div className="bg-black/60 backdrop-blur-sm px-4 py-3 rounded-xl border border-white/10 animate-fade-in shadow-2xl">
                       <p className="text-white font-bold text-lg leading-tight shadow-black drop-shadow-md">
                         {generatedOutput.scriptText.split(' ').map((word, i, arr) => {
                           const pastChars = arr.slice(0, i).join(' ').length + (i > 0 ? 1 : 0);
                           const isCurrent = isPlaying && currentCharIndex >= pastChars && currentCharIndex <= pastChars + word.length;
                           return (
                             <span key={i} className={`transition-colors duration-200 ${isCurrent ? 'text-[#D4AF37]' : 'text-white'} mr-1`}>
                               {word}
                             </span>
                           );
                         })}
                       </p>
                    </div>
                  )}
                </div>

                {/* Simulated Audio Waveform / Playing indicator */}
                {isPlaying && (
                  <div className="absolute top-24 left-1/2 -translate-x-1/2 flex items-center gap-1 opacity-70">
                     {[...Array(5)].map((_, i) => (
                       <div key={i} className="w-1.5 bg-[#D4AF37] rounded-full animate-pulse" style={{ height: `${Math.random() * 24 + 8}px`, animationDelay: `${i * 0.15}s` }} />
                     ))}
                  </div>
                )}

                {/* Overlays / Controls */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/video:opacity-100 transition-opacity flex flex-col items-center justify-center gap-6">
                  
                  <button 
                    onClick={() => {
                      if (isPlaying) {
                        window.speechSynthesis.cancel();
                        setIsPlaying(false);
                        setCurrentCharIndex(0);
                      } else {
                        setCurrentCharIndex(0);
                        const utterance = new SpeechSynthesisUtterance(generatedOutput.scriptText);
                        
                        // Attempt to find a more natural voice
                        const voices = window.speechSynthesis.getVoices();
                        const isMale = ['Marcus', 'David', 'Jordan', 'Kaito'].includes(generatedOutput.avatarName);
                        
                        let bestVoice = voices.find(v => 
                          v.lang.startsWith('en') && 
                          (v.name.includes('Google') || v.name.includes('Premium') || v.name.includes('Online')) &&
                          (isMale ? v.name.includes('Male') || v.name.toLowerCase().includes('david') || v.name.toLowerCase().includes('daniel') 
                                  : v.name.includes('Female') || v.name.toLowerCase().includes('samantha') || v.name.toLowerCase().includes('zira'))
                        );
                        
                        if (!bestVoice) {
                           bestVoice = voices.find(v => v.lang.startsWith('en-US') && (isMale ? v.name.includes('Male') : v.name.includes('Female')));
                        }
                        
                        if (bestVoice) {
                          utterance.voice = bestVoice;
                        }

                        utterance.rate = 0.95; // Slightly slower for natural feel
                        utterance.pitch = isMale ? 0.9 : 1.1;
                        
                        utterance.onboundary = (e) => {
                          if (e.name === 'word') {
                            setCurrentCharIndex(e.charIndex);
                          }
                        };
                        utterance.onend = () => {
                           setIsPlaying(false);
                           setCurrentCharIndex(0);
                        };
                        window.speechSynthesis.speak(utterance);
                        setIsPlaying(true);
                      }
                    }}
                    className={`p-5 rounded-full shadow-2xl transition-transform hover:scale-110 ${isPlaying ? 'bg-rose-500 hover:bg-rose-600' : 'bg-[#D4AF37] hover:bg-[#E3C48F]'}`}
                  >
                    {isPlaying ? <div className="w-6 h-6 bg-white rounded-sm" /> : <MonitorPlay className="w-6 h-6 text-[#0B1B3D] ml-1" />}
                  </button>
                  
                  <div className="flex gap-4">
                    <button 
                      onClick={() => {
                         window.speechSynthesis.cancel();
                         setIsPlaying(false);
                         setGeneratedOutput(null);
                      }}
                      className="p-3 bg-rose-500/80 rounded-full hover:bg-rose-600 transition-colors shadow-lg"
                      title="Delete Video"
                    >
                      <Users className="w-5 h-5 rotate-45" />
                    </button>
                    <button 
                      onClick={handleGenerate}
                      className="p-3 bg-[#D4AF37]/80 rounded-full hover:bg-[#E3C48F] transition-colors shadow-lg"
                      title="Redo Generation"
                    >
                      <Wand2 className="w-5 h-5 text-[#0B1B3D]" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center space-y-4">
                <div className={`w-16 h-16 bg-[#0B1B3D] rounded-full flex items-center justify-center ${isGenerating ? 'animate-bounce' : 'animate-pulse'}`}>
                  {isGenerating ? (
                    <Loader2 className="w-8 h-8 text-[#D4AF37] animate-spin" />
                  ) : (
                    <MonitorPlay className="w-8 h-8 text-[#7C8AA8]/30" />
                  )}
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-[#7C8AA8]">{isGenerating ? 'Synthesizing...' : 'No Output Loaded'}</p>
                  <p className="text-[10px] text-[#7C8AA8]/50 leading-relaxed">
                    {isGenerating ? generationStep : 'Select an avatar and input a script to begin vertical synthesis.'}
                  </p>
                </div>
              </div>
            )}

            {/* Brand Parameter Overlays */}
            <div className="absolute top-6 left-6 right-6 flex justify-between">
              <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center">
                <div className="w-3 h-3 bg-[#D4AF37] rounded-full" />
              </div>
              <div className="px-3 py-1 bg-black/40 backdrop-blur-md rounded-full border border-white/20">
                <span className="text-[8px] font-mono text-white tracking-widest">REC 00:00:00</span>
              </div>
            </div>

            <div className="absolute bottom-8 left-6 right-6">
              <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/20 space-y-2">
                <div className="h-1 bg-white/20 rounded-full overflow-hidden">
                  <div className="h-full bg-[#D4AF37] w-1/3" />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[8px] text-white/70 font-mono">NEURAL_DUB_V1.0</span>
                  <span className="text-[8px] text-[#D4AF37] font-bold">BLOOM STUDIO</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#142850]/50 border border-white/5 rounded-2xl p-4">
            <h4 className="text-[10px] font-bold text-[#7C8AA8] uppercase tracking-widest mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-3 h-3 text-[#D4AF37]" /> Operational Compliance
            </h4>
            <p className="text-[9px] text-[#7C8AA8]/70 leading-relaxed">
              This dashboard is for asset compilation only. Financial data, director ledgers, and team compensation records are strictly masked from this workspace.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StockAvatarStudio;
