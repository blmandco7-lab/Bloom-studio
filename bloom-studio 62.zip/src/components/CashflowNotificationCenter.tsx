import React, { useState } from 'react';
import { Bell, AlertTriangle, CheckCircle2, DollarSign, Clock, ShieldAlert, ArrowRight, X } from 'lucide-react';
import { UserProfileWithRole } from './ManagerCommissionLog';

export interface SystemCashflowAlert {
  id: string;
  type: 'PAYOUT_DISBURSED' | 'OVERDUE_INVOICE_DIRECTOR';
  recipientRoleTarget: 'AllStaff' | 'DirectorOnly' | 'CreatorOnly';
  campaignName: string;
  brandName: string;
  grossContractValue?: number;
  paymentTerms?: string;
  message: string;
  timestamp: string;
  read: boolean;
}

interface CashflowNotificationCenterProps {
  currentUser: UserProfileWithRole;
  initialAlerts?: SystemCashflowAlert[];
}

/**
 * CashflowNotificationCenter:
 * Automated background notification and reminder framework.
 * 
 * MODULE 1: Staff & Creator Pay Release Alerts (Broad Distribution)
 * MODULE 2: Automated Owner Past-Due Invoice Reminder (Exclusively Director Dashboard)
 */
export default function CashflowNotificationCenter({
  currentUser,
  initialAlerts = [
    {
      id: "alert_1",
      type: "OVERDUE_INVOICE_DIRECTOR",
      recipientRoleTarget: "DirectorOnly",
      campaignName: "Botanical Silk Body Oil Launch",
      brandName: "Velvet Home Botanics",
      grossContractValue: 18500,
      paymentTerms: "Net 30",
      message: "⚠️ CRITICAL OUTSTANDING BALANCE: Velvet Home Botanics - Botanical Silk Body Oil Launch is currently past due on their Net 30 agreement. Total Gross Inbound Outstanding: $18,500.00.",
      timestamp: "Today at 08:30 AM",
      read: false
    },
    {
      id: "alert_2",
      type: "PAYOUT_DISBURSED",
      recipientRoleTarget: "AllStaff",
      campaignName: "Summer Glow Botanical Serum",
      brandName: "GlowLab Beauty",
      message: "Notification: Funds for Summer Glow Botanical Serum have cleared. Your payout has been disbursed to your ledger.",
      timestamp: "Yesterday at 04:15 PM",
      read: false
    }
  ]
}: CashflowNotificationCenterProps) {
  const isDirector = currentUser.role === 'Owner' || currentUser.role === 'Director';
  const [alerts, setAlerts] = useState<SystemCashflowAlert[]>(initialAlerts);

  // Filter alerts based on role
  const visibleAlerts = alerts.filter(alert => {
    if (alert.recipientRoleTarget === 'DirectorOnly') {
      return isDirector;
    }
    return true;
  });

  const dismissAlert = (id: string) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  };

  const markAllRead = () => {
    setAlerts(prev => prev.map(a => ({ ...a, read: true })));
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Top Overdue Critical Alerts for Director */}
      {isDirector && visibleAlerts.filter(a => a.type === 'OVERDUE_INVOICE_DIRECTOR').map((alert) => (
        <div
          key={alert.id}
          className="bg-amber-950/80 border-2 border-amber-500/60 rounded-3xl p-5 shadow-2xl text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-pulse"
        >
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-amber-400 bg-amber-900/60 border border-amber-500/30 px-2 py-0.5 rounded-full">
                Director Past-Due Settlement Alert
              </span>
              <h4 className="text-sm font-bold text-white mt-1">
                Outstanding Brand Inbound Collection
              </h4>
              <p className="text-xs text-amber-200 mt-0.5 leading-relaxed font-mono">
                {alert.message}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center">
            <button
              type="button"
              onClick={() => dismissAlert(alert.id)}
              className="text-xs font-mono bg-amber-900/80 hover:bg-amber-800 text-amber-200 px-3.5 py-2 rounded-xl transition-all cursor-pointer border border-amber-500/40"
            >
              Acknowledge &amp; Send Follow-Up
            </button>
          </div>
        </div>
      ))}

      {/* General Notification Panel */}
      <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-5 shadow-xl text-agency-textLight space-y-4">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <Bell className="w-4 h-4 text-agency-gold" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-white">
              Cashflow &amp; Ledger Notification Stream
            </h3>
            <span className="text-[10px] font-mono text-agency-gold bg-agency-navy border border-agency-gold/30 px-2 py-0.5 rounded-full">
              {visibleAlerts.length} Active
            </span>
          </div>

          {visibleAlerts.length > 0 && (
            <button
              type="button"
              onClick={markAllRead}
              className="text-[11px] font-mono text-slate-400 hover:text-agency-gold transition-colors cursor-pointer"
            >
              Mark all as read
            </button>
          )}
        </div>

        <div className="space-y-2.5">
          {visibleAlerts.length === 0 ? (
            <p className="text-xs text-slate-400 font-mono py-3 text-center">
              Zero pending cashflow alerts or overdue notices.
            </p>
          ) : (
            visibleAlerts.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                  item.type === 'OVERDUE_INVOICE_DIRECTOR'
                    ? 'bg-amber-950/40 border-amber-500/30'
                    : 'bg-agency-navy border-white/10'
                }`}
              >
                <div className="flex items-start gap-3">
                  {item.type === 'PAYOUT_DISBURSED' ? (
                    <div className="w-8 h-8 rounded-xl bg-emerald-950/60 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded-xl bg-amber-950/60 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                  )}

                  <div className="space-y-0.5">
                    <p className="text-xs text-white leading-relaxed font-sans">
                      {item.message}
                    </p>
                    <span className="text-[10px] font-mono text-slate-400 block">
                      {item.timestamp}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => dismissAlert(item.id)}
                  className="text-slate-400 hover:text-white p-1 transition-colors cursor-pointer"
                  title="Dismiss notification"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
