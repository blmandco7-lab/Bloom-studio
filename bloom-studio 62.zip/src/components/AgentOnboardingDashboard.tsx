import React, { useState, useEffect } from 'react';
import { 
  UserPlus, ShieldCheck, CheckCircle2, Clock, AlertTriangle, FileText, 
  Award, Lock, ArrowRight, Sparkles, Sliders, Check, ExternalLink, RefreshCw, Send,
  FileCheck, PenTool, Landmark, DollarSign, Download, Upload, Play
} from 'lucide-react';
import { generateOfficialW9Pdf, generateOfficial1099NecPdf } from '../lib/w9PdfGenerator';
import { AgencyDebitCard } from './AgencyDebitCard';
import { doc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import PrivacyPolicyModal from './PrivacyPolicyModal';

export interface AgentOnboardingStep {
  id: string;
  title: string;
  desc: string;
  category: string;
  selfChecked: boolean;
  verified: boolean;
  requiredForLaunch: boolean;
}

interface AgentOnboardingDashboardProps {
  currentUser?: any;
  currentRole?: string;
  targetStaffId?: string; // New prop: if provided, show progress for this specific staff member
  targetStaffName?: string; // New prop: display name for the staff member
  triggerNotification?: (title: string, message: string, type?: string) => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  onComplete?: () => void;
  onNavigateToScreen?: (screenId: string) => void;
}

export default function AgentOnboardingDashboard({
  currentUser,
  currentRole = 'agentmgr',
  targetStaffId,
  targetStaffName,
  triggerNotification,
  onAddActivityLog,
  onComplete,
  onNavigateToScreen
}: AgentOnboardingDashboardProps) {
  const effectiveRole = (currentRole || '').toLowerCase();
  const isDirector = effectiveRole === 'director' || effectiveRole === 'owner' || effectiveRole === 'agency';

  // The ID used for data persistence. Defaults to currentUser.id if not looking at someone else.
  const activeStaffId = targetStaffId || currentUser?.id || 'default_staff';
  const activeStaffName = targetStaffName || currentUser?.name || 'Staff Member';

  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [payoutType, setPayoutType] = useState<'paypal' | 'debit'>('paypal');
  const [paypalAccountEmail, setPaypalAccountEmail] = useState(currentUser?.email || 'manager@agency.com');
  const [debitCardNum, setDebitCardNum] = useState('4000 1234 5678 8842');
  const [debitExp, setDebitExp] = useState('12/28');
  const [debitCvv, setDebitCvv] = useState('123');
  const [isPayoutConfigured, setIsPayoutConfigured] = useState(() => {
    return localStorage.getItem('wl_agent_payout_configured') === 'true';
  });

  // Privacy Policy Modal State
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [privacyAcknowledged, setPrivacyAcknowledged] = useState(false);

  // IRS W-9 & 1099 Fillable Form Modal States
  const [showTaxModal, setShowTaxModal] = useState(false);
  const [taxTab, setTaxTab] = useState<'w9' | '1099' | 'signoff'>('w9');
  const [w9Form, setW9Form] = useState({
    legalName: currentUser?.name || 'Staff Legal Name',
    businessName: '',
    taxClassification: 'Individual/Sole Proprietor',
    taxIdType: 'SSN' as 'SSN' | 'EIN',
    taxId: '',
    address: '100 Grand Ave, Suite 400',
    cityStateZip: 'Los Angeles, CA 90071',
    signatureText: currentUser?.name || 'Staff Legal Name',
    signatureDate: new Date().toISOString().split('T')[0],
    perjuryCert: false
  });

  const DEFAULT_STEPS: AgentOnboardingStep[] = [
    // Category: Legal Identity Verification
    {
      id: 'step_legal_name',
      title: 'Full Legal Name Verification',
      desc: 'Must match government-issued ID exactly (no nicknames) for payroll and contract verification.',
      category: 'Legal Identity Verification',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_gov_id',
      title: 'Government-Issued Photo ID',
      desc: 'Upload color scan of Driver’s License, State ID, or Passport to verify identity and residency.',
      category: 'Legal Identity Verification',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_background_check',
      title: 'Authorized Background Screen',
      desc: 'Completed consent signature for third-party criminal and credit background check.',
      category: 'Legal Identity Verification',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    // Category: IRS Tax & Independent Contractor Documentation
    {
      id: 'step_contract',
      title: 'Signed Independent Contractor Agreement',
      desc: 'Executed master employment contract detailing responsibilities, duties, and compensation boundaries [9hqWU2].',
      category: 'IRS Tax & Documentation',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_w9',
      title: 'IRS Form W-9 (Request for Taxpayer ID)',
      desc: 'Completed and signed IRS W-9 form capturing Full Name, Business Entity Type, Address, and SSN or EIN.',
      category: 'IRS Tax & Documentation',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_1099_signoff',
      title: '1099 Classification Sign-off',
      desc: 'Legal declaration form signed by the manager acknowledging 1099 Independent Contractor status and tax responsibilities.',
      category: 'IRS Tax & Documentation',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    // Category: Professional Experience & Industry Credentials
    {
      id: 'step_portfolio',
      title: 'Verified Portfolio / Work History',
      desc: 'Proof of previous talent management, campaign coordination, or digital marketing experience.',
      category: 'Experience & Credentials',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_references',
      title: 'Reference Verification',
      desc: 'Contact information for at least two professional industry references to verify past conduct.',
      category: 'Experience & Credentials',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    // Category: Core System & Security Infrastructure
    {
      id: 'step_device_token',
      title: 'Verified Personal Device Token',
      desc: 'Confirmation that personal laptop or tablet runs an updated, encrypted OS with an active passcode.',
      category: 'System & Security',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_corporate_email',
      title: 'Corporate Email Provisioning',
      desc: 'Setting up custom agency inbox (e.g., name@yourdomain.com) to route traffic through filters.',
      category: 'System & Security',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_privacy_policy',
      title: 'Master Privacy Policy & GDPR/CCPA Sign-Off',
      desc: 'Mandatory review and acknowledgment of creator data isolation, encryption policies, and strict compliance boundaries.',
      category: 'System & Security',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    // Category: Specialized Management Training
    {
      id: 'step_training_phase_1',
      title: 'Security & Auth Set Training',
      desc: 'Complete Phase 1 video and procedure sheet for technical security provisioning.',
      category: 'Management Training',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_training_phase_2',
      title: 'Compliance Systems Training',
      desc: 'Complete Phase 2 video and procedure sheet for content policing and FTC audit mastery.',
      category: 'Management Training',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    },
    {
      id: 'step_training_phase_3',
      title: 'Timeline & SOP Training',
      desc: 'Complete Phase 3 training for 48h review windows and production calendar enforcement.',
      category: 'Management Training',
      selfChecked: false,
      verified: false,
      requiredForLaunch: true
    }
  ];

  // Load persistent onboarding state
  const [steps, setSteps] = useState<AgentOnboardingStep[]>(DEFAULT_STEPS);
  const [loading, setLoading] = useState(true);

  // Firestore Real-time Sync
  useEffect(() => {
    if (!activeStaffId) {
      setLoading(false);
      return;
    }

    try {
      const staffRef = doc(db, 'staff_onboarding', activeStaffId);

      const unsubscribe = onSnapshot(staffRef, (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.steps) {
            // Merge default steps with saved data to handle potential schema updates
            setSteps(DEFAULT_STEPS.map(ds => {
              const match = data.steps.find((s: any) => s.id === ds.id);
              if (match) {
                return {
                  ...ds,
                  selfChecked: match.selfChecked ?? false,
                  verified: match.verified ?? false
                };
              }
              return ds;
            }));
          }
        } else {
          // First time initialization for this staff member
          setSteps(DEFAULT_STEPS);
        }
        setLoading(false);
      }, (err) => {
        console.warn("Firestore onSnapshot error:", err);
        setLoading(false);
      });

      return () => unsubscribe();
    } catch (err) {
      console.warn("Firestore setup error:", err);
      setLoading(false);
    }
  }, [activeStaffId]);

  // Calculate progress stats
  const verifiedCount = steps.filter(s => s.verified).length;
  const selfCheckedCount = steps.filter(s => s.selfChecked).length;
  const totalCount = steps.length;
  const progressPercent = Math.round((verifiedCount / totalCount) * 100);

  // Update Firestore
  const updateOnboardingInDb = async (newSteps: AgentOnboardingStep[]) => {
    try {
      const staffRef = doc(db, 'staff_onboarding', activeStaffId);
      await setDoc(staffRef, { 
        steps: newSteps, 
        updatedAt: new Date().toISOString(),
        staffName: activeStaffName,
        progress: Math.round((newSteps.filter(s => s.verified).length / newSteps.length) * 100)
      }, { merge: true });
    } catch (e) {
      console.error("Error updating onboarding:", e);
    }
  };

  // Toggle Manager Self-Check (for keeping track of personal progress)
  const handleToggleSelfCheck = async (id: string) => {
    const newSteps = steps.map(s => {
      if (s.id === id) {
        const nextSelf = !s.selfChecked;
        if (triggerNotification) {
          triggerNotification(
            "Progress Updated", 
            `Step "${s.title}" marked as ${nextSelf ? 'Checked Off by Staff' : 'Pending Check-off'}. (Awaiting Director Verification)`, 
            nextSelf ? 'info' : 'warning'
          );
        }
        return { ...s, selfChecked: nextSelf };
      }
      return s;
    });

    setSteps(newSteps);
    await updateOnboardingInDb(newSteps);

    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || (isDirector ? "Director" : "Staff Member"), 
        currentRole, 
        `Updated self check-off on onboarding step ${id} for ${activeStaffName}`
      );
    }
  };

  // Toggle Director Verification (Only Director can verify)
  const handleDirectorVerifyStep = async (id: string) => {
    if (!isDirector) {
      if (triggerNotification) {
        triggerNotification("Director Verification Required", "Only the Agency Director can mark steps as Official Verified.", "warning");
      }
      return;
    }

    const newSteps = steps.map(s => {
      if (s.id === id) {
        const nextVerified = !s.verified;
        if (triggerNotification) {
          triggerNotification(
            "Director Verification", 
            `Step "${s.title}" ${nextVerified ? 'Officially VERIFIED by Director' : 'Verification Revoked'}.`, 
            nextVerified ? 'success' : 'warning'
          );
        }
        return { 
          ...s, 
          verified: nextVerified,
          selfChecked: nextVerified ? true : s.selfChecked 
        };
      }
      return s;
    });

    setSteps(newSteps);
    await updateOnboardingInDb(newSteps);

    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "User", currentRole, `Director toggled official verification on step ${id} for ${activeStaffName}`);
    }
  };

  const handleRequestDirectorApproval = () => {
    if (triggerNotification) {
      triggerNotification(
        "Verification Request Transmitted",
        "Your onboarding check-offs have been transmitted to the Director Console for official verification and clearance.",
        "success"
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "Agent Manager", currentRole, "Requested official Director verification on onboarding steps");
    }
  };

  return (
    <div className="w-full bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6 font-sans text-agency-textLight max-w-5xl mx-auto animate-fadeIn">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full flex items-center gap-1.5">
              <UserPlus className="w-3.5 h-3.5" />
              Agent Manager Onboarding Hub
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Staff Clearance &amp; Verification
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5">
            Agent & Staff Onboarding Checklist
          </h2>
          <p className="text-xs text-slate-400">
            Check off steps to track your onboarding progress. Official verification is granted by the Director.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isDirector ? (
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3.5 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Director Verification Console Active
            </span>
          ) : (
            <span className="bg-agency-navy border border-agency-gold/30 text-agency-gold px-3.5 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" /> Director Verification Required
            </span>
          )}
        </div>
      </div>

      {/* Progress Bar Card */}
      <div className="bg-[#091322] border-2 border-[#C9A46A]/40 rounded-2xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold tracking-widest block">
              Director-Verified Clearance
            </span>
            <h3 className="text-xl font-bold font-mono text-white flex items-center gap-2">
              <span>{progressPercent}% Director Verified</span>
              {progressPercent === 100 && (
                <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-sans font-semibold">
                  100% Certified Agent Manager
                </span>
              )}
            </h3>
          </div>

          <div className="text-right font-mono text-xs text-slate-300">
            <div><span className="text-emerald-400 font-bold">{verifiedCount}</span> / <span>{totalCount} Director Verified</span></div>
            <div className="text-[11px] text-slate-400 font-sans mt-0.5">{selfCheckedCount} / {totalCount} Self-Checked</div>
          </div>
        </div>

        {/* Progress Bar Track */}
        <div className="w-full bg-[#16243F] rounded-full h-4 overflow-hidden p-0.5 border border-white/10 relative">
          <div 
            className="bg-gradient-to-r from-[#b89359] via-[#C9A46A] to-[#E3C48F] h-full rounded-full transition-all duration-700 ease-out shadow-lg"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-agency-gold" />
            Clearance Status: {progressPercent === 100 ? 'Fully Approved & Active' : 'In Progress (Awaiting Director Sign-off)'}
          </span>
          <span>
            {isDirector ? 'Director Override Active' : 'Check off steps below to update your status'}
          </span>
        </div>
      </div>

      {/* Onboarding Checklist Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-agency-gold" />
            Verification Milestones &amp; Manager Checklist
          </h3>
          {!isDirector && (
            <button
              onClick={handleRequestDirectorApproval}
              className="text-xs font-mono text-agency-gold hover:text-white bg-agency-navy border border-agency-gold/30 hover:border-agency-gold px-3.5 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Notify Director for Verification
            </button>
          )}
        </div>

        <div className="space-y-3">
          {steps.map((step) => (
            <div 
              key={step.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                step.verified
                  ? 'bg-[#0b182d]/90 border-emerald-500/40' 
                  : step.selfChecked
                  ? 'bg-[#091528] border-sky-500/30'
                  : 'bg-[#091322] border-white/10 hover:border-agency-gold/30'
              }`}
            >
              <div className="flex items-start gap-3.5">
                {/* Manager Self-Check Box */}
                <button
                  type="button"
                  title={step.selfChecked ? 'Click to uncheck personal progress' : 'Click to check off personal progress'}
                  onClick={() => handleToggleSelfCheck(step.id)}
                  className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all cursor-pointer mt-0.5 shrink-0 ${
                    step.selfChecked 
                      ? 'bg-sky-500 border-sky-400 text-slate-950' 
                      : 'bg-agency-navy border-white/20 hover:border-agency-gold text-transparent'
                  }`}
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                </button>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm text-white font-sans">{step.title}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-agency-navy border border-white/10 text-agency-gold">
                      {step.category}
                    </span>
                    {step.requiredForLaunch && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950/60 text-rose-300 border border-rose-500/30">
                        Mandatory
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400">
                    {step.desc}
                  </p>

                  {/* Contextual Action Buttons */}
                  <div className="flex items-center gap-2 flex-wrap pt-1.5">
                    {step.id === 'step_w9' && (
                      <button
                        type="button"
                        onClick={() => {
                          setTaxTab('w9');
                          setShowTaxModal(true);
                        }}
                        className="bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-3.5 py-1.5 rounded-lg shadow transition cursor-pointer flex items-center gap-1.5"
                      >
                        <FileCheck className="w-3.5 h-3.5" />
                        {step.selfChecked ? 'View / Re-sign IRS W-9 Documents' : 'Fill Out & Sign IRS Form W-9'}
                      </button>
                    )}
                    {step.id === 'step_1099_signoff' && (
                      <button
                        type="button"
                        onClick={() => {
                          setTaxTab('signoff');
                          setShowTaxModal(true);
                        }}
                        className="bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-3.5 py-1.5 rounded-lg shadow transition cursor-pointer flex items-center gap-1.5"
                      >
                        <PenTool className="w-3.5 h-3.5" />
                        {step.selfChecked ? 'View 1099 Classification Sign-off' : 'Sign 1099 Classification Declaration'}
                      </button>
                    )}
                    {(step.id === 'step_gov_id' || step.id === 'step_portfolio' || step.id === 'step_contract') && (
                      <button
                        type="button"
                        onClick={() => triggerNotification && triggerNotification("Secure Upload Active", `Please drag and drop your files into the vault for ${step.title}.`, "info")}
                        className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs px-3.5 py-1.5 rounded-lg shadow transition cursor-pointer flex items-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        Upload {step.id === 'step_contract' ? 'Signed Agreement' : 'Verification File'}
                      </button>
                    )}
                    {(step.id === 'step_background_check' || step.id === 'step_references') && (
                      <button
                        type="button"
                        onClick={() => triggerNotification && triggerNotification("Verification Request Sent", `The Agency Director has been notified to verify your ${step.title.toLowerCase()}.`, "info")}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-1.5 rounded-lg shadow transition cursor-pointer flex items-center gap-1.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        Request {step.id === 'step_references' ? 'Reference' : 'Screening'} Verification
                      </button>
                    )}
                    {step.id === 'step_device_token' && (
                      <button
                        type="button"
                        onClick={() => {
                          handleToggleSelfCheck('step_device_token');
                          if (triggerNotification) triggerNotification("Device Token Generated", "A secure device encryption token has been generated and verified for your workspace login.", "success");
                        }}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-1.5 rounded-lg shadow transition cursor-pointer flex items-center gap-1.5"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        Generate & Verify Device Token
                      </button>
                    )}
                    {step.id === 'step_corporate_email' && (
                      <span className="text-[10px] text-agency-gold font-mono border border-agency-gold/20 px-2 py-1 rounded bg-agency-gold/5">
                        <ShieldCheck className="w-3 h-3 inline mr-1" /> Provisioning handled by Agency Director
                      </span>
                    )}
                    {step.id === 'step_privacy_policy' && (
                      <button
                        type="button"
                        onClick={() => setShowPrivacyModal(true)}
                        className="bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-3.5 py-1.5 rounded-lg shadow transition cursor-pointer flex items-center gap-1.5"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        {step.selfChecked ? 'Review Master Privacy Policy' : 'Review & Acknowledge Privacy Policy'}
                      </button>
                    )}
                    {step.category === 'Management Training' && (
                      <button
                        type="button"
                        onClick={() => onNavigateToScreen && onNavigateToScreen('agent-manager-training')}
                        className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs px-4 py-2 rounded-xl shadow-lg transition cursor-pointer flex items-center gap-2"
                      >
                        <Play className="w-3.5 h-3.5" />
                        Enter Training Portal
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Status Badges & Director Action */}
              <div className="shrink-0 flex items-center gap-2">
                {step.verified ? (
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Director Verified
                  </span>
                ) : step.selfChecked ? (
                  <span className="bg-sky-500/20 text-sky-300 border border-sky-500/30 px-3 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-sky-400" /> Self-Checked (Awaiting Director Verification)
                  </span>
                ) : (
                  <span className="bg-amber-500/10 text-amber-300 border border-amber-500/20 px-3 py-1 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-400" /> Pending Check-off
                  </span>
                )}

                {/* Director Verification Toggle Button */}
                {isDirector && (
                  <button
                    type="button"
                    onClick={() => handleDirectorVerifyStep(step.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer border flex items-center gap-1.5 ${
                      step.verified
                        ? 'bg-rose-950/60 hover:bg-rose-900 border-rose-500/40 text-rose-300'
                        : 'bg-emerald-600 hover:bg-emerald-500 border-emerald-400 text-white shadow-lg'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {step.verified ? 'Unverify (Director)' : 'Verify Step (Director)'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Director Notes & Guidelines Box */}
      <div className="bg-[#091322] border border-white/10 rounded-2xl p-5 space-y-3">
        <h4 className="text-xs font-mono font-bold text-[#C9A46A] uppercase tracking-wider flex items-center gap-2">
          <FileText className="w-4 h-4" />
          Staff Onboarding Policy & Requirements
        </h4>
        <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
          <p>
            1. <strong>Identity & Legal:</strong> All staff must provide government-issued photo ID and pass a background check before accessing agency data.
          </p>
          <p>
            2. <strong>Tax Classification:</strong> Managers operate as 1099 Independent Contractors and are responsible for their own tax filings.
          </p>
          <p>
            3. <strong>System Security:</strong> Personal devices must be encrypted and password-protected to route brand traffic securely.
          </p>
        </div>
      </div>

      {/* Submit / Finish Action */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-white/10">
        <span className="text-xs text-slate-400 font-mono">
          Agent Manager Onboarding v2.4 &bull; Syncs with Director Console
        </span>

        {isDirector ? (
          <button
            onClick={() => {
              if (triggerNotification) triggerNotification("Director Saved", "Onboarding progress saved for Agent Director.", "success");
              if (onComplete) onComplete();
            }}
            className="bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-6 py-3 rounded-xl shadow-lg transition cursor-pointer"
          >
            Save &amp; Return to Director Console
          </button>
        ) : (
          <button
            onClick={handleRequestDirectorApproval}
            className="bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-6 py-3 rounded-xl shadow-lg transition cursor-pointer flex items-center gap-2"
          >
            <Send className="w-4 h-4" />
            Submit Onboarding Progress to Director
          </button>
        )}
      </div>

      {/* PayPal / Agency Debit Card Setup Modal */}
      {showPayoutModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-[#0b1424] border border-agency-gold/40 rounded-3xl p-6 md:p-8 max-w-3xl w-full space-y-6 shadow-2xl relative my-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="text-lg font-bold text-white font-serif">Setup Staff Payroll Payout Wallet</h3>
                <p className="text-xs text-slate-400">Configure your official PayPal account or Agency Debit Card for direct payouts.</p>
              </div>

              <button
                type="button"
                onClick={() => setShowPayoutModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Payout Type Selector */}
            <div className="grid grid-cols-2 gap-2 bg-[#060b13] p-1.5 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => setPayoutType('paypal')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
                  payoutType === 'paypal'
                    ? 'bg-agency-gold text-agency-navy shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>PayPal Account</span>
              </button>

              <button
                type="button"
                onClick={() => setPayoutType('debit')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
                  payoutType === 'debit'
                    ? 'bg-agency-gold text-agency-navy shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>Agency Debit Card</span>
              </button>
            </div>

            {payoutType === 'paypal' ? (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-2xl text-[11px] text-blue-200">
                  ⚡ Official Agency Direct Option: Instant 0% fee deposit directly to your verified PayPal email on scheduled paydays.
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">PayPal Account Email</label>
                  <input
                    type="email"
                    value={paypalAccountEmail}
                    onChange={(e) => setPaypalAccountEmail(e.target.value)}
                    className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:border-agency-gold outline-none"
                    placeholder="manager@agency.com"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl text-[11px] text-emerald-200">
                  💳 Official Agency Debit Card Option: Corporate card ledger disbursement on scheduled paydays. Includes 3D card controls, instant escrow settlements, and Apple Wallet integration.
                </div>

                {/* Embedded Interactive Agency Debit Card */}
                <div className="bg-[#060b13] border border-white/10 rounded-2xl p-4 md:p-6">
                  <AgencyDebitCard 
                    creatorName={currentUser?.name || 'Staff Manager'}
                    creatorHandle={currentUser?.email ? `@${currentUser.email.split('@')[0]}` : '@manager'}
                    agencyName="Bloom & Co."
                    cardLast4={debitCardNum.slice(-4) || '4242'}
                    cardExpiry={debitExp || '08/29'}
                    balance={8450}
                    onTriggerNotification={triggerNotification}
                    onAddActivityLog={onAddActivityLog}
                  />
                </div>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setShowPayoutModal(false)}
                className="px-4 py-2.5 rounded-xl border border-white/15 text-slate-300 hover:text-white text-xs font-mono cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsPayoutConfigured(true);
                  localStorage.setItem('wl_agent_payout_configured', 'true');
                  handleToggleSelfCheck('step_3');
                  setShowPayoutModal(false);
                  if (triggerNotification) {
                    triggerNotification("Payroll Wallet Saved", "PayPal / Agency Debit Card payout wallet updated successfully.", "success");
                  }
                }}
                className="px-5 py-2.5 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs font-mono shadow-lg transition cursor-pointer flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Save &amp; Verify Payout Method
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IRS Form W-9 & 1099 Interactive Modal */}
      {showTaxModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-[#0b1424] border border-agency-gold/40 rounded-3xl p-6 md:p-8 max-w-2xl w-full space-y-6 shadow-2xl relative my-8">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono uppercase bg-amber-950/80 text-amber-300 border border-amber-500/40 px-2.5 py-0.5 rounded-full font-bold">
                    Official IRS Tax Documents
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white font-serif mt-1">
                  IRS Form W-9 &amp; Form 1099 Tax Center
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setShowTaxModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Document Tabs */}
            <div className="grid grid-cols-3 gap-2 bg-[#060b13] p-1.5 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => setTaxTab('w9')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
                  taxTab === 'w9'
                    ? 'bg-agency-gold text-agency-navy shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileCheck className="w-3.5 h-3.5" />
                <span>IRS W-9</span>
              </button>

              <button
                type="button"
                onClick={() => setTaxTab('signoff')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
                  taxTab === 'signoff'
                    ? 'bg-agency-gold text-agency-navy shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <PenTool className="w-3.5 h-3.5" />
                <span>1099 Sign-off</span>
              </button>

              <button
                type="button"
                onClick={() => setTaxTab('1099')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
                  taxTab === '1099'
                    ? 'bg-agency-gold text-agency-navy shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Landmark className="w-3.5 h-3.5" />
                <span>1099-NEC</span>
              </button>
            </div>

            {taxTab === 'w9' ? (
              <div className="space-y-4 text-xs">
                <div className="p-3.5 bg-agency-navy border border-agency-gold/30 rounded-2xl space-y-1">
                  <span className="font-bold text-agency-gold font-mono flex items-center gap-1.5">
                    <PenTool className="w-4 h-4" /> Official IRS Form W-9 Electronic Submission
                  </span>
                  <p className="text-slate-300 text-[11px]">
                    Department of the Treasury Internal Revenue Service. Request for Taxpayer Identification Number and Certification.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">1. Legal Name (as shown on tax return)</label>
                    <input
                      type="text"
                      value={w9Form.legalName}
                      onChange={(e) => setW9Form({ ...w9Form, legalName: e.target.value })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">2. Business Name / Disregarded Entity</label>
                    <input
                      type="text"
                      value={w9Form.businessName}
                      placeholder="Optional DBAs or LLC Name"
                      onChange={(e) => setW9Form({ ...w9Form, businessName: e.target.value })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">3. Federal Tax Classification</label>
                  <select
                    value={w9Form.taxClassification}
                    onChange={(e) => setW9Form({ ...w9Form, taxClassification: e.target.value })}
                    className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none"
                  >
                    <option value="Individual/Sole Proprietor">Individual / Sole Proprietor or Single-member LLC</option>
                    <option value="C Corporation">C Corporation</option>
                    <option value="S Corporation">S Corporation</option>
                    <option value="Partnership">Partnership</option>
                    <option value="LLC">Limited Liability Company (LLC)</option>
                  </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Tax ID Type</label>
                    <select
                      value={w9Form.taxIdType}
                      onChange={(e) => setW9Form({ ...w9Form, taxIdType: e.target.value as 'SSN' | 'EIN' })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none font-mono"
                    >
                      <option value="SSN">SSN (Social Security Number)</option>
                      <option value="EIN">EIN (Employer Identification Number)</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Taxpayer ID Number (TIN)</label>
                    <input
                      type="text"
                      value={w9Form.taxId}
                      placeholder={w9Form.taxIdType === 'SSN' ? 'XXX-XX-XXXX' : 'XX-XXXXXXX'}
                      onChange={(e) => setW9Form({ ...w9Form, taxId: e.target.value })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Address (number, street, apt/suite)</label>
                    <input
                      type="text"
                      value={w9Form.address}
                      onChange={(e) => setW9Form({ ...w9Form, address: e.target.value })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">City, State, and ZIP Code</label>
                    <input
                      type="text"
                      value={w9Form.cityStateZip}
                      onChange={(e) => setW9Form({ ...w9Form, cityStateZip: e.target.value })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none"
                    />
                  </div>
                </div>

                <div className="p-3.5 bg-[#060b13] border border-white/10 rounded-2xl space-y-2">
                  <label className="flex items-start gap-2.5 cursor-pointer text-[11px] text-slate-300 leading-relaxed">
                    <input
                      type="checkbox"
                      checked={w9Form.perjuryCert}
                      onChange={(e) => setW9Form({ ...w9Form, perjuryCert: e.target.checked })}
                      className="mt-0.5 rounded text-agency-gold focus:ring-agency-gold"
                    />
                    <span>
                      Under penalties of perjury, I certify that: (1) The number shown on this form is my correct taxpayer identification number, (2) I am not subject to backup withholding, and (3) I am a U.S. citizen or other U.S. person.
                    </span>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Electronic Signature</label>
                    <input
                      type="text"
                      value={w9Form.signatureText}
                      onChange={(e) => setW9Form({ ...w9Form, signatureText: e.target.value })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none font-serif italic"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Date Signed</label>
                    <input
                      type="date"
                      value={w9Form.signatureDate}
                      onChange={(e) => setW9Form({ ...w9Form, signatureDate: e.target.value })}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            ) : taxTab === 'signoff' ? (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-agency-navy border border-agency-gold/30 rounded-2xl space-y-2">
                  <span className="font-bold text-agency-gold font-mono flex items-center gap-1.5">
                    <PenTool className="w-4 h-4" /> 1099 Classification & Status Acknowledgment
                  </span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    By signing below, you acknowledge and agree that you are operating as a 1099 Independent Contractor for all tax and legal purposes.
                  </p>
                </div>

                <div className="bg-[#060b13] border border-white/10 rounded-2xl p-5 space-y-4 text-slate-300 leading-relaxed text-[11px]">
                  <p>
                    I, <strong>{w9Form.legalName}</strong>, hereby declare and acknowledge the following:
                  </p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>I am an Independent Contractor, not an employee of the Agency.</li>
                    <li>I am responsible for filing and paying all of my own self-employment taxes, including Social Security, Medicare, and Income taxes.</li>
                    <li>I am not eligible for agency-sponsored health insurance, 401(k), or other employment benefits.</li>
                    <li>I maintain my own equipment and set my own workspace boundaries while adhering to campaign deliverables.</li>
                  </ul>
                  
                  <div className="pt-2">
                    <label className="flex items-start gap-2.5 cursor-pointer">
                      <input
                        type="checkbox"
                        className="mt-0.5 rounded text-agency-gold focus:ring-agency-gold"
                        required
                      />
                      <span>I have read and agree to the 1099 Classification declaration.</span>
                    </label>
                  </div>

                  <div className="pt-2 border-t border-white/10 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-white font-bold text-xs flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-agency-gold" /> Master Privacy &amp; Data Security Acknowledgment
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowPrivacyModal(true)}
                        className="text-[10px] font-mono text-agency-gold hover:underline bg-agency-gold/10 hover:bg-agency-gold/20 px-2 py-0.5 rounded border border-agency-gold/20 cursor-pointer"
                      >
                        Read Master Privacy Policy
                      </button>
                    </div>
                    <label className="flex items-start gap-2.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={privacyAcknowledged}
                        onChange={(e) => setPrivacyAcknowledged(e.target.checked)}
                        className="mt-0.5 rounded text-agency-gold focus:ring-agency-gold"
                      />
                      <span>I have read and agree to Bloom Studio’s Master Privacy Policy, staff data protocols, and creator information confidentiality obligations.</span>
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Staff Signature</label>
                    <input
                      type="text"
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none font-serif italic"
                      placeholder="Type legal name to sign"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Date</label>
                    <input
                      type="date"
                      defaultValue={new Date().toISOString().split('T')[0]}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2 text-white text-xs focus:border-agency-gold outline-none font-mono"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    handleToggleSelfCheck('step_1099_signoff');
                    if (privacyAcknowledged) {
                      const privStep = steps.find(s => s.id === 'step_privacy_policy');
                      if (privStep && !privStep.selfChecked) {
                        handleToggleSelfCheck('step_privacy_policy');
                      }
                    }
                    if (triggerNotification) triggerNotification("Sign-off Complete", "1099 Independent Contractor declaration and compliance protocols acknowledged.", "success");
                  }}
                  className="w-full py-3 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  Confirm &amp; Sign 1099 Declaration
                </button>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-300 font-mono flex items-center gap-1.5 text-sm">
                      <Landmark className="w-4 h-4" /> Form 1099-NEC Nonemployee Compensation Summary
                    </span>
                    <span className="text-[10px] font-mono bg-emerald-900/60 text-emerald-200 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
                      Tax Year 2025
                    </span>
                  </div>
                  <p className="text-slate-300 text-xs">
                    Annual earnings report for contractor and manager commissions disbursed by Agency Master Holdings.
                  </p>
                </div>

                <div className="bg-[#060b13] border border-white/10 rounded-2xl p-4 space-y-3 font-mono">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="text-slate-400">Payer Name:</span>
                    <span className="text-white font-bold">Agency Master Holdings LLC</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="text-slate-400">Recipient Name:</span>
                    <span className="text-white font-bold">{w9Form.legalName || currentUser?.name}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="text-slate-400">Box 1 Nonemployee Compensation:</span>
                    <span className="text-emerald-400 font-bold text-sm">$48,250.00</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Federal Tax Withheld:</span>
                    <span className="text-slate-200 font-bold">$0.00</span>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      generateOfficial1099NecPdf({
                        taxYear: '2025',
                        payerName: 'Agency Master Holdings LLC',
                        recipientName: w9Form.legalName || currentUser?.name || 'Staff Member',
                        recipientTin: w9Form.taxId || 'XX-XXX4819',
                        nonemployeeCompensation: 48250,
                        federalTaxWithheld: 0
                      });
                      if (triggerNotification) {
                        triggerNotification("1099 Downloaded", "Official IRS Form 1099-NEC PDF downloaded.", "success");
                      }
                    }}
                    className="w-full py-3 bg-agency-navy border border-agency-gold/40 hover:border-agency-gold text-agency-gold rounded-xl font-mono text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                  >
                    <Download className="w-4 h-4" />
                    Download Official IRS Form 1099-NEC PDF
                  </button>
                </div>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setShowTaxModal(false)}
                className="px-4 py-2.5 rounded-xl border border-white/15 text-slate-300 hover:text-white text-xs font-mono cursor-pointer"
              >
                Close
              </button>
              {taxTab === 'w9' && (
                <button
                  type="button"
                  onClick={async () => {
                    if (!w9Form.perjuryCert) {
                      alert('Please check the penalty of perjury certification checkbox.');
                      return;
                    }
                    if (!w9Form.taxId) {
                      alert('Please enter your Taxpayer ID Number (SSN or EIN).');
                      return;
                    }

                    try {
                      // Generate W-9 PDF
                      generateOfficialW9Pdf({
                        legalName: w9Form.legalName,
                        businessName: w9Form.businessName,
                        taxClassification: w9Form.taxClassification,
                        tinType: w9Form.taxIdType,
                        tinNumber: w9Form.taxId,
                        address: w9Form.address,
                        cityStateZip: w9Form.cityStateZip,
                        signatureName: w9Form.signatureText,
                        dateSigned: w9Form.signatureDate
                      });

                      // Save to Firestore / local storage
                      const formId = `w9_${currentUser?.email?.replace(/[^a-zA-Z0-9]/g, '_') || 'staff'}`;
                      try {
                        await setDoc(doc(db, 'studio-w9-forms', formId), {
                          ...w9Form,
                          userId: currentUser?.id || 'staff',
                          userEmail: currentUser?.email || '',
                          submittedAt: new Date().toISOString(),
                          status: 'verified'
                        });
                      } catch (err) {
                        console.warn('Firestore write warning:', err);
                      }

                      handleToggleSelfCheck('step_w9');
                      setShowTaxModal(false);
                      if (triggerNotification) {
                        triggerNotification("W-9 Form Submitted", "Official IRS Form W-9 signed, PDF generated, and verified for tax compliance.", "success");
                      }
                    } catch (e) {
                      console.error('Error submitting W9:', e);
                    }
                  }}
                  className="px-5 py-2.5 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs font-mono shadow-lg transition cursor-pointer flex items-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Sign &amp; Submit Official IRS W-9
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Global Master Privacy Policy Modal */}
      <PrivacyPolicyModal
        isOpen={showPrivacyModal}
        onClose={() => {
          setShowPrivacyModal(false);
          setPrivacyAcknowledged(true);
          const privStep = steps.find(s => s.id === 'step_privacy_policy');
          if (privStep && !privStep.selfChecked) {
            handleToggleSelfCheck('step_privacy_policy');
          }
          if (triggerNotification) {
            triggerNotification("Privacy Policy Acknowledged", "Master Privacy Policy review acknowledged and recorded in your compliance dossier.", "success");
          }
          if (onAddActivityLog) {
            onAddActivityLog(activeStaffName, effectiveRole, "Acknowledged Master Privacy Policy & Compliance protocols");
          }
        }}
        triggerNotification={triggerNotification}
      />

    </div>
  );
}
