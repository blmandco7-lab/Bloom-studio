import React, { useState } from 'react';
import { FileCheck, Sparkles, Globe, Eye, ArrowRight, ExternalLink, ShieldCheck, Share2, Copy, CheckCircle2 } from 'lucide-react';

export interface FinalizedCampaignCaseStudyData {
  id: string;
  slug: string;
  brandName: string;
  campaignTitle: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  totalViews: string;
  totalReach: string;
  engagementRate: string;
  ugcCount: number;
  highlightHook: string;
  quote: string;
  heroImageUrl: string;
  isPublished?: boolean;
}

interface CaseStudyPublisherProps {
  initialCampaigns?: FinalizedCampaignCaseStudyData[];
}

/**
 * CaseStudyPublisher:
 * Dashboard utility component for the Director view to publish aggregate, non-sensitive case studies.
 * 
 * CRITICAL PRIVACY BOUND:
 * Exclusively accesses and publishes marketing performance metrics (Views, Engagement, Reach).
 * Strictly hardcoded to NEVER query, process, or expose internal influencer payouts,
 * manager compensation, or agency net profit margins.
 */
export default function CaseStudyPublisher({
  initialCampaigns = [
    {
      id: "cs_1",
      slug: "glowlab-botanical-serum-launch",
      brandName: "GlowLab Beauty",
      campaignTitle: "Summer Botanical Serum Organic Whitelisting",
      niche: "Beauty",
      totalViews: "842,500 Views",
      totalReach: "1.45M Impressions",
      engagementRate: "7.8%",
      ugcCount: 12,
      highlightHook: "Macro 4K texture reels driving 2.1x higher engagement than category benchmarks.",
      quote: "Bloom Studio delivered flawless FTC-compliant assets with unmatched organic traction.",
      heroImageUrl: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80",
      isPublished: true
    },
    {
      id: "cs_2",
      slug: "barkhydrate-organic-balm-rollout",
      brandName: "BarkHydrate Eco",
      campaignTitle: "Organic Fur Shampoo & Pet Balm Launch",
      niche: "Pets",
      totalViews: "520,000 Views",
      totalReach: "980K Impressions",
      engagementRate: "8.1%",
      ugcCount: 8,
      highlightHook: "Authentic canine story reels with 100% verified #ad compliance at second 0.",
      quote: "Our best-performing organic UGC launch to date.",
      heroImageUrl: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=800&auto=format&fit=crop&q=80",
      isPublished: false
    }
  ]
}: CaseStudyPublisherProps) {
  const [campaigns, setCampaigns] = useState<FinalizedCampaignCaseStudyData[]>(initialCampaigns);
  const [previewCaseStudy, setPreviewCaseStudy] = useState<FinalizedCampaignCaseStudyData | null>(null);
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);

  const togglePublish = (id: string) => {
    setCampaigns(prev => prev.map(c => c.id === id ? { ...c, isPublished: !c.isPublished } : c));
  };

  const handleCopyLink = (slug: string) => {
    const fullUrl = `https://bloomstudio.agency/case-studies/${slug}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedSlug(slug);
    setTimeout(() => setCopiedSlug(null), 3000);
  };

  return (
    <div className="bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl text-agency-textLight space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Director Marketing Engine
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Public Case Study Publisher
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl text-white mt-1.5">
            Campaign Case Study Publisher
          </h2>
          <p className="text-xs text-slate-400">
            Convert finalized campaign analytics into high-converting public case study landing pages with zero financial disclosure.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-300 bg-agency-navy px-4 py-2 rounded-xl border border-white/10">
          <ShieldCheck className="w-4 h-4 text-agency-gold" />
          <span>Non-Sensitive Public Output</span>
        </div>
      </div>

      {/* Campaign List */}
      <div className="space-y-4">
        {campaigns.map((camp) => (
          <div
            key={camp.id}
            className="bg-agency-navy border border-white/10 hover:border-agency-gold/40 transition-all rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md"
          >
            <div className="space-y-1.5 max-w-xl">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-base">{camp.campaignTitle}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-agency-navyLight border border-white/10 text-agency-gold">
                  {camp.niche}
                </span>
                {camp.isPublished ? (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
                    Live on Web
                  </span>
                ) : (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-white/5">
                    Draft / Unpublished
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Client: <strong className="text-white">{camp.brandName}</strong> &bull; Views: <strong className="text-emerald-400">{camp.totalViews}</strong> &bull; Engagement: <strong className="text-agency-gold">{camp.engagementRate}</strong> &bull; Yield: <strong className="text-white">{camp.ugcCount} UGC Reels</strong>
              </p>
              <p className="text-xs text-slate-300 font-mono italic">
                "{camp.highlightHook}"
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setPreviewCaseStudy(camp)}
                className="inline-flex items-center gap-1.5 bg-agency-navyLight hover:bg-agency-navy border border-white/10 text-slate-200 text-xs px-3.5 py-2 rounded-xl transition-all cursor-pointer font-mono"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Preview Page</span>
              </button>

              <button
                type="button"
                onClick={() => togglePublish(camp.id)}
                className={`inline-flex items-center gap-1.5 font-bold text-xs px-4 py-2 rounded-xl transition-all cursor-pointer shadow-md ${
                  camp.isPublished
                    ? 'bg-agency-navy text-slate-300 border border-white/20 hover:border-white/40'
                    : 'bg-agency-gold hover:bg-[#b89359] text-agency-navy'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{camp.isPublished ? 'Unpublish' : 'Publish Public Case Study'}</span>
              </button>

              {camp.isPublished && (
                <button
                  type="button"
                  onClick={() => handleCopyLink(camp.slug)}
                  className="p-2 bg-agency-navyLight hover:bg-agency-navy border border-agency-gold/30 text-agency-gold rounded-xl transition-colors cursor-pointer"
                  title="Copy Public URL"
                >
                  {copiedSlug === camp.slug ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Case Study Live Preview Modal */}
      {previewCaseStudy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-white text-slate-900 rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-10 space-y-8 relative">
            <button
              type="button"
              onClick={() => setPreviewCaseStudy(null)}
              className="absolute top-6 right-6 text-slate-400 hover:text-slate-900 bg-slate-100 p-2 rounded-full font-bold cursor-pointer"
            >
              ✕
            </button>

            {/* Public Header */}
            <div className="border-b border-slate-200 pb-6 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono uppercase font-bold tracking-widest text-[#B89359] bg-[#B89359]/10 px-3 py-1 rounded-full">
                  Case Study &bull; {previewCaseStudy.niche} Vertical
                </span>
                <span className="text-xs text-slate-500 font-mono">
                  Bloom Studio Agency
                </span>
              </div>
              <h1 className="font-serif font-bold text-3xl sm:text-4xl text-slate-900 leading-tight">
                {previewCaseStudy.campaignTitle}
              </h1>
              <p className="text-sm text-slate-600">
                Partner: <strong>{previewCaseStudy.brandName}</strong> &bull; Public Performance White Paper
              </p>
            </div>

            {/* Metric Highlights */}
            <div className="grid grid-cols-3 gap-4 bg-slate-50 p-6 rounded-2xl border border-slate-200 text-center font-mono">
              <div>
                <span className="text-xs text-slate-500 block uppercase">Total Views</span>
                <span className="text-2xl font-bold text-slate-900">{previewCaseStudy.totalViews}</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block uppercase">Reach</span>
                <span className="text-2xl font-bold text-[#B89359]">{previewCaseStudy.totalReach}</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block uppercase">Engagement</span>
                <span className="text-2xl font-bold text-emerald-600">{previewCaseStudy.engagementRate}</span>
              </div>
            </div>

            {/* Hero Image & Content */}
            <div className="space-y-4 text-slate-700 leading-relaxed text-sm">
              <img
                src={previewCaseStudy.heroImageUrl}
                alt="Case study"
                className="w-full h-64 object-cover rounded-2xl shadow-md border border-slate-200"
              />
              <h3 className="font-serif font-bold text-xl text-slate-900 pt-2">
                Strategic Campaign Execution &amp; Creative Yield
              </h3>
              <p>
                {previewCaseStudy.highlightHook} Every piece of content was vetted with 100% FTC-compliant caption tagging and synchronized commercial audio clearance for seamless digital ad whitelisting.
              </p>
              <blockquote className="border-l-4 border-[#B89359] pl-4 italic text-slate-800 bg-amber-50/50 py-3 rounded-r-xl">
                "{previewCaseStudy.quote}"
              </blockquote>
            </div>

            {/* Public CTA Footer */}
            <div className="bg-slate-900 text-white p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="font-bold text-sm">Scale your brand with Bloom Studio Talent</h4>
                <p className="text-xs text-slate-400">Request a tailored casting match deck for your next campaign.</p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewCaseStudy(null)}
                className="bg-[#B89359] hover:bg-[#a58148] text-slate-900 font-bold text-xs px-5 py-2.5 rounded-xl cursor-pointer"
              >
                Inquire for Your Brand
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
