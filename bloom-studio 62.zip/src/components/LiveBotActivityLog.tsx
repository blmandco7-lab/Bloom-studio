import React, { useState, useEffect, useRef } from 'react';

interface LiveBotActivityLogProps {
  externalLogs?: string[];
  className?: string;
  isActive?: boolean;
}

interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
}

export default function LiveBotActivityLog({ 
  externalLogs = [], 
  className = '',
  isActive = true 
}: LiveBotActivityLogProps) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const terminalRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new entries
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [logs]);

  // Sync incoming external logs
  useEffect(() => {
    if (externalLogs.length > 0) {
      const now = new Date();
      const timestamp = `[${now.toLocaleTimeString()}]`;
      const formatted = externalLogs.map((msg, idx) => ({
        id: `ext-${idx}-${msg.slice(0, 10)}`,
        timestamp,
        message: msg
      }));
      setLogs(formatted.slice(-40));
    } else {
      setLogs([]);
    }
  }, [externalLogs]);

  return (
    <div className={`bot-log-widget ${className}`}>
      <div className="log-header">
        <div className="status-indicator">
          <span className={`pulse-dot ${!isActive ? 'opacity-40 bg-slate-500 shadow-none' : ''}`}></span>
          LIVE BOT ACTIVITY LOG
        </div>
        <span className="active-tag">
          {isActive ? 'Active Runner' : 'Paused'}
        </span>
      </div>
      <div className="log-terminal" id="botTerminalLog" ref={terminalRef}>
        {logs.length > 0 ? (
          logs.map((entry) => (
            <div key={entry.id} className="log-entry">
              <span className="timestamp">{entry.timestamp}</span> {entry.message}
            </div>
          ))
        ) : (
          <div className="text-xs text-slate-500 italic p-2 font-mono">
            No active system events recorded. Awaiting live activity...
          </div>
        )}
      </div>
    </div>
  );
}
