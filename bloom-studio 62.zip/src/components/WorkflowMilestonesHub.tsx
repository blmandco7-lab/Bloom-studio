import React, { useState, useEffect, useMemo } from 'react';
import { 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Database, 
  Filter, 
  ArrowUpDown, 
  Plus, 
  Trash2, 
  Search, 
  Calendar, 
  AlertCircle, 
  CheckSquare, 
  Square,
  Sparkles,
  RefreshCw,
  FolderOpen
} from 'lucide-react';
import BrandReviewPortal from './BrandReviewPortal';
import ProjectArchiveHub from './ProjectArchiveHub';
import TalentRightsBuyoutManager from './TalentRightsBuyoutManager';

interface MilestoneTask {
  id: string;
  title: string;
  campaign: string;
  category: 'Brand Review' | 'Signatures' | 'Archiving' | 'FTC Compliance' | 'Other';
  priority: 'High' | 'Medium' | 'Low';
  dueDate: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  notes?: string;
}

const INITIAL_MILESTONES: MilestoneTask[] = [
  {
    id: "m_01",
    title: "48-Hour Brand SLA Expiry Audit",
    campaign: "Elena Rostova • Lumina Launch",
    category: "Brand Review",
    priority: "High",
    dueDate: "2026-09-21",
    status: "In Progress",
    notes: "Campaign automatic SLA feedback approval threshold approaching."
  },
  {
    id: "m_02",
    title: "Sign Commercial Rights Buyout",
    campaign: "Kai Lifestyle • AuraWear Fit",
    category: "Signatures",
    priority: "High",
    dueDate: "2026-09-22",
    status: "Pending",
    notes: "Requires secure name-typing signature pad execution."
  },
  {
    id: "m_03",
    title: "Sweep Finished Campaign to Cold Storage",
    campaign: "Golden Leo • Summer Splendor",
    category: "Archiving",
    priority: "Low",
    dueDate: "2026-09-30",
    status: "Completed",
    notes: "Settle final brand invoicing before archiving."
  },
  {
    id: "m_04",
    title: "Verify FTC Caption Tags Compliance",
    campaign: "Marcus VFX • ElectroTech Ads",
    category: "FTC Compliance",
    priority: "Medium",
    dueDate: "2026-09-25",
    status: "In Progress",
    notes: "Caption check before active campaign publication."
  },
  {
    id: "m_05",
    title: "Release Milestone Escrow Payout",
    campaign: "Sarah Jenkins • High-Impact Wear Test",
    category: "Signatures",
    priority: "High",
    dueDate: "2026-09-20",
    status: "Pending",
    notes: "Escrow release conditional on legal signature timestamp."
  }
];

export default function WorkflowMilestonesHub() {
  const [tasks, setTasks] = useState<MilestoneTask[]>(() => {
    try {
      const saved = localStorage.getItem('wl_workflow_milestone_tasks');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return INITIAL_MIES_LOAD_OR_FALLBACK();
  });

  function INITIAL_MIES_LOAD_OR_FALLBACK() {
    return INITIAL_MILESTONES;
  }

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem('wl_workflow_milestone_tasks', JSON.stringify(tasks));
    } catch (e) {}
  }, [tasks]);

  // Search & Filters State
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<'All' | 'High' | 'Medium' | 'Low'>('All');
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Brand Review' | 'Signatures' | 'Archiving' | 'FTC Compliance' | 'Other'>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'In Progress' | 'Completed'>('All');
  const [sortBy, setSortBy] = useState<'urgency-desc' | 'urgency-asc' | 'date-asc' | 'date-desc'>('urgency-desc');

  // Form State for Adding Task
  const [showAddForm, setShowAddForm] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formCampaign, setFormCampaign] = useState('');
  const [formCategory, setFormCategory] = useState<'Brand Review' | 'Signatures' | 'Archiving' | 'FTC Compliance' | 'Other'>('Brand Review');
  const [formPriority, setFormPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [formDueDate, setFormDueDate] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const priorityWeights = {
    'High': 3,
    'Medium': 2,
    'Low': 1
  };

  const categories = ['Brand Review', 'Signatures', 'Archiving', 'FTC Compliance', 'Other'];

  // Handle adding custom milestone task
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formCampaign.trim()) return;

    const newTask: MilestoneTask = {
      id: `task_${Date.now()}`,
      title: formTitle.trim(),
      campaign: formCampaign.trim(),
      category: formCategory,
      priority: formPriority,
      dueDate: formDueDate || new Date().toISOString().split('T')[0],
      status: 'Pending',
      notes: formNotes.trim() || undefined
    };

    setTasks(prev => [newTask, ...prev]);
    
    // Reset Form
    setFormTitle('');
    setFormCampaign('');
    setFormCategory('Brand Review');
    setFormPriority('Medium');
    setFormDueDate('');
    setFormNotes('');
    setShowAddForm(false);
  };

  // Toggle priority directly on row click or dropdown select
  const handleUpdatePriority = (id: string, newPriority: 'High' | 'Medium' | 'Low') => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, priority: newPriority } : t));
  };

  // Toggle status
  const handleToggleStatus = (id: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const nextStatusMap: Record<MilestoneTask['status'], MilestoneTask['status']> = {
          'Pending': 'In Progress',
          'In Progress': 'Completed',
          'Completed': 'Pending'
        };
        return { ...t, status: nextStatusMap[t.status] };
      }
      return t;
    }));
  };

  const handleDeleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  // Reset default sample tasks
  const handleResetDefaults = () => {
    if (confirm('Are you sure you want to restore the default workflow milestones? This will overwrite your current task list.')) {
      setTasks(INITIAL_MILESTONES);
    }
  };

  // Filter & Sort computation
  const processedTasks = useMemo(() => {
    let result = [...tasks];

    // Filter by search query
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(t => 
        t.title.toLowerCase().includes(q) || 
        t.campaign.toLowerCase().includes(q) || 
        (t.notes && t.notes.toLowerCase().includes(q))
      );
    }

    // Filter by priority
    if (priorityFilter !== 'All') {
      result = result.filter(t => t.priority === priorityFilter);
    }

    // Filter by category
    if (categoryFilter !== 'All') {
      result = result.filter(t => t.category === categoryFilter);
    }

    // Filter by status
    if (statusFilter !== 'All') {
      result = result.filter(t => t.status === statusFilter);
    }

    // Sort by selection
    result.sort((a, b) => {
      if (sortBy === 'urgency-desc') {
        const weightDiff = priorityWeights[b.priority] - priorityWeights[a.priority];
        if (weightDiff !== 0) return weightDiff;
        // tiebreaker by date (soonest first)
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      if (sortBy === 'urgency-asc') {
        const weightDiff = priorityWeights[a.priority] - priorityWeights[b.priority];
        if (weightDiff !== 0) return weightDiff;
        return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
      }
      if (sortBy === 'date-asc') {
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      if (sortBy === 'date-desc') {
        return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
      }
      return 0;
    });

    return result;
  }, [tasks, search, priorityFilter, categoryFilter, statusFilter, sortBy]);

  return (
    <div className="space-y-8 animate-fade-in text-slate-100">
      
      {/* Title Header Card */}
      <div className="bg-[#0b1320] border-2 border-indigo-500/30 rounded-2xl p-6 overflow-hidden shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
              Campaign & Workflow Milestones
            </h1>
            <p className="text-xs text-slate-400 mt-2 max-w-2xl">
              Automated timers, binding signatures, and task priority trackers to orchestrate campaign pipelines efficiently.
            </p>
          </div>
          <button
            onClick={() => setShowAddForm(prev => !prev)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition duration-200 shadow-md shadow-indigo-900/20 self-start md:self-center"
          >
            <Plus className="w-4 h-4" />
            Add Milestone
          </button>
        </div>
      </div>

      {/* Add Custom Milestone Form Panel */}
      {showAddForm && (
        <div className="bg-[#0b1320] border border-indigo-500/20 rounded-2xl p-6 shadow-xl space-y-4 animate-slide-down">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold font-mono text-indigo-400 uppercase tracking-wider">Create New Workflow Milestone</h3>
            <button 
              onClick={() => setShowAddForm(false)} 
              className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded hover:bg-slate-800"
            >
              Cancel
            </button>
          </div>
          
          <form onSubmit={handleAddTask} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[11px] font-mono text-slate-400 uppercase">Milestone Title *</label>
              <input
                type="text"
                required
                value={formTitle}
                onChange={e => setFormTitle(e.target.value)}
                placeholder="e.g. Verify legal terms of service"
                className="w-full bg-[#050e1a] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-mono text-slate-400 uppercase">Campaign / Creator *</label>
              <input
                type="text"
                required
                value={formCampaign}
                onChange={e => setFormCampaign(e.target.value)}
                placeholder="e.g. Elena Rostova • Lumina Launch"
                className="w-full bg-[#050e1a] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-mono text-slate-400 uppercase">Category</label>
              <select
                value={formCategory}
                onChange={e => setFormCategory(e.target.value as any)}
                className="w-full bg-[#050e1a] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-mono text-slate-400 uppercase">Priority / Urgency *</label>
              <div className="flex gap-2">
                {(['Low', 'Medium', 'High'] as const).map(p => {
                  const colors = {
                    Low: 'border-blue-500/20 text-blue-400 bg-blue-500/5 hover:bg-blue-500/10',
                    Medium: 'border-amber-500/20 text-amber-400 bg-amber-500/5 hover:bg-amber-500/10',
                    High: 'border-rose-500/20 text-rose-400 bg-rose-500/5 hover:bg-rose-500/10'
                  };
                  const activeColors = {
                    Low: 'border-blue-500 text-blue-400 bg-blue-500/20 font-bold',
                    Medium: 'border-amber-500 text-amber-400 bg-amber-500/20 font-bold',
                    High: 'border-rose-500 text-rose-400 bg-rose-500/20 font-bold'
                  };
                  return (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setFormPriority(p)}
                      className={`flex-1 border py-1.5 rounded-lg text-[11px] tracking-wide uppercase transition ${
                        formPriority === p ? activeColors[p] : colors[p]
                      }`}
                    >
                      {p}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-mono text-slate-400 uppercase">Due Date</label>
              <input
                type="date"
                value={formDueDate}
                onChange={e => setFormDueDate(e.target.value)}
                className="w-full bg-[#050e1a] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-mono text-slate-400 uppercase">Internal Comments / Notes</label>
              <input
                type="text"
                value={formNotes}
                onChange={e => setFormNotes(e.target.value)}
                placeholder="Optional workflow details"
                className="w-full bg-[#050e1a] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="md:col-span-2 pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white uppercase tracking-wider rounded-xl transition duration-150"
              >
                Create Milestone Task
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Main Milestone Tasks List & Controls */}
      <div className="bg-[#050e1a] border border-white/5 rounded-2xl p-6 space-y-6 shadow-xl">
        <div className="flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-indigo-500/10 rounded-lg text-indigo-400">
                <FolderOpen className="w-4 h-4" />
              </span>
              <h3 className="text-sm font-bold font-mono text-white uppercase tracking-wider">Workflow Milestone Tracker</h3>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Live campaign checkpoints categorized by function and arranged by urgency priority level.
            </p>
          </div>
          
          {/* Action to reset defaults */}
          <button
            onClick={handleResetDefaults}
            className="text-slate-400 hover:text-white transition duration-150 text-[10px] uppercase font-mono tracking-wider flex items-center gap-1.5 hover:bg-slate-800/50 px-2.5 py-1 rounded"
          >
            <RefreshCw className="w-3 h-3" />
            Reset Defaults
          </button>
        </div>

        {/* Toolbar: Search, Filters & Sorting */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-3">
          
          {/* Search */}
          <div className="relative xl:col-span-2">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by title, creator, or comments..."
              className="w-full bg-[#0b1320] border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center bg-[#0b1320] border border-slate-800 rounded-xl px-2">
            <Filter className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-2" />
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value as any)}
              className="bg-transparent w-full border-none py-2 text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="All" className="bg-[#0b1320]">All Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat} className="bg-[#0b1320]">{cat}</option>
              ))}
            </select>
          </div>

          {/* Priority Filter */}
          <div className="flex items-center bg-[#0b1320] border border-slate-800 rounded-xl px-2">
            <AlertCircle className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-2" />
            <select
              value={priorityFilter}
              onChange={e => setPriorityFilter(e.target.value as any)}
              className="bg-transparent w-full border-none py-2 text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="All" className="bg-[#0b1320]">All Priorities</option>
              <option value="High" className="bg-[#0b1320]">High Priority</option>
              <option value="Medium" className="bg-[#0b1320]">Medium Priority</option>
              <option value="Low" className="bg-[#0b1320]">Low Priority</option>
            </select>
          </div>

          {/* Urgency Sorting */}
          <div className="flex items-center bg-[#0b1320] border border-slate-800 rounded-xl px-2">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-2" />
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="bg-transparent w-full border-none py-2 text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="urgency-desc" className="bg-[#0b1320]">Urgency (High → Low)</option>
              <option value="urgency-asc" className="bg-[#0b1320]">Urgency (Low → High)</option>
              <option value="date-asc" className="bg-[#0b1320]">Due Date (Soonest first)</option>
              <option value="date-desc" className="bg-[#0b1320]">Due Date (Latest first)</option>
            </select>
          </div>

        </div>

        {/* Milestone Rows Table */}
        <div className="border border-white/5 rounded-xl overflow-hidden bg-[#0b1320]">
          {processedTasks.length === 0 ? (
            <div className="p-8 text-center space-y-2">
              <AlertTriangle className="w-8 h-8 text-slate-500 mx-auto" />
              <h4 className="text-xs font-bold font-mono text-slate-400 uppercase">No Milestones Found</h4>
              <p className="text-[11px] text-slate-500">Try adjusting your filters or search terms to locate specific items.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-800/50">
              {processedTasks.map(task => {
                const isCompleted = task.status === 'Completed';
                
                // Color mapping for priority badges
                const priorityStyles = {
                  High: 'border-rose-500/20 text-rose-400 bg-rose-500/10 hover:bg-rose-500/20',
                  Medium: 'border-amber-500/20 text-amber-400 bg-amber-500/10 hover:bg-amber-500/20',
                  Low: 'border-blue-500/20 text-blue-400 bg-blue-500/10 hover:bg-blue-500/20'
                };

                const statusStyles = {
                  'Pending': 'text-slate-400 bg-slate-800/60',
                  'In Progress': 'text-indigo-400 bg-indigo-500/10',
                  'Completed': 'text-emerald-400 bg-emerald-500/10'
                };

                return (
                  <div 
                    key={task.id} 
                    className={`p-4 transition duration-150 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-[#080f1a] ${
                      isCompleted ? 'opacity-60' : ''
                    }`}
                  >
                    
                    {/* Left: Checkbox + Milestone & Creator Info */}
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <button
                        onClick={() => handleToggleStatus(task.id)}
                        className="mt-0.5 text-slate-400 hover:text-white transition focus:outline-none shrink-0"
                        title={`Toggle status: currently ${task.status}`}
                      >
                        {isCompleted ? (
                          <CheckSquare className="w-4 h-4 text-emerald-400" />
                        ) : task.status === 'In Progress' ? (
                          <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>

                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`text-[12px] font-semibold text-white ${isCompleted ? 'line-through text-slate-500' : ''}`}>
                            {task.title}
                          </span>
                          <span className="text-[10px] font-mono uppercase tracking-wider text-indigo-400/80 bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-900/40">
                            {task.category}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-400">
                          <span className="font-medium text-slate-300">{task.campaign}</span>
                          <span className="text-slate-500">•</span>
                          <span className="flex items-center gap-1 font-mono text-[10px]">
                            <Calendar className="w-3 h-3 text-slate-500" />
                            Due {task.dueDate}
                          </span>
                        </div>
                        {task.notes && (
                          <p className="text-[11px] text-slate-400 italic bg-black/10 p-1.5 rounded border border-white/5 max-w-xl">
                            {task.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Right: Priority Indicator Select + Status Clicker + Actions */}
                    <div className="flex items-center gap-3 self-end md:self-center shrink-0">
                      
                      {/* Interactive Priority Badge / Cycle Selector */}
                      <div className="relative">
                        <select
                          value={task.priority}
                          onChange={e => handleUpdatePriority(task.id, e.target.value as any)}
                          className={`text-[10px] font-mono font-bold tracking-wider uppercase border rounded-md px-2.5 py-1 appearance-none cursor-pointer focus:outline-none focus:ring-1 focus:ring-indigo-500/50 pr-6 ${
                            priorityStyles[task.priority]
                          }`}
                          title="Click to cycle or select priority"
                        >
                          <option value="High" className="bg-[#0b1320] text-rose-400">HIGH</option>
                          <option value="Medium" className="bg-[#0b1320] text-amber-400">MEDIUM</option>
                          <option value="Low" className="bg-[#0b1320] text-blue-400">LOW</option>
                        </select>
                        <span className="absolute right-2 top-2 pointer-events-none text-slate-400 text-[8px]">▼</span>
                      </div>

                      {/* Status pill cycle click */}
                      <button
                        onClick={() => handleToggleStatus(task.id)}
                        className={`text-[9px] font-mono font-bold tracking-wider uppercase px-2 py-1 rounded transition duration-150 ${statusStyles[task.status]}`}
                      >
                        {task.status}
                      </button>

                      {/* Delete */}
                      <button
                        onClick={() => handleDeleteTask(task.id)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition"
                        title="Delete Milestone"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Counter Summary Panel */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-[#0b1320]/60 border border-white/5 rounded-xl p-4">
          <div className="text-center space-y-0.5">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Total Tracked</span>
            <p className="text-lg font-bold text-white font-mono">{tasks.length}</p>
          </div>
          <div className="text-center space-y-0.5">
            <span className="text-[10px] font-mono text-rose-400 uppercase">High Priority</span>
            <p className="text-lg font-bold text-rose-400 font-mono">
              {tasks.filter(t => t.priority === 'High' && t.status !== 'Completed').length}
            </p>
          </div>
          <div className="text-center space-y-0.5">
            <span className="text-[10px] font-mono text-indigo-400 uppercase">In Progress</span>
            <p className="text-lg font-bold text-indigo-400 font-mono">
              {tasks.filter(t => t.status === 'In Progress').length}
            </p>
          </div>
          <div className="text-center space-y-0.5">
            <span className="text-[10px] font-mono text-emerald-400 uppercase">Completed</span>
            <p className="text-lg font-bold text-emerald-400 font-mono">
              {tasks.filter(t => t.status === 'Completed').length}
            </p>
          </div>
        </div>

      </div>

      {/* Grid of Other Hub Modules */}
      <div className="grid grid-cols-1 gap-8">
        
        {/* Brand Review Timer & Urgent Warning */}
        <div className="bg-[#050e1a] border border-white/5 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-rose-500/10 rounded-lg">
              <Clock className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">2-Day Brand Review Timer & Urgent Ping</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">On-screen 48-hour countdown clock built into the brand portal, with 12-hour background email warning.</p>
            </div>
          </div>
          
          <BrandReviewPortal />
        </div>

        {/* Digital Binding Signatures */}
        <div className="bg-[#050e1a] border border-white/5 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-500/10 rounded-lg">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Digital Binding Signatures</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Secure name-typing signature pad for creators, stamping legal name and server timestamp.</p>
            </div>
          </div>
          
          <div className="border border-white/10 rounded-xl overflow-hidden p-6 bg-[#0b1320]">
             <p className="text-xs text-slate-400 mb-4 font-mono uppercase tracking-wider">Executed Commercial Rights &amp; Buyouts Registry (View Only)</p>
             <TalentRightsBuyoutManager userRole="workflow" />
          </div>
        </div>

        {/* Automated Project Archiving */}
        <div className="bg-[#050e1a] border border-white/5 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-slate-500/10 rounded-lg">
              <Database className="w-5 h-5 text-slate-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Automated Project Archiving</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Non-destructive cold storage tools to sweep completed campaigns off active dashboard screens.</p>
            </div>
          </div>
          
          <ProjectArchiveHub />
        </div>

      </div>
    </div>
  );
}
