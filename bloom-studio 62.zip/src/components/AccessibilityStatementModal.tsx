import React, { useState } from 'react';
import { 
  Eye, CheckCircle2, AlertCircle, HelpCircle, X, ExternalLink, 
  Sparkles, Keyboard, Monitor, Volume2, ShieldCheck, Mail, Printer, RefreshCw
} from 'lucide-react';

interface AccessibilityStatementModalProps {
  isOpen: boolean;
  onClose: () => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger' | 'error' | any) => void;
}

export default function AccessibilityStatementModal({
  isOpen,
  onClose,
  triggerNotification
}: AccessibilityStatementModalProps) {
  const [activeTab, setActiveTab] = useState<'statement' | 'features' | 'shortcuts' | 'feedback'>('statement');
  const [feedbackCategory, setFeedbackCategory] = useState('Screen Reader Issue');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackMessage.trim()) return;
    setFeedbackSubmitted(true);
    if (triggerNotification) {
      triggerNotification('Accessibility Feedback Logged', 'Thank you. Our compliance & engineering team will review your report.', 'success');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-300"
      role="dialog"
      aria-modal="true"
      aria-labelledby="accessibility-statement-title"
    >
      <div className="bg-[#0B1B3D] border border-blue-500/30 rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-left relative">
        {/* Header */}
        <div className="p-6 md:p-8 border-b border-white/10 bg-[#081222]/80 flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-blue-500/10 rounded-2xl border border-blue-500/30 text-blue-400 shrink-0">
              <Eye className="w-7 h-7" aria-hidden="true" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                  ADA Title III &amp; WCAG 2.1 AA
                </span>
                <span className="text-[10px] font-mono text-[#7C8AA8]">
                  Standard Conformance Target
                </span>
              </div>
              <h2 id="accessibility-statement-title" className="text-2xl font-serif font-bold text-white mt-1">
                Accessibility Statement &amp; Assistive Tech Guide
              </h2>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Commitment to Digital Inclusivity, Screen Reader Support &amp; Keyboard Usability
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-[#7C8AA8] hover:text-white transition"
            aria-label="Close Accessibility Statement Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-[#081222] border-b border-white/5 px-6 py-2 overflow-x-auto gap-2 text-xs font-mono shrink-0">
          <button
            onClick={() => setActiveTab('statement')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'statement' ? 'bg-blue-600 text-white' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            1. Conformance Statement
          </button>
          <button
            onClick={() => setActiveTab('features')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'features' ? 'bg-blue-600 text-white' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            2. Platform Capabilities
          </button>
          <button
            onClick={() => setActiveTab('shortcuts')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'shortcuts' ? 'bg-blue-600 text-white' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            3. Keyboard Navigation
          </button>
          <button
            onClick={() => setActiveTab('feedback')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeTab === 'feedback' ? 'bg-blue-600 text-white' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            4. Accessibility Feedback
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6 text-slate-300 text-xs leading-relaxed">
          {activeTab === 'statement' && (
            <div className="space-y-4">
              <div className="p-4 bg-[#142850]/50 border border-blue-500/20 rounded-2xl flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white text-sm">WCAG 2.1 Level AA Standard</h4>
                  <p className="text-[#7C8AA8] mt-1 text-xs">
                    Bloom Studio OS is designed and developed to conform with the Web Content Accessibility Guidelines (WCAG) 2.1 Level AA and comply with the Americans with Disabilities Act (ADA) Title III requirements.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Our Continuous Accessibility Roadmap</h3>
                <p>
                  We believe that digital talent management, legal contract execution, and financial distribution should be equally accessible to all creators, executives, and brand partners. We continuously test our interface using automated evaluation engines, screen readers, and high-contrast display modes.
                </p>
                <p>
                  Core high-stakes surfaces—including IRS Form W-9 submission, contractual digital signature flows, payment ledgers, and privacy requests—are prioritized with explicit form labeling (<code className="bg-[#081222] px-1.5 py-0.5 rounded text-blue-300">aria-label</code>, <code className="bg-[#081222] px-1.5 py-0.5 rounded text-blue-300">htmlFor</code>) and accessible error descriptions.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="bg-[#142850] p-3.5 rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5 text-xs">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Screen Reader Compatibility</span>
                  </div>
                  <p className="text-[11px] text-[#7C8AA8]">Tested with NVDA, JAWS (Windows) and VoiceOver (macOS / iOS).</p>
                </div>

                <div className="bg-[#142850] p-3.5 rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5 text-xs">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>High-Contrast Typography</span>
                  </div>
                  <p className="text-[11px] text-[#7C8AA8]">Meets or exceeds the 4.5:1 contrast ratio for normal body copy.</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'features' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Accessibility Features Implemented</h3>
              
              <div className="space-y-3">
                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white text-xs">1. Accessible Image Descriptions (<code className="text-blue-300">alt</code> tags)</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Creator avatars, portfolio media kit assets, and brand campaign submission previews include descriptive alt attributes or are marked decorative where appropriate.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white text-xs">2. Form Labeling &amp; Error Boundaries</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Input fields across Tax Compliance, Contract Signing, and Casting Dashboards are paired with semantic labels, clear placeholder context, and explicit ARIA live error states.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white text-xs">3. Non-Color Reliant Status Indicators</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Legal signature statuses, payment clearance indicators, and approval queues pair color with recognizable geometric icons and text badges to support users with color vision deficiency.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'shortcuts' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Keyboard Navigation &amp; Focus Control</h3>
              <p>
                You can navigate the entire platform without a mouse using standard keyboard controls:
              </p>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse bg-[#142850] rounded-2xl overflow-hidden text-[11px]">
                  <thead>
                    <tr className="border-b border-white/10 bg-[#081222]">
                      <th className="p-3 font-bold text-blue-400 uppercase">Key / Combination</th>
                      <th className="p-3 font-bold text-blue-400 uppercase">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    <tr>
                      <td className="p-3 font-mono font-bold text-white">Tab / Shift + Tab</td>
                      <td className="p-3">Move focus forward or backward through interactive elements.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-white">Enter / Space</td>
                      <td className="p-3">Activate buttons, execute digital signatures, or toggle expandable panels.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-white">Escape (Esc)</td>
                      <td className="p-3">Close any active modal dialog (Terms of Service, Privacy Policy, Certificate Viewers).</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-white">Arrow Keys</td>
                      <td className="p-3">Navigate within tab groups, dropdown options, and multi-article legal viewports.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'feedback' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Accessibility Remediation &amp; Contact</h3>
              <p>
                If you encounter any barrier or difficulty accessing any content, document, or feature within Bloom Studio OS, please let us know:
              </p>

              {feedbackSubmitted ? (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <div className="text-white font-bold text-sm">Thank You for Your Feedback!</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Your accessibility report has been forwarded to our engineering team for prioritized remediation.
                  </p>
                  <button
                    onClick={() => setFeedbackSubmitted(false)}
                    className="px-4 py-1.5 bg-emerald-500/20 text-emerald-300 rounded-xl text-xs font-bold hover:bg-emerald-500/30 transition mt-2"
                  >
                    Submit Another Feedback Item
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitFeedback} className="space-y-3 bg-[#081222] p-4 rounded-2xl border border-white/5">
                  <div>
                    <label htmlFor="feedback-category" className="block text-xs font-bold text-white mb-1">
                      Issue Category:
                    </label>
                    <select
                      id="feedback-category"
                      value={feedbackCategory}
                      onChange={(e) => setFeedbackCategory(e.target.value)}
                      className="w-full bg-[#142850] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-blue-400"
                    >
                      <option value="Screen Reader Issue">Screen Reader / Audio Description Issue</option>
                      <option value="Keyboard Navigation">Keyboard Navigation Barrier</option>
                      <option value="Color Contrast">Color Contrast or Visual Legibility</option>
                      <option value="Form Labeling">Missing Form Label / Input Identifier</option>
                      <option value="Other">Other Accessibility Request</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="feedback-message" className="block text-xs font-bold text-white mb-1">
                      Description of the Accessibility Barrier:
                    </label>
                    <textarea
                      id="feedback-message"
                      rows={3}
                      value={feedbackMessage}
                      onChange={(e) => setFeedbackMessage(e.target.value)}
                      placeholder="Please specify the screen, component, or document and any assistive technology used..."
                      className="w-full bg-[#142850] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder:text-[#7C8AA8] outline-none focus:border-blue-400"
                      required
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-lg shadow-blue-600/20"
                    >
                      Submit Accessibility Report
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 md:p-6 border-t border-white/10 bg-[#081222] flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-2 text-[11px] text-[#7C8AA8] font-mono">
            <Keyboard className="w-4 h-4 text-blue-400" />
            <span>Fully Navigable via Tab &amp; Keyboard Controls</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition shadow-lg shadow-blue-600/20"
            >
              Close Guide
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
