import React, { useState, useEffect, useCallback } from 'react';
import { 
  ShieldCheck, Lock, EyeOff, AlertTriangle, Video, 
  Camera, Zap, RefreshCw, Terminal, CheckCircle2,
  Copy, X, MonitorPlay, Eye, Shield, Info
} from 'lucide-react';
import { Creator } from '../types';

interface DAPSContainerProps {
  children: React.ReactNode;
  title?: string;
  isShieldActive?: boolean;
  viewerTag?: string;
  onSecurityEvent?: (type: string, detail: string) => void;
}

export const DAPSContainer: React.FC<DAPSContainerProps> = ({
  children,
  title = "Traceable Digital Asset Container",
  isShieldActive = true,
  viewerTag = "DIRECTOR_SESSION_AUTHENTICATED",
  onSecurityEvent
}) => {
  const [isBlurred, setIsBlurred] = useState(false);
  const [deterrentNotification, setDeterrentNotification] = useState<string | null>(null);

  // Trigger Deterrent Alert Pill
  const triggerNotificationToast = useCallback((msg: string) => {
    setDeterrentNotification(msg);
    onSecurityEvent?.('DETERRENT_EVENT', msg);
    setTimeout(() => {
      setDeterrentNotification(null);
    }, 3500);
  }, [onSecurityEvent]);

  // Client-side interaction listeners & loss-of-focus auto-blur
  useEffect(() => {
    if (!isShieldActive) return;

    // 1. Hotkey detection (Attribution reminder)
    const handleKeyDown = (e: KeyboardEvent) => {
      // PrintScreen detection
      if (e.key === 'PrintScreen') {
        // Note: Browsers cannot stop OS-level screen capture; we notify about forensic watermarking
        triggerNotificationToast('Capture Hotkey Detected: Dynamic session watermark embedded for attribution.');
      }
      // Ctrl+P / Cmd+P print intercept
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        triggerNotificationToast('Browser print dialog blocked on sensitive rate card asset.');
      }
    };

    // 2. Auto-blur on window blur / tab switch to deter casual over-the-shoulder viewing
    const handleWindowBlur = () => {
      setIsBlurred(true);
    };
    const handleWindowFocus = () => {
      setIsBlurred(false);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [isShieldActive, triggerNotificationToast]);

  // Context Menu (Right Click File Grab) Deterrent
  const handleContextMenu = (e: React.MouseEvent) => {
    if (!isShieldActive) return;
    e.preventDefault();
    triggerNotificationToast('Context menu and direct asset export restricted by DAPS policy.');
  };

  // Drag Start (Text / Image Drag) Deterrent
  const handleDragStart = (e: React.DragEvent) => {
    if (!isShieldActive) return;
    e.preventDefault();
    triggerNotificationToast('Direct drag-and-drop asset extraction restricted.');
  };

  return (
    <div 
      onContextMenu={handleContextMenu}
      onDragStart={handleDragStart}
      className={`relative select-none transition-all duration-300 ${
        isBlurred ? 'filter blur-md pointer-events-none' : ''
      }`}
      style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
    >
      {/* Informative Notification Toast */}
      {deterrentNotification && (
        <div className="fixed bottom-8 right-8 z-[200] bg-[#142850] border border-[#C9A46A]/50 rounded-2xl p-4 shadow-2xl flex items-center gap-3 text-[#E2C799] text-xs font-mono animate-in slide-in-from-bottom-5 duration-200 max-w-md">
          <Info className="w-5 h-5 text-[#C9A46A] flex-shrink-0" />
          <span>{deterrentNotification}</span>
        </div>
      )}

      {/* Embedded Forensic Attribution Watermark */}
      <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center opacity-[0.04] overflow-hidden select-none">
        <div className="text-center rotate-[-20deg]">
          <p className="text-6xl font-black uppercase text-white whitespace-nowrap tracking-wider">
            BLOOM & CO. • PROPRIETARY
          </p>
          <p className="text-sm font-mono text-white mt-1">
            VIEWER REF: {viewerTag} • {new Date().toLocaleDateString()}
          </p>
        </div>
      </div>

      {children}
    </div>
  );
};

interface DAPSCommandCenterProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

export const DigitalAssetProtectionSystem: React.FC<DAPSCommandCenterProps> = ({
  creators,
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}) => {
  const [shieldActive, setShieldActive] = useState(true);
  const [telemetryLogs, setTelemetryLogs] = useState<{ id: string; time: string; event: string; status: string }[]>([
    { id: '1', time: '10:14:22', event: 'Right-Click Context Menu Deterrent', status: 'ACTION_RESTRICTED' },
    { id: '2', time: '09:48:10', event: 'Print Keystroke Intercept (Ctrl+P)', status: 'DIALOG_PREVENTED' },
    { id: '3', time: '08:30:55', event: 'Focus Switch Auto-Blur Active', status: 'VIEW_DEFENSE_ENGAGED' }
  ]);

  const triggerSimulation = (type: 'FOCUS_BLUR' | 'PRINT_PREVENT' | 'RIGHT_CLICK') => {
    const time = new Date().toLocaleTimeString();
    if (type === 'FOCUS_BLUR') {
      setTelemetryLogs(prev => [{ id: Date.now().toString(), time, event: 'Window Focus Lost / Tab Switch', status: 'AUTO_BLUR_ENGAGED' }, ...prev]);
      triggerNotification?.('DAPS Focus Guard', 'Loss-of-focus blur engaged to deter over-the-shoulder viewing.', 'info');
    } else if (type === 'PRINT_PREVENT') {
      setTelemetryLogs(prev => [{ id: Date.now().toString(), time, event: 'Print Hotkey Intercepted (Ctrl+P)', status: 'PREVENT_DEFAULT' }, ...prev]);
      triggerNotification?.('DAPS Policy', 'Browser print dialog blocked on sensitive asset view.', 'warning');
    } else {
      setTelemetryLogs(prev => [{ id: Date.now().toString(), time, event: 'Right-Click Context Menu Restricted', status: 'RESTRICTED' }, ...prev]);
      triggerNotification?.('DAPS Deterrent', 'Right-click context menu and file extraction restricted.', 'info');
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#0E1C38] via-[#142850] to-[#0A162B] border border-[#D4AF37]/20 rounded-3xl p-6 shadow-2xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#D4AF37]/10 rounded-xl text-[#D4AF37]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white tracking-wide">
              Digital Asset Protection & Watermarking (DAPS)
            </h1>
          </div>
          <p className="text-xs text-[#B8C0D4] max-w-2xl">
            Client-side visual deterrence and dynamic session-tagged watermarking layer for talent rate cards, media kits, and agency deliverables.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShieldActive(!shieldActive)}
            className={`px-4 py-2.5 rounded-xl font-mono text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              shieldActive 
                ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300' 
                : 'bg-rose-500/20 border border-rose-500/40 text-rose-300'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>PROTECTION LAYER: {shieldActive ? 'ACTIVE' : 'DISARMED'}</span>
          </button>
        </div>
      </div>

      {/* Transparent Technical Notice */}
      <div className="bg-[#0D1830] border border-[#C9A46A]/20 rounded-2xl p-5 flex items-start gap-4">
        <Info className="w-5 h-5 text-[#C9A46A] shrink-0 mt-0.5" />
        <div className="text-xs text-[#B8C0D4] leading-relaxed space-y-1.5">
          <p className="font-semibold text-white">Browser Security Architecture Notice:</p>
          <p>
            Client-side web applications cannot prevent operating-system-level screen capture tools (such as OS PrintScreen shortcuts, Snipping Tools, OBS Studio, native display recorders, or external recording hardware). 
          </p>
          <p>
            DAPS implements real, client-enforceable controls: <strong className="text-white">loss-of-focus auto-blurring</strong> when switching tabs or windows, <strong className="text-white">right-click and drag restrictions</strong> to deter casual extraction, and <strong className="text-white">dynamic session watermarking</strong> tagged with viewer identity and timestamp for forensic traceability.
          </p>
        </div>
      </div>

      {/* Interactive Protected Viewport Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Protected Asset Sandbox (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-[#142850] border border-white/5 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <MonitorPlay className="w-4 h-4 text-[#D4AF37]" />
                Live Protected Viewport Preview
              </h3>
              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                Deterrent Layer Active
              </span>
            </div>

            <DAPSContainer 
              isShieldActive={shieldActive} 
              viewerTag={`${currentUser?.name || 'Talent Director'} (${currentUser?.email || 'authenticated'})`}
            >
              <div className="bg-[#0B1B3D] border border-white/10 rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-[#D4AF37]">Elena Rostova • Bloom & Co. Exclusive</span>
                    <h4 className="text-base font-bold text-white font-serif">Verified Media Kit & Rate Card 2026</h4>
                  </div>
                  <span className="px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[10px] font-mono rounded-full">
                    Protected Asset
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-3 bg-white/5 rounded-xl">
                    <p className="text-[10px] text-slate-400">TikTok Rate</p>
                    <p className="text-sm font-bold font-mono text-[#D4AF37]">$2,850</p>
                  </div>
                  <div className="p-3 bg-white/5 rounded-xl">
                    <p className="text-[10px] text-slate-400">IG Reel Rate</p>
                    <p className="text-sm font-bold font-mono text-[#D4AF37]">$3,200</p>
                  </div>
                  <div className="p-3 bg-white/5 rounded-xl">
                    <p className="text-[10px] text-slate-400">Engagement</p>
                    <p className="text-sm font-bold font-mono text-emerald-400">8.4%</p>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  Notice the dynamic forensic watermark subtly embedded across the canvas. Tab switching or clicking away will automatically blur this sensitive rate information.
                </p>
              </div>
            </DAPSContainer>
          </div>
        </div>

        {/* Right Column: Security Telemetry & Test Triggers (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#142850] border border-white/5 rounded-3xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" />
              Protection Layer Test Controls
            </h3>

            <div className="space-y-3">
              <button
                onClick={() => triggerSimulation('FOCUS_BLUR')}
                className="w-full p-3.5 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/10 hover:border-amber-500/40 rounded-2xl text-left transition-all flex items-center justify-between cursor-pointer"
              >
                <div>
                  <p className="text-xs font-bold text-white">Simulate Loss of Focus</p>
                  <p className="text-[10px] text-slate-400">Applies automatic blur when user switches windows</p>
                </div>
                <EyeOff className="w-4 h-4 text-amber-400" />
              </button>

              <button
                onClick={() => triggerSimulation('PRINT_PREVENT')}
                className="w-full p-3.5 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/10 hover:border-blue-500/40 rounded-2xl text-left transition-all flex items-center justify-between cursor-pointer"
              >
                <div>
                  <p className="text-xs font-bold text-white">Simulate Print Dialog Intercept</p>
                  <p className="text-[10px] text-slate-400">Blocks Ctrl+P / Cmd+P browser print requests</p>
                </div>
                <Lock className="w-4 h-4 text-blue-400" />
              </button>

              <button
                onClick={() => triggerSimulation('RIGHT_CLICK')}
                className="w-full p-3.5 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/10 hover:border-cyan-500/40 rounded-2xl text-left transition-all flex items-center justify-between cursor-pointer"
              >
                <div>
                  <p className="text-xs font-bold text-white">Simulate Context Menu Restriction</p>
                  <p className="text-[10px] text-slate-400">Prevents right-click browser file saving</p>
                </div>
                <Shield className="w-4 h-4 text-cyan-400" />
              </button>
            </div>
          </div>

          {/* Telemetry Log Stream */}
          <div className="bg-[#142850] border border-white/5 rounded-3xl p-6 shadow-2xl space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest font-mono flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#D4AF37]" />
              DAPS Event Audit Stream
            </h3>

            <div className="space-y-2 max-h-48 overflow-y-auto font-mono text-[11px]">
              {telemetryLogs.map((log) => (
                <div key={log.id} className="p-2.5 bg-[#0B1B3D] rounded-xl flex items-center justify-between text-slate-300 border border-white/5">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-slate-500">{log.time}</span>
                    <p className="text-white">{log.event}</p>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 bg-emerald-500/10 rounded-full">
                    {log.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default DigitalAssetProtectionSystem;
