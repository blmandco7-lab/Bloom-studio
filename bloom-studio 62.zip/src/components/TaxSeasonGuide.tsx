import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, AlertTriangle, Calendar, FileText, Download, ExternalLink, 
  HelpCircle, ShieldCheck, Clock, CheckSquare, Square, Info, Sparkles, 
  ArrowRight, Landmark, DollarSign, Calculator, RefreshCw, Send, Printer
} from 'lucide-react';
import { Creator } from '../types';
import { generateOfficial1099NecPdf } from '../lib/w9PdfGenerator';
import { safeStorage } from '../utils/safeStorage';

interface ChecklistItem {
  id: string;
  category: 'prep' | 'filing' | 'quarterly' | 'audit';
  title: string;
  deadline: string;
  description: string;
  actionLabel?: string;
  actionUrl?: string;
  isCustomAction?: boolean;
  actionType?: 'irs_w9' | 'irs_1099' | 'calc' | 'export';
  completed: boolean;
}

interface TaxSeasonGuideProps {
  creators: Creator[];
  taxItems: any[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onNavigateToTab: (tab: 'compliance' | 'estimated-taxes' | 'accounting-integrations' | 'templates-and-signing') => void;
}

const DEFAULT_CHECKLIST: ChecklistItem[] = [
  // Phase 1: Preparation (Nov - Dec)
  {
    id: 'chk_roster_audit',
    category: 'prep',
    title: 'Audit Roster & Identify Contractors Paid ≥$600',
    deadline: 'December 15',
    description: 'Review cumulative annual earnings across all talent and sub-agency creators. Under IRS rules, any independent contractor or single-member LLC paid $600 or more during the calendar year requires Form 1099-NEC.',
    actionLabel: 'View Compliance Registry',
    actionType: 'export',
    completed: false
  },
  {
    id: 'chk_w9_collection',
    category: 'prep',
    title: 'Collect & Verify Official IRS Form W-9 from All Creators',
    deadline: 'December 31',
    description: 'Ensure every contractor has a signed, current Form W-9 on file with valid legal name, tax classification (LLC, Sole Prop, Corp), and Taxpayer Identification Number (SSN or EIN). Missing W-9s risk mandatory 24% backup withholding.',
    actionLabel: 'Open Official IRS W-9 (PDF)',
    actionUrl: 'https://www.irs.gov/pub/irs-pdf/fw9.pdf',
    completed: false
  },
  {
    id: 'chk_tin_matching',
    category: 'prep',
    title: 'Verify Legal Names & TINs to Avoid IRS CP2100 "B-Notices"',
    deadline: 'January 10',
    description: 'Confirm that creator legal names match IRS social security or employer identification records. Name/TIN mismatches trigger IRS penalty notices ($310 per incorrect form) and backup withholding mandates.',
    actionLabel: 'IRS TIN Matching Portal',
    actionUrl: 'https://www.irs.gov/tax-professionals/taxpayer-identification-number-tin-matching',
    completed: false
  },
  {
    id: 'chk_ledger_reconciliation',
    category: 'prep',
    title: 'Reconcile Escrow Disbursements & Gross Campaign Payouts',
    deadline: 'January 15',
    description: 'Verify that all brand sponsor payouts, commission splits, and escrow releases match bank records and general ledger accounting entries before finalizing 1099 box figures.',
    actionLabel: 'Open Accounting Integrations',
    actionType: 'calc',
    completed: false
  },

  // Phase 2: January 31 Mandatory Filing
  {
    id: 'chk_1099_generation',
    category: 'filing',
    title: 'Generate Official IRS Form 1099-NEC (Nonemployee Compensation)',
    deadline: 'January 25',
    description: 'Prepare Form 1099-NEC with contractor compensation in Box 1. Ensure payer details (Agency Name, Address, EIN) and recipient details match executed W-9 records.',
    actionLabel: 'Open Official 1099-NEC (PDF)',
    actionUrl: 'https://www.irs.gov/pub/irs-pdf/f1099nec.pdf',
    completed: false
  },
  {
    id: 'chk_copy_b_dispatch',
    category: 'filing',
    title: 'Deliver Form 1099-NEC (Copy B) to All Creators by Jan 31',
    deadline: 'January 31 (Strict)',
    description: 'IRS statutory deadline: Copy B must be delivered to recipients electronically (with prior consent) or postmarked by January 31. Failure to distribute timely incurs IRS late filing penalties.',
    actionLabel: 'Distribute 1099s to Creators',
    actionType: 'irs_1099',
    completed: false
  },
  {
    id: 'chk_copy_a_irs_filing',
    category: 'filing',
    title: 'File Form 1099-NEC (Copy A) & Form 1096 with the IRS',
    deadline: 'January 31 (Strict)',
    description: 'Submit Copy A to the IRS electronically via the IRS IRIS portal or FIRE system. Electronic filing is required for businesses filing 10 or more information returns.',
    actionLabel: 'IRS IRIS Electronic Filing Portal',
    actionUrl: 'https://www.irs.gov/e-file-providers/information-returns-intake-system-iris',
    completed: false
  },
  {
    id: 'chk_state_filing',
    category: 'filing',
    title: 'Verify State-Level 1099 Filing Requirements',
    deadline: 'January 31 - March 31',
    description: 'Confirm state tax department filing requirements. While the Combined Federal/State Filing (CFSF) program forwards returns to participating states, certain states (e.g., CA, NY, PA) require direct electronic reporting.',
    actionLabel: 'IRS CFSF Guidelines',
    actionUrl: 'https://www.irs.gov/filing/state-information-returns',
    completed: false
  },

  // Phase 3: Quarterly Estimated Taxes (Form 1040-ES)
  {
    id: 'chk_quarterly_schedule',
    category: 'quarterly',
    title: 'Quarterly Estimated Taxes (Form 1040-ES) Schedule',
    deadline: 'Apr 15 / Jun 15 / Sep 15 / Jan 15',
    description: 'Self-employed creators and agency owners must pay quarterly estimated taxes (15.3% Self-Employment Tax + Federal Marginal Income Tax) to avoid IRS underpayment penalties under IRC § 6654.',
    actionLabel: 'Open Estimated Tax Calculator',
    actionType: 'calc',
    completed: false
  },
  {
    id: 'chk_auto_withholding',
    category: 'quarterly',
    title: 'Set Auto-Withholding Holdback Reserves (25-30%)',
    deadline: 'Ongoing',
    description: 'Configure automated escrow holdbacks so a portion of each deal payout is reserved into a separate tax holding ledger, ensuring seamless quarterly payments without cashflow surprises.',
    actionLabel: 'Configure Holdback Rate',
    actionType: 'calc',
    completed: false
  },

  // Phase 4: Retention & CPA Review
  {
    id: 'chk_record_retention',
    category: 'audit',
    title: 'Archive 1099 Delivery Receipts & W-9s for 7-Year Retention',
    deadline: 'February 15',
    description: 'IRS compliance guidelines mandate retaining all information returns, executed W-9 certificates, digital signature audit hashes, and payment records for a minimum of 4 to 7 years.',
    actionLabel: 'Export Full Tax Package',
    actionType: 'export',
    completed: false
  },
  {
    id: 'chk_cpa_audit',
    category: 'audit',
    title: 'Sync General Ledger with Wave / Zoho Books or Invite CPA',
    deadline: 'February 28',
    description: 'Export clean transaction journals to Wave or Zoho Books, or invite your certified public accountant (CPA) with secure auditor credentials to review deductions and prepare annual returns.',
    actionLabel: 'Configure Accounting Integrations',
    actionType: 'calc',
    completed: false
  }
];

export default function TaxSeasonGuide({
  creators,
  taxItems,
  onAddActivityLog,
  triggerNotification,
  onNavigateToTab
}: TaxSeasonGuideProps) {
  const [checklist, setChecklist] = useState<ChecklistItem[]>(() => {
    try {
      const saved = safeStorage.getItem('bloom_tax_season_checklist');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_CHECKLIST;
  });

  const [filterCategory, setFilterCategory] = useState<'all' | 'prep' | 'filing' | 'quarterly' | 'audit'>('all');

  useEffect(() => {
    try {
      safeStorage.setItem('bloom_tax_season_checklist', JSON.stringify(checklist));
    } catch {}
  }, [checklist]);

  const toggleChecklist = (id: string) => {
    setChecklist(prev => prev.map(item => {
      if (item.id === id) {
        const nextState = !item.completed;
        if (nextState) {
          triggerNotification('Tax Task Completed', `Marked "${item.title}" as finished.`, 'success');
          onAddActivityLog('Director', 'director', `Completed tax checklist item: ${item.title}`);
        }
        return { ...item, completed: nextState };
      }
      return item;
    }));
  };

  const completedCount = checklist.filter(c => c.completed).length;
  const progressPct = Math.round((completedCount / checklist.length) * 100);

  const filteredItems = checklist.filter(c => {
    if (filterCategory === 'all') return true;
    return c.category === filterCategory;
  });

  // Calculate live statistics from taxItems
  const totalPaid = taxItems.reduce((acc, t) => acc + (t.earnings1099 || 0), 0);
  const eligible1099Count = taxItems.filter(t => (t.earnings1099 || 0) >= 600).length;
  const missingW9Count = taxItems.filter(t => t.w9Status === 'Missing' && (t.earnings1099 || 0) >= 600).length;
  const filed1099Count = taxItems.filter(t => t.status1099 === 'Filed & Sent').length;

  const handleActionClick = (item: ChecklistItem) => {
    if (item.actionUrl) {
      window.open(item.actionUrl, '_blank', 'noopener,noreferrer');
      triggerNotification('IRS Resource Opened', `Opened official portal in a new tab: ${item.actionLabel}`, 'info');
      return;
    }

    if (item.actionType === 'export') {
      onNavigateToTab('compliance');
    } else if (item.actionType === 'calc') {
      onNavigateToTab('estimated-taxes');
    } else if (item.actionType === 'irs_1099') {
      onNavigateToTab('compliance');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Overview & Live Compliance Status Bar */}
      <div className="bg-gradient-to-br from-[#111E33] via-[#0E1B33] to-[#0A1325] border border-[#C9A46A]/20 rounded-2xl p-6 relative overflow-hidden shadow-xl">
        <div className="absolute -top-10 -right-10 w-52 h-52 bg-radial-gradient(circle,rgba(201,164,106,0.12)_0%,transparent_70%) pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider bg-[#C9A46A]/10 border border-[#C9A46A]/20 px-2.5 py-0.5 rounded-full">
                Official Agency Tax Season Manual
              </span>
              <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-950/40 border border-emerald-500/20 px-2 py-0.5 rounded-full flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> IRS 2026 Tax Year Active
              </span>
            </div>
            <h2 className="font-serif font-bold text-2xl md:text-3xl text-white">
              What to Do Around Tax Season: W-9 &amp; 1099-NEC Master Guide
            </h2>
            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Step-by-step compliance protocol for talent agencies, independent creators, and managers. Follow the 4 key phases below to prevent IRS penalties, avoid mandatory backup withholding, and execute seamless 1099 filing.
            </p>
          </div>

          {/* Progress Tracker Card */}
          <div className="bg-[#080E1C]/80 border border-white/10 rounded-2xl p-4 min-w-[240px] space-y-3 shrink-0 shadow-inner">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-300">Tax Season Readiness</span>
              <span className="text-sm font-mono font-bold text-[#C9A46A]">{progressPct}%</span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#C9A46A] to-emerald-400 transition-all duration-500 rounded-full"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>{completedCount} of {checklist.length} tasks completed</span>
              {progressPct === 100 ? (
                <span className="text-emerald-400 font-bold">✓ 100% Ready</span>
              ) : (
                <span className="text-amber-400">{checklist.length - completedCount} remaining</span>
              )}
            </div>
          </div>
        </div>

        {/* Live Metrics Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-white/10">
          <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3">
            <span className="text-[10px] font-mono text-[#7C8AA8] uppercase block">Total Creator Payouts</span>
            <span className="text-base font-bold font-mono text-white mt-0.5 block">${totalPaid.toLocaleString()}</span>
            <span className="text-[9px] text-slate-400 mt-0.5 block">Total 1099 taxable ledger</span>
          </div>
          <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3">
            <span className="text-[10px] font-mono text-[#7C8AA8] uppercase block">Eligible 1099 Payees (≥$600)</span>
            <span className="text-base font-bold font-mono text-[#C9A46A] mt-0.5 block">{eligible1099Count} Creators</span>
            <span className="text-[9px] text-slate-400 mt-0.5 block">Requires 1099-NEC by Jan 31</span>
          </div>
          <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3">
            <span className="text-[10px] font-mono text-[#7C8AA8] uppercase block">Missing W-9 Warning</span>
            <span className={`text-base font-bold font-mono mt-0.5 block ${missingW9Count > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {missingW9Count} Urgent
            </span>
            <span className="text-[9px] text-slate-400 mt-0.5 block">Needs W-9 before payment</span>
          </div>
          <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3">
            <span className="text-[10px] font-mono text-[#7C8AA8] uppercase block">1099 Filing Status</span>
            <span className="text-base font-bold font-mono text-cyan-400 mt-0.5 block">{filed1099Count} / {eligible1099Count} Filed</span>
            <span className="text-[9px] text-slate-400 mt-0.5 block">Dispatched &amp; submitted</span>
          </div>
        </div>
      </div>

      {/* Critical Tax Rules Cheat Sheet (The 4 Golden Rules) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0D1830] border border-amber-500/20 rounded-2xl p-4 space-y-2 relative overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <DollarSign className="w-4 h-4" />
          </div>
          <h3 className="font-serif font-bold text-white text-sm">Rule 1: The $600 Threshold</h3>
          <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
            Any creator, editor, or contractor paid <strong>$600 or more</strong> cumulatively in a calendar year MUST receive an IRS Form 1099-NEC. Below $600 is exempt from 1099 filing, though the creator must still report income.
          </p>
        </div>

        <div className="bg-[#0D1830] border border-rose-500/20 rounded-2xl p-4 space-y-2 relative overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
            <Calendar className="w-4 h-4" />
          </div>
          <h3 className="font-serif font-bold text-white text-sm">Rule 2: January 31 Deadline</h3>
          <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
            Form 1099-NEC has a strict <strong>January 31 filing deadline</strong> with NO automatic 30-day extensions. You must provide Copy B to the creator AND file Copy A with the IRS by this date.
          </p>
        </div>

        <div className="bg-[#0D1830] border border-sky-500/20 rounded-2xl p-4 space-y-2 relative overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <h3 className="font-serif font-bold text-white text-sm">Rule 3: W-9 Before Payout</h3>
          <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
            Always collect a completed, signed <strong>Form W-9 before paying</strong> any contractor. If a contractor refuses to provide a TIN/SSN, federal law mandates withholding <strong>24% backup withholding</strong>.
          </p>
        </div>

        <div className="bg-[#0D1830] border border-emerald-500/20 rounded-2xl p-4 space-y-2 relative overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Calculator className="w-4 h-4" />
          </div>
          <h3 className="font-serif font-bold text-white text-sm">Rule 4: 15.3% SE Tax + Estimates</h3>
          <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
            Independent creators pay 15.3% Self-Employment tax on 92.35% of net profit. Pay quarterly estimates (Form 1040-ES) on <strong>Apr 15, Jun 15, Sep 15, Jan 15</strong> to prevent IRS underpayment penalties.
          </p>
        </div>
      </div>

      {/* Interactive Step-by-Step Checklist */}
      <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div>
            <h3 className="font-serif font-semibold text-lg text-white flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-[#C9A46A]" /> Tax Season Execution Checklist
            </h3>
            <p className="text-xs text-[#7C8AA8] mt-0.5">
              Click any item to mark it complete. Click the action button to access official forms or open internal tools.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-1.5 bg-[#111E33] p-1 rounded-xl border border-white/5 text-xs">
            <button
              onClick={() => setFilterCategory('all')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterCategory === 'all' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'
              }`}
            >
              All ({checklist.length})
            </button>
            <button
              onClick={() => setFilterCategory('prep')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterCategory === 'prep' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'
              }`}
            >
              1. Prep (Nov-Dec)
            </button>
            <button
              onClick={() => setFilterCategory('filing')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterCategory === 'filing' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'
              }`}
            >
              2. Jan 31 Filing
            </button>
            <button
              onClick={() => setFilterCategory('quarterly')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterCategory === 'quarterly' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'
              }`}
            >
              3. Quarterly ES
            </button>
            <button
              onClick={() => setFilterCategory('audit')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                filterCategory === 'audit' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'
              }`}
            >
              4. CPA &amp; Retention
            </button>
          </div>
        </div>

        {/* Checklist List */}
        <div className="space-y-3">
          {filteredItems.map(item => (
            <div
              key={item.id}
              className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                item.completed
                  ? 'bg-emerald-950/20 border-emerald-500/20 text-slate-300'
                  : 'bg-[#111E33]/70 hover:bg-[#111E33] border-white/5 text-white'
              }`}
            >
              <div className="flex items-start gap-3.5 flex-1">
                <button
                  type="button"
                  onClick={() => toggleChecklist(item.id)}
                  className="mt-0.5 text-slate-400 hover:text-white transition-colors cursor-pointer shrink-0"
                >
                  {item.completed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-500 hover:text-[#C9A46A]" />
                  )}
                </button>

                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`font-semibold text-sm ${item.completed ? 'line-through text-slate-400' : 'text-white'}`}>
                      {item.title}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0D1830] border border-white/10 text-amber-300">
                      📅 {item.deadline}
                    </span>
                    <span className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase font-bold ${
                      item.category === 'prep' ? 'bg-indigo-950 text-indigo-300 border border-indigo-500/20' :
                      item.category === 'filing' ? 'bg-rose-950 text-rose-300 border border-rose-500/20' :
                      item.category === 'quarterly' ? 'bg-amber-950 text-amber-300 border border-amber-500/20' :
                      'bg-emerald-950 text-emerald-300 border border-emerald-500/20'
                    }`}>
                      {item.category === 'prep' ? 'Phase 1: Prep' :
                       item.category === 'filing' ? 'Phase 2: Filing' :
                       item.category === 'quarterly' ? 'Phase 3: Estimates' :
                       'Phase 4: CPA/Audit'}
                    </span>
                  </div>
                  <p className="text-xs text-[#7C8AA8] leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              {item.actionLabel && (
                <div className="shrink-0 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleActionClick(item)}
                    className="bg-[#16243F] hover:bg-[#1f3154] border border-[#C9A46A]/30 hover:border-[#C9A46A] text-[#C9A46A] text-xs font-semibold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-sm cursor-pointer whitespace-nowrap"
                  >
                    {item.actionUrl ? <ExternalLink className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                    {item.actionLabel}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Official Government Tax Resources Quick Links */}
      <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-4">
        <h3 className="font-serif font-semibold text-base text-white flex items-center gap-2">
          <Landmark className="w-4 h-4 text-[#C9A46A]" /> Official IRS &amp; State Government Tax Portals
        </h3>
        <p className="text-xs text-[#7C8AA8]">
          Direct authoritative links to official IRS.gov portals, form PDFs, and payment systems.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
          <a
            href="https://www.irs.gov/pub/irs-pdf/fw9.pdf"
            target="_blank"
            rel="noreferrer"
            className="p-3.5 bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl flex items-center justify-between transition-all group"
          >
            <div>
              <span className="font-semibold text-xs text-white group-hover:text-[#C9A46A] block">IRS Form W-9 (Official PDF)</span>
              <span className="text-[10px] text-slate-400">Request for Taxpayer ID &amp; Certification</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#C9A46A] shrink-0" />
          </a>

          <a
            href="https://www.irs.gov/pub/irs-pdf/f1099nec.pdf"
            target="_blank"
            rel="noreferrer"
            className="p-3.5 bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl flex items-center justify-between transition-all group"
          >
            <div>
              <span className="font-semibold text-xs text-white group-hover:text-[#C9A46A] block">IRS Form 1099-NEC (Official PDF)</span>
              <span className="text-[10px] text-slate-400">Nonemployee Compensation Form</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#C9A46A] shrink-0" />
          </a>

          <a
            href="https://www.irs.gov/e-file-providers/information-returns-intake-system-iris"
            target="_blank"
            rel="noreferrer"
            className="p-3.5 bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl flex items-center justify-between transition-all group"
          >
            <div>
              <span className="font-semibold text-xs text-white group-hover:text-[#C9A46A] block">IRS IRIS E-Filing System</span>
              <span className="text-[10px] text-slate-400">Free electronic filing for 1099 returns</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#C9A46A] shrink-0" />
          </a>

          <a
            href="https://www.irs.gov/payments/direct-pay"
            target="_blank"
            rel="noreferrer"
            className="p-3.5 bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl flex items-center justify-between transition-all group"
          >
            <div>
              <span className="font-semibold text-xs text-white group-hover:text-[#C9A46A] block">IRS Direct Pay (Quarterly ES)</span>
              <span className="text-[10px] text-slate-400">Pay 1040-ES estimated taxes online</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#C9A46A] shrink-0" />
          </a>

          <a
            href="https://www.eftps.gov"
            target="_blank"
            rel="noreferrer"
            className="p-3.5 bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl flex items-center justify-between transition-all group"
          >
            <div>
              <span className="font-semibold text-xs text-white group-hover:text-[#C9A46A] block">EFTPS Federal Tax Payments</span>
              <span className="text-[10px] text-slate-400">Electronic Federal Tax Payment System</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#C9A46A] shrink-0" />
          </a>

          <a
            href="https://www.irs.gov/forms-pubs/about-schedule-c-form-1040"
            target="_blank"
            rel="noreferrer"
            className="p-3.5 bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/40 rounded-xl flex items-center justify-between transition-all group"
          >
            <div>
              <span className="font-semibold text-xs text-white group-hover:text-[#C9A46A] block">IRS Schedule C (Profit &amp; Loss)</span>
              <span className="text-[10px] text-slate-400">Sole proprietorship business deductions</span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-[#C9A46A] shrink-0" />
          </a>
        </div>
      </div>
    </div>
  );
}
