import React, { useState } from 'react';
import { 
  Landmark, 
  FileText, 
  ShieldCheck, 
  Download, 
  ExternalLink, 
  CheckCircle2, 
  Upload, 
  Eye, 
  EyeOff, 
  Lock, 
  Sparkles, 
  Check, 
  AlertTriangle, 
  FileSignature,
  Building, 
  UserCheck, 
  Shield, 
  HelpCircle, 
  ArrowUpRight, 
  CheckSquare, 
  Square, 
  RefreshCw,
  Calculator,
  BookOpen,
  DollarSign
} from 'lucide-react';
import { Creator } from '../types';
import { IrsTaxIntakeVault } from './IrsTaxIntakeVault';
import W9And1099Tracker from './W9And1099Tracker';

interface UnifiedTaxHubProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
  defaultTab?: 'vault' | 'tracker';
}

export const UnifiedTaxHub: React.FC<UnifiedTaxHubProps> = ({
  creators = [],
  currentUser,
  currentRole = 'creator',
  onAddActivityLog,
  triggerNotification,
  defaultTab = 'vault'
}) => {
  const [activeMainTab, setActiveMainTab] = useState<'vault' | 'tracker'>(defaultTab);

  const primaryBrandColor = '#C9A46A';
  const cardBgColor = '#0D1830';

  return (
    <div className="space-y-6 animate-fade-in" id="unifiedTaxHubContainer">
      {/* Top Master Header & Navigation Banner */}
      <div 
        className="rounded-2xl p-6 border shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6"
        style={{
          backgroundColor: cardBgColor,
          borderColor: `${primaryBrandColor}30`
        }}
      >
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold px-2.5 py-1 rounded-full border text-[#C9A46A] border-[#C9A46A]/30 bg-[#C9A46A]/10 flex items-center gap-1.5">
              <Landmark className="w-3 h-3" />
              Official IRS &amp; Creator Tax Center
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
              Secure 256-bit Encrypted Vault
            </span>
          </div>

          <h1 className="text-2xl lg:text-3xl font-serif font-bold text-white tracking-tight flex items-center gap-3">
            <ShieldCheck className="w-7 h-7 text-[#C9A46A]" />
            <span>Official Tax Vault &amp; W-9 / 1099 Tracker Hub</span>
          </h1>

          <p className="text-xs text-slate-300 leading-relaxed">
            Manage your certified IRS Form W-9, verify Taxpayer Identification Numbers (TIN), track 1099-NEC creator earnings, and access tax season compliance guides in one unified secure dashboard.
          </p>
        </div>

        {/* Master Tab Selector */}
        <div className="flex flex-col sm:flex-row items-center gap-2.5 shrink-0 bg-[#070D18] p-1.5 rounded-2xl border border-white/10 shadow-inner">
          <button
            type="button"
            id="tabBtnOfficialTaxVault"
            onClick={() => setActiveMainTab('vault')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeMainTab === 'vault'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Landmark className="w-4 h-4" />
            <span>Official Tax Vault &amp; W-9 Builder</span>
          </button>

          <button
            type="button"
            id="tabBtnW9And1099Tracker"
            onClick={() => setActiveMainTab('tracker')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeMainTab === 'tracker'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>W-9 &amp; 1099 Tax Tracker &amp; Filing</span>
          </button>
        </div>
      </div>

      {/* Render Active Sub-Hub */}
      <div className="transition-all">
        {activeMainTab === 'vault' ? (
          <IrsTaxIntakeVault
            creators={creators}
            currentUser={currentUser}
            currentRole={currentRole}
            onAddActivityLog={onAddActivityLog}
            triggerNotification={triggerNotification}
          />
        ) : (
          <W9And1099Tracker
            creators={creators}
            currentUser={currentUser}
            currentRole={currentRole}
            onAddActivityLog={onAddActivityLog || (() => {})}
            triggerNotification={triggerNotification || (() => {})}
          />
        )}
      </div>
    </div>
  );
};
