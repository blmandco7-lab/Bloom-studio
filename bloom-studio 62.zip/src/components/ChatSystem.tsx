/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Send, 
  Paperclip, 
  Trash, 
  MessageSquare, 
  Search, 
  Plus, 
  X, 
  User, 
  Users, 
  Building2, 
  Sparkles, 
  Check, 
  ShieldCheck, 
  Lock, 
  AlertTriangle,
  Info,
  ChevronRight
} from 'lucide-react';
import { Message, Thread, Role, Creator, Deal } from '../types';
import { 
  getRecipientsForRole, 
  isAllowedToMessage, 
  getRoleMessagingDescription,
  DirectoryPerson,
  identifyPersonRole
} from '../lib/messagingRules';

interface ChatSystemProps {
  currentRole: Role;
  currentUser: any; // Signed-in user details
  creators: Creator[];
  deals: Deal[];
  campaigns?: any[];
  threads: Thread[];
  onSendMessage: (threadId: string, text: string, attachment?: any) => void;
  onAddThread: (name: string, role: string) => void;
  onDeleteThread: (threadId: string) => void;
}

export default function ChatSystem({ 
  currentRole, 
  currentUser, 
  creators, 
  deals, 
  campaigns = [],
  threads, 
  onSendMessage, 
  onAddThread, 
  onDeleteThread 
}: ChatSystemProps) {
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(null);
  const [msgText, setMsgText] = useState('');
  const [attachment, setAttachment] = useState<{ name: string; data: string; type: string } | null>(null);
  const [showNewMessageModal, setShowNewMessageModal] = useState(false);
  const [directorySearch, setDirectorySearch] = useState('');
  const [threadSearch, setThreadSearch] = useState('');
  const [pendingSelectName, setPendingSelectName] = useState<string | null>(null);
  const [securityNotice, setSecurityNotice] = useState<string | null>(null);

  // Role permissions info
  const roleDesc = useMemo(() => {
    return getRoleMessagingDescription(currentRole);
  }, [currentRole]);

  // 1. Authorized recipients list for the active role
  const allRecipients = useMemo(() => {
    return getRecipientsForRole(currentRole, currentUser, creators, deals, campaigns);
  }, [currentRole, currentUser, creators, deals, campaigns]);

  // 2. Filter threads based on role permissions and sidebar search
  const visibleThreads = useMemo(() => {
    // Only show threads that the current role is authorized to communicate with
    const authorized = threads.filter(t => {
      const perm = isAllowedToMessage(
        currentRole, 
        currentUser, 
        { name: t.name, role: t.role }, 
        creators, 
        deals, 
        campaigns
      );
      return perm.allowed;
    });

    if (!threadSearch.trim()) {
      return authorized;
    }

    const q = threadSearch.toLowerCase();
    return authorized.filter(t => 
      t.name.toLowerCase().includes(q) || 
      t.role.toLowerCase().includes(q) ||
      t.messages.some(m => m.text.toLowerCase().includes(q))
    );
  }, [threads, threadSearch, currentRole, currentUser, creators, deals, campaigns]);

  // Ensure active thread is selected and valid
  useEffect(() => {
    if (visibleThreads.length > 0) {
      if (!selectedThreadId || !visibleThreads.some(t => t.id === selectedThreadId)) {
        setSelectedThreadId(visibleThreads[0].id);
      }
    } else {
      setSelectedThreadId(null);
    }
  }, [visibleThreads, selectedThreadId]);

  // Auto-select a newly created thread when pendingSelectName is set
  useEffect(() => {
    if (pendingSelectName) {
      const found = visibleThreads.find(t => 
        t.name.toLowerCase() === pendingSelectName.toLowerCase() || 
        t.name.toLowerCase().includes(pendingSelectName.toLowerCase()) ||
        pendingSelectName.toLowerCase().includes(t.name.toLowerCase())
      );
      if (found) {
        setSelectedThreadId(found.id);
        setPendingSelectName(null);
      }
    }
  }, [visibleThreads, pendingSelectName]);

  const handleStartDirectMessage = (personName: string, personRole: string, personHandle?: string) => {
    if (!personName) return;

    // Check permission
    const perm = isAllowedToMessage(
      currentRole, 
      currentUser, 
      { name: personName, role: personRole, handle: personHandle }, 
      creators, 
      deals, 
      campaigns
    );

    if (!perm.allowed) {
      setSecurityNotice(perm.reason || 'This messaging recipient is not authorized for your role.');
      return;
    }

    // Check if thread already exists
    const existing = visibleThreads.find(t => 
      t.name.toLowerCase() === personName.toLowerCase() || 
      (personHandle && t.name.toLowerCase() === personHandle.toLowerCase()) ||
      t.name.toLowerCase().includes(personName.toLowerCase()) ||
      personName.toLowerCase().includes(t.name.toLowerCase())
    );

    if (existing) {
      setSelectedThreadId(existing.id);
    } else {
      const threadName = personHandle || personName;
      onAddThread(threadName, personRole);
      setPendingSelectName(threadName);
    }
    setShowNewMessageModal(false);
    setDirectorySearch('');
    setSecurityNotice(null);
  };

  const handleSelectRecipientFromDropdown = (recipientName: string) => {
    if (!recipientName) return;
    const targetRecipient = allRecipients.find(r => r.name === recipientName);
    if (!targetRecipient) return;
    handleStartDirectMessage(targetRecipient.name, targetRecipient.role, targetRecipient.handle);
  };

  const activeThread = visibleThreads.find(t => t.id === selectedThreadId);

  // Check if active thread is authorized for sending
  const activeThreadPermission = useMemo(() => {
    if (!activeThread) return { allowed: false, reason: 'No conversation selected.' };
    return isAllowedToMessage(
      currentRole, 
      currentUser, 
      { name: activeThread.name, role: activeThread.role }, 
      creators, 
      deals, 
      campaigns
    );
  }, [activeThread, currentRole, currentUser, creators, deals, campaigns]);

  const handleSend = () => {
    if (!msgText.trim() && !attachment) return;
    if (!selectedThreadId || !activeThread) return;

    if (!activeThreadPermission.allowed) {
      setSecurityNotice(activeThreadPermission.reason || 'Messaging route restricted.');
      return;
    }

    onSendMessage(selectedThreadId, msgText, attachment || undefined);
    setMsgText('');
    setAttachment(null);
    setSecurityNotice(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 700000) {
      alert("Attachment size too large! Please upload files under 700KB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      setAttachment({
        name: file.name,
        data: ev.target?.result as string,
        type: file.type
      });
    };
    reader.readAsDataURL(file);
  };

  const renderMessageContent = (m: Message) => {
    return (
      <div className="space-y-1.5">
        <p className="text-xs leading-relaxed">{m.text}</p>
        {m.attachment && (
          <div className="mt-2 p-2 bg-[#0A1220]/60 border border-white/5 rounded-lg flex items-center justify-between gap-4">
            <span className="text-[10px] font-mono text-[#C9A46A] truncate max-w-[120px]">{m.attachment.name}</span>
            <a 
              href={m.attachment.data} 
              download={m.attachment.name}
              className="text-[10px] bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-2 py-0.5 rounded font-semibold whitespace-nowrap"
            >
              Download
            </a>
          </div>
        )}
      </div>
    );
  };

  // Filtered recipients for directory modal
  const modalFilteredRecipients = useMemo(() => {
    if (!directorySearch.trim()) return allRecipients;
    const q = directorySearch.toLowerCase();
    return allRecipients.filter(r => 
      r.name.toLowerCase().includes(q) || 
      r.role.toLowerCase().includes(q) || 
      (r.handle && r.handle.toLowerCase().includes(q)) ||
      (r.relationshipNote && r.relationshipNote.toLowerCase().includes(q))
    );
  }, [allRecipients, directorySearch]);

  const categories = useMemo(() => {
    return Array.from(new Set(modalFilteredRecipients.map(r => r.category)));
  }, [modalFilteredRecipients]);

  return (
    <div className="space-y-6">
      {/* Top Header & Role Permissions Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#0D1830] border border-[#rgba(201,164,106,0.18)] rounded-2xl p-5 shadow-lg">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-3">
            <h1 className="font-sans font-medium text-2xl tracking-tight text-white flex items-center gap-2">
              <Send className="text-[#C9A46A] w-6 h-6" /> Role-Based Messaging
            </h1>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#16243F] border border-[#C9A46A]/30 text-[#C9A46A]">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{roleDesc.title}</span>
            </span>
          </div>
          
          <p className="text-xs text-[#7C8AA8] leading-relaxed">
            {roleDesc.summary}
          </p>

          <div className="flex items-center gap-2 pt-1">
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-md flex items-center gap-1">
              <Lock className="w-3 h-3" />
              <span>{roleDesc.allowedSummary}</span>
            </span>
          </div>
        </div>

        {/* Action Controls: New DM Modal button + Quick Dropdown */}
        <div className="flex flex-wrap items-center gap-3 self-start lg:self-center">
          <button
            type="button"
            onClick={() => setShowNewMessageModal(true)}
            className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transition-colors shadow-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Direct Message</span>
          </button>

          <div className="flex items-center gap-2 bg-[#111E33] border border-[#C9A46A]/30 rounded-xl p-2">
            <MessageSquare className="w-4 h-4 text-[#C9A46A] shrink-0" />
            <span className="text-xs font-semibold text-white whitespace-nowrap hidden sm:inline">Quick Select:</span>
            <select 
              onChange={e => handleSelectRecipientFromDropdown(e.target.value)}
              className="bg-[#0D1830] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white outline-none focus:border-[#C9A46A] cursor-pointer max-w-[220px]"
              defaultValue=""
            >
              <option value="" disabled>Select authorized contact...</option>
              {categories.map(cat => (
                <optgroup key={cat} label={cat}>
                  {allRecipients.filter(r => r.category === cat).map(r => (
                    <option key={r.name} value={r.name}>
                      {r.name} ({r.role})
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Security alert if violation attempted */}
      {securityNotice && (
        <div className="bg-rose-950/40 border border-rose-500/40 rounded-xl p-4 flex items-start justify-between gap-3 text-rose-200 text-xs animate-in fade-in">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <strong className="font-semibold block text-rose-300">Role-Based Access Policy Enforced</strong>
              <p className="mt-0.5 text-rose-200/90">{securityNotice}</p>
            </div>
          </div>
          <button 
            type="button" 
            onClick={() => setSecurityNotice(null)} 
            className="text-rose-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Messaging Interface */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-0 bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl overflow-hidden shadow-xl min-h-[520px]">
        {/* Thread Sidebar (Left) */}
        <div className="md:col-span-4 border-r border-[#rgba(201,164,106,0.14)] flex flex-col">
          <div className="p-4 border-b border-[#rgba(201,164,106,0.14)] bg-[#111E33] space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-[#7C8AA8] uppercase tracking-wider flex items-center gap-1.5">
                <span>Conversations</span>
                <span className="bg-[#16243F] text-[#C9A46A] px-1.5 py-0.2 rounded text-[10px]">
                  {visibleThreads.length}
                </span>
              </h3>
              <button
                type="button"
                onClick={() => setShowNewMessageModal(true)}
                className="text-[#C9A46A] hover:text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New</span>
              </button>
            </div>

            {/* Search Input for Threads */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#7C8AA8] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search conversations..."
                value={threadSearch}
                onChange={e => setThreadSearch(e.target.value)}
                className="w-full bg-[#0D1830] border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-[#7C8AA8] outline-none focus:border-[#C9A46A]"
              />
              {threadSearch && (
                <button
                  type="button"
                  onClick={() => setThreadSearch('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-[#7C8AA8] hover:text-white text-xs"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-[#rgba(201,164,106,0.14)] max-h-[440px]">
            {visibleThreads.length === 0 ? (
              <div className="p-6 text-center text-[#7C8AA8] text-xs space-y-3">
                <p>No active conversations matching your role permissions.</p>
                <button
                  type="button"
                  onClick={() => setShowNewMessageModal(true)}
                  className="text-[#C9A46A] underline font-semibold hover:text-[#E3C48F] block mx-auto cursor-pointer"
                >
                  Start a new authorized message &rarr;
                </button>
              </div>
            ) : (
              visibleThreads.map(t => {
                const isSelected = t.id === selectedThreadId;
                const initials = t.name.replace('@', '').substring(0, 2).toUpperCase();
                const lastMsg = t.messages[t.messages.length - 1];
                const pRole = identifyPersonRole({ name: t.name, role: t.role });
                
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setSelectedThreadId(t.id)}
                    className={`w-full text-left p-3.5 flex gap-3 items-center cursor-pointer transition-colors ${
                      isSelected ? 'bg-[#111E33] border-l-2 border-[#C9A46A]' : 'hover:bg-[#111E33]/40'
                    }`}
                    aria-label={`Conversation with ${t.name} (${t.role})`}
                    aria-current={isSelected ? 'true' : 'false'}
                  >
                    <div className="w-9 h-9 rounded-full bg-[#16243F] border border-[#C9A46A]/20 flex items-center justify-center font-bold text-[#C9A46A] text-xs shrink-0">
                      {initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <h4 className="text-xs font-semibold text-white truncate">{t.name}</h4>
                        <span className="text-[9px] text-[#7C8AA8] font-mono capitalize shrink-0 ml-1">{t.role}</span>
                      </div>
                      <p className="text-[10px] text-[#7C8AA8] truncate mt-1 leading-normal">
                        {lastMsg ? lastMsg.text : 'No messages yet'}
                      </p>
                    </div>

                    {currentRole === 'director' && (
                      <div 
                        onClick={(e) => { e.stopPropagation(); onDeleteThread(t.id); }}
                        className="text-[#7C8AA8] hover:text-rose-400 p-1 rounded cursor-pointer"
                        title="Delete Thread"
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.stopPropagation(); onDeleteThread(t.id); } }}
                      >
                        <Trash className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Chat Window (Right) */}
        <div className="md:col-span-8 flex flex-col h-full bg-[#0D1830]">
          {activeThread ? (
            <>
              {/* Header */}
              <div className="p-4 border-b border-[#rgba(201,164,106,0.14)] bg-[#111E33]/90 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#C9A46A] text-[#0A1220] flex items-center justify-center font-bold text-xs">
                    {activeThread.name.replace('@', '').substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                      <span>{activeThread.name}</span>
                      <span className="text-[10px] bg-[#16243F] border border-[#C9A46A]/30 text-[#C9A46A] px-2 py-0.5 rounded-full font-normal">
                        {activeThread.role}
                      </span>
                    </h3>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-[#7C8AA8] flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-400" />
                        <span>Role-Authorized Direct Channel</span>
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowNewMessageModal(true)}
                  className="text-xs text-[#7C8AA8] hover:text-white flex items-center gap-1.5 bg-[#0D1830] border border-white/10 px-3 py-1.5 rounded-lg cursor-pointer transition-colors"
                >
                  <Users className="w-3.5 h-3.5 text-[#C9A46A]" />
                  <span>Switch Person</span>
                </button>
              </div>

              {/* Message List */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4 max-h-[340px]">
                {activeThread.messages.length === 0 ? (
                  <div className="text-center py-12 text-[#7C8AA8] text-xs space-y-2">
                    <p>No messages yet. Send a direct message to {activeThread.name}.</p>
                    <span className="text-[10px] font-mono text-[#C9A46A]">
                      Communication is encrypted and bound to role permissions.
                    </span>
                  </div>
                ) : (
                  activeThread.messages.map(m => {
                    const isMe = m.from === 'me';
                    return (
                      <div 
                        key={m.id} 
                        className={`flex gap-3 max-w-[80%] ${isMe ? 'ml-auto flex-row-reverse' : ''}`}
                      >
                        <div className={`p-3 rounded-2xl text-white ${
                          isMe 
                            ? 'bg-[#16243F] border border-[#C9A46A]/20 rounded-tr-none' 
                            : 'bg-[#111E33] border border-white/5 rounded-tl-none'
                        }`}>
                          {renderMessageContent(m)}
                          <span className="text-[8px] text-slate-400 font-mono block mt-1 text-right">
                            {m.time}
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Attachment Preview */}
              {attachment && (
                <div className="px-4 py-2 bg-[#111E33] border-t border-white/5 flex items-center justify-between text-xs text-[#C9A46A]">
                  <span className="truncate max-w-sm">✓ Attached: {attachment.name}</span>
                  <button 
                    onClick={() => setAttachment(null)}
                    className="text-rose-400 text-xs font-bold font-mono hover:underline cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              )}

              {/* Message Input Footer */}
              <div className="p-4 border-t border-[#rgba(201,164,106,0.14)] bg-[#111E33] flex items-center gap-3">
                <label className="cursor-pointer text-[#7C8AA8] hover:text-white transition-colors">
                  <Paperclip className="w-5 h-5" />
                  <input 
                    type="file" 
                    onChange={handleFileChange}
                    className="hidden" 
                    accept="image/*,application/pdf"
                  />
                </label>

                <input
                  type="text"
                  value={msgText}
                  onChange={e => setMsgText(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') handleSend(); }}
                  placeholder={`Message ${activeThread.name}...`}
                  className="flex-1 bg-[#0D1830] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]"
                />

                <button
                  onClick={handleSend}
                  disabled={!activeThreadPermission.allowed}
                  className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeThreadPermission.allowed 
                      ? 'bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220]' 
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-[#7C8AA8] text-xs space-y-3">
              <div className="w-12 h-12 rounded-full bg-[#111E33] border border-[#C9A46A]/20 flex items-center justify-center text-[#C9A46A]">
                <MessageSquare className="w-6 h-6" />
              </div>
              <p className="max-w-xs">Select an authorized contact or start a new direct message.</p>
              <button
                type="button"
                onClick={() => setShowNewMessageModal(true)}
                className="bg-[#C9A46A] text-[#0A1220] font-bold text-xs px-4 py-2 rounded-xl cursor-pointer hover:bg-[#E3C48F]"
              >
                + New Message by Name
              </button>
            </div>
          )}
        </div>
      </div>

      {/* NEW DIRECT MESSAGE BY NAME MODAL (Filtered by Active Role Permissions) */}
      {showNewMessageModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl w-full max-w-xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-5 bg-gradient-to-r from-[#111E33] to-[#16243F] border-b border-white/10 flex items-center justify-between">
              <div>
                <h2 className="font-serif font-bold text-lg text-white flex items-center gap-2">
                  <User className="w-5 h-5 text-[#C9A46A]" />
                  <span>Authorized Contacts Directory</span>
                </h2>
                <p className="text-xs text-[#7C8AA8] mt-0.5">
                  Showing people you are authorized to message in your current role ({currentRole.toUpperCase()}).
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowNewMessageModal(false)}
                className="text-[#7C8AA8] hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Live Search Bar */}
            <div className="p-4 border-b border-white/10 bg-[#0A1220]/60">
              <div className="relative">
                <Search className="w-4 h-4 text-[#C9A46A] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search authorized contacts by name or role..."
                  value={directorySearch}
                  onChange={e => setDirectorySearch(e.target.value)}
                  autoFocus
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-[#7C8AA8] outline-none focus:border-[#C9A46A]"
                />
                {directorySearch && (
                  <button
                    type="button"
                    onClick={() => setDirectorySearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#7C8AA8] hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Categorized Person List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6 max-h-[50vh]">
              {categories.length === 0 ? (
                <div className="text-center py-12 text-[#7C8AA8] text-xs">
                  No authorized contact found matching "{directorySearch}".
                </div>
              ) : (
                categories.map(category => {
                  const peopleInCat = modalFilteredRecipients.filter(r => r.category === category);
                  if (peopleInCat.length === 0) return null;

                  return (
                    <div key={category} className="space-y-2">
                      <div className="flex items-center justify-between border-b border-white/5 pb-1">
                        <h3 className="text-[11px] font-bold uppercase tracking-wider text-[#C9A46A]">
                          {category} ({peopleInCat.length})
                        </h3>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {peopleInCat.map(person => {
                          const initials = person.name.replace('@', '').substring(0, 2).toUpperCase();
                          return (
                            <button
                              key={person.name}
                              type="button"
                              onClick={() => handleStartDirectMessage(person.name, person.role, person.handle)}
                              className="text-left bg-[#111E33] hover:bg-[#16243F] border border-white/5 hover:border-[#C9A46A]/50 rounded-xl p-3 flex items-center gap-3 transition-all group cursor-pointer"
                            >
                              <div className="w-10 h-10 rounded-full bg-[#0A1220] border border-[#C9A46A]/30 flex items-center justify-center font-bold text-[#C9A46A] text-xs shrink-0 group-hover:scale-105 transition-transform">
                                {initials}
                              </div>
                              <div className="flex-1 min-w-0">
                                <h4 className="text-xs font-semibold text-white truncate group-hover:text-[#C9A46A] transition-colors">
                                  {person.name}
                                </h4>
                                <div className="flex items-center gap-1.5 mt-0.5">
                                  <span className="text-[10px] text-[#7C8AA8] font-mono capitalize">
                                    {person.role}
                                  </span>
                                  {person.handle && (
                                    <span className="text-[10px] text-[#C9A46A] font-mono truncate">
                                      • {person.handle}
                                    </span>
                                  )}
                                </div>
                                {person.relationshipNote && (
                                  <p className="text-[9px] text-slate-400 truncate mt-0.5 font-sans">
                                    {person.relationshipNote}
                                  </p>
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-[#111E33] border-t border-white/10 flex items-center justify-between text-xs text-[#7C8AA8]">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Role-based routing active</span>
              </span>
              <button
                type="button"
                onClick={() => setShowNewMessageModal(false)}
                className="px-4 py-2 rounded-lg border border-white/10 hover:bg-white/5 text-white text-xs font-semibold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
