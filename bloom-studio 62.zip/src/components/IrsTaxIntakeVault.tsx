import React, { useState } from 'react';
import { 
  FileText, Landmark, ShieldCheck, Download, ExternalLink, CheckCircle2, 
  Upload, Eye, EyeOff, Lock, Sparkles, Check, AlertTriangle, FileSignature,
  Building, UserCheck, Shield, HelpCircle, ArrowUpRight, CheckSquare, Square, RefreshCw, Send
} from 'lucide-react';
import { Creator, OfficialW9Record } from '../types';
import { computeRealSha256, persistSignatureRecord } from '../lib/cryptoSignatures';
import { fillOfficialIrsW9Pdf } from '../lib/w9PdfGenerator';
import { getSafeUrl } from '../utils/security';

interface IrsTaxIntakeVaultProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

const OFFICIAL_IRS_LINKS = [
  {
    title: 'Official Form W-9 (Rev. March 2024)',
    docCode: 'Form W-9 PDF',
    url: 'https://www.irs.gov/pub/irs-pdf/fw9.pdf',
    description: 'Request for Taxpayer Identification Number and Certification (IRS.gov official source).'
  },
  {
    title: 'Instructions for Requester of Form W-9',
    docCode: 'IRS Instructions W-9',
    url: 'https://www.irs.gov/pub/irs-pdf/iw9.pdf',
    description: 'Statutory agency guidelines for requesting and verifying Form W-9 TIN matches.'
  },
  {
    title: 'Official Form 1099-NEC (Nonemployee Compensation)',
    docCode: 'Form 1099-NEC',
    url: 'https://www.irs.gov/pub/irs-pdf/f1099nec.pdf',
    description: 'Annual nonemployee independent contractor tax reporting schedules.'
  },
  {
    title: 'Official Form W-8BEN (Foreign Status Certificate)',
    docCode: 'Form W-8BEN',
    url: 'https://www.irs.gov/pub/irs-pdf/fw8ben.pdf',
    description: 'Certificate of Foreign Status of Beneficial Owner for United States Tax Withholding.'
  },
  {
    title: 'IRS TIN Online Matching Program',
    docCode: 'IRS TIN Verification',
    url: 'https://www.irs.gov/tax-professionals/taxpayer-identification-number-tin-on-line-matching',
    description: 'Federal e-services pre-filing Taxpayer Identification Number validation.'
  }
];

export const IrsTaxIntakeVault: React.FC<IrsTaxIntakeVaultProps> = ({
  creators,
  currentUser,
  currentRole = 'creator',
  onAddActivityLog,
  triggerNotification
}) => {
  const isCreator = currentRole.toLowerCase() === 'creator';
  const isDirector = currentRole.toLowerCase() === 'director' || currentRole.toLowerCase() === 'owner' || currentRole.toLowerCase() === 'agency';
  const creatorName = currentUser?.name || 'Elena Rostova';
  const creatorId = currentUser?.uid || 'creator-01';

  const [activeTab, setActiveTab] = useState<'filler' | 'upload' | 'vault' | 'links'>(isCreator ? 'upload' : 'filler');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Digital W-9 Form State
  const [fullName, setFullName] = useState(creatorName);
  const [businessName, setBusinessName] = useState('');
  const [taxClassification, setTaxClassification] = useState<'Individual/sole proprietor' | 'C Corporation' | 'S Corporation' | 'Partnership' | 'Trust/estate' | 'LLC'>('Individual/sole proprietor');
  const [llcTaxType, setLlcTaxType] = useState<'C' | 'S' | 'P'>('S');
  const [streetAddress, setStreetAddress] = useState('742 Evergreen Terrace');
  const [cityStateZip, setCityStateZip] = useState('Los Angeles, CA 90028');
  const [taxIdType, setTaxIdType] = useState<'SSN' | 'EIN'>('SSN');
  const [taxIdNumber, setTaxIdNumber] = useState('123-45-6789');
  const [certAgreed, setCertAgreed] = useState(false);
  const [signatureLegalName, setSignatureLegalName] = useState(creatorName);

  // Completed Vault Records Table (Isolated Tax Directory)
  const [vaultRecords, setVaultRecords] = useState<OfficialW9Record[]>([
    {
      id: 'tax-rec-001',
      userId: 'c1',
      fullName: 'Elena Rostova',
      businessName: 'Rostova Media LLC',
      taxClassification: 'LLC',
      llcTaxType: 'S',
      streetAddress: '450 Lexington Ave, Suite 1200',
      cityStateZip: 'New York, NY 10017',
      taxIdType: 'EIN',
      taxIdNumber: '•••-••-8492',
      certificationAgreed: true,
      signatureLegalName: 'Elena Rostova',
      signatureDate: '2026-08-15',
      signedPdfName: 'Official_W9_Elena_Rostova_Signed.pdf',
      uploadedAt: '2026-08-15 11:20 AM',
      verifiedStatus: 'Verified & Tax Compliant',
      irsAuditHash: `IRS_VAULT_RECORD_9941_${Date.now()}`
    },
    {
      id: 'tax-rec-002',
      userId: 'c2',
      fullName: 'Marcus Vance',
      businessName: 'Vance Kinetic Studio',
      taxClassification: 'Individual/sole proprietor',
      streetAddress: '1280 Ocean Drive',
      cityStateZip: 'Miami, FL 33139',
      taxIdType: 'SSN',
      taxIdNumber: '•••-••-3190',
      certificationAgreed: true,
      signatureLegalName: 'Marcus Vance',
      signatureDate: '2026-08-20',
      signedPdfName: 'Marcus_Vance_W9_Verified.pdf',
      uploadedAt: '2026-08-20 02:45 PM',
      verifiedStatus: 'Verified & Tax Compliant',
      irsAuditHash: `IRS_VAULT_RECORD_3182_${Date.now()}`
    }
  ]);

  // Handle Submission of Digital Form
  const handleSaveDigitalW9 = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !taxIdNumber || !signatureLegalName || !certAgreed) {
      triggerNotification?.('Incomplete W-9', 'Please verify all statutory fields and check the certification agreement.', 'warning');
      return;
    }

    setIsSubmitting(true);
    try {
      const nowIso = new Date().toISOString();
      const payloadStr = `IRS_W9_SUBMISSION|NAME:${fullName}|CLASS:${taxClassification}|TIN:${taxIdType}_${taxIdNumber.slice(-4)}|SIG:${signatureLegalName}|DATE:${nowIso}`;
      const irsAuditHash = await computeRealSha256(payloadStr);

      const recordId = `tax-rec-${Date.now().toString().slice(-4)}`;
      const newRecord: OfficialW9Record = {
        id: recordId,
        userId: creatorId,
        fullName,
        businessName,
        taxClassification,
        llcTaxType: taxClassification === 'LLC' ? llcTaxType : undefined,
        streetAddress,
        cityStateZip,
        taxIdType,
        taxIdNumber: `•••-••-${taxIdNumber.slice(-4)}`,
        certificationAgreed: true,
        signatureLegalName,
        signatureDate: new Date().toISOString().slice(0, 10),
        signedPdfName: `Digital_W9_${fullName.replace(/\s+/g, '_')}_${new Date().getFullYear()}.pdf`,
        uploadedAt: new Date().toLocaleString(),
        verifiedStatus: 'Pending Director Check-Off',
        irsAuditHash
      };

      // Generate official vector IRS Form W-9 PDF
      await fillOfficialIrsW9Pdf({
        legalName: fullName,
        businessName,
        taxClassification,
        llcTaxClassification: taxClassification === 'LLC' ? (llcTaxType as any) : undefined,
        address: streetAddress,
        cityStateZip,
        tinType: taxIdType as any,
        tinNumber: taxIdNumber,
        signatureName: signatureLegalName,
        dateSigned: new Date().toISOString().slice(0, 10),
        creatorHandle: creatorName,
        auditHash: irsAuditHash
      }, { download: true });

      // Persist signature record
      await persistSignatureRecord({
        id: recordId,
        documentType: 'Official IRS Form W-9',
        signerName: signatureLegalName,
        signerEmail: currentUser?.email,
        signerRole: currentRole,
        isoTimestamp: nowIso,
        formattedTimestamp: newRecord.uploadedAt,
        digest: irsAuditHash,
        payloadContent: payloadStr,
        metadata: { taxClassification, taxIdType }
      });

      setVaultRecords(prev => [newRecord, ...prev]);
      setActiveTab('vault');

      triggerNotification?.(
        'W-9 Submitted for Director Check-Off',
        `Your W-9 has been successfully routed to the Agency Director for verification and review.`,
        'success'
      );

      onAddActivityLog?.(
        fullName,
        currentRole,
        `Submitted official digital Form W-9 for Director Check-Off (${newRecord.taxIdType} verified).`
      );
    } catch (err: any) {
      console.error('[IrsTaxIntakeVault] W9 Submission failed:', err);
      triggerNotification?.(
        'Submission Failed',
        err.message || 'Failed to record official digital Form W-9 signature.',
        'danger'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Upload completed PDF handler
  const handleUploadPdfMock = async (fileName: string) => {
    setIsSubmitting(true);
    try {
      const nowIso = new Date().toISOString();
      const payloadStr = `IRS_W9_PDF_UPLOAD|FILE:${fileName}|CREATOR:${creatorName}|DATE:${nowIso}`;
      const irsAuditHash = await computeRealSha256(payloadStr);

      const recordId = `tax-rec-${Date.now().toString().slice(-4)}`;
      const newRecord: OfficialW9Record = {
        id: recordId,
        userId: creatorId,
        fullName: creatorName,
        businessName: 'Uploaded Tax Entity',
        taxClassification: 'Individual/sole proprietor',
        streetAddress: 'On File with Creator',
        cityStateZip: 'On File with Creator',
        taxIdType: 'SSN',
        taxIdNumber: '•••-••-4242',
        certificationAgreed: true,
        signatureLegalName: creatorName,
        signatureDate: new Date().toISOString().slice(0, 10),
        signedPdfName: fileName,
        uploadedAt: new Date().toLocaleString(),
        verifiedStatus: 'Pending Director Check-Off',
        irsAuditHash
      };

      await persistSignatureRecord({
        id: recordId,
        documentType: 'Uploaded IRS Form W-9 PDF',
        signerName: creatorName,
        signerEmail: currentUser?.email,
        signerRole: currentRole,
        isoTimestamp: nowIso,
        formattedTimestamp: newRecord.uploadedAt,
        digest: irsAuditHash,
        payloadContent: payloadStr,
        metadata: { fileName }
      });

      setVaultRecords(prev => [newRecord, ...prev]);
      setActiveTab('vault');

      triggerNotification?.(
        'W-9 Uploaded & Sent to Director',
        `File ${fileName} successfully uploaded and routed to the Director for review and check-off.`,
        'success'
      );

      onAddActivityLog?.(
        creatorName,
        currentRole,
        `Uploaded signed tax document (${fileName}) for Director check-off.`
      );
    } catch (err: any) {
      console.error('[IrsTaxIntakeVault] PDF upload failed:', err);
      triggerNotification?.(
        'Upload Failed',
        err.message || 'Failed to record tax PDF upload signature.',
        'danger'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Director Check-Off Action
  const handleDirectorCheckOff = (recordId: string) => {
    setVaultRecords(prev => prev.map(r => r.id === recordId ? { ...r, verifiedStatus: 'Verified & Tax Compliant (Director Approved)' } : r));
    triggerNotification?.('Tax Document Checked Off', 'The W-9 record has been marked as verified and approved by the Director.', 'success');
    onAddActivityLog?.(currentUser?.name || 'Director', 'director', `Checked off and approved tax compliance for record ${recordId}.`);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#0E1C38] via-[#142850] to-[#0A162B] border border-[#D4AF37]/20 rounded-3xl p-6 shadow-2xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#D4AF37]/10 rounded-xl text-[#D4AF37]">
              <Landmark className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white tracking-wide">
              {isCreator ? 'My Creator Tax Status & W-9 Vault' : 'Official IRS Tax Intake Vault'}
            </h1>
          </div>
          <p className="text-xs text-[#B8C0D4] max-w-2xl">
            {isCreator 
              ? 'Check your tax compliance status, verify if a Form W-9 is required for your payouts, and upload signed documents for Director review and check-off.'
              : 'Secure onboarding portal connected directly to official IRS documents. Review creator submissions, check off tax clearances, and audit encrypted tax records.'}
          </p>
        </div>

        {/* Live Status Badge for Creators */}
        {isCreator && (
          <div className="flex items-center gap-3 bg-[#0B1B3D] px-4 py-3 rounded-2xl border border-amber-500/30">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="text-[10px] font-mono text-slate-400 uppercase">W-9 Compliance Action</div>
              <div className="text-xs font-bold text-amber-300">Action Required: Submit W-9 for Payout Check-Off</div>
            </div>
          </div>
        )}
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-3">
        {isCreator && (
          <button
            onClick={() => setActiveTab('upload')}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'upload'
                ? 'bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] shadow-lg'
                : 'bg-[#142850] text-slate-300 hover:text-white border border-white/5'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Upload W-9 / Tax Info</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('filler')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'filler'
              ? 'bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] shadow-lg'
              : 'bg-[#142850] text-slate-300 hover:text-white border border-white/5'
          }`}
        >
          <FileSignature className="w-4 h-4" />
          <span>Digital W-9 E-Sign Filler</span>
        </button>

        <button
          onClick={() => setActiveTab('vault')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'vault'
              ? 'bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] shadow-lg'
              : 'bg-[#142850] text-slate-300 hover:text-white border border-white/5'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Tax Status &amp; Vault Records ({vaultRecords.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('links')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'links'
              ? 'bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] shadow-lg'
              : 'bg-[#142850] text-slate-300 hover:text-white border border-white/5'
          }`}
        >
          <ExternalLink className="w-4 h-4" />
          <span>Official IRS Instructions</span>
        </button>
      </div>

      {/* TAB: Upload Signed PDF Dropzone (Creator Primary View) */}
      {activeTab === 'upload' && (
        <div className="bg-[#142850] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <span className="text-[10px] font-mono text-[#D4AF37] uppercase tracking-wider">Secure Creator Upload</span>
              <h3 className="text-xl font-serif font-bold text-white">Upload Your Signed Form W-9 or Tax Info</h3>
              <p className="text-xs text-slate-400 mt-0.5">Documents uploaded here are immediately routed to the Agency Director for statutory review and check-off.</p>
            </div>
            <span className="px-3 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-mono font-bold rounded-full">
              Status: W-9 Pending Check-Off
            </span>
          </div>

          <div className="border-2 border-dashed border-white/10 hover:border-[#D4AF37]/50 rounded-3xl p-10 text-center space-y-4 bg-[#0B1B3D]/50 transition-all">
            <Upload className="w-12 h-12 text-[#D4AF37] mx-auto" />
            <div className="space-y-1">
              <p className="text-sm font-bold text-white">Drop your signed Form W-9 PDF or tax exemption letter here</p>
              <p className="text-xs text-slate-400">Supported formats: PDF, JPG, PNG (Sent instantly to Director for approval)</p>
            </div>

            <div className="flex flex-wrap justify-center gap-3 pt-4">
              <button
                type="button"
                onClick={() => handleUploadPdfMock(`Official_W9_${creatorName.replace(/\s+/g, '_')}_Signed.pdf`)}
                className="px-5 py-3 bg-[#D4AF37] hover:bg-[#E3C48F] text-[#0B1B3D] font-bold rounded-2xl text-xs transition-all shadow-lg flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Upload &amp; Submit for Director Check-Off</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB: Digital W-9 Form Filler */}
      {activeTab === 'filler' && (
        <div className="bg-[#142850] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
            <div>
              <span className="text-[10px] uppercase font-mono text-[#D4AF37] tracking-wider">
                Department of the Treasury • Internal Revenue Service
              </span>
              <h2 className="text-xl font-serif font-bold text-white">
                Form W-9: Request for Taxpayer Identification Number & Certification
              </h2>
            </div>
            <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold rounded-full w-fit">
              Direct Director Routing
            </span>
          </div>

          <form onSubmit={handleSaveDigitalW9} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] text-white/70 uppercase font-bold tracking-wider">
                  1. Name (as shown on your income tax return) *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-white/70 uppercase font-bold tracking-wider">
                  2. Business name / Disregarded entity name (if different)
                </label>
                <input
                  type="text"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="e.g. Media LLC"
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none"
                />
              </div>
            </div>

            <div className="space-y-2 bg-[#0B1B3D] border border-white/5 rounded-2xl p-5">
              <label className="text-[10px] text-[#D4AF37] uppercase font-bold tracking-wider">
                3. Federal Tax Classification (Select one)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                {[
                  'Individual/sole proprietor',
                  'C Corporation',
                  'S Corporation',
                  'Partnership',
                  'Trust/estate',
                  'LLC'
                ].map((type) => (
                  <label 
                    key={type}
                    className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                      taxClassification === type 
                        ? 'bg-[#142850] border-[#D4AF37] text-white' 
                        : 'bg-white/[0.02] border-white/5 text-slate-400 hover:border-white/20'
                    }`}
                  >
                    <input
                      type="radio"
                      name="taxClassification"
                      checked={taxClassification === type}
                      onChange={() => setTaxClassification(type as any)}
                      className="text-[#D4AF37] focus:ring-0"
                    />
                    <span className="text-xs font-semibold">{type}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] text-white/70 uppercase font-bold tracking-wider">
                  Address (Street, City, State, ZIP) *
                </label>
                <input
                  type="text"
                  required
                  value={streetAddress}
                  onChange={(e) => setStreetAddress(e.target.value)}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-white/70 uppercase font-bold tracking-wider">
                  Taxpayer ID Type &amp; Number (SSN / EIN) *
                </label>
                <div className="flex gap-2">
                  <select
                    value={taxIdType}
                    onChange={(e) => setTaxIdType(e.target.value as any)}
                    className="bg-[#0B1B3D] border border-white/10 rounded-2xl px-3 py-3 text-sm text-[#D4AF37] font-mono outline-none"
                  >
                    <option value="SSN">SSN</option>
                    <option value="EIN">EIN</option>
                  </select>
                  <input
                    type="text"
                    required
                    value={taxIdNumber}
                    onChange={(e) => setTaxIdNumber(e.target.value)}
                    placeholder="123-45-6789"
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-2xl px-4 py-3 text-sm text-white font-mono focus:border-[#D4AF37] outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4 bg-[#0B1B3D] border border-white/5 rounded-2xl p-5">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={certAgreed}
                  onChange={(e) => setCertAgreed(e.target.checked)}
                  className="rounded text-[#D4AF37] focus:ring-0 w-4 h-4 mt-0.5"
                />
                <span className="text-xs font-semibold text-white">
                  Certification: Under penalties of perjury, I certify that the number shown on this form is my correct taxpayer identification number.
                </span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest">
                    Electronic Legal Signature
                  </label>
                  <input
                    type="text"
                    required
                    value={signatureLegalName}
                    onChange={(e) => setSignatureLegalName(e.target.value)}
                    placeholder="Type your full legal name"
                    className="w-full bg-[#142850] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-[#D4AF37] font-serif italic focus:border-[#D4AF37] outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest">
                    Date
                  </label>
                  <input
                    type="text"
                    disabled
                    value={new Date().toLocaleDateString()}
                    className="w-full bg-[#142850]/50 border border-white/5 rounded-xl px-4 py-2.5 text-sm text-slate-400 font-mono"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] hover:from-[#E3C48F] hover:to-[#FFF0D4] text-[#0B1B3D] font-bold rounded-2xl text-sm transition-all shadow-xl flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? <RefreshCw className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
              <span>{isSubmitting ? 'Submitting to Director...' : 'Submit Form W-9 for Director Check-Off'}</span>
            </button>
          </form>
        </div>
      )}

      {/* TAB: Isolated Tax Vault & Status Check-Off Table */}
      {activeTab === 'vault' && (
        <div className="bg-[#142850] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h3 className="text-xl font-serif font-bold text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-400" />
                {isCreator ? 'My W-9 Status & Submission History' : 'Creator Tax Compliance & Director Check-Off'}
              </h3>
              <p className="text-xs text-slate-400">Real-time status tracking and director verification logs</p>
            </div>
            <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-full text-xs font-mono font-bold">
              Secure TLS Vault
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-white/10 text-slate-400 text-[10px] uppercase">
                  <th className="py-3 px-3">Creator / Entity</th>
                  <th className="py-3 px-3">Classification</th>
                  <th className="py-3 px-3">Document Name</th>
                  <th className="py-3 px-3">Audit Hash</th>
                  <th className="py-3 px-3">Status / Check-Off</th>
                  {isDirector && <th className="py-3 px-3 text-right">Director Action</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {vaultRecords.map((rec) => (
                  <tr key={rec.id} className="hover:bg-white/[0.02] transition-all">
                    <td className="py-3.5 px-3">
                      <div className="font-bold text-white font-sans">{rec.fullName}</div>
                      <span className="text-[10px] text-slate-400">{rec.businessName || 'Individual'}</span>
                    </td>
                    <td className="py-3.5 px-3 text-slate-300">
                      {rec.taxClassification}
                    </td>
                    <td className="py-3.5 px-3 text-cyan-300">
                      <span className="truncate max-w-[160px] inline-block">{rec.signedPdfName}</span>
                    </td>
                    <td className="py-3.5 px-3 text-slate-400 text-[10px]">
                      {rec.irsAuditHash}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className={`px-2.5 py-1 rounded-full text-[9px] font-bold ${
                        rec.verifiedStatus.includes('Verified') 
                          ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400' 
                          : 'bg-amber-500/10 border border-amber-500/20 text-amber-400'
                      }`}>
                        {rec.verifiedStatus.toUpperCase()}
                      </span>
                    </td>
                    {isDirector && (
                      <td className="py-3.5 px-3 text-right">
                        {!rec.verifiedStatus.includes('Verified') && (
                          <button
                            type="button"
                            onClick={() => handleDirectorCheckOff(rec.id)}
                            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-black font-bold rounded-xl text-[10px] shadow transition-all cursor-pointer"
                          >
                            ✓ Check Off / Approve
                          </button>
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: Official IRS Instructions */}
      {activeTab === 'links' && (
        <div className="bg-[#142850] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6">
          <div>
            <h3 className="text-xl font-serif font-bold text-white">Official IRS Document & Guidance Anchors</h3>
            <p className="text-xs text-slate-400">Live authoritative links directly to IRS.gov federal compliance publications</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {OFFICIAL_IRS_LINKS.map((doc, idx) => (
              <a
                key={idx}
                href={getSafeUrl(doc.url)}
                target="_blank"
                rel="noopener noreferrer"
                className="p-5 bg-[#0B1B3D] border border-white/5 hover:border-[#D4AF37]/40 rounded-2xl space-y-2 group transition-all"
              >
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded bg-[#D4AF37]/10 text-[#D4AF37] font-mono text-[10px] font-bold">
                    {doc.docCode}
                  </span>
                  <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-[#D4AF37] transition-all" />
                </div>
                <h4 className="text-sm font-bold text-white group-hover:text-[#D4AF37] transition-all">
                  {doc.title}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {doc.description}
                </p>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default IrsTaxIntakeVault;
