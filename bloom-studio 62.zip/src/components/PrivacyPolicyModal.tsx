import React, { useState } from 'react';
import { 
  Shield, Lock, FileText, Download, CheckCircle2, AlertTriangle, 
  ExternalLink, X, Database, Eye, Server, RefreshCw, Key, FileCheck,
  UserCheck, HelpCircle, Mail, Globe, ArrowRight, ShieldCheck, Printer
} from 'lucide-react';

import { safeStorage } from '../utils/safeStorage';
import { recordAgreementInVault } from '../lib/cryptoSignatures';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAcknowledge?: () => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger' | 'error' | any) => void;
}

export default function PrivacyPolicyModal({
  isOpen,
  onClose,
  onAcknowledge,
  triggerNotification
}: PrivacyPolicyModalProps) {
  const [activeSection, setActiveSection] = useState<'summary' | 'collection' | 'tax-security' | 'subprocessors' | 'rights' | 'retention'>('summary');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAcknowledgeAndReturn = () => {
    try {
      safeStorage.setItem('bloom_privacy_policy_acknowledged', 'true');
      recordAgreementInVault({
        id: `privacy_ack_${Date.now()}`,
        documentType: 'Master Privacy Policy & Data Architecture Review',
        signerName: 'Authenticated User / Staff',
        signerEmail: '',
        organization: 'Bloom Studio Workspace',
        signerRole: 'user',
        isoTimestamp: new Date().toISOString(),
        formattedTimestamp: new Date().toLocaleString(),
        digest: `SHA256:PRIVACY_POLICY_ACK_${Date.now()}`,
        clausesAccepted: [
          'Master Data Architecture & Zero-Sell Privacy Covenant',
          'IRS Form W-9 / 1099 Encryption & 7-Year Retention',
          'Multi-Tenant Isolation & Subprocessor Security'
        ]
      });
    } catch (e) {}

    if (onAcknowledge) {
      onAcknowledge();
    }
    if (triggerNotification) {
      triggerNotification('Privacy Policy Acknowledged', 'Master Privacy Policy review acknowledged and recorded in your compliance dossier.', 'success');
    }
    onClose();
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.origin + '#privacy-policy').catch(() => {});
    }
    setCopiedSection('link');
    setTimeout(() => setCopiedSection(null), 2000);
    if (triggerNotification) {
      triggerNotification('Privacy Policy Copied', 'Direct reference link copied to clipboard.', 'info');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-300"
      role="dialog"
      aria-modal="true"
      aria-labelledby="privacy-policy-title"
    >
      <div className="bg-[#0B1B3D] border border-[#D4AF37]/30 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-left relative">
        {/* Modal Header */}
        <div className="p-6 md:p-8 border-b border-white/10 bg-[#081222]/80 flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-[#D4AF37]/10 rounded-2xl border border-[#D4AF37]/30 text-[#D4AF37] shrink-0">
              <ShieldCheck className="w-7 h-7" aria-hidden="true" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-mono font-bold text-[#D4AF37] uppercase tracking-widest bg-[#D4AF37]/10 px-2 py-0.5 rounded border border-[#D4AF37]/20">
                  Master Legal Governance • v2026.1
                </span>
                <span className="text-[10px] font-mono text-[#7C8AA8]">
                  Last Updated: September 13, 2026
                </span>
              </div>
              <h2 id="privacy-policy-title" className="text-2xl font-serif font-bold text-white mt-1">
                Bloom Studio Platform Privacy Policy &amp; Data Protection Statement
              </h2>
              <p className="text-xs text-[#7C8AA8] mt-0.5">
                Multi-Tenant Data Architecture, IRS Tax Identification Encryption &amp; GDPR / CCPA Disclosure
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-[#7C8AA8] hover:text-white transition"
              title="Print Privacy Policy"
              aria-label="Print Privacy Policy"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-[#7C8AA8] hover:text-white transition"
              aria-label="Close Privacy Policy Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Sub-Tabs */}
        <div className="flex bg-[#081222] border-b border-white/5 px-6 py-2 overflow-x-auto gap-2 text-xs font-mono shrink-0">
          <button
            onClick={() => setActiveSection('summary')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeSection === 'summary' ? 'bg-[#D4AF37] text-[#0B1B3D]' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            1. Overview &amp; Architecture
          </button>
          <button
            onClick={() => setActiveSection('collection')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeSection === 'collection' ? 'bg-[#D4AF37] text-[#0B1B3D]' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            2. Data Categories Collected
          </button>
          <button
            onClick={() => setActiveSection('tax-security')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeSection === 'tax-security' ? 'bg-[#D4AF37] text-[#0B1B3D]' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            3. Tax &amp; SSN/EIN Encryption
          </button>
          <button
            onClick={() => setActiveSection('subprocessors')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeSection === 'subprocessors' ? 'bg-[#D4AF37] text-[#0B1B3D]' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            4. Third-Party Sub-Processors
          </button>
          <button
            onClick={() => setActiveSection('rights')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeSection === 'rights' ? 'bg-[#D4AF37] text-[#0B1B3D]' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            5. GDPR &amp; CCPA Rights
          </button>
          <button
            onClick={() => setActiveSection('retention')}
            className={`px-3 py-1.5 rounded-xl font-bold transition whitespace-nowrap ${
              activeSection === 'retention' ? 'bg-[#D4AF37] text-[#0B1B3D]' : 'text-[#7C8AA8] hover:text-white'
            }`}
          >
            6. Retention &amp; DPO
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6 text-slate-300 text-xs leading-relaxed">
          {activeSection === 'summary' && (
            <div className="space-y-4">
              <div className="p-4 bg-[#142850]/50 border border-[#D4AF37]/20 rounded-2xl flex items-start gap-3">
                <Shield className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-white text-sm">Our Privacy &amp; Data Commitment</h4>
                  <p className="text-[#7C8AA8] mt-1 text-xs">
                    Bloom Studio Inc. (&quot;Agency&quot;, &quot;we&quot;, &quot;our&quot;, or &quot;us&quot;) operates Bloom Studio OS, an enterprise talent management and creator monetization SaaS platform. We strictly safeguard the confidentiality, multi-tenant isolation, and privacy rights of represented talent, agency staff, brand partners, and platform administrators.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">1. Multi-Tenant Partitioning &amp; Scope Isolation</h3>
                <p>
                  Bloom Studio OS is built with strict multi-tenant isolation. Creator rosters, communication records, brand contracts, and financial ledgers are compartmentalized per agency pod (<code className="bg-[#081222] px-1.5 py-0.5 rounded text-[#D4AF37]">subagency</code> / <code className="bg-[#081222] px-1.5 py-0.5 rounded text-[#D4AF37]">tenantId</code>). Staff access is strictly scoped to the user&apos;s assigned agency pod, and cross-tenant queries are blocked by Firestore security rules and backend Express access controls.
                </p>
                <p>
                  Client-side state uses sandboxed, iframe-safe memory fallbacks (<code className="bg-[#081222] px-1.5 py-0.5 rounded text-indigo-300">safeStorage.ts</code>) to prevent unauthorized cross-origin storage leakage or sandboxed browser exceptions.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="bg-[#142850] p-4 rounded-2xl border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono text-[#D4AF37] uppercase font-bold">Encrypted at Rest</div>
                  <div className="text-white font-bold text-xs">AES-GCM-256 &amp; TLS 1.3</div>
                  <p className="text-[#7C8AA8] text-[11px]">All sensitive tax IDs and financial contracts are hashed and cryptographically secured.</p>
                </div>
                <div className="bg-[#142850] p-4 rounded-2xl border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Zero Ad-Tracking</div>
                  <div className="text-white font-bold text-xs">No Data Monetization</div>
                  <p className="text-[#7C8AA8] text-[11px]">We never sell, rent, or trade creator or client information to third-party ad networks.</p>
                </div>
                <div className="bg-[#142850] p-4 rounded-2xl border border-white/5 space-y-1">
                  <div className="text-[10px] font-mono text-blue-400 uppercase font-bold">GDPR &amp; CCPA Ready</div>
                  <div className="text-white font-bold text-xs">Automated Erasure Tools</div>
                  <p className="text-[#7C8AA8] text-[11px]">Self-service Data Subject Access and Relational Purge tools built directly into the UI.</p>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'collection' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">2. Information We Collect &amp; Process</h3>
              <p>
                To provide talent representation, campaign management, media kit publication, contract execution, and direct payout fulfillment, we process the following categories of data:
              </p>

              <div className="space-y-3">
                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5">
                  <div className="font-bold text-white text-xs mb-1">A. Creator &amp; Talent Profile Data</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Legal Name, Preferred Name, Public Social Media Handles (Instagram, TikTok, YouTube), Creator Bio, Follower &amp; Engagement Metrics, Portfolio Images, Rate Cards, and Media Kit links.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5">
                  <div className="font-bold text-white text-xs mb-1">B. Digital Contract &amp; Execution Metadata</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Electronic Signer Legal Full Name, Signer Role, Signing Timestamp (ISO 8601), Counterparty Details, Cryptographic SHA-256 Digest Proofs, Terms of Service acceptance versions, and Representation Agreement Clauses.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5">
                  <div className="font-bold text-white text-xs mb-1">C. Financial, Banking &amp; Payout Routing</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Bank Routing Numbers, Account Numbers (processed via PCI-compliant partners like Stripe / Treasury APIs), Payment Ledger Records, Invoicing Details, Monthly Retainers, and Performance Commission calculations.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5">
                  <div className="font-bold text-white text-xs mb-1">D. Communication &amp; Workflow Records</div>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Direct chat messages, brand brief inquiries, content submission drafts, revision feedback logs, and internal talent management notes.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'tax-security' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">3. IRS Form W-9, 1099 &amp; Tax ID Security</h3>
              <p>
                Given the sensitivity of U.S. and international tax filings, Bloom Studio OS implements specialized cryptographic protections for Taxpayer Identification Numbers (TIN), Social Security Numbers (SSN), and Employer Identification Numbers (EIN):
              </p>

              <div className="bg-[#081222] p-4 rounded-2xl border border-emerald-500/20 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                  <Lock className="w-4 h-4" />
                  <span>Statutory Tax Data Protections:</span>
                </div>
                <ul className="list-disc list-inside space-y-2 text-[11px] text-slate-300">
                  <li>
                    <strong>Encrypted Document Vault:</strong> Form W-9 PDFs and digital submissions are generated programmatically in-memory and encrypted before persistence.
                  </li>
                  <li>
                    <strong>Masked UI Presentation:</strong> SSN and EIN fields are masked by default (<code className="bg-[#142850] px-1 text-slate-200">***-**-6789</code>) across all dashboards and can only be unmasked by authorized Compliance Directors.
                  </li>
                  <li>
                    <strong>IRS Statutory Retention:</strong> In compliance with federal tax regulations, completed W-9 and 1099-NEC distribution records are retained for the statutory 7-year audit period before automated scheduled shredding.
                  </li>
                </ul>
              </div>
            </div>
          )}

          {activeSection === 'subprocessors' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">4. Authorized Third-Party Sub-Processors</h3>
              <p>
                To provide critical infrastructure, transactional payments, and messaging, we integrate with the following enterprise cloud providers under strict Data Protection Agreements (DPAs):
              </p>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse bg-[#142850] rounded-2xl overflow-hidden text-[11px]">
                  <thead>
                    <tr className="border-b border-white/10 bg-[#081222]">
                      <th className="p-3 font-bold text-[#D4AF37] uppercase">Sub-Processor</th>
                      <th className="p-3 font-bold text-[#D4AF37] uppercase">Purpose &amp; Scope</th>
                      <th className="p-3 font-bold text-[#D4AF37] uppercase">Location</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    <tr>
                      <td className="p-3 font-bold text-white">Google Cloud &amp; Firebase</td>
                      <td className="p-3">Primary database hosting, Cloud Firestore multi-tenant storage, Auth token verification.</td>
                      <td className="p-3">United States</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold text-white">Stripe Inc.</td>
                      <td className="p-3">Credit card processing, instant agency payouts, expense cards, and KYC verification.</td>
                      <td className="p-3">United States / Global</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold text-white">Twilio &amp; SendGrid</td>
                      <td className="p-3">Automated SMS deal alerts, creator dispatch notifications, and transactional emails.</td>
                      <td className="p-3">United States</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold text-white">Accounting Integrations (Wave / Zoho)</td>
                      <td className="p-3">Optional accounting ledger synchronization and automated expense booking.</td>
                      <td className="p-3">United States / Canada</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeSection === 'rights' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">5. Your Privacy Rights (GDPR &amp; CCPA / CPRA)</h3>
              <p>
                Regardless of your geographic location, Bloom Studio OS affords comprehensive data subject rights to all platform users:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Right of Access &amp; Portability</span>
                  </div>
                  <p className="text-[#7C8AA8]">
                    You may request a machine-readable JSON or PDF export of all talent profiles, contracts, and financial ledgers associated with your account.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Right to Erasure (Article 17)</span>
                  </div>
                  <p className="text-[#7C8AA8]">
                    Initiate complete data deletion across all relational collections via our self-service <strong>Privacy Compliance Center</strong>.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Right to Rectification</span>
                  </div>
                  <p className="text-[#7C8AA8]">
                    Update, correct, or amend profile details, rate cards, or tax classifications directly inside your account settings.
                  </p>
                </div>

                <div className="p-3.5 bg-[#142850] rounded-xl border border-white/5 space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Non-Discrimination</span>
                  </div>
                  <p className="text-[#7C8AA8]">
                    We never withhold talent services, modify rates, or degrade service quality when you exercise your statutory privacy rights.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'retention' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">6. Data Retention Schedules &amp; DPO Contact</h3>
              <p>
                Data is retained only as long as necessary to fulfill talent management contracts, protect legal rights, and comply with tax regulations:
              </p>

              <div className="p-4 bg-[#142850] rounded-2xl border border-white/5 space-y-2 text-[11px]">
                <div className="flex justify-between border-b border-white/10 pb-1.5">
                  <span className="text-white font-bold">Active Creator Profiles:</span>
                  <span className="text-[#D4AF37] font-mono">Duration of Representation + 30 Days</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-1.5">
                  <span className="text-white font-bold">Executed Contracts &amp; Cryptographic Signatures:</span>
                  <span className="text-[#D4AF37] font-mono">Statutory Limitation (10 Years)</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-1.5">
                  <span className="text-white font-bold">IRS Form W-9 / 1099 Tax Records:</span>
                  <span className="text-[#D4AF37] font-mono">IRS Retention Window (7 Years)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white font-bold">Ephemeral Session Cache &amp; Drafts:</span>
                  <span className="text-[#D4AF37] font-mono">Auto-purged on session logout</span>
                </div>
              </div>

              <div className="p-4 bg-[#081222] rounded-2xl border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mt-4">
                <div>
                  <div className="text-white font-bold text-xs flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Data Protection Officer (DPO) &amp; Compliance Office</span>
                  </div>
                  <p className="text-[11px] text-[#7C8AA8] mt-0.5 font-mono">
                    compliance@bloomstudio.internal • Bloom Studio Legal &amp; Governance Department
                  </p>
                </div>
                <button
                  onClick={handleCopyLink}
                  className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 shrink-0"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>{copiedSection === 'link' ? 'Copied!' : 'Copy Direct Policy Link'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 md:p-6 border-t border-white/10 bg-[#081222] flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-2 text-[11px] text-[#7C8AA8] font-mono">
            <Shield className="w-4 h-4 text-[#D4AF37]" />
            <span>Multi-Tenant Enterprise Security &amp; Privacy Shield Active</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleAcknowledgeAndReturn}
              className="px-6 py-2.5 bg-[#D4AF37] hover:bg-[#b08e58] text-[#0B1B3D] font-bold text-xs rounded-xl transition shadow-lg shadow-[#D4AF37]/20 cursor-pointer"
            >
              Acknowledge &amp; Return
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
