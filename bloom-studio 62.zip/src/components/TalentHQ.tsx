import React, { useState, useEffect } from 'react';
import { 
  Users, UserPlus, CalendarDays, Lock, AlertTriangle, Search, 
  Plus, CheckCircle2, ShieldCheck, Heart, TrendingUp, Sparkles, 
  ExternalLink, Mail, ArrowRight, DollarSign, Filter
} from 'lucide-react';
import { Creator, Deal, Role } from '../types';
import { UnifiedCalendarHub } from './UnifiedCalendarHub';
import ExclusivityTracker from './ExclusivityTracker';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, where, doc, setDoc, deleteDoc } from 'firebase/firestore';

interface TalentHQProps {
  creators: Creator[];
  setCreators: React.Dispatch<React.SetStateAction<Creator[]>>;
  deals: Deal[];
  currentUser?: any;
  currentRole?: Role | string;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: any) => void;
  onNavigateToScreen?: (screenId: string) => void;
}

export default function TalentHQ({
  creators = [],
  setCreators,
  deals = [],
  currentUser,
  currentRole = 'director',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onAddActivityLog,
  triggerNotification,
  onNavigateToScreen
}: TalentHQProps) {
  const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase());
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr' || (currentRole || '').toLowerCase() === 'agent';

  const roleLower = (currentRole || '').toLowerCase();
  const isRestrictedStaff = ['agentmgr', 'agent', 'coordinator'].includes(roleLower);

  const [activeTab, setActiveTab] = useState<'roster' | 'intake' | 'availability' | 'contracts'>('roster');
  const [rosterSearch, setRosterSearch] = useState('');
  const [selectedNiche, setSelectedNiche] = useState<string>('all');
  const [applications, setApplications] = useState<any[]>([]);

  useEffect(() => {
    let unsub = () => {};
    if (db) {
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
      const isPlatformOwner = currentUser?.isPlatformOwner || false;

      let q: any = collection(db, 'inbound-agency-leads');
      if (!isPlatformOwner) {
        q = query(
          collection(db, 'inbound-agency-leads'),
          where('subagency', '==', userPod)
        );
      }

      unsub = onSnapshot(q, (snapshot) => {
        const items: any[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          // Filter out brand collaboration pitches so we only see actual talent/creator roster applications
          if (data.type !== 'brand_forward') {
            items.push({
              id: docSnap.id,
              name: data.name || data.creatorName || 'Anonymous Applicant',
              handle: data.handle || data.creatorHandle || '@unknown',
              niche: data.niche || data.creatorPlatform || 'Beauty & Skincare',
              followers: data.followers || '150K',
              engagement: data.engagement || data.eng || '4.8%',
              email: data.email || data.creatorEmail || 'unknown@example.com',
              date: data.joined || data.date || (data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleDateString() : 'Aug 24, 2026'),
              status: data.status || 'Under Review',
              ...data
            });
          }
        });

        if (items.length > 0) {
          setApplications(items);
        } else {
          setApplications([
            {
              id: 'app_1',
              name: 'Sierra Brooks',
              handle: '@sierrabrooks',
              niche: 'Beauty & Skincare',
              followers: '320K',
              engagement: '4.8%',
              email: 'sierra@ugcbeauty.com',
              date: 'Aug 24, 2026',
              status: 'Under Review',
              tenantId: userPod,
              subagency: userPod,
              pod: userPod
            },
            {
              id: 'app_2',
              name: 'Liam Chen',
              handle: '@liamvlogs',
              niche: 'Lifestyle & Tech',
              followers: '185K',
              engagement: '5.2%',
              email: 'liam@chenmedia.io',
              date: 'Aug 23, 2026',
              status: 'Under Review',
              tenantId: userPod,
              subagency: userPod,
              pod: userPod
            }
          ]);
        }
      }, (error) => {
        console.warn("Firestore inbound-agency-leads listener warning:", error);
      });
    }
    return () => unsub();
  }, [currentUser]);

  const filteredCreators = creators.filter(c => {
    // Manager visibility scope filter
    if (isRestrictedStaff) {
      const userName = (currentUser?.name || '').toLowerCase();
      const ag = (c.assignedAgent || (c as any).agent || '').toLowerCase();
      const mgr = (c.assignedManager || '').toLowerCase();
      const coord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
      const isAssigned = (
        ag.includes(userName) || userName.includes(ag) ||
        mgr.includes(userName) || userName.includes(mgr) ||
        coord.includes(userName) || userName.includes(coord) ||
        (userName.includes('marcus') && (ag.includes('marcus') || mgr.includes('marcus'))) ||
        (userName.includes('alex') && (ag.includes('alex') || coord.includes('alex')))
      );
      if (!isAssigned) return false;
    }

    if (selectedNiche !== 'all' && (c.niche || '').toLowerCase() !== selectedNiche.toLowerCase()) return false;
    if (rosterSearch.trim()) {
      const q = rosterSearch.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.handle.toLowerCase().includes(q) || (c.niche || '').toLowerCase().includes(q);
    }
    return true;
  });

  const handleApproveApplicant = async (app: any) => {
    const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
    const newCreatorId = 'c_' + Date.now();
    const newCreator: Creator & { tenantId: string; subagency: string; pod: string } = {
      id: newCreatorId,
      name: app.name,
      handle: app.handle,
      niche: app.niche,
      status: 'Active',
      platform: app.platform || 'TikTok',
      followers: app.followers || '100K',
      eng: app.engagement || '5.0%',
      agreement: 'Standard 80/20',
      assignedAgent: currentUser?.name || 'Unassigned',
      tenantId: userPod,
      subagency: userPod,
      pod: userPod
    };

    setCreators(prev => [newCreator, ...prev]);
    setApplications(prev => prev.filter(a => a.id !== app.id));

    try {
      if (db) {
        // Save creator to Firestore
        await setDoc(doc(db, 'studio-creators', newCreatorId), newCreator);
        // Delete application lead from Firestore (inbound-agency-leads)
        if (app.id && !app.id.startsWith('app_')) {
          await deleteDoc(doc(db, 'inbound-agency-leads', app.id));
        }
      }
    } catch (err) {
      console.error("Error approving applicant in Firestore:", err);
    }

    if (triggerNotification) {
      triggerNotification("Talent Accepted", `${app.name} (${app.handle}) has been added to the active roster!`, "success");
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "User", String(currentRole || 'none'), `Approved applicant ${app.name} to talent roster`);
    }
  };

  const handleRejectApplicant = async (app: any) => {
    setApplications(prev => prev.filter(a => a.id !== app.id));

    try {
      if (db && app.id && !app.id.startsWith('app_')) {
        await deleteDoc(doc(db, 'inbound-agency-leads', app.id));
      }
    } catch (err) {
      console.error("Error rejecting applicant in Firestore:", err);
    }

    if (triggerNotification) {
      triggerNotification("Application Archived", `Archived ${app.name}'s talent application.`, "info");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                UNIFIED TALENT HQ &amp; ROSTER HUB
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                {creators.length} Managed Creators
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              Talent HQ
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Unified headquarters for creator directory profiles, incoming talent applications, availability blackout calendars, and category exclusivity locks.
            </p>
          </div>
        </div>

        {isAgentMgr && (
          <button
            type="button"
            onClick={() => {
              if (triggerNotification) {
                triggerNotification("Suggestion Sent", "Your suggestion for a new creator has been sent to the Director for review.", "info");
              }
              if (onAddActivityLog) {
                onAddActivityLog(currentUser?.name || "Manager", "agentmgr", "Suggested a new creator for onboarding");
              }
            }}
            className="bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-bold px-5 py-3 rounded-xl shadow-lg transition-all cursor-pointer flex items-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            <span>Suggest New Creator</span>
          </button>
        )}
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('roster')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'roster'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Talent Directory &amp; Roster</span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/20 font-mono">{filteredCreators.length}</span>
        </button>

        {isDirector && (
          <button
            type="button"
            onClick={() => setActiveTab('intake')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
              activeTab === 'intake'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>Inbound Applications &amp; Intake</span>
            {applications.length > 0 && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono">
                {applications.length} New
              </span>
            )}
          </button>
        )}

        <button
          type="button"
          onClick={() => setActiveTab('availability')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'availability'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          <span>Availability &amp; Calendar</span>
        </button>

        {isDirector && (
          <button
            type="button"
            onClick={() => setActiveTab('contracts')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
              activeTab === 'contracts'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>Contracts &amp; Exclusivity</span>
          </button>
        )}
      </div>

      {/* TAB CONTENT: Talent Roster */}
      {activeTab === 'roster' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#0D1830] border border-white/10 rounded-xl p-3">
            <div className="relative flex-1 w-full">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search talent by name, handle, or niche..."
                value={rosterSearch}
                onChange={e => setRosterSearch(e.target.value)}
                className="w-full bg-black/30 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <select
                value={selectedNiche}
                onChange={e => setSelectedNiche(e.target.value)}
                className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="all">All Niches</option>
                <option value="Beauty">Beauty &amp; Skincare</option>
                <option value="Pets">Pets &amp; Animals</option>
                <option value="Lifestyle">Lifestyle &amp; Fashion</option>
                <option value="Fitness">Fitness &amp; Wellness</option>
                <option value="Tech">Tech &amp; Gaming</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredCreators.map(creator => (
              <div 
                key={creator.id}
                className="bg-[#0D1830] border border-white/10 rounded-2xl p-4 space-y-3 shadow-lg flex flex-col justify-between hover:border-[#C9A46A]/40 transition"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <img 
                      src={creator.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'} 
                      alt={creator.name}
                      className="w-12 h-12 rounded-full object-cover border border-[#C9A46A]/40"
                    />
                    <div className="min-w-0">
                      <h4 className="font-bold text-white text-sm truncate">{creator.name}</h4>
                      <span className="text-xs text-[#C9A46A] font-mono block truncate">{creator.handle}</span>
                      <span className="text-[10px] text-slate-400 block truncate">{creator.niche || 'General UGC'}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5 text-xs">
                    <div className="bg-black/30 p-2 rounded-xl">
                      <span className="text-[9px] text-slate-500 uppercase block">Followers</span>
                      <span className="font-bold text-white font-mono">{creator.followers || '120K'}</span>
                    </div>
                    <div className="bg-black/30 p-2 rounded-xl">
                      <span className="text-[9px] text-slate-500 uppercase block">Engagement</span>
                      <span className="font-bold text-emerald-400 font-mono">{creator.eng || '4.5%'}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
                  <span className="text-[10px] font-mono text-slate-500">Agent: {creator.assignedAgent || 'Unassigned'}</span>
                  <span className="text-[10px] font-bold text-emerald-400 font-mono">● {creator.status || 'Active'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: Inbound Applications & Intake */}
      {activeTab === 'intake' && (
        <div className="space-y-4">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-white text-lg font-serif">Inbound Creator Applications Inbox</h3>
            <p className="text-xs text-slate-400 mt-0.5">Review and onboard incoming UGC and talent applications received from the public portal.</p>
          </div>

          <div className="space-y-3">
            {applications.length === 0 ? (
              <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-12 text-center text-slate-400 text-xs">
                No pending creator applications in the review queue.
              </div>
            ) : (
              applications.map(app => (
                <div 
                  key={app.id}
                  className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center font-bold text-[#C9A46A]">
                      {app.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-sm">{app.name}</h4>
                      <span className="text-xs text-[#C9A46A] font-mono mr-2">{app.handle}</span>
                      <span className="text-xs text-slate-400">&bull; {app.niche} &bull; {app.followers} ({app.engagement} eng.)</span>
                      <span className="text-[10px] text-slate-500 block font-mono mt-0.5">Applied: {app.date} &bull; {isDirector ? app.email : '••••@••••.com'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleRejectApplicant(app)}
                      className="px-3 py-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 text-xs font-bold transition cursor-pointer"
                    >
                      Decline
                    </button>
                    <button
                      type="button"
                      onClick={() => handleApproveApplicant(app)}
                      className="px-4 py-2 rounded-xl bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Accept &amp; Onboard</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT: Availability Calendar */}
      {activeTab === 'availability' && (
        <UnifiedCalendarHub defaultTab="availability"
          creators={creators}
          currentRole={currentRole as Role}
          currentUser={currentUser}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
          
          
        />
      )}

      {/* TAB CONTENT: Contracts & Exclusivity */}
      {activeTab === 'contracts' && (
        <ExclusivityTracker
          creators={creators}
          deals={deals}
          currentRole={currentRole as Role}
          currentUser={currentUser}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
          
          
        />
      )}
    </div>
  );
}
