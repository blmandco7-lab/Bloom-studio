/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Trash2, RotateCcw, AlertTriangle, Calendar, Info, AlertOctagon } from 'lucide-react';
import { TrashItem } from '../types';
import DeleteConfirmationModal, { DeleteConfirmConfig } from './DeleteConfirmationModal';

interface TrashBinProps {
  trashItems: TrashItem[];
  onRestore: (item: TrashItem) => void;
  onPurge: (itemId: string) => void;
  onEmptyTrash: () => void;
}

export default function TrashBin({ trashItems, onRestore, onPurge, onEmptyTrash }: TrashBinProps) {
  const [deleteModalConfig, setDeleteModalConfig] = useState<DeleteConfirmConfig | null>(null);

  const getDaysRemaining = (deletedAt: string) => {
    const deletedDate = new Date(deletedAt);
    const now = new Date();
    const msDiff = now.getTime() - deletedDate.getTime();
    const daysElapsed = Math.floor(msDiff / (1000 * 60 * 60 * 24));
    return Math.max(0, 30 - daysElapsed);
  };

  const getBadgeColor = (type: string) => {
    switch (type) {
      case 'creator': return 'bg-amber-950 border border-amber-500/30 text-amber-400';
      case 'deal': return 'bg-emerald-950 border border-emerald-500/30 text-emerald-400';
      case 'mission': return 'bg-blue-950 border border-blue-500/30 text-blue-400';
      case 'invoice': return 'bg-rose-950 border border-rose-500/30 text-rose-400';
      case 'contract': return 'bg-purple-950 border border-purple-500/30 text-purple-400';
      default: return 'bg-[#16243F] border border-white/10 text-slate-300';
    }
  };

  const handleRequestPurge = (item: TrashItem) => {
    setDeleteModalConfig({
      isOpen: true,
      title: 'Purge Item Permanently',
      itemName: item.name,
      itemType: item.type,
      isPermanent: true,
      message: `Are you sure you want to permanently erase "${item.name}"? Once purged, this record cannot be recovered, and its 30-day grace period is terminated immediately.`,
      confirmButtonText: 'Purge Permanently',
      confirmButtonVariant: 'danger',
      onConfirm: () => {
        onPurge(item.id);
      }
    });
  };

  const handleRequestEmptyTrash = () => {
    setDeleteModalConfig({
      isOpen: true,
      title: 'Empty Recoup Trash Bin',
      itemName: `${trashItems.length} items in trash`,
      itemType: 'trash bin',
      isPermanent: true,
      message: `Are you sure you want to permanently destroy all ${trashItems.length} items currently in the Recoup Trash Bin? This action is irrevocable.`,
      confirmButtonText: `Erase All ${trashItems.length} Items`,
      confirmButtonVariant: 'danger',
      onConfirm: () => {
        onEmptyTrash();
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-sans font-medium text-2xl tracking-tight text-white flex items-center gap-2">
            <Trash2 className="text-[#C9A46A] w-6 h-6" /> Recoup Trash Bin
          </h1>
          <p className="text-xs text-[#7C8AA8] mt-1">
            Restore accidentally deleted creators, deals, missions, or campaign files within a 30-day grace period
          </p>
        </div>

        {trashItems.length > 0 && (
          <button
            onClick={handleRequestEmptyTrash}
            className="bg-rose-950/40 hover:bg-rose-950 border border-rose-500/30 text-rose-400 px-4 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" /> Empty Recoup Trash
          </button>
        )}
      </div>

      <div className="bg-[#0D1830] border border-[#C9A46A]/20 rounded-2xl p-4 flex items-start gap-3">
        <Info className="text-[#C9A46A] w-5 h-5 shrink-0 mt-0.5" />
        <div className="text-xs text-[#B8C0D4] leading-relaxed space-y-1">
          <p className="font-semibold text-white">
            30-Day Safe Recovery Protocol:
          </p>
          <p>
            When items are deleted from active panels (creators, brand deals, campaigns, contracts, exclusivity locks), a full snapshot is automatically archived in cloud storage for <span className="font-semibold text-white">30 days</span>. You can restore any item back to its original panel with complete fields and metadata intact, or permanently purge it at any time.
          </p>
        </div>
      </div>

      {trashItems.length === 0 ? (
        <div className="border border-white/5 bg-[#0D1830] rounded-2xl p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#111E33] border border-white/5 flex items-center justify-center mx-auto text-slate-500">
            <Trash2 className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-medium text-white">Trash bin is empty</p>
            <p className="text-xs text-[#7C8AA8] max-w-xs mx-auto">
              Any deleted roster creators, brand deals, invoice briefs, or contracts will appear here for recovery.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                  <th className="p-4 font-semibold">Item Name / Details</th>
                  <th className="p-4 font-semibold">Type</th>
                  <th className="p-4 font-semibold">Deleted Date</th>
                  <th className="p-4 font-semibold">Days Remaining</th>
                  <th className="p-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {trashItems.map(item => {
                  const daysLeft = getDaysRemaining(item.deletedAt);
                  return (
                    <tr key={item.id} className="hover:bg-[#111E33]/30 transition-colors">
                      <td className="p-4">
                        <div className="font-medium text-white text-sm">{item.name}</div>
                        <div className="text-[10px] text-[#7C8AA8] mt-0.5">
                          ID: {item.id.toUpperCase()}
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize ${getBadgeColor(item.type)}`}>
                          {item.type}
                        </span>
                      </td>
                      <td className="p-4 text-[#B8C0D4]">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-[#7C8AA8]" />
                          {new Date(item.deletedAt).toLocaleDateString(undefined, {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`font-semibold ${daysLeft <= 5 ? 'text-rose-400' : 'text-amber-400'}`}>
                          {daysLeft} days left
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <div className="inline-flex gap-2">
                          <button
                            onClick={() => onRestore(item)}
                            className="bg-[#16243F] border border-white/10 hover:border-[#C9A46A] text-white hover:text-[#C9A46A] px-3 py-1.5 rounded-xl text-[11px] font-semibold flex items-center gap-1 transition-all cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" /> Restore
                          </button>
                          <button
                            onClick={() => handleRequestPurge(item)}
                            className="bg-rose-950/20 hover:bg-rose-950 border border-rose-500/20 hover:border-rose-500 text-rose-400 px-3 py-1.5 rounded-xl text-[11px] font-semibold flex items-center gap-1 transition-all cursor-pointer"
                          >
                            Purge
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal for Trash Actions */}
      <DeleteConfirmationModal
        config={deleteModalConfig}
        onClose={() => setDeleteModalConfig(null)}
      />
    </div>
  );
}
