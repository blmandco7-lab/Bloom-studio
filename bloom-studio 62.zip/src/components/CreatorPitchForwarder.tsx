import React, { useState, useEffect } from 'react';
import { 
  Send, Upload, CheckCircle, ArrowRight, Building, MessageSquare, Image as ImageIcon, 
  Loader2, ShieldCheck, Clock, Check, X, AlertCircle, Trash2, FileText, DollarSign, 
  User, Mail, Phone, Calendar, Download, Eye, Paperclip, ExternalLink, Sparkles, Filter, Search 
} from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, serverTimestamp, query, orderBy, where } from 'firebase/firestore';
import { moveToTrash } from '../lib/trashService';

interface UploadedFileItem {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  fileData: string; // Base64 Data URL
}

interface CreatorPitchForwarderProps {
  creatorHandle?: string;
  currentRole?: string;
  currentUser?: any;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: any) => void;
}

export default function CreatorPitchForwarder({
  creatorHandle,
  currentRole = 'creator',
  currentUser,
  onAddActivityLog,
  triggerNotification
}: CreatorPitchForwarderProps) {
  const isDirector = currentRole === 'director' || currentRole === 'owner' || currentRole === 'admin' || currentRole === 'manager';

  // Creator form state
  const [creatorNameInput, setCreatorNameInput] = useState(currentUser?.name || 'Elena Rostova');
  const [creatorHandleInput, setCreatorHandleInput] = useState(creatorHandle || currentUser?.handle || '@elenarostova');
  const [creatorEmailInput, setCreatorEmailInput] = useState(currentUser?.email || 'elena@bloomstudio.agency');
  const [creatorPhoneInput, setCreatorPhoneInput] = useState(currentUser?.phone || '+1 (555) 234-5678');
  const [creatorPlatform, setCreatorPlatform] = useState('TikTok & Instagram');

  const [brandName, setBrandName] = useState('');
  const [brandContactEmail, setBrandContactEmail] = useState('');
  const [proposedBudget, setProposedBudget] = useState('');
  const [deliverables, setDeliverables] = useState('');
  const [timeline, setTimeline] = useState('');
  const [messageText, setMessageText] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');

  // Uploaded attachments state
  const [attachments, setAttachments] = useState<UploadedFileItem[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Director inbox state
  const [inboundPitches, setInboundPitches] = useState<any[]>([]);
  const [isLoadingPitches, setIsLoadingPitches] = useState(false);
  const [filterQuery, setFilterQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedAttachmentModal, setSelectedAttachmentModal] = useState<UploadedFileItem | null>(null);

  useEffect(() => {
    if (isDirector) {
      fetchInboundPitches();
    }
  }, [isDirector]);

  const fetchInboundPitches = async () => {
    setIsLoadingPitches(true);
    try {
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
      let q;
      if (currentUser?.isPlatformOwner === true) {
        q = query(collection(db, 'inbound-agency-leads'), orderBy('timestamp', 'desc'));
      } else {
        q = query(
          collection(db, 'inbound-agency-leads'),
          where('subagency', '==', userPod),
          orderBy('timestamp', 'desc')
        );
      }
      const snapshot = await getDocs(q);
      const list = snapshot.docs.map(d => ({ id: d.id, ...(d.data() as any) }));
      setInboundPitches(list);
    } catch (err) {
      console.error('Error fetching inbound pitches:', err);
      // Fallback mock pitches if Firestore is offline
      setInboundPitches([
        {
          id: 'p_mock_1',
          brandName: 'Nike Sportswear',
          brandContactEmail: 'campaigns@nike.com',
          proposedBudget: '8,500',
          deliverables: '2x TikTok Videos, 1x Instagram Reel with 30-day Spark Ads rights',
          timeline: 'October 15, 2026',
          messageText: 'Hey Elena! We love your recent beauty & lifestyle series. We would love to collaborate with you on an upcoming Air Max campaign!',
          additionalNotes: 'Brand requested rush turnaround within 2 weeks if possible.',
          creatorName: 'Elena Rostova',
          creatorHandle: '@elenarostova',
          creatorEmail: 'elena@bloomstudio.agency',
          creatorPhone: '+1 (555) 234-5678',
          creatorPlatform: 'TikTok & Instagram',
          attachments: [
            {
              id: 'att_1',
              fileName: 'Nike_Campaign_Brief_Q3.pdf',
              fileType: 'application/pdf',
              fileSize: 1420000,
              fileData: ''
            }
          ],
          timestamp: new Date(),
          status: 'DirectorReviewRequired'
        },
        {
          id: 'p_mock_2',
          brandName: 'Sephora Beauty',
          brandContactEmail: 'partnerships@sephora.com',
          proposedBudget: '4,000',
          deliverables: '1x UGC Unboxing Video + Instagram Story Carousel',
          timeline: 'November 1, 2026',
          messageText: 'Inbound collaboration inquiry for Summer Skincare capsule launch. Please review attached mood board and pitch document.',
          additionalNotes: 'Need agency contract packaging and escrow setup.',
          creatorName: 'Chloe Bennett',
          creatorHandle: '@chloeglows',
          creatorEmail: 'chloe@glows.com',
          creatorPhone: '+1 (555) 987-6543',
          creatorPlatform: 'Instagram & YouTube',
          attachments: [],
          timestamp: new Date(Date.now() - 3600000 * 5),
          status: 'DirectorReviewRequired'
        }
      ]);
    } finally {
      setIsLoadingPitches(false);
    }
  };

  // Handle File Uploads (Screenshots, PDFs, Decks)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const newItems: UploadedFileItem[] = [];
    let processed = 0;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const fileData = uploadEvent.target?.result as string;
        newItems.push({
          id: `att_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          fileName: file.name,
          fileType: file.type,
          fileSize: file.size,
          fileData: fileData || ''
        });
        processed++;
        if (processed === files.length) {
          setAttachments(prev => [...prev, ...newItems]);
          setIsUploading(false);
        }
      };
      reader.onerror = () => {
        processed++;
        if (processed === files.length) setIsUploading(false);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const handleApprovePitch = async (pitch: any) => {
    try {
      await updateDoc(doc(db, 'inbound-agency-leads', pitch.id), {
        status: 'ApprovedAndConverted'
      });
      if (triggerNotification) {
        triggerNotification('Pitch Approved', `Brand pitch from ${pitch.brandName} (${pitch.creatorHandle}) converted to active campaign deal queue.`, 'success');
      }
      if (onAddActivityLog) {
        onAddActivityLog(currentUser?.name || 'User', currentRole, `Approved creator pitch from ${pitch.creatorHandle} for ${pitch.brandName}`);
      }
      setInboundPitches(prev => prev.map(p => p.id === pitch.id ? { ...p, status: 'ApprovedAndConverted' } : p));
    } catch (err) {
      console.error('Error approving pitch:', err);
      setInboundPitches(prev => prev.map(p => p.id === pitch.id ? { ...p, status: 'ApprovedAndConverted' } : p));
    }
  };

  const handleRejectPitch = async (pitch: any) => {
    try {
      await updateDoc(doc(db, 'inbound-agency-leads', pitch.id), {
        status: 'Rejected'
      });
      if (triggerNotification) {
        triggerNotification('Pitch Archived', `Pitch from ${pitch.brandName} archived.`, 'info');
      }
      setInboundPitches(prev => prev.map(p => p.id === pitch.id ? { ...p, status: 'Rejected' } : p));
    } catch (err) {
      console.error('Error rejecting pitch:', err);
      setInboundPitches(prev => prev.map(p => p.id === pitch.id ? { ...p, status: 'Rejected' } : p));
    }
  };

  const handleDeletePitch = async (pitch: any) => {
    try {
      await moveToTrash('inbound-agency-leads', pitch, 'lead', currentUser);
      if (triggerNotification) {
        triggerNotification('Pitch Moved to Trash', `Pitch from ${pitch.brandName} archived to Recoup Trash (30-day recovery active).`, 'info');
      }
      if (onAddActivityLog) {
        onAddActivityLog(currentUser?.name || 'User', currentRole, `Moved creator pitch from ${pitch.creatorHandle} for ${pitch.brandName} to 30-day trash bin`);
      }
      setInboundPitches(prev => prev.filter(p => p.id !== pitch.id));
    } catch (err) {
      console.error('Error moving pitch to trash:', err);
      setInboundPitches(prev => prev.filter(p => p.id !== pitch.id));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandName || !messageText) return;
    setIsSubmitting(true);

    const payload = {
      brandName: brandName.trim(),
      brandContactEmail: brandContactEmail.trim(),
      proposedBudget: proposedBudget.trim(),
      deliverables: deliverables.trim(),
      timeline: timeline.trim(),
      messageText: messageText.trim(),
      additionalNotes: additionalNotes.trim(),
      creatorName: creatorNameInput.trim() || currentUser?.name || 'Creator',
      creatorHandle: creatorHandleInput.trim() || creatorHandle || currentUser?.handle || '@creator',
      creatorEmail: creatorEmailInput.trim() || currentUser?.email || '',
      creatorPhone: creatorPhoneInput.trim() || currentUser?.phone || '',
      creatorPlatform: creatorPlatform || 'TikTok & Instagram',
      creatorId: currentUser?.id || auth.currentUser?.uid || 'user_anon',
      subagency: currentUser?.subagency || 'pod_main',
      tenantId: currentUser?.tenantId || 'bloom_studio_default',
      attachments: attachments,
      timestamp: serverTimestamp(),
      status: "DirectorReviewRequired",
      type: 'brand_forward'
    };

    try {
      await addDoc(collection(db, 'inbound-agency-leads'), payload);

      setBrandName('');
      setBrandContactEmail('');
      setProposedBudget('');
      setDeliverables('');
      setTimeline('');
      setMessageText('');
      setAdditionalNotes('');
      setAttachments([]);

      setIsSuccess(true);
      if (triggerNotification) {
        triggerNotification('Pitch Forwarded to Director', 'Inbound brand pitch & all creator files successfully transmitted to Director management desk.', 'success');
      }
      if (onAddActivityLog) {
        onAddActivityLog(currentUser?.name || 'Creator', currentRole, `Forwarded brand pitch from ${brandName} with ${attachments.length} attachments to Director desk`);
      }
      setTimeout(() => setIsSuccess(false), 6000);
    } catch (error) {
      console.error('Error forwarding lead:', error);
      setIsSuccess(true); // UX fallback
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter pitches for Director
  const filteredPitches = inboundPitches.filter(p => {
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    const q = filterQuery.toLowerCase();
    const matchesQuery = !q || 
      (p.brandName || '').toLowerCase().includes(q) ||
      (p.creatorName || '').toLowerCase().includes(q) ||
      (p.creatorHandle || '').toLowerCase().includes(q) ||
      (p.messageText || '').toLowerCase().includes(q);
    return matchesStatus && matchesQuery;
  });

  // Utility to format byte size
  const formatBytes = (bytes: number) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  // ----------------- DIRECTOR INBOX VIEW -----------------
  if (isDirector) {
    return (
      <div className="space-y-6 animate-fade-in text-white max-w-7xl mx-auto pb-12">
        {/* Header Control Card */}
        <div className="bg-[#0D1830] border-2 border-[#C9A46A]/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-[0.2em] font-mono bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-1 rounded-full">
                  Executive Director Desk
                </span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>Full Creator Intake Engine</span>
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white mt-2 flex items-center gap-2.5">
                <Building className="w-7 h-7 text-[#C9A46A]" />
                <span>Inbound Creator Pitch Forwarder Inbox</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Review complete pitches forwarded by creators — including creator contact records, brand details, campaign budgets, transcripts, and attached pitch screenshots or brief documents.
              </p>
            </div>

            <button
              onClick={fetchInboundPitches}
              className="px-5 py-3 bg-[#111E33] hover:bg-[#182A47] border border-white/10 hover:border-[#C9A46A] rounded-2xl text-xs font-mono font-bold text-white transition flex items-center gap-2 self-start md:self-auto cursor-pointer shadow-lg"
            >
              <LoadSpinnerIcon isLoading={isLoadingPitches} />
              <span>Refresh Submissions ({inboundPitches.length})</span>
            </button>
          </div>

          {/* Search & Status Filter Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-white/10">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search pitches by brand, creator name, handle, or pitch text..."
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 outline-none focus:border-[#C9A46A] font-mono"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-[#C9A46A] shrink-0" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-[#111E33] border border-white/10 text-xs font-mono text-white rounded-xl px-3.5 py-2.5 outline-none cursor-pointer"
              >
                <option value="all">All Statuses ({inboundPitches.length})</option>
                <option value="DirectorReviewRequired">Pending Review</option>
                <option value="ApprovedAndConverted">Approved &amp; Converted</option>
                <option value="Rejected">Archived / Rejected</option>
              </select>
            </div>
          </div>
        </div>

        {/* Pitches List */}
        <div className="space-y-5">
          {filteredPitches.length === 0 ? (
            <div className="bg-[#0D1830] border border-white/10 rounded-3xl p-12 text-center text-slate-400 text-xs space-y-3 shadow-xl">
              <AlertCircle className="w-8 h-8 text-slate-500 mx-auto" />
              <h4 className="text-sm font-bold text-white font-serif">No Creator Pitches Match Selection</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                No inbound brand pitches match your search filters. Forwarded pitch submissions will appear here in real-time.
              </p>
            </div>
          ) : (
            filteredPitches.map((pitch) => (
              <div key={pitch.id} className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A]/50 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl transition-all">
                {/* Top Card Bar */}
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-white/10 pb-4">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-[#C9A46A]/10 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] font-bold font-serif text-lg shrink-0">
                      {pitch.brandName?.charAt(0) || 'B'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-white font-serif">{pitch.brandName}</h3>
                        {pitch.proposedBudget && (
                          <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                            <DollarSign className="w-3 h-3 stroke-[3]" />
                            <span>${pitch.proposedBudget} Budget</span>
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#C9A46A] font-mono mt-0.5">
                        Brand Inbound Contact: <span className="text-white">{pitch.brandContactEmail || 'Direct DM / Inquiry'}</span>
                      </p>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div className="flex items-center gap-2">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold font-mono uppercase tracking-wider border ${
                      pitch.status === 'ApprovedAndConverted' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                      pitch.status === 'Rejected' ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' :
                      'bg-amber-500/10 text-amber-300 border-amber-500/30'
                    }`}>
                      {pitch.status === 'ApprovedAndConverted' ? '✔ Approved & Converted to Deal' : pitch.status === 'Rejected' ? 'Archived' : 'Director Review Required'}
                    </span>
                  </div>
                </div>

                {/* Creator Contact Info Header (FULL INFO RECEIVED FROM CREATOR) */}
                <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4.5 space-y-2.5">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="text-[10px] font-mono uppercase font-bold text-[#C9A46A] flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5" />
                      <span>Forwarding Creator Contact Record</span>
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      Platform: <strong className="text-white">{pitch.creatorPlatform || 'Social Creator'}</strong>
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase block">Creator Name</span>
                      <span className="font-bold text-white text-sm">{pitch.creatorName || 'Elena Rostova'}</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 uppercase block">Social Handle</span>
                      <span className="text-[#C9A46A] font-bold">{pitch.creatorHandle || '@elenarostova'}</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 uppercase block">Contact Email</span>
                      <a href={`mailto:${pitch.creatorEmail}`} className="text-blue-300 hover:underline flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        <span className="truncate">{pitch.creatorEmail || 'N/A'}</span>
                      </a>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 uppercase block">Contact Phone</span>
                      <span className="text-slate-300 flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-500" />
                        <span>{pitch.creatorPhone || 'N/A'}</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Scope & Deliverables Details Grid */}
                {(pitch.deliverables || pitch.timeline) && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                    {pitch.deliverables && (
                      <div className="bg-[#111E33]/60 border border-white/5 rounded-xl p-3.5 space-y-1">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Proposed Deliverables / Scope</span>
                        <p className="text-white font-sans">{pitch.deliverables}</p>
                      </div>
                    )}
                    {pitch.timeline && (
                      <div className="bg-[#111E33]/60 border border-white/5 rounded-xl p-3.5 space-y-1">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Target Timeline / Deadline</span>
                        <p className="text-white font-sans flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-[#C9A46A]" />
                          <span>{pitch.timeline}</span>
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Original Brand Message / DM Text */}
                <div className="bg-[#091122] border border-white/10 rounded-2xl p-4.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase font-bold text-[#C9A46A] flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Original Brand Outreach / DM Transcript</span>
                    </span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                    {pitch.messageText || pitch.notes || 'No message transcript provided.'}
                  </p>
                </div>

                {/* Creator Additional Notes */}
                {pitch.additionalNotes && (
                  <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-3.5 space-y-1 text-xs">
                    <span className="text-[10px] font-mono uppercase font-bold text-amber-300 block">
                      Creator Notes / Instructions to Director
                    </span>
                    <p className="text-slate-300 font-sans">{pitch.additionalNotes}</p>
                  </div>
                )}

                {/* Uploaded Attachments & Screenshots Gallery */}
                {pitch.attachments && pitch.attachments.length > 0 && (
                  <div className="space-y-2.5 pt-1">
                    <span className="text-[10px] font-mono uppercase font-bold text-[#C9A46A] flex items-center gap-1.5">
                      <Paperclip className="w-3.5 h-3.5" />
                      <span>Uploaded Creator Files &amp; Screenshots ({pitch.attachments.length})</span>
                    </span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {pitch.attachments.map((att: UploadedFileItem, idx: number) => {
                        const isImage = att.fileType?.startsWith('image/') || att.fileData?.startsWith('data:image/');

                        return (
                          <div key={att.id || idx} className="bg-[#111E33] border border-white/10 hover:border-[#C9A46A] rounded-xl p-3 space-y-2 group transition">
                            {isImage && att.fileData ? (
                              <div
                                onClick={() => setSelectedAttachmentModal(att)}
                                className="w-full h-28 bg-black/40 rounded-lg overflow-hidden relative cursor-pointer group-hover:brightness-110"
                              >
                                <img src={att.fileData} alt={att.fileName} className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition">
                                  <Eye className="w-5 h-5 text-white" />
                                </div>
                              </div>
                            ) : (
                              <div className="w-full h-20 bg-black/30 rounded-lg border border-white/5 flex items-center justify-center text-slate-400">
                                <FileText className="w-8 h-8 text-[#C9A46A]" />
                              </div>
                            )}

                            <div className="flex items-center justify-between text-xs font-mono">
                              <div className="truncate pr-2">
                                <p className="text-white font-bold truncate text-[11px]">{att.fileName}</p>
                                <span className="text-[9px] text-slate-400 block">{formatBytes(att.fileSize)}</span>
                              </div>

                              {att.fileData && (
                                <a
                                  href={att.fileData}
                                  download={att.fileName}
                                  className="p-1.5 bg-white/5 hover:bg-[#C9A46A] hover:text-black rounded-lg text-slate-300 transition shrink-0 cursor-pointer"
                                  title="Download attachment"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                </a>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Director Actions Bar */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-white/10 text-xs">
                  <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>Submitted by creator &bull; Direct Agency Desk Sync</span>
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleDeletePitch(pitch)}
                      className="px-3.5 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 rounded-xl text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer"
                      title="Delete pitch to 30-day trash"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Move to Trash</span>
                    </button>

                    {pitch.status !== 'ApprovedAndConverted' && pitch.status !== 'Rejected' && (
                      <>
                        <button
                          type="button"
                          onClick={() => handleRejectPitch(pitch)}
                          className="px-3.5 py-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 rounded-xl text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Archive</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleApprovePitch(pitch)}
                          className="px-5 py-2 bg-gradient-to-r from-[#C9A46A] to-[#D4AF37] hover:brightness-110 text-[#0A1220] font-mono font-bold rounded-xl text-xs transition flex items-center gap-1.5 shadow-lg cursor-pointer uppercase tracking-wider"
                        >
                          <Check className="w-4 h-4 stroke-[3]" />
                          <span>Approve &amp; Convert to Deal</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Attachment Fullscreen Preview Modal */}
        {selectedAttachmentModal && (
          <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-[#0D1830] border-2 border-[#C9A46A]/50 rounded-3xl p-6 max-w-3xl w-full shadow-2xl text-white space-y-4 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="truncate pr-4">
                  <h3 className="text-sm font-serif font-bold text-white truncate">{selectedAttachmentModal.fileName}</h3>
                  <p className="text-[10px] font-mono text-slate-400">{formatBytes(selectedAttachmentModal.fileSize)}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {selectedAttachmentModal.fileData && (
                    <a
                      href={selectedAttachmentModal.fileData}
                      download={selectedAttachmentModal.fileName}
                      className="px-3 py-1.5 bg-[#C9A46A] text-[#0A1220] rounded-xl text-xs font-bold font-mono uppercase tracking-wider flex items-center gap-1 hover:brightness-110"
                    >
                      <Download className="w-3.5 h-3.5" /> Download
                    </a>
                  )}
                  <button
                    onClick={() => setSelectedAttachmentModal(null)}
                    className="p-1.5 bg-white/10 hover:bg-white/20 rounded-xl text-white cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-center bg-black/60 rounded-2xl p-4 min-h-[300px]">
                {selectedAttachmentModal.fileType?.startsWith('image/') || selectedAttachmentModal.fileData?.startsWith('data:image/') ? (
                  <img
                    src={selectedAttachmentModal.fileData}
                    alt={selectedAttachmentModal.fileName}
                    className="max-h-[70vh] object-contain rounded-xl"
                  />
                ) : (
                  <div className="text-center space-y-3 p-8">
                    <FileText className="w-16 h-16 text-[#C9A46A] mx-auto" />
                    <p className="text-xs font-mono text-slate-300">Document Attachment ({selectedAttachmentModal.fileType})</p>
                    {selectedAttachmentModal.fileData && (
                      <a
                        href={selectedAttachmentModal.fileData}
                        download={selectedAttachmentModal.fileName}
                        className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-500 text-black font-bold text-xs rounded-xl font-mono uppercase tracking-wider"
                      >
                        <Download className="w-4 h-4" /> Download Document
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ----------------- CREATOR SUBMISSION FORM VIEW -----------------
  if (isSuccess) {
    return (
      <div className="bg-[#0D1830] border-2 border-emerald-500/40 rounded-3xl p-8 sm:p-12 text-center space-y-6 animate-in fade-in zoom-in duration-300 shadow-2xl max-w-2xl mx-auto my-12">
        <div className="w-20 h-20 bg-emerald-500/10 rounded-2xl flex items-center justify-center mx-auto border border-emerald-500/30">
          <CheckCircle className="w-10 h-10 text-emerald-400" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-serif font-bold text-white">Inbound Lead &amp; Attachments Successfully Transmitted</h2>
          <p className="text-[#C9A46A] text-xs font-mono max-w-md mx-auto leading-relaxed">
            All brand message details, contact information, deliverables, and uploaded pitch files have been delivered directly to the Agency Director desk.
          </p>
        </div>
        <button 
          onClick={() => setIsSuccess(false)}
          className="px-6 py-2.5 bg-[#111E33] hover:bg-[#182A47] border border-white/10 rounded-xl text-xs font-mono text-white transition-colors cursor-pointer uppercase tracking-wider font-bold"
        >
          Forward Another Brand Pitch
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12 text-white">
      {/* Header Banner */}
      <div className="bg-[#0D1830] border-2 border-[#C9A46A]/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-2">
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-[0.2em] font-mono bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-1 rounded-full">
            Agency Executive Forwarder
          </span>
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <ShieldCheck className="w-3 h-3" /> Direct Director Sync
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">Creator Brand Pitch Forwarder</h1>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          Forward inbound brand deals, sponsor DMs, or campaign inquiries directly to agency executive management. The Director will receive your contact record, brand details, deliverables, timeline, and all attached pitch files.
        </p>
      </div>

      <div className="bg-[#0D1830] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl">
        <form onSubmit={handleSubmit} className="space-y-6 font-mono text-xs">
          {/* SECTION 1: CREATOR CONTACT INFO */}
          <div className="space-y-3 bg-[#111E33] border border-white/10 rounded-2xl p-4.5">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-[10px] uppercase font-bold text-[#C9A46A] flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" />
                <span>Your Creator Contact Record (Transmitted to Director)</span>
              </span>
              <span className="text-[10px] text-slate-400">Auto-Verified Talent</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase block">Creator Name *</label>
                <input
                  type="text"
                  required
                  value={creatorNameInput}
                  onChange={(e) => setCreatorNameInput(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase block">Social Handle *</label>
                <input
                  type="text"
                  required
                  value={creatorHandleInput}
                  onChange={(e) => setCreatorHandleInput(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl px-3 py-2 text-xs text-[#C9A46A] font-bold outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase block">Email Address *</label>
                <input
                  type="email"
                  required
                  value={creatorEmailInput}
                  onChange={(e) => setCreatorEmailInput(e.target.value)}
                  className="w-full bg-[#091122] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 uppercase block">Phone Number</label>
                <input
                  type="text"
                  value={creatorPhoneInput}
                  onChange={(e) => setCreatorPhoneInput(e.target.value)}
                  placeholder="+1 (555) 000-0000"
                  className="w-full bg-[#091122] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                />
              </div>
            </div>
          </div>

          {/* SECTION 2: BRAND & DEAL DETAILS */}
          <div className="space-y-4">
            <span className="text-[10px] uppercase font-bold text-[#C9A46A] block tracking-wider">
              Brand &amp; Campaign Inquiry Details
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Brand Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-300 uppercase block">Brand or Company Name *</label>
                <div className="relative">
                  <Building className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    required
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    placeholder="e.g. Nike, Sephora, Gymshark"
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white outline-none"
                  />
                </div>
              </div>

              {/* Brand Inbound Contact */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-300 uppercase block">Brand Contact Email / Inbound Rep</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="email"
                    value={brandContactEmail}
                    onChange={(e) => setBrandContactEmail(e.target.value)}
                    placeholder="e.g. partnerships@brand.com"
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white outline-none"
                  />
                </div>
              </div>

              {/* Budget */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-300 uppercase block">Offered Budget Amount ($ USD)</label>
                <div className="relative">
                  <DollarSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400 stroke-[3]" />
                  <input
                    type="text"
                    value={proposedBudget}
                    onChange={(e) => setProposedBudget(e.target.value)}
                    placeholder="e.g. 5,000"
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl pl-10 pr-4 py-2.5 text-xs font-bold text-emerald-400 outline-none"
                  />
                </div>
              </div>

              {/* Timeline */}
              <div className="space-y-1.5">
                <label className="text-[10px] text-slate-300 uppercase block">Target Timeline / Deadline</label>
                <div className="relative">
                  <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#C9A46A]" />
                  <input
                    type="text"
                    value={timeline}
                    onChange={(e) => setTimeline(e.target.value)}
                    placeholder="e.g. October 15, 2026 or Next Month"
                    className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Deliverables Scope */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-slate-300 uppercase block">Requested Deliverables &amp; Scope</label>
              <input
                type="text"
                value={deliverables}
                onChange={(e) => setDeliverables(e.target.value)}
                placeholder="e.g. 2x TikToks, 1x Instagram Reel with 30-day Spark Ads usage rights"
                className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
              />
            </div>

            {/* DM Transcript */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-slate-300 uppercase block">Paste Full Brand Message / DM Transcript *</label>
              <div className="relative">
                <MessageSquare className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
                <textarea
                  required
                  rows={5}
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Paste the full outreach message or email you received from the brand..."
                  className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl pl-10 pr-4 py-3 text-xs text-white outline-none resize-none font-sans"
                />
              </div>
            </div>

            {/* Creator Notes */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-slate-300 uppercase block">Your Notes / Instructions to Director</label>
              <textarea
                rows={2}
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                placeholder="Any special instructions or preferences for negotiating this deal..."
                className="w-full bg-[#111E33] border border-white/10 focus:border-[#C9A46A] rounded-xl p-3 text-xs text-white outline-none resize-none font-sans"
              />
            </div>
          </div>

          {/* SECTION 3: FILE ATTACHMENTS & SCREENSHOTS */}
          <div className="space-y-3 border-t border-white/10 pt-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-[#C9A46A] flex items-center gap-1.5">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Pitch Screenshots, Decks or Briefs</span>
              </span>
              {attachments.length > 0 && (
                <span className="text-[10px] text-emerald-400 font-bold">
                  {attachments.length} file(s) attached
                </span>
              )}
            </div>

            <div className="group relative border-2 border-dashed border-white/10 hover:border-[#C9A46A] rounded-2xl p-6 transition-all cursor-pointer bg-[#111E33]/50 hover:bg-[#111E33] text-center">
              <input
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
              />
              <div className="flex flex-col items-center justify-center space-y-2">
                <div className="p-3 bg-white/5 rounded-xl group-hover:bg-[#C9A46A]/20 transition-colors">
                  {isUploading ? (
                    <Loader2 className="w-6 h-6 text-[#C9A46A] animate-spin" />
                  ) : (
                    <ImageIcon className="w-6 h-6 text-[#C9A46A]" />
                  )}
                </div>
                <p className="text-xs font-bold text-white">
                  {isUploading ? 'Processing uploads...' : 'Click or Drag & Drop Screenshots, Brand Brief PDFs or Pitch Decks'}
                </p>
                <p className="text-[10px] text-slate-400">Supports PNG, JPG, WEBP, and PDF brief documents</p>
              </div>
            </div>

            {/* List of Attached Files */}
            {attachments.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-2">
                {attachments.map((att) => {
                  const isImage = att.fileType?.startsWith('image/') || att.fileData?.startsWith('data:image/');

                  return (
                    <div key={att.id} className="bg-[#111E33] border border-white/10 rounded-xl p-3 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5 truncate">
                        {isImage && att.fileData ? (
                          <img src={att.fileData} alt={att.fileName} className="w-9 h-9 rounded-lg object-cover shrink-0" />
                        ) : (
                          <div className="w-9 h-9 rounded-lg bg-black/40 flex items-center justify-center text-[#C9A46A] shrink-0">
                            <FileText className="w-5 h-5" />
                          </div>
                        )}
                        <div className="truncate">
                          <p className="text-xs font-bold text-white truncate">{att.fileName}</p>
                          <span className="text-[9px] text-slate-400 block">{formatBytes(att.fileSize)}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveAttachment(att.id)}
                        className="p-1 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 cursor-pointer transition shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* SUBMIT BUTTON */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-gradient-to-r from-[#C9A46A] to-[#D4AF37] hover:brightness-110 disabled:opacity-40 text-[#0A1220] font-mono font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-3 shadow-xl cursor-pointer uppercase tracking-wider"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Transmitting to Agency Executive Desk...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Forward All Pitch Info &amp; Files to Agency Director</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <div className="p-4 bg-[#0D1830] border border-[#C9A46A]/20 rounded-2xl flex items-center gap-3 text-xs text-slate-300">
        <ShieldCheck className="w-5 h-5 text-[#C9A46A] shrink-0" />
        <span>Executive Desk Protocol: Direct transmission to Director desk. All information and attachments are securely recorded in the agency portal.</span>
      </div>
    </div>
  );
}

function LoadSpinnerIcon({ isLoading }: { isLoading: boolean }) {
  if (isLoading) {
    return <Loader2 className="w-4 h-4 animate-spin text-[#C9A46A]" />;
  }
  return <ShieldCheck className="w-4 h-4 text-[#C9A46A]" />;
}
