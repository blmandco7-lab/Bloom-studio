import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Package, 
  Clock, 
  CheckCircle2, 
  Users, 
  Briefcase, 
  Layers, 
  Sparkles,
  TrendingUp,
  AlertTriangle,
  FileText
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';

interface ManagerDashboardConsoleProps {
  creators?: any[];
  deals?: any[];
  currentRole?: string;
  currentUser?: any;
}

/**
 * ManagerDashboardConsole
 * Core operational workspace for Agent Managers enforcing strict financial blindness
 * and high-priority operational briefing logs, styled in original Bloom Studio navy and gold.
 */
export default function ManagerDashboardConsole({
  creators = [],
  deals = [],
  currentRole = 'agentmgr',
  currentUser
}: ManagerDashboardConsoleProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'pipelines' | 'briefings'>('overview');
  const [pipelineRows, setPipelineRows] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const mgrName = currentUser?.name || 'Manager';

  useEffect(() => {
    // Fetch campaigns assigned to the current user or all if they are a director
    const campaignsRef = collection(db, 'studio-campaigns');
    const q = currentRole === 'director' 
      ? query(campaignsRef)
      : query(campaignsRef, where('assignedAgent', '==', mgrName));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const campaigns: any[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        campaigns.push({
          id: doc.id,
          campaignName: data.title || data.campaignName,
          vertical: data.vertical || data.niche || 'General',
          brandClient: data.brandName || data.brandClient,
          assignedAgent: data.assignedAgent,
          stageStatus: data.status || data.stageStatus || 'Active',
        });
      });
      setPipelineRows(campaigns);
      setIsLoading(false);
    }, (err) => {
      console.error('Error fetching campaigns:', err);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [currentRole, mgrName]);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Daily Briefing Banner */}
      <div className="bg-[#112240] border border-[#C9A46A]/20 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#C9A46A]/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-[#C9A46A] font-mono text-xs uppercase tracking-widest mb-1">
              <Briefcase className="w-4 h-4" /> Agent Manager Executive Console
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white">Daily Operational Briefing & Pipeline Hub</h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> SECURE ROLE SHIELD ACTIVE
            </span>
          </div>
        </div>

        {/* High-Priority Notification Deck */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#C9A46A]">
            <Clock className="w-4 h-4" /> Live Operational Briefing Deck
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {pipelineRows.slice(0, 3).map((row) => (
              <div 
                key={`alert-${row.id}`}
                className="bg-[#0B132B]/80 border border-white/10 rounded-xl p-4 flex flex-col justify-between hover:border-[#C9A46A]/30 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30`}>
                      Campaign Status
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">Just updated</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {row.campaignName} for {row.brandClient} is currently in {row.stageStatus}.
                  </p>
                </div>
              </div>
            ))}
            {pipelineRows.length === 0 && !isLoading && (
              <div className="col-span-3 py-6 text-center text-slate-400 text-xs font-mono border border-dashed border-white/10 rounded-xl">
                No active campaign briefings found.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Staff Velocity Metric Grid (2 Columns) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#112240] border border-white/10 rounded-2xl p-6 shadow-lg flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">Velocity Metric</span>
            <h3 className="text-lg font-semibold text-white mt-1">Average Agent Content Review Speed</h3>
            <p className="text-xs text-slate-400 mt-0.5">Tracked across internal staging & compliance queues</p>
          </div>
          <div className="text-right">
            <span className="text-3xl font-mono font-bold text-[#C9A46A]">4.2 hrs</span>
            <span className="block text-[10px] font-mono text-emerald-400 mt-1">↓ 1.5h faster than weekly target</span>
          </div>
        </div>

        <div className="bg-[#112240] border border-white/10 rounded-2xl p-6 shadow-lg flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">Audition Pipeline</span>
            <h3 className="text-lg font-semibold text-white mt-1">Open Casting Call Auditions Awaiting Shortlist</h3>
            <p className="text-xs text-slate-400 mt-0.5">Pending manager sign-off for active dispatches</p>
          </div>
          <div className="text-right">
            <span className="text-3xl font-mono font-bold text-[#C9A46A]">18</span>
            <span className="block text-[10px] font-mono text-amber-400 mt-1">Requires review today</span>
          </div>
        </div>
      </div>

      {/* Campaign Pipeline Tracking Matrix (Pets, Cosmetics, Luxury Lifestyle) */}
      <div className="bg-[#112240] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#C9A46A]" /> Active Campaign Pipeline Tracking Matrix
            </h2>
            <p className="text-xs text-slate-400">Monitoring real-time stage status across Pets, Cosmetics, and Luxury Lifestyle verticals</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono bg-[#0B132B] border border-white/10 px-3 py-1 rounded-xl text-slate-300">
              5 Active Projects
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-[11px] font-mono uppercase tracking-wider text-slate-400 bg-[#0B132B]/50">
                <th className="py-3 px-4">Campaign Name</th>
                <th className="py-3 px-4">Vertical</th>
                <th className="py-3 px-4">Brand Client</th>
                <th className="py-3 px-4">Assigned Agent</th>
                <th className="py-3 px-4">Live Deliverable Stage Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs">
              {pipelineRows.map((row) => (
                <tr key={row.id} className="hover:bg-white/5 transition-colors">
                  <td className="py-3.5 px-4 font-medium text-white flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#C9A46A]" />
                    {row.campaignName}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2.5 py-1 rounded-lg text-[10px] font-mono bg-white/5 text-slate-300 border border-white/10">
                      {row.vertical}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-200">{row.brandClient}</td>
                  <td className="py-3.5 px-4 text-slate-300 font-mono">{row.assignedAgent}</td>
                  <td className="py-3.5 px-4">
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold ${
                      row.stageStatus.includes('Internal Review')
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : row.stageStatus.includes('Brand Review')
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                        : row.stageStatus.includes('Filming')
                        ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}>
                      {row.stageStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
