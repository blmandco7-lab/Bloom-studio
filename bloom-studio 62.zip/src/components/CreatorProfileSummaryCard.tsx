import React from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  Instagram, 
  Video as VideoIcon, 
  Youtube, 
  Activity, 
  Tag, 
  Award,
  Layers,
  Check
} from 'lucide-react';

export interface CreatorMarketingMetrics {
  id?: string;
  name: string;
  handle: string;
  avatar?: string;
  platform: 'TikTok' | 'Instagram' | 'YouTube' | string;
  niche: 'Beauty' | 'Pets' | 'Lifestyle' | string;
  verifiedReach: string;
  avgViews?: string;
  engagementRate?: string;
  // Dynamic Niche Matrix Parameters (Client-facing metadata only)
  skinTypeMatrix?: string;
  skinTone?: string;
  hairMatrix?: string;
  petBreedMetrics?: string;
  petAgeWeight?: string;
  petDietCategory?: string;
  aestheticMatrix?: string;
  lightingStyle?: string;
  colorStory?: string;
  ftcComplianceVerified?: boolean;
  copyrightClearanceActive?: boolean;
}

interface CreatorProfileSummaryCardProps {
  creator?: CreatorMarketingMetrics;
  compact?: boolean;
  className?: string;
}

const DEFAULT_CREATOR: CreatorMarketingMetrics = {
  name: "Elena Rostova",
  handle: "@elenarostova",
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80",
  platform: "Instagram",
  niche: "Beauty",
  verifiedReach: "485,000",
  avgViews: "142,500",
  engagementRate: "5.8%",
  skinTypeMatrix: "Combination / Sensitive",
  skinTone: "Neutral Cool (Fitzpatrick II)",
  hairMatrix: "Type 2B Wavy / Color-Treated",
  ftcComplianceVerified: true,
  copyrightClearanceActive: true
};

export default function CreatorProfileSummaryCard({
  creator = DEFAULT_CREATOR,
  compact = false,
  className = ""
}: CreatorProfileSummaryCardProps) {
  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return <Instagram className="w-4 h-4 text-pink-400" />;
      case 'tiktok':
        return <VideoIcon className="w-4 h-4 text-cyan-400" />;
      case 'youtube':
        return <Youtube className="w-4 h-4 text-red-400" />;
      default:
        return <Activity className="w-4 h-4 text-agency-gold" />;
    }
  };

  const renderNicheTags = () => {
    const nicheLower = (creator.niche || '').toLowerCase();

    if (nicheLower.includes('beauty') || nicheLower.includes('cosmetic')) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
              Skin Type Matrix
            </span>
            <span className="text-xs font-semibold text-white">
              {creator.skinTypeMatrix || "Combination / Dehydrated"}
            </span>
          </div>
          <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
              Tone & Undertone
            </span>
            <span className="text-xs font-semibold text-white">
              {creator.skinTone || "Neutral-Cool / Olive"}
            </span>
          </div>
          <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
              Hair Matrix
            </span>
            <span className="text-xs font-semibold text-white">
              {creator.hairMatrix || "Wavy 2B / Balayage"}
            </span>
          </div>
        </div>
      );
    }

    if (nicheLower.includes('pet') || nicheLower.includes('dog') || nicheLower.includes('cat')) {
      return (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
              Pet Breed Metrics
            </span>
            <span className="text-xs font-semibold text-white">
              {creator.petBreedMetrics || "Golden Retriever / Purebred"}
            </span>
          </div>
          <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
              Age & Weight Matrix
            </span>
            <span className="text-xs font-semibold text-white">
              {creator.petAgeWeight || "3.5 Years • 64 lbs"}
            </span>
          </div>
          <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
              Dietary Profile
            </span>
            <span className="text-xs font-semibold text-white">
              {creator.petDietCategory || "Organic Raw / Grain-Free"}
            </span>
          </div>
        </div>
      );
    }

    // Default Lifestyle Matrix
    return (
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
        <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
            Aesthetic Matrix
          </span>
          <span className="text-xs font-semibold text-white">
            {creator.aestheticMatrix || "Warm Minimalist / Nordic"}
          </span>
        </div>
        <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
            Lighting Style
          </span>
          <span className="text-xs font-semibold text-white">
            {creator.lightingStyle || "Natural Golden Hour (5600K)"}
          </span>
        </div>
        <div className="bg-agency-navy/80 border border-white/10 rounded-xl p-2.5">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-0.5">
            Color Palette
          </span>
          <span className="text-xs font-semibold text-white">
            {creator.colorStory || "Earthy Terracotta & Cream"}
          </span>
        </div>
      </div>
    );
  };

  return (
    <div 
      id={`creator-profile-summary-${creator.handle.replace('@', '')}`}
      className={`bg-agency-navyLight border border-agency-gold/30 rounded-2xl p-6 shadow-xl relative overflow-hidden text-agency-textLight ${className}`}
    >
      {/* Top Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-white/10">
        <div className="flex items-center gap-4">
          <div className="relative">
            <img 
              src={creator.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80"} 
              alt={creator.name}
              referrerPolicy="no-referrer"
              className="w-14 h-14 rounded-2xl object-cover border-2 border-agency-gold/50 shadow-md"
            />
            <div className="absolute -bottom-1 -right-1 bg-agency-navy p-1 rounded-full border border-white/20">
              {getPlatformIcon(creator.platform)}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-serif font-bold text-white tracking-wide">
                {creator.name}
              </h3>
              <span className="bg-agency-gold/20 text-agency-gold text-[10px] font-mono uppercase font-bold px-2 py-0.5 rounded-md border border-agency-gold/40">
                {creator.niche}
              </span>
            </div>
            <p className="text-xs font-mono text-slate-300 flex items-center gap-1.5 mt-0.5">
              <span>{creator.handle}</span>
              <span>•</span>
              <span className="text-slate-400">{creator.platform} Creator</span>
            </p>
          </div>
        </div>

        {/* Verified Reach Stat Card */}
        <div className="bg-agency-navy/90 border border-agency-gold/30 rounded-xl px-4 py-2.5 flex items-center justify-between sm:justify-start gap-4">
          <div>
            <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block">
              Verified Total Reach
            </span>
            <span className="text-lg font-mono font-bold text-agency-gold">
              {creator.verifiedReach}
            </span>
          </div>
          <div className="text-right pl-3 border-l border-white/10">
            <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block">
              Avg Velocity
            </span>
            <span className="text-xs font-mono font-bold text-emerald-400">
              {creator.avgViews || "120K+"} views
            </span>
          </div>
        </div>
      </div>

      {/* Niche Breakdown Grid */}
      <div className="py-4 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-agency-gold flex items-center gap-1.5">
            <Tag className="w-3.5 h-3.5" />
            <span>Niche Parameter Matrix ({creator.niche})</span>
          </span>
          <span className="text-[10px] font-mono text-slate-400">
            Client-Facing High-Level Specs
          </span>
        </div>
        {renderNicheTags()}
      </div>

      {/* Legal / Safety Badges (Bold Gold-Bordered Stamps) */}
      <div className="pt-4 border-t border-white/10 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-agency-gold/10 border-2 border-agency-gold shadow-sm">
          <ShieldCheck className="w-4 h-4 text-agency-gold shrink-0" />
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-agency-gold">
            FTC Compliance Registry Verified
          </span>
        </div>

        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-emerald-500/10 border-2 border-emerald-400/80 shadow-sm">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-300">
            Copyright Clearance Active
          </span>
        </div>
      </div>
    </div>
  );
}
