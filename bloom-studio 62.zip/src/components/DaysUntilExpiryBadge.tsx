import React from 'react';
import { getDaysUntilExpiry } from '../lib/contractUtils';

interface DaysUntilExpiryBadgeProps {
  endDate?: string;
  className?: string;
  showIcon?: boolean;
  compact?: boolean;
  id?: string;
}

export default function DaysUntilExpiryBadge({
  endDate,
  className = '',
  showIcon = true,
  compact = false,
  id
}: DaysUntilExpiryBadgeProps) {
  const calculation = getDaysUntilExpiry(endDate);

  return (
    <span
      id={id || `expiry-badge-${endDate || 'none'}`}
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold tracking-tight transition-all ${calculation.colorClass} ${className}`}
      title={`Contract End Date: ${endDate || 'Not specified'} (${calculation.label})`}
    >
      {showIcon && (
        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${calculation.dotColorClass}`} />
      )}
      <span>{compact ? calculation.badgeText : calculation.label}</span>
    </span>
  );
}
