/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Target, CheckCircle2, Clock, DollarSign, Calendar, AlertCircle, 
  ExternalLink, UploadCloud, ChevronRight, Sparkles, ShieldCheck, Compass 
} from 'lucide-react';
import { Mission, MissionChecklistItem } from '../types';

interface CreatorAssignedMissionsViewProps {
  missions: Mission[];
  currentUser: any;
  primaryBrandColor?: string;
  cardBgColor?: string;
  onNavigateToSubmit?: () => void;
  onNavigateToMarketplace?: () => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

const FALLBACK_CREATOR_MISSIONS: Mission[] = [
  {
    id: 'miss_assigned_01',
    name: 'Aura Glow Botanical Hydration UGC Reel',
    type: 'Campaign',
    brand: 'Aura Glow Cosmetics',
    creator: '@alexjones',
    brief: 'Produce 1x 60s Reel showing macro application texture with FTC #ad disclosure. Highlight barrier repair and dewy skin finish in natural morning light.',
    total: 3,
    completed: 2,
    status: 'On track',
    budget: 3500,
    due: 'In 4 Days',
    deadline: '2026-09-12',
    checklists: [
      { id: 'chk_1', label: 'Submit 3-Second Hook Video Draft', done: true },
      { id: 'chk_2', label: 'Include Clear FTC #ad / #sponsored Disclosure in Caption & Video', done: true },
      { id: 'chk_3', label: 'Upload Final 4K Vertical Video & Raw B-Roll to Agency QA', done: false }
    ]
  },
  {
    id: 'miss_assigned_02',
    name: 'Lumina Ergonomic Creator Desk Setup & Studio Tour',
    type: 'Collab',
    brand: 'Lumina Studio Pro',
    creator: '@alexjones',
    brief: 'Create 1x TikTok vertical format setup showcase featuring daylight 5600K lighting with raw unboxing b-roll clips.',
    total: 2,
    completed: 1,
    status: 'Dispatched',
    budget: 2200,
    due: 'In 8 Days',
    deadline: '2026-09-16',
    checklists: [
      { id: 'chk_4', label: 'Desk Setup Lighting Test & Mic Audio Check', done: true },
      { id: 'chk_5', label: 'Deliver 9:16 Video Asset to Agency QA for Brand Approval', done: false }
    ]
  }
];

export default function CreatorAssignedMissionsView({
  missions = [],
  currentUser,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onNavigateToSubmit,
  onNavigateToMarketplace,
  triggerNotification
}: CreatorAssignedMissionsViewProps) {
  const myHandleLower = (currentUser?.handle || '').toLowerCase().replace(/^@/, '');
  const myNameLower = (currentUser?.name || '').toLowerCase();

  // Filter missions strictly assigned to this creator
  const assigned = missions.filter(m => {
    const cLower = (m.creator || '').toLowerCase().replace(/^@/, '');
    return (myHandleLower && cLower.includes(myHandleLower)) || (myNameLower && cLower.includes(myNameLower));
  });

  // Use fallback missions if empty and matches default creator profile
  const effectiveMissions = assigned.length > 0 
    ? assigned 
    : (myHandleLower.includes('alex') || myNameLower.includes('alex') || !myHandleLower)
      ? FALLBACK_CREATOR_MISSIONS
      : [];

  const [localMissions, setLocalMissions] = useState<Mission[]>(effectiveMissions);

  const handleToggleChecklist = (missionId: string, checkId: string) => {
    setLocalMissions(prev => prev.map(m => {
      if (m.id !== missionId) return m;
      const updatedChecklists = (m.checklists || []).map(c => {
        if (c.id === checkId) {
          const nextDone = !c.done;
          return { ...c, done: nextDone };
        }
        return c;
      });
      const completedCount = updatedChecklists.filter(c => c.done).length;
      return {
        ...m,
        checklists: updatedChecklists,
        completed: completedCount
      };
    }));
    triggerNotification('Checklist Updated', 'Deliverable checklist progress updated.', 'info');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto animate-fade-in text-slate-100">
      {/* Header Banner */}
      <div 
        className="border border-white/10 rounded-2xl p-6 shadow-xl"
        style={{ backgroundColor: cardBgColor }}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
              <Target className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                  ASSIGNED MISSIONS ONLY
                </span>
                <span className="text-xs text-emerald-400 font-mono">
                  {effectiveMissions.length} Active {effectiveMissions.length === 1 ? 'Mission' : 'Missions'}
                </span>
              </div>
              <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
                My Missions &amp; Pay Rates
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Active campaign missions assigned to {currentUser?.name || 'your profile'} ({currentUser?.handle || '@creator'}) with guaranteed compensation.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 self-start md:self-auto">
            {onNavigateToMarketplace && (
              <button
                onClick={onNavigateToMarketplace}
                className="bg-purple-600/30 hover:bg-purple-600/40 text-purple-200 border border-purple-500/40 px-4 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition cursor-pointer shadow-lg"
              >
                <Compass className="w-4 h-4 text-purple-400" />
                <span>Explore Open Opportunities</span>
              </button>
            )}

            {onNavigateToSubmit && (
              <button
                onClick={onNavigateToSubmit}
                className="bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] px-4 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition cursor-pointer shadow-lg"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Submit Deliverable</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Missions List */}
      {localMissions.length === 0 ? (
        <div 
          className="border border-white/10 rounded-2xl p-12 text-center space-y-4 shadow-xl"
          style={{ backgroundColor: cardBgColor }}
        >
          <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-[#C9A46A]">
            <Target className="w-8 h-8 opacity-80" />
          </div>
          <div>
            <h2 className="text-lg font-serif font-bold text-white">No Assigned Missions Found</h2>
            <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
              You currently have no campaign missions dispatched to your handle ({currentUser?.handle || '@creator'}). When your agent manager or brand partner assigns you to a mission, your deliverables and guaranteed pay rate will appear here.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {localMissions.map((m) => {
            const payRate = m.budget || 2500;
            const completedCount = m.completed ?? 0;
            const totalCount = m.total ?? (m.checklists?.length || 1);
            const progressPct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

            return (
              <div 
                key={m.id}
                className="border border-white/10 hover:border-[#C9A46A]/40 rounded-2xl p-6 space-y-5 transition shadow-xl"
                style={{ backgroundColor: cardBgColor }}
              >
                {/* Top Row: Brand & Status */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-[#C9A46A] uppercase tracking-wider">
                      {m.brand}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-slate-300 border border-white/10 font-mono">
                      {m.type || 'Campaign'}
                    </span>
                  </div>

                  <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold uppercase ${
                    m.status === 'Completed'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      : 'bg-[#C9A46A]/10 text-[#C9A46A] border border-[#C9A46A]/30'
                  }`}>
                    {m.status || 'On Track'}
                  </span>
                </div>

                {/* Title & Pay Rate Card */}
                <div>
                  <h2 className="font-serif font-bold text-xl text-white">
                    {m.name}
                  </h2>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                    {m.brief}
                  </p>
                </div>

                {/* Prominent Guaranteed Pay Rate Banner */}
                <div className="bg-[#111E33] border border-white/10 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-[#7C8AA8] block">
                      Guaranteed Pay Rate
                    </span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-2xl font-bold font-mono text-emerald-400">
                        ${payRate.toLocaleString()}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">USD</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-[#7C8AA8] block">
                      Target Due Date
                    </span>
                    <div className="flex items-center gap-1.5 text-xs font-mono text-[#C9A46A] font-bold mt-1">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{m.due || m.deadline || 'In 5 Days'}</span>
                    </div>
                  </div>
                </div>

                {/* Deliverables Checklist Progress */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-300 font-semibold">
                      Deliverables: {completedCount}/{totalCount} Completed
                    </span>
                    <span className="font-mono text-[#C9A46A] font-bold">
                      {progressPct}%
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-[#C9A46A] rounded-full transition-all duration-300"
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>

                  {/* Checklists */}
                  {m.checklists && m.checklists.length > 0 && (
                    <div className="space-y-2 pt-2">
                      {m.checklists.map((chk) => (
                        <button 
                          key={chk.id}
                          type="button"
                          onClick={() => handleToggleChecklist(m.id, chk.id)}
                          className="w-full text-left flex items-start gap-2.5 p-2.5 rounded-lg bg-[#111E33]/60 hover:bg-[#111E33] border border-white/5 cursor-pointer transition"
                          aria-label={`Toggle checklist item: ${chk.label}`}
                        >
                          <div className={`mt-0.5 w-4 h-4 rounded flex items-center justify-center border transition ${
                            chk.done 
                              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400' 
                              : 'border-white/20 hover:border-[#C9A46A]'
                          }`}>
                            {chk.done && <CheckCircle2 className="w-3.5 h-3.5" />}
                          </div>
                          <span className={`text-xs ${chk.done ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                            {chk.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Bottom Actions */}
                <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-3">
                  <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Escrow Protected
                  </span>

                  {onNavigateToSubmit ? (
                    <button
                      onClick={onNavigateToSubmit}
                      className="px-3.5 py-1.5 bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] font-mono text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 shadow"
                    >
                      <UploadCloud className="w-3.5 h-3.5" />
                      <span>Submit Content</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => triggerNotification('Deliverable Uploaded', `Deliverable submitted for ${m.name}.`, 'success')}
                      className="px-3.5 py-1.5 bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] font-mono text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 shadow"
                    >
                      <span>Submit Draft</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
