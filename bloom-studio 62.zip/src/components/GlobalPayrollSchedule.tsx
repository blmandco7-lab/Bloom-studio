import React, { useState, useMemo, useEffect } from 'react';
import { Clock, ShieldCheck, DollarSign, ArrowRight, CheckCircle2, AlertCircle, Sparkles, Building2 } from 'lucide-react';
import { UserProfileWithRole } from './ManagerCommissionLog';
import { safeStorage } from '../utils/safeStorage';
import { db } from '../lib/firebase';
import { doc, setDoc, getDoc, collection, onSnapshot, query } from 'firebase/firestore';

export interface GlobalPayrollCampaign {
  id: string;
  clientId: string;
  brandName: string;
  campaignTitle: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  brandPaymentTerms: 'Upfront' | 'Net 15' | 'Net 30' | 'Net 60';
  invoiceDate: string;
  estimatedClearDate: string;
  daysRemaining: number;
  escrowStatus: 'Awaiting Brand Deposit' | 'Cleared in Escrow' | 'Disbursed';
  grossContractValue: number; // Strictly Director-Only
  totalCreatorAllocations: number;
  totalStaffAllocations: number;
  assignedStaff: Array<{
    uid: string;
    name: string;
    role: string;
    compensationAmount: number;
  }>;
  assignedCreators: Array<{
    creatorHandle: string;
    contractAmount: number;
  }>;
}

interface GlobalPayrollScheduleProps {
  currentUser: UserProfileWithRole;
  onDisburseFunds?: (campaignId: string) => Promise<void> | void;
  initialCampaigns?: GlobalPayrollCampaign[];
  mode?: 'payroll' | 'escrow';
}

/**
 * GlobalPayrollSchedule:
 * Premium, Owner/Director-only master tracking view.
 * 
 * CRITICAL IMPLEMENTATION SAFETY BOUND:
 * 1. Restricted exclusively to user.role === 'Owner' || 'Director'.
 * 2. Completely hides internal team profit margins and top-line gross numbers from any manager or coordinator.
 * 3. Disbursal trigger instantly simulates / calls backend ledger updates to increment staff totalEarnedToDate.
 */
export const DEFAULT_PAYROLL_CAMPAIGNS: GlobalPayrollCampaign[] = [
  {
    id: "camp_glowlab_01",
    clientId: "glowlab",
    brandName: "GlowLab Beauty",
    campaignTitle: "Summer Botanical Serum Whitelisting",
    niche: "Beauty",
    brandPaymentTerms: "Net 30",
    invoiceDate: "2026-08-01",
    estimatedClearDate: "2026-08-31",
    daysRemaining: 8,
    escrowStatus: "Cleared in Escrow",
    grossContractValue: 24500,
    totalCreatorAllocations: 12000,
    totalStaffAllocations: 3200,
    assignedStaff: [
      { uid: "usr_mgr_sarah_04", name: "Sarah Jenkins", role: "AgentManager", compensationAmount: 1800 },
      { uid: "usr_agent_8821", name: "Elena Rostova", role: "Agent", compensationAmount: 950 },
      { uid: "usr_coord_12", name: "Liam Vance", role: "Coordinator", compensationAmount: 450 }
    ],
    assignedCreators: [
      { creatorHandle: "@ava_glow", contractAmount: 6000 },
      { creatorHandle: "@mia_botanics", contractAmount: 6000 }
    ]
  },
  {
    id: "camp_barkhydrate_02",
    clientId: "barkhydrate",
    brandName: "BarkHydrate Eco",
    campaignTitle: "Organic Fur Shampoo & Pet Balm Launch",
    niche: "Pets",
    brandPaymentTerms: "Net 15",
    invoiceDate: "2026-08-15",
    estimatedClearDate: "2026-08-30",
    daysRemaining: 7,
    escrowStatus: "Awaiting Brand Deposit",
    grossContractValue: 18000,
    totalCreatorAllocations: 8500,
    totalStaffAllocations: 2400,
    assignedStaff: [
      { uid: "usr_mgr_sarah_04", name: "Sarah Jenkins", role: "AgentManager", compensationAmount: 1400 },
      { uid: "usr_coord_12", name: "Liam Vance", role: "Coordinator", compensationAmount: 1000 }
    ],
    assignedCreators: [
      { creatorHandle: "@paws_and_palette", contractAmount: 8500 }
    ]
  },
  {
    id: "camp_velvet_03",
    clientId: "velvet",
    brandName: "Velvet Home",
    campaignTitle: "Aromatherapy Diffuser Seeding",
    niche: "Lifestyle",
    brandPaymentTerms: "Upfront",
    invoiceDate: "2026-07-20",
    estimatedClearDate: "2026-07-20",
    daysRemaining: 0,
    escrowStatus: "Disbursed",
    grossContractValue: 12000,
    totalCreatorAllocations: 5500,
    totalStaffAllocations: 1800,
    assignedStaff: [
      { uid: "usr_mgr_sarah_04", name: "Sarah Jenkins", role: "AgentManager", compensationAmount: 1800 }
    ],
    assignedCreators: [
      { creatorHandle: "@velvet_lifestyle", contractAmount: 5500 }
    ]
  }
];

export default function GlobalPayrollSchedule({
  currentUser,
  onDisburseFunds,
  initialCampaigns,
  mode = 'payroll'
}: GlobalPayrollScheduleProps) {
  const [activeCampaignsList, setActiveCampaignsList] = useState<GlobalPayrollCampaign[]>(initialCampaigns || DEFAULT_PAYROLL_CAMPAIGNS);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'agency-payroll-campaigns'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const campaignsData: GlobalPayrollCampaign[] = [];
      snapshot.forEach((doc) => {
        campaignsData.push({ id: doc.id, ...doc.data() } as GlobalPayrollCampaign);
      });
      if (campaignsData.length > 0) {
        setActiveCampaignsList(campaignsData);
      }
      setIsLoading(false);
    }, (err) => {
      console.error('Error fetching payroll campaigns:', err);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const isDirector = currentUser.role === 'Owner' || currentUser.role === 'Director' || (currentUser as any).role === 'director';
  const isAgentMgr = (currentUser as any).role === 'agentmgr' || (currentUser as any).role === 'agent';
  const isEscrowMode = mode === 'escrow';

  // State for Director-controlled payroll dates & payout registration
  const [nextPayDate, setNextPayDate] = useState(() => {
    try {
      return safeStorage.getItem('wl_agency_next_pay_date') || '2026-08-30';
    } catch {
      return '2026-08-30';
    }
  });
  const [isEditingPayDate, setIsEditingPayDate] = useState(false);
  const [payDateInput, setPayDateInput] = useState(nextPayDate);

  const [payoutMethod, setPayoutMethod] = useState<'paypal' | 'debit'>(() => {
    try {
      return (safeStorage.getItem('wl_staff_payout_type') as any) || 'paypal';
    } catch {
      return 'paypal';
    }
  });
  const [paypalEmail, setPaypalEmail] = useState(() => {
    try {
      return safeStorage.getItem('wl_staff_paypal_email') || currentUser?.email || 'manager@agency.com';
    } catch {
      return currentUser?.email || 'manager@agency.com';
    }
  });
  const [debitCardLast4, setDebitCardLast4] = useState(() => {
    try {
      return safeStorage.getItem('wl_staff_debit_last4') || '8842';
    } catch {
      return '8842';
    }
  });
  const [debitExpiry, setDebitExpiry] = useState('12/28');
  const [debitCvv, setDebitCvv] = useState('123');
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [isPayoutConfigured, setIsPayoutConfigured] = useState(() => {
    try {
      return safeStorage.getItem('wl_staff_payout_configured') === 'true';
    } catch {
      return false;
    }
  });

  // Load persisted agency payroll settings and user payout settings from Firestore
  useEffect(() => {
    async function loadRemoteSettings() {
      try {
        const settingsSnap = await getDoc(doc(db, 'agency-settings', 'payroll'));
        if (settingsSnap.exists()) {
          const data = settingsSnap.data();
          if (data?.nextPayDate) {
            setNextPayDate(data.nextPayDate);
            setPayDateInput(data.nextPayDate);
            safeStorage.setItem('wl_agency_next_pay_date', data.nextPayDate);
          }
        }
      } catch (err) {
        console.warn('[GlobalPayrollSchedule] Failed to load remote payroll settings:', err);
      }

      const uid = (currentUser as any)?.id || currentUser?.uid;
      if (uid) {
        try {
          const userSnap = await getDoc(doc(db, 'studio-users', uid));
          if (userSnap.exists()) {
            const uData = userSnap.data();
            if (uData?.payoutConfig) {
              const p = uData.payoutConfig;
              if (p.payoutMethod) {
                setPayoutMethod(p.payoutMethod);
                safeStorage.setItem('wl_staff_payout_type', p.payoutMethod);
              }
              if (p.paypalEmail) {
                setPaypalEmail(p.paypalEmail);
                safeStorage.setItem('wl_staff_paypal_email', p.paypalEmail);
              }
              if (p.debitCardLast4) {
                setDebitCardLast4(p.debitCardLast4);
                safeStorage.setItem('wl_staff_debit_last4', p.debitCardLast4);
              }
              if (p.isConfigured !== undefined) {
                setIsPayoutConfigured(p.isConfigured);
                safeStorage.setItem('wl_staff_payout_configured', String(p.isConfigured));
              }
            }
          }
        } catch (err) {
          console.warn('[GlobalPayrollSchedule] Failed to load remote payout config:', err);
        }
      }
    }
    loadRemoteSettings();
  }, [currentUser]);

  const handleSaveNextPayDate = async () => {
    setNextPayDate(payDateInput);
    safeStorage.setItem('wl_agency_next_pay_date', payDateInput);
    setIsEditingPayDate(false);

    try {
      await setDoc(doc(db, 'agency-settings', 'payroll'), {
        nextPayDate: payDateInput,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser.email || currentUser.name || 'Director'
      }, { merge: true });
    } catch (err) {
      console.warn('[GlobalPayrollSchedule] Failed to save next pay date to Firestore:', err);
    }

    setSuccessToast(`Official agency payroll date set to ${payDateInput}. All staff schedules updated.`);
    setTimeout(() => setSuccessToast(null), 5000);
  };

  const handleSavePayoutMethod = async () => {
    safeStorage.setItem('wl_staff_payout_type', payoutMethod);
    safeStorage.setItem('wl_staff_paypal_email', paypalEmail);
    const last4 = (debitCardLast4 || '8842').replace(/\D/g, '').slice(-4);
    safeStorage.setItem('wl_staff_debit_last4', last4);
    safeStorage.removeItem('wl_staff_debit_number');
    safeStorage.setItem('wl_staff_payout_configured', 'true');
    setIsPayoutConfigured(true);
    setShowPayoutModal(false);

    const uid = (currentUser as any)?.id || currentUser?.uid;
    if (uid) {
      try {
        await setDoc(doc(db, 'studio-users', uid), {
          payoutConfig: {
            payoutMethod,
            paypalEmail,
            debitCardLast4: last4,
            isConfigured: true,
            updatedAt: new Date().toISOString()
          }
        }, { merge: true });
      } catch (err) {
        console.warn('[GlobalPayrollSchedule] Failed to persist payout config to Firestore:', err);
      }
    }

    setSuccessToast(`Payroll payout method saved (${payoutMethod === 'paypal' ? 'PayPal: ' + paypalEmail : 'Agency Card ending in ' + last4}).`);
    setTimeout(() => setSuccessToast(null), 5000);
  };

  // Filter campaigns based on role: Managers see assigned staff campaigns, Creators see assigned creator campaigns in escrow mode
  const filteredCampaigns = useMemo(() => {
    if (isDirector) return activeCampaignsList;
    if (isEscrowMode) {
      return activeCampaignsList.map(camp => {
        const myCreator = camp.assignedCreators?.find(c =>
          c.creatorHandle.toLowerCase() === (currentUser as any)?.handle?.toLowerCase() ||
          c.creatorHandle.toLowerCase() === (currentUser as any)?.name?.toLowerCase()
        );
        return {
          ...camp,
          grossContractValue: 0,
          totalStaffAllocations: 0,
          totalCreatorAllocations: myCreator ? myCreator.contractAmount : camp.totalCreatorAllocations,
          assignedStaff: []
        };
      }).filter(Boolean) as GlobalPayrollCampaign[];
    }
    return activeCampaignsList.map(camp => {
      // Find current user in assigned staff
      const myStaffEntry = camp.assignedStaff.find(s => s.uid === currentUser.uid || s.name === currentUser.name);
      if (!myStaffEntry) {
        return {
          ...camp,
          grossContractValue: 0,
          totalCreatorAllocations: 0,
          totalStaffAllocations: camp.totalStaffAllocations,
          assignedCreators: []
        };
      }
      
      // Return a masked version for the manager
      return {
        ...camp,
        grossContractValue: 0, // Mask gross
        totalCreatorAllocations: 0, // Mask creator totals
        totalStaffAllocations: myStaffEntry.compensationAmount, // Only show their own
        assignedStaff: [myStaffEntry],
        assignedCreators: [] // Mask creators
      };
    }).filter(Boolean) as GlobalPayrollCampaign[];
  }, [activeCampaignsList, isDirector, isEscrowMode, currentUser]);

  const [campaigns, setCampaigns] = useState<GlobalPayrollCampaign[]>(filteredCampaigns);

  // Sync campaigns if filtered list changes
  React.useEffect(() => {
    setCampaigns(filteredCampaigns);
  }, [filteredCampaigns]);
  const [disbursingId, setDisbursingId] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleDisburse = async (campaign: GlobalPayrollCampaign) => {
    setDisbursingId(campaign.id);
    try {
      if (onDisburseFunds) {
        await onDisburseFunds(campaign.id);
      }

      try {
        await setDoc(doc(db, "agency-payroll-campaigns", campaign.id), {
          ...campaign,
          escrowStatus: 'Disbursed',
          disbursedAt: new Date().toISOString(),
          disbursedBy: currentUser.email || currentUser.name || 'Director'
        }, { merge: true });
      } catch (fErr) {
        console.warn('[GlobalPayrollSchedule] Failed to persist campaign disbursement:', fErr);
      }
      
      // Update local state to disbursed
      setCampaigns(prev => prev.map(c => c.id === campaign.id ? { ...c, escrowStatus: 'Disbursed' } : c));
      setSuccessToast(`Successfully released & disbursed funds for ${campaign.campaignTitle}! Staff and creator ledgers have been credited.`);
      setTimeout(() => setSuccessToast(null), 5000);
    } catch (err) {
      console.error('Failed to disburse funds:', err);
    } finally {
      setDisbursingId(null);
    }
  };

  return (
    <div className="bg-agency-navy border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl text-agency-textLight space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navyLight border border-agency-gold/30 px-3 py-0.5 rounded-full">
              {isDirector ? (isEscrowMode ? 'Director Master Escrow' : 'Director Master View') : (isEscrowMode ? 'Creator Escrow Clearance' : 'Manager Payroll Preview')}
            </span>
            <span className="text-xs text-emerald-400 font-mono bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
              {isDirector ? 'Executive Clearance Level 1' : (isEscrowMode ? 'Creator Escrow Access' : 'Manager Financial Access')}
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5">
            {isEscrowMode ? 'Escrow Settlement & Payout Schedule' : 'Global Payroll & Cash-Flow Schedule'}
          </h2>
          <p className="text-xs text-slate-400">
            {isEscrowMode
              ? 'Creator escrow settlement matrix: synchronizing brand milestone clearances, escrow deposits, and creator disbursements.'
              : 'Time-locked cash alignment matrix: synchronizing brand settlement terms, escrow milestones, and manager payroll releases.'}
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-300 bg-agency-navyLight px-4 py-2 rounded-xl border border-white/10">
          <Building2 className="w-4 h-4 text-agency-gold" />
          <span>{isEscrowMode ? 'Creator Escrow Vault Pipeline' : 'Active Inbound Escrow Pipeline'}</span>
        </div>
      </div>

      {/* Payroll Date & Payout Method Configuration Banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Next Scheduled Payroll Date Card */}
        <div className="bg-[#091322] border border-[#C9A46A]/30 rounded-2xl p-5 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-[#C9A46A] uppercase font-bold tracking-wider flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" /> {isEscrowMode ? 'Next Creator Disbursement Date' : 'Next Agency Payroll Date'}
            </span>
            {isDirector && (
              <button
                type="button"
                onClick={() => setIsEditingPayDate(!isEditingPayDate)}
                className="text-[11px] font-mono text-agency-gold hover:text-white underline cursor-pointer"
              >
                {isEditingPayDate ? 'Cancel' : (isEscrowMode ? 'Set Creator Pay Date (Director)' : 'Set Pay Date (Director)')}
              </button>
            )}
          </div>

          {isEditingPayDate ? (
            <div className="flex items-center gap-2 pt-1">
              <input
                type="date"
                value={payDateInput}
                onChange={(e) => setPayDateInput(e.target.value)}
                className="bg-[#060b13] border border-white/20 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:border-agency-gold outline-none"
              />
              <button
                type="button"
                onClick={handleSaveNextPayDate}
                className="bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-3.5 py-1.5 rounded-xl cursor-pointer"
              >
                Save Date
              </button>
            </div>
          ) : (
            <div>
              <p className="text-2xl font-serif font-bold text-white font-mono">
                {nextPayDate}
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                {isDirector 
                  ? (isEscrowMode ? 'All creator disbursements will disburse on this Director-scheduled date.' : 'All manager payouts will disburse on this Director-scheduled date.')
                  : (isEscrowMode ? 'Expected disbursement date set by Agency Director. Check your payout wallet below.' : 'Expected payday set by Agency Director. Check your payout wallet below.')}
              </p>
            </div>
          )}
        </div>

        {/* Staff Payout or Creator Direct Deposit Setup Card */}
        <div className="bg-[#091322] border border-white/10 hover:border-agency-gold/30 rounded-2xl p-5 space-y-3 shadow-lg transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-emerald-400 uppercase font-bold tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" /> {isEscrowMode ? 'Creator Direct Deposit Setup' : 'Staff Payout Direct Deposit Setup'}
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-agency-navy px-2 py-0.5 rounded border border-white/10">
              PayPal &amp; Agency Card Only
            </span>
          </div>

          <div className="flex items-center justify-between gap-3 pt-1">
            <div>
              {isPayoutConfigured ? (
                <p className="text-xs font-bold text-white font-mono flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  {payoutMethod === 'paypal' ? `PayPal: ${paypalEmail}` : `Agency Card: •••• ${debitCardLast4}`}
                </p>
              ) : (
                <p className="text-xs text-amber-300 font-mono italic">
                  No payout method saved yet
                </p>
              )}
              <p className="text-[11px] text-slate-400 mt-0.5">
                {isEscrowMode
                  ? 'Connect your PayPal account or Agency Debit Card for direct creator escrow payouts.'
                  : 'Connect your PayPal account or Agency Debit Card for direct manager payouts.'}
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowPayoutModal(true)}
              className="bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-4 py-2 rounded-xl shadow cursor-pointer shrink-0"
            >
              {isPayoutConfigured ? 'Edit Payout' : 'Set Up Payout'}
            </button>
          </div>
        </div>
      </div>

      {successToast && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs px-4 py-3 rounded-2xl flex items-center gap-2.5 shadow-lg">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Master Ledger Table */}
      <div className="overflow-x-auto rounded-2xl border border-white/10 bg-agency-navyLight">
        <table className="w-full text-left text-xs">
          <thead className="bg-agency-navy text-agency-gold font-mono uppercase text-[10px] tracking-wider border-b border-white/10">
            <tr>
              <th className="py-4 px-4">Campaign &amp; Niche</th>
              <th className="py-4 px-4">Brand Payment Terms</th>
              <th className="py-4 px-4">Cash Flow Timeline</th>
              <th className="py-4 px-4">Escrow Tracking Status</th>
              <th className="py-4 px-4 text-right">Executive Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 font-sans">
            {campaigns.map((camp) => {
              const isClearing = disbursingId === camp.id;
              const isCleared = camp.escrowStatus === 'Cleared in Escrow';
              const isAwaiting = camp.escrowStatus === 'Awaiting Brand Deposit';
              const isDisbursed = camp.escrowStatus === 'Disbursed';

              return (
                <tr key={camp.id} className="hover:bg-white/[0.02] transition-colors">
                  {/* 1. Campaign & Niche */}
                  <td className="py-4.5 px-4 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{camp.campaignTitle}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-agency-navy border border-white/10 text-slate-300">
                        {camp.niche}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 font-mono">
                      Client: <strong className="text-agency-gold">{camp.brandName}</strong> 
                      {isDirector && (
                        <> &bull; Gross Contract: <strong className="text-slate-200">${camp.grossContractValue.toLocaleString()}</strong></>
                      )}
                      {!isDirector && (
                        <> &bull; {isEscrowMode ? 'Creator Payout' : 'Staff Payout'}: <strong className="text-emerald-400">${camp.totalStaffAllocations.toLocaleString()}</strong></>
                      )}
                    </p>
                  </td>

                  {/* 2. Brand Payment Terms */}
                  <td className="py-4.5 px-4 font-mono">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold bg-agency-navy border border-agency-gold/30 text-agency-gold">
                      {camp.brandPaymentTerms}
                    </span>
                    <span className="block text-[10px] text-slate-400 mt-1">
                      Invoiced: {camp.invoiceDate}
                    </span>
                  </td>

                  {/* 3. Cash Flow Timeline */}
                  <td className="py-4.5 px-4 font-mono">
                    <div className="flex items-center gap-1.5 text-xs text-slate-300">
                      <Clock className="w-3.5 h-3.5 text-agency-gold" />
                      <span>
                        {isDisbursed
                          ? 'Settled'
                          : camp.daysRemaining > 0
                          ? `${camp.daysRemaining} days remaining`
                          : 'Settlement Due'}
                      </span>
                    </div>
                    <span className="block text-[10px] text-slate-400 mt-1">
                      Est. Clear: {camp.estimatedClearDate}
                    </span>
                  </td>

                  {/* 4. Escrow Tracking Status */}
                  <td className="py-4.5 px-4">
                    {isAwaiting && (
                      <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-amber-400 bg-amber-950/60 border border-amber-500/40 px-3 py-1 rounded-xl shadow-sm">
                        <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                        Awaiting Brand Deposit
                      </span>
                    )}

                    {isCleared && (
                      <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-300 bg-emerald-950/70 border border-emerald-400/50 px-3 py-1 rounded-xl shadow-md animate-pulse">
                        <Sparkles className="w-3.5 h-3.5 text-agency-gold" />
                        Ready to Disburse
                      </span>
                    )}

                    {isDisbursed && (
                      <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-slate-400 bg-agency-navy border border-white/10 px-3 py-1 rounded-xl">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        {isEscrowMode ? 'Disbursed to Creator' : 'Disbursed to Managers & Talent'}
                      </span>
                    )}
                  </td>

                  {/* 5. Critical Action Trigger Button */}
                  <td className="py-4.5 px-4 text-right">
                    {isCleared && isDirector ? (
                      <button
                        type="button"
                        onClick={() => handleDisburse(camp)}
                        disabled={isClearing}
                        className="inline-flex items-center gap-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg transition-all cursor-pointer disabled:opacity-50"
                      >
                        <DollarSign className="w-4 h-4" />
                        <span>{isClearing ? 'Disbursing...' : (isEscrowMode ? 'Release & Disburse Creator Funds' : 'Release & Disburse Manager Funds')}</span>
                      </button>
                    ) : isDisbursed ? (
                      <span className="text-[11px] font-mono text-slate-400 italic">
                        Ledgers Credited
                      </span>
                    ) : isCleared && !isDirector ? (
                      <span className="text-[11px] font-mono text-emerald-400 font-bold uppercase">
                        Payment Pending
                      </span>
                    ) : (
                      <span className="text-[11px] font-mono text-amber-400/80">
                        Time-Locked (Net Terms)
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* PayPal / Agency Debit Card Setup Modal */}
      {showPayoutModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#0b1424] border border-agency-gold/40 rounded-3xl p-6 md:p-8 max-w-lg w-full space-y-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="text-lg font-bold text-white font-serif">{isEscrowMode ? 'Setup Creator Payout Wallet' : 'Setup Staff Payout Wallet'}</h3>
                <p className="text-xs text-slate-400">Configure your official PayPal account or Agency Debit Card for direct payouts.</p>
              </div>

              <button
                type="button"
                onClick={() => setShowPayoutModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Method Selection Tabs */}
            <div className="grid grid-cols-2 gap-2 bg-[#060b13] p-1.5 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => setPayoutMethod('paypal')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
                  payoutMethod === 'paypal'
                    ? 'bg-agency-gold text-agency-navy shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>PayPal Account</span>
              </button>

              <button
                type="button"
                onClick={() => setPayoutMethod('debit')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
                  payoutMethod === 'debit'
                    ? 'bg-agency-gold text-agency-navy shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>Agency Debit Card</span>
              </button>
            </div>

            {/* Inputs */}
            {payoutMethod === 'paypal' ? (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-2xl text-[11px] text-blue-200">
                  ⚡ Official Agency Payroll Option: Instant 0% fee deposit directly to your verified PayPal email on scheduled paydays.
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">PayPal Account Email</label>
                  <input
                    type="email"
                    value={paypalEmail}
                    onChange={(e) => setPaypalEmail(e.target.value)}
                    className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:border-agency-gold outline-none"
                    placeholder="yourname@agency.com"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl text-[11px] text-emerald-200">
                  💳 Official Agency Debit Card Option: Instant corporate card ledger disbursement on scheduled paydays.
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Agency Debit Card (Last 4 Digits Only)</label>
                  <input
                    type="text"
                    maxLength={4}
                    value={debitCardLast4}
                    onChange={(e) => setDebitCardLast4(e.target.value)}
                    className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:border-agency-gold outline-none font-mono"
                    placeholder="8842"
                  />
                  <p className="text-[10px] text-slate-400">For security compliance, full card numbers are never stored on client devices.</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">Expiration Date</label>
                    <input
                      type="text"
                      value={debitExpiry}
                      onChange={(e) => setDebitExpiry(e.target.value)}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:border-agency-gold outline-none font-mono"
                      placeholder="MM/YY"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono text-slate-300 font-bold uppercase">CVV / Security Code</label>
                    <input
                      type="text"
                      value={debitCvv}
                      onChange={(e) => setDebitCvv(e.target.value)}
                      className="w-full bg-[#060b13] border border-white/15 rounded-xl px-3.5 py-2.5 text-white text-xs focus:border-agency-gold outline-none font-mono"
                      placeholder="123"
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setShowPayoutModal(false)}
                className="px-4 py-2.5 rounded-xl border border-white/15 text-slate-300 hover:text-white text-xs font-mono cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSavePayoutMethod}
                className="px-5 py-2.5 rounded-xl bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs font-mono shadow-lg transition cursor-pointer flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Save Payroll Payout Wallet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

