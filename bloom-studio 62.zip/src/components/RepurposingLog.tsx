import React, { useState } from 'react';
import { Layers, Plus, TrendingUp, RefreshCw, CheckCircle, Video, Play, Share2, ClipboardList, AlertTriangle, XCircle, FileText } from 'lucide-react';
import { Creator, Deal } from '../types';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, where, doc, setDoc } from 'firebase/firestore';

interface RepurposingTask {
  id: string;
  creator: string;
  dealBrand: string;
  sourcePlatform: string;
  sourceViews: number;
  secondaryPlatform: string;
  status: 'Draft' | 'Scheduled' | 'Live';
  repurposedViews: number;
  multiplierRatio: string;
  assignedEditor: string;
  completedDate?: string;
}

interface RejectedLogEntry {
  id: string;
  creator: string;
  brand: string;
  platform: string;
  contentType: string;
  mediaUrl?: string;
  rejectedBy: string;
  reason: string;
  rejectedAt: string;
}

const DEFAULT_REPURPOSING_TASKS: RepurposingTask[] = [
  {
    id: "rep_seed_1",
    creator: "@elenarostova",
    dealBrand: "Alo Yoga",
    sourcePlatform: "Instagram Reels",
    sourceViews: 420000,
    secondaryPlatform: "TikTok",
    status: "Live",
    repurposedViews: 185000,
    multiplierRatio: "1.44x",
    assignedEditor: "Jordan K.",
    completedDate: "2026-07-20"
  },
  {
    id: "rep_seed_2",
    creator: "@sofia_ugc",
    dealBrand: "Cosmetics Box",
    sourcePlatform: "TikTok",
    sourceViews: 280000,
    secondaryPlatform: "YouTube Shorts",
    status: "Scheduled",
    repurposedViews: 0,
    multiplierRatio: "Pending",
    assignedEditor: "Unassigned"
  }
];

interface RepurposingLogProps {
  creators: Creator[];
  deals: Deal[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentUser?: any;
  currentRole?: string;
  logs?: RejectedLogEntry[];
  setLogs?: React.Dispatch<React.SetStateAction<RejectedLogEntry[]>>;
}

export default function RepurposingLog({ 
  creators, 
  deals, 
  onAddActivityLog, 
  triggerNotification, 
  currentUser, 
  currentRole,
  logs,
  setLogs
}: RepurposingLogProps) {
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const mgrName = currentUser?.name || 'Marcus Cole';
  const myCreators = (creators || []).filter(c => 
    c.assignedAgent?.toLowerCase() === mgrName.toLowerCase() &&
    c.name.toLowerCase() !== mgrName.toLowerCase() &&
    c.handle.toLowerCase() !== (currentUser?.handle || '').toLowerCase()
  );
  const myHandles = myCreators.map(c => c.handle.toLowerCase());

  const [activeTab, setActiveTab] = useState<'repurposed' | 'rejected'>('repurposed');

  const [rejectedLogs, setRejectedLogs] = useState<RejectedLogEntry[]>(logs || []);

  React.useEffect(() => {
    if (logs) setRejectedLogs(logs);
  }, [logs]);

  const [tasks, setTasks] = useState<RepurposingTask[]>([]);

  React.useEffect(() => {
    let unsub = () => {};
    if (db) {
      const isPlatformOwner = currentUser?.isPlatformOwner || false;
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
      const myHandle = currentUser?.handle || '';
      const myFormattedHandle = myHandle.startsWith('@') ? myHandle : `@${myHandle}`;
      const isCreator = (currentRole || '').toLowerCase() === 'creator';

      let q: any = collection(db, 'studio-repurposing-logs');

      if (!isPlatformOwner) {
        if (isCreator) {
          q = query(
            collection(db, 'studio-repurposing-logs'),
            where('creatorHandle', '==', myFormattedHandle)
          );
        } else {
          q = query(
            collection(db, 'studio-repurposing-logs'),
            where('tenantId', '==', userPod)
          );
        }
      }

      unsub = onSnapshot(q, (snapshot) => {
        const loadedTasks: RepurposingTask[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          loadedTasks.push({
            id: docSnap.id,
            creator: data.creator || '',
            dealBrand: data.dealBrand || data.brand || '',
            sourcePlatform: data.sourcePlatform || '',
            sourceViews: data.sourceViews || 0,
            secondaryPlatform: data.secondaryPlatform || '',
            status: data.status || 'Draft',
            repurposedViews: data.repurposedViews || 0,
            multiplierRatio: data.multiplierRatio || 'Pending',
            assignedEditor: data.assignedEditor || 'Unassigned',
            completedDate: data.completedDate
          });
        });
        
        if (loadedTasks.length > 0) {
          setTasks(loadedTasks);
        } else {
          // Seed default repurposing tasks to Firestore so it's fully persistent and doesn't revert to empty
          const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
          DEFAULT_REPURPOSING_TASKS.forEach(async (task) => {
            const formattedHandle = task.creator.startsWith('@') ? task.creator : `@${task.creator}`;
            const cleanTask = {
              ...task,
              creatorId: currentUser?.uid || 'user_guest',
              creatorHandle: formattedHandle,
              tenantId: userPod,
              subagency: userPod,
              pod: userPod
            };
            try {
              await setDoc(doc(db, 'studio-repurposing-logs', task.id), cleanTask);
            } catch (err) {
              console.warn("Seeding repurposing task failed:", err);
            }
          });
          setTasks(DEFAULT_REPURPOSING_TASKS);
        }
      }, (error) => {
        console.warn("Firestore studio-repurposing-logs listener warning:", error);
      });
    }
    return () => unsub();
  }, [currentUser, currentRole]);

  React.useEffect(() => {
    // Local storage as secondary fallback only for rejected logs
    try {
      localStorage.setItem('wl_rejected_content_log', JSON.stringify(rejectedLogs));
    } catch (e) {}
    if (setLogs && JSON.stringify(logs) !== JSON.stringify(rejectedLogs)) {
      setLogs(rejectedLogs);
    }
  }, [rejectedLogs, logs, setLogs]);

  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [newCreator, setNewCreator] = useState('');
  const [newBrand, setNewBrand] = useState('');
  const [newSourcePlatform, setNewSourcePlatform] = useState('TikTok');
  const [newSecondaryPlatform, setNewSecondaryPlatform] = useState('Instagram Reels');
  const [newSourceViews, setNewSourceViews] = useState('');
  const [newEditor, setNewEditor] = useState('');
  const [newStatus, setNewStatus] = useState<'Draft' | 'Scheduled' | 'Live'>('Draft');

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCreator || !newBrand) {
      alert("Creator and Brand are required!");
      return;
    }

    const srcViews = parseInt(newSourceViews) || 10000;
    const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';

    const selectedCreatorObj = creators.find(c => c.handle === newCreator || c.handle.toLowerCase() === newCreator.toLowerCase());
    const creatorId = selectedCreatorObj?.id || (selectedCreatorObj as any)?.uid || currentUser?.uid || currentUser?.id || '';
    const creatorHandle = selectedCreatorObj?.handle || newCreator;
    const formattedHandle = creatorHandle.startsWith('@') ? creatorHandle : `@${creatorHandle}`;

    const taskId = 'rep_' + Date.now();
    const newTask: RepurposingTask & { creatorId: string; creatorHandle: string; tenantId: string; subagency: string; pod: string } = {
      id: taskId,
      creator: newCreator,
      creatorId: creatorId,
      creatorHandle: formattedHandle,
      tenantId: userPod,
      subagency: userPod,
      pod: userPod,
      dealBrand: newBrand,
      sourcePlatform: newSourcePlatform,
      sourceViews: srcViews,
      secondaryPlatform: newSecondaryPlatform,
      status: newStatus,
      repurposedViews: 0,
      multiplierRatio: 'Pending',
      assignedEditor: newEditor || 'Unassigned',
      completedDate: newStatus === 'Live' ? new Date().toISOString().slice(0, 10) : newStatus === 'Scheduled' ? 'Scheduled 2026-07-22' : undefined
    };

    setTasks(prev => [newTask, ...prev]);
    setShowAddModal(false);

    // reset
    setNewCreator('');
    setNewBrand('');
    setNewSourceViews('');
    setNewEditor('');

    try {
      if (db) {
        await setDoc(doc(db, 'studio-repurposing-logs', taskId), newTask);
      }
    } catch (err) {
      console.error("Error saving repurposing task to Firestore:", err);
    }

    triggerNotification(
      'Repurposing Job Logged',
      `Content slice job logged for ${newTask.creator} x ${newTask.dealBrand} to ${newTask.secondaryPlatform}.`,
      'success'
    );
    onAddActivityLog(currentUser?.name || 'User', currentRole || 'none', `Logged content repurposing task: ${newTask.creator} to ${newTask.secondaryPlatform}`);
  };

  const totalRepurposedViews = tasks.reduce((sum, t) => sum + t.repurposedViews, 0);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden">
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider">
              Asset Slicing &amp; Distribution
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              Content Repurposing Log
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
              Track conversion pathways of flagship videos into high-frequency vertical crops, Pinterest pins, and multi-platform Reels.
            </p>
          </div>
          {activeTab === 'repurposed' && (
            <button
              onClick={() => setShowAddModal(true)}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors self-start sm:self-center shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Create Slicing Job
            </button>
          )}
        </div>
      </div>

      {/* Explanation Banner: What is Slicing? */}
      <div className="bg-[#0D1830] border border-cyan-500/30 rounded-2xl p-4 flex items-start gap-3.5">
        <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-lg shrink-0 mt-0.5">
          <Layers className="w-5 h-5" />
        </div>
        <div className="space-y-1">
          <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider">
            What is "Slicing" in the Agency Workflow?
          </h4>
          <p className="text-xs text-slate-300 leading-relaxed">
            <strong>Slicing does not automatically cut, trim, or process video files.</strong> Instead, it is an agency tracking ledger that records when a primary piece of content (such as a long-form YouTube video or Instagram Reel) is repurposed by an editor or creator into multiple short-form vertical crops, clips, or cross-platform posts. This log tracks source reach vs. leveraged reach and calculates multiplier ROI across channels.
          </p>
        </div>
      </div>

      {/* Tab Selector: Separate Repurposed Content vs Rejected Content */}
      <div className="flex border-b border-white/10 gap-6">
        <button
          onClick={() => setActiveTab('repurposed')}
          className={`pb-3 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'repurposed'
              ? 'border-[#C9A46A] text-white'
              : 'border-transparent text-[#7C8AA8] hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4" /> Repurposed Content Log (Slicing Workflow)
          <span className="bg-[#111E33] px-2 py-0.5 rounded-full text-[10px]">{tasks.length}</span>
        </button>
        <button
          onClick={() => setActiveTab('rejected')}
          className={`pb-3 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'rejected'
              ? 'border-rose-400 text-white'
              : 'border-transparent text-[#7C8AA8] hover:text-white'
          }`}
        >
          <AlertTriangle className="w-4 h-4 text-rose-400" /> Rejected Content Log
          <span className="bg-rose-950/60 border border-rose-500/30 text-rose-300 px-2 py-0.5 rounded-full text-[10px]">{rejectedLogs.length}</span>
        </button>
      </div>

      {activeTab === 'repurposed' ? (
        <>
          {/* Summary KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-[#C9A46A]/10 text-[#C9A46A] rounded-xl">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase block">Total Repurposed Paths</span>
                <span className="text-xl font-bold text-white">{tasks.length} Active jobs</span>
              </div>
            </div>

            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase block">Added Multiplier Views</span>
                <span className="text-xl font-bold text-emerald-400">+{totalRepurposedViews.toLocaleString()} views</span>
              </div>
            </div>

            <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <ClipboardList className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-[#7C8AA8] uppercase block">Asset Leverage Gain</span>
                <span className="text-xl font-bold text-cyan-400">1.7x Aggregate ROI</span>
              </div>
            </div>
          </div>

          {/* Table Log Ledger */}
          <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-white/5 bg-[#111E33]/50 flex justify-between items-center">
              <h3 className="text-xs font-semibold text-[#7C8AA8] uppercase tracking-wider">Repurposed Deliverables Ledger</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                    <th className="p-4">Creator / Brand</th>
                    <th className="p-4">Source Channel</th>
                    <th className="p-4">Target Channel</th>
                    <th className="p-4">Source Reach</th>
                    <th className="p-4">Leveraged Reach</th>
                    <th className="p-4">Multiplier Boost</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Assigned Editor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {tasks.filter(task => !isAgentMgr || myHandles.includes(task.creator.toLowerCase())).map(task => (
                    <tr key={task.id} className="hover:bg-[#111E33]/30 transition-colors">
                      <td className="p-4">
                        <div className="font-semibold text-white">{task.creator}</div>
                        <div className="text-[10px] text-[#7C8AA8] mt-0.5">{task.dealBrand}</div>
                      </td>
                      <td className="p-4">
                        <span className="font-medium text-slate-300">{task.sourcePlatform}</span>
                      </td>
                      <td className="p-4 font-semibold text-[#C9A46A]">{task.secondaryPlatform}</td>
                      <td className="p-4 font-mono text-[#B8C0D4]">{task.sourceViews.toLocaleString()} views</td>
                      <td className="p-4 font-mono text-white">
                        {task.status === 'Live' ? `${task.repurposedViews.toLocaleString()} views` : '—'}
                      </td>
                      <td className="p-4 font-bold text-emerald-400">{task.multiplierRatio}</td>
                      <td className="p-4">
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          task.status === 'Live' ? 'bg-emerald-950 border border-emerald-500/30 text-emerald-400' :
                          task.status === 'Scheduled' ? 'bg-cyan-950 border border-cyan-500/30 text-cyan-400' :
                          'bg-amber-950 border border-amber-500/30 text-amber-400'
                        }`}>
                          {task.status}
                        </span>
                      </td>
                      <td className="p-4 text-slate-300">{task.assignedEditor}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* Rejected Content Log View (Separate from Repurposed Content) */
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-white/5 bg-[#111E33]/50 flex justify-between items-center">
            <div>
              <h3 className="text-xs font-semibold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" /> Rejected Content Audit Log
              </h3>
              <p className="text-[11px] text-[#7C8AA8] mt-0.5">
                Separate ledger displaying submissions rejected during Content Review along with director feedback notes.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/5 bg-[#111E33] text-[#7C8AA8] uppercase font-mono tracking-wider">
                  <th className="p-4">Creator / Brand</th>
                  <th className="p-4">Platform &amp; Format</th>
                  <th className="p-4">Rejection Reason &amp; Feedback</th>
                  <th className="p-4">Rejected By</th>
                  <th className="p-4">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {rejectedLogs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-[#7C8AA8] italic">
                      No rejected content submissions recorded yet.
                    </td>
                  </tr>
                ) : (
                  rejectedLogs.map(item => (
                    <tr key={item.id} className="hover:bg-[#111E33]/30 transition-colors">
                      <td className="p-4">
                        <div className="font-semibold text-white">{item.creator}</div>
                        <div className="text-[10px] text-[#7C8AA8] mt-0.5">{item.brand}</div>
                      </td>
                      <td className="p-4">
                        <span className="font-medium text-slate-300">{item.platform}</span>
                        <div className="text-[10px] text-[#7C8AA8]">{item.contentType}</div>
                      </td>
                      <td className="p-4 max-w-sm">
                        <div className="bg-rose-950/30 border border-rose-500/20 text-rose-200 px-3 py-2 rounded-lg text-xs leading-relaxed font-mono">
                          {item.reason || 'No reason provided.'}
                        </div>
                      </td>
                      <td className="p-4 text-slate-300">{item.rejectedBy}</td>
                      <td className="p-4 font-mono text-[#7C8AA8]">{item.rejectedAt}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Slicing Job Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-[#060B15]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#rgba(201,164,106,0.24)] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="h-14 flex items-center justify-between px-6 border-b border-[#rgba(201,164,106,0.14)] bg-[#111E33]">
              <h3 className="font-serif font-medium text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#C9A46A]" /> Log Content Repurposing Slicing Job
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#7C8AA8] hover:text-white">&times;</button>
            </div>

            <form onSubmit={handleCreateTask} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Creator</label>
                  <select
                    value={newCreator}
                    onChange={e => setNewCreator(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                  >
                    <option value="">Select Creator</option>
                    {creators.filter(c => !isAgentMgr || myHandles.includes(c.handle.toLowerCase())).map(c => (
                      <option key={c.id} value={c.handle}>{c.name} ({c.handle})</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Brand Campaign</label>
                  <select
                    value={newBrand}
                    onChange={e => setNewBrand(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                  >
                    <option value="">Select Brand</option>
                    {deals.filter(d => !isAgentMgr || myHandles.includes(d.creator.toLowerCase())).map(d => (
                      <option key={d.id} value={d.brand}>{d.brand}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Original Platform</label>
                  <select
                    value={newSourcePlatform}
                    onChange={e => setNewSourcePlatform(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                  >
                    <option value="TikTok">TikTok Video</option>
                    <option value="Instagram Reels">Instagram Reels</option>
                    <option value="YouTube Longform">YouTube Longform</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Target Format</label>
                  <select
                    value={newSecondaryPlatform}
                    onChange={e => setNewSecondaryPlatform(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                  >
                    <option value="Instagram Reels">Instagram Reels</option>
                    <option value="YouTube Shorts">YouTube Shorts</option>
                    <option value="TikTok Sparks">TikTok Spark Ads</option>
                    <option value="Pinterest Pins">Pinterest Pin Board</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Original Views</label>
                  <input
                    type="number"
                    placeholder="e.g. 50000"
                    value={newSourceViews}
                    onChange={e => setNewSourceViews(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Editor assigned</label>
                  <input
                    type="text"
                    placeholder="e.g. Lead Editor"
                    value={newEditor}
                    onChange={e => setNewEditor(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-[#7C8AA8] uppercase">Current Repurposing status</label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value as any)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                >
                  <option value="Draft">Draft (Briefing Editor)</option>
                  <option value="Scheduled">Scheduled for Post-edit Publish</option>
                  <option value="Live">Live (Already posted)</option>
                </select>
              </div>

              <div className="pt-4 flex justify-end gap-2 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="bg-transparent hover:bg-white/5 border border-white/10 px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-5 py-2.5 rounded-xl text-xs font-semibold"
                >
                  Log Repurpose Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
