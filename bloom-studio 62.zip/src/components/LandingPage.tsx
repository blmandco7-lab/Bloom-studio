import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, Sparkles, ShieldCheck, Mail, ArrowRight, UserCheck, HelpCircle, Briefcase, Zap, LogIn, CheckCircle2, ChevronRight, X, Phone, FileText, User, Building2 } from 'lucide-react';
import { signInWithGoogle } from '../lib/firebase';
import { HiringSettings } from '../types';

interface LandingPageProps {
  agencyName: string;
  legalEntityName: string;
  primaryBrandColor: string;
  cardBgColor: string;
  mainDashboardBg: string;
  textMainColor: string;
  textMutedColor: string;
  hiringSettings?: HiringSettings;
  vslVideoUrl?: string;
  onLogin?: (email: string, role: string) => void;
  onOpenBrandPartnerModal?: () => void;
  onBrandSubmit: (companyName: string, email: string, budget: number, briefing: string) => void;
  onCreatorSubmit: (name: string, handle: string, email: string, bio: string) => void;
  onAgentSubmit?: (name: string, email: string, phone: string, role: string, experience: string, notes: string) => void;
  onStartAgencySignup?: () => void;
}

export default function LandingPage({
  agencyName,
  legalEntityName,
  primaryBrandColor,
  cardBgColor,
  mainDashboardBg,
  textMainColor,
  textMutedColor,
  hiringSettings,
  vslVideoUrl,
  onLogin,
  onOpenBrandPartnerModal,
  onBrandSubmit,
  onCreatorSubmit,
  onAgentSubmit,
  onStartAgencySignup
}: LandingPageProps) {
  const [showModal, setShowModal] = useState(false);
  const [showCareersModal, setShowCareersModal] = useState(false);
  const [authError, setAuthError] = useState('');
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  
  // Unified Portal State
  const [activePortalTab, setActivePortalTab] = useState<'director' | 'staff' | 'creator' | 'subagency' | 'brand'>('director');
  const [selectedStaffRole, setSelectedStaffRole] = useState<'agentmgr' | 'coordinator' | 'agent'>('agentmgr');
  const [creatorInput, setCreatorInput] = useState('@elena');
  const [subagencyInput, setSubagencyInput] = useState('pod_west_coast');

  // Tab for registration section: 'creator' | 'brand'
  const [registrationMode, setRegistrationMode] = useState<'creator' | 'brand'>('creator');
  
  // Brand Form State
  const [brandCompany, setBrandCompany] = useState('');
  const [brandEmail, setBrandEmail] = useState('');
  const [brandBudget, setBrandBudget] = useState('');
  const [brandBrief, setBrandBrief] = useState('');
  const [brandSubmittedSuccess, setBrandSubmittedSuccess] = useState(false);

  // Creator Form State
  const [creatorName, setCreatorName] = useState('');
  const [creatorHandle, setCreatorHandle] = useState('');
  const [creatorEmail, setCreatorEmail] = useState('');
  const [creatorBio, setCreatorBio] = useState('');
  const [creatorSubmittedSuccess, setCreatorSubmittedSuccess] = useState(false);

  // Agent / Manager Form State (Careers)
  const [agentName, setAgentName] = useState('');
  const [agentEmail, setAgentEmail] = useState('');
  const [agentPhone, setAgentPhone] = useState('');
  const [agentRole, setAgentRole] = useState('Agent Manager (Agency & Roster Lead)');
  const [agentExperience, setAgentExperience] = useState('3-5 years talent management');
  const [agentNotes, setAgentNotes] = useState('');
  const [agentSubmittedSuccess, setAgentSubmittedSuccess] = useState(false);

  const [inviteCodeInput, setInviteCodeInput] = useState(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const urlInvite = urlParams.get('invite');
      if (urlInvite) return urlInvite.toUpperCase();
      return localStorage.getItem('wl_pending_invite_code') || '';
    }
    return '';
  });

  const matchedInviteCode = React.useMemo(() => {
    if (!inviteCodeInput.trim()) return null;
    try {
      const savedCodes = JSON.parse(localStorage.getItem('wl_access_codes') || '[]');
      return savedCodes.find((c: any) => c.code?.toUpperCase() === inviteCodeInput.trim().toUpperCase() && c.status === 'Active') || null;
    } catch (e) {
      return null;
    }
  }, [inviteCodeInput]);

  const handleDirectEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const email = loginEmail.trim().toLowerCase();
    if (!email) return;

    let role = "creator";
    if (matchedInviteCode?.role) {
      role = matchedInviteCode.role;
    } else if (email.includes("director") || email.includes("admin") || email.includes("owner")) {
      role = "director";
    } else if (email.includes("manager") || email.includes("lead")) {
      role = "agentmgr";
    } else if (email.includes("agent")) {
      role = "agent";
    } else if (email.includes("brand") || email.includes("partner") || email.includes("sephora")) {
      role = "brand";
    }

    if (onLogin) {
      onLogin(email, role);
      setShowModal(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setAuthError('');
    setIsSigningIn(true);
    if (typeof window !== 'undefined') {
      if (inviteCodeInput.trim()) {
        localStorage.setItem('wl_pending_invite_code', inviteCodeInput.trim().toUpperCase());
      } else {
        localStorage.removeItem('wl_pending_invite_code');
      }
    }
    try {
      const user = await signInWithGoogle();
      if (user) {
        // Successful Google sign-in.
        // Close modal and let onAuthStateChanged in App.tsx securely resolve
        // the user's verified Firestore profile and assigned role.
        setShowModal(false);
      }
    } catch (err: any) {
      if (err?.code === 'auth/popup-closed-by-user' || err?.message?.includes('popup-closed-by-user') || err?.code === 'auth/cancelled-popup-request') {
        console.info('[Auth] Google sign-in window was closed by user.');
        setAuthError("Google sign-in window was closed. You can try again or use the Platform Owner or Workspace Email options below.");
        return;
      }
      console.error("Google sign-in error:", err);
      if (err?.code === 'auth/unauthorized-domain' || err?.message?.includes('unauthorized-domain')) {
        setAuthError(
          "Notice: The current preview domain (" + (typeof window !== 'undefined' ? window.location.hostname : 'preview') + 
          ") is not authorized in Firebase Auth. Use the Instant Workspace Access options below to enter immediately."
        );
      } else if (err?.code === 'auth/popup-blocked') {
        setAuthError("Popup was blocked by your browser. You can use Instant Workspace Access below or allow popups.");
      } else {
        setAuthError(err?.message || "Google sign-in was cancelled or failed. Please try again.");
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleBrandFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandCompany || !brandEmail || !brandBudget || !brandBrief) return;
    onBrandSubmit(brandCompany, brandEmail, Number(brandBudget), brandBrief);
    setBrandSubmittedSuccess(true);
  };

  const handleCreatorFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!creatorName || !creatorHandle || !creatorEmail || !creatorBio) return;
    onCreatorSubmit(creatorName, creatorHandle, creatorEmail, creatorBio);
    setCreatorSubmittedSuccess(true);
  };

  const handleCareerFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agentName || !agentEmail || !agentPhone) return;
    if (onAgentSubmit) {
      onAgentSubmit(agentName, agentEmail, agentPhone, agentRole, agentExperience, agentNotes);
    }
    setAgentSubmittedSuccess(true);
  };

  const openCareersForRole = (roleTitle: string) => {
    setAgentRole(roleTitle);
    setShowCareersModal(true);
  };

  return (
    <div id="landing-page" className="min-h-screen bg-[#ffffff] text-slate-900 font-sans antialiased flex flex-col items-center w-full overflow-y-auto">
      
      {/* TOP HEADER NAVIGATION BAR */}
      <header className="w-full max-w-5xl flex items-center justify-between px-6 py-6 border-b border-slate-100">
        <div className="flex flex-col">
          <span className="text-2xl font-bold tracking-wider font-serif text-[#0a1d37]">
            {agencyName.toUpperCase()}
          </span>
          <span className="text-[10px] text-[#D4AF37] tracking-[0.2em] font-mono uppercase mt-1 font-bold">
            {legalEntityName.toUpperCase()}
          </span>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            type="button"
            onClick={() => setShowCareersModal(true)}
            className="text-xs font-semibold text-slate-600 hover:text-[#0a1d37] transition-colors cursor-pointer hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-100"
          >
            <Briefcase className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Careers</span>
          </button>

          {onOpenBrandPartnerModal && (
            <button 
              type="button"
              id="landing-brand-partner-btn"
              onClick={onOpenBrandPartnerModal}
              className="border border-cyan-500/40 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900/50 hover:text-white transition-all font-semibold text-xs px-4 py-2.5 rounded-md cursor-pointer flex items-center gap-1.5 shadow-sm"
            >
              <Building2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Brand Partner Access</span>
            </button>
          )}

          <button 
            onClick={() => setShowModal(true)}
            className="border-2 border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0a1d37] transition-all font-bold text-xs uppercase tracking-widest px-6 py-2.5 rounded-md cursor-pointer"
          >
            Portal Login
          </button>
        </div>
      </header>
      {/* VSL HERO SECTION */}
      <section className="relative w-full py-20 lg:py-32 flex flex-col items-center justify-center overflow-hidden bg-slate-900 shadow-inner">
        <img 
          src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1200&q=80"
          alt="Bloom Studio Corporate Workspace Asset"
          className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-luminosity"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#ffffff] via-transparent to-transparent"></div>
        
        <div className="relative z-10 w-full max-w-5xl px-6 flex flex-col md:flex-row items-center gap-12">
          {/* Saying / Headline */}
          <div className="flex-1 text-center md:text-left space-y-4">
            <div className="inline-block px-3 py-1 bg-[#D4AF37]/20 border border-[#D4AF37]/40 rounded-full text-[10px] text-[#D4AF37] font-mono tracking-widest uppercase mb-2">
              Bloom Studio Exclusives
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-white drop-shadow-sm font-serif leading-tight">
              Scaling Elite Creators to <span className="text-[#D4AF37] italic">New Heights.</span>
            </h1>
            <p className="text-slate-300 text-sm md:text-base font-medium max-w-xl leading-relaxed drop-shadow mx-auto md:mx-0">
              We turn viral moments into sustainable empires. Watch our exclusive briefing to discover how our proprietary management infrastructure drives multi-platform growth.
            </p>
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
              <button 
                onClick={() => setShowModal(true)}
                className="bg-[#D4AF37] text-[#0a1d37] hover:bg-[#ffffff] transition-all font-bold text-sm uppercase tracking-widest px-8 py-3.5 rounded-md cursor-pointer shadow-xl hover:shadow-2xl w-full sm:w-auto"
              >
                Access Portal
              </button>
            </div>
          </div>

          {/* VSL Video Container */}
          <div className="flex-1 w-full max-w-lg aspect-video rounded-xl overflow-hidden shadow-2xl border-4 border-white/20 relative group bg-black cursor-pointer">
            {vslVideoUrl ? (
              <video 
                src={vslVideoUrl} 
                controls
                className="w-full h-full object-cover"
              />
            ) : (
              <>
                <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none group-hover:scale-110 transition-transform">
                   <div className="w-16 h-16 rounded-full bg-[#D4AF37] flex items-center justify-center shadow-[0_0_30px_rgba(212,175,55,0.6)]">
                     <svg className="w-7 h-7 text-[#0a1d37] ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                   </div>
                </div>
                {/* Placeholder for video / Thumbnail */}
                <img 
                   src="https://images.unsplash.com/photo-1551818255-e6e10975bc17?auto=format&fit=crop&w=800&q=80" 
                   alt="Agency Briefing Video Sales Letter (VSL) Thumbnail" 
                   className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" 
                />
                <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md text-white text-[10px] font-mono tracking-widest px-2 py-1 rounded">
                  ▶ 02:45
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      {/* SERVICES INFORMATION GRIDS */}
      <section className="w-full max-w-5xl px-6 py-16 grid md:grid-cols-2 gap-16 border-b border-slate-100">
        <div className="space-y-4">
          <h2 className="text-lg font-extrabold tracking-wider text-[#0a1d37] font-mono uppercase border-b-2 border-[#D4AF37] pb-2">
            [ Talent & Influencer Agency Services ]
          </h2>
          <ul className="space-y-2.5 text-sm text-slate-600 font-medium">
            <li>- Automated Full-Lifecycle Campaign Management</li>
            <li>- Multi-Platform Multimodal Creator Vetting</li>
            <li>- Real-Time Engagement &amp; Escrow Velocity Tracking</li>
            <li>- AI-Powered Creative Briefing &amp; Script Isolation</li>
          </ul>
        </div>
        <div className="space-y-4">
          <h2 className="text-lg font-extrabold tracking-wider text-[#0a1d37] font-mono uppercase border-b-2 border-[#0a1d37] pb-2">
            [ Brands Partnership Environment ]
          </h2>
          <ul className="space-y-2.5 text-sm text-slate-600 font-medium">
            <li>- Targeted Niche Casting (Pets, Cosmetics, Lifestyle)</li>
            <li>- 100% Verified FTC Copy Compliance Registry</li>
            <li>- Secure Sandbox Asset Deliverable Review</li>
            <li>- Frictionless Client Portal &amp; Automated Wrap-Up Reports</li>
          </ul>
        </div>
      </section>

      {/* NICHE VERTICAL PILLARS GRID CONTAINER */}
      <section className="w-full max-w-5xl px-6 py-16 border-b border-slate-100">
        <h3 className="text-center text-sm font-bold uppercase tracking-[0.2em] text-[#0a1d37] mb-12">[ Our Specialized Vertical Matrices ]</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Card 1: Pet Influencers */}
          <div className="bg-[#0a1d37] text-white border-2 border-[#D4AF37]/30 p-6 rounded-xl space-y-2 shadow-2xl text-left">
            <span className="text-xl">🐾</span>
            <h4 className="font-bold text-[#D4AF37] font-serif text-lg">Pet Influencers</h4>
            <p className="text-xs text-slate-300 leading-relaxed">Dedicated audience metric tracking built specifically for high-end organic pet care, nutrition profiles, and lifestyle scaling parameters.</p>
          </div>
          
          {/* Card 2: Cosmetics & Beauty */}
          <div className="bg-[#0a1d37] text-white border-2 border-[#D4AF37]/30 p-6 rounded-xl space-y-2 shadow-2xl text-left">
            <span className="text-xl">💄</span>
            <h4 className="font-bold text-[#D4AF37] font-serif text-lg">Cosmetics & Beauty</h4>
            <p className="text-xs text-slate-300 leading-relaxed">High-conversion layout deployment frameworks for visual product application flatlays, tutorial analytics, and strict placement briefs.</p>
          </div>
          
          {/* Card 3: Luxury Lifestyle */}
          <div className="bg-[#0a1d37] text-white border-2 border-[#D4AF37]/30 p-6 rounded-xl space-y-2 shadow-2xl text-left">
            <span className="text-xl">🌿</span>
            <h4 className="font-bold text-[#D4AF37] font-serif text-lg">Luxury Lifestyle</h4>
            <p className="text-xs text-slate-300 leading-relaxed">Aesthetic curations highlighting daily routines, premium product integrations, high-end travel logs, and wellness matrices.</p>
          </div>

        </div>
      </section>

      {/* CONNECT & EXPAND REGISTRATION SECTION */}
      <section id="connect" className="w-full max-w-5xl px-6 py-16 border-b border-slate-100">
        <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
          <h3 className="text-xl font-bold tracking-widest text-[#0a1d37] font-mono uppercase">
            [ Connect &amp; Expand Registration Portal ]
          </h3>
          <p className="text-xs text-slate-500 font-medium leading-relaxed">
            Submit your details directly — whether you are talent applying for representation or a brand deploying an inbound campaign brief.
          </p>
        </div>

        {/* Tab Navigation for Registration (Creators & Brands only) */}
        <div className="flex items-center justify-center gap-3 mb-10">
          <button
            type="button"
            onClick={() => setRegistrationMode('creator')}
            className={`px-6 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
              registrationMode === 'creator'
                ? 'bg-[#D4AF37] text-black shadow-lg shadow-amber-500/20 scale-105'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>✨ Creators (Representation)</span>
          </button>

          <button
            type="button"
            onClick={() => setRegistrationMode('brand')}
            className={`px-6 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
              registrationMode === 'brand'
                ? 'bg-[#0a1d37] text-white shadow-lg scale-105'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <span>💼 Brand Campaigns (Partners)</span>
          </button>
        </div>
        
        {/* Dynamic Registration Forms */}
        {registrationMode === 'creator' ? (
          <div className="max-w-xl mx-auto bg-[#0a1d37] text-white rounded-2xl p-8 border border-blue-950/40 shadow-2xl space-y-6">
            <h4 className="text-md font-bold font-mono tracking-wider text-center border-b border-blue-900/60 pb-3 text-[#D4AF37]">
              [ ✨ APPLY FOR TALENT REPRESENTATION ]
            </h4>

            {creatorSubmittedSuccess ? (
              <div className="p-6 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-center space-y-3 text-emerald-300">
                <div className="text-3xl">✨</div>
                <h5 className="font-bold text-base text-white">Application Submitted!</h5>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Thank you! Your creator dossier has been received and routed directly to our talent director. We will contact you upon review.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setCreatorSubmittedSuccess(false);
                    setCreatorName('');
                    setCreatorHandle('');
                    setCreatorEmail('');
                    setCreatorBio('');
                  }}
                  className="px-4 py-2 bg-[#D4AF37] text-black font-bold text-xs rounded-lg cursor-pointer"
                >
                  Submit Another
                </button>
              </div>
            ) : (
              <form onSubmit={handleCreatorFormSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Legal / Creator Name *
                  </label>
                  <input 
                    type="text" 
                    value={creatorName}
                    onChange={(e) => setCreatorName(e.target.value)}
                    placeholder="e.g. Rachel Sterling" 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Primary Social Handle *
                  </label>
                  <input 
                    type="text" 
                    value={creatorHandle}
                    onChange={(e) => setCreatorHandle(e.target.value)}
                    placeholder="e.g. @rachelsterling" 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Direct Contact Email *
                  </label>
                  <input 
                    type="email" 
                    value={creatorEmail}
                    onChange={(e) => setCreatorEmail(e.target.value)}
                    placeholder="e.g. rachel@sterlingmgmt.com" 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Bio &amp; Content Focus Niche *
                  </label>
                  <textarea 
                    value={creatorBio}
                    onChange={(e) => setCreatorBio(e.target.value)}
                    placeholder="[Briefly describe your audience reach, primary platforms, and vertical focus...]" 
                    rows={3} 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition resize-none" 
                  />
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-[#D4AF37] hover:bg-[#bfa232] text-black font-extrabold text-xs uppercase tracking-widest py-4 px-4 rounded-xl transition shadow-lg mt-2 cursor-pointer"
                >
                  Submit Representation Request
                </button>
              </form>
            )}
          </div>
        ) : (
          <div className="max-w-xl mx-auto bg-[#0a1d37] text-white rounded-2xl p-8 border border-blue-950/40 shadow-2xl space-y-6">
            <h4 className="text-md font-bold font-mono tracking-wider text-center border-b border-blue-900/60 pb-3 text-[#D4AF37]">
              [ 💼 DEPLOY INBOUND BRAND CAMPAIGN ]
            </h4>

            {brandSubmittedSuccess ? (
              <div className="p-6 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-center space-y-3 text-emerald-300">
                <div className="text-3xl">💼</div>
                <h5 className="font-bold text-base text-white">Campaign Brief Received!</h5>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Thank you! Your campaign briefing has been submitted to the Director's Brand Deals CRM. We will match talent and reach out shortly.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setBrandSubmittedSuccess(false);
                    setBrandCompany('');
                    setBrandEmail('');
                    setBrandBudget('');
                    setBrandBrief('');
                  }}
                  className="px-4 py-2 bg-[#D4AF37] text-black font-bold text-xs rounded-lg cursor-pointer"
                >
                  Deploy Another Brief
                </button>
              </div>
            ) : (
              <form onSubmit={handleBrandFormSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Brand / Company Name *
                  </label>
                  <input 
                    type="text" 
                    value={brandCompany}
                    onChange={(e) => setBrandCompany(e.target.value)}
                    placeholder="e.g. Lumina Skin Corp" 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Work Email *
                  </label>
                  <input 
                    type="email" 
                    value={brandEmail}
                    onChange={(e) => setBrandEmail(e.target.value)}
                    placeholder="e.g. marketing@luminaskin.com" 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Allocated Budget ($ USD) *
                  </label>
                  <input 
                    type="number" 
                    value={brandBudget}
                    onChange={(e) => setBrandBudget(e.target.value)}
                    placeholder="e.g. 15000" 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition font-mono" 
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 font-mono">
                    Campaign Scope / Deliverable Brief *
                  </label>
                  <textarea 
                    value={brandBrief}
                    onChange={(e) => setBrandBrief(e.target.value)}
                    placeholder="[Describe target deliverables, preferred creators, flight dates, and key performance requirements...]" 
                    rows={3} 
                    required 
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition resize-none" 
                  />
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-[#0a1d37] hover:bg-slate-800 text-[#D4AF37] border-2 border-[#D4AF37] font-extrabold text-xs uppercase tracking-widest py-4 px-4 rounded-xl transition shadow-lg mt-2 cursor-pointer"
                >
                  Submit Briefing &amp; Partner
                </button>
              </form>
            )}
          </div>
        )}
      </section>

      {/* PITCH HOOK, SECURITY PROFILE & MAIN CTA TRIGGER */}
      <section className="w-full max-w-4xl px-6 py-16 flex flex-col items-center text-center space-y-8">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-[#0a1d37] font-serif">
          Are you looking to run your agency with <span className="italic text-[#D4AF37]">software?</span>
        </h2>

        {/* Secure Workspace Architecture Card Component */}
        <div className="w-full max-w-2xl bg-[#0a1d37] border-2 border-[#D4AF37] rounded-xl p-6 text-left shadow-xl text-white">
          <div className="flex items-center gap-2 mb-3 text-[#D4AF37]">
            <span className="text-base">🛡️</span>
            <h3 className="text-xs font-bold uppercase tracking-widest font-mono">[ SECURE WORKSPACE ARCHITECTURE ]</h3>
          </div>
          <p className="text-xs text-slate-300 font-medium leading-relaxed font-sans mb-6">
            Our dynamic routing layers handle permission configurations dynamically, maintaining rigid data silos between external entities and proprietary rosters. Direct messaging flows remain strictly managed under escrow parameters.
          </p>

          {/* Sub-Technical Features Specifications */}
          <div className="border-t border-slate-800 pt-4 space-y-3 font-mono text-[11px] text-slate-400">
            <p><strong className="text-[#D4AF37] font-semibold">● PROGRAMMATIC ESCROW FILTERS:</strong> Automated campaign funding distribution nodes executing only upon API social endpoint metrics verification.</p>
            <p><strong className="text-[#D4AF37] font-semibold">● REAL-TIME DATA COMPREHENSION:</strong> Track isolated reach parameters and cross-platform network metrics natively without leaky third-party data tracking snippets.</p>
            <p><strong className="text-[#D4AF37] font-semibold">--- PROTOCOL SAFE PROFILE REGISTRIES ---</strong></p>
          </div>
        </div>

        {/* Polished Gold Sign Up Button Trigger */}
        <a 
          href="#connect" 
          className="inline-block bg-[#D4AF37] hover:bg-[#bfa232] text-black font-extrabold text-xs uppercase tracking-widest py-4 px-16 rounded-xl transition-all shadow-xl transform active:scale-[0.99] border-b-2 border-amber-600"
        >
          Sign Up / Apply
        </a>
      </section>

      {/* WHO WE ARE CREDIBILITY OVERVIEW SECTION */}
      <section className="w-full max-w-3xl px-6 py-16 text-center border-t border-slate-100 space-y-12">
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-[#0a1d37] font-mono tracking-widest uppercase">[ Who We Are ]</h2>
          <p className="text-slate-600 text-sm leading-relaxed max-w-xl mx-auto font-medium">
            About {agencyName}: {agencyName} is a full-service talent management and campaign production house. We exist to anchor the relationship between elite creators and the global brands ready to partner with them. We protect our roster’s creative freedom while fully executing the strict performance metrics and secure data parameters that enterprise brands expect. By focusing on long-term alignments rather than one-off placements, we eliminate the traditional friction point between creator autonomy and corporate guidelines. Backed by transparent analytics, {agencyName} is the vital foundation behind high-impact influencer marketing campaigns.
          </p>
        </div>

        {/* Pinned Core Structural Governance Grid Under Biography */}
        <div className="border-t border-slate-100 pt-8 grid md:grid-cols-3 gap-6 text-left font-sans">
          <div className="space-y-1.5">
            <h4 className="text-xs font-bold text-[#0a1d37] uppercase tracking-wider font-mono">1. Absolute Autonomy</h4>
            <p className="text-xs text-slate-500 leading-relaxed">We protect talent identity and creative vectors completely, establishing native barriers against corporate guidelines.</p>
          </div>
          <div className="space-y-1.5">
            <h4 className="text-xs font-bold text-[#0a1d37] uppercase tracking-wider font-mono">2. Zero Aggregation Data</h4>
            <p className="text-xs text-slate-500 leading-relaxed">We completely reject selling, tracking, or pooling private campaign interaction briefs to external analytical brokers.</p>
          </div>
          <div className="space-y-1.5">
            <h4 className="text-xs font-bold text-[#0a1d37] uppercase tracking-wider font-mono">3. Ecosystem Isolation</h4>
            <p className="text-xs text-slate-500 leading-relaxed">Every client relationship and partner metrics dossier is handled inside decentralized structural code matrices to verify complete safety.</p>
          </div>
        </div>
      </section>

      {/* CAREERS & AGENCY STAFF OPENINGS SECTION (CLEAN COMPACT BAR ABOVE FOOTER) */}
      {(hiringSettings?.isHiringActive !== false && hiringSettings?.showCareersOnLanding !== false) && (
        <section id="careers" className="w-full max-w-4xl px-6 py-8 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-6 bg-slate-50/70 rounded-2xl my-8 text-center sm:text-left">
          <div className="space-y-1">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <span className="text-[9px] font-bold text-emerald-600 bg-emerald-100/90 px-2.5 py-0.5 rounded-full font-mono uppercase tracking-wider">
                ● Now Hiring
              </span>
              <span className="text-xs font-serif font-bold text-[#0a1d37]">Agency Careers &amp; Positions</span>
            </div>
            <p className="text-xs text-slate-600 max-w-md leading-relaxed">
              Join our talent representation team. Explore open roles for talent agents, roster managers, campaign coordinators, and operations staff.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowCareersModal(true)}
            className="shrink-0 inline-flex items-center gap-2 px-6 py-3.5 bg-[#0a1d37] text-[#D4AF37] border-2 border-[#D4AF37] hover:bg-[#061224] rounded-xl font-bold text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer"
          >
            <Briefcase className="w-4 h-4" />
            <span>Open Careers Portal &amp; Submit Application</span>
          </button>
        </section>
      )}

      {/* Footer */}
      <footer style={{ backgroundColor: '#0a1d37' }} className="w-full text-white py-8 px-6 flex flex-col items-center justify-center shadow-inner mt-auto space-y-4">
        <div className="w-full max-w-4xl flex flex-wrap items-center justify-center gap-6 font-mono text-[11px] tracking-wider text-slate-300 font-bold uppercase">
          <div className="flex items-center gap-2"><span className="text-amber-500">🔒</span> AES-256</div>
          <div className="hidden md:inline text-slate-800">|</div>
          <div className="flex items-center gap-2"><span className="text-amber-400">●</span> SOC 2 AUDIT READINESS IN-PROGRESS</div>
          {hiringSettings?.showCareersOnLanding !== false && (
            <>
              <div className="hidden md:inline text-slate-700">|</div>
              <button 
                type="button" 
                onClick={() => setShowCareersModal(true)}
                className="text-[#D4AF37] hover:underline cursor-pointer flex items-center gap-1.5"
              >
                <Briefcase className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>CAREERS &amp; POSITIONS</span>
                {hiringSettings?.isHiringActive === false && (
                  <span className="text-[9px] text-slate-400 font-mono normal-case">(Closed)</span>
                )}
              </button>
            </>
          )}
          <div className="hidden md:inline text-slate-700">|</div>
          <button 
            type="button" 
            onClick={() => setShowModal(true)}
            className="text-slate-300 hover:text-white cursor-pointer"
          >
            PORTAL LOGIN
          </button>
        </div>
        <p className="text-[10px] text-slate-500 font-sans">
          © {new Date().getFullYear()} {agencyName} • {legalEntityName}. All rights reserved.
        </p>
      </footer>

      {/* CAREERS APPLICATION MODAL OVERLAY */}
      {showCareersModal && (
        <div id="careersModal" className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <motion.div 
            initial={{ scale: 0.94, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-[#0a1d37] border-2 border-[#D4AF37] rounded-2xl w-full max-w-3xl p-6 md:p-8 relative shadow-2xl text-white my-8 max-h-[90vh] overflow-y-auto"
          >
            {/* Close Button */}
            <button 
              type="button"
              onClick={() => setShowCareersModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="text-left space-y-1 mb-6 border-b border-blue-900/60 pb-4 pr-8">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#D4AF37] font-bold">
                [ {agencyName.toUpperCase()} • AGENCY POSITIONS &amp; TALENT TEAM ]
              </span>
              <h3 className="text-xl md:text-2xl font-serif font-bold text-white">
                {hiringSettings?.isHiringActive === false ? 'Agency Positions Overview' : 'Apply to Join Our Agency Team'}
              </h3>
              <p className="text-xs text-slate-300">
                {hiringSettings?.isHiringActive === false 
                  ? 'Staff applications are currently paused. Review our internal agency position structures below.' 
                  : "All applications are routed directly to the Agency Director's Action Queue for review."}
              </p>
            </div>

            {/* If Hiring is completely paused */}
            {hiringSettings?.isHiringActive === false && (
              <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-200 text-xs space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <span>ℹ️</span> Applications Currently Paused
                </p>
                <p className="text-[11px] text-amber-300/80 leading-relaxed">
                  We are not actively accepting new candidate applications at this moment. You may still review our core agency role responsibilities below.
                </p>
              </div>
            )}

            {/* Position Descriptions Grid */}
            <div className="mb-8 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-mono font-bold text-slate-400 block">
                  Agency Roles &amp; Operational Responsibilities:
                </span>
                {hiringSettings?.customHiringNote && (
                  <span className="text-[10px] font-medium text-[#D4AF37] italic bg-[#D4AF37]/10 px-2 py-0.5 rounded border border-[#D4AF37]/20">
                    📢 {hiringSettings.customHiringNote}
                  </span>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                
                {/* Role 1: Talent Agent */}
                <button 
                  type="button"
                  onClick={() => {
                    if (hiringSettings?.isHiringActive !== false && hiringSettings?.openRoles?.talentAgent !== false) {
                      setAgentRole('Talent Agent');
                    }
                  }}
                  className={`p-3.5 rounded-xl border transition-all text-left w-full ${
                    hiringSettings?.openRoles?.talentAgent === false
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
                      : agentRole === 'Talent Agent'
                        ? 'bg-blue-950/70 border-[#D4AF37] shadow-md cursor-pointer'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300 cursor-pointer'
                  }`}
                  aria-pressed={agentRole === 'Talent Agent'}
                  disabled={hiringSettings?.isHiringActive === false || hiringSettings?.openRoles?.talentAgent === false}
                >
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span className="text-white">Talent Agent</span>
                    {hiringSettings?.openRoles?.talentAgent === false ? (
                      <span className="text-slate-500 text-[10px]">Closed</span>
                    ) : agentRole === 'Talent Agent' ? (
                      <span className="text-[#D4AF37] text-[10px]">● Selected</span>
                    ) : (
                      <span className="text-emerald-400 text-[10px]">Open</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Sources prospective brand sponsorship opportunities and scouts creator talent for our agency roster. Talent agents focus strictly on talent sourcing and scouting; they do not negotiate brand deals, contract terms, or compensation rates.
                  </p>
                </button>

                {/* Role 2: Agent Manager (Agency & Roster Lead) */}
                <button 
                  type="button"
                  onClick={() => {
                    if (hiringSettings?.isHiringActive !== false && hiringSettings?.openRoles?.agentManager !== false) {
                      setAgentRole('Agent Manager (Agency & Roster Lead)');
                    }
                  }}
                  className={`p-3.5 rounded-xl border transition-all text-left w-full ${
                    hiringSettings?.openRoles?.agentManager === false
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
                      : agentRole.includes('Agent Manager')
                        ? 'bg-blue-950/70 border-[#D4AF37] shadow-md cursor-pointer'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300 cursor-pointer'
                  }`}
                  aria-pressed={agentRole.includes('Agent Manager')}
                  disabled={hiringSettings?.isHiringActive === false || hiringSettings?.openRoles?.agentManager === false}
                >
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span className="text-white">Agent Manager (Agency &amp; Roster Lead)</span>
                    {hiringSettings?.openRoles?.agentManager === false ? (
                      <span className="text-slate-500 text-[10px]">Closed</span>
                    ) : agentRole.includes('Agent Manager') ? (
                      <span className="text-[#D4AF37] text-[10px]">● Selected</span>
                    ) : (
                      <span className="text-emerald-400 text-[10px]">Open</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Directs agent deal allocations across the talent team (assigning inbound brand deals and campaign revenue pipelines to individual agents based on capacity and creator fit). Matches roster creators to incoming brand requests, audits creator pricing rate cards, manages deal escalations, and collaborates directly with the Agency Director.
                  </p>
                </button>

                {/* Role 3: Campaign Coordinator */}
                <button 
                  type="button"
                  onClick={() => {
                    if (hiringSettings?.isHiringActive !== false && hiringSettings?.openRoles?.campaignCoordinator !== false) {
                      setAgentRole('Campaign Coordinator');
                    }
                  }}
                  className={`p-3.5 rounded-xl border transition-all text-left w-full ${
                    hiringSettings?.openRoles?.campaignCoordinator === false
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
                      : agentRole === 'Campaign Coordinator'
                        ? 'bg-blue-950/70 border-[#D4AF37] shadow-md cursor-pointer'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300 cursor-pointer'
                  }`}
                  aria-pressed={agentRole === 'Campaign Coordinator'}
                  disabled={hiringSettings?.isHiringActive === false || hiringSettings?.openRoles?.campaignCoordinator === false}
                >
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span className="text-white">Campaign Coordinator</span>
                    {hiringSettings?.openRoles?.campaignCoordinator === false ? (
                      <span className="text-slate-500 text-[10px]">Closed</span>
                    ) : agentRole === 'Campaign Coordinator' ? (
                      <span className="text-[#D4AF37] text-[10px]">● Selected</span>
                    ) : (
                      <span className="text-emerald-400 text-[10px]">Open</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Coordinates post-signing campaign logistics. Collects video and photo drafts from creators, checks brand safety guidelines and FTC disclosures, coordinates client revisions, tracks posting schedules, and compiles final performance links.
                  </p>
                </button>

                {/* Role 4: Operations & Billing Specialist */}
                <button 
                  type="button"
                  onClick={() => {
                    if (hiringSettings?.isHiringActive !== false && hiringSettings?.openRoles?.operationsSpecialist !== false) {
                      setAgentRole('Operations & Billing Specialist');
                    }
                  }}
                  className={`p-3.5 rounded-xl border transition-all text-left w-full ${
                    hiringSettings?.openRoles?.operationsSpecialist === false
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
                      : agentRole === 'Operations & Billing Specialist'
                        ? 'bg-blue-950/70 border-[#D4AF37] shadow-md cursor-pointer'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300 cursor-pointer'
                  }`}
                  aria-pressed={agentRole === 'Operations & Billing Specialist'}
                  disabled={hiringSettings?.isHiringActive === false || hiringSettings?.openRoles?.operationsSpecialist === false}
                >
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span className="text-white">Operations &amp; Billing Specialist</span>
                    {hiringSettings?.openRoles?.operationsSpecialist === false ? (
                      <span className="text-slate-500 text-[10px]">Closed</span>
                    ) : agentRole === 'Operations & Billing Specialist' ? (
                      <span className="text-[#D4AF37] text-[10px]">● Selected</span>
                    ) : (
                      <span className="text-emerald-400 text-[10px]">Open</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Handles agency financial operations: generating client invoices, managing net-30 / net-60 receivables, collecting W-9 compliance documents, and coordinating talent payout distributions.
                  </p>
                </button>

                {/* Role 5: Brand Partnerships Lead */}
                <button 
                  type="button"
                  onClick={() => {
                    if (hiringSettings?.isHiringActive !== false && hiringSettings?.openRoles?.brandPartnerships !== false) {
                      setAgentRole('Brand Partnerships Lead');
                    }
                  }}
                  className={`p-3.5 rounded-xl border transition-all text-left w-full ${
                    hiringSettings?.openRoles?.brandPartnerships === false
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
                      : agentRole === 'Brand Partnerships Lead'
                        ? 'bg-blue-950/70 border-[#D4AF37] shadow-md cursor-pointer'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300 cursor-pointer'
                  }`}
                  aria-pressed={agentRole === 'Brand Partnerships Lead'}
                  disabled={hiringSettings?.isHiringActive === false || hiringSettings?.openRoles?.brandPartnerships === false}
                >
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span className="text-white">Brand Partnerships Lead</span>
                    {hiringSettings?.openRoles?.brandPartnerships === false ? (
                      <span className="text-slate-500 text-[10px]">Closed</span>
                    ) : agentRole === 'Brand Partnerships Lead' ? (
                      <span className="text-[#D4AF37] text-[10px]">● Selected</span>
                    ) : (
                      <span className="text-emerald-400 text-[10px]">Open</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Develops and nurtures direct relationships with top consumer brands, media agencies, and Fortune 500 sponsors. Secures multi-campaign sponsorships and negotiates high-value brand partnerships.
                  </p>
                </button>

                {/* Role 6: Inbound Sales Executive */}
                <button 
                  type="button"
                  onClick={() => {
                    if (hiringSettings?.isHiringActive !== false && hiringSettings?.openRoles?.inboundSales !== false) {
                      setAgentRole('Inbound Sales Executive');
                    }
                  }}
                  className={`p-3.5 rounded-xl border transition-all text-left w-full ${
                    hiringSettings?.openRoles?.inboundSales === false
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-60 cursor-not-allowed'
                      : agentRole === 'Inbound Sales Executive'
                        ? 'bg-blue-950/70 border-[#D4AF37] shadow-md cursor-pointer'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300 cursor-pointer'
                  }`}
                  aria-pressed={agentRole === 'Inbound Sales Executive'}
                  disabled={hiringSettings?.isHiringActive === false || hiringSettings?.openRoles?.inboundSales === false}
                >
                  <div className="flex items-center justify-between font-bold mb-1">
                    <span className="text-white">Inbound Sales Executive</span>
                    {hiringSettings?.openRoles?.inboundSales === false ? (
                      <span className="text-slate-500 text-[10px]">Closed</span>
                    ) : agentRole === 'Inbound Sales Executive' ? (
                      <span className="text-[#D4AF37] text-[10px]">● Selected</span>
                    ) : (
                      <span className="text-emerald-400 text-[10px]">Open</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Handles incoming brand inquiries, sponsor partnership requests, and inbound campaign briefing forms. Qualifies sponsor budgets, pitches agency roster packages, and converts inbound brand leads into contracted pipeline deals.
                  </p>
                </button>

              </div>
            </div>

            {/* Application Form */}
            {hiringSettings?.isHiringActive === false ? (
              <div className="p-6 bg-slate-900/80 border border-slate-800 rounded-xl text-center space-y-3 text-slate-400">
                <p className="text-xs">
                  Applications are currently paused by the Agency Director. Please check back when new recruitment cycles open.
                </p>
                <button
                  type="button"
                  onClick={() => setShowCareersModal(false)}
                  className="px-6 py-2 bg-[#D4AF37] text-black font-bold text-xs rounded-xl cursor-pointer"
                >
                  Close
                </button>
              </div>
            ) : agentSubmittedSuccess ? (
              <div className="p-6 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-center space-y-4 text-emerald-300">
                <div className="text-4xl">✅</div>
                <h4 className="font-bold text-lg text-white">Application Received!</h4>
                <p className="text-xs text-slate-200 leading-relaxed max-w-md mx-auto">
                  Thank you, <strong>{agentName}</strong>. Your candidate dossier for the <strong>{agentRole}</strong> position has been routed directly to the Agency Director's Action Queue for review. We will contact you at <strong>{agentEmail}</strong>.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setAgentSubmittedSuccess(false);
                    setAgentName('');
                    setAgentEmail('');
                    setAgentPhone('');
                    setAgentNotes('');
                    setShowCareersModal(false);
                  }}
                  className="px-6 py-2.5 bg-[#D4AF37] text-black font-bold text-xs rounded-xl cursor-pointer shadow-lg"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleCareerFormSubmit} className="space-y-4 border-t border-blue-900/60 pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <FileText className="w-4 h-4 text-[#D4AF37]" />
                  <h4 className="font-bold text-sm text-white">Candidate Information Form</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">
                      Full Legal Name *
                    </label>
                    <input 
                      type="text" 
                      value={agentName}
                      onChange={(e) => setAgentName(e.target.value)}
                      placeholder="e.g. Marcus Vance" 
                      required 
                      className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">
                      Work / Contact Email *
                    </label>
                    <input 
                      type="email" 
                      value={agentEmail}
                      onChange={(e) => setAgentEmail(e.target.value)}
                      placeholder="e.g. marcus@agencyrep.com" 
                      required 
                      className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">
                      Phone Number *
                    </label>
                    <input 
                      type="tel" 
                      value={agentPhone}
                      onChange={(e) => setAgentPhone(e.target.value)}
                      placeholder="e.g. +1 (555) 234-5678" 
                      required 
                      className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition" 
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">
                      Applying Staff Position *
                    </label>
                    <select 
                      value={agentRole}
                      onChange={(e) => setAgentRole(e.target.value)}
                      className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition cursor-pointer font-sans"
                    >
                      {hiringSettings?.openRoles?.talentAgent !== false && (
                        <option value="Talent Agent">Talent Agent (Talent Sourcing & Pitching)</option>
                      )}
                      {hiringSettings?.openRoles?.agentManager !== false && (
                        <option value="Agent Manager (Agency & Roster Lead)">Agent Manager (Agency & Roster Lead)</option>
                      )}
                      {hiringSettings?.openRoles?.campaignCoordinator !== false && (
                        <option value="Campaign Coordinator">Campaign Coordinator (Delivery & Logistics)</option>
                      )}
                      {hiringSettings?.openRoles?.operationsSpecialist !== false && (
                        <option value="Operations & Billing Specialist">Operations & Billing Specialist</option>
                      )}
                      {hiringSettings?.openRoles?.brandPartnerships !== false && (
                        <option value="Brand Partnerships Lead">Brand Partnerships Lead</option>
                      )}
                      {hiringSettings?.openRoles?.inboundSales !== false && (
                        <option value="Inbound Sales Executive">Inbound Sales Executive</option>
                      )}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">
                    Industry Experience Level
                  </label>
                  <select 
                    value={agentExperience}
                    onChange={(e) => setAgentExperience(e.target.value)}
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition cursor-pointer font-sans"
                  >
                    <option value="1-2 years talent representation">1-2 years talent representation</option>
                    <option value="3-5 years talent management">3-5 years talent management</option>
                    <option value="5+ years senior talent executive">5+ years senior talent executive</option>
                    <option value="Independent talent manager transitioning roster">Independent talent manager transitioning roster</option>
                    <option value="Entry-level / eager to learn agency workflows">Entry-level / eager to learn agency workflows</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">
                    Background, LinkedIn / Portfolio, or Talent Sourcing Experience
                  </label>
                  <textarea 
                    value={agentNotes}
                    onChange={(e) => setAgentNotes(e.target.value)}
                    placeholder="[Highlight your background, notable talent sourced, agency experience, or motivation...]" 
                    rows={3}
                    className="w-full bg-[#050e1a] border border-blue-900 rounded-xl px-4 py-3 text-xs focus:outline-none text-slate-200 transition resize-none" 
                  />
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-[#D4AF37] hover:bg-[#bfa232] text-black font-extrabold text-xs uppercase tracking-widest py-4 px-4 rounded-xl transition shadow-lg mt-2 cursor-pointer"
                >
                  Submit Staff &amp; Agent Application
                </button>
              </form>
            )}
          </motion.div>
        </div>
      )}

      {/* Unified Multi-Role Portal Login Modal */}
      {showModal && (
        <div id="loginModal" className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="border rounded-2xl w-full max-w-xl p-6 md:p-8 relative shadow-2xl text-white space-y-5"
            style={{ backgroundColor: '#0a1d37', borderColor: '#D4AF37' }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-950 bg-[#D4AF37] font-bold shadow-md">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-serif font-bold text-white">{agencyName || 'Bloom Studio'} Unified Portal</h3>
                  <p className="text-xs text-slate-300">Select your role or authorization portal below</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer transition"
              >
                ✕
              </button>
            </div>

            {/* Error Notification */}
            {authError && (
              <div className="p-3 bg-red-950/80 border border-red-500/40 text-red-200 rounded-xl text-xs">
                {authError}
              </div>
            )}

            {/* Role Selector Tabs */}
            <div className="grid grid-cols-4 gap-1 bg-[#050C18] p-1 rounded-xl border border-white/10 text-center font-mono text-[11px]">
              <button
                type="button"
                onClick={() => setActivePortalTab('director')}
                className={`py-2 px-1 rounded-lg font-bold transition cursor-pointer flex flex-col items-center gap-0.5 ${
                  activePortalTab === 'director' ? 'bg-[#D4AF37] text-black shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>👑 Owner</span>
              </button>

              <button
                type="button"
                onClick={() => setActivePortalTab('staff')}
                className={`py-2 px-1 rounded-lg font-bold transition cursor-pointer flex flex-col items-center gap-0.5 ${
                  activePortalTab === 'staff' ? 'bg-[#D4AF37] text-black shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>💼 Staff</span>
              </button>

              <button
                type="button"
                onClick={() => setActivePortalTab('creator')}
                className={`py-2 px-1 rounded-lg font-bold transition cursor-pointer flex flex-col items-center gap-0.5 ${
                  activePortalTab === 'creator' ? 'bg-[#D4AF37] text-black shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🎨 Creator</span>
              </button>

              <button
                type="button"
                onClick={() => setActivePortalTab('subagency')}
                className={`py-2 px-1 rounded-lg font-bold transition cursor-pointer flex flex-col items-center gap-0.5 ${
                  activePortalTab === 'subagency' ? 'bg-[#D4AF37] text-black shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>🏢 Sub-Agency</span>
              </button>
            </div>

            {/* TAB CONTENT 1: DIRECTOR (AGENCY OWNER) */}
            {activePortalTab === 'director' && (
              <div className="space-y-4 bg-[#051124] p-4 rounded-xl border border-white/10 animate-fade-in">
                <div>
                  <h4 className="text-sm font-bold text-[#D4AF37] flex items-center gap-1.5 font-mono">
                    👑 Agency Executive Director &amp; Master Owner
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Full administrative control over agency financials, commission splits, staff role assignments, and roster vault.
                  </p>
                </div>

                {/* Google Sign-in for Director */}
                <button 
                  type="button" 
                  id="btn-login-google-director"
                  onClick={handleGoogleSignIn}
                  disabled={isSigningIn}
                  className="w-full py-3 px-4 bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs rounded-xl cursor-pointer shadow-md transition-all flex items-center justify-center gap-2.5 border border-slate-200"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>{isSigningIn ? 'Connecting to Google...' : 'Sign in with Google (Director)'}</span>
                </button>

                <div className="text-center pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      if (onLogin) onLogin('director@bloomstudio.com', 'director');
                      setShowModal(false);
                    }}
                    className="text-xs text-[#D4AF37] hover:underline font-mono font-bold cursor-pointer"
                  >
                    ⚡ Instant Director Quick Access &rarr;
                  </button>
                </div>
              </div>
            )}

            {/* TAB CONTENT 2: INTERNAL STAFF */}
            {activePortalTab === 'staff' && (
              <div className="space-y-4 bg-[#051124] p-4 rounded-xl border border-white/10 animate-fade-in">
                <div>
                  <h4 className="text-sm font-bold text-amber-300 flex items-center gap-1.5 font-mono">
                    💼 Internal Agency Staff (Team Workspace)
                  </h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Internal team members operating inside your primary agency. Select your staff designation:
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedStaffRole('agentmgr')}
                    className={`p-2.5 rounded-xl border text-left font-mono transition cursor-pointer ${
                      selectedStaffRole === 'agentmgr' ? 'bg-[#1A2C4A] border-[#D4AF37] text-white' : 'bg-white/5 border-white/10 text-slate-400'
                    }`}
                  >
                    <span className="text-xs font-bold block text-[#D4AF37]">Agent Mgr</span>
                    <span className="text-[10px] text-slate-300 block mt-0.5">Deals &amp; Roster</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedStaffRole('coordinator')}
                    className={`p-2.5 rounded-xl border text-left font-mono transition cursor-pointer ${
                      selectedStaffRole === 'coordinator' ? 'bg-[#1A2C4A] border-[#D4AF37] text-white' : 'bg-white/5 border-white/10 text-slate-400'
                    }`}
                  >
                    <span className="text-xs font-bold block text-[#D4AF37]">Coordinator</span>
                    <span className="text-[10px] text-slate-300 block mt-0.5">Campaigns &amp; QA</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedStaffRole('agent')}
                    className={`p-2.5 rounded-xl border text-left font-mono transition cursor-pointer ${
                      selectedStaffRole === 'agent' ? 'bg-[#1A2C4A] border-[#D4AF37] text-white' : 'bg-white/5 border-white/10 text-slate-400'
                    }`}
                  >
                    <span className="text-xs font-bold block text-[#D4AF37]">Talent Agent</span>
                    <span className="text-[10px] text-slate-300 block mt-0.5">Talent Pitches</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (onLogin) onLogin(`${selectedStaffRole}@agency.com`, selectedStaffRole);
                    setShowModal(false);
                  }}
                  className="w-full py-3 bg-[#D4AF37] hover:bg-[#e0bb43] text-slate-950 font-bold text-xs font-mono rounded-xl cursor-pointer transition shadow-md uppercase tracking-wider"
                >
                  Enter Agency Staff Portal ({selectedStaffRole.toUpperCase()})
                </button>
              </div>
            )}

            {/* TAB CONTENT 3: ROSTER CREATOR */}
            {activePortalTab === 'creator' && (
              <div className="space-y-4 bg-[#051124] p-4 rounded-xl border border-white/10 animate-fade-in">
                <div>
                  <h4 className="text-sm font-bold text-purple-300 flex items-center gap-1.5 font-mono">
                    🎨 Represented Creator Portal
                  </h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Represented talent access to view active campaign briefs, deliverable checklists, pay rates, and content uploads.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-mono text-slate-400 block">Creator Handle or Email</label>
                  <input
                    type="text"
                    value={creatorInput}
                    onChange={(e) => setCreatorInput(e.target.value)}
                    placeholder="e.g. @elena or creator@agency.com"
                    className="w-full bg-[#0D1830] border border-white/15 rounded-xl p-2.5 text-xs text-white outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (onLogin) onLogin(creatorInput.includes('@') ? creatorInput : `${creatorInput}@creator.com`, 'creator');
                    setShowModal(false);
                  }}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs font-mono rounded-xl cursor-pointer transition shadow-md uppercase tracking-wider"
                >
                  Access Creator Dashboard ({creatorInput || '@talent'})
                </button>
              </div>
            )}

            {/* TAB CONTENT 4: SUB-AGENCY (ISOLATED POD) */}
            {activePortalTab === 'subagency' && (
              <div className="space-y-4 bg-[#051124] p-4 rounded-xl border border-white/10 animate-fade-in">
                <div>
                  <h4 className="text-sm font-bold text-blue-300 flex items-center gap-1.5 font-mono">
                    🏢 Sub-Agency Owner (Isolated Franchise / Pod)
                  </h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Independent sub-agency partners running their own isolated talent pod under master umbrella oversight.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-mono text-slate-400 block">Sub-Agency Pod Key or Domain</label>
                  <input
                    type="text"
                    value={subagencyInput}
                    onChange={(e) => setSubagencyInput(e.target.value)}
                    placeholder="e.g. pod_west_coast or glow_talent"
                    className="w-full bg-[#0D1830] border border-white/15 rounded-xl p-2.5 text-xs text-white outline-none focus:border-blue-400"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (onLogin) onLogin(`owner@${subagencyInput}.com`, 'subagency');
                    setShowModal(false);
                  }}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs font-mono rounded-xl cursor-pointer transition shadow-md uppercase tracking-wider"
                >
                  Access Sub-Agency Pod ({subagencyInput})
                </button>
              </div>
            )}

            {/* Footer Agency Signup Link */}
            {onStartAgencySignup && (
              <div className="pt-2 border-t border-white/10 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    onStartAgencySignup();
                  }}
                  className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
                >
                  Need a brand new agency workspace? Register here
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}

    </div>
  );
}
