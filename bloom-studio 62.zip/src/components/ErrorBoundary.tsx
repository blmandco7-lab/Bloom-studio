import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  private handleGoHome = () => {
    this.setState({ hasError: false, error: null });
    window.location.href = '/';
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#050C18] flex items-center justify-center p-6 font-sans">
          <div className="max-w-md w-full bg-[#111E33] border border-red-500/30 rounded-2xl p-8 text-center shadow-2xl">
            <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="text-red-500 w-8 h-8" />
            </div>
            
            <h1 className="text-2xl font-bold text-white mb-2">Something went wrong</h1>
            <p className="text-[#94A3B8] mb-8 leading-relaxed">
              An unexpected error occurred in the application. We've logged the incident and are working to fix it.
            </p>

            {/* Sanitized error reference (no raw error string exposure) */}
            <div className="bg-black/20 rounded-lg p-3 mb-6 text-center border border-white/5">
              <span className="text-[11px] text-slate-400 font-mono">
                Error Reference: ERR_CLIENT_RUNTIME_{Math.abs(this.state.error?.message.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) || 0).toString(16).toUpperCase()}
              </span>
            </div>

            <div className="flex flex-col gap-3">
              <button
                onClick={this.handleReset}
                className="w-full flex items-center justify-center gap-2 bg-[#C9A46A] hover:bg-[#B69359] text-[#050C18] font-semibold py-3 px-6 rounded-xl transition-all duration-200"
              >
                <RefreshCw size={18} />
                Reload Application
              </button>
              
              <button
                onClick={this.handleGoHome}
                className="w-full flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white font-medium py-3 px-6 rounded-xl transition-all duration-200 border border-white/10"
              >
                <Home size={18} />
                Return to Home
              </button>
            </div>

            <p className="mt-8 text-[11px] text-[#475569] uppercase tracking-widest">
              Bloom Studio OS • Recovery System
            </p>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
