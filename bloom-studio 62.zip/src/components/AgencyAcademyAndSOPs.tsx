import React, { useState } from 'react';
import { 
  BookOpen, Video, FileCheck, Search, ShieldCheck, CheckCircle2, 
  HelpCircle, Sparkles, ChevronRight, FileText, Download, Play, Users, Landmark, Tag, UserPlus, ExternalLink, X, Info,
  BarChart3, Settings, Bot, Truck, ShieldAlert, DollarSign, Briefcase, Award, FolderKanban
} from 'lucide-react';
import { Role } from '../types';
import { DEFAULT_KB_ARTICLES } from '../data/kbData';
import TrainingHub from './TrainingHub';

interface AgencyAcademyAndSOPsProps {
  currentRole: Role;
  onAskKB?: (question: string, targetId: string) => void;
  kbAnswer?: string;
  isKBLoading?: boolean;
  onNavigateToScreen?: (screenId: string) => void;
}

interface ButtonDoc {
  id: string;
  title: string;
  category: string;
  summary: string;
  whatItDoes: string;
  steps: string[];
  inputs: string[];
  output: string;
}

export default function AgencyAcademyAndSOPs({
  currentRole = 'director',
  onAskKB = () => {},
  kbAnswer = '',
  isKBLoading = false,
  onNavigateToScreen
}: AgencyAcademyAndSOPsProps) {
  const [activeTab, setActiveTab] = useState<'director-guide' | 'kb' | 'training' | 'sops'>('director-guide');
  const [kbSearchQuery, setKbSearchQuery] = useState('');
  const [directorSearchQuery, setDirectorSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeButtonDoc, setActiveButtonDoc] = useState<ButtonDoc | null>(null);

  const BUTTON_DOCS: Record<string, ButtonDoc> = {
    'director-dash': {
      id: 'director-dash',
      title: 'Director Dashboard',
      category: 'Executive Oversight',
      summary: 'Command center displaying live agency financial health, cash balances, and real-time revenue velocity.',
      whatItDoes: 'Provides top-level executive visibility over total agency earnings, active campaign volume, cash reserves via Stripe integration, and recent activity logs across all pods.',
      steps: [
        'Review the top summary cards for real-time cash balance and revenue metrics.',
        'Monitor incoming critical alerts from bot watchdog and payment gateways.',
        'Use quick actions to drill down into specific pod performance.'
      ],
      inputs: ['Stripe webhook feeds', 'Automated financial ledger logs', 'Pod transactional data'],
      output: 'Executive summary metrics and real-time agency health score.'
    },
    'roster': {
      id: 'roster',
      title: 'Creator Roster & Talent HQ',
      category: 'Talent Management',
      summary: 'Central talent database for managing creator profiles, social metrics, contracts, and payout statuses.',
      whatItDoes: 'Allows directors and managers to view all active creators, onboard new talent instantly with "Quick Add", assign dedicated agents, track exclusivity clauses, and manage direct deposit details.',
      steps: [
        'Click "Quick Add Creator" to onboard new talent with handle, category, and payout email.',
        'Click any creator profile to inspect contract status, W-9/1099 verification, and earnings escrow.',
        'Use batch actions to export CSV rosters or assign agents.'
      ],
      inputs: ['Creator name & handle', 'Social follower counts & Niche', 'Stripe Connect / Direct deposit info'],
      output: 'Active creator roster profile with verified compliance and escrow status.'
    },
    'brand-crm': {
      id: 'brand-crm',
      title: 'Brand CRM & Deal Pipeline',
      category: 'Sales & Partnerships',
      summary: 'Track brand partner inquiries, deal negotiation stages, status filters, and campaign budgets.',
      whatItDoes: 'Manages all inbound brand leads and active sponsorship deals. Features robust filtering by date range, deal status, and budget size to help managers prioritize incoming partner inquiries.',
      steps: [
        'Review incoming brand inquiries and lead briefs in the CRM table.',
        'Use the Date Range, Status (Lead, Negotiating, Signed, Closed), and Budget filters to sort deals efficiently.',
        'Click any deal to view deliverables, rate cards, and attached contracts.'
      ],
      inputs: ['Brand name & contact email', 'Campaign budget & deliverables', 'Proposed dates & rate cards'],
      output: 'Structured CRM database of brand partner relationships and active deal pipelines.'
    },
    'global-payroll': {
      id: 'global-payroll',
      title: 'Global Payroll & Escrow Hub',
      category: 'Finance & Payouts',
      summary: 'Secure Stripe escrow disbursement, W-9 verification, and net commission split engine.',
      whatItDoes: 'Handles agency financial settlement. Calculates 20% agency commission automatically, verifies W-9/1099 tax status, and securely disburses net creator earnings via Stripe Connect.',
      steps: [
        'Verify brand milestone sign-off and fund arrival in escrow.',
        'Check creator W-9 compliance status.',
        'Click "Disburse Funds" to transfer net earnings and automatically record transaction in financial ledger.'
      ],
      inputs: ['Brand milestone sign-off', 'Creator tax documentation (W-9)', 'Agreed commission percentage'],
      output: 'Verified payout receipts and automated commission split transfers.'
    },
    'onboarding-staff': {
      id: 'onboarding-staff',
      title: 'Agent & Staff Onboarding',
      category: 'Staff Management',
      summary: 'Provision staff credentials, assign roles (Agent, Manager, Coordinator), and configure secure pods.',
      whatItDoes: 'Onboards new agency personnel, assigns them to specific work pods, and establishes role-based access permissions across the platform.',
      steps: [
        'Click "Invite New Staff" to enter staff member details and select role.',
        'Assign staff to a specific Work Pod (e.g., Pod Alpha, Pod Beta).',
        'Verify permissions in User & Staff Management.'
      ],
      inputs: ['Staff name & email', 'Role assignment (Agent/Manager)', 'Work Pod designation'],
      output: 'Active staff account with role-guarded workspace permissions.'
    },
    'inbound-leads': {
      id: 'inbound-leads',
      title: 'Inbound Leads & Inquiries',
      category: 'Sales',
      summary: 'Receive and triage incoming brand campaign briefs and partnership proposals.',
      whatItDoes: 'Captures incoming brand interest from public intake forms, landing page VSLs, and direct partner submissions for director review and conversion.',
      steps: [
        'Review incoming brand proposals and budget specs.',
        'Run exclusivity and blacklist checks.',
        'Click "Convert to Deal" to send lead directly into Brand CRM and Deal Pipeline.'
      ],
      inputs: ['Brand brief details', 'Budget range & timeline', 'Contact person'],
      output: 'Qualified brand lead ready for rate quotation and contract issuance.'
    },
    'director-delegation': {
      id: 'director-delegation',
      title: 'Director Delegation & Security',
      category: 'Security & Controls',
      summary: 'Configure staff overrides, security restrictions, and cross-pod visibility permissions.',
      whatItDoes: 'Gives the Executive Director master control over agency-wide security settings, allowing or restricting staff access to cross-pod data.',
      steps: [
        'Adjust delegation toggles for staff override privileges.',
        'Review security policy enforcement logs.',
        'Save configuration to instantly update tenant security rules.'
      ],
      inputs: ['Security preference toggles', 'Superuser verification'],
      output: 'Enforced agency security configuration and pod isolation boundaries.'
    },
    'campaign-board': {
      id: 'campaign-board',
      title: 'Campaign Board & Workspace',
      category: 'Operations',
      summary: 'Manage active campaign deliverables, milestone tracking, and task assignments.',
      whatItDoes: 'Visual Kanban board for tracking campaign progression from briefing and content draft submission to brand review and final sign-off.',
      steps: [
        'Drag and drop campaign cards across stages (Briefed, Filming, Review, Completed).',
        'Assign creators and lead agents to specific campaign milestones.',
        'Check deadlines and compliance flags.'
      ],
      inputs: ['Campaign milestones', 'Creator deliverables', 'Deadline dates'],
      output: 'Organized campaign workflow status and completion trackers.'
    },
    'financial-contracts': {
      id: 'financial-contracts',
      title: 'Financial Contract Hub',
      category: 'Finance & Legal',
      summary: 'Secure storage vault for executed brand contracts, creator exclusivity agreements, and invoices.',
      whatItDoes: 'Maintains immutable digital copies of all signed contracts with cryptographic verification hashes and automated expiration alerts.',
      steps: [
        'Upload executed contract PDFs or generate via agreement wizard.',
        'Inspect contract terms, exclusivity windows, and licensing rights.',
        'Download signed audit trail reports.'
      ],
      inputs: ['Executed PDF documents', 'Party signatures', 'Effective date ranges'],
      output: 'Cryptographically secured contract vault with expiry tracking.'
    },
    'analytics-revenue': {
      id: 'analytics-revenue',
      title: 'Revenue Intelligence & Analytics',
      category: 'Executive Oversight',
      summary: 'Deep-dive charts and metrics on agency revenue velocity, creator ROI, and campaign margins.',
      whatItDoes: 'Aggregates financial and performance data into actionable charts, forecasting future revenue and highlighting top-performing pods.',
      steps: [
        'Select date range filters (30D, QTD, YTD).',
        'Analyze gross vs net margin splits and creator payout distributions.',
        'Export executive summary reports.'
      ],
      inputs: ['Transactional ledger data', 'Campaign budgets', 'Commission logs'],
      output: 'Comprehensive revenue charts and business intelligence reports.'
    },
    'content-library': {
      id: 'content-library',
      title: 'Content Review & Copyright Scanner',
      category: 'Content Review',
      summary: 'Scan uploaded creator videos for copyright audio infringements and FTC disclosure compliance.',
      whatItDoes: 'Runs automated AI checks on video submissions to ensure licensed audio tracks and clear #ad disclosure badges before brand delivery.',
      steps: [
        'Upload or select creator video draft.',
        'Run Automated Copyright & Sound Scan.',
        'Verify FTC badge placement and approve for brand vault release.'
      ],
      inputs: ['Video file (.mp4/.mov)', 'Audio track fingerprints'],
      output: 'Compliance clearance certificate and sound scan audit log.'
    },
    'fulfillment-hub': {
      id: 'fulfillment-hub',
      title: 'Sample Fulfillment & Gifting',
      category: 'Logistics',
      summary: 'Track product sample shipments, creator delivery receipts, and unboxing deadlines.',
      whatItDoes: 'Manages physical product logistics when brands ship samples to creators for review videos, logging carrier tracking numbers and arrival confirmations.',
      steps: [
        'Enter brand shipping tracking number (FedEx/UPS).',
        'Monitor arrival status and creator delivery confirmation.',
        'Trigger automated unboxing reminder notifications.'
      ],
      inputs: ['Carrier tracking code', 'Creator shipping address', 'Product item description'],
      output: 'Verified physical sample delivery confirmation and unboxing clock.'
    },
    'audit-logs': {
      id: 'audit-logs',
      title: 'System Audit Logs & Watchdog',
      category: 'Security & Controls',
      summary: 'Immutable chronological record of all system events, user logins, and financial disbursements.',
      whatItDoes: 'Provides complete transparency and security auditing across all staff actions, preventing unauthorized overrides and logging security events.',
      steps: [
        'Filter audit log by event type (Financial, Security, Admin).',
        'Inspect user ID, timestamp, and IP signature for any action.',
        'Export audit trail for compliance review.'
      ],
      inputs: ['System activity event streams', 'User authentication tokens'],
      output: 'Chronological security audit trail with cryptographic verification.'
    },
    'tax-compliance': {
      id: 'tax-compliance',
      title: 'W-9 & 1099 Tax Vault',
      category: 'Finance & Payouts',
      summary: 'Collect and verify tax documentation for creators and staff before disbursement.',
      whatItDoes: 'Ensures IRS compliance by storing verified W-9 forms, calculating annual earnings, and preparing 1099 generation data.',
      steps: [
        'Prompt creator/staff to submit digital W-9 via secure portal.',
        'Verify TIN/SSN format and signature validity.',
        'Approve for tax-cleared payout eligibility.'
      ],
      inputs: ['Digital W-9 form', 'Taxpayer Identification Number', 'Legal address'],
      output: 'Tax-verified payout eligibility status and documentation vault.'
    },
    'exclusivity-tracker': {
      id: 'exclusivity-tracker',
      title: 'Brand Exclusivity Tracker',
      category: 'Sales & Legal',
      summary: 'Monitor brand category exclusivity windows to prevent creator conflicts across competing sponsors.',
      whatItDoes: 'Cross-checks candidate creators against active brand agreements to ensure no conflicting competitor deals are signed during exclusivity periods.',
      steps: [
        'Input candidate creator and prospective brand category.',
        'Run Exclusivity Conflict Check.',
        'Review active cooling periods and restriction windows.'
      ],
      inputs: ['Creator ID', 'Brand industry category', 'Proposed campaign dates'],
      output: 'Conflict status report (Clear / Exclusivity Conflict Detected).'
    },
    'media-kits': {
      id: 'media-kits',
      title: 'Dynamic Media Kits & Match Decks',
      category: 'Sales',
      summary: 'Generate branded PDF pitch decks and live interactive media kits for prospective brand sponsors.',
      whatItDoes: 'Compiles real-time creator metrics, audience demographics, and past case studies into professional presentation kits.',
      steps: [
        'Select creator roster subset and target brand industry.',
        'Customize rate cards and package deliverables.',
        'Generate shareable live link or PDF export.'
      ],
      inputs: ['Creator IDs', 'Audience demographic data', 'Brand sponsor name'],
      output: 'Professional branded pitch deck and interactive talent match deck.'
    },
    'bot-hub': {
      id: 'bot-hub',
      title: 'AI Bot Control Panel & Logs',
      category: 'Automation',
      summary: 'Monitor automated outreach bots, scrapers, and AI agent activity streams.',
      whatItDoes: 'Controls background automation bots that assist with lead generation, contract reminders, and scheduling.',
      steps: [
        'Toggle bot execution states (Active / Paused).',
        'Inspect real-time execution logs and error alerts.',
        'Adjust bot parameters and rate limits.'
      ],
      inputs: ['Bot schedule configurations', 'Target keyword parameters'],
      output: 'Active automation status and real-time bot activity log.'
    },
    'pod-config': {
      id: 'pod-config',
      title: 'Work Pod Configuration',
      category: 'Settings',
      summary: 'Configure work pods, department partitions, and multi-pod management hierarchies.',
      whatItDoes: 'Manages organizational pod boundaries, allowing the agency to scale into multiple specialized pods while maintaining strict access partitioning.',
      steps: [
        'Create new work pod designation (e.g., Pod Gamma).',
        'Assign Pod Lead / Manager and member staff.',
        'Configure cross-pod visibility rules.'
      ],
      inputs: ['Pod name & description', 'Assigned staff members', 'Security partition rules'],
      output: 'Configured work pod environment with isolated team permissions.'
    }
  };

  const filteredArticles = DEFAULT_KB_ARTICLES.filter(art => {
    if (selectedCategory !== 'all' && art.category !== selectedCategory) return false;
    if (kbSearchQuery.trim()) {
      const q = kbSearchQuery.toLowerCase();
      return art.title.toLowerCase().includes(q) || art.content.toLowerCase().includes(q);
    }
    return true;
  });

  const filteredButtonDocs = Object.values(BUTTON_DOCS).filter(doc => {
    if (!directorSearchQuery.trim()) return true;
    const q = directorSearchQuery.toLowerCase();
    return (
      doc.title.toLowerCase().includes(q) ||
      doc.category.toLowerCase().includes(q) ||
      doc.summary.toLowerCase().includes(q) ||
      doc.whatItDoes.toLowerCase().includes(q) ||
      doc.inputs.some(inp => inp.toLowerCase().includes(q)) ||
      doc.output.toLowerCase().includes(q)
    );
  });

  const SOPS_LIST = [
    {
      id: 'sop_1',
      title: 'SOP-01: Inbound Brand Lead Qualification & Rate Quotation',
      category: 'Deals & Contracts',
      version: 'v3.2',
      summary: 'Step-by-step workflow for assessing incoming brand briefs, checking category exclusivity conflicts, and calculating gross rate cards.',
      steps: [
        'Ingest brand brief into Campaign Workspace and log contact lead in Brand CRM.',
        'Run Exclusivity Tracker check on candidate creators to prevent category conflict.',
        'Quote standardized CPM rate card with agency 20% commission buffer included.',
        'Generate and issue electronic deliverable agreement with mandatory FTC compliance clause.'
      ]
    },
    {
      id: 'sop_2',
      title: 'SOP-02: Creator Sample Fulfillment & Gifting Tracking',
      category: 'Logistics',
      version: 'v2.1',
      summary: 'Standard procedure for requesting merchandise samples, shipping tracking, and verification upon creator receipt.',
      steps: [
        'Confirm creator shipping address and phone number from verified Talent HQ file.',
        'Obtain carrier tracking code (FedEx/UPS/USPS) from brand partner.',
        'Log tracking node in Fulfillment Hub and send automatic SMS arrival alert.',
        'Verify unboxing within 48 hours to initiate production timeline clock.'
      ]
    },
    {
      id: 'sop_3',
      title: 'SOP-03: Content Draft Review, Sound Scanning & FTC Clearance',
      category: 'Content Review',
      version: 'v4.0',
      summary: 'Rigorous 3-point inspection protocol required before any video deliverable is cleared for brand review or public broadcast.',
      steps: [
        'Upload creator video file into AI Sound & Copyright Scanner to confirm commercial licensing.',
        'Inspect first 3 seconds and caption for conspicuous #ad / #sponsored disclosure.',
        'Verify resolution (1080x1920 min 9:16 vertical) and safe-zone margin compliance.',
        'Director or Lead Agent 1-click signs approval to release to brand review vault.'
      ]
    },
    {
      id: 'sop_4',
      title: 'SOP-04: Escrow Disbursement & Monthly Retainer Payouts',
      category: 'Finance',
      version: 'v2.8',
      summary: 'Escrow settlement procedures, W-9 verification, and payroll disbursement timeline.',
      steps: [
        'Confirm brand partner sign-off and milestone delivery acknowledgment in writing.',
        'Verify creator has an active W-9/1099 and valid direct deposit details on file.',
        'Deduct agency commission fee and transfer net talent earnings via Stripe Connect.',
        'Archive completed contract in Historical Campaign Vault with executive wrap-up report.'
      ]
    }
  ];

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto relative">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                UNIFIED AGENCY ACADEMY &amp; SOPS
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Verified Guidelines
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              Agency Academy &amp; SOPs
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Consolidated knowledge repository containing searchable FAQ guides, role-based video training curriculums, and standard operating procedures.
            </p>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('director-guide')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'director-guide'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Director Master Guide &amp; Button Explainer</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('kb')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'kb'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Knowledge Base</span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/20 font-mono">{DEFAULT_KB_ARTICLES.length}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('training')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'training'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Video className="w-4 h-4" />
          <span>Training Academy</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sops')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'sops'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Standard Operating Procedures (SOPs)</span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/20 font-mono">{SOPS_LIST.length}</span>
        </button>
      </div>

      {/* TAB CONTENT: Director Master Guide & Steps */}
      {activeTab === 'director-guide' && (
        <div className="space-y-6">
          <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-[#C9A46A]">
                  <Sparkles className="w-5 h-5" />
                  <h2 className="text-lg font-bold text-white">Executive Director Master Workflow &amp; Button Explainer Decoder</h2>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mt-1">
                  Type any button name, feature, or keyword in the search bar below, or click any button card to instantly inspect its exact purpose, required inputs, and execution steps.
                </p>
              </div>

              {/* Search Bar for Director Buttons */}
              <div className="relative w-full md:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search any button or feature..."
                  value={directorSearchQuery}
                  onChange={e => setDirectorSearchQuery(e.target.value)}
                  className="w-full bg-black/40 border border-[#C9A46A]/30 rounded-xl pl-10 pr-3 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-[#C9A46A] shadow-inner"
                />
              </div>
            </div>

            {/* Core vs Advanced Note */}
            <div className="bg-black/40 border border-white/10 rounded-xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-[#C9A46A] font-bold text-xs uppercase font-mono">
                <Info className="w-4 h-4" />
                <span>Director Navigation Tip: Do you need all those buttons?</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                <strong>No, you do not need every single button on a daily basis!</strong> While the system provides modular features for deep customization, your daily agency operations only require <strong>5 Core Buttons</strong>: (1) <strong className="text-white">Director Dashboard</strong> for cash flow, (2) <strong className="text-white">Creator Roster</strong> for talent management, (3) <strong className="text-white">Brand CRM</strong> for brand deals, (4) <strong className="text-white">Global Payroll &amp; Escrow</strong> for payouts, and (5) <strong className="text-white">Campaign Board</strong> for deliverables. All other buttons are optional advanced utilities.
              </p>
            </div>
          </div>

          {!directorSearchQuery.trim() && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Step 1: Onboarding Staff */}
              <div 
                onClick={() => setActiveButtonDoc(BUTTON_DOCS['onboarding-staff'])}
                className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A] rounded-2xl p-6 space-y-4 shadow-xl flex flex-col justify-between cursor-pointer transition group"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                      Step 1
                    </span>
                    <UserPlus className="w-5 h-5 text-[#C9A46A] group-hover:scale-110 transition" />
                  </div>
                  <h3 className="font-bold text-base text-white group-hover:text-[#C9A46A] transition flex items-center justify-between">
                    <span>Onboarding Staff &amp; Agents</span>
                    <Info className="w-3.5 h-3.5 text-[#C9A46A]" />
                  </h3>
                  <p className="text-xs text-slate-400">Click to inspect what staff onboarding buttons do.</p>

                  <ol className="space-y-2 text-xs text-slate-300 pt-2 border-t border-white/5">
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">1.</span>
                      <span>Click <strong className="text-white">Agent &amp; Staff Onboarding</strong> in sidebar.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">2.</span>
                      <span>Click <strong className="text-white">Invite New Staff</strong> to provision credentials.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">3.</span>
                      <span>Use <strong className="text-white">Director Delegation</strong> for overrides.</span>
                    </li>
                  </ol>
                </div>

                <div className="pt-4 border-t border-white/5 text-[10px] font-mono text-[#C9A46A] flex items-center justify-between">
                  <span>Click to View Button Breakdown</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>

              {/* Step 2: Onboarding Creators */}
              <div 
                onClick={() => setActiveButtonDoc(BUTTON_DOCS['roster'])}
                className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A] rounded-2xl p-6 space-y-4 shadow-xl flex flex-col justify-between cursor-pointer transition group"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                      Step 2
                    </span>
                    <Users className="w-5 h-5 text-[#C9A46A] group-hover:scale-110 transition" />
                  </div>
                  <h3 className="font-bold text-base text-white group-hover:text-[#C9A46A] transition flex items-center justify-between">
                    <span>Onboarding Creators &amp; Talent</span>
                    <Info className="w-3.5 h-3.5 text-[#C9A46A]" />
                  </h3>
                  <p className="text-xs text-slate-400">Click to inspect creator management buttons.</p>

                  <ol className="space-y-2 text-xs text-slate-300 pt-2 border-t border-white/5">
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">1.</span>
                      <span>Click <strong className="text-white">Creator Roster</strong> or <strong className="text-white">Talent HQ</strong>.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">2.</span>
                      <span>Click <strong className="text-white">Quick Add Creator</strong> for instant onboarding.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">3.</span>
                      <span>Review sign-ups in <strong className="text-white">Waitlist</strong> or <strong className="text-white">Inbound Leads</strong>.</span>
                    </li>
                  </ol>
                </div>

                <div className="pt-4 border-t border-white/5 text-[10px] font-mono text-[#C9A46A] flex items-center justify-between">
                  <span>Click to View Button Breakdown</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>

              {/* Step 3: Working with Brands & Deals */}
              <div 
                onClick={() => setActiveButtonDoc(BUTTON_DOCS['brand-crm'])}
                className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A] rounded-2xl p-6 space-y-4 shadow-xl flex flex-col justify-between cursor-pointer transition group"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                      Step 3
                    </span>
                    <Landmark className="w-5 h-5 text-[#C9A46A] group-hover:scale-110 transition" />
                  </div>
                  <h3 className="font-bold text-base text-white group-hover:text-[#C9A46A] transition flex items-center justify-between">
                    <span>Working with Brands &amp; Deals</span>
                    <Info className="w-3.5 h-3.5 text-[#C9A46A]" />
                  </h3>
                  <p className="text-xs text-slate-400">Click to inspect brand CRM &amp; escrow buttons.</p>

                  <ol className="space-y-2 text-xs text-slate-300 pt-2 border-t border-white/5">
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">1.</span>
                      <span>Check <strong className="text-white">Inbound Leads</strong> and use <strong className="text-white">Brand CRM</strong> filters.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">2.</span>
                      <span>Track progress in <strong className="text-white">Deal Pipeline</strong> &amp; <strong className="text-white">Campaign Board</strong>.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="font-mono text-[#C9A46A] font-bold">3.</span>
                      <span>Disburse via <strong className="text-white">Global Payroll &amp; Escrow</strong>.</span>
                    </li>
                  </ol>
                </div>

                <div className="pt-4 border-t border-white/5 text-[10px] font-mono text-[#C9A46A] flex items-center justify-between">
                  <span>Click to View Button Breakdown</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          )}

          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Tag className="w-4 h-4 text-[#C9A46A]" />
                Director Navigation Complete Button Decoder ({filteredButtonDocs.length} Buttons &amp; Features Available)
              </h3>
              {directorSearchQuery && (
                <button
                  type="button"
                  onClick={() => setDirectorSearchQuery('')}
                  className="text-xs text-[#C9A46A] hover:underline font-mono"
                >
                  Clear Search
                </button>
              )}
            </div>

            {filteredButtonDocs.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                No matching buttons or features found for &quot;{directorSearchQuery}&quot;. Try searching for &quot;payroll&quot;, &quot;roster&quot;, &quot;crm&quot;, &quot;escrow&quot;, &quot;tax&quot;, etc.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                {filteredButtonDocs.map(doc => (
                  <button
                    key={doc.id}
                    type="button"
                    onClick={() => setActiveButtonDoc(doc)}
                    className="bg-black/30 border border-white/5 hover:border-[#C9A46A] rounded-xl p-4 space-y-2 text-left cursor-pointer transition group flex flex-col justify-between"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono uppercase tracking-wider text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2 py-0.5 rounded-full">
                          {doc.category}
                        </span>
                        <Info className="w-3.5 h-3.5 text-[#C9A46A] group-hover:scale-125 transition" />
                      </div>
                      <h4 className="font-bold text-white text-sm group-hover:text-[#C9A46A] transition">{doc.title}</h4>
                      <p className="text-slate-300 line-clamp-2 leading-relaxed">{doc.summary}</p>
                    </div>

                    <div className="pt-2 border-t border-white/5 text-[10px] font-mono text-[#C9A46A] flex items-center justify-between">
                      <span>Click for Breakdown</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* BUTTON EXPLAINER MODAL */}
      {activeButtonDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#0B1528]">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 text-[#C9A46A] flex items-center justify-center">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                    {activeButtonDoc.category}
                  </span>
                  <h3 className="text-lg font-bold text-white mt-1">{activeButtonDoc.title}</h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveButtonDoc(null)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white flex items-center justify-center transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 overflow-y-auto">
              <div className="space-y-2">
                <h4 className="text-xs font-mono uppercase text-slate-400 font-bold">Purpose &amp; Function</h4>
                <p className="text-xs text-slate-200 leading-relaxed bg-black/30 border border-white/5 rounded-xl p-3.5">
                  {activeButtonDoc.whatItDoes}
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="text-xs font-mono uppercase text-slate-400 font-bold">Step-by-Step Execution</h4>
                <ol className="space-y-2 text-xs text-slate-200 bg-black/30 border border-white/5 rounded-xl p-3.5">
                  {activeButtonDoc.steps.map((st, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <span className="w-4 h-4 rounded-full bg-[#C9A46A]/20 text-[#C9A46A] flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{st}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 bg-black/30 border border-white/5 rounded-xl p-3.5">
                  <span className="text-[10px] font-mono uppercase text-slate-400 font-bold block">Required Inputs</span>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {activeButtonDoc.inputs.map((inp, idx) => (
                      <li key={idx} className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#C9A46A]"></span>
                        <span>{inp}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-1.5 bg-black/30 border border-white/5 rounded-xl p-3.5">
                  <span className="text-[10px] font-mono uppercase text-slate-400 font-bold block">Generated Output</span>
                  <p className="text-xs text-emerald-400 font-mono leading-relaxed">
                    {activeButtonDoc.output}
                  </p>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-white/10 bg-[#0B1528] flex justify-end">
              <button
                type="button"
                onClick={() => setActiveButtonDoc(null)}
                className="bg-[#C9A46A] hover:bg-[#b8935b] text-[#0A1220] px-5 py-2 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: Knowledge Base */}
      {activeTab === 'kb' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#0D1830] border border-white/10 rounded-xl p-3">
            <div className="relative flex-1 w-full">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search articles, guides, policies..."
                value={kbSearchQuery}
                onChange={e => setKbSearchQuery(e.target.value)}
                className="w-full bg-black/30 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={selectedCategory}
                onChange={e => setSelectedCategory(e.target.value)}
                className="bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
              >
                <option value="all">All Topics</option>
                <option value="ftc">FTC Compliance</option>
                <option value="pay">Payments &amp; Escrow</option>
                <option value="deals">Deals &amp; Casting</option>
                <option value="contracts">Contracts</option>
                <option value="agency">Agency Operations</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredArticles.map(art => (
              <div 
                key={art.id}
                className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-3 shadow-lg hover:border-[#C9A46A]/40 transition"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-[#C9A46A]">
                    {art.category}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">ID: {art.id}</span>
                </div>

                <h3 className="text-sm font-bold text-white leading-snug">{art.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{art.content}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: Training Hub */}
      {activeTab === 'training' && (
        <TrainingHub
          currentRole={currentRole}
          onAskKB={onAskKB}
          kbAnswer={kbAnswer}
          isKBLoading={isKBLoading}
        />
      )}

      {/* TAB CONTENT: SOPs */}
      {activeTab === 'sops' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {SOPS_LIST.map(sop => (
              <div 
                key={sop.id}
                className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-4 shadow-xl"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-2.5 py-0.5 rounded-full">
                      {sop.category} &bull; {sop.version}
                    </span>
                    <h3 className="text-base font-bold text-white mt-1">{sop.title}</h3>
                  </div>
                  <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Enforced SOP
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{sop.summary}</p>

                <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-2">
                  <span className="text-[10px] font-mono uppercase text-slate-400 block font-bold">Standard Execution Steps:</span>
                  <ol className="space-y-2 text-xs text-slate-200">
                    {sop.steps.map((step, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-[#C9A46A]/20 text-[#C9A46A] flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span className="leading-relaxed">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

