import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  QrCode, Camera, Upload, CheckCircle2, AlertCircle, RefreshCw, 
  Volume2, VolumeX, Sparkles, X, Package, Truck, User, 
  Layers, ArrowRight, History, Printer, Download, Search, Check,
  ChevronRight, ExternalLink, Zap
} from 'lucide-react';
import jsQR from 'jsqr';
import QRCode from 'qrcode';
import { FulfillmentItem, ProductShippingStage } from './FulfillmentHub';

export interface ScannedQRResult {
  rawText: string;
  matchedItem?: FulfillmentItem;
  extractedId?: string;
  extractedTracking?: string;
  extractedCreator?: string;
  extractedProduct?: string;
  extractedCarrier?: string;
  extractedStage?: ProductShippingStage;
  timestamp: string;
}

export interface ScanSessionLog {
  id: string;
  timestamp: string;
  rawText: string;
  productName: string;
  creatorHandle: string;
  trackingNumber: string;
  actionTaken: string;
  status: ProductShippingStage;
}

interface FulfillmentQRScannerModalProps {
  isOpen?: boolean;
  onClose: () => void;
  items: FulfillmentItem[];
  user?: any;
  userRole?: string;
  userName?: string;
  onUpdateItemStage: (itemId: string, newStage: ProductShippingStage, customData?: { trackingNumber?: string; carrier?: string; notes?: string }) => Promise<void> | void;
  onAddNewPackage?: (newPackage: Partial<FulfillmentItem>) => Promise<void> | void;
  onAddNewScannedPackage?: (newPackage: Partial<FulfillmentItem>) => Promise<void> | void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
}

export default function FulfillmentQRScannerModal({
  isOpen = true,
  onClose,
  items = [],
  user,
  userRole,
  userName,
  onUpdateItemStage,
  onAddNewPackage,
  onAddNewScannedPackage,
  triggerNotification
}: FulfillmentQRScannerModalProps) {
  const effectiveRole = userRole || user?.role || 'Agent';
  const effectiveName = userName || user?.name || user?.displayName || 'Agent';
  const handleAddNewPkg = onAddNewScannedPackage || onAddNewPackage;
  const [activeTab, setActiveTab] = useState<'camera' | 'upload' | 'simulate' | 'generator' | 'history'>('camera');
  
  // Camera scanning state
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [batchMode, setBatchMode] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

  // Scanning detection state
  const [lastScannedResult, setLastScannedResult] = useState<ScannedQRResult | null>(null);
  const [scannedHistory, setScannedHistory] = useState<ScanSessionLog[]>([]);
  const [scanCooldown, setScanCooldown] = useState(false);
  const [isProcessingUpdate, setIsProcessingUpdate] = useState(false);
  const [customNote, setCustomNote] = useState('');

  // Generator state
  const [generatorSelectedId, setGeneratorSelectedId] = useState<string>(items[0]?.id || '');
  const [generatedQRUrl, setGeneratedQRUrl] = useState<string>('');
  const [customQRText, setCustomQRText] = useState<string>('');

  // Audio beep feedback
  const playScanBeep = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(987.77, ctx.currentTime); // B5 note
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.16);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.16);
      }
    } catch (e) {
      // Audio context restricted or unavailable
    }
  }, [soundEnabled]);

  // QR Decoder & Matcher helper
  const parseQRContent = useCallback((raw: string): ScannedQRResult => {
    const trimmed = raw.trim();
    let extractedId: string | undefined;
    let extractedTracking: string | undefined;
    let extractedCreator: string | undefined;
    let extractedProduct: string | undefined;
    let extractedCarrier: string | undefined;
    let extractedStage: ProductShippingStage | undefined;

    // 1. Try parsing JSON format
    if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
      try {
        const parsed = JSON.parse(trimmed);
        extractedId = parsed.id || parsed.packageId || parsed.itemId;
        extractedTracking = parsed.trackingNumber || parsed.tracking || parsed.track;
        extractedCreator = parsed.creatorHandle || parsed.creator || parsed.handle;
        extractedProduct = parsed.productName || parsed.product;
        extractedCarrier = parsed.carrier;
        if (parsed.stage || parsed.shippingStage || parsed.status) {
          const s = parsed.stage || parsed.shippingStage || parsed.status;
          if (s === 'Received by Creator' || s === 'Shipped' || s === 'Sample Requested') {
            extractedStage = s;
          }
        }
      } catch (e) {
        // Not valid JSON, continue with pattern matching
      }
    }

    // 2. Try parsing URL query params if it's a URL
    if (trimmed.includes('?') || trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      try {
        const urlObj = new URL(trimmed.startsWith('http') ? trimmed : `https://bloom.agency/${trimmed}`);
        extractedId = urlObj.searchParams.get('id') || urlObj.searchParams.get('packageId') || extractedId;
        extractedTracking = urlObj.searchParams.get('track') || urlObj.searchParams.get('tracking') || urlObj.searchParams.get('tLabels') || extractedTracking;
        extractedCreator = urlObj.searchParams.get('creator') || urlObj.searchParams.get('handle') || extractedCreator;
        extractedProduct = urlObj.searchParams.get('product') || extractedProduct;
      } catch (e) {}
    }

    // 3. Prefix matching (e.g. "PKG-ful_1", "ROOM-...", "TRACK:1Z...")
    if (!extractedId && (trimmed.startsWith('ful_') || trimmed.startsWith('PKG-') || trimmed.startsWith('BLOOM-'))) {
      extractedId = trimmed.replace('PKG-', '').replace('BLOOM-', '');
    }

    // 4. Match against fulfillment roster
    const matchedItem = items.find(item => {
      // Direct ID match
      if (extractedId && item.id.toLowerCase() === extractedId.toLowerCase()) return true;
      if (item.id.toLowerCase() === trimmed.toLowerCase()) return true;

      // Tracking number match
      if (extractedTracking && item.trackingNumber && item.trackingNumber.trim().toLowerCase() === extractedTracking.trim().toLowerCase()) return true;
      if (item.trackingNumber && trimmed.toLowerCase().includes(item.trackingNumber.trim().toLowerCase())) return true;

      // Creator handle match
      if (extractedCreator) {
        const c1 = item.creatorHandle.toLowerCase().replace('@', '');
        const c2 = extractedCreator.toLowerCase().replace('@', '');
        if (c1 === c2) return true;
      }

      // Raw token match
      if (trimmed.toLowerCase().includes(item.id.toLowerCase())) return true;

      return false;
    });

    return {
      rawText: trimmed,
      matchedItem,
      extractedId: extractedId || matchedItem?.id,
      extractedTracking: extractedTracking || matchedItem?.trackingNumber,
      extractedCreator: extractedCreator || matchedItem?.creatorHandle,
      extractedProduct: extractedProduct || matchedItem?.productName,
      extractedCarrier: extractedCarrier || matchedItem?.carrier,
      extractedStage,
      timestamp: new Date().toLocaleTimeString()
    };
  }, [items]);

  // Handle successful QR detection
  const handleDecodedQR = useCallback((qrData: string) => {
    if (scanCooldown) return;

    setScanCooldown(true);
    playScanBeep();

    const parsed = parseQRContent(qrData);
    setLastScannedResult(parsed);

    if (batchMode && parsed.matchedItem) {
      // In batch mode, auto-mark as Received by Creator if not already
      onUpdateItemStage(parsed.matchedItem.id, 'Received by Creator');
      
      const newLog: ScanSessionLog = {
        id: 'scan_' + Date.now(),
        timestamp: new Date().toLocaleTimeString(),
        rawText: qrData,
        productName: parsed.matchedItem.productName,
        creatorHandle: parsed.matchedItem.creatorHandle,
        trackingNumber: parsed.matchedItem.trackingNumber,
        actionTaken: 'Auto-Updated to Received by Creator',
        status: 'Received by Creator'
      };
      setScannedHistory(prev => [newLog, ...prev]);

      if (triggerNotification) {
        triggerNotification(
          '📦 Package Verified & Updated',
          `Scanned ${parsed.matchedItem.creatorHandle}'s package (${parsed.matchedItem.productName}) - Marked as Received!`,
          'success'
        );
      }
    }

    // Cooldown to prevent double-scanning
    setTimeout(() => {
      setScanCooldown(false);
    }, batchMode ? 1800 : 1000);
  }, [batchMode, scanCooldown, parseQRContent, playScanBeep, onUpdateItemStage, triggerNotification]);

  // Camera video frame scanner loop
  const scanVideoFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current || videoRef.current.readyState < 2) {
      animFrameIdRef.current = requestAnimationFrame(scanVideoFrame);
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (ctx && video.videoWidth > 0 && video.videoHeight > 0) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'dontInvert'
      });

      if (code && code.data && code.data.trim()) {
        // Draw visual bounding box highlight on canvas
        ctx.beginPath();
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#10B981';
        ctx.moveTo(code.location.topLeftCorner.x, code.location.topLeftCorner.y);
        ctx.lineTo(code.location.topRightCorner.x, code.location.topRightCorner.y);
        ctx.lineTo(code.location.bottomRightCorner.x, code.location.bottomRightCorner.y);
        ctx.lineTo(code.location.bottomLeftCorner.x, code.location.bottomLeftCorner.y);
        ctx.closePath();
        ctx.stroke();

        handleDecodedQR(code.data);
      }
    }

    animFrameIdRef.current = requestAnimationFrame(scanVideoFrame);
  }, [handleDecodedQR]);

  // Start / Stop camera stream
  const startCamera = useCallback(async () => {
    setCameraError(null);
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }

      if (!navigator?.mediaDevices?.getUserMedia) {
        throw new Error("Camera API not supported in this browser environment.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true");
        await videoRef.current.play();
      }
      setCameraActive(true);
      animFrameIdRef.current = requestAnimationFrame(scanVideoFrame);
    } catch (err: any) {
      console.warn("Camera init note:", err);
      setCameraActive(false);
      setCameraError(
        err?.name === "NotAllowedError"
          ? "Camera permission was denied. Please allow camera access in browser settings or use the Photo Upload / Preset Simulator tabs below."
          : "Live camera stream unavailable in this context. You can upload package label photos or use the instant simulator."
      );
    }
  }, [facingMode, scanVideoFrame]);

  const stopCamera = useCallback(() => {
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  }, []);

  // Effect to manage camera lifecycle when modal opens/closes or tab changes
  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab, startCamera, stopCamera]);

  // File Upload QR Code Decoder
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        const offCanvas = document.createElement('canvas');
        offCanvas.width = img.width;
        offCanvas.height = img.height;
        const ctx = offCanvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imageData = ctx.getImageData(0, 0, offCanvas.width, offCanvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data) {
            handleDecodedQR(code.data);
            if (triggerNotification) {
              triggerNotification('✓ QR Code Scanned from Image', `Extracted label data: ${code.data.substring(0, 40)}...`, 'success');
            }
          } else {
            if (triggerNotification) {
              triggerNotification('No QR Code Found', 'Could not detect a valid QR code in the uploaded image. Please try another photo or crop closer to the QR code.', 'warning');
            }
          }
        }
      };
      img.src = ev.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Generate QR Label
  const generateLabelForSelected = useCallback(async (itemId: string, customPayload?: string) => {
    const targetItem = items.find(i => i.id === itemId) || items[0];
    const payload = customPayload || JSON.stringify({
      id: targetItem?.id || 'ful_sample',
      creatorHandle: targetItem?.creatorHandle || '@creator',
      productName: targetItem?.productName || 'Sample Box',
      trackingNumber: targetItem?.trackingNumber || '9400111899562537829102',
      carrier: targetItem?.carrier || 'USPS',
      niche: targetItem?.niche || 'Beauty',
      agency: 'Bloom Studio',
      generatedAt: new Date().toISOString()
    });

    try {
      const dataUrl = await QRCode.toDataURL(payload, {
        width: 380,
        margin: 2,
        color: {
          dark: '#0A1220',
          light: '#FFFFFF'
        },
        errorCorrectionLevel: 'M'
      });
      setGeneratedQRUrl(dataUrl);
    } catch (err) {
      console.error("Failed to generate QR:", err);
    }
  }, [items]);

  useEffect(() => {
    if (activeTab === 'generator') {
      const targetId = generatorSelectedId || items[0]?.id;
      if (targetId) {
        generateLabelForSelected(targetId);
      }
    }
  }, [activeTab, generatorSelectedId, items, generateLabelForSelected]);

  // Actions on Scanned Item
  const handleApplyStatusUpdate = async (stage: ProductShippingStage) => {
    if (!lastScannedResult) return;
    setIsProcessingUpdate(true);
    const targetId = lastScannedResult.matchedItem?.id || lastScannedResult.extractedId;

    try {
      if (targetId && lastScannedResult.matchedItem) {
        await onUpdateItemStage(targetId, stage, {
          trackingNumber: lastScannedResult.extractedTracking,
          notes: customNote
        });

        const newLog: ScanSessionLog = {
          id: 'scan_' + Date.now(),
          timestamp: new Date().toLocaleTimeString(),
          rawText: lastScannedResult.rawText,
          productName: lastScannedResult.matchedItem.productName,
          creatorHandle: lastScannedResult.matchedItem.creatorHandle,
          trackingNumber: lastScannedResult.matchedItem.trackingNumber,
          actionTaken: `Updated stage to: ${stage}`,
          status: stage
        };
        setScannedHistory(prev => [newLog, ...prev]);

        if (triggerNotification) {
          triggerNotification(
            '✓ Sample Record Updated',
            `${lastScannedResult.matchedItem.creatorHandle} — ${lastScannedResult.matchedItem.productName} updated to "${stage}"!`,
            'success'
          );
        }
      } else if (handleAddNewPkg) {
        // Create new package entry from scanned QR payload
        await handleAddNewPkg({
          creatorHandle: lastScannedResult.extractedCreator || '@creator',
          productName: lastScannedResult.extractedProduct || 'Scanned Package Sample',
          trackingNumber: lastScannedResult.extractedTracking || `TRK-${Date.now().toString().slice(-8)}`,
          carrier: lastScannedResult.extractedCarrier || 'USPS',
          shippingStage: stage,
          niche: 'Beauty'
        });

        if (triggerNotification) {
          triggerNotification(
            '✓ New Package Logged',
            `Created and marked package as "${stage}" for ${lastScannedResult.extractedCreator || '@creator'}!`,
            'success'
          );
        }
      }

      setCustomNote('');
    } catch (e) {
      console.error("Error applying status update:", e);
    } finally {
      setIsProcessingUpdate(false);
    }
  };

  const handlePrintLabel = () => {
    const printWin = window.open('', '_blank');
    if (!printWin) return;
    const targetItem = items.find(i => i.id === generatorSelectedId) || items[0];
    
    printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Package Shipping &amp; QR Tracking Label - ${targetItem?.id}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 20px; color: #111; }
            .label-card { border: 2px solid #000; border-radius: 12px; padding: 20px; max-width: 440px; margin: 0 auto; }
            .header { display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 12px; }
            .agency { font-size: 14px; font-weight: bold; text-transform: uppercase; letter-spacing: 1px; }
            .pkg-id { font-family: monospace; font-size: 13px; font-weight: bold; background: #eee; padding: 2px 6px; border-radius: 4px; }
            .body { display: flex; gap: 16px; align-items: center; }
            .qr-box img { width: 140px; height: 140px; border: 1px solid #ddd; }
            .meta { flex: 1; font-size: 12px; line-height: 1.5; }
            .meta strong { font-size: 13px; display: block; margin-top: 4px; }
            .footer { border-top: 1px dashed #999; margin-top: 14px; padding-top: 8px; font-size: 10px; text-align: center; color: #555; }
          </style>
        </head>
        <body>
          <div class="label-card">
            <div class="header">
              <span class="agency">BLOOM &amp; CO • FULFILLMENT</span>
              <span class="pkg-id">${targetItem?.id?.toUpperCase() || 'PKG-1'}</span>
            </div>
            <div class="body">
              <div class="qr-box">
                <img src="${generatedQRUrl}" alt="QR" />
              </div>
              <div class="meta">
                <div>CREATOR RECIPIENT:</div>
                <strong style="color: #000; font-size: 14px;">${targetItem?.creatorHandle || '@creator'}</strong>
                <div style="margin-top: 6px;">PRODUCT SAMPLE:</div>
                <strong>${targetItem?.productName || 'Package Box'}</strong>
                <div style="margin-top: 6px;">CARRIER &amp; TRACKING:</div>
                <div style="font-family: monospace; font-weight: bold;">${targetItem?.carrier} • ${targetItem?.trackingNumber || 'PENDING'}</div>
              </div>
            </div>
            <div class="footer">
              SCAN TO UPDATE SAMPLE STATUS • CONFIDENTIAL AGENCY PR GIFTING
            </div>
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `);
    printWin.document.close();
  };

  if (!isOpen) return null;

  return (
    <div
      id="fulfillment-qr-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        id="fulfillment-qr-modal-card"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-[#091222] border border-[#C9A46A]/50 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-slate-100 font-sans animate-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 bg-[#0E1A30] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#C9A46A]/20 text-[#C9A46A] flex items-center justify-center border border-[#C9A46A]/30 shrink-0 shadow-inner">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-serif font-bold text-white">QR Code Sample Scanner</h3>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live Optical Decoder
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Scan received package labels to immediately locate and update creator sample statuses.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? "Mute audio beep" : "Enable audio beep"}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                soundEnabled 
                  ? 'bg-emerald-950/60 border-emerald-500/30 text-emerald-300' 
                  : 'bg-white/5 border-white/10 text-slate-400'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-white/10 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-4 pt-3 flex items-center gap-1.5 border-b border-white/10 bg-[#0A1426] overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('camera')}
            className={`pb-2.5 px-3.5 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'camera'
                ? 'border-[#C9A46A] text-[#C9A46A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" /> Live Camera Scanner
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`pb-2.5 px-3.5 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'upload'
                ? 'border-[#C9A46A] text-[#C9A46A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-3.5 h-3.5" /> Upload Label Photo
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('simulate')}
            className={`pb-2.5 px-3.5 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'simulate'
                ? 'border-[#C9A46A] text-[#C9A46A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" /> Quick Package Presets
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('generator')}
            className={`pb-2.5 px-3.5 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'generator'
                ? 'border-[#C9A46A] text-[#C9A46A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Printer className="w-3.5 h-3.5" /> Generate &amp; Print QR Labels
          </button>
          {scannedHistory.length > 0 && (
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`pb-2.5 px-3.5 text-xs font-semibold border-b-2 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                activeTab === 'history'
                  ? 'border-[#C9A46A] text-[#C9A46A]'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <History className="w-3.5 h-3.5 text-sky-400" />
              <span>Session Log</span>
              <span className="ml-1 px-1.5 py-0.2 rounded-full bg-sky-500/20 text-sky-300 text-[10px] font-mono">
                {scannedHistory.length}
              </span>
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* TAB 1: LIVE CAMERA SCANNER */}
          {activeTab === 'camera' && (
            <div className="space-y-4">
              {/* Batch Mode Toggle Bar */}
              <div className="flex items-center justify-between bg-[#111E36] border border-white/10 rounded-2xl px-3.5 py-2 text-xs">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#C9A46A]" />
                  <span className="font-semibold text-slate-200">Continuous Batch Receiving Mode</span>
                  <span className="text-[10px] text-slate-400 hidden sm:inline">(Auto-marks scanned items as received)</span>
                </div>
                <button
                  type="button"
                  onClick={() => setBatchMode(!batchMode)}
                  className={`px-3 py-1 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer border ${
                    batchMode 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/20' 
                      : 'bg-white/5 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  {batchMode ? 'ON (Batch Mode)' : 'OFF (Review Mode)'}
                </button>
              </div>

              {/* Viewfinder Container */}
              <div className="relative w-full aspect-video sm:h-72 bg-black rounded-2xl overflow-hidden border border-[#C9A46A]/30 flex items-center justify-center shadow-inner">
                {cameraError ? (
                  <div className="p-5 text-center space-y-3 max-w-md">
                    <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                    <p className="text-xs text-amber-200 font-medium leading-relaxed">{cameraError}</p>
                    <div className="flex flex-wrap gap-2 justify-center pt-2">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 bg-[#C9A46A] hover:bg-[#b89358] text-[#0A1220] font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition shadow"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Package Photo</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveTab('simulate')}
                        className="px-4 py-2 bg-white/10 hover:bg-white/15 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition"
                      >
                        <Zap className="w-3.5 h-3.5 text-amber-400" />
                        <span>Use Quick Presets</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover"
                      playsInline
                      muted
                      autoPlay
                    />
                    <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

                    {/* Laser Scanner Reticle Overlay */}
                    <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                      <div className="w-48 sm:w-56 h-48 sm:h-56 border-2 border-dashed border-[#C9A46A]/80 rounded-2xl relative flex items-center justify-center bg-black/20 backdrop-blur-[1px]">
                        {/* Corner markers */}
                        <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-emerald-400 rounded-tl-lg" />
                        <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-emerald-400 rounded-tr-lg" />
                        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-emerald-400 rounded-bl-lg" />
                        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-emerald-400 rounded-br-lg" />

                        {/* Animated Laser Scanning Line */}
                        <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_#34D399] animate-pulse" />

                        <div className="absolute bottom-2 text-[10px] font-mono text-emerald-300 font-bold bg-black/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                          {scanCooldown ? "SCAN REGISTERED" : "ALIGN QR LABEL"}
                        </div>
                      </div>
                    </div>

                    {/* Camera Control Overlay */}
                    <div className="absolute top-3 right-3 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setFacingMode(prev => prev === 'environment' ? 'user' : 'environment');
                        }}
                        className="px-2.5 py-1.5 rounded-xl bg-black/60 hover:bg-black/80 text-slate-200 border border-white/20 text-[11px] font-mono flex items-center gap-1.5 backdrop-blur-sm cursor-pointer transition"
                      >
                        <RefreshCw className="w-3 h-3 text-[#C9A46A]" />
                        <span>Flip Cam</span>
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: UPLOAD LABEL PHOTO */}
          {activeTab === 'upload' && (
            <div className="space-y-4">
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-[#C9A46A]/40 hover:border-[#C9A46A] bg-[#0E1B2E]/60 hover:bg-[#0E1B2E] rounded-3xl p-8 text-center cursor-pointer transition-all space-y-3 group"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#C9A46A]/10 border border-[#C9A46A]/30 text-[#C9A46A] flex items-center justify-center mx-auto group-hover:scale-105 transition-transform">
                  <Upload className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Click or Drag &amp; Drop Package Label Photo</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Supports PNG, JPG, or WEBP photos of shipping slips, USPS/UPS labels, and creator box tags.
                  </p>
                </div>
                <span className="inline-block text-[11px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 px-3 py-1 rounded-full border border-[#C9A46A]/20">
                  Select File from Device
                </span>
              </div>
            </div>
          )}

          {/* TAB 3: QUICK PRESET SIMULATOR */}
          {activeTab === 'simulate' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>Select any active creator shipment to simulate scanning its barcode/QR label:</span>
                <span className="text-[10px] font-mono text-[#C9A46A]">{items.length} Packages in Roster</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-72 overflow-y-auto pr-1">
                {items.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      const payload = JSON.stringify({
                        id: item.id,
                        creatorHandle: item.creatorHandle,
                        productName: item.productName,
                        trackingNumber: item.trackingNumber,
                        carrier: item.carrier,
                        niche: item.niche
                      });
                      handleDecodedQR(payload);
                    }}
                    className="p-3 bg-[#0F1D33] hover:bg-[#152744] border border-white/10 hover:border-[#C9A46A]/50 rounded-2xl transition-all cursor-pointer flex items-center justify-between group"
                  >
                    <div className="space-y-0.5 min-w-0 pr-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs text-white truncate">{item.creatorHandle}</span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-white/5 text-slate-400 border border-white/10">
                          {item.carrier}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 truncate">{item.productName}</p>
                      <div className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                        <span>Trk: {item.trackingNumber || 'Pending'}</span>
                      </div>
                    </div>
                    <div className="shrink-0 flex items-center gap-1 text-[11px] font-mono text-[#C9A46A] group-hover:translate-x-0.5 transition-transform">
                      <span className="hidden sm:inline">Scan</span>
                      <Zap className="w-3.5 h-3.5" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: GENERATE & PRINT QR LABELS */}
          {activeTab === 'generator' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-start">
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Select Package to Generate Shipping Label QR:
                    </label>
                    <select
                      value={generatorSelectedId}
                      onChange={(e) => {
                        setGeneratorSelectedId(e.target.value);
                        generateLabelForSelected(e.target.value);
                      }}
                      className="w-full bg-[#111E36] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3 py-2 text-xs text-white font-mono outline-none"
                    >
                      {items.map(i => (
                        <option key={i.id} value={i.id}>
                          {i.creatorHandle} — {i.productName} ({i.trackingNumber || 'No Trk'})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Or Custom Barcode / Tracking ID:
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={customQRText}
                        onChange={(e) => setCustomQRText(e.target.value)}
                        placeholder="e.g. 9400111899562537829102"
                        className="flex-1 bg-[#111E36] border border-white/10 focus:border-[#C9A46A] rounded-xl px-3 py-2 text-xs text-white font-mono outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (customQRText.trim()) {
                            generateLabelForSelected('', customQRText.trim());
                          }
                        }}
                        className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl cursor-pointer"
                      >
                        Generate
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={handlePrintLabel}
                      disabled={!generatedQRUrl}
                      className="px-4 py-2.5 bg-[#C9A46A] hover:bg-[#b89358] text-[#0A1220] font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow transition"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Print Label Badge</span>
                    </button>
                    {generatedQRUrl && (
                      <a
                        href={generatedQRUrl}
                        download={`QR-Label-${generatorSelectedId || 'Package'}.png`}
                        className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer transition"
                      >
                        <Download className="w-4 h-4" />
                        <span>Download PNG</span>
                      </a>
                    )}
                  </div>
                </div>

                {/* QR Code Preview Card */}
                <div className="bg-[#050C17] border border-white/10 rounded-2xl p-4 text-center space-y-3">
                  <div className="text-[11px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider">
                    Official Bloom &amp; Co Package Label
                  </div>
                  {generatedQRUrl ? (
                    <div className="bg-white p-3 rounded-xl inline-block shadow-lg">
                      <img src={generatedQRUrl} alt="Generated QR" className="w-40 h-40 object-contain mx-auto" />
                    </div>
                  ) : (
                    <div className="w-40 h-40 bg-white/5 rounded-xl mx-auto flex items-center justify-center text-xs text-slate-500 font-mono">
                      Generating...
                    </div>
                  )}
                  <p className="text-[11px] text-slate-400 font-mono">
                    Affix to packaging slip for instant scanner recognition.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: SESSION HISTORY LOG */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-white/10 pb-2">
                <span>Scanned packages in current session:</span>
                <button
                  type="button"
                  onClick={() => setScannedHistory([])}
                  className="text-rose-400 hover:text-rose-300 font-mono text-[11px] cursor-pointer"
                >
                  Clear Session History
                </button>
              </div>

              <div className="space-y-2 max-h-72 overflow-y-auto">
                {scannedHistory.map(log => (
                  <div key={log.id} className="p-3 bg-[#0F1D33] border border-white/10 rounded-xl flex items-center justify-between text-xs font-mono">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-bold">{log.creatorHandle}</span>
                        <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/20">
                          {log.status}
                        </span>
                      </div>
                      <p className="text-slate-300 font-sans">{log.productName}</p>
                      <span className="text-slate-500 text-[10px]">{log.trackingNumber}</span>
                    </div>
                    <div className="text-right text-slate-400 text-[10px]">
                      <div>{log.timestamp}</div>
                      <div className="text-[#C9A46A]">{log.actionTaken}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* LAST SCANNED RESULT ACTION CARD */}
          {lastScannedResult && (
            <div className="bg-[#060F1E] border-2 border-emerald-500/50 rounded-2xl p-4 space-y-3 shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-150">
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-mono font-bold text-emerald-300 uppercase tracking-wider">
                      Scanned Package Detected
                    </h4>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Timestamp: {lastScannedResult.timestamp}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                    Status: {lastScannedResult.matchedItem?.shippingStage || 'Unregistered'}
                  </span>
                </div>
              </div>

              {/* Package Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-[#091529] p-3 rounded-xl border border-white/5">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400">Creator Recipient</span>
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-[#C9A46A]" />
                    <span>{lastScannedResult.matchedItem?.creatorHandle || lastScannedResult.extractedCreator || '@unknown_creator'}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400">Product Sample</span>
                  <div className="font-semibold text-slate-200 flex items-center gap-1.5 truncate">
                    <Package className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span className="truncate">{lastScannedResult.matchedItem?.productName || lastScannedResult.extractedProduct || 'Product Sample Item'}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400">Carrier &amp; Tracking</span>
                  <div className="font-mono text-slate-300 flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{lastScannedResult.matchedItem?.carrier || lastScannedResult.extractedCarrier || 'Carrier'} • {lastScannedResult.matchedItem?.trackingNumber || lastScannedResult.extractedTracking || 'No Tracking #'}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400">Campaign Niche</span>
                  <div className="font-mono text-[#C9A46A]">
                    {lastScannedResult.matchedItem?.niche || 'Beauty / Lifestyle'}
                  </div>
                </div>
              </div>

              {/* Custom Note Input */}
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 font-mono">
                  Package Condition / Arrival Notes (Optional):
                </label>
                <input
                  type="text"
                  value={customNote}
                  onChange={(e) => setCustomNote(e.target.value)}
                  placeholder="e.g., Box in perfect condition, verified by agent"
                  className="w-full bg-[#0D182A] border border-white/10 focus:border-emerald-400 rounded-xl px-3 py-1.5 text-xs text-white outline-none font-sans"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => handleApplyStatusUpdate('Received by Creator')}
                  disabled={isProcessingUpdate}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg cursor-pointer transition disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Mark as Received by Creator (Arrived)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleApplyStatusUpdate('Shipped')}
                  disabled={isProcessingUpdate}
                  className="py-2.5 px-3.5 rounded-xl bg-sky-950 hover:bg-sky-900 border border-sky-500/40 text-sky-200 font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition disabled:opacity-50"
                >
                  <Truck className="w-3.5 h-3.5 text-sky-400" />
                  <span>Set as Shipped</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleApplyStatusUpdate('Sample Requested')}
                  disabled={isProcessingUpdate}
                  className="py-2.5 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-semibold text-xs cursor-pointer transition disabled:opacity-50"
                >
                  <span>Reset to Requested</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3.5 sm:p-4 bg-[#070E1A] border-t border-white/10 flex items-center justify-between text-xs text-slate-400 font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Agent Scanner: {userName} ({userRole})</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold cursor-pointer transition"
          >
            Done / Close
          </button>
        </div>
      </div>
    </div>
  );
}
