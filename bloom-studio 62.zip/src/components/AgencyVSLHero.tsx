import React, { useState } from 'react';
import { Sparkles, Video, Copy, Check, Upload, ArrowRight, Wand2, FileText, Send, ShieldCheck, Download } from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';

interface AgencyPitchGeneratorProps {
  vslVideoUrl?: string;
  setVslVideoUrl?: (url: string) => void;
  currentUser?: any;
  currentRole?: string;
  onNavigate?: (screenId: string) => void;
}

export const AgencyVSLHero: React.FC<AgencyPitchGeneratorProps> = ({
  vslVideoUrl = '',
  setVslVideoUrl,
  currentUser,
  currentRole
}) => {
  const [brandName, setBrandName] = useState('');
  const [productNiche, setProductNiche] = useState('Beauty & Skincare');
  const [targetAudience, setTargetAudience] = useState('Gen-Z / Millennial Shoppers');
  const [pitchAngle, setPitchAngle] = useState('High-converting UGC & authentic social proof');
  const [generatedScript, setGeneratedScript] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const isPlatformOwner = Boolean(
    currentUser?.isPlatformOwner ||
    currentUser?.email === 'lilbitnd06@gmail.com' ||
    currentUser?.role === 'owner'
  );
  const userRole = (currentRole || currentUser?.role || '').toLowerCase();
  const isDirector = isPlatformOwner || userRole === 'director' || userRole === 'agency' || userRole === 'super_admin';

  const handleVslUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && setVslVideoUrl) {
      const videoUrl = URL.createObjectURL(file);
      setVslVideoUrl(videoUrl);
      try {
        safeStorage.setItem('bloom_vsl_video_url', videoUrl);
      } catch (err) {
        console.error('Failed to save VSL video:', err);
      }
    }
  };

  const handleGenerateScript = (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    setTimeout(() => {
      const brand = brandName ? brandName.trim() : 'Your Brand';
      const niche = productNiche || 'Beauty & Skincare';
      const audience = targetAudience || 'Gen-Z & Millennial Shoppers';
      const angle = pitchAngle || 'High-converting UGC';

      // Generate distinct hook variations based on niche & brand hash
      const hooks = [
        `"Hey ${brand} team — we analyzed your recent ad spend in ${niche}. Your hooks are solid, but retention drops by 45% after second 3 because your creators lack authentic macro skin texture and raw storytelling."`,
        `"Quick question for the growth team at ${brand}: how much revenue are you losing each month to unvetted creators who miss deadlines and deliver low-res footage for ${audience}?"`,
        `"We spotted your ${niche} campaigns running on Meta and TikTok. While your CTR is strong, your whitelisting permissions are capped due to lack of direct FTC compliance agreements."`,
        `"Most ${niche} brands scaling past 7-figures hit a wall with creator churn. At ${brand}, you need a managed roster that guarantees replacement assets within 48 hours."`
      ];

      const solutions = [
        `"Bloom Studio deploys a fully vetted pod of verified creators targeting ${audience}. Utilizing our proprietary DAPS asset protection and raw 4K licensing pipeline, we eliminate scammer risk while doubling your monthly output of ${angle} ad variations."`,
        `"We bridge the gap between elite ${niche} creators and performance marketing teams. By pairing ${brand} with exclusive talent bound by strict exclusivity and performance retainers, your ad accounts gain stable, predictable scaling."`,
        `"Our infrastructure handles everything from contracts and W-9 collection to raw asset staging and FTC verification. We supply ${brand} with pre-vetted ${audience} creators who specialize in high-converting ${angle}."`
      ];

      const ctas = [
        `"Ready to upgrade your ad creative pipeline? Let's deploy a 3-creator test pod for ${brand} this week with zero upfront exclusivity lock-in. Click below to review our verified roster."`,
        `"Let's schedule a 15-minute creative teardown for ${brand}. We'll audit your current ${niche} funnels and show you our exact creator performance benchmarks. Tap below to book your slot."`,
        `"Secure your Q4 ad inventory for ${brand} today. Let's map out your custom ${niche} creator roster and launch your first batch of verified deliverables."`
      ];

      // Pseudo-random selection based on string length to ensure variety
      const hookIndex = (brand.length + niche.length) % hooks.length;
      const solIndex = (audience.length + angle.length) % solutions.length;
      const ctaIndex = (brand.length * 3) % ctas.length;

      const script = `[EXECUTIVE VSL & OUTREACH PITCH: ${brand.toUpperCase()} x BLOOM STUDIO]
Target Niche: ${niche} | Core Audience: ${audience} | Strategy: ${angle}

0:00 - 0:20 | THE STRATEGIC HOOK:
${hooks[hookIndex]}

0:20 - 0:55 | THE INFRASTRUCTURE SOLUTION:
${solutions[solIndex]}

0:55 - 1:30 | THE VALUE & ROI PROJECTION:
"By eliminating middlemen and deploying dedicated agent managers for ${brand}, we reduce production overhead by 35% while increasing hook conversion rates across all ${niche} channels."

1:30 - 2:00 | CALL TO ACTION:
${ctas[ctaIndex]}`;

      setGeneratedScript(script);
      setIsGenerating(false);
    }, 800);
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(generatedScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 font-sans text-slate-100">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#142850] to-[#0B1B3D] border border-[#D4AF37]/30 rounded-3xl p-8 mb-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0B1B3D] border border-[#D4AF37]/40 text-xs font-mono text-[#D4AF37] mb-4">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>AI PITCH &amp; VSL SCRIPT GENERATOR</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-serif font-bold text-white tracking-tight mb-3">
            Agency Pitch &amp; VSL Command Center
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Generate custom tailored outreach scripts, video pitch hooks, and manage your core agency video sales letter (VSL) assets for brand acquisition.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Pitch Generator Form */}
        <div className="lg:col-span-1 bg-[#142850]/80 border border-[#D4AF37]/20 rounded-2xl p-6 shadow-xl space-y-6">
          <h2 className="text-lg font-serif font-bold text-white flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-[#D4AF37]" />
            <span>Configure Brand Pitch</span>
          </h2>

          <form onSubmit={handleGenerateScript} className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1.5 uppercase tracking-wider">Target Brand Name</label>
              <input
                type="text"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="e.g. Glossier, Gymshark..."
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1.5 uppercase tracking-wider">Product Niche</label>
              <select
                value={productNiche}
                onChange={(e) => setProductNiche(e.target.value)}
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="Beauty & Skincare">Beauty &amp; Skincare</option>
                <option value="Pets & Canine Wellness">Pets &amp; Canine Wellness</option>
                <option value="Luxury Lifestyle & Home">Luxury Lifestyle &amp; Home</option>
                <option value="Fitness & Apparel">Fitness &amp; Apparel</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1.5 uppercase tracking-wider">Target Audience</label>
              <input
                type="text"
                value={targetAudience}
                onChange={(e) => setTargetAudience(e.target.value)}
                placeholder="e.g. Gen-Z women 18-30..."
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-slate-300 mb-1.5 uppercase tracking-wider">Primary Pitch Angle</label>
              <input
                type="text"
                value={pitchAngle}
                onChange={(e) => setPitchAngle(e.target.value)}
                placeholder="e.g. FTC compliant whitelisting..."
                className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <button
              type="submit"
              disabled={isGenerating}
              className="w-full bg-gradient-to-r from-[#F2A104] to-[#D4AF37] hover:from-[#e59803] hover:to-[#c3a032] text-[#0B1B3D] font-bold py-3 px-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer text-sm font-mono tracking-wide"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-[#0B1B3D] border-t-transparent rounded-full animate-spin" />
                  <span>GENERATING SCRIPT...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>GENERATE TAILORED PITCH</span>
                </>
              )}
            </button>
          </form>

          {/* VSL Video Management for Directors */}
          {isDirector && (
            <div className="pt-6 border-t border-white/10 space-y-3">
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
                <Video className="w-4 h-4" />
                <span>Director VSL Video Asset</span>
              </h3>
              <p className="text-xs text-slate-400">Upload your master pitch video to be featured in executive proposals.</p>
              <label className="flex items-center justify-center gap-2 bg-[#0B1B3D] hover:bg-[#07132a] text-white px-4 py-3 rounded-xl border border-dashed border-[#D4AF37]/40 cursor-pointer transition-colors text-xs font-bold">
                <Upload className="w-4 h-4 text-[#D4AF37]" />
                <span>{vslVideoUrl ? 'Replace Pitch Video File' : 'Upload Pitch Video (.mp4)'}</span>
                <input type="file" accept="video/*" onChange={handleVslUpload} className="hidden" />
              </label>
              {vslVideoUrl && (
                <div className="text-[11px] text-emerald-400 font-mono flex items-center gap-1.5 pt-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>Master VSL video loaded &amp; ready</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Generated Script Output & VSL Preview */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-[#142850]/80 border border-white/10 rounded-2xl p-6 shadow-xl relative">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-white/10">
              <h3 className="text-sm font-mono uppercase tracking-wider text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#D4AF37]" />
                <span>Generated Pitch &amp; VSL Script Output</span>
              </h3>
              {generatedScript && (
                <button
                  onClick={handleCopyScript}
                  className="flex items-center gap-1.5 bg-[#0B1B3D] hover:bg-[#1f386c] text-[#D4AF37] px-3 py-1.5 rounded-lg text-xs font-mono border border-[#D4AF37]/30 transition-all cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'COPIED!' : 'COPY SCRIPT'}</span>
                </button>
              )}
            </div>

            {generatedScript ? (
              <div className="bg-[#0B1B3D] border border-white/10 rounded-xl p-6 font-mono text-xs sm:text-sm text-slate-200 whitespace-pre-wrap leading-relaxed max-h-[350px] overflow-y-auto">
                {generatedScript}
              </div>
            ) : (
              <div className="text-center py-16 text-slate-400 font-mono text-xs space-y-3">
                <Wand2 className="w-8 h-8 text-[#D4AF37]/40 mx-auto animate-pulse" />
                <p>Configure your target brand parameters on the left and click Generate Tailored Pitch.</p>
              </div>
            )}
          </div>

          {/* Current Master VSL Preview Box */}
          <div className="bg-[#142850]/80 border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-mono uppercase tracking-wider text-white flex items-center gap-2">
              <Video className="w-4 h-4 text-[#D4AF37]" />
              <span>Active VSL Video Preview</span>
            </h3>

            <div className="relative aspect-video bg-black rounded-xl overflow-hidden border border-white/10 shadow-inner">
              {vslVideoUrl ? (
                <video src={vslVideoUrl} controls className="w-full h-full object-cover" />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 font-mono text-xs p-4 text-center">
                  <Video className="w-10 h-10 mb-2 opacity-30" />
                  <p>No master pitch video uploaded yet.</p>
                  <p className="text-[10px] text-slate-600 mt-1">Directors can upload an mp4 video using the panel on the left.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgencyVSLHero;
