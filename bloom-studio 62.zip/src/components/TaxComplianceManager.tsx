import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, 
  Download, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Eye, 
  Loader2, 
  RefreshCw, 
  FileSignature, 
  X, 
  Lock, 
  Info,
  Calendar,
  Building2,
  UserCheck
} from 'lucide-react';
import { db, storage } from '../lib/firebase';
import { doc, setDoc, onSnapshot, getDoc } from 'firebase/firestore';
import { generateOfficialW9Pdf, W9FormData } from '../lib/w9PdfGenerator';
import MultiFilePdfViewerModal, { ViewableFile } from './DocumentViewerModal';
import { safeStorage } from '../utils/safeStorage';

interface TaxComplianceManagerProps {
  creatorHandle: string;
  creatorName: string;
  creatorId: string;
  triggerNotification?: (title: string, message: string, type?: string) => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  matchingCreator?: any;
}

export const TaxComplianceManager: React.FC<TaxComplianceManagerProps> = ({
  creatorHandle,
  creatorName,
  creatorId,
  triggerNotification: externalNotification,
  onAddActivityLog: externalActivityLog,
  matchingCreator
}) => {
  const [w9Uploaded, setW9Uploaded] = useState<boolean>(false);
  const [w9FileName, setW9FileName] = useState<string>('IRS_Form_W9_Signed.pdf');
  const [w9FileSize, setW9FileSize] = useState<string>('148 KB');
  const [w9Status, setW9Status] = useState<string>('Not Submitted');
  const [w9UploadedAt, setW9UploadedAt] = useState<string>('');
  const [w9FileData, setW9FileData] = useState<string>('');
  const [w9FileUrl, setW9FileUrl] = useState<string>('');
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<string>('');
  
  // Local notification banner
  const [localNotification, setLocalNotification] = useState<{ title: string; message: string; type: 'success' | 'danger' | 'info' } | null>(null);

  // Document Viewer Modal
  const [viewerOpen, setViewerOpen] = useState<boolean>(false);
  const [viewerFiles, setViewerFiles] = useState<ViewableFile[]>([]);

  // Interactive Online W-9 Generator / E-sign Modal
  const [showSignModal, setShowSignModal] = useState<boolean>(false);
  const [signFormData, setSignFormData] = useState<W9FormData>({
    legalName: creatorName || '',
    businessName: '',
    taxClassification: 'Individual/sole proprietor or single-member LLC',
    llcTaxClassification: 'S',
    address: '742 Evergreen Terrace',
    cityStateZip: 'Los Angeles, CA 90028',
    tinType: 'SSN',
    tinNumber: '123-45-6789',
    signatureName: creatorName || '',
    creatorHandle: creatorHandle || ''
  });
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const notify = (title: string, message: string, type: 'success' | 'danger' | 'info' = 'info') => {
    if (externalNotification) {
      externalNotification(title, message, type);
    }
    setLocalNotification({ title, message, type });
    setTimeout(() => {
      setLocalNotification(null);
    }, 6000);
  };

  const logActivity = (action: string) => {
    if (externalActivityLog) {
      externalActivityLog(creatorName || creatorHandle, 'creator', action);
    }
  };

  useEffect(() => {
    if (!db) return;
    const cleanHandle = creatorHandle.replace(/[@.]/g, '_');
    const w9DocId = `w9_${cleanHandle}`;

    const unsub = onSnapshot(doc(db, 'studio-w9-forms', w9DocId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.w9Status) setW9Status(data.w9Status);
        if (data.fileName) setW9FileName(data.fileName);
        if (data.fileSize) setW9FileSize(data.fileSize);
        if (data.uploadedAt) setW9UploadedAt(data.uploadedAt);
        if (data.fileData) setW9FileData(data.fileData);
        if (data.fileUrl || data.storageUrl) setW9FileUrl(data.fileUrl || data.storageUrl);
        if (data.w9Status === 'Verified' || data.w9Status === 'Submitted') {
          setW9Uploaded(true);
        }
      } else {
        // Check cleanHandle directly as fallback
        getDoc(doc(db, 'studio-w9-forms', cleanHandle)).then((altSnap) => {
          if (altSnap.exists()) {
            const data = altSnap.data();
            if (data.w9Status) setW9Status(data.w9Status);
            if (data.fileName) setW9FileName(data.fileName);
            if (data.fileSize) setW9FileSize(data.fileSize);
            if (data.uploadedAt) setW9UploadedAt(data.uploadedAt);
            if (data.fileData) setW9FileData(data.fileData);
            if (data.fileUrl || data.storageUrl) setW9FileUrl(data.fileUrl || data.storageUrl);
            if (data.w9Status === 'Verified' || data.w9Status === 'Submitted') {
              setW9Uploaded(true);
            }
          }
        }).catch(() => {});
      }
    });

    return () => unsub();
  }, [creatorHandle]);

  // Persist file substantive data to backend & Firestore
  const persistTaxDocument = async (fileName: string, fileSizeStr: string, dataUrl: string) => {
    const cleanHandle = creatorHandle.replace(/[@.]/g, '_');
    const w9DocId = `w9_${cleanHandle}`;
    let remoteFileUrl = '';

    // 1. Upload to server tax storage endpoint
    setUploadProgress('Persisting document to compliance storage vault...');
    try {
      const resp = await fetch('/api/tax/upload-w9', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          creatorHandle,
          creatorName,
          creatorId: creatorId || cleanHandle,
          fileName,
          fileSize: fileSizeStr,
          fileData: dataUrl,
          documentType: 'W-9'
        })
      });

      if (resp.ok) {
        const json = await resp.json();
        if (json.fileUrl) {
          remoteFileUrl = json.fileUrl;
        }
      } else {
        console.warn('Backend storage upload returned status:', resp.status);
      }
    } catch (serverErr) {
      console.warn('Backend tax upload endpoint error:', serverErr);
    }

    // 2. Upload to Firebase Storage if configured
    try {
      if (storage) {
        const { ref, uploadString, getDownloadURL } = await import('firebase/storage');
        const storageRef = ref(storage, `tax_documents/${cleanHandle}/${Date.now()}_${fileName.replace(/[^a-zA-Z0-9._-]/g, '_')}`);
        await uploadString(storageRef, dataUrl, 'data_url');
        const fbUrl = await getDownloadURL(storageRef);
        if (fbUrl) {
          remoteFileUrl = fbUrl;
        }
      }
    } catch (storageErr) {
      console.info('Firebase Storage upload non-critical notice (using server storage/dataUrl):', storageErr);
    }

    const effectiveFileUrl = remoteFileUrl || dataUrl;
    const nowIso = new Date().toISOString();

    // 3. Write to Firestore studio-w9-forms
    setUploadProgress('Recording tax compliance certificate in Firestore...');
    try {
      await setDoc(doc(db, 'studio-w9-forms', w9DocId), {
        id: w9DocId,
        creator: creatorHandle,
        creatorHandle,
        creatorId: creatorId || cleanHandle,
        realName: creatorName || creatorHandle,
        taxIdStatus: 'Submitted for Review',
        w9Status: 'Submitted',
        earnings1099: matchingCreator?.totalEarned || 0,
        status1099: 'Pending Filing',
        fileName,
        fileSize: fileSizeStr,
        fileData: dataUrl,
        fileUrl: effectiveFileUrl,
        storageUrl: effectiveFileUrl,
        storagePath: `tax_documents/${cleanHandle}/${fileName}`,
        uploadedAt: nowIso,
        documentType: 'W-9',
        auditStatus: 'Submitted for Agency Compliance Verification'
      }, { merge: true });
    } catch (firestoreErr) {
      console.error('Firestore studio-w9-forms save error:', firestoreErr);
    }

    // 4. Update studio-creators roster record
    try {
      const creatorDocId = matchingCreator?.id || `creator_${cleanHandle}`;
      await setDoc(doc(db, 'studio-creators', creatorDocId), {
        w9Uploaded: true,
        w9Status: 'Submitted',
        taxIdStatus: 'Submitted for Review',
        w9FileName: fileName,
        w9FileSize: fileSizeStr,
        w9FileUrl: effectiveFileUrl,
        w9UploadedAt: nowIso
      }, { merge: true });
    } catch (crErr) {
      console.warn('studio-creators write warning:', crErr);
    }

    // Safe metadata-only cache in safeStorage
    try {
      const existing = JSON.parse(safeStorage.getItem('wl_w9_records') || '[]');
      const filtered = existing.filter((item: any) => (item.creator || '').toLowerCase() !== creatorHandle.toLowerCase());
      const w9RecordMeta = {
        id: w9DocId,
        creator: creatorHandle,
        realName: creatorName || creatorHandle,
        taxIdStatus: 'Submitted for Review',
        w9Status: 'Submitted',
        earnings1099: matchingCreator?.totalEarned || 0,
        status1099: 'Pending Filing',
        fileName,
        fileSize: fileSizeStr,
        uploadedAt: nowIso
      };
      safeStorage.setItem('wl_w9_records', JSON.stringify([w9RecordMeta, ...filtered]));
    } catch (e) {
      console.warn('safeStorage write notice:', e);
    }

    // 5. Update local state
    setW9Uploaded(true);
    setW9FileName(fileName);
    setW9FileSize(fileSizeStr);
    setW9Status('Submitted');
    setW9FileData(dataUrl);
    setW9FileUrl(effectiveFileUrl);
    setW9UploadedAt(nowIso);

    notify('IRS Form W-9 Submitted', `${fileName} (${fileSizeStr}) has been safely saved to the agency tax compliance vault.`, 'success');
    logActivity(`Uploaded IRS Form W-9: ${fileName}`);
  };

  const handleW9FileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      notify('File Exceeds Limit', 'Please upload a tax form smaller than 15MB.', 'danger');
      return;
    }

    setIsUploading(true);
    setUploadProgress('Reading file content...');

    try {
      const reader = new FileReader();
      reader.onerror = () => {
        setIsUploading(false);
        notify('File Read Error', 'Failed to read document content. Please try a different PDF or image.', 'danger');
      };

      reader.onload = async (event) => {
        const dataUrl = event.target?.result as string;
        if (!dataUrl) {
          setIsUploading(false);
          notify('File Read Error', 'File was empty or unreadable.', 'danger');
          return;
        }

        const sizeStr = `${(file.size / 1024).toFixed(1)} KB`;
        await persistTaxDocument(file.name, sizeStr, dataUrl);
        setIsUploading(false);
        setUploadProgress('');
      };

      reader.readAsDataURL(file);
    } catch (err: any) {
      console.error('File upload error:', err);
      setIsUploading(false);
      setUploadProgress('');
      notify('Upload Failed', 'An error occurred during upload. Please try again.', 'danger');
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  const handleOpenViewer = () => {
    const activeSource = w9FileData || w9FileUrl;
    if (!activeSource) {
      notify('No Document Data', 'No document content is currently stored. Please upload your signed W-9.', 'info');
      return;
    }

    setViewerFiles([
      {
        name: w9FileName || 'IRS_Form_W9_Signed.pdf',
        dataUrl: activeSource.startsWith('data:') ? activeSource : undefined,
        url: !activeSource.startsWith('data:') ? activeSource : undefined,
        size: w9FileSize,
        category: 'IRS Tax Compliance Form',
        description: `Form W-9 Taxpayer Identification Number and Certification for ${creatorName} (${creatorHandle}). Submitted: ${w9UploadedAt ? new Date(w9UploadedAt).toLocaleDateString() : 'Recently'}.`
      }
    ]);
    setViewerOpen(true);
  };

  const handleDownloadDocument = () => {
    const activeSource = w9FileData || w9FileUrl;
    if (activeSource) {
      const a = document.createElement('a');
      a.href = activeSource;
      a.download = w9FileName || 'IRS_Form_W9_Signed.pdf';
      a.click();
      notify('Downloading Tax Form', `Downloading ${w9FileName}`, 'info');
      logActivity(`Downloaded signed IRS Form W-9`);
    } else {
      // Generate a certified printable W-9 PDF if no stored file is found
      handleGenerateAndSaveSignedPdf();
    }
  };

  const handleGenerateAndSaveSignedPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const result = await generateOfficialW9Pdf({
        ...signFormData,
        signatureName: signFormData.signatureName || creatorName,
        dateSigned: new Date().toLocaleDateString('en-US')
      });

      const fileName = result.fileName || `${(creatorName || 'Creator').replace(/\s+/g, '_')}_W9_Signed.pdf`;
      const sizeStr = `${(result.pdfBytes.byteLength / 1024).toFixed(1)} KB`;

      await persistTaxDocument(fileName, sizeStr, result.dataUrl);
      setShowSignModal(false);
    } catch (err: any) {
      console.error('Error generating official W-9 PDF:', err);
      notify('Generation Failed', 'Could not generate official W-9 PDF. Please check required fields.', 'danger');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="bg-[#0B132B]/80 backdrop-blur-md p-6 rounded-2xl border border-white/10 shadow-xl space-y-5">
      {/* Toast Banner */}
      {localNotification && (
        <div 
          className={`p-3.5 rounded-xl text-sm flex items-center justify-between transition-all ${
            localNotification.type === 'success' 
              ? 'bg-emerald-950/80 border border-emerald-500/30 text-emerald-200'
              : localNotification.type === 'danger'
              ? 'bg-rose-950/80 border border-rose-500/30 text-rose-200'
              : 'bg-amber-950/80 border border-amber-500/30 text-amber-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {localNotification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : localNotification.type === 'danger' ? (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <div>
              <p className="font-semibold text-white leading-tight">{localNotification.title}</p>
              <p className="text-xs opacity-90">{localNotification.message}</p>
            </div>
          </div>
          <button 
            type="button" 
            onClick={() => setLocalNotification(null)}
            className="text-white/60 hover:text-white p-1 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <h3 className="text-xl font-bold text-white flex items-center gap-2.5">
            <FileText className="text-[#C9A46A] w-5 h-5" /> 
            IRS Form W-9 Tax Compliance
          </h3>
          <p className="text-slate-400 text-xs mt-1">
            Federal law requires a signed Form W-9 before agency payout disbursement and 1099-NEC tax year filing.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Lock className="w-3 h-3" /> Encrypted Vault
          </span>
        </div>
      </div>

      {/* Main Compliance Card */}
      <div className="bg-[#111E33] border border-white/10 rounded-xl p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className={`p-2.5 rounded-xl shrink-0 ${
              w9Uploaded 
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
            }`}>
              {w9Uploaded ? <CheckCircle2 className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-white font-semibold text-base">IRS Form W-9</h4>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                  w9Status === 'Verified'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : w9Status === 'Submitted'
                    ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}>
                  {w9Status}
                </span>
              </div>
              <p className="text-slate-300 text-xs mt-1">
                {w9Uploaded 
                  ? `Saved document: ${w9FileName} (${w9FileSize})`
                  : 'No signed Form W-9 document is currently on file for this creator account.'}
              </p>
              {w9UploadedAt && (
                <p className="text-slate-400 text-[11px] mt-0.5 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-[#C9A46A]" /> Submitted {new Date(w9UploadedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                </p>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {w9Uploaded && (
              <>
                <button
                  type="button"
                  onClick={handleOpenViewer}
                  className="bg-[#192742] hover:bg-[#203357] text-slate-100 hover:text-white border border-white/10 px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Inspect document in multi-page viewer"
                >
                  <Eye className="w-3.5 h-3.5 text-[#C9A46A]" /> View Document
                </button>
                <button
                  type="button"
                  onClick={handleDownloadDocument}
                  className="bg-[#192742] hover:bg-[#203357] text-[#C9A46A] hover:text-white border border-[#C9A46A]/30 px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Download signed file"
                >
                  <Download className="w-3.5 h-3.5" /> Download
                </button>
              </>
            )}

            {/* Hidden File Input */}
            <input 
              ref={fileInputRef}
              type="file" 
              accept=".pdf,.png,.jpg,.jpeg" 
              className="hidden" 
              onChange={handleW9FileUpload} 
            />

            <button
              type="button"
              disabled={isUploading}
              onClick={() => fileInputRef.current?.click()}
              className="bg-gradient-to-r from-[#C9A46A] to-[#B38E55] hover:from-[#D4B076] hover:to-[#BD985E] text-[#0A1120] font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-md transition-all cursor-pointer disabled:opacity-50"
            >
              {isUploading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="w-3.5 h-3.5" />
                  {w9Uploaded ? 'Re-upload / Update' : 'Upload Signed W-9'}
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setShowSignModal(true)}
              className="bg-[#192742] hover:bg-[#22365c] text-white border border-white/10 hover:border-[#C9A46A]/40 px-3.5 py-2 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer"
              title="Generate, fill out and digitally sign official IRS Form W-9"
            >
              <FileSignature className="w-3.5 h-3.5 text-[#C9A46A]" />
              E-Sign IRS W-9 Online
            </button>
          </div>
        </div>

        {/* Upload Progress Bar */}
        {isUploading && (
          <div className="bg-[#0A1120] p-3 rounded-lg border border-white/10 space-y-2 animate-pulse">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium flex items-center gap-1.5">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#C9A46A]" />
                {uploadProgress || 'Processing tax certificate...'}
              </span>
              <span className="text-[#C9A46A] font-bold">Secure Upload</span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-[#C9A46A] to-emerald-400 rounded-full animate-[shimmer_2s_infinite]" style={{ width: '85%' }} />
            </div>
          </div>
        )}

        {/* Security & Verification Details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-white/5 text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>IRS 1099-NEC Matching Ready</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <UserCheck className="w-4 h-4 text-[#C9A46A] shrink-0" />
            <span>Filer: {creatorName} ({creatorHandle})</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Lock className="w-4 h-4 text-blue-400 shrink-0" />
            <span>PII Protected & Access Controlled</span>
          </div>
        </div>
      </div>

      {/* Interactive E-Sign Modal */}
      {showSignModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#0D1829] border border-white/15 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <FileSignature className="w-5 h-5 text-[#C9A46A]" />
                  Generate & E-Sign Official IRS Form W-9
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Request for Taxpayer Identification Number and Certification (Rev. March 2024 / Department of the Treasury IRS)
                </p>
              </div>
              <button 
                type="button" 
                onClick={() => setShowSignModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  1. Name as shown on your income tax return (Legal Name) *
                </label>
                <input 
                  type="text" 
                  value={signFormData.legalName}
                  onChange={(e) => setSignFormData({ ...signFormData, legalName: e.target.value })}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                  placeholder="e.g. Olivia Sterling"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  2. Business name / disregarded entity name (if different)
                </label>
                <input 
                  type="text" 
                  value={signFormData.businessName || ''}
                  onChange={(e) => setSignFormData({ ...signFormData, businessName: e.target.value })}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                  placeholder="e.g. Sterling Creative LLC"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  3. Federal Tax Classification *
                </label>
                <select 
                  value={signFormData.taxClassification}
                  onChange={(e) => setSignFormData({ ...signFormData, taxClassification: e.target.value })}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#C9A46A]"
                >
                  <option value="Individual/sole proprietor or single-member LLC">Individual/sole proprietor or single-member LLC</option>
                  <option value="C Corporation">C Corporation</option>
                  <option value="S Corporation">S Corporation</option>
                  <option value="Partnership">Partnership</option>
                  <option value="Limited liability company">Limited liability company (LLC)</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    5. Address (number, street, and apt. or suite no.) *
                  </label>
                  <input 
                    type="text" 
                    value={signFormData.address}
                    onChange={(e) => setSignFormData({ ...signFormData, address: e.target.value })}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                    placeholder="742 Evergreen Terrace"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    6. City, state, and ZIP code *
                  </label>
                  <input 
                    type="text" 
                    value={signFormData.cityStateZip}
                    onChange={(e) => setSignFormData({ ...signFormData, cityStateZip: e.target.value })}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
                    placeholder="Los Angeles, CA 90028"
                  />
                </div>
              </div>

              {/* Part I: TIN */}
              <div className="bg-[#111E33] p-4 rounded-xl border border-white/10 space-y-3">
                <span className="text-[#C9A46A] font-bold uppercase tracking-wider text-[11px] block">
                  Part I: Taxpayer Identification Number (TIN)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">TIN Type</label>
                    <select 
                      value={signFormData.tinType}
                      onChange={(e) => setSignFormData({ ...signFormData, tinType: e.target.value as 'SSN' | 'EIN' })}
                      className="w-full bg-[#0B132B] border border-white/10 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="SSN">Social Security Number (SSN)</option>
                      <option value="EIN">Employer Identification Number (EIN)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Number (e.g. 123-45-6789 or 12-3456789) *</label>
                    <input 
                      type="text" 
                      value={signFormData.tinNumber}
                      onChange={(e) => setSignFormData({ ...signFormData, tinNumber: e.target.value })}
                      className="w-full bg-[#0B132B] border border-white/10 rounded-lg px-3 py-2 text-white"
                      placeholder="123-45-6789"
                    />
                  </div>
                </div>
              </div>

              {/* Part II: Certification & E-Signature */}
              <div className="bg-[#111E33] p-4 rounded-xl border border-white/10 space-y-3">
                <span className="text-[#C9A46A] font-bold uppercase tracking-wider text-[11px] block">
                  Part II: Certification & Digital Signature
                </span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Under penalties of perjury, I certify that: (1) The number shown on this form is my correct taxpayer identification number, 
                  (2) I am not subject to backup withholding, and (3) I am a U.S. citizen or other U.S. person.
                </p>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Signature of U.S. Person (Type full legal name to sign) *
                  </label>
                  <input 
                    type="text" 
                    value={signFormData.signatureName}
                    onChange={(e) => setSignFormData({ ...signFormData, signatureName: e.target.value })}
                    className="w-full bg-[#0B132B] border border-[#C9A46A]/50 rounded-lg px-3 py-2 text-white font-mono"
                    placeholder="Olivia Sterling"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Date certified: {new Date().toLocaleDateString()} &bull; IP & Timestamp logged securely
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setShowSignModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/5"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isGeneratingPdf || !signFormData.legalName || !signFormData.tinNumber || !signFormData.signatureName}
                onClick={handleGenerateAndSaveSignedPdf}
                className="bg-gradient-to-r from-[#C9A46A] to-[#B38E55] hover:from-[#D4B076] hover:to-[#BD985E] text-[#0A1120] font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
              >
                {isGeneratingPdf ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Generating & Filing W-9...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" /> Certify & Submit Official W-9
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Multi-File / PDF Viewer Modal */}
      <MultiFilePdfViewerModal
        isOpen={viewerOpen}
        onClose={() => setViewerOpen(false)}
        title="Official IRS Form W-9 Verification Vault"
        files={viewerFiles}
      />
    </div>
  );
};

export default TaxComplianceManager;
