import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, Plus, Trash, Search, ArrowRight, ArrowLeft, Move, 
  CheckCircle, UserPlus, Filter, Table, Kanban, Award, Share2, 
  Sparkles, DollarSign, Users, AlertCircle
} from 'lucide-react';
import { Creator } from '../types';
import { formatCsvRow, sanitizeCsvCell } from '../utils/security';

interface OutreachTrackerProps {
  prospects: any[];
  setProspects: React.Dispatch<React.SetStateAction<any[]>>;
  handleAddProspect: (e: React.FormEvent<HTMLFormElement>) => void;
  isAddProspectModalOpen: boolean;
  setIsAddProspectModalOpen: (val: boolean) => void;
  onMoveReadyProspectsToIntake: () => void;
  handleAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  primaryBrandColor: string;
  cardBgColor: string;
  currentUser: any;
  currentRole: string;
  setCreators: React.Dispatch<React.SetStateAction<Creator[]>>;
  creators: Creator[];
}

export default function OutreachTracker({
  prospects,
  setProspects,
  handleAddProspect,
  isAddProspectModalOpen,
  setIsAddProspectModalOpen,
  onMoveReadyProspectsToIntake,
  handleAddActivityLog,
  triggerNotification,
  primaryBrandColor,
  cardBgColor,
  currentUser,
  currentRole,
  setCreators,
  creators
}: OutreachTrackerProps) {
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [nicheFilter, setNicheFilter] = useState('All');
  const [agencyContextId, setAgencyContextId] = useState('bloom_studio_default');

  // Resolve user subagency pod or active agency ID
  useEffect(() => {
    const activeId = currentUser?.subagency || currentUser?.tenantId || (window as any).currentAgencyId || 'bloom_studio_default';
    setAgencyContextId(activeId);
  }, [currentUser]);

  // Filter prospects based on current role (agents only see their own outreach, director sees all)
  const visibleProspects = prospects.filter(p => {
    const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
    const isAgent = (currentRole || '').toLowerCase() === 'agent';
    if ((isAgentMgr || isAgent) && p.addedBy && p.addedBy.toLowerCase() !== (currentUser?.name || '').toLowerCase()) {
      return false;
    }
    return true;
  });

  const filteredProspects = visibleProspects.filter(p => {
    const matchesSearch = p.handle.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.niche.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesNiche = nicheFilter === 'All' || p.niche === nicheFilter;
    return matchesSearch && matchesNiche;
  });

  // Unique niches list for filter dropdown
  const niches = ['All', ...Array.from(new Set(prospects.map(p => p.niche)))];

  // Pipeline stages mapped to columns
  const COLUMNS = [
    { id: 'contacted', title: 'Discovered / Contacted', stages: ['Waiting reply', 'No response'], color: 'text-amber-400', bg: 'bg-amber-950/20' },
    { id: 'negotiating', title: 'Negotiating', stages: ['Interested', 'In conversation'], color: 'text-sky-400', bg: 'bg-sky-950/20' },
    { id: 'contract_pending', title: 'Contract Pending', stages: ['Ready to sign'], color: 'text-pink-400', bg: 'bg-pink-950/20' },
    { id: 'signed', title: 'Signed & Onboarded', stages: ['Signed & Onboarded'], color: 'text-emerald-400', bg: 'bg-emerald-950/20' }
  ];

  // Helper to move stages
  const moveProspectStage = (id: string, newStage: string) => {
    setProspects(prev => prev.map(p => {
      if (p.id === id) {
        const oldStage = p.stage;
        handleAddActivityLog(
          currentUser?.name || "User",
          currentRole,
          `🔄 OUTREACH ROUTING: Moved ${p.handle} from [${oldStage}] to [${newStage}] inside agency workspace [${agencyContextId}].`
        );
        triggerNotification(
          "Pipeline Updated",
          `${p.handle} is now in '${newStage}' stage.`,
          "success"
        );
        return { ...p, stage: newStage };
      }
      return p;
    }));
  };

  // Convert a signed prospect directly to the main roster
  const onboardToRoster = (prospect: any) => {
    // Check if already in roster
    if (creators.some(c => c.handle.toLowerCase() === prospect.handle.toLowerCase())) {
      triggerNotification(
        "Already Onboarded",
        `${prospect.handle} is already registered in the active creator roster.`,
        "warning"
      );
      return;
    }

    const newCreator: Creator = {
      id: 'c_from_prospect_' + Date.now(),
      handle: prospect.handle,
      name: prospect.name,
      platform: prospect.platform || 'TikTok',
      niche: prospect.niche || 'Lifestyle',
      followers: prospect.followers || '0',
      eng: prospect.eng || '0%',
      agreement: 'Exclusive (75-80%)',
      status: 'Active',
      assignedAgent: currentUser?.name || 'Assigned Agent',
      age: prospect.age || '24'
    };

    setCreators(prev => [...prev, newCreator]);
    // Optionally remove or keep in "Signed & Onboarded" status
    setProspects(prev => prev.filter(p => p.id !== prospect.id));

    handleAddActivityLog(
      currentUser?.name || "User",
      currentRole,
      `✨ ROSTER INTAKE: Formally onboarded exclusive creator ${prospect.handle} into roster pool.`
    );

    triggerNotification(
      "Formal Onboarding Successful",
      `Formally completed exclusive talent intake representation for ${prospect.name} (${prospect.handle}).`,
      "success"
    );
  };

  const deleteProspectLocal = (id: string) => {
    const prospect = prospects.find(p => p.id === id);
    if (!prospect) return;
    setProspects(prev => prev.filter(p => p.id !== id));
    handleAddActivityLog(currentUser?.name || "User", currentRole, `Removed prospect ${prospect.handle} from outreach tracker`);
    triggerNotification(
      "Prospect Removed",
      `Successfully removed ${prospect.handle} from the outreach tracking board.`,
      "info"
    );
  };

  // Drag and Drop implementation simulation
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetStage: string) => {
    e.preventDefault();
    const id = e.dataTransfer.getData("text/plain");
    if (id) {
      moveProspectStage(id, targetStage);
    }
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    e.dataTransfer.setData("text/plain", id);
  };

  // Metrics for current leads
  const totalLeads = visibleProspects.length;
  const replyWaiting = visibleProspects.filter(p => p.stage === 'Waiting reply' || p.stage === 'No response').length;
  const negotiating = visibleProspects.filter(p => p.stage === 'Interested' || p.stage === 'In conversation').length;
  const readyToSign = visibleProspects.filter(p => p.stage === 'Ready to sign').length;
  const signedCount = visibleProspects.filter(p => p.stage === 'Signed & Onboarded').length;

  return (
    <div className="space-y-6">
      {/* Header Panel */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-white/5 rounded-2xl p-6 overflow-hidden" style={{ backgroundColor: cardBgColor }}>
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider block" style={{ color: primaryBrandColor }}>
              📡 System Separation Lane: Active Agency [{agencyContextId}]
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              Outreach Acquisition Tracker
            </h1>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Monitor talent negotiation phases, legal contract discussions, and response metrics in real-time.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Toggle */}
            <div className="flex bg-[#111E33] border border-white/5 p-1 rounded-xl">
              <button 
                onClick={() => setViewMode('kanban')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  viewMode === 'kanban' 
                    ? 'bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30' 
                    : 'text-slate-400 hover:text-white'
                }`}
                style={viewMode === 'kanban' ? { color: primaryBrandColor, borderColor: `${primaryBrandColor}40`, backgroundColor: `${primaryBrandColor}20` } : {}}
              >
                <Kanban className="w-3.5 h-3.5" /> Kanban
              </button>
              <button 
                onClick={() => setViewMode('table')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  viewMode === 'table' 
                    ? 'bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30' 
                    : 'text-slate-400 hover:text-white'
                }`}
                style={viewMode === 'table' ? { color: primaryBrandColor, borderColor: `${primaryBrandColor}40`, backgroundColor: `${primaryBrandColor}20` } : {}}
              >
                <Table className="w-3.5 h-3.5" /> List Table
              </button>
            </div>

            <button 
              onClick={() => setIsAddProspectModalOpen(true)}
              className="bg-[#C9A46A] hover:opacity-90 text-slate-950 px-4 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all"
              style={{ backgroundColor: primaryBrandColor }}
            >
              <Plus className="w-4 h-4" /> Log Outreach Lead
            </button>
          </div>
        </div>
      </div>

      {/* Performance Stats Panel */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex flex-col justify-between" style={{ backgroundColor: cardBgColor }}>
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-medium">Total Leads</span>
          <div className="text-2xl font-bold text-white mt-1.5">{totalLeads}</div>
          <div className="text-[10px] text-slate-500 mt-1">In system queue</div>
        </div>
        <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex flex-col justify-between" style={{ backgroundColor: cardBgColor }}>
          <span className="text-[10px] text-amber-400 uppercase tracking-wider block font-medium">Waiting / Unresponsive</span>
          <div className="text-2xl font-bold text-white mt-1.5">{replyWaiting}</div>
          <div className="text-[10px] text-slate-500 mt-1">Follow-up needed</div>
        </div>
        <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex flex-col justify-between" style={{ backgroundColor: cardBgColor }}>
          <span className="text-[10px] text-sky-400 uppercase tracking-wider block font-medium">Negotiating</span>
          <div className="text-2xl font-bold text-white mt-1.5">{negotiating}</div>
          <div className="text-[10px] text-slate-500 mt-1">Pitching deals</div>
        </div>
        <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex flex-col justify-between" style={{ backgroundColor: cardBgColor }}>
          <span className="text-[10px] text-pink-400 uppercase tracking-wider block font-medium">Contract Pending</span>
          <div className="text-2xl font-bold text-white mt-1.5">{readyToSign}</div>
          <div className="text-[10px] text-slate-500 mt-1">Awaiting digital signature</div>
        </div>
        <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex flex-col justify-between" style={{ backgroundColor: cardBgColor }}>
          <span className="text-[10px] text-emerald-400 uppercase tracking-wider block font-medium font-bold">Signed Onboarded</span>
          <div className="text-2xl font-bold text-emerald-400 mt-1.5">{signedCount}</div>
          <div className="text-[10px] text-emerald-500/70 mt-1">Formally represented</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#0D1830] border border-white/5 p-4 rounded-xl flex flex-col sm:flex-row gap-4 items-center justify-between" style={{ backgroundColor: cardBgColor }}>
        <div className="relative w-full sm:max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-400" />
          </span>
          <input
            type="text"
            placeholder="Search prospect name, handle, or niche..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white outline-none focus:border-[#C9A46A]/40 transition-colors"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-2 text-xs text-slate-400 shrink-0">
            <Filter className="w-3.5 h-3.5" /> Filter Niche:
          </div>
          <select
            value={nicheFilter}
            onChange={(e) => setNicheFilter(e.target.value)}
            className="bg-[#111E33] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white outline-none cursor-pointer focus:border-[#C9A46A]/40"
          >
            {niches.map((n, idx) => (
              <option key={idx} value={n}>{n}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Core Dynamic Board Renderer */}
      {viewMode === 'kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-start">
          {COLUMNS.map(col => {
            // Get prospects matching this column's stages
            const colProspects = filteredProspects.filter(p => col.stages.includes(p.stage));

            return (
              <div 
                key={col.id} 
                className="bg-[#0D1830]/80 border border-white/5 rounded-2xl flex flex-col max-h-[700px] overflow-hidden"
                style={{ backgroundColor: `${cardBgColor}bb` }}
                onDragOver={handleDragOver}
                onDrop={(e) => {
                  // Drop default to first stage of this column
                  handleDrop(e, col.stages[0]);
                }}
              >
                {/* Column Header */}
                <div className={`p-4 border-b border-white/5 flex items-center justify-between ${col.bg}`}>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${col.id === 'signed' ? 'bg-emerald-400 animate-pulse' : col.id === 'contract_pending' ? 'bg-pink-400' : col.id === 'negotiating' ? 'bg-sky-400' : 'bg-amber-400'}`}></span>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      {col.title}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono bg-white/5 px-2 py-0.5 rounded-full text-slate-300 font-semibold">
                    {colProspects.length}
                  </span>
                </div>

                {/* Column Body / Stack */}
                <div className="p-3 overflow-y-auto space-y-3 min-h-[300px] max-h-[600px] custom-scrollbar">
                  {colProspects.length === 0 ? (
                    <div className="text-center py-12 border border-dashed border-white/5 rounded-xl text-[11px] text-slate-500">
                      Empty column.
                    </div>
                  ) : (
                    colProspects.map(p => (
                      <div 
                        key={p.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, p.id)}
                        className="p-4 bg-[#111E33] border border-white/5 hover:border-white/10 rounded-xl space-y-3 shadow-md hover:shadow-lg transition-all cursor-grab active:cursor-grabbing group relative"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full bg-[#16243F] border border-[#C9A46A]/20 flex items-center justify-center font-bold font-serif text-[#C9A46A] text-[10px]" style={{ color: primaryBrandColor, borderColor: `${primaryBrandColor}30` }}>
                              {p.name.split(' ').map((n: string) => n[0]).join('')}
                            </div>
                            <div>
                              <h4 className="text-xs font-bold text-white tracking-tight">{p.name}</h4>
                              <p className="text-[10px] text-sky-400 font-mono mt-0.5">{p.handle}</p>
                            </div>
                          </div>

                          <button 
                            onClick={() => deleteProspectLocal(p.id)}
                            className="text-slate-400 hover:text-rose-400 p-1 rounded-lg transition-colors bg-transparent opacity-100"
                            title="Remove lead"
                          >
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[9px] uppercase font-bold px-2 py-0.5 rounded bg-slate-950/40 text-[#C9A46A] border border-[#C9A46A]/10">
                            {p.niche}
                          </span>
                          <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded border ${
                            p.platform === 'TikTok' ? 'bg-rose-950/20 border-rose-500/20 text-rose-400' :
                            p.platform === 'Instagram' ? 'bg-pink-950/20 border-pink-500/20 text-pink-400' :
                            'bg-red-950/20 border-red-500/20 text-red-400'
                          }`}>
                            {p.platform}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 pt-1 border-t border-white/5 font-mono">
                          <div>Followers: <strong className="text-white font-sans">{p.followers}</strong></div>
                          <div className="text-right">Eng Rate: <strong className="text-white font-sans">{p.eng}</strong></div>
                        </div>

                        <div className="bg-slate-950/40 border border-white/5 rounded-lg p-2.5 text-[10px] text-slate-400 leading-relaxed font-mono space-y-1">
                          <div className="flex justify-between">
                            <span className="text-slate-500 uppercase font-bold text-[9px]">Contacted Date:</span>
                            <span className="text-slate-300 font-semibold">{p.dateAdded || p.lastContactDate || '2026-08-01'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500 uppercase font-bold text-[9px]">Contacted By:</span>
                            <span className="text-slate-300 font-semibold">{p.addedBy || p.agent || 'Agency Representative'}</span>
                          </div>
                          <div className="pt-1 border-t border-white/5">
                            <span className="text-slate-500 block text-[9px] uppercase font-bold mb-0.5">Last Interaction:</span>
                            {p.lastContact}
                          </div>
                        </div>

                        {/* Interactive Board Control Buttons */}
                        <div className="flex items-center justify-between pt-2 border-t border-white/5">
                          {/* Left Navigation */}
                          <div>
                            {col.id !== 'contacted' && (
                              <button 
                                onClick={() => {
                                  // Back navigation mapping
                                  const prevStages: Record<string, string> = {
                                    negotiating: 'Waiting reply',
                                    contract_pending: 'In conversation',
                                    signed: 'Ready to sign'
                                  };
                                  moveProspectStage(p.id, prevStages[col.id]);
                                }}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                                title="Move Left"
                              >
                                <ArrowLeft className="w-3 h-3" />
                              </button>
                            )}
                          </div>

                          {/* Center action - formal roster onboarding */}
                          {col.id === 'signed' && (
                            <button
                              onClick={() => onboardToRoster(p)}
                              className="bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/30 hover:border-emerald-500 text-emerald-400 font-bold text-[9px] uppercase tracking-wider px-2.5 py-1 rounded-lg flex items-center gap-1 transition-all"
                            >
                              <UserPlus className="w-3 h-3" /> Onboard Roster
                            </button>
                          )}

                          {/* Right Navigation */}
                          <div>
                            {col.id !== 'signed' && (
                              <button 
                                onClick={() => {
                                  // Forward navigation mapping
                                  const nextStages: Record<string, string> = {
                                    contacted: 'Interested',
                                    negotiating: 'Ready to sign',
                                    contract_pending: 'Signed & Onboarded'
                                  };
                                  moveProspectStage(p.id, nextStages[col.id]);
                                }}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors flex items-center gap-1"
                                title="Move Right"
                              >
                                <span className="text-[9px] font-sans font-semibold">Advance</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>

                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Legacy Table List fallback */
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden" style={{ backgroundColor: cardBgColor }}>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5 bg-[#111E33]/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="p-4">Creator</th>
                  <th className="p-4">Platform</th>
                  <th className="p-4">Followers</th>
                  <th className="p-4">Engagement</th>
                  <th className="p-4">Contacted Date</th>
                  <th className="p-4">Contacted By</th>
                  <th className="p-4">Last Contact</th>
                  <th className="p-4">Stage</th>
                  <th className="p-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                {filteredProspects.map(p => (
                  <tr key={p.id} className="hover:bg-[#111E33]/30 transition-colors">
                    <td className="p-4 flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-[#16243F] border border-[#C9A46A]/20 flex items-center justify-center font-bold font-serif text-[#C9A46A] text-xs" style={{ color: primaryBrandColor, borderColor: `${primaryBrandColor}30` }}>
                        {p.name.split(' ').map((n: string) => n[0]).join('')}
                      </div>
                      <div>
                        <div className="font-semibold text-white">{p.handle}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">{p.niche}</div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`inline-block px-2 py-0.5 rounded font-mono font-bold text-[10px] uppercase ${
                        p.platform === 'TikTok' ? 'bg-rose-950/40 border border-rose-500/30 text-rose-400' :
                        p.platform === 'Instagram' ? 'bg-pink-950/40 border border-pink-500/30 text-pink-400' :
                        'bg-red-950/40 border border-red-500/30 text-red-400'
                      }`}>
                        {p.platform}
                      </span>
                    </td>
                    <td className="p-4 font-semibold text-white">{p.followers}</td>
                    <td className="p-4">{p.eng}</td>
                    <td className="p-4 text-slate-300 font-mono">{p.dateAdded || p.lastContactDate || '2026-08-01'}</td>
                    <td className="p-4 text-slate-300 font-mono">{p.addedBy || p.agent || 'Agency Representative'}</td>
                    <td className="p-4 text-slate-400">{p.lastContact}</td>
                    <td className="p-4">
                      <span className={`inline-block px-2.5 py-0.5 rounded-full font-semibold text-[10px] border ${
                        p.stage === 'Waiting reply' || p.stage === 'No response' ? 'bg-amber-950/40 border-amber-500/30 text-amber-400' :
                        p.stage === 'Interested' || p.stage === 'In conversation' ? 'bg-sky-950/40 border-sky-500/30 text-sky-400' :
                        p.stage === 'Ready to sign' ? 'bg-pink-950/40 border-pink-500/30 text-pink-400' :
                        'bg-emerald-950/40 border-emerald-500/30 text-emerald-400'
                      }`}>
                        {p.stage}
                      </span>
                    </td>
                    <td className="p-4 text-right flex items-center justify-end gap-2">
                      {p.stage === 'Signed & Onboarded' && (
                        <button
                          onClick={() => onboardToRoster(p)}
                          className="bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/25 text-emerald-400 px-2 py-1 rounded text-[10px] font-bold"
                        >
                          Onboard
                        </button>
                      )}
                      <button 
                        onClick={() => deleteProspectLocal(p.id)}
                        className="text-slate-400 hover:text-rose-400 p-2 rounded-xl hover:bg-white/5 transition-colors opacity-100"
                        title="Delete prospect log"
                      >
                        <Trash className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {filteredProspects.length === 0 && (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-500">
                      No prospects matching current filters. Click "Log Outreach Lead" to begin.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Action panel at bottom */}
      <div className="flex flex-wrap items-center gap-3">
        {((currentRole || '').toLowerCase() === 'agentmgr' || (currentRole || '').toLowerCase() === 'agent') ? (
          <button
            onClick={() => {
              triggerNotification("Sent to Director", "Ready outreach prospects have been sent to the Director for active roster clearance.", "success");
              handleAddActivityLog(currentUser?.name || "Agent Manager", currentRole, "Submitted ready outreach prospects to Director for approval");
            }}
            className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            style={{ backgroundColor: primaryBrandColor }}
          >
            <TrendingUp className="w-4 h-4" /> Send Ready Leads to Director when Ready
          </button>
        ) : (
          <button
            onClick={onMoveReadyProspectsToIntake}
            className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            style={{ backgroundColor: primaryBrandColor }}
          >
            <TrendingUp className="w-4 h-4" /> Intake All Ready Leads to Active Roster
          </button>
        )}
        <button
          onClick={() => {
            const listToExport = filteredProspects.length > 0 ? filteredProspects : prospects;
            if (!listToExport || listToExport.length === 0) {
              triggerNotification("Export Notice", "No outreach prospects found to export.", "warning");
              return;
            }

            const headers = ["ID", "Name", "Handle", "Niche", "Followers", "Stage", "Last Contact", "Notes", "Added By"];

            const rows = listToExport.map(p => formatCsvRow([
              p.id,
              p.name,
              p.handle,
              p.niche,
              p.followers,
              p.stage,
              p.lastContact,
              p.notes || "",
              p.addedBy || ""
            ]));

            const csvContent = [headers.map(sanitizeCsvCell).join(","), ...rows].join("\r\n");
            const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.setAttribute("href", url);
            link.setAttribute("download", `outreach_prospects_${new Date().toISOString().split("T")[0]}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            handleAddActivityLog(currentUser?.name || "User", currentRole, `Exported ${listToExport.length} outreach prospects to CSV`);
            triggerNotification("List Exported", `Downloaded outreach prospects CSV (${listToExport.length} records).`, "success");
          }}
          className="bg-transparent hover:bg-white/5 text-slate-400 hover:text-white border border-white/10 px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          Export CSV Summary
        </button>
      </div>
    </div>
  );
}
