import React, { useState } from 'react';
import { DollarSign, Clock, CheckCircle2, ShieldCheck, Sparkles, TrendingUp, HelpCircle, Lock } from 'lucide-react';

export interface CreatorCampaignMilestone {
  campaignId: string;
  campaignTitle: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  creatorDeliverable: string;
  fixedContractPay: number;
  cashPipelineStatus: 'Pending Client Deposit - Net 30' | 'Pending Client Deposit - Net 15' | 'Cleared in Agency Escrow' | 'Disbursed to Talent Bank';
  settledDate?: string;
}

export interface CreatorLedgerData {
  creatorHandle: string;
  creatorName: string;
  expectedUpcomingPay: number;
  totalIncomeSettled: number;
  activeDeliverables: CreatorCampaignMilestone[];
  completedDeliverables: CreatorCampaignMilestone[];
}

interface CreatorEarningsEscrowPanelProps {
  creatorHandle?: string;
  initialData?: CreatorLedgerData;
}

/**
 * CreatorEarningsEscrowPanel:
 * Premium, sandbox-isolated creator payment tracking component.
 * 
 * CRITICAL DISCRETION AUDIT:
 * 1. Zero access to top-line brand budgets, corporate invoices, or agency manager commission splits.
 * 2. Strictly displays the creator's private, transparent fixed contract payouts and milestone timeline states.
 */
export default function CreatorEarningsEscrowPanel({
  creatorHandle = "@ava_glow",
  initialData = {
    creatorHandle: "@ava_glow",
    creatorName: "Ava Sterling",
    expectedUpcomingPay: 6000,
    totalIncomeSettled: 24500,
    activeDeliverables: [
      {
        campaignId: "camp_glowlab_01",
        campaignTitle: "Summer Glow Botanical Serum Whitelisting",
        niche: "Beauty",
        creatorDeliverable: "1x 60s 4K Morning Glow Routine UGC + Link Sticker",
        fixedContractPay: 6000,
        cashPipelineStatus: "Cleared in Agency Escrow"
      }
    ],
    completedDeliverables: [
      {
        campaignId: "camp_velvet_00",
        campaignTitle: "Botanical Silk Body Oil Campaign",
        niche: "Beauty",
        creatorDeliverable: "2x Aesthetic UGC Reels",
        fixedContractPay: 5500,
        cashPipelineStatus: "Disbursed to Talent Bank",
        settledDate: "July 28, 2026"
      },
      {
        campaignId: "camp_aura_99",
        campaignTitle: "Glow Essentials Spring Collection",
        niche: "Lifestyle",
        creatorDeliverable: "1x TikTok Video + 30-day Whitelisting",
        fixedContractPay: 13000,
        cashPipelineStatus: "Disbursed to Talent Bank",
        settledDate: "June 14, 2026"
      },
      {
        campaignId: "camp_paw_88",
        campaignTitle: "PawSpa Organic Balm Collab",
        niche: "Pets",
        creatorDeliverable: "1x Pet Wellness Reel",
        fixedContractPay: 6000,
        cashPipelineStatus: "Disbursed to Talent Bank",
        settledDate: "May 02, 2026"
      }
    ]
  }
}: CreatorEarningsEscrowPanelProps) {
  const [data] = useState<CreatorLedgerData>(initialData);

  const getStatusBadge = (status: CreatorCampaignMilestone['cashPipelineStatus']) => {
    switch (status) {
      case 'Pending Client Deposit - Net 30':
      case 'Pending Client Deposit - Net 15':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-amber-400 bg-amber-950/60 border border-amber-500/40 px-3 py-1 rounded-xl">
            <Clock className="w-3.5 h-3.5" />
            {status}
          </span>
        );
      case 'Cleared in Agency Escrow':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-300 bg-emerald-950/70 border border-emerald-400/40 px-3 py-1 rounded-xl shadow-md">
            <Sparkles className="w-3.5 h-3.5 text-agency-gold" />
            Cleared in Agency Escrow (Release Pending)
          </span>
        );
      case 'Disbursed to Talent Bank':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-mono font-bold text-slate-300 bg-agency-navy border border-white/10 px-3 py-1 rounded-xl">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Disbursed to Bank
          </span>
        );
    }
  };

  return (
    <div className="bg-agency-navyLight border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl text-agency-textLight space-y-8 max-w-5xl mx-auto">
      {/* Upper Portal Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navy border border-agency-gold/30 px-3 py-0.5 rounded-full">
              Talent Financial Vault
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Creator Direct Deposit Escrow
            </span>
          </div>
          <h2 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5">
            Creator Earnings &amp; Escrow Tracker
          </h2>
          <p className="text-xs text-slate-400">
            Private, contract-guaranteed disbursement ledger for <strong className="text-agency-gold">{data.creatorHandle}</strong> ({data.creatorName}).
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-300 bg-agency-navy px-4 py-2 rounded-xl border border-white/10">
          <ShieldCheck className="w-4 h-4 text-agency-gold" />
          <span>FDIC-Secured Agency Escrow</span>
        </div>
      </div>

      {/* 3-State Payment Milestone Display Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* State 1: Expected Campaign Pay */}
        <div className="bg-agency-navy border border-white/10 rounded-2xl p-5 space-y-2 shadow-md">
          <span className="text-[11px] uppercase font-mono tracking-wider text-slate-400 flex items-center justify-between">
            <span>Expected Campaign Pay</span>
            <Clock className="w-4 h-4 text-agency-gold" />
          </span>
          <div className="text-3xl font-bold font-mono text-white">
            ${data.expectedUpcomingPay.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            Locked in active production contracts
          </p>
        </div>

        {/* State 2: Cash Pipeline Status */}
        <div className="bg-agency-navy border border-agency-gold/40 rounded-2xl p-5 space-y-2 shadow-md">
          <span className="text-[11px] uppercase font-mono tracking-wider text-agency-gold flex items-center justify-between">
            <span>Cash Pipeline Status</span>
            <Sparkles className="w-4 h-4 text-agency-gold" />
          </span>
          <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
            Cleared in Escrow
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            Brand settlement secured &bull; Scheduled for direct wire transfer
          </p>
        </div>

        {/* State 3: Total Income Settled */}
        <div className="bg-agency-navy border border-white/10 rounded-2xl p-5 space-y-2 shadow-md">
          <span className="text-[11px] uppercase font-mono tracking-wider text-slate-400 flex items-center justify-between">
            <span>Total Income Settled</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </span>
          <div className="text-3xl font-bold font-mono text-emerald-400">
            ${data.totalIncomeSettled.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            Cumulative career payouts disbursed by Bloom Studio
          </p>
        </div>
      </div>

      {/* Active Campaign Milestones */}
      <div className="space-y-4">
        <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-agency-gold" /> Active Deliverables &amp; Cash Escrow Progress
        </h3>

        <div className="space-y-3">
          {data.activeDeliverables.map((item) => (
            <div
              key={item.campaignId}
              className="bg-agency-navy border border-agency-gold/30 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-base">{item.campaignTitle}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-agency-navyLight border border-white/10 text-slate-300">
                    {item.niche}
                  </span>
                </div>
                <p className="text-xs text-slate-400">{item.creatorDeliverable}</p>
                <div className="pt-1">
                  <span className="text-xs font-mono text-slate-300">
                    Contract Guaranteed Compensation: <strong className="text-agency-gold text-sm">${item.fixedContractPay.toLocaleString()}</strong>
                  </span>
                </div>
              </div>

              <div>
                {getStatusBadge(item.cashPipelineStatus)}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Historical Settled Disbursements */}
      <div className="space-y-4 border-t border-white/10 pt-6">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Settled Payment History &amp; Bank Transfers
        </h3>

        <div className="overflow-x-auto rounded-2xl border border-white/10 bg-agency-navy">
          <table className="w-full text-left text-xs">
            <thead className="bg-agency-navyLight text-agency-gold font-mono uppercase text-[10px] tracking-wider border-b border-white/10">
              <tr>
                <th className="py-3 px-4">Campaign</th>
                <th className="py-3 px-4">Deliverables</th>
                <th className="py-3 px-4">Contract Amount</th>
                <th className="py-3 px-4">Settled Date</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-sans">
              {data.completedDeliverables.map((row) => (
                <tr key={row.campaignId} className="hover:bg-white/[0.02]">
                  <td className="py-3.5 px-4 font-bold text-white">{row.campaignTitle}</td>
                  <td className="py-3.5 px-4 text-slate-400">{row.creatorDeliverable}</td>
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-200">${row.fixedContractPay.toLocaleString()}</td>
                  <td className="py-3.5 px-4 font-mono text-slate-400">{row.settledDate}</td>
                  <td className="py-3.5 px-4">
                    <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-md">
                      <CheckCircle2 className="w-3 h-3" /> Disbursed
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
