import React, { useState, useRef } from 'react';
import { 
  Eye, TrendingUp, Sparkles, CheckCircle2, ShieldCheck, Download, Award, 
  Play, Video, Share2, Upload, PlusCircle, Edit3, X, FileText, Info, Trash2, Film
} from 'lucide-react';
import { exportClientWrapUpPDF, ClientWrapUpData } from '../utils/pdfExportUtils';

interface UploadedVideoProof {
  id: string;
  creatorHandle: string;
  deliverableTitle: string;
  videoUrl: string;
  views: string;
  engagement: string;
  timestamp: string;
}

interface ExecutiveWrapUpReportProps {
  initialData?: ClientWrapUpData;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: string) => void;
  userRole?: string;
  currentRole?: string;
}

/**
 * ExecutiveWrapUpReport:
 * Client-Facing high-end executive summary report component for Brand Partners in Pets, Beauty, and Lifestyle.
 *
 * CRITICAL FINANCIAL SEGREGATION AUDIT:
 * Exclusively displays consumer-facing marketing deliverables and macro campaign outcomes.
 * STRICTLY NEVER queries, displays, or exposes:
 *  - Net Influencer Payouts
 *  - Agency Net Retained Margins
 *  - Manager / Coordinator Commission splits
 */
export default function ExecutiveWrapUpReport({
  initialData = {
    brandName: "GlowLab Beauty & BarkHydrate",
    campaignTitle: "Summer Botanical Serum & Pet Hydration Push",
    date: "August 2026",
    niche: "Beauty",
    totalReach: "1,450,000+",
    totalViews: "842,500 Views",
    engagementRate: "7.8%",
    ugcAssetYield: 12,
    ftcComplianceScore: "100% Compliant Caption Baseline Tracker",
    copyrightStatus: "Copyright & Audio Sync Security Passed",
    creatorDeliverables: [
      {
        creatorHandle: "@ava",
        niche: "Beauty / Skincare",
        deliverableType: "60s Morning Glow Routine UGC",
        views: "340,200",
        engagement: "8.4%",
        ftcTag: "Verified #ad"
      },
      {
        creatorHandle: "@paws_and_palette",
        niche: "Pets & Lifestyle",
        deliverableType: "Golden Retriever Hydration Story",
        views: "295,000",
        engagement: "7.9%",
        ftcTag: "Verified #ad"
      },
      {
        creatorHandle: "@velvet_botanics",
        niche: "Aesthetic Lifestyle",
        deliverableType: "Evening Routine 4K Carousel",
        views: "207,300",
        engagement: "6.8%",
        ftcTag: "Verified #ad"
      }
    ]
  },
  onAddActivityLog,
  triggerNotification,
  userRole = 'director',
  currentRole = 'director'
}: ExecutiveWrapUpReportProps) {
  const effectiveRole = (currentRole || userRole || '').toLowerCase();
  const isDirector = effectiveRole === 'director' || effectiveRole === 'owner' || effectiveRole === 'agency';
  const isAgentMgr = !isDirector;
  const [data, setData] = useState<ClientWrapUpData>(initialData);
  const [isExporting, setIsExporting] = useState(false);
  const [showHowItWorks, setShowHowItWorks] = useState(false);
  const [showManualLogModal, setShowManualLogModal] = useState(false);
  const [showUploadVideoModal, setShowUploadVideoModal] = useState(false);
  const [activeVideoModalUrl, setActiveVideoModalUrl] = useState<string | null>(null);

  // Manual Log Form State
  const [editBrandName, setEditBrandName] = useState(data.brandName);
  const [editCampaignTitle, setEditCampaignTitle] = useState(data.campaignTitle);
  const [editTotalReach, setEditTotalReach] = useState(data.totalReach);
  const [editTotalViews, setEditTotalViews] = useState(data.totalViews);
  const [editEngagementRate, setEditEngagementRate] = useState(data.engagementRate);
  const [editUgcAssetYield, setEditUgcAssetYield] = useState(data.ugcAssetYield);

  // Uploaded Video Proofs State
  const [uploadedVideos, setUploadedVideos] = useState<UploadedVideoProof[]>([
    {
      id: 'proof_1',
      creatorHandle: '@ava',
      deliverableTitle: 'Morning Dew Drops Reel',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-girl-applying-face-cream-in-a-mirror-41484-large.mp4',
      views: '340,200',
      engagement: '8.4%',
      timestamp: '2026-08-24 09:30 AM'
    }
  ]);

  const [uploadHandle, setUploadHandle] = useState('@ava');
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadUrlInput, setUploadUrlInput] = useState('');
  const fileUploadRef = useRef<HTMLInputElement>(null);

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await exportClientWrapUpPDF(data);
      if (triggerNotification) {
        triggerNotification("Report Exported", "Executive Wrap-Up PDF saved.", "success");
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsExporting(false);
    }
  };

  const handleSaveManualLog = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: ClientWrapUpData = {
      ...data,
      brandName: editBrandName,
      campaignTitle: editCampaignTitle,
      totalReach: editTotalReach,
      totalViews: editTotalViews,
      engagementRate: editEngagementRate,
      ugcAssetYield: Number(editUgcAssetYield) || data.ugcAssetYield
    };
    setData(updated);
    setShowManualLogModal(false);
    if (triggerNotification) {
      triggerNotification("Wrap-Up Updated", "Manual metrics and campaign details logged successfully.", "success");
    }
    if (onAddActivityLog) {
      onAddActivityLog("Director", "director", `Manually logged Executive Wrap-Up Report for ${editBrandName}`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const blobUrl = URL.createObjectURL(file);
      const newProof: UploadedVideoProof = {
        id: 'proof_' + Date.now(),
        creatorHandle: uploadHandle || '@creator',
        deliverableTitle: uploadTitle || file.name.replace(/\.[^/.]+$/, ""),
        videoUrl: blobUrl,
        views: 'Verified Upload',
        engagement: 'Pending AI Scan',
        timestamp: new Date().toLocaleString()
      };
      setUploadedVideos(prev => [newProof, ...prev]);
      setShowUploadVideoModal(false);
      setUploadTitle('');
      setUploadUrlInput('');
      if (triggerNotification) {
        triggerNotification("Video Proof Uploaded", `Attached ${file.name} to Executive Wrap-Up vault.`, "success");
      }
    }
  };

  const handleDirectUrlUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadUrlInput.trim()) return;
    const newProof: UploadedVideoProof = {
      id: 'proof_' + Date.now(),
      creatorHandle: uploadHandle || '@creator',
      deliverableTitle: uploadTitle || 'Direct Social Video Link',
      videoUrl: uploadUrlInput.trim(),
      views: 'Direct Link Verified',
      engagement: 'API Monitored',
      timestamp: new Date().toLocaleString()
    };
    setUploadedVideos(prev => [newProof, ...prev]);
    setShowUploadVideoModal(false);
    setUploadTitle('');
    setUploadUrlInput('');
    if (triggerNotification) {
      triggerNotification("Video Link Added", "External deliverable video URL linked to report.", "success");
    }
  };

  return (
    <div className="bg-agency-navy border border-agency-gold/30 rounded-3xl p-6 md:p-8 shadow-2xl text-agency-textLight space-y-6 max-w-5xl mx-auto font-sans">
      
      {/* Top Bar with How It Works, Manual Log, Upload Video, and Export PDF */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-agency-navyLight border border-agency-gold/40 flex flex-col items-center justify-center text-center p-1 shadow-inner shrink-0">
            <span className="text-[10px] uppercase font-mono text-agency-gold font-bold">BRAND</span>
            <span className="text-[9px] text-slate-400 font-mono">LOGO</span>
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] uppercase font-mono font-bold tracking-wider text-agency-gold bg-agency-navyLight border border-agency-gold/30 px-3 py-0.5 rounded-full">
                Client Executive Summary
              </span>
              <span className="text-xs text-emerald-400 font-mono bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                Verified Final
              </span>
              <button
                type="button"
                onClick={() => setShowHowItWorks(!showHowItWorks)}
                className="text-[11px] text-slate-300 hover:text-white flex items-center gap-1 font-mono bg-white/5 border border-white/10 px-2.5 py-0.5 rounded-full transition cursor-pointer"
              >
                <Info className="w-3 h-3 text-[#C9A46A]" />
                <span>How This Generates</span>
              </button>
            </div>
            <h2 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5">
              {data.campaignTitle}
            </h2>
            <p className="text-xs text-slate-400">
              Prepared for <strong className="text-agency-gold">{data.brandName}</strong> &bull; {data.date} &bull; Bloom Studio
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {!isAgentMgr && (
            <>
              <button
                type="button"
                onClick={() => setShowManualLogModal(true)}
                className="inline-flex items-center gap-1.5 bg-agency-navyLight hover:bg-[#16243F] text-slate-200 border border-agency-gold/40 text-xs font-mono font-bold px-3.5 py-2.5 rounded-xl transition cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-[#C9A46A]" />
                <span>Log / Edit Metrics</span>
              </button>

              <button
                type="button"
                onClick={() => setShowUploadVideoModal(true)}
                className="inline-flex items-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold px-3.5 py-2.5 rounded-xl transition cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Video Proof</span>
              </button>
            </>
          )}

          {isAgentMgr && (
            <span className="text-xs font-mono text-agency-gold bg-agency-navyLight border border-agency-gold/30 px-3 py-2 rounded-xl">
              🔒 Agent Manager View: Read-Only Director-Sent Summary Report
            </span>
          )}

          {!isAgentMgr && (
            <button
              type="button"
              onClick={handleExport}
              disabled={isExporting}
              className="inline-flex items-center gap-2 bg-agency-gold hover:bg-[#b89359] text-agency-navy font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg transition-all cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Exporting...' : 'Export Final PDF'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Explanatory Banner (How Does This Report Generate?) */}
      {showHowItWorks && (
        <div className="bg-[#091322] border-2 border-[#C9A46A]/40 rounded-2xl p-5 space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold font-mono text-[#C9A46A] uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#C9A46A]" />
              Automated Intelligence &amp; Ingestion Architecture
            </h4>
            <button onClick={() => setShowHowItWorks(false)} className="text-slate-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The Executive Wrap-Up Report is generated automatically by aggregating live campaign telemetry from verified TikTok, Instagram Reels, and YouTube APIs across all logged deliverables in your campaigns. It calculates cumulative impressions, audience retention, and verified FTC compliance tags.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1 text-[11px] font-mono text-slate-400">
            <div className="bg-black/30 p-2.5 rounded-xl border border-white/5">
              <strong className="text-white block mb-0.5">● If API scraping fails or account is private:</strong>
              Use the <strong className="text-[#C9A46A]">"Upload Video Proof"</strong> button to attach video files directly or enter live post links.
            </div>
            <div className="bg-black/30 p-2.5 rounded-xl border border-white/5">
              <strong className="text-white block mb-0.5">● If metrics need custom adjustments:</strong>
              Click <strong className="text-[#C9A46A]">"Log / Edit Metrics"</strong> to enter customized view counts, engagement benchmarks, and deliverable stats.
            </div>
          </div>
        </div>
      )}

      {/* 1. High-Level Performance Grid (3 Columns) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Card 1: Total Reach & Video Views */}
        <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-5 space-y-2 shadow-md">
          <span className="text-[11px] uppercase font-mono tracking-wider text-slate-400 flex items-center justify-between">
            <span>Total Campaign Reach &amp; Views</span>
            <Eye className="w-4 h-4 text-agency-gold" />
          </span>
          <div className="text-3xl font-bold font-mono text-white">
            {data.totalViews}
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            {data.totalReach} Cumulative Impressions across TikTok &amp; Reels
          </p>
        </div>

        {/* Card 2: Overall Audience Engagement Rate */}
        <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-5 space-y-2 shadow-md">
          <span className="text-[11px] uppercase font-mono tracking-wider text-slate-400 flex items-center justify-between">
            <span>Overall Engagement Rate</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </span>
          <div className="text-3xl font-bold font-mono text-emerald-400">
            {data.engagementRate}
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            Benchmark: 2.1x higher than standard organic category baseline
          </p>
        </div>

        {/* Card 3: Asset Production Yield */}
        <div className="bg-agency-navyLight border border-agency-gold/40 rounded-2xl p-5 space-y-2 shadow-md">
          <span className="text-[11px] uppercase font-mono tracking-wider text-agency-gold flex items-center justify-between">
            <span>Asset Production Yield</span>
            <Award className="w-4 h-4 text-agency-gold" />
          </span>
          <div className="text-3xl font-bold font-mono text-agency-gold">
            {data.ugcAssetYield} Final UGC Videos
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            Handcrafted 4K deliverables cleared for digital ad whitelisting
          </p>
        </div>
      </div>

      {/* 2. Legal & Safety Trust Score Panel */}
      <div className="bg-agency-navyLight border border-agency-gold/30 rounded-2xl p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-agency-gold" /> Legal &amp; Safety Trust Score Certification
          </h3>
          <span className="text-[10px] font-mono text-agency-gold bg-agency-navy border border-agency-gold/30 px-2.5 py-0.5 rounded-full">
            100% Brand Safe
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-agency-navy p-3.5 rounded-xl border border-white/5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-950/60 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">FTC Caption Compliance Score</span>
              <span className="text-[11px] text-emerald-400 font-mono">{data.ftcComplianceScore}</span>
            </div>
          </div>

          <div className="bg-agency-navy p-3.5 rounded-xl border border-white/5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-agency-gold/20 text-agency-gold flex items-center justify-center border border-agency-gold/30">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">Commercial Audio Whitelist</span>
              <span className="text-[11px] text-agency-gold font-mono">{data.copyrightStatus}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Proof-of-Post Video Vault (Uploaded Videos by Agency & Creators) */}
      <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-[#C9A46A]" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Proof-of-Post &amp; Video Delivery Vault ({uploadedVideos.length} Attached)
            </h3>
          </div>
          <button
            type="button"
            onClick={() => setShowUploadVideoModal(true)}
            className="text-[11px] font-mono text-[#C9A46A] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" /> Attach Video
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {uploadedVideos.map((video) => (
            <div key={video.id} className="p-3 bg-agency-navy rounded-xl border border-white/5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => setActiveVideoModalUrl(video.videoUrl)}
                  className="w-10 h-10 rounded-lg bg-black/40 border border-white/10 flex items-center justify-center text-[#C9A46A] hover:bg-[#C9A46A]/20 transition shrink-0 cursor-pointer"
                >
                  <Play className="w-4 h-4 ml-0.5 fill-[#C9A46A]" />
                </button>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block truncate">{video.deliverableTitle}</span>
                  <span className="text-[10px] font-mono text-slate-400">{video.creatorHandle} &bull; {video.timestamp}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  {video.views}
                </span>
                <button
                  type="button"
                  onClick={() => setUploadedVideos(prev => prev.filter(v => v.id !== video.id))}
                  className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                  title="Remove video proof"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Creator Asset Delivery Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-2">
            <Video className="w-4 h-4 text-agency-gold" /> Creator Deliverable Breakdown
          </h3>
          <span className="text-[11px] font-mono text-slate-400">
            {data.creatorDeliverables.length} Featured Talent Deliverables
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {data.creatorDeliverables.map((item, idx) => (
            <div
              key={idx}
              className="bg-agency-navyLight border border-white/10 hover:border-agency-gold/50 rounded-2xl p-4 space-y-3 transition-all shadow-md group"
            >
              <div className="relative aspect-[9/12] w-full rounded-xl bg-agency-navy border border-white/10 overflow-hidden flex flex-col items-center justify-center group-hover:border-agency-gold/40 transition-all">
                <div className="w-12 h-12 rounded-full bg-agency-gold/20 text-agency-gold flex items-center justify-center border border-agency-gold/40 shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="w-5 h-5 fill-agency-gold ml-0.5" />
                </div>
                <span className="text-[10px] font-mono text-slate-400 mt-2">
                  Live 4K UGC Video
                </span>

                <span className="absolute top-2.5 right-2.5 text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                  {item.ftcTag}
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{item.creatorHandle}</span>
                  <span className="text-[10px] font-mono text-slate-400">{item.niche}</span>
                </div>
                <p className="text-[11px] text-slate-300 line-clamp-1">{item.deliverableType}</p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5 text-[11px] font-mono">
                <div>
                  <span className="text-slate-400 block text-[9px] uppercase">Views</span>
                  <span className="text-white font-bold">{item.views}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[9px] uppercase">Eng. Rate</span>
                  <span className="text-emerald-400 font-bold">{item.engagement}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Manual Log / Edit Metrics Modal */}
      {showManualLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-agency-navy border border-agency-gold/40 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2 text-agency-gold text-xs font-mono font-bold uppercase">
                <Edit3 className="w-4 h-4" />
                <span>Manually Log Executive Wrap-Up Metrics</span>
              </div>
              <button onClick={() => setShowManualLogModal(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveManualLog} className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Brand Client Name</label>
                <input
                  type="text"
                  value={editBrandName}
                  onChange={e => setEditBrandName(e.target.value)}
                  className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Campaign Title</label>
                <input
                  type="text"
                  value={editCampaignTitle}
                  onChange={e => setEditCampaignTitle(e.target.value)}
                  className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase text-slate-400 mb-1">Total Impressions / Reach</label>
                  <input
                    type="text"
                    value={editTotalReach}
                    onChange={e => setEditTotalReach(e.target.value)}
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase text-slate-400 mb-1">Total Video Views</label>
                  <input
                    type="text"
                    value={editTotalViews}
                    onChange={e => setEditTotalViews(e.target.value)}
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase text-slate-400 mb-1">Engagement Rate (%)</label>
                  <input
                    type="text"
                    value={editEngagementRate}
                    onChange={e => setEditEngagementRate(e.target.value)}
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase text-slate-400 mb-1">UGC Asset Yield (Count)</label>
                  <input
                    type="number"
                    value={editUgcAssetYield}
                    onChange={e => setEditUgcAssetYield(Number(e.target.value))}
                    className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowManualLogModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-agency-gold text-agency-navy font-bold uppercase"
                >
                  Save Metrics
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upload Video Proof Modal */}
      {showUploadVideoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-agency-navy border border-emerald-500/40 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-mono font-bold uppercase">
                <Upload className="w-4 h-4" />
                <span>Upload Deliverable Video Proof</span>
              </div>
              <button onClick={() => setShowUploadVideoModal(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Upload local MP4/WebM video files directly if social AI scraper is unable to access private creator reels.
            </p>

            <div className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Creator Handle</label>
                <input
                  type="text"
                  value={uploadHandle}
                  onChange={e => setUploadHandle(e.target.value)}
                  className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 mb-1">Deliverable Title / Reel Name</label>
                <input
                  type="text"
                  placeholder="e.g. 60s Hydration Routine Reel"
                  value={uploadTitle}
                  onChange={e => setUploadTitle(e.target.value)}
                  className="w-full bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                />
              </div>

              {/* File Upload Box */}
              <div 
                onClick={() => fileUploadRef.current?.click()}
                className="p-6 border-2 border-dashed border-emerald-500/40 hover:border-emerald-400 rounded-2xl bg-black/20 text-center cursor-pointer space-y-2 transition"
              >
                <Upload className="w-8 h-8 text-emerald-400 mx-auto" />
                <span className="text-xs font-bold text-white block">Click to Select MP4 / MOV Video</span>
                <span className="text-[10px] text-slate-400 font-mono">Supports MP4, WebM, QuickTime (Up to 500MB)</span>
                <input
                  ref={fileUploadRef}
                  type="file"
                  accept="video/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>

              {/* Or Direct URL */}
              <div className="pt-2">
                <span className="text-[10px] uppercase text-slate-400 block mb-1">Or Attach Direct Video / Stream URL:</span>
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="https://..."
                    value={uploadUrlInput}
                    onChange={e => setUploadUrlInput(e.target.value)}
                    className="flex-1 bg-agency-navyLight border border-white/10 rounded-xl px-3 py-2 text-white"
                  />
                  <button
                    type="button"
                    onClick={handleDirectUrlUpload}
                    className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs uppercase"
                  >
                    Attach
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Video Player Modal */}
      {activeVideoModalUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="bg-agency-navy border border-agency-gold/40 rounded-3xl max-w-2xl w-full p-4 space-y-3 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-mono font-bold text-white">Video Deliverable Proof Preview</span>
              <button onClick={() => setActiveVideoModalUrl(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="rounded-2xl overflow-hidden bg-black aspect-video flex items-center justify-center">
              <video src={activeVideoModalUrl} controls autoPlay className="w-full h-full object-contain" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
