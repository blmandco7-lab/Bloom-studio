import React, { useState, useMemo } from 'react';
import { CreatorCastingMarketplace } from './CreatorCastingMarketplace';
import { 
  Megaphone, Plus, Search, Filter, Sparkles, Star, CheckCircle, 
  Clock, X, Eye, ThumbsUp, Send, Check, AlertCircle, ChevronRight, 
  User, Heart, Play, Film, Award, TrendingUp, DollarSign, Calendar
} from 'lucide-react';

export type NicheCategory = 'Pets' | 'Beauty' | 'Lifestyle';

export interface CreatorAudition {
  id: string;
  handle: string;
  creatorName: string;
  avatarUrl: string;
  niche: NicheCategory;
  matchScore: number; // e.g. 98 for 98%
  followersCount: string;
  engagementRate: string;
  campaignTitle: string;
  brand: string;
  compensation: string;
  pitchSnippet: string;
  submittedAt: string;
  status: 'Under Review' | 'Shortlisted' | 'Audition Approved' | 'Offered' | 'Passed';
  reelDuration?: string;
  keyHighlights: string[];
}

export interface CastingBrief {
  id: string;
  title: string;
  brand: string;
  niche: NicheCategory;
  budget: string;
  rolesCount: number;
  deadline: string;
  requirements: string;
  status: 'Open' | 'Reviewing' | 'Closed';
}

const INITIAL_AUDITIONS: CreatorAudition[] = [
  {
    id: 'aud_1',
    handle: '@paws_and_palette',
    creatorName: 'Sophie & Oliver (Golden Retriever)',
    avatarUrl: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=150&auto=format&fit=crop&q=80',
    niche: 'Pets',
    matchScore: 98,
    followersCount: '485K',
    engagementRate: '5.8%',
    campaignTitle: 'BarkBox Summer Treat Box Commercial',
    brand: 'BarkBox',
    compensation: '$4,500 + $350 PR Box',
    pitchSnippet: 'Oliver loves high-protein freeze-dried snacks! We have high-speed 4K Sony FX3 camera gear ready for cinematic slow-motion taste test shots.',
    submittedAt: '2026-08-22',
    status: 'Shortlisted',
    reelDuration: '0:45',
    keyHighlights: ['4K Cinematic Sony FX3', 'High Engagement Pets Audience', 'Fast 48-hour turn around']
  },
  {
    id: 'aud_2',
    handle: '@glow_with_mia',
    creatorName: 'Mia Chen',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    niche: 'Beauty',
    matchScore: 95,
    followersCount: '620K',
    engagementRate: '4.6%',
    campaignTitle: 'GlowLab Vitamin C Serum Launch',
    brand: 'GlowLab Beauty',
    compensation: '$5,200 + Full Skincare Set',
    pitchSnippet: 'Specializing in close-up glass-skin texture routines and natural morning lighting transitions without beauty filters.',
    submittedAt: '2026-08-21',
    status: 'Audition Approved',
    reelDuration: '0:60',
    keyHighlights: ['Filter-free Glass Skin Macro', 'Proven DTC Conversion', 'US Top 10 Beauty Creator']
  },
  {
    id: 'aud_3',
    handle: '@golden_whisker',
    creatorName: 'Liam Davis & Milo',
    avatarUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=150&auto=format&fit=crop&q=80',
    niche: 'Pets',
    matchScore: 92,
    followersCount: '310K',
    engagementRate: '6.4%',
    campaignTitle: 'Whiskers & Co. Cat Tree & Scratching Post',
    brand: 'Whiskers & Co.',
    compensation: '$3,800 + Deluxe Tree',
    pitchSnippet: 'Milo is extremely playful with automated laser toys and cat towers. Perfect comedic reel format with viral audio hook.',
    submittedAt: '2026-08-20',
    status: 'Under Review',
    reelDuration: '0:38',
    keyHighlights: ['6.4% Viral Engagement', 'Humor + Aesthetic Home', 'Pet Parents 25-34 Demo']
  },
  {
    id: 'aud_4',
    handle: '@velvet_botanics',
    creatorName: 'Elena Rostova',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    niche: 'Beauty',
    matchScore: 94,
    followersCount: '410K',
    engagementRate: '5.1%',
    campaignTitle: 'Botanical Hair Oil Serum Spotlight',
    brand: 'Luxe Haircare',
    compensation: '$4,200',
    pitchSnippet: 'Can demonstrate split-end repair with wet-to-dry silk blowout tutorial. High aesthetic bathroom and vanity setup.',
    submittedAt: '2026-08-19',
    status: 'Offered',
    reelDuration: '0:52',
    keyHighlights: ['Hair Care Specialist', 'Aesthetic Vanity Studio', 'Editorial Lighting']
  },
  {
    id: 'aud_5',
    handle: '@aurora_lifestyle',
    creatorName: 'Marcus & Aurora',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    niche: 'Lifestyle',
    matchScore: 89,
    followersCount: '275K',
    engagementRate: '4.9%',
    campaignTitle: 'Nordic Clean Linen & Home Scenting',
    brand: 'Nordic Living',
    compensation: '$3,500 + Home Bundle',
    pitchSnippet: 'Sunday reset routine incorporating morning matcha, linen making, and diffuser misting. Neutral minimalist aesthetic.',
    submittedAt: '2026-08-18',
    status: 'Under Review',
    reelDuration: '0:48',
    keyHighlights: ['Clean Aesthetic Decor', 'Sunday Reset Routine', 'DTC Homebuyer Reach']
  },
  {
    id: 'aud_6',
    handle: '@luxe_paws',
    creatorName: 'Chloe Taylor & Coco (Frenchie)',
    avatarUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=150&auto=format&fit=crop&q=80',
    niche: 'Pets',
    matchScore: 91,
    followersCount: '520K',
    engagementRate: '5.3%',
    campaignTitle: 'BarkBox Summer Treat Box Commercial',
    brand: 'BarkBox',
    compensation: '$4,500',
    pitchSnippet: 'Coco has high comedic facial expressions that always get 500k+ organic views. We love making fast-paced product unboxings!',
    submittedAt: '2026-08-17',
    status: 'Shortlisted',
    reelDuration: '0:40',
    keyHighlights: ['500K+ Viral Views Average', 'Comedic Expression Frenchie', 'TikTok Shop Affiliate Certified']
  }
];

export default function CastingDashboard({ 
  currentUser, 
  currentRole, 
  canAgentMgrCreateCastingCalls = true,
  creators = [],
  triggerNotification,
  onAddActivityLog
}: { 
  currentUser?: any; 
  currentRole?: string; 
  canAgentMgrCreateCastingCalls?: boolean;
  creators?: any[];
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}) {
  // Local state for audition records
  const [auditions, setAuditions] = useState<CreatorAudition[]>(INITIAL_AUDITIONS);
  const [selectedNiche, setSelectedNiche] = useState<'All' | NicheCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedAudition, setSelectedAudition] = useState<CreatorAudition | null>(null);

  // Referral Modal State for Agents / Managers
  const [referModalAudition, setReferModalAudition] = useState<CreatorAudition | null>(null);
  const [selectedReferHandle, setSelectedReferHandle] = useState<string>('');
  const [referNote, setReferNote] = useState<string>('Great fit for your aesthetic and current campaign availability!');
  const [referSuccess, setReferSuccess] = useState<boolean>(false);

  // Role Checks
  const isDirector = (currentRole || '').toLowerCase() === 'director';
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const isAgent = (currentRole || '').toLowerCase() === 'agent';
  const canIssueCastingCall = isDirector || (isAgentMgr && canAgentMgrCreateCastingCalls);

  // Assigned creator handles
  const myHandles = useMemo(() => {
    return (currentUser?.assignedCreators || currentUser?.assignedHandles || []).map((h: string) => h.toLowerCase());
  }, [currentUser]);

  const selectableCreators = useMemo(() => {
    if (isDirector) return creators;
    if (myHandles.length > 0) {
      const filtered = creators.filter((c: any) => myHandles.includes((c.handle || '').toLowerCase()));
      return filtered.length > 0 ? filtered : creators;
    }
    return creators;
  }, [isDirector, myHandles, creators]);

  // Modal State for Issuing New Casting Call
  const [showNewCallModal, setShowNewCallModal] = useState(false);
  const [newCallTitle, setNewCallTitle] = useState('');
  const [newCallBrand, setNewCallBrand] = useState('');
  const [newCallNiche, setNewCallNiche] = useState<NicheCategory>('Pets');
  const [newCallBudget, setNewCallBudget] = useState('$5,000');
  const [newCallRoles, setNewCallRoles] = useState(3);
  const [newCallDeadline, setNewCallDeadline] = useState('2026-09-15');
  const [newCallRequirements, setNewCallRequirements] = useState(
    '60-second dedicated TikTok reel with 4K macro product shots, FTC #ad disclosure, and link-in-bio inclusion for 7 days.'
  );
  const [callIssuedSuccess, setCallIssuedSuccess] = useState(false);

  // If creator, render marketplace
  if (currentUser?.role === 'creator') {
    return <CreatorCastingMarketplace currentUserHandle={currentUser.handle || '@unknown'} />;
  }
  
  // Filtered auditions calculation
  const filteredAuditions = useMemo(() => {
    return auditions.filter(aud => {
      const matchNiche = selectedNiche === 'All' || aud.niche === selectedNiche;
      const matchStatus = statusFilter === 'All' || aud.status === statusFilter;
      const q = searchQuery.toLowerCase().trim();
      const matchQuery = 
        !q || 
        aud.handle.toLowerCase().includes(q) || 
        aud.creatorName.toLowerCase().includes(q) || 
        aud.brand.toLowerCase().includes(q) || 
        aud.campaignTitle.toLowerCase().includes(q) || 
        aud.pitchSnippet.toLowerCase().includes(q);

      return matchNiche && matchStatus && matchQuery;
    });
  }, [auditions, selectedNiche, statusFilter, searchQuery]);

  // Summary Metrics
  const totalAuditionsCount = auditions.length;
  const shortlistedCount = auditions.filter(a => a.status === 'Shortlisted' || a.status === 'Audition Approved' || a.status === 'Offered').length;
  const avgMatchScore = Math.round(auditions.reduce((acc, curr) => acc + curr.matchScore, 0) / (auditions.length || 1));

  // Handler for Updating Audition Status
  const handleUpdateStatus = (id: string, newStatus: CreatorAudition['status'], e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setAuditions(prev => prev.map(item => item.id === id ? { ...item, status: newStatus } : item));
    if (selectedAudition?.id === id) {
      setSelectedAudition(prev => prev ? { ...prev, status: newStatus } : null);
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || 'Staff', currentRole || 'agent', `Updated audition status for ${id} to ${newStatus}`);
    }
  };

  // Handler for Referring Casting Call to Creator
  const handleReferToCreator = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReferHandle || !referModalAudition) return;

    try {
      const referralEntry = {
        id: `cref_${Date.now()}`,
        auditionId: referModalAudition.id,
        campaignTitle: referModalAudition.campaignTitle,
        brand: referModalAudition.brand,
        creatorHandle: selectedReferHandle,
        agentName: currentUser?.name || 'Agent',
        note: referNote,
        date: new Date().toISOString()
      };
      const saved = JSON.parse(localStorage.getItem('wl_casting_referrals') || '[]');
      localStorage.setItem('wl_casting_referrals', JSON.stringify([referralEntry, ...saved]));
    } catch {}

    setReferSuccess(true);
    if (triggerNotification) {
      triggerNotification(
        "Casting Brief Dispatched",
        `Successfully referred "${referModalAudition.campaignTitle}" to creator ${selectedReferHandle}.`,
        "success"
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || "Agent",
        currentRole || "agent",
        `Referred casting call for ${referModalAudition.brand} to creator ${selectedReferHandle}`
      );
    }

    setTimeout(() => {
      setReferSuccess(false);
      setReferModalAudition(null);
      setSelectedReferHandle('');
    }, 1200);
  };

  // Handler for Issuing New Casting Call
  const handleCreateCastingCall = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCallTitle || !newCallBrand) return;

    // Simulate adding placeholder audition for the new brief
    const mockNewAudition: CreatorAudition = {
      id: `aud_${Date.now()}`,
      handle: '@paws_and_palette',
      creatorName: 'Sophie & Oliver',
      avatarUrl: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=150&auto=format&fit=crop&q=80',
      niche: newCallNiche,
      matchScore: 97,
      followersCount: '485K',
      engagementRate: '5.8%',
      campaignTitle: newCallTitle,
      brand: newCallBrand,
      compensation: newCallBudget,
      pitchSnippet: `Instant fast-track pitch for ${newCallBrand}: Ready to deliver ${newCallRequirements.slice(0, 80)}...`,
      submittedAt: new Date().toISOString().split('T')[0],
      status: 'Under Review',
      reelDuration: '0:45',
      keyHighlights: ['Target Niche Verified', 'FTC Compliant Format', 'Priority Fast Track']
    };

    setAuditions(prev => [mockNewAudition, ...prev]);
    setCallIssuedSuccess(true);

    setTimeout(() => {
      setCallIssuedSuccess(false);
      setShowNewCallModal(false);
      setNewCallTitle('');
      setNewCallBrand('');
    }, 1500);
  };

  return (
    <div className="space-y-6 text-white max-w-7xl mx-auto animate-fade-in">
      {/* Top Header Section */}
      <div className="bg-[#0B1B3D] border border-[#D4AF37]/35 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Ambient Gold Glows */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#D4AF37] bg-[#D4AF37]/15 border border-[#D4AF37]/30 px-3 py-0.5 rounded-full">
                Talent Scouting &amp; Auditions
              </span>
              <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> 3 Core Niches Active
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1.5 flex items-center gap-2.5">
              <Megaphone className="w-7 h-7 text-[#D4AF37]" /> Casting Dashboard
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Review incoming creator auditions, match scores, and audition reels for brand sponsorships across <strong className="text-white">Pets</strong>, <strong className="text-white">Beauty</strong>, and <strong className="text-white">Lifestyle</strong>.
            </p>
          </div>

          {/* Action Button: Issue New Casting Call (Only shown to Director or authorized Agent Manager) */}
          {canIssueCastingCall ? (
            <button
              type="button"
              onClick={() => setShowNewCallModal(true)}
              className="bg-[#D4AF37] hover:bg-[#b89359] text-[#0B1B3D] font-bold text-xs md:text-sm px-5 py-3 rounded-2xl flex items-center gap-2 shadow-lg shadow-[#D4AF37]/20 transition-all hover:scale-[1.02] cursor-pointer self-start md:self-auto shrink-0"
            >
              <Plus className="w-4 h-4 text-[#0B1B3D] stroke-[2.5]" />
              <span>Issue New Casting Call</span>
            </button>
          ) : (
            <div className="bg-[#112240] border border-white/10 rounded-2xl px-4 py-2 text-xs text-slate-300 flex items-center gap-2 self-start md:self-auto shrink-0">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>Browse &amp; Refer Briefs to Talent</span>
            </div>
          )}
        </div>

        {/* Quick Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-white/10 relative z-10">
          <div className="bg-[#112240] border border-white/5 rounded-xl p-3">
            <div className="text-[10px] uppercase font-mono text-slate-400">Total Auditions</div>
            <div className="text-xl font-bold font-mono text-white mt-0.5">{totalAuditionsCount}</div>
            <div className="text-[10px] text-slate-400">Across active briefs</div>
          </div>

          <div className="bg-[#112240] border border-[#D4AF37]/30 rounded-xl p-3">
            <div className="text-[10px] uppercase font-mono text-slate-400">Average Match Score</div>
            <div className="text-xl font-bold font-mono text-[#D4AF37] mt-0.5">{avgMatchScore}%</div>
            <div className="text-[10px] text-emerald-400">High affinity talent</div>
          </div>

          <div className="bg-[#112240] border border-emerald-500/20 rounded-xl p-3">
            <div className="text-[10px] uppercase font-mono text-slate-400">Shortlisted / Approved</div>
            <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">{shortlistedCount}</div>
            <div className="text-[10px] text-slate-400">Ready for booking</div>
          </div>

          <div className="bg-[#112240] border border-purple-500/20 rounded-xl p-3">
            <div className="text-[10px] uppercase font-mono text-slate-400">Open Casting Calls</div>
            <div className="text-xl font-bold font-mono text-purple-300 mt-0.5">4 Active</div>
            <div className="text-[10px] text-slate-400">BarkBox, GlowLab &amp; more</div>
          </div>
        </div>
      </div>

      {/* Filter Tags Specifically Tailored for Niches: Pets, Beauty, Lifestyle */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0B1B3D] border border-white/5 rounded-2xl p-5 shadow-sm">
        {/* Niche Filter Pills */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-semibold text-slate-500 mr-2 flex items-center gap-1.5 uppercase tracking-wider">
            <Filter className="w-3.5 h-3.5 text-[#D4AF37]" /> Filter By Niche:
          </span>

          {(['All', 'Pets', 'Beauty', 'Lifestyle'] as const).map(niche => {
            const isSelected = selectedNiche === niche;
            return (
              <button
                key={niche}
                type="button"
                onClick={() => setSelectedNiche(niche)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-2 ${
                  isSelected
                    ? 'bg-[#D4AF37] text-[#0B1B3D] font-bold shadow-md shadow-[#D4AF37]/10'
                    : 'bg-[#112240] text-slate-300 hover:text-white border border-white/5 hover:border-white/10'
                }`}
              >
                {niche === 'Pets' && '🐾'}
                {niche === 'Beauty' && '✨'}
                {niche === 'Lifestyle' && '🌿'}
                {niche === 'All' && '🌟'}
                <span>{niche === 'All' ? 'All' : niche}</span>
              </button>
            );
          })}
        </div>

        {/* Search & Status Filter */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3.5 top-3 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search creator, brand, campaign..."
              className="w-full bg-[#112240] border border-white/5 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-[#D4AF37]/50"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#112240] border border-white/5 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#D4AF37]/50"
          >
            <option value="All">All Statuses</option>
            <option value="Under Review">Under Review</option>
            <option value="Shortlisted">Shortlisted</option>
            <option value="Audition Approved">Audition Approved</option>
            <option value="Offered">Offered</option>
          </select>
        </div>
      </div>

      {/* Clean Table Framework Listing Creator Auditions */}
      <div className="bg-[#0B1B3D] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            {/* Table Header */}
            <thead className="bg-[#0D1830] text-slate-400 font-mono uppercase text-[10px] tracking-wider border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4">Creator Handle</th>
                <th className="py-3.5 px-4">Match Score</th>
                <th className="py-3.5 px-4">Niche Category</th>
                <th className="py-3.5 px-4">Campaign &amp; Brand</th>
                <th className="py-3.5 px-4">Compensation</th>
                <th className="py-3.5 px-4">Audition Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-white/5">
              {filteredAuditions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    <Megaphone className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    <p className="font-semibold text-white">No Auditions Match Current Filter</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">Try resetting search or adjusting niche filters.</p>
                  </td>
                </tr>
              ) : (
                filteredAuditions.map((aud) => {
                  const isTopMatch = aud.matchScore >= 95;

                  return (
                    <tr
                      key={aud.id}
                      onClick={() => setSelectedAudition(aud)}
                      className="hover:bg-[#112240]/80 transition-colors cursor-pointer group"
                    >
                      {/* Creator Handle & Avatar */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={aud.avatarUrl}
                            alt={aud.creatorName}
                            className="w-9 h-9 rounded-full object-cover border border-[#D4AF37]/30 group-hover:border-[#D4AF37] transition-colors"
                          />
                          <div>
                            <div className="font-bold text-white group-hover:text-[#D4AF37] transition-colors flex items-center gap-1.5 flex-wrap">
                              <span>{aud.handle}</span>
                              {myHandles.includes(aud.handle.toLowerCase()) && (
                                <span className="text-[9px] bg-purple-500/20 text-purple-300 border border-purple-500/40 px-1.5 py-0.2 rounded font-mono font-bold">
                                  ★ MY CREATOR
                                </span>
                              )}
                              {isTopMatch && (
                                <span className="text-[9px] bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 px-1.5 py-0.2 rounded font-mono">
                                  TOP PICK
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400">{aud.creatorName} &bull; {aud.followersCount}</div>
                          </div>
                        </div>
                      </td>

                      {/* Match Score */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <div className={`font-mono font-bold text-sm px-2.5 py-0.5 rounded-lg border ${
                            aud.matchScore >= 95
                              ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                              : aud.matchScore >= 90
                              ? 'bg-[#D4AF37]/15 text-[#D4AF37] border-[#D4AF37]/30'
                              : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                          }`}>
                            {aud.matchScore}%
                          </div>
                          <div className="w-16 h-1.5 bg-slate-700/60 rounded-full overflow-hidden hidden sm:block">
                            <div
                              className={`h-full rounded-full ${
                                aud.matchScore >= 95 ? 'bg-emerald-400' : 'bg-[#D4AF37]'
                              }`}
                              style={{ width: `${aud.matchScore}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      {/* Niche Category */}
                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold border ${
                          aud.niche === 'Pets'
                            ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                            : aud.niche === 'Beauty'
                            ? 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                            : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                        }`}>
                          {aud.niche === 'Pets' && '🐾'}
                          {aud.niche === 'Beauty' && '✨'}
                          {aud.niche === 'Lifestyle' && '🌿'}
                          <span>{aud.niche}</span>
                        </span>
                      </td>

                      {/* Campaign & Brand */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-200">{aud.campaignTitle}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{aud.brand}</div>
                      </td>

                      {/* Compensation */}
                      <td className="py-3.5 px-4 font-mono text-emerald-400 font-semibold">
                        {aud.compensation}
                      </td>

                      {/* Audition Status */}
                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                          aud.status === 'Offered'
                            ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                            : aud.status === 'Audition Approved'
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                            : aud.status === 'Shortlisted'
                            ? 'bg-[#D4AF37]/15 text-[#D4AF37] border-[#D4AF37]/30'
                            : aud.status === 'Passed'
                            ? 'bg-red-500/15 text-red-300 border-red-500/30'
                            : 'bg-slate-500/15 text-slate-300 border-slate-500/30'
                        }`}>
                          {aud.status}
                        </span>
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => setSelectedAudition(aud)}
                            className="bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white px-2.5 py-1 rounded-lg text-[11px] font-semibold border border-white/10 transition-colors flex items-center gap-1 cursor-pointer"
                            title="Review Audition Reel & Pitch"
                          >
                            <Eye className="w-3 h-3 text-[#D4AF37]" />
                            <span>Review</span>
                          </button>

                          {/* Refer to Creator Button for Agents / Managers */}
                          <button
                            type="button"
                            onClick={() => {
                              setReferModalAudition(aud);
                              setSelectedReferHandle(selectableCreators[0]?.handle || '');
                            }}
                            className="bg-purple-950/60 hover:bg-purple-900/80 text-purple-300 px-2.5 py-1 rounded-lg text-[11px] font-semibold border border-purple-500/30 transition-colors flex items-center gap-1 cursor-pointer"
                            title="Refer this casting call to one of your creators"
                          >
                            <Send className="w-3 h-3 text-purple-300" />
                            <span>Refer</span>
                          </button>

                          {!isAgent && aud.status !== 'Shortlisted' && aud.status !== 'Audition Approved' && aud.status !== 'Offered' && (
                            <button
                              type="button"
                              onClick={(e) => handleUpdateStatus(aud.id, 'Shortlisted', e)}
                              className="bg-[#D4AF37]/15 hover:bg-[#D4AF37]/30 text-[#D4AF37] px-2.5 py-1 rounded-lg text-[11px] font-semibold border border-[#D4AF37]/30 transition-colors cursor-pointer"
                            >
                              Shortlist
                            </button>
                          )}

                          {!isAgent && aud.status !== 'Audition Approved' && aud.status !== 'Offered' && (
                            <button
                              type="button"
                              onClick={(e) => handleUpdateStatus(aud.id, 'Audition Approved', e)}
                              className="bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 px-2.5 py-1 rounded-lg text-[11px] font-semibold border border-emerald-500/30 transition-colors cursor-pointer"
                            >
                              Approve
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* =========================================================================
          MODAL: ISSUE NEW CASTING CALL
         ========================================================================= */}
      {showNewCallModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-[#0B1B3D] border border-[#D4AF37]/40 rounded-3xl max-w-xl w-full p-6 space-y-5 shadow-2xl relative my-8 text-white">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
                  <Megaphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-lg text-white">Issue New Casting Call</h3>
                  <p className="text-xs text-slate-400">Broadcast open sponsorship brief to agency talent roster</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowNewCallModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {callIssuedSuccess ? (
              <div className="bg-emerald-950/80 border border-emerald-500/40 rounded-2xl p-6 text-center space-y-2 animate-fade-in">
                <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="font-serif font-bold text-lg text-white">Casting Call Broadcasted!</h4>
                <p className="text-xs text-emerald-200">
                  Brief issued for <strong>{newCallBrand}</strong> in <strong>{newCallNiche}</strong>. Talent alerts dispatched.
                </p>
              </div>
            ) : (
              <form onSubmit={handleCreateCastingCall} className="space-y-4 text-xs">
                {/* Campaign Title & Sponsoring Brand */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Campaign Title *</label>
                    <input
                      type="text"
                      required
                      value={newCallTitle}
                      onChange={(e) => setNewCallTitle(e.target.value)}
                      placeholder="e.g. Summer Glow Reel Campaign"
                      className="w-full bg-[#112240] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Sponsoring Brand *</label>
                    <input
                      type="text"
                      required
                      value={newCallBrand}
                      onChange={(e) => setNewCallBrand(e.target.value)}
                      placeholder="e.g. GlowLab Beauty"
                      className="w-full bg-[#112240] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>

                {/* Target Niche Category & Budget */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Target Niche *</label>
                    <select
                      value={newCallNiche}
                      onChange={(e) => setNewCallNiche(e.target.value as NicheCategory)}
                      className="w-full bg-[#112240] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#D4AF37]"
                    >
                      <option value="Pets">🐾 Pets</option>
                      <option value="Beauty">✨ Beauty</option>
                      <option value="Lifestyle">🌿 Lifestyle</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Budget / Comp *</label>
                    <input
                      type="text"
                      required
                      value={newCallBudget}
                      onChange={(e) => setNewCallBudget(e.target.value)}
                      placeholder="$5,000"
                      className="w-full bg-[#112240] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-300">Creator Slots *</label>
                    <input
                      type="number"
                      min={1}
                      max={20}
                      value={newCallRoles}
                      onChange={(e) => setNewCallRoles(parseInt(e.target.value) || 1)}
                      className="w-full bg-[#112240] border border-white/10 rounded-xl px-3.5 py-2.5 text-white font-mono outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>

                {/* Requirements & Deadline */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-300">Audition Requirements &amp; Deliverables *</label>
                  <textarea
                    rows={3}
                    required
                    value={newCallRequirements}
                    onChange={(e) => setNewCallRequirements(e.target.value)}
                    placeholder="Outline script guidelines, format requirements, and product shipping terms..."
                    className="w-full bg-[#112240] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-[#D4AF37]"
                  />
                </div>

                {/* Deadline */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-300">Audition Deadline *</label>
                  <input
                    type="date"
                    required
                    value={newCallDeadline}
                    onChange={(e) => setNewCallDeadline(e.target.value)}
                    className="w-full bg-[#112240] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-[#D4AF37]"
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setShowNewCallModal(false)}
                    className="bg-white/5 hover:bg-white/10 text-slate-300 px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="bg-[#D4AF37] hover:bg-[#b89359] text-[#0B1B3D] font-bold px-6 py-2.5 rounded-xl flex items-center gap-2 shadow-lg transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Publish Casting Call</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: AUDITION REVIEW & PITCH PREVIEW
         ========================================================================= */}
      {selectedAudition && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-[#0B1B3D] border border-[#D4AF37]/40 rounded-3xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative my-8 text-white">
            
            {/* Header */}
            <div className="flex items-start justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3.5">
                <img
                  src={selectedAudition.avatarUrl}
                  alt={selectedAudition.creatorName}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-[#D4AF37]"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif font-bold text-xl text-white">{selectedAudition.handle}</h3>
                    <span className="text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                      {selectedAudition.matchScore}% MATCH
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {selectedAudition.creatorName} &bull; {selectedAudition.followersCount} Followers &bull; {selectedAudition.engagementRate} Engagement
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedAudition(null)}
                className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Campaign Target Brief Info */}
            <div className="bg-[#112240] border border-white/10 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono uppercase text-[10px]">Auditioning For Brief</span>
                <span className="text-emerald-400 font-mono font-bold">{selectedAudition.compensation}</span>
              </div>
              <div className="font-semibold text-white text-sm">{selectedAudition.campaignTitle}</div>
              <div className="text-xs text-slate-300 flex items-center gap-2">
                <span>Brand: <strong className="text-white">{selectedAudition.brand}</strong></span>
                <span>&bull;</span>
                <span>Niche: <strong className="text-[#D4AF37]">{selectedAudition.niche}</strong></span>
                <span>&bull;</span>
                <span>Submitted: <strong className="text-slate-400">{selectedAudition.submittedAt}</strong></span>
              </div>
            </div>

            {/* Pitch & Audition Reel Simulation */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-1.5">
                <Film className="w-4 h-4" /> Creator Pitch &amp; Audition Concept
              </h4>
              <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-4 text-xs text-slate-200 leading-relaxed italic">
                "{selectedAudition.pitchSnippet}"
              </div>

              {/* Highlights Chips */}
              <div className="flex flex-wrap gap-2 pt-1">
                {selectedAudition.keyHighlights.map((h, i) => (
                  <span
                    key={`${selectedAudition.id}-highlight-${i}`}
                    className="bg-[#112240] border border-white/10 text-slate-300 text-[11px] px-3 py-1 rounded-full flex items-center gap-1.5"
                  >
                    <CheckCircle className="w-3 h-3 text-[#D4AF37]" /> {h}
                  </span>
                ))}
              </div>
            </div>

            {/* Status Control Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/10">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Current Status:</span>
                <span className="font-mono text-xs font-bold text-white bg-white/5 border border-white/10 px-2.5 py-1 rounded-lg">
                  {selectedAudition.status}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const aud = selectedAudition;
                    setSelectedAudition(null);
                    setReferModalAudition(aud);
                    setSelectedReferHandle(selectableCreators[0]?.handle || '');
                  }}
                  className="bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-500/40 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Refer to Creator</span>
                </button>
                {!isAgent && (
                  <>
                    <button
                      type="button"
                      onClick={() => handleUpdateStatus(selectedAudition.id, 'Passed')}
                      className="bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-500/30 px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Pass
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUpdateStatus(selectedAudition.id, 'Shortlisted')}
                      className="bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#D4AF37] border border-[#D4AF37]/40 px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Shortlist
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUpdateStatus(selectedAudition.id, 'Audition Approved')}
                      className="bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      ✓ Approve Audition
                    </button>
                    <button
                      type="button"
                      onClick={() => handleUpdateStatus(selectedAudition.id, 'Offered')}
                      className="bg-[#D4AF37] hover:bg-[#b89359] text-[#0B1B3D] px-4 py-2 rounded-xl text-xs font-bold transition-colors shadow-md cursor-pointer"
                    >
                      Issue Brand Offer
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: REFER CASTING BRIEF TO CREATOR (AGENT / MANAGER)
         ========================================================================= */}
      {referModalAudition && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-[#0B1B3D] border border-purple-500/40 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative my-8 text-white">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-300">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-lg text-white">Refer Casting Call to Creator</h3>
                  <p className="text-xs text-slate-400">Dispatch casting brief directly to your assigned talent</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setReferModalAudition(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Campaign Snippet */}
            <div className="bg-[#112240] border border-white/10 rounded-2xl p-3.5 space-y-1 text-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-mono text-[10px] uppercase text-[#D4AF37]">{referModalAudition.brand}</span>
                <span className="text-emerald-400 font-mono font-bold">{referModalAudition.compensation}</span>
              </div>
              <div className="font-semibold text-white">{referModalAudition.campaignTitle}</div>
              <div className="text-[11px] text-slate-400">Niche: {referModalAudition.niche}</div>
            </div>

            {referSuccess ? (
              <div className="bg-emerald-950/80 border border-emerald-500/40 rounded-2xl p-6 text-center space-y-2 animate-fade-in">
                <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="font-serif font-bold text-lg text-white">Casting Brief Dispatched!</h4>
                <p className="text-xs text-emerald-200">
                  Sent to <strong>{selectedReferHandle}</strong> with your personalized referral note.
                </p>
              </div>
            ) : (
              <form onSubmit={handleReferToCreator} className="space-y-4 text-xs">
                {/* Select Creator from Roster */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-300 flex items-center justify-between">
                    <span>Select Creator on Your Roster *</span>
                    <span className="text-[10px] text-purple-300 font-mono">
                      {selectableCreators.length} Available
                    </span>
                  </label>
                  <select
                    value={selectedReferHandle}
                    onChange={(e) => setSelectedReferHandle(e.target.value)}
                    required
                    className="w-full bg-[#112240] border border-white/10 rounded-xl px-3.5 py-2.5 text-white outline-none focus:border-purple-400 font-mono text-xs cursor-pointer"
                  >
                    <option value="">-- Choose Creator --</option>
                    {selectableCreators.map((c: any) => (
                      <option key={c.id || c.handle} value={c.handle}>
                        {c.name} ({c.handle}) — {c.niche || 'Creator'}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Personalized Referral Note */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-300">Agent Recommendation / Directives</label>
                  <textarea
                    rows={3}
                    value={referNote}
                    onChange={(e) => setReferNote(e.target.value)}
                    placeholder="Provide advice on angling their pitch, key brand requirements, etc."
                    className="w-full bg-[#112240] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-400 resize-none text-xs"
                  />
                </div>

                {/* Submit Action */}
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setReferModalAudition(null)}
                    className="px-4 py-2.5 rounded-xl border border-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!selectedReferHandle}
                    className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Casting Brief to Creator</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
