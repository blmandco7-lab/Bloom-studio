/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, Maximize2, SkipForward, BookOpen, AlertCircle, Sparkles, Loader2, HelpCircle, Send, RotateCcw, Shield, ShieldCheck, Clock, Users, DollarSign, FileText, CheckCircle2, ChevronRight, Globe, ChevronDown } from 'lucide-react';
import { TrainingGuide, Role } from '../types';
import { DEFAULT_TRAINING_GUIDES } from '../data/kbData';
import { AGENT_MANAGER_PHASES, TrainingPhase } from '../data/agentManagerTraining';
import ReactMarkdown from 'react-markdown';
import { getAuthHeaders } from '../lib/firebase';
import { safeStorage } from '../utils/safeStorage';

interface TrainingHubProps {
  currentRole: Role;
  onAskKB: (question: string, targetId: string) => void;
  kbAnswer: string;
  isKBLoading: boolean;
}

export default function TrainingHub({ currentRole, onAskKB, kbAnswer, isKBLoading }: TrainingHubProps) {
  const [selectedRole, setSelectedRole] = useState<Role>(currentRole);
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(60); // Mock duration in seconds
  const [question, setQuestion] = useState('');
  const [lastQuestion, setLastQuestion] = useState('');
  const [aiGeneratorOutput, setAiGeneratorOutput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [customGuides, setCustomGuides] = useState<TrainingGuide[]>([]);

  // Director training video upload state
  const [uploadedVideos, setUploadedVideos] = useState<TrainingGuide[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_training_videos_list');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadDesc, setUploadDesc] = useState('');
    const [uploadUrl, setUploadUrl] = useState('');
  const [uploadRoles, setUploadRoles] = useState<string[]>(['creator']);
  const [uploadDestination, setUploadDestination] = useState('library');


  const [completedSteps, setCompletedSteps] = useState<Record<string, string[]>>(() => {
    try {
      return JSON.parse(safeStorage.getItem('wl_training_completed_by') || '{}');
    } catch {
      return {};
    }
  });

  // Agent Manager Specialized Training State
  const [activePhaseIndex, setActivePhaseIndex] = useState(0);
  const [viewMode, setViewMode] = useState<'video' | 'sheet'>('video');

  const activePhase = AGENT_MANAGER_PHASES[activePhaseIndex];

  // Icons mapping for phases
  const getPhaseIcon = (iconName: string) => {
    switch (iconName) {
      case 'Shield': return <Shield className="w-4 h-4" />;
      case 'ShieldCheck': return <ShieldCheck className="w-4 h-4" />;
      case 'Clock': return <Clock className="w-4 h-4" />;
      case 'Users': return <Users className="w-4 h-4" />;
      case 'DollarSign': return <DollarSign className="w-4 h-4" />;
      default: return <BookOpen className="w-4 h-4" />;
    }
  };

  // Navigation feature descriptions for each role to answer the user's specific request
  const navFeatures: Record<Role, { tab: string; desc: string }[]> = {
    creator: [
      { tab: 'Creator Portal', desc: 'Your centralized personal dashboard displaying profile metrics, active social stats, platform links, and campaign status.' },
      { tab: 'Daily Briefing', desc: 'Daily snapshot of your upcoming campaign deliverables, urgent tasks, and escrow milestone alerts.' },
      { tab: 'My Deals', desc: 'Review and manage your active brand sponsorships, deal stages, and deliverable deadlines.' },
      { tab: 'My Sponsorship Pipeline', desc: 'Track upcoming sponsored campaign leads, pitches under review, and contract negotiation stages.' },
      { tab: 'My Earnings', desc: 'Review your total campaign earnings, escrow release ledgers, and payout transaction history.' },
      { tab: 'Casting Calls', desc: 'Browse open brand sponsorship opportunities and apply for upcoming paid campaign roles.' },
      { tab: 'Missions', desc: 'Interactive campaign checklists to review brand briefs and mark deliverable milestones completed.' },
      { tab: 'My Content / Status', desc: 'Submit draft videos and captions for agency & brand review, and track content approval status.' },
      { tab: 'Content Review', desc: 'Inspect feedback and revision requests on your submitted deliverables.' },
      { tab: 'Talent Media Kits', desc: 'Your shareable, branded media kit showcasing audience demographics and sponsorship rate cards.' },
      { tab: 'Creator Announcements', desc: 'Official studio notices, FTC compliance updates, and agency broadcasts addressed to talent.' },
      { tab: 'FTC & Studio Guidelines', desc: 'Creator compliance guides for #ad disclosures, deliverable QA, and payout instructions.' },
      { tab: 'Knowledge Base', desc: 'Creator handbook and playbook covering how deals work, FTC rules, and deliverable expectations.' },
      { tab: 'Messaging', desc: 'Direct 1-on-1 messaging with your assigned agent and agency support team.' }
    ],
    agent: [
      { tab: 'Agent Dashboard', desc: 'A focused console displaying your assigned creators, active deals, personal tasks queue, and MTD commission earnings.' },
      { tab: 'My Roster', desc: 'Roster panel to view and manage your creators\' profiles, platform stats, payment preferences, and active contracts.' },
      { tab: 'Availability', desc: 'Calendar grid indicating when your creators are busy, on vacation, or available to take on brand campaigns.' },
      { tab: 'Missions', desc: 'Task manager to create detailed campaign checklists, set deliverables, and track creator progress.' },
      { tab: 'Brand Deals', desc: 'Pipeline board to pitched, negotiate, contract, and close sponsor deals, auto-generating invoices on completion.' },
      { tab: 'Content Review', desc: 'Approval studio where creators submit captions and media drafts. Includes automated FTC checking and moment-flagging.' },
      { tab: 'Messaging', desc: 'Chat feed restricted to conversing only with your assigned creators and brand contacts.' }
    ],
    agentmgr: [
      { tab: 'Agent Manager', desc: 'Overview of your agent team, collective roster count, pending tasks, and rolling team commission summaries.' },
      { tab: 'Agent Roster', desc: 'Roster allocation panel to add new agents, assign creator quotas, and track individual deal volumes.' },
      { tab: 'Agent Scoring', desc: 'Objective, data-driven rating system evaluating agent performance quarterly on deal close rates and FTC compliance.' },
      { tab: 'Commission structure', desc: 'Customization panel to override default commission parameters, reward top agents, and set probation rates.' },
      { tab: 'Team Announcements', desc: 'Broadcaster tool to post updates, targets, or policy reminders to your entire team of agents.' }
    ],
    brand: [
      { tab: 'Daily Briefing', desc: 'High-level snapshot of your running campaign, active deliverables, and invoice status.' },
      { tab: 'Brand Inquiries', desc: 'Submit new campaign briefs and deliverables requests directly to the Agency Director.' },
      { tab: 'Brand Feedback', desc: 'Rate agency collaboration and submit post-campaign feedback surveys.' },
      { tab: 'Pay Invoices', desc: 'View itemized invoices for your active campaigns and fulfill payments via secure credit card processing.' },
      { tab: 'Creator Match', desc: 'Explore curated roster creators matching your brand\'s target audience and niche.' },
      { tab: 'Content Review', desc: 'Review and leave timestamped feedback on agency-approved video and photo deliverables before publication.' },
      { tab: 'Contract Vault', desc: 'Access and inspect signed campaign contracts, usage licenses, and FTC compliance terms.' },
      { tab: 'Messages (Director)', desc: 'Direct 1-on-1 messaging channel with your assigned Agency Director.' }
    ],
    subagency: [
      { tab: 'Dashboard', desc: 'Main sub-agency overview showing total creators, active network deals, monthly revenue splits, and anti-poaching compliance.' },
      { tab: 'My Creators', desc: 'Independent roster tracker to add your own creators and sync them with the master network for automated matching.' },
      { tab: 'Deals & Network', desc: 'Collab board displaying available high-budget deals shared by Bloom & Co, with splitting parameters.' },
      { tab: 'Revenue', desc: 'Ledger detailing the 60/40 revenue split with the master agency and the automated payouts to your talent.' },
      { tab: 'My Team', desc: 'Personnel tracker to onboard sub-agents, assign creator portfolios, and log performance.' },
      { tab: 'Submit Content', desc: 'Form to submit your creators\' captions and draft assets to the master agency for final FTC and guideline approval.' }
    ],
    director: [
      { tab: 'Daily Briefing', desc: 'A command center grouping active system alerts, a pending action queue, real-time roster headcounts, and milestone alerts.' },
      { tab: 'Director Dashboard', desc: 'Universal console providing role access toggles, bot master switches, anti-poaching policies, and revenue split settings.' },
      { tab: 'Bot Hub', desc: 'Configuration dock for automated bots (FTC, Retention, Invoicing, Social Listening, etc.)' },
      { tab: 'White Label', desc: 'Whitelabel customization engine allowing you to brand the app, set colors/logos, and export independent client copies.' },
      { tab: 'Access Codes', desc: 'Security hub to generate and override secure credentials for team roles and individual members.' }
    ],
    agency: [
      { tab: 'Agency Dashboard', desc: 'Dashboard displaying open collab deals, active campaigns, and your certified agency status within the master network.' },
      { tab: 'Collab Deals', desc: 'A dedicated marketplace to browse open brand deals posted by Bloom & Co. Apply to match your creators and earn split revenue.' },
      { tab: 'My Profile', desc: 'Professional bio and platform focus visible to master coordinators for automated campaign eligibility matching.' }
    ],
    coordinator: [
      { tab: 'Daily Briefing', desc: 'Personalized briefing listing your assigned campaigns, pending execution checklist items, and campaign milestone alerts.' },
      { tab: 'Campaign Board', desc: 'Visual Kanban tracking your assigned campaigns from Brief → Report. Manage deliverables, verify FTC disclosures, and move stages.' },
      { tab: 'Messaging', desc: 'Secure direct messenger to contact assigned creators and brand managers to coordinate drafting and publishing.' },
      { tab: 'FTC Compliance Desk', desc: 'Audit tool to verify that deliverables satisfy official FTC endorsement guidelines, ensuring proper sponsorship disclosure.' },
      { tab: 'Knowledge base', desc: 'Access resources and guides on standard operating procedures for creative delivery and auditing.' },
      { tab: 'Training', desc: 'Interactive videos and text guides outlining the campaign coordinator workflow and compliance checklist.' }
    ],
    contractor: [
      { tab: 'Standby Bench & Single-Deal Portal', desc: 'Non-exclusive fast-track portal for single gig contracts, W-9 tax intake, sample logistics, and video deliverable staging.' },
      { tab: 'Daily Briefing', desc: 'Overview of gig milestones, deliverable deadlines, and payout processing status.' },
      { tab: 'Deliverable Staging', desc: 'Upload 9:16 vertical videos and draft captions for automated FTC compliance check and brand review.' },
      { tab: 'Tax & Compliance Vault', desc: 'IRS W-9 compliance and secure flat-fee escrow payment disbursement tracking.' }
    ],
    none: [
      { tab: 'Daily Briefing', desc: 'Account pending role assignment or activation by the Director.' }
    ]
  };

  const getGuideForRole = (): TrainingGuide | undefined => {
    const guides = [...DEFAULT_TRAINING_GUIDES, ...customGuides];
    return guides.find(g => g.role.toLowerCase() === selectedRole.toLowerCase());
  };

  const handlePlayVideo = (videoUrl: string) => {
    setPlayingVideo(videoUrl);
    setIsPlaying(true);
    setCurrentTime(0);
  };

  // Video player controls mockup
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && playingVideo) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= duration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playingVideo, duration]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentTime(Number(e.target.value));
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const toggleUploadRole = (roleId: string) => {
    setUploadRoles(prev =>
      prev.includes(roleId) ? prev.filter(r => r !== roleId) : [...prev, roleId]
    );
  };

  const [isCompilingWiki, setIsCompilingWiki] = useState(false);

  // AI Simulator State
  const [activeGeneratorTab, setActiveGeneratorTab] = useState<'sop' | 'simulator'>(currentRole === 'agentmgr' ? 'simulator' : 'sop');
  const [isSimulatorActive, setIsSimulatorActive] = useState(false);
  const [simulatorTopic, setSimulatorTopic] = useState("How to handle a client dispute");
  const [simMessages, setSimMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([]);
  const [simInput, setSimInput] = useState("");
  const [isSimLoading, setIsSimLoading] = useState(false);
  const [simGrade, setSimGrade] = useState<any>(null);

  // AI Voice Dubbing State
  const [selectedDubLanguages, setSelectedDubLanguages] = useState<string[]>([]);
  const [isDubbing, setIsDubbing] = useState(false);
  const [activeAudioLanguage, setActiveAudioLanguage] = useState<string>('english');

  const DUB_LANGUAGES = [
    { id: 'spanish', label: 'Spanish (Neural)' },
    { id: 'french', label: 'French (Neural)' },
    { id: 'german', label: 'German (Neural)' },
    { id: 'japanese', label: 'Japanese (Neural)' }
  ];

  const handleLaunchSimulator = async () => {
    setIsSimulatorActive(true);
    setSimMessages([]);
    setSimGrade(null);
    setIsSimLoading(true);

    try {
      const authHeaders = await getAuthHeaders();
      const res = await fetch('/api/training-simulator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ topic: simulatorTopic, messages: [] })
      });
      const data = await res.json();
      if (data.success && data.reply) {
        setSimMessages([{ role: 'assistant', content: data.reply }]);
      }
    } catch (err) {
      setSimMessages([{ role: 'assistant', content: "Listen, we're already late on the Q4 campaign. Why is the creator draft still in 'Pending' status? I need answers now." }]);
    } finally {
      setIsSimLoading(false);
    }
  };

  const handleSendSimMessage = async () => {
    if (!simInput.trim() || isSimLoading || simGrade) return;

    const userMsg = { role: 'user' as const, content: simInput.trim() };
    const updatedMessages = [...simMessages, userMsg];
    setSimMessages(updatedMessages);
    setSimInput("");
    setIsSimLoading(true);

    try {
      const authHeaders = await getAuthHeaders();
      const res = await fetch('/api/training-simulator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ topic: simulatorTopic, messages: updatedMessages })
      });
      const data = await res.json();
      if (data.success) {
        if (data.grading) {
          setSimGrade(data.grading);
          setSimMessages(prev => [...prev, { role: 'assistant', content: data.grading.finalReply || data.reply }]);
        } else {
          setSimMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
        }
      }
    } catch (err) {
      setSimMessages(prev => [...prev, { role: 'assistant', content: "I don't think you're taking this seriously. Either provide a solution or I'm calling your manager." }]);
    } finally {
      setIsSimLoading(false);
    }
  };

  const handleUploadVideo = async () => {
    if (!uploadUrl.trim()) {
      alert('Please provide a video URL or file');
      return;
    }

    if (uploadDestination !== 'library') {
      try {
        const existingStr = safeStorage.getItem('wl_training_videos');
        const existing = existingStr ? JSON.parse(existingStr) : {};
        existing[uploadDestination] = uploadUrl.trim();
        safeStorage.setItem('wl_training_videos', JSON.stringify(existing));
        alert('Successfully set tutorial video override for ' + uploadDestination);
      } catch (e) {
        console.error(e);
      }
    } else {
      if (!uploadTitle.trim()) {
        alert('Please enter a video title');
        return;
      }
      if (uploadRoles.length === 0) {
        alert('Please select at least one target role');
        return;
      }

      setIsCompilingWiki(true);
      let dubbedTracks = {};

      // Trigger AI Dubbing if languages are selected
      if (selectedDubLanguages.length > 0) {
        setIsDubbing(true);
        try {
          const authHeaders = await getAuthHeaders();
          const res = await fetch('/api/dub-video', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...authHeaders },
            body: JSON.stringify({ videoUrl: uploadUrl, targetLanguages: selectedDubLanguages })
          });
          const data = await res.json();
          if (data.success) {
            dubbedTracks = data.dubbedTracks;
          }
        } catch (err) {
          console.error("Dubbing failed:", err);
        } finally {
          setIsDubbing(false);
        }
      }

      let wikiData = {
        title: uploadTitle.trim(),
        overview: uploadDesc.trim() || 'AI Transcribed training module.',
        transcription: "1. 'Welcome team. Reviewing mandatory campaign brief and unboxing quality standards.'\n2. 'Ensure creators verify packing slips and tag #ad correctly.'",
        slideFrames: ["Slide 1: Campaign Brief & FTC Rules", "Slide 2: Sample Inspection & Escrow Milestones"],
        sops: [
          "1. Sample Audit: Verify package arrival within 24 hours.",
          "2. FTC Compliance: Position #ad tag in top 2 lines.",
          "3. Defect Protocol: Report broken pumps to Project Shield Crisis Log.",
          "4. Escrow: Milestone auto-released upon verified live post."
        ]
      };

      try {
        const authHeaders = await getAuthHeaders();
        const res = await fetch('/api/video-to-wiki-compile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeaders },
          body: JSON.stringify({
            videoTitle: uploadTitle.trim(),
            videoDescription: uploadDesc.trim(),
            videoUrl: uploadUrl.trim()
          })
        });
        const data = await res.json();
        if (data.success && data.wiki) {
          wikiData = data.wiki;
        }
      } catch (err) {
        console.error("Video-to-wiki compile error:", err);
      } finally {
        setIsCompilingWiki(false);
      }

      const formattedDescription = `**Executive Overview:** ${wikiData.overview}\n\n**Voice Transcription Breakdown:**\n${wikiData.transcription}\n\n**Extracted Slides / Frames:**\n• ${wikiData.slideFrames?.join('\n• ') || ''}\n\n**Standard Operating Procedures (SOPs):**\n• ${wikiData.sops?.join('\n• ') || ''}`;

      const newVideo: TrainingGuide & { assignedRoles?: string[] } = {
        id: 'custom_vid_' + Date.now(),
        title: uploadTitle.trim(),
        role: uploadRoles.map(r => r.charAt(0).toUpperCase() + r.slice(1)).join(', '),
        assignedRoles: uploadRoles,
        category: 'Video Tutorial & Auto-Wiki',
        type: 'Video',
        description: uploadDesc.trim() || 'Role-specific training video tutorial.',
        embedVideoUrl: uploadUrl.trim() || 'https://www.w3schools.com/html/mov_bbb.mp4',
        dubbedTracks
      };

      const newWikiArticle: TrainingGuide = {
        id: 'wiki_compiled_' + Date.now(),
        title: `[Wiki SOP] ${wikiData.title}`,
        role: uploadRoles.map(r => r.charAt(0).toUpperCase() + r.slice(1)).join(', '),
        category: 'Help Center Wiki SOP',
        type: 'Article',
        description: formattedDescription,
        embedVideoUrl: uploadUrl.trim()
      };

      const updatedVideos = [newVideo, ...uploadedVideos];
      const updatedGuides = [newWikiArticle, ...customGuides];
      setUploadedVideos(updatedVideos);
      setCustomGuides(updatedGuides);

      try {
        safeStorage.setItem('wl_training_videos_list', JSON.stringify(updatedVideos));
        safeStorage.setItem('wl_custom_training_guides', JSON.stringify(updatedGuides));
        alert('🎥✨ Gemini 1.5 Pro successfully watched video, transcribed voice, extracted slide frames, and auto-compiled SOP text into the Help Center Wiki!');
      } catch (e) {}
    }

    setUploadTitle('');
    setUploadDesc('');
    setUploadUrl('');
    setUploadRoles(['creator']);
  };
  const handleDeleteUploadedVideo = (id: string) => {
    const updated = uploadedVideos.filter(v => v.id !== id);
    setUploadedVideos(updated);
    try {
      safeStorage.setItem('wl_training_videos_list', JSON.stringify(updated));
    } catch (e) {}
  };

  const getVideosForRole = (role: Role): TrainingGuide[] => {
    const allGuides = [...DEFAULT_TRAINING_GUIDES, ...customGuides, ...uploadedVideos];
    return allGuides.filter(g => {
      const norm = role.toLowerCase();
      if ((g as any).assignedRoles && Array.isArray((g as any).assignedRoles)) {
        return (g as any).assignedRoles.includes(norm);
      }
      return g.role.toLowerCase() === norm || g.role.toLowerCase().includes(norm);
    });
  };

  // SOP training generator for real training modules
  const handleAIGenerator = async () => {
    const topic = (document.getElementById('ai-t-topic') as HTMLSelectElement)?.value || "How to pitch a brand deal";
    const aud = (document.getElementById('ai-t-audience') as HTMLSelectElement)?.value || "Agent";
    
    setIsGenerating(true);
    setAiGeneratorOutput("Writing detailed training module...");

    const prompt = `Write a comprehensive, professional training guide for a talent and influencer marketing agency.
Audience: ${aud}
Topic: ${topic}
Provide a short overview, 4 actionable standard operating procedures (SOPs), and a final professional tip.
Be specific and professional. Under 300 words.`;

    try {
      const authHeaders = await getAuthHeaders();
      const res = await fetch('/api/ask-kb', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ question: prompt, context: "Agency training assistant" })
      });
      const data = await res.json();
      const outputText = data?.answer || `**${topic} Standard Operating Procedure (SOP):**\n\n1. **Preparation:** Review client brief and confirm creator alignment.\n2. **Outreach & Pitching:** Send formal media kit deck with verified statistics.\n3. **Contracting & Escrow:** Ensure milestones are funded before production.\n4. **Review & Approval:** Audit drafts 48h prior to go-live for FTC compliance.`;
      
      setAiGeneratorOutput(outputText);
      
      // Save it to custom guides list so it appears instantly
      const newGuide: TrainingGuide = {
        id: 'custom_' + Date.now(),
        title: topic,
        role: aud,
        category: 'Studio SOP Module',
        type: 'Article',
        description: outputText,
        embedVideoUrl: 'https://www.w3schools.com/html/movie.mp4'
      };
      setCustomGuides(prev => [newGuide, ...prev]);
    } catch (err) {
      const outputText = `**${topic} Standard Operating Procedure (SOP):**\n\n1. **Preparation:** Review client brief and confirm creator alignment.\n2. **Outreach & Pitching:** Send formal media kit deck with verified statistics.\n3. **Contracting & Escrow:** Ensure milestones are funded before production.\n4. **Review & Approval:** Audit drafts 48h prior to go-live for FTC compliance.`;
      setAiGeneratorOutput(outputText);
    } finally {
      setIsGenerating(false);
    }
  };

  const currentGuide = getGuideForRole();
  const roleVideos = getVideosForRole(selectedRole);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-sans font-medium text-2xl tracking-tight text-white flex items-center gap-2">
            <BookOpen className="text-[#C9A46A] w-6 h-6" /> Training Hub
          </h1>
          <p className="text-xs text-[#7C8AA8] mt-1">
            Complete guide to navigation, features, and SOPs for all platform roles
          </p>
        </div>
        
        {currentRole === 'director' && (
          <div className="bg-[#0D1830] border border-amber-500/30 rounded-xl p-3 max-w-md flex items-start gap-2.5">
            <AlertCircle className="text-[#C9A46A] w-5 h-5 shrink-0 mt-0.5" />
            <div className="text-[11px] text-[#B8C0D4] leading-relaxed">
              <span className="font-semibold text-white">Director Privilege:</span> You can preview the exact training dashboard and video tutorial assigned to any role below.
            </div>
          </div>
        )}
      </div>

      {/* Role Selection Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1 bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-xl">
        {(['creator', 'agent', 'coordinator', 'agentmgr', 'brand', 'subagency', 'agency', 'director'] as Role[]).map(role => {
          const isAllowed = currentRole === 'director' || currentRole === role;
          if (!isAllowed) return null;
          return (
            <button
              key={role}
              onClick={() => {
                setSelectedRole(role);
                // Reset to first video when switching
                setPlayingVideo(null);
                setIsPlaying(false);
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                selectedRole === role
                  ? 'bg-[#C9A46A] text-[#0A1220] font-semibold'
                  : 'text-[#7C8AA8] hover:text-white hover:bg-[#16243F]'
              }`}
            >
              {role === 'agentmgr' ? 'Agent Manager' : role === 'subagency' ? 'Sub-Agency' : role === 'agency' ? 'Agency' : role}
            </button>
          );
        })}
      </div>

      {/* Specialized Agent Manager Checklist Layout */}
      {selectedRole === 'agentmgr' && (
        <div className="bg-[#0D1830] border border-[#C9A46A]/20 rounded-2xl overflow-hidden shadow-2xl">
          <div className="p-6 border-b border-white/5 bg-gradient-to-r from-[#111E33] to-[#0D1830] flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-serif font-bold text-white flex items-center gap-2">
                <ShieldCheck className="text-[#C9A46A] w-6 h-6" />
                Agent Manager Onboarding Checklist
              </h2>
              <p className="text-xs text-[#7C8AA8] mt-1">
                Complete the 5 specialized phases to unlock your management seat permissions.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-2 w-32 bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[#C9A46A] transition-all duration-500" 
                  style={{ width: `${(activePhaseIndex + 1) * 20}%` }}
                ></div>
              </div>
              <span className="text-[10px] font-mono text-[#C9A46A] font-bold">
                PHASE {activePhaseIndex + 1} / 5
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Sidebar: Phases list */}
            <div className="lg:col-span-4 border-r border-white/5 bg-[#0A1220]/50 p-4 space-y-3">
              {AGENT_MANAGER_PHASES.map((phase, idx) => (
                <button
                  key={phase.id}
                  onClick={() => setActivePhaseIndex(idx)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-start gap-3 group ${
                    activePhaseIndex === idx
                      ? 'bg-[#16243F] border-[#C9A46A]/40 shadow-lg'
                      : 'bg-transparent border-transparent hover:bg-white/5 text-[#7C8AA8]'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                    activePhaseIndex === idx ? 'bg-[#C9A46A] text-[#0A1220]' : 'bg-[#111E33] text-[#7C8AA8]'
                  }`}>
                    {getPhaseIcon(phase.icon)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono font-bold text-[#C9A46A]">PHASE {phase.number}</span>
                      {activePhaseIndex > idx && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                    </div>
                    <h4 className={`text-xs font-bold truncate ${activePhaseIndex === idx ? 'text-white' : 'group-hover:text-white'}`}>
                      {phase.title}
                    </h4>
                    <p className="text-[10px] text-[#5A6984] line-clamp-1 mt-0.5">{phase.desc}</p>
                  </div>
                </button>
              ))}

              <div className="pt-4 mt-4 border-t border-white/5">
                <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl space-y-2">
                  <h5 className="text-[10px] font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5" />
                    Director Audit Log
                  </h5>
                  <p className="text-[10px] text-[#7C8AA8] leading-relaxed italic">
                    All phase completions are logged with unique Firestore tokens [9hqWU2] and verified by the Director Watchdog Loop.
                  </p>
                </div>
              </div>
            </div>

            {/* Main Content Area: Video or Sheet */}
            <div className="lg:col-span-8 p-0 flex flex-col min-h-[500px]">
              {/* Header: Toggle Video/Sheet */}
              <div className="p-4 border-b border-white/5 flex items-center justify-between bg-black/20">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setViewMode('video')}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      viewMode === 'video' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'
                    }`}
                  >
                    <Play className="w-3.5 h-3.5" />
                    Video Tutorial
                  </button>
                  <button
                    onClick={() => setViewMode('sheet')}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      viewMode === 'sheet' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    Procedure Sheet
                  </button>
                </div>
                
                <div className="flex items-center gap-2">
                  {activePhaseIndex > 0 && (
                    <button 
                      onClick={() => setActivePhaseIndex(prev => prev - 1)}
                      className="p-1.5 rounded-lg bg-white/5 text-[#7C8AA8] hover:text-white transition-colors"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  )}
                  {activePhaseIndex < AGENT_MANAGER_PHASES.length - 1 && (
                    <button 
                      onClick={() => setActivePhaseIndex(prev => prev + 1)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 text-[#C9A46A] hover:bg-[#C9A46A] hover:text-[#0A1220] text-xs font-bold transition-all"
                    >
                      Next Phase
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Body */}
              <div className="flex-1 overflow-y-auto max-h-[600px] p-6 bg-[#0A1220]/30">
                {viewMode === 'video' ? (
                  <div className="space-y-6">
                    <div className="aspect-video bg-black rounded-2xl border border-white/5 overflow-hidden relative group">
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-t from-black/80 via-transparent to-black/40">
                        {isPlaying && playingVideo === activePhase.videoUrl ? (
                          <div className="space-y-4 text-center p-8 bg-black/60 backdrop-blur-sm rounded-2xl border border-white/10">
                            <Loader2 className="w-12 h-12 text-[#C9A46A] animate-spin mx-auto" />
                            <div>
                              <p className="text-sm font-bold text-white">Streaming Training Module...</p>
                              <p className="text-[11px] text-[#7C8AA8] mt-1 font-mono uppercase tracking-widest">
                                Phase {activePhase.number}: {activePhase.id.toUpperCase()}
                              </p>
                            </div>
                            <button 
                              onClick={() => setIsPlaying(false)}
                              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl transition-colors"
                            >
                              Pause Tutorial
                            </button>
                          </div>
                        ) : (
                          <div className="text-center p-8">
                            <button 
                              onClick={() => {
                                setPlayingVideo(activePhase.videoUrl);
                                setIsPlaying(true);
                              }}
                              className="w-20 h-20 rounded-full bg-[#C9A46A] text-[#0A1220] flex items-center justify-center shadow-2xl shadow-amber-500/30 hover:scale-110 transition-transform mb-6 mx-auto"
                            >
                              <Play fill="#0A1220" className="w-10 h-10 ml-1.5" />
                            </button>
                            <h3 className="text-lg font-serif font-bold text-white">{activePhase.title}</h3>
                            <p className="text-xs text-[#7C8AA8] mt-2 max-w-sm mx-auto">
                              Watch the interactive video guide for this management phase before proceeding to the procedure sheet.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {activePhase.steps.map(step => {
                        const stepId = `${activePhase.id}-${step.id}`;
                        const isDone = completedSteps[currentRole]?.includes(stepId) || false;
                        
                        return (
                        <div key={step.id} className="p-4 bg-[#111E33] border border-white/5 rounded-2xl space-y-2">
                          <div className="flex items-start justify-between">
                            <h5 className="text-[11px] font-bold text-white uppercase leading-tight">{step.title}</h5>
                            {step.refCode && <span className="text-[8px] font-mono bg-[#C9A46A]/20 text-[#C9A46A] px-1 rounded">{step.refCode}</span>}
                          </div>
                          <p className="text-[10px] text-[#7C8AA8] leading-relaxed">{step.desc}</p>
                          <div className="pt-2">
                            <button 
                              onClick={() => {
                                setCompletedSteps(prev => {
                                  const roleCompleted = prev[currentRole] || [];
                                  const newCompleted = isDone 
                                    ? roleCompleted.filter(id => id !== stepId)
                                    : [...roleCompleted, stepId];
                                  const updated = { ...prev, [currentRole]: newCompleted };
                                  try {
                                    safeStorage.setItem('wl_training_completed_by', JSON.stringify(updated));
                                  } catch (e) {}
                                  return updated;
                                });
                              }}
                              className={`text-[10px] font-bold flex items-center gap-1 hover:underline transition-colors ${
                                isDone ? 'text-emerald-400' : 'text-[#C9A46A]'
                              }`}
                            >
                              {isDone ? '✓ Completed' : 'Mark Complete'} <ChevronRight className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      )})}
                    </div>
                  </div>
                ) : (
                  <div className="prose prose-invert prose-sm max-w-none prose-headings:font-serif prose-headings:text-[#C9A46A] prose-strong:text-white prose-p:text-[#B8C0D4] prose-li:text-[#B8C0D4]">
                    <div className="bg-[#111E33] border border-white/5 p-8 rounded-3xl shadow-inner">
                      <ReactMarkdown>{activePhase.sheetContent}</ReactMarkdown>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Video Player and Feature Navigation Walkthrough */}
        <div className="lg:col-span-8 space-y-6">
          {/* Interactive Tutorial Video Player */}
          <div className="bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 border-b border-[#rgba(201,164,106,0.14)] flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[#C9A46A]">
                  Interactive Navigation Tutorial
                </h3>
                <h4 className="text-sm font-medium text-white mt-0.5 capitalize">
                  Walkthrough Video — {selectedRole === 'agentmgr' ? 'Agent Manager' : selectedRole === 'subagency' ? 'Sub-Agency' : selectedRole === 'agency' ? 'Agency' : selectedRole} Dashboard
                </h4>
              </div>
              <span className="text-[10px] bg-emerald-950/50 border border-emerald-500/30 text-emerald-400 font-semibold px-2 py-0.5 rounded-full">
                Video Active
              </span>
            </div>

            {/* Video Canvas Mockup */}
            <div className="relative aspect-video bg-black flex flex-col items-center justify-center">
              {playingVideo ? (
                <div className="absolute inset-0 flex flex-col justify-between p-4 bg-gradient-to-t from-black/80 via-black/20 to-black/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs bg-black/60 border border-[#C9A46A]/20 px-2 py-1 rounded text-[#C9A46A] font-mono">
                      Tutorial Playing: {selectedRole.toUpperCase()}
                    </span>
                    <button 
                      onClick={() => setPlayingVideo(null)} 
                      className="text-xs bg-black/60 hover:bg-black/90 px-2.5 py-1 rounded text-white"
                    >
                      Reset Player
                    </button>
                  </div>

                  {/* Animated Video Simulation */}
                  <div className="flex flex-col items-center justify-center flex-1">
                    {isPlaying ? (
                      <div className="space-y-4 text-center">
                        <div className="w-16 h-16 rounded-full border-4 border-t-amber-500 border-r-transparent border-[#C9A46A] animate-spin mx-auto"></div>
                        <p className="text-xs text-[#C9A46A] font-medium tracking-wide animate-pulse">
                          Simulating Role Dashboard Walkthrough Screen Recording...
                        </p>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setIsPlaying(true)}
                        className="w-16 h-16 rounded-full bg-[#C9A46A] text-[#0A1220] flex items-center justify-center shadow-lg shadow-amber-500/20 hover:scale-105 transition-transform"
                      >
                        <Play fill="#0A1220" className="w-7 h-7 ml-1" />
                      </button>
                    )}
                  </div>

                  {/* Simulated Custom Video Controls bar */}
                  <div className="bg-black/80 border border-white/10 rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between gap-3">
                      <button 
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="text-white hover:text-[#C9A46A] transition-colors"
                      >
                        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </button>
                      
                      <span className="text-[10px] text-[#7C8AA8] font-mono">
                        {formatTime(currentTime)}
                      </span>

                      <input 
                        type="range"
                        min="0"
                        max={duration}
                        value={currentTime}
                        onChange={handleSeek}
                        className="flex-1 accent-[#C9A46A] h-1 rounded-full cursor-pointer bg-gray-800"
                      />

                      <span className="text-[10px] text-[#7C8AA8] font-mono">
                        {formatTime(duration)}
                      </span>

                      <Volume2 className="w-4 h-4 text-[#7C8AA8]" />
                      
                      <div className="relative group">
                        <button className="flex items-center gap-1 text-[10px] bg-white/5 hover:bg-white/10 px-2 py-1 rounded border border-white/10 text-white transition-colors">
                          <Globe className="w-3 h-3 text-indigo-400" />
                          <span className="uppercase">{activeAudioLanguage === 'english' ? 'English' : activeAudioLanguage}</span>
                          <ChevronDown className="w-3 h-3 opacity-50" />
                        </button>
                        <div className="absolute bottom-full right-0 mb-2 w-32 bg-[#0D1830] border border-white/10 rounded-lg shadow-2xl overflow-hidden hidden group-hover:block z-50">
                          <div className="p-1.5 space-y-0.5">
                            <p className="text-[8px] text-[#7C8AA8] uppercase font-bold px-2 py-1">Audio Track</p>
                            <button 
                              onClick={() => setActiveAudioLanguage('english')}
                              className={`w-full text-left px-2 py-1.5 rounded text-[10px] transition-colors ${activeAudioLanguage === 'english' ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-white hover:bg-white/5'}`}
                            >
                              English (Original)
                            </button>
                            {(() => {
                              const activeGuide = uploadedVideos.find(v => v.embedVideoUrl === playingVideo || v.url === playingVideo);
                              return activeGuide?.dubbedTracks ? Object.keys(activeGuide.dubbedTracks).map(lang => (
                                <button 
                                  key={lang}
                                  onClick={() => setActiveAudioLanguage(lang)}
                                  className={`w-full text-left px-2 py-1.5 rounded text-[10px] transition-colors ${activeAudioLanguage === lang ? 'bg-indigo-500 text-white font-bold' : 'text-white hover:bg-white/5'}`}
                                >
                                  {lang.charAt(0).toUpperCase() + lang.slice(1)} (AI Dubbed)
                                </button>
                              )) : null;
                            })()}
                          </div>
                        </div>
                      </div>

                      <Maximize2 className="w-4 h-4 text-[#7C8AA8] cursor-pointer hover:text-white" />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-6 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#16243F] border border-[#C9A46A]/30 flex items-center justify-center mx-auto">
                    <Play className="text-[#C9A46A] w-6 h-6 ml-0.5" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-white">Interactive video tutorial ready</p>
                    <p className="text-xs text-[#7C8AA8] max-w-md mx-auto">
                      Click below to load the step-by-step navigation video explaining where to find features on the {selectedRole} portal.
                    </p>
                  </div>
                  <button
                    onClick={() => handlePlayVideo(currentGuide?.embedVideoUrl || 'https://www.w3schools.com/html/movie.mp4')}
                    className="bg-[#C9A46A] text-[#0A1220] hover:bg-[#E3C48F] px-4 py-2 rounded-xl text-xs font-semibold transition-colors"
                  >
                    Play Tutorial Video
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Role Video Tutorials List */}
          <div className="bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <div className="flex items-center gap-2">
                <Play className="text-[#C9A46A] w-4 h-4" />
                <h3 className="text-sm font-semibold text-white">
                  Video Tutorials Assigned to {selectedRole.toUpperCase()} ({roleVideos.length})
                </h3>
              </div>
              <span className="text-[10px] bg-[#111E33] text-[#C9A46A] font-mono px-2 py-0.5 rounded border border-white/10">
                ROLE SCOPED
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {roleVideos.map(video => (
                <div key={video.id} className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl space-y-2 flex flex-col justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] uppercase font-mono font-bold text-[#C9A46A]">{video.category || 'Video'}</span>
                      {currentRole === 'director' && String(video.id).startsWith('custom_') && (
                        <button
                          onClick={() => handleDeleteUploadedVideo(video.id)}
                          className="text-[10px] text-red-400 hover:text-red-300 font-semibold"
                        >
                          Delete
                        </button>
                      )}
                    </div>
                    <h4 className="text-xs font-semibold text-white">{video.title}</h4>
                    <p className="text-[11px] text-[#7C8AA8] line-clamp-2 leading-relaxed">{video.description}</p>
                  </div>
                  <button
                    onClick={() => handlePlayVideo(video.embedVideoUrl || 'https://www.w3schools.com/html/movie.mp4')}
                    className="w-full bg-[#16243F] hover:bg-[#C9A46A] text-[#C9A46A] hover:text-[#0A1220] py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 mt-2"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Watch Video Tutorial
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Guide breakdown */}
          <div className="bg-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-5 space-y-4">
            <h3 className="font-sans font-medium text-lg text-white border-b border-[#rgba(201,164,106,0.14)] pb-3">
              Navigation &amp; Feature Map
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(navFeatures[selectedRole] || []).map((feature, i) => (
                <div key={i} className="p-3 bg-[#111E33] border border-white/5 rounded-xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">{feature.tab}</span>
                    <span className="text-[9px] text-[#C9A46A] font-mono font-semibold">Active</span>
                  </div>
                  <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
                    {feature.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Ask Bloom & SOP Generator Box */}
        <div className="lg:col-span-4 space-y-6">
          {/* Ask Bloom Box */}
          <div className="bg-[#0D1830] border border-[#C9A46A]/20 rounded-2xl p-5 space-y-4 shadow-lg shadow-black/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="text-[#C9A46A] w-5 h-5 animate-pulse" />
                <h3 className="text-sm font-semibold text-[#C9A46A] uppercase tracking-wider">
                  Ask Bloom Assistant
                </h3>
              </div>
              <span className="text-[9px] bg-[#C9A46A]/10 text-[#C9A46A] border border-[#C9A46A]/30 px-2 py-0.5 rounded font-mono font-medium">
                AI &amp; KB STUDIO
              </span>
            </div>
            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Ask any question regarding agency policies, role scopes, contract rules, FTC disclosures, or navigation procedures.
            </p>

            {/* Quick Suggestion Chips */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-mono text-[#7C8AA8] uppercase tracking-wider block">
                Quick Prompts:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  "How does creator commission work?",
                  "What does directs agent deal allocations mean?",
                  "What are the FTC disclosure rules?",
                  "When and how do creators get paid?",
                  "Exclusive vs Non-Exclusive contracts",
                  "What is a media kit?"
                ].map((promptText, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setQuestion(promptText);
                      setLastQuestion(promptText);
                      onAskKB(promptText, 'training-assistant-out');
                    }}
                    disabled={isKBLoading}
                    className="text-[10px] bg-[#111E33] hover:bg-[#1E2E4A] text-[#93A1C0] hover:text-[#C9A46A] border border-white/5 hover:border-[#C9A46A]/40 px-2.5 py-1 rounded-lg transition-all text-left flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <HelpCircle className="w-2.5 h-2.5 text-[#C9A46A]/70" />
                    <span>{promptText}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-1">
              <div className="relative">
                <input
                  type="text"
                  value={question}
                  onChange={e => setQuestion(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && question.trim() && !isKBLoading) {
                      setLastQuestion(question);
                      onAskKB(question, 'training-assistant-out');
                    }
                  }}
                  disabled={isKBLoading}
                  placeholder="Ask any question e.g. How do payments work?"
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl pl-3 pr-10 py-2.5 text-xs text-white focus:border-[#C9A46A] outline-none transition-colors disabled:opacity-60"
                />
                {question.trim() && !isKBLoading && (
                  <button
                    type="button"
                    onClick={() => setQuestion('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => {
                  if (question.trim() && !isKBLoading) {
                    setLastQuestion(question);
                    onAskKB(question, 'training-assistant-out');
                  }
                }}
                disabled={!question.trim() || isKBLoading}
                className="w-full bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-2.5 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 shadow-md shadow-[#C9A46A]/10 disabled:opacity-50 cursor-pointer"
              >
                {isKBLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-[#0A1220]" />
                    <span>Consulting Knowledge Base...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Ask Bloom</span>
                  </>
                )}
              </button>
            </div>

            {/* Answer Display Card */}
            {isKBLoading && !kbAnswer && (
              <div className="bg-[#111E33] border border-[#C9A46A]/20 p-4 rounded-xl space-y-2 animate-pulse">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 text-[#C9A46A] animate-spin" />
                  <span className="text-[11px] font-mono text-[#C9A46A]">Bloom AI is searching knowledge base...</span>
                </div>
                <div className="h-2 bg-white/10 rounded w-3/4"></div>
                <div className="h-2 bg-white/10 rounded w-5/6"></div>
              </div>
            )}

            {kbAnswer && (
              <div className="bg-[#111E33] border-l-2 border-[#C9A46A] p-4 rounded-r-xl space-y-2 transition-all">
                <div className="flex items-center justify-between border-b border-white/5 pb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-[#C9A46A]" />
                    <span className="text-[10px] font-semibold text-[#C9A46A] tracking-wider uppercase">
                      ANSWER FOR: "{lastQuestion || 'Inquiry'}"
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setQuestion('');
                      setLastQuestion('');
                    }}
                    title="Ask another question"
                    className="text-[10px] text-[#7C8AA8] hover:text-[#C9A46A] flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <RotateCcw className="w-2.5 h-2.5" />
                    <span>Clear</span>
                  </button>
                </div>
                <div className="text-xs text-[#B8C0D4] leading-relaxed whitespace-pre-wrap font-sans">
                  {kbAnswer}
                </div>
              </div>
            )}
          </div>

          {/* Director Only: Video Upload Panel */}
          {currentRole === 'director' && (
            <div className="bg-[#0D1830] border border-amber-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <div className="flex items-center gap-2">
                  <Play className="text-amber-400 w-5 h-5" />
                  <h3 className="text-sm font-semibold text-white">Upload Training Video</h3>
                </div>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 font-mono px-2 py-0.5 rounded border border-amber-500/30">
                  DIRECTOR ONLY
                </span>
              </div>
              <p className="text-xs text-[#7C8AA8]">
                Upload a training video with a title and description, and assign which roles can view it.
              </p>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Upload Destination</label>
                  <select
                    value={uploadDestination}
                    onChange={e => setUploadDestination(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:border-[#C9A46A] outline-none"
                  >
                    <option value="library">Training Video (Role Library)</option>
                    <option value="interactive_nav">Video Tutorial (Interactive Navigation)</option>
                    <option value="phase_1">Video Tutorial (Phase 1: Brand Pitching)</option>
                    <option value="phase_2">Video Tutorial (Phase 2: Roster Mgmt)</option>
                    <option value="phase_3">Video Tutorial (Phase 3: Deal Flow)</option>
                    <option value="phase_4">Video Tutorial (Phase 4: Contract)</option>
                    <option value="phase_5">Video Tutorial (Phase 5: Payments)</option>
                  </select>
                </div>

                {uploadDestination === 'library' && (
                  <>
                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase">Video Title</label>
                      <input
                        type="text"
                        value={uploadTitle}
                        onChange={e => setUploadTitle(e.target.value)}
                        placeholder="e.g. Q4 Brand Deal & FTC Guidelines"
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:border-[#C9A46A] outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-[#7C8AA8] uppercase">Description</label>
                      <textarea
                        value={uploadDesc}
                        onChange={e => setUploadDesc(e.target.value)}
                        rows={2}
                        placeholder="Brief description of what this video tutorial covers..."
                        className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:border-[#C9A46A] outline-none resize-none"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-1">
                  <label className="text-[10px] text-[#7C8AA8] uppercase">Video URL or File</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={uploadUrl}
                      onChange={e => setUploadUrl(e.target.value)}
                      placeholder="https://...mp4 or select file ->"
                      className="flex-1 bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:border-[#C9A46A] outline-none"
                    />
                    <label className="bg-[#16243F] hover:bg-white/10 border border-white/10 text-white text-xs px-3 py-2 rounded-xl cursor-pointer shrink-0">
                      File
                      <input
                        type="file"
                        accept="video/*"
                        className="hidden"
                        onChange={e => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const objUrl = URL.createObjectURL(file);
                            setUploadUrl(objUrl);
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>

                <div className="space-y-2 p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Globe className="w-3.5 h-3.5 text-indigo-400" />
                      <label className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Multi-Lingual AI Dubbing</label>
                    </div>
                    <span className="text-[8px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded font-mono">Neural Voice Cloning</span>
                  </div>
                  <p className="text-[10px] text-[#7C8AA8]">Automatically clone your voice and translate audio tracks for international creators.</p>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {DUB_LANGUAGES.map(lang => (
                      <button
                        key={lang.id}
                        type="button"
                        onClick={() => {
                          setSelectedDubLanguages(prev => 
                            prev.includes(lang.id) ? prev.filter(l => l !== lang.id) : [...prev, lang.id]
                          );
                        }}
                        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-[10px] transition-all ${
                          selectedDubLanguages.includes(lang.id)
                            ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-300 shadow-sm'
                            : 'bg-[#111E33] border-white/5 text-[#7C8AA8] hover:border-white/10'
                        }`}
                      >
                        <div className={`w-1.5 h-1.5 rounded-full ${selectedDubLanguages.includes(lang.id) ? 'bg-indigo-400 shadow-[0_0_8px_rgba(129,140,248,0.5)]' : 'bg-white/10'}`} />
                        {lang.label}
                      </button>
                    ))}
                  </div>
                </div>

                {uploadDestination === 'library' && (
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-[#7C8AA8] uppercase">Assign to Roles</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: 'creator', label: 'Creator' },
                        { id: 'agent', label: 'Agent' },
                        { id: 'coordinator', label: 'Coordinator' },
                        { id: 'agentmgr', label: 'Agent Manager' }
                      ].map(role => (
                        <label
                          key={role.id}
                          className={`flex items-center gap-2 p-2 rounded-xl border text-xs cursor-pointer select-none transition-colors ${
                            uploadRoles.includes(role.id)
                              ? 'bg-amber-500/20 border-amber-500/40 text-amber-200'
                              : 'bg-[#111E33] border-white/10 text-[#7C8AA8] hover:border-white/20'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={uploadRoles.includes(role.id)}
                            onChange={() => toggleUploadRole(role.id)}
                            className="rounded accent-[#C9A46A]"
                          />
                          <span>{role.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                
                <button
                  onClick={handleUploadVideo}
                  disabled={isCompilingWiki || isDubbing || (uploadDestination === 'library' && !uploadTitle.trim()) || !uploadUrl.trim()}
                  className="w-full py-3 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {(isCompilingWiki || isDubbing) && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  {isDubbing 
                    ? `AI Dubbing Neural Network: ${selectedDubLanguages.length} Tracks...` 
                    : isCompilingWiki 
                      ? 'AI Processing & Wiki Compilation...' 
                      : (uploadDestination === 'library' ? 'Upload Video & Auto-Compile to Wiki' : 'Set as Agent Manager Tutorial Video')}
                </button>

              </div>
            </div>
          )}

          {/* SOP Module Generator & Simulator */}
          {(currentRole === 'director' || currentRole === 'agentmgr') && (
            <div className="bg-gradient-to-b from-[#111E33] to-[#0D1830] border border-[#C9A46A]/30 rounded-2xl overflow-hidden shadow-xl">
              <div className="flex border-b border-white/5">
                <button 
                  onClick={() => setActiveGeneratorTab('sop')}
                  className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${activeGeneratorTab === 'sop' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'}`}
                >
                  SOP Module Generator
                </button>
                <button 
                  onClick={() => setActiveGeneratorTab('simulator')}
                  className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${activeGeneratorTab === 'simulator' ? 'bg-[#C9A46A] text-[#0A1220]' : 'text-[#7C8AA8] hover:text-white'}`}
                >
                  [ Launch Training Simulator ]
                </button>
              </div>

              <div className="p-5 space-y-4">
                {activeGeneratorTab === 'sop' ? (
                  <>
                    <div className="flex items-center gap-2">
                      <Sparkles className="text-[#C9A46A] w-5 h-5" />
                      <h3 className="text-sm font-semibold text-white">SOP Module Generator</h3>
                    </div>
                    <p className="text-xs text-[#7C8AA8]">
                      Generate standard operating procedures (SOPs) or training articles instantly and save them directly into the Knowledge Base.
                    </p>

                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[10px] text-[#7C8AA8] uppercase">Module Topic</label>
                        <select id="ai-t-topic" className="w-full bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-2 text-xs text-white outline-none">
                          <option value="How to pitch a brand deal">How to pitch a brand deal</option>
                          <option value="FTC disclosure compliance guide">FTC disclosure compliance</option>
                          <option value="Negotiating creator contracts">Negotiating creator contracts</option>
                          <option value="Onboarding a new creator step-by-step">Onboarding a new creator</option>
                          <option value="Running a quarterly agent review">Running a quarterly agent review</option>
                          <option value="Handling a brand safety crisis">Handling a brand safety crisis</option>
                          <option value="Building a media kit that converts">Building a media kit that converts</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] text-[#7C8AA8] uppercase">Target Audience</label>
                        <select id="ai-t-audience" className="w-full bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-2 text-xs text-white outline-none">
                          <option value="Agent">Agents</option>
                          <option value="Agent Manager">Agent Managers</option>
                          <option value="Sub-Agency">Sub-Agencies</option>
                          <option value="Agency">Agencies</option>
                          <option value="Creator">Creators</option>
                          <option value="Brand">Brands</option>
                        </select>
                      </div>

                      <button
                        onClick={handleAIGenerator}
                        disabled={isGenerating}
                        className="w-full bg-gradient-to-r from-amber-500 to-[#C9A46A] hover:brightness-110 text-[#0A1220] py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                      >
                        <Sparkles className="w-4 h-4" />
                        {isGenerating ? 'Generating Guide...' : 'Generate and Save SOP Module'}
                      </button>
                    </div>

                    {aiGeneratorOutput && (
                      <div className="bg-[#0A1220]/75 border border-white/5 p-3 rounded-xl max-h-48 overflow-y-auto">
                        <p className="text-[11px] text-[#B8C0D4] leading-relaxed whitespace-pre-wrap">
                          {aiGeneratorOutput}
                        </p>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="space-y-4">
                    {!isSimulatorActive ? (
                      <>
                        <div className="flex items-center gap-2">
                          <RotateCcw className="text-[#C9A46A] w-5 h-5" />
                          <h3 className="text-sm font-semibold text-white">AI Training Simulator</h3>
                        </div>
                        <p className="text-xs text-[#7C8AA8] leading-relaxed">
                          Test your management skills in a realistic AI role-play. The AI will simulate a challenging scenario and grade your performance.
                        </p>
                        
                        <div className="space-y-3">
                          <div className="space-y-1">
                            <label className="text-[10px] text-[#7C8AA8] uppercase">Simulation Topic</label>
                            <select 
                              value={simulatorTopic}
                              onChange={(e) => setSimulatorTopic(e.target.value)}
                              className="w-full bg-[#111E33] border border-white/10 rounded-xl px-2.5 py-2 text-xs text-white outline-none focus:border-[#C9A46A]"
                            >
                              <option value="How to handle a client dispute">How to handle a client dispute</option>
                              <option value="Angry Brand Rep: Unusable content draft">Angry Brand Rep: Unusable content draft</option>
                              <option value="Late Creator: Missing Q4 campaign deadline">Late Creator: Missing Q4 campaign deadline</option>
                              <option value="FTC Compliance Crisis: Missing #ad tag">FTC Compliance Crisis: Missing #ad tag</option>
                              <option value="Rate Negotiation: Brand demanding 50% discount">Rate Negotiation: Brand demanding 50% discount</option>
                            </select>
                          </div>
                          
                          <button
                            onClick={handleLaunchSimulator}
                            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-3 rounded-xl text-xs font-bold shadow-lg shadow-emerald-900/20 transition-all flex items-center justify-center gap-2"
                          >
                            <Play className="w-4 h-4 fill-current" />
                            Start Interactive Simulation
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="flex flex-col h-[450px]">
                        <div className="flex items-center justify-between border-b border-white/5 pb-2 mb-2">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Simulation Active</span>
                          </div>
                          <button 
                            onClick={() => setIsSimulatorActive(false)}
                            className="text-[10px] text-[#7C8AA8] hover:text-white underline"
                          >
                            Exit Session
                          </button>
                        </div>

                        {/* Chat Window */}
                        <div className="flex-1 overflow-y-auto space-y-3 p-2 min-h-0 custom-scrollbar">
                          {simMessages.map((msg, i) => (
                            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                              <div className={`max-w-[85%] p-3 rounded-2xl text-[11px] leading-relaxed shadow-sm ${
                                msg.role === 'user' 
                                  ? 'bg-[#C9A46A] text-[#0A1220] font-medium' 
                                  : 'bg-[#16243F] text-[#B8C0D4] border border-white/5'
                              }`}>
                                <div className="text-[9px] font-bold uppercase mb-1 opacity-60">
                                  {msg.role === 'user' ? 'You (Agent Manager)' : 'Angry Brand Coordinator'}
                                </div>
                                {msg.content}
                              </div>
                            </div>
                          ))}
                          {isSimLoading && (
                            <div className="flex justify-start">
                              <div className="bg-[#16243F] border border-white/5 p-3 rounded-2xl">
                                <Loader2 className="w-4 h-4 text-[#C9A46A] animate-spin" />
                              </div>
                            </div>
                          )}

                          {simGrade && (
                            <div className="mt-4 p-4 bg-[#0A1220] border-2 border-[#C9A46A] rounded-2xl space-y-3 animate-in fade-in zoom-in duration-300">
                              <div className="flex items-center justify-between">
                                <h4 className="text-xs font-bold text-[#C9A46A] uppercase">AI Performance Grade</h4>
                                <span className="text-3xl font-serif font-black text-white">{simGrade.overallGrade}</span>
                              </div>
                              
                              <div className="grid grid-cols-3 gap-2">
                                <div className="text-center p-1 bg-white/5 rounded-lg">
                                  <div className="text-[8px] text-[#7C8AA8] uppercase">Tone</div>
                                  <div className="text-xs font-bold text-white">{simGrade.toneScore}%</div>
                                </div>
                                <div className="text-center p-1 bg-white/5 rounded-lg">
                                  <div className="text-[8px] text-[#7C8AA8] uppercase">Policy</div>
                                  <div className="text-xs font-bold text-white">{simGrade.procedureScore}%</div>
                                </div>
                                <div className="text-center p-1 bg-white/5 rounded-lg">
                                  <div className="text-[8px] text-[#7C8AA8] uppercase">Speed</div>
                                  <div className="text-xs font-bold text-white">{simGrade.speedScore}%</div>
                                </div>
                              </div>

                              <p className="text-[10px] text-[#B8C0D4] leading-relaxed italic">
                                "{simGrade.feedback}"
                              </p>

                              <button 
                                onClick={handleLaunchSimulator}
                                className="w-full bg-[#16243F] hover:bg-white/5 text-white py-2 rounded-xl text-[10px] font-bold border border-white/10"
                              >
                                Try Again
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Input Area */}
                        {!simGrade && (
                          <div className="mt-3 pt-3 border-t border-white/5 flex gap-2">
                            <input 
                              type="text"
                              value={simInput}
                              onChange={(e) => setSimInput(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleSendSimMessage()}
                              placeholder="Type your response to the brand..."
                              className="flex-1 bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:border-[#C9A46A] outline-none"
                            />
                            <button 
                              onClick={handleSendSimMessage}
                              disabled={isSimLoading || !simInput.trim()}
                              className="bg-[#C9A46A] text-[#0A1220] p-2 rounded-xl disabled:opacity-50 transition-colors"
                            >
                              <Send className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
