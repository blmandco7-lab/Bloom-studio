import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Layers, ChevronDown, Check, Shield, Lock, Crown, BarChart3, TrendingUp } from 'lucide-react';
import ActivePodSummaryOverlay from './ActivePodSummaryOverlay';

interface WorkPodOption {
  id: string;
  name: string;
  isMain: boolean;
  isExplicitBelong: boolean;
  scopeLabel: string;
  scopeBadge: string;
  scopeColor: string;
}

interface WorkPodSelectorProps {
  currentUser: any;
  currentRole: string;
  liveTenantsMap?: Record<string, any>;
  onSelectPod: (podId: string, podName: string) => void;
  campaigns?: any[];
  deals?: any[];
  invoices?: any[];
  creators?: any[];
  onNavigate?: (screenId: string) => void;
  onOpenExecutiveComparison?: () => void;
}

const getPodScopeConfig = (podId: string, podName: string) => {
  const idLower = (podId || '').trim().toLowerCase();
  const nameLower = (podName || '').trim().toLowerCase();
  const isCore =
    idLower === 'pod_main' ||
    idLower === 'main' ||
    idLower === 'bloom_studio_default' ||
    nameLower === 'bloom & co' ||
    nameLower === 'main agency' ||
    nameLower === 'bloom studio';

  return {
    isCore,
    label: isCore ? 'Core Agency' : 'Subagency',
    badgeText: isCore ? 'Core HQ' : 'Subagency',
    colorClasses: isCore
      ? 'bg-[#C9A46A]/20 text-[#C9A46A] border-[#C9A46A]/40'
      : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
  };
};

export default function WorkPodSelector({
  currentUser,
  currentRole,
  liveTenantsMap = {},
  onSelectPod,
  campaigns = [],
  deals = [],
  invoices = [],
  creators = [],
  onNavigate,
  onOpenExecutiveComparison,
}: WorkPodSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Check if caller holds the 'director' role or platform owner
  const isDirector = useMemo(() => {
    const role = (currentRole || '').toLowerCase();
    return (
      role === 'director' ||
      role === 'owner' ||
      Boolean(currentUser?.isPlatformOwner)
    );
  }, [currentRole, currentUser]);

  const isStaffRole = useMemo(() => {
    const role = (currentRole || '').toLowerCase();
    return (
      isDirector ||
      role === 'agentmgr' ||
      role === 'agent' ||
      role === 'coordinator' ||
      role === 'subagency'
    );
  }, [currentRole, isDirector]);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Close dropdown on Escape key
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  // Compute strictly authorized pods and current pod scope
  const { authorizedPodList, activePodDisplay, activePodId, currentPodScope } = useMemo(() => {
    const userAssignedPodId = (
      currentUser?.pod ||
      currentUser?.tenantId ||
      currentUser?.subagency ||
      'pod_main'
    ).trim();

    const userAssignedPodName = (
      currentUser?.subagency ||
      currentUser?.subagencyName ||
      'Bloom & Co'
    ).trim();

    // Map known tenants from liveTenantsMap
    const knownTenants: Record<string, string> = {
      pod_main: 'Bloom & Co',
      main: 'Bloom & Co',
      bloom_studio_default: 'Bloom & Co',
      pod_sports: 'Bloom Sports Network',
      pod_viral: 'Viral Partners Agency',
    };

    Object.entries(liveTenantsMap).forEach(([key, val]) => {
      if (val && typeof val === 'object') {
        const name = val.agencyName || val.name || val.legalEntityName || key;
        knownTenants[key] = name;
      }
    });

    // Compute explicit belong list for this user
    const explicitBelongSet = new Set<string>();
    if (Array.isArray(currentUser?.authorizedPods)) {
      currentUser.authorizedPods.forEach((p: string) => explicitBelongSet.add(p.trim().toLowerCase()));
    }
    if (Array.isArray(currentUser?.authorizedSubagencies)) {
      currentUser.authorizedSubagencies.forEach((p: string) => explicitBelongSet.add(p.trim().toLowerCase()));
    }
    if (typeof currentUser?.authorizedPods === 'string') {
      currentUser.authorizedPods
        .split(',')
        .forEach((p: string) => explicitBelongSet.add(p.trim().toLowerCase()));
    }
    if (currentUser?.homePod) explicitBelongSet.add(currentUser.homePod.trim().toLowerCase());
    if (currentUser?.assignedPod) explicitBelongSet.add(currentUser.assignedPod.trim().toLowerCase());
    if (currentUser?.homeSubagency) explicitBelongSet.add(currentUser.homeSubagency.trim().toLowerCase());
    if (userAssignedPodId) explicitBelongSet.add(userAssignedPodId.toLowerCase());
    if (userAssignedPodName) explicitBelongSet.add(userAssignedPodName.toLowerCase());

    const isExplicitBelong = (id: string, name: string) => {
      const idLower = id.toLowerCase();
      const nameLower = name.toLowerCase();
      return (
        explicitBelongSet.has(idLower) ||
        explicitBelongSet.has(nameLower) ||
        (idLower === 'pod_main' && (explicitBelongSet.has('bloom & co') || explicitBelongSet.has('main')))
      );
    };

    // 1. If Director: Can see all pods across the workspace (even ones they don't explicitly belong to)
    if (isDirector) {
      const allPodsMap = new Map<string, WorkPodOption>();

      const addOption = (id: string, name: string, isMain = false) => {
        const scope = getPodScopeConfig(id, name);
        allPodsMap.set(id, {
          id,
          name,
          isMain,
          isExplicitBelong: isExplicitBelong(id, name),
          scopeLabel: scope.label,
          scopeBadge: scope.badgeText,
          scopeColor: scope.colorClasses,
        });
      };

      addOption('pod_main', 'Bloom & Co', true);
      addOption('pod_sports', 'Bloom Sports Network');
      addOption('pod_viral', 'Viral Partners Agency');

      Object.entries(liveTenantsMap).forEach(([id, t]) => {
        if (!allPodsMap.has(id)) {
          const name = t?.agencyName || t?.name || id;
          addOption(id, name, id === 'pod_main' || id === 'main');
        }
      });

      const list = Array.from(allPodsMap.values());
      const currentActiveName = knownTenants[userAssignedPodId] || userAssignedPodName || 'Bloom & Co';
      const scope = getPodScopeConfig(userAssignedPodId, currentActiveName);

      return {
        authorizedPodList: list,
        activePodDisplay: currentActiveName,
        activePodId: userAssignedPodId,
        currentPodScope: scope,
      };
    }

    // 2. Non-Directors (agentmgr, agent, coordinator):
    // MUST ONLY see pods they explicitly belong to. They cannot see other pods.
    const userPodsMap = new Map<string, WorkPodOption>();

    Array.from(explicitBelongSet).forEach((rawItem) => {
      const trimmed = rawItem.trim();
      const lower = trimmed.toLowerCase();

      let matchedId = trimmed;
      let matchedName = trimmed;

      if (lower === 'pod_main' || lower === 'bloom & co' || lower === 'main') {
        matchedId = 'pod_main';
        matchedName = 'Bloom & Co';
      } else if (lower === 'pod_sports' || lower.includes('sports')) {
        matchedId = 'pod_sports';
        matchedName = 'Bloom Sports Network';
      } else if (lower === 'pod_viral' || lower.includes('viral')) {
        matchedId = 'pod_viral';
        matchedName = 'Viral Partners Agency';
      } else if (liveTenantsMap[trimmed]) {
        matchedId = trimmed;
        matchedName = liveTenantsMap[trimmed]?.agencyName || trimmed;
      } else {
        const found = Object.entries(liveTenantsMap).find(
          ([, t]) => (t?.agencyName || '').toLowerCase() === lower
        );
        if (found) {
          matchedId = found[0];
          matchedName = found[1]?.agencyName || trimmed;
        }
      }

      if (!userPodsMap.has(matchedId)) {
        const scope = getPodScopeConfig(matchedId, matchedName);
        userPodsMap.set(matchedId, {
          id: matchedId,
          name: matchedName,
          isMain: matchedId === 'pod_main',
          isExplicitBelong: true,
          scopeLabel: scope.label,
          scopeBadge: scope.badgeText,
          scopeColor: scope.colorClasses,
        });
      }
    });

    const list = Array.from(userPodsMap.values());
    const currentActiveName = userAssignedPodName || 'Bloom & Co';
    const scope = getPodScopeConfig(userAssignedPodId, currentActiveName);

    return {
      authorizedPodList: list,
      activePodDisplay: currentActiveName,
      activePodId: userAssignedPodId,
      currentPodScope: scope,
    };
  }, [currentUser, liveTenantsMap, isDirector]);

  // If not a staff user (e.g. Creator or Brand), do not display work pod controls
  if (!isStaffRole) {
    return null;
  }

  const hasMultipleAuthorizedPods = authorizedPodList.length > 1;

  // Single Pod: Render locked indicator with prominent visual scope badge
  if (!hasMultipleAuthorizedPods) {
    return (
      <>
        <div
          id="header-pod-indicator-locked"
          className="hidden md:flex items-center gap-2 bg-[#111E33] border border-white/10 px-2.5 py-1.5 rounded-xl text-xs text-slate-300 shrink-0 shadow-sm"
          title={`Active Work Pod: ${activePodDisplay} (${currentPodScope.label}). Scoped exclusively to your assigned subagency desk.`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="text-[#7C8AA8] font-medium">Pod:</span>
          <span className="text-white font-bold truncate max-w-[120px]">
            {activePodDisplay}
          </span>
          
          {/* Visual Badge for current pod's scope - Click to open Active Pod Summary */}
          <button
            type="button"
            id="current-pod-scope-badge"
            onClick={(e) => {
              e.stopPropagation();
              setIsSummaryOpen(true);
            }}
            className={`text-[9px] uppercase font-mono font-bold tracking-wider px-2 py-0.5 rounded-full border shrink-0 transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-sm hover:brightness-125 ${currentPodScope.colorClasses}`}
            title={`Click badge to view Active Pod Summary for ${activePodDisplay}`}
          >
            {currentPodScope.badgeText}
          </button>

          {isDirector && onOpenExecutiveComparison && (
            <button
              type="button"
              id="btn-single-pod-executive-roll-up"
              onClick={onOpenExecutiveComparison}
              className="text-[9px] uppercase font-mono font-bold tracking-wider px-2 py-0.5 rounded-full border border-[#C9A46A]/50 bg-[#C9A46A]/20 text-[#C9A46A] hover:bg-[#C9A46A]/30 transition-all cursor-pointer flex items-center gap-1"
              title="Open Executive Multi-Pod Roll-Up"
            >
              <BarChart3 className="w-2.5 h-2.5" /> Roll-Up
            </button>
          )}

          <span title="Desk Locked to Authorized Scope">
            <Lock className="w-3 h-3 text-[#C9A46A]/80 ml-0.5 shrink-0" />
          </span>
        </div>

        <ActivePodSummaryOverlay
          isOpen={isSummaryOpen}
          onClose={() => setIsSummaryOpen(false)}
          activePodId={activePodId}
          activePodName={activePodDisplay}
          currentRole={currentRole}
          currentUser={currentUser}
          campaigns={campaigns}
          deals={deals}
          invoices={invoices}
          creators={creators}
          onNavigate={onNavigate}
        />
      </>
    );
  }

  // Multiple Authorized Pods: Render interactive dropdown with current scope badge
  return (
    <div className="relative hidden md:block shrink-0" ref={dropdownRef}>
      <button
        type="button"
        id="header-work-pod-toggle"
        onClick={() => setIsOpen((prev) => !prev)}
        className="flex items-center gap-2 bg-[#111E33] hover:bg-[#162540] border border-white/10 hover:border-[#C9A46A]/40 px-2.5 py-1.5 rounded-xl text-xs text-slate-300 transition-all cursor-pointer shadow-sm focus:outline-none focus:ring-1 focus:ring-[#C9A46A]/50"
        title={`Current Active Pod: ${activePodDisplay} (${currentPodScope.label})`}
        aria-haspopup="true"
        aria-expanded={isOpen}
      >
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
        <span className="text-[#7C8AA8] font-medium">Pod:</span>
        <span className="text-[#C9A46A] font-bold truncate max-w-[110px]">
          {activePodDisplay}
        </span>

        {/* Visual Badge for current pod's scope - Click to open Active Pod Summary */}
        <span
          id="current-pod-scope-badge"
          onClick={(e) => {
            e.stopPropagation();
            setIsSummaryOpen(true);
          }}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.stopPropagation();
              setIsSummaryOpen(true);
            }
          }}
          className={`text-[9px] uppercase font-mono font-bold tracking-wider px-2 py-0.5 rounded-full border shrink-0 transition-all hover:scale-105 active:scale-95 cursor-pointer shadow-sm hover:brightness-125 ${currentPodScope.colorClasses}`}
          title={`Click badge to view Active Pod Summary for ${activePodDisplay}`}
        >
          {currentPodScope.badgeText}
        </span>

        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 shrink-0 ${
            isOpen ? 'rotate-180 text-[#C9A46A]' : ''
          }`}
        />
      </button>

      {isOpen && (
        <div
          id="header-work-pod-dropdown-menu"
          className="absolute left-0 mt-2 w-72 bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl shadow-2xl z-50 overflow-hidden backdrop-blur-xl animate-in fade-in duration-150"
        >
          {/* Header with Scope and Authorization Status */}
          <div className="p-3 border-b border-white/10 bg-[#111E33]/60">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                Active Work Pod
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsSummaryOpen(true);
                  setIsOpen(false);
                }}
                className={`text-[9px] uppercase font-mono font-bold tracking-wider px-2 py-0.5 rounded-full border cursor-pointer hover:scale-105 transition-all ${currentPodScope.colorClasses}`}
                title={`Click to view Active Pod Summary for ${activePodDisplay}`}
              >
                Scope: {currentPodScope.label}
              </button>
            </div>
            
            <div className="flex items-center justify-between mt-2 pt-1 border-t border-white/5">
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                {isDirector ? (
                  <>
                    <Crown className="w-3 h-3 text-[#C9A46A]" />
                    <span className="text-amber-300 font-semibold">Director Cross-Pod Access</span>
                  </>
                ) : (
                  <span>Authorized Desks</span>
                )}
              </span>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {authorizedPodList.length} {authorizedPodList.length === 1 ? 'Pod' : 'Pods'} Accessible
              </span>
            </div>
          </div>

          {/* Pod List (Scoped Strictly: All for Director, explicit-only for non-director) */}
          <div className="p-1.5 space-y-1 max-h-60 overflow-y-auto custom-scrollbar">
            {authorizedPodList.map((pod) => {
              const isSelected =
                activePodDisplay.toLowerCase() === pod.name.toLowerCase() ||
                activePodId.toLowerCase() === pod.id.toLowerCase();

              return (
                <button
                  key={pod.id}
                  type="button"
                  id={`work-pod-option-${pod.id}`}
                  onClick={() => {
                    onSelectPod(pod.id, pod.name);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#C9A46A]/15 border border-[#C9A46A]/40 text-white shadow-sm'
                      : 'hover:bg-white/5 border border-transparent text-slate-300 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className={`w-2 h-2 rounded-full shrink-0 ${
                        isSelected ? 'bg-[#C9A46A]' : 'bg-slate-500'
                      }`}
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold leading-snug truncate">
                          {pod.name}
                        </span>
                        {/* Option Scope Badge */}
                        <span
                          className={`text-[8px] uppercase font-mono font-bold px-1.5 py-0.2 rounded border shrink-0 ${pod.scopeColor}`}
                        >
                          {pod.scopeBadge}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono leading-none mt-1 flex items-center gap-1.5">
                        <span>{pod.isMain ? 'Core Agency Desk' : 'Subagency Desk'}</span>
                        {isDirector && !pod.isExplicitBelong && (
                          <span className="text-[8px] font-sans text-amber-400/90 bg-amber-400/10 px-1 rounded">
                            Director Oversight
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {isSelected && (
                    <Check className="w-4 h-4 text-[#C9A46A] shrink-0 ml-2" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Active Pod Summary Action */}
          <div className="px-2.5 py-2 border-t border-white/10 bg-[#0E1B33] space-y-1.5">
            <button
              type="button"
              id="view-active-pod-summary-btn"
              onClick={(e) => {
                e.stopPropagation();
                setIsSummaryOpen(true);
                setIsOpen(false);
              }}
              className="w-full bg-white/5 hover:bg-[#C9A46A]/15 text-[#C9A46A] hover:text-white border border-[#C9A46A]/30 rounded-xl px-3 py-1.5 text-[11px] font-mono font-semibold flex items-center justify-between transition-all cursor-pointer shadow-sm"
            >
              <span className="flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5" /> View Pod Summary
              </span>
              <span className="text-[9px] text-slate-400 uppercase">Totals &amp; Revenue &rarr;</span>
            </button>

            {isDirector && onOpenExecutiveComparison && (
              <button
                type="button"
                id="view-multi-pod-comparison-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenExecutiveComparison();
                  setIsOpen(false);
                }}
                className="w-full bg-[#C9A46A]/15 hover:bg-[#C9A46A]/25 text-white border border-[#C9A46A]/50 rounded-xl px-3 py-1.5 text-[11px] font-mono font-semibold flex items-center justify-between transition-all cursor-pointer shadow-sm"
              >
                <span className="flex items-center gap-1.5 text-[#C9A46A]">
                  <BarChart3 className="w-3.5 h-3.5" /> Executive Comparison
                </span>
                <span className="text-[9px] text-[#C9A46A] uppercase font-bold">All Pods P&L &rarr;</span>
              </button>
            )}
          </div>

          {/* Security Isolation Footer */}
          <div className="p-2.5 border-t border-white/10 bg-[#0A1220]/80 flex items-center gap-2 text-[10px] text-slate-400">
            <Shield className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
            <span className="leading-tight">
              {isDirector
                ? 'Director mode active: Authorized to audit across all registered pods.'
                : 'Multi-tenant isolation active: Access strictly restricted to assigned pods.'}
            </span>
          </div>
        </div>
      )}

      {/* Active Pod Summary Overlay Modal */}
      <ActivePodSummaryOverlay
        isOpen={isSummaryOpen}
        onClose={() => setIsSummaryOpen(false)}
        activePodId={activePodId}
        activePodName={activePodDisplay}
        currentRole={currentRole}
        currentUser={currentUser}
        campaigns={campaigns}
        deals={deals}
        invoices={invoices}
        creators={creators}
        onNavigate={onNavigate}
      />
    </div>
  );
}
