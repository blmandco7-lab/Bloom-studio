import React, { useState, useEffect } from 'react';
import { 
  Users, Award, Activity, DollarSign, UserPlus, FileText, 
  ShieldCheck, CheckCircle2, AlertTriangle, Trash2, Sliders, 
  Clock, Plus, Search, ChevronRight, Send, Lock, Package, Landmark, ArrowRight, Eye
} from 'lucide-react';
import { Creator, Deal, Role } from '../types';
import AgentOnboardingDashboard from './AgentOnboardingDashboard';
import ManagerDashboardConsole from './ManagerDashboardConsole';
import { db } from '../lib/firebase';
import { collection, onSnapshot, doc, deleteDoc, query, where } from 'firebase/firestore';
import { moveToTrash } from '../lib/trashService';

interface AgentItem {
  id: string;
  name: string;
  role: string;
  email: string;
  score: number;
  dealsCompleted: number;
  volume: number;
  deadlinesMet: number;
  commsScore: number;
  pod: string;
  assignedTalentCount: number;
  commissionRate: number;
}

interface AgentManagementHubProps {
  creators: Creator[];
  deals: Deal[];
  currentUser?: any;
  currentRole?: string;
  initialTab?: 'briefing' | 'managers' | 'performance' | 'commissions' | 'onboarding';
  primaryBrandColor?: string;
  cardBgColor?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: any) => void;
  onNavigateToScreen?: (screenId: string) => void;
}

export default function AgentManagementHub({
  creators = [],
  deals = [],
  currentUser,
  currentRole = 'director',
  initialTab = 'managers',
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  onAddActivityLog,
  triggerNotification,
  onNavigateToScreen
}: AgentManagementHubProps) {
  const [activeTab, setActiveTab] = useState<'briefing' | 'managers' | 'performance' | 'commissions' | 'onboarding'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);

  // Firestore synced agents roster
  const [agents, setAgents] = useState<AgentItem[]>([]);

  useEffect(() => {
    const isOwner = !!currentUser?.isPlatformOwner;
    const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
    
    let baseQuery;
    if (isOwner) {
      baseQuery = collection(db, 'studio-agents');
    } else {
      baseQuery = query(
        collection(db, 'studio-agents'),
        where('pod', '==', userPod)
      );
    }

    const unsub = onSnapshot(baseQuery, (snap) => {
      const list: AgentItem[] = [];
      snap.forEach(d => {
        const data = d.data();
        list.push({
          id: d.id,
          name: data.name || 'Agent',
          role: data.role || 'Agent',
          email: data.email || '',
          score: data.score || 95,
          dealsCompleted: data.dealsCompleted || 10,
          volume: data.volume || 100000,
          deadlinesMet: data.deadlinesMet || 95,
          commsScore: data.commsScore || 4.8,
          pod: data.pod || data.subagency || 'Primary Pod',
          assignedTalentCount: data.assignedTalentCount || 3,
          commissionRate: data.commissionRate || 12
        });
      });
      if (list.length > 0) {
        setAgents(list);
      } else {
        // Fallback initial seed if empty
        setAgents([
          {
            id: 'ag_1',
            name: 'Marcus Cole',
            role: 'Agent Manager',
            email: 'marcus@bloomstudio.com',
            score: 96,
            dealsCompleted: 14,
            volume: 185000,
            deadlinesMet: 98,
            commsScore: 4.9,
            pod: userPod,
            assignedTalentCount: 5,
            commissionRate: 15
          },
          {
            id: 'ag_2',
            name: 'Elena Vance',
            role: 'Senior Agent',
            email: 'elena@bloomstudio.com',
            score: 92,
            dealsCompleted: 11,
            volume: 142000,
            deadlinesMet: 95,
            commsScore: 4.7,
            pod: userPod,
            assignedTalentCount: 4,
            commissionRate: 12.5
          }
        ]);
      }
    }, err => console.warn('[studio-agents] sync error:', err));
    return () => unsub();
  }, [currentUser]);

  // Notes state
  const [staffNotes, setStaffNotes] = useState([
    { id: 'note_1', author: 'Director', text: 'Marcus Cole signed $45K brand partnership with BarkHydrate. Commission approved for Q3 payout.', date: 'Today at 2:15 PM' },
    { id: 'note_2', author: 'Director', text: 'Elena Vance assigned 2 new beauty UGC creators for onboarding checks.', date: 'Yesterday at 4:30 PM' }
  ]);
  const [newNoteText, setNewNoteText] = useState('');

  const isAgentMgr = currentRole === 'agentmgr' || currentRole.includes('manager');
  const myName = (currentUser?.name || '').toLowerCase().trim();
  
  const visibleAgents = agents.filter(ag => {
    if (!isAgentMgr) return true;
    const amInBeautyPod = myName.includes('marcus') || myName.includes('cole');
    if (amInBeautyPod) return ag.pod.includes('Beauty') || ag.pod.includes('UGC');
    return ag.name.toLowerCase().includes(myName) || ag.pod.includes('Pet');
  });

  const isDirector = ['director', 'agency'].includes((currentRole || '').toLowerCase());

  const handleOffboardAgent = async (agentId: string, agentName: string) => {
    if (!window.confirm(`Are you sure you want to permanently offboard ${agentName}? This will revoke their workspace access and re-pool their creators.`)) return;
    
    console.log('[AgentManagementHub] handleOffboardAgent triggered for:', { agentId, agentName });
    try {
      const targetAgent = agents.find(a => a.id === agentId);
      if (targetAgent) {
        await moveToTrash('studio-agents', targetAgent, 'agent', currentUser);
      }
      await deleteDoc(doc(db, 'studio-agents', agentId));
    } catch (err) {
      console.warn('[AgentManagementHub] Firestore offboard delete error:', err);
    }

    setAgents(prev => prev.filter(a => a.id !== agentId));
    if (triggerNotification) {
      triggerNotification("Agent Offboarded", `${agentName} has been unassigned and credentials revoked.`, "warning");
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.name || "User", currentRole, `Offboarded agent ${agentName} from agency seat`);
    }
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('[AgentManagementHub] handleAddNote triggered with text:', newNoteText);
    if (!newNoteText.trim()) return;

    const newNote = {
      id: 'note_' + Date.now(),
      author: currentUser?.name || (isDirector ? 'Director' : 'Staff Lead'),
      text: newNoteText.trim(),
      date: 'Just now'
    };

    setStaffNotes(prev => [newNote, ...prev]);
    setNewNoteText('');
    if (triggerNotification) {
      triggerNotification("Staff Note Saved", "Logged internal note to agency registry.", "success");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                UNIFIED STAFF &amp; AGENT MANAGEMENT HUB
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                {agents.length} Active Staff Seats
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              Agent Management Hub
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Unified workspace for agent manager permissions, performance scoring, commission rate structures, and staff onboarding.
            </p>
          </div>
        </div>
      </div>

      {/* Quick Manager Desk Operational Shortcuts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: ftc-compliance');
            if (onNavigateToScreen) onNavigateToScreen('ftc-compliance');
          }}
          className="bg-[#0D1830] border border-emerald-500/30 hover:border-emerald-400 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to FTC Compliance"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors">FTC Compliance</h4>
            <p className="text-[10px] text-slate-400">Audit #ad disclosures</p>
          </div>
        </button>

        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: w9-1099-tracker');
            if (onNavigateToScreen) onNavigateToScreen('w9-1099-tracker');
          }}
          className="bg-[#0D1830] border border-sky-500/30 hover:border-sky-400 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to W-9 & 1099 Tracker"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <FileText className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-sky-400 transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-sky-400 transition-colors">W-9 &amp; 1099 Tracker</h4>
            <p className="text-[10px] text-slate-400">IRS tax filings</p>
          </div>
        </button>

        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: content-review');
            if (onNavigateToScreen) onNavigateToScreen('content-review');
          }}
          className="bg-[#0D1830] border border-purple-500/30 hover:border-purple-400 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to Content Review"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Activity className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-purple-400 transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-purple-400 transition-colors">Content Review</h4>
            <p className="text-[10px] text-slate-400">Draft approvals</p>
          </div>
        </button>

        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: contracts');
            if (onNavigateToScreen) onNavigateToScreen('contracts');
          }}
          className="bg-[#0D1830] border border-amber-500/30 hover:border-amber-400 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to Contract Vault"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Lock className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-amber-400 transition-colors">Contract Vault</h4>
            <p className="text-[10px] text-slate-400">E-Sign &amp; rights</p>
          </div>
        </button>

        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: fulfillment-hub');
            if (onNavigateToScreen) onNavigateToScreen('fulfillment-hub');
          }}
          className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A]/50 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to Fulfillment Desk"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Package className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-[#C9A46A] transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A] transition-colors">Fulfillment Desk</h4>
            <p className="text-[10px] text-slate-400">Sample &amp; gifting</p>
          </div>
        </button>

        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: revenue');
            if (onNavigateToScreen) onNavigateToScreen('revenue');
          }}
          className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A]/50 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to My Earnings"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Landmark className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-[#C9A46A] transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A] transition-colors">My Earnings</h4>
            <p className="text-[10px] text-slate-400">Commission log</p>
          </div>
        </button>

        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: kb');
            if (onNavigateToScreen) onNavigateToScreen('kb');
          }}
          className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A]/50 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to Training Hub"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Award className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-[#C9A46A] transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A] transition-colors">Training Hub</h4>
            <p className="text-[10px] text-slate-400">Academy SOPs</p>
          </div>
        </button>

        <button 
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Shortcut clicked: brand-crm');
            if (onNavigateToScreen) onNavigateToScreen('brand-crm');
          }}
          className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A]/50 rounded-2xl p-3 space-y-2 transition-all cursor-pointer group shadow-lg text-left w-full block"
          aria-label="Navigate to Client Reports"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Users className="w-3.5 h-3.5" />
            </div>
            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-[#C9A46A] transition-colors" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white group-hover:text-[#C9A46A] transition-colors">Client Reports</h4>
            <p className="text-[10px] text-slate-400">Brand CRM</p>
          </div>
        </button>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Tab clicked: managers');
            setActiveTab('managers');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'managers'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Agent Managers &amp; Permissions</span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/20 font-mono">{agents.length}</span>
        </button>

        <button
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Tab clicked: briefing');
            setActiveTab('briefing');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'briefing'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Daily Briefing &amp; Pipelines</span>
        </button>

        <button
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Tab clicked: performance');
            setActiveTab('performance');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'performance'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Agent Dashboard &amp; Scoring</span>
        </button>

        <button
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Tab clicked: commissions');
            setActiveTab('commissions');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'commissions'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Commission Structure &amp; Splits</span>
        </button>

        <button
          type="button"
          onClick={() => {
            console.log('[AgentManagementHub] Tab clicked: onboarding');
            setActiveTab('onboarding');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'onboarding'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>Onboarding &amp; Internal Notes</span>
        </button>
      </div>

      {/* TAB CONTENT: Daily Briefing & Pipelines */}
      {activeTab === 'briefing' && (
        <ManagerDashboardConsole
          creators={creators}
          deals={deals}
          currentRole={currentRole}
        />
      )}

      {/* TAB CONTENT: Agent Managers & Permissions */}
      {activeTab === 'managers' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {visibleAgents.map(ag => (
              <div 
                key={ag.id}
                className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4 shadow-lg flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-full bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center font-bold text-[#C9A46A]">
                      {ag.name.charAt(0)}
                    </div>
                    <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      Active Manager
                    </span>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white">{ag.name}</h3>
                    <p className="text-xs text-slate-400">{ag.role} &bull; {ag.pod}</p>
                    <p className="text-[11px] font-mono text-slate-500 mt-0.5">{ag.email}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5 text-xs">
                    <div className="bg-black/30 p-2 rounded-xl">
                      <span className="text-[10px] text-slate-500 block uppercase">Assigned Talent</span>
                      <span className="font-bold text-white font-mono">{ag.assignedTalentCount} Creators</span>
                    </div>
                    <div className="bg-black/30 p-2 rounded-xl">
                      <span className="text-[10px] text-slate-500 block uppercase">Split Rate</span>
                      <span className="font-bold text-[#C9A46A] font-mono">{ag.commissionRate}%</span>
                    </div>
                  </div>
                </div>

                {isDirector && (
                  <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 font-mono">ID: {ag.id}</span>
                    <button
                      type="button"
                      onClick={() => handleOffboardAgent(ag.id, ag.name)}
                      className="text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Offboard Agent</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: Performance & Scoring */}
      {activeTab === 'performance' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {visibleAgents.map(ag => (
            <div key={ag.id} className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4 shadow-lg">
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-bold text-white text-base">{ag.name}</h3>
                  <span className="text-xs text-slate-400">{ag.role}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase text-slate-500 block">Overall KPI</span>
                  <span className="text-xl font-bold font-mono text-[#C9A46A]">{ag.score}/100</span>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2 rounded-lg bg-black/30">
                  <span className="text-slate-400">Deals Closed:</span>
                  <span className="font-bold text-white font-mono">{ag.dealsCompleted}</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-lg bg-black/30">
                  <span className="text-slate-400">Managed Deal Volume:</span>
                  <span className="font-bold text-emerald-400 font-mono">${ag.volume.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-lg bg-black/30">
                  <span className="text-slate-400">Deadline Met Rate:</span>
                  <span className="font-bold text-white font-mono">{ag.deadlinesMet}%</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-lg bg-black/30">
                  <span className="text-slate-400">Comms Score:</span>
                  <span className="font-bold text-amber-400 font-mono">⭐ {ag.commsScore} / 5.0</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB CONTENT: Commissions Structure */}
      {activeTab === 'commissions' && (
        <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-6 space-y-6">
          <div>
            <h3 className="text-lg font-bold text-white font-serif">Agency Commission Structure &amp; Splits</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Standard agency tiered commission payouts calculated from net contract values.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#16243F] border border-white/5 rounded-xl p-4 space-y-2">
              <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold">Tier 1: Senior Manager</span>
              <span className="text-2xl font-bold font-mono text-white block">15.0%</span>
              <p className="text-[11px] text-slate-400">Applied to deals over $50K closed by Senior Pod Managers.</p>
            </div>
            <div className="bg-[#16243F] border border-white/5 rounded-xl p-4 space-y-2">
              <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold">Tier 2: Standard Agent</span>
              <span className="text-2xl font-bold font-mono text-white block">12.5%</span>
              <p className="text-[11px] text-slate-400">Standard commission split on managed creator deals.</p>
            </div>
            <div className="bg-[#16243F] border border-white/5 rounded-xl p-4 space-y-2">
              <span className="text-[10px] font-mono text-[#C9A46A] uppercase font-bold">Tier 3: Coordinator / Assist</span>
              <span className="text-2xl font-bold font-mono text-white block">10.0%</span>
              <p className="text-[11px] text-slate-400">Fulfillment and sample tracking milestone override bonus.</p>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: Onboarding & Notes */}
      {activeTab === 'onboarding' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {isDirector ? (
              <>
                {/* Staff Selection Sidebar */}
                <div className="lg:col-span-4 bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-white/5 pb-3">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Users className="w-4 h-4 text-[#C9A46A]" />
                      <span>Staff Registry &amp; Verification</span>
                    </h3>
                  </div>
                  
                  <div className="space-y-2">
                    {agents.map(ag => (
                      <button
                        key={ag.id}
                        onClick={() => setSelectedAgentId(ag.id)}
                        className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between group ${
                          selectedAgentId === ag.id 
                            ? 'bg-[#C9A46A]/10 border-[#C9A46A]/40' 
                            : 'bg-black/20 border-transparent hover:bg-white/5'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                            selectedAgentId === ag.id ? 'bg-[#C9A46A] text-[#0A1220]' : 'bg-[#111E33] text-slate-400'
                          }`}>
                            {ag.name.charAt(0)}
                          </div>
                          <div>
                            <p className={`text-xs font-bold ${selectedAgentId === ag.id ? 'text-white' : 'text-slate-300'}`}>{ag.name}</p>
                            <p className="text-[10px] text-slate-500">{ag.role}</p>
                          </div>
                        </div>
                        <ChevronRight className={`w-4 h-4 transition-transform ${selectedAgentId === ag.id ? 'text-[#C9A46A] translate-x-1' : 'text-slate-600'}`} />
                      </button>
                    ))}
                  </div>

                  <div className="pt-4 border-t border-white/5 mt-4">
                    <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-xl">
                      <p className="text-[10px] text-indigo-300 leading-relaxed italic">
                        Director Mode: You are viewing and verifying onboarding documentation for individual staff members.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Onboarding Dashboard for selected agent */}
                <div className="lg:col-span-8">
                  {selectedAgentId ? (
                    <AgentOnboardingDashboard 
                      currentUser={currentUser} 
                      currentRole={currentRole} 
                      targetStaffId={selectedAgentId}
                      targetStaffName={agents.find(a => a.id === selectedAgentId)?.name}
                      triggerNotification={triggerNotification} 
                      onAddActivityLog={onAddActivityLog}
                      onNavigateToScreen={onNavigateToScreen}
                    />
                  ) : (
                    <div className="bg-[#0D1830] border border-white/10 rounded-3xl p-12 text-center space-y-4">
                      <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto">
                        <UserPlus className="w-8 h-8 text-slate-500" />
                      </div>
                      <div className="max-w-xs mx-auto">
                        <h3 className="text-lg font-serif font-bold text-white">Select Staff Member</h3>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          Choose an agent or staff member from the registry to manage their secure onboarding checklist.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              /* Agent Manager view - shows their OWN checklist */
              <div className="lg:col-span-12">
                <AgentOnboardingDashboard 
                  currentUser={currentUser} 
                  currentRole={currentRole} 
                  triggerNotification={triggerNotification} 
                  onAddActivityLog={onAddActivityLog}
                  onNavigateToScreen={onNavigateToScreen}
                />
              </div>
            )}
          </div>

          {/* Internal Staff Notes */}
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#C9A46A]" />
                <span>Internal Staff Notes &amp; Logs</span>
              </h3>
              <span className="text-[10px] font-mono text-slate-400">{staffNotes.length} notes</span>
            </div>

            <form onSubmit={handleAddNote} className="space-y-2">
              <textarea
                rows={3}
                placeholder="Log internal update about staff or pod assignments..."
                value={newNoteText}
                onChange={e => setNewNoteText(e.target.value)}
                className="w-full bg-black/30 border border-white/10 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
              />
              <button
                type="submit"
                className="w-full bg-[#C9A46A] hover:bg-[#b89359] text-[#0A1220] font-bold text-xs py-2 rounded-xl transition cursor-pointer"
              >
                Log Staff Note
              </button>
            </form>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {staffNotes.map(n => (
                <div key={n.id} className="bg-black/30 border border-white/5 rounded-xl p-3 space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
                    <span className="text-[#C9A46A] font-bold">{n.author}</span>
                    <span>{n.date}</span>
                  </div>
                  <p className="text-xs text-slate-300">{n.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
