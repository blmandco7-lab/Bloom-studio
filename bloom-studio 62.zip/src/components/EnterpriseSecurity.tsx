import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, Lock, Server, FileText, CheckCircle2, AlertTriangle, 
  Download, RefreshCw, Cpu, Database, Key, Check, Users, FileCheck, Landmark,
  Shield, Terminal, Sparkles, ExternalLink, HardDrive, Eye, Edit3, Save
} from 'lucide-react';
import BrandTermsAgreementModal from './BrandTermsAgreementModal';
import { computeRealSha256, persistSignatureRecord } from '../lib/cryptoSignatures';
import { getAuthHeaders, db } from '../lib/firebase';
import { doc, setDoc, onSnapshot } from 'firebase/firestore';
import { safeStorage } from '../utils/safeStorage';

interface EnterpriseSecurityProps {
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentUser?: any;
  currentRole?: string;
}

export default function EnterpriseSecurity({
  onAddActivityLog,
  triggerNotification,
  currentUser,
  currentRole = 'none'
}: EnterpriseSecurityProps) {
  const [activeTab, setActiveTab] = useState<'soc2' | 'rbac' | 'media-vault' | 'white-label-tos'>('soc2');
  const [isSubmittingSignature, setIsSubmittingSignature] = useState<string | null>(null);

  // SOC 2 Internal Readiness Checklist state with local persistence
  const defaultSoc2Controls = [
    {
      id: 'CC6.1',
      title: 'Logical & Role-Based Access Controls (RBAC)',
      desc: 'Architecture enforces server-side tenant pod scoping and strict role authorization boundaries across sub-agencies.',
      status: 'Implemented',
      auditEvidence: 'Express route authorization middleware (verifyFirebaseToken, requireStaff, pod checks) and Firestore security rules implemented.'
    },
    {
      id: 'CC6.6',
      title: 'Data Encryption In-Transit & At-Rest (TLS 1.3 & AES-256)',
      desc: 'All communications secured via HTTPS/TLS 1.3. Cloud databases enforce at-rest encryption standards.',
      status: 'Implemented',
      auditEvidence: 'Transport encryption enforced across all API endpoints; Cloud storage uses native at-rest volume encryption.'
    },
    {
      id: 'CC7.1',
      title: 'Continuous Vulnerability & Penetration Scanning',
      desc: 'Automated dependency audit checks and routine security regression tests.',
      status: 'In-Development',
      auditEvidence: 'Automated CI/CD dependency vulnerability scans active; external third-party penetration test scheduled prior to formal audit.'
    },
    {
      id: 'CC8.1',
      title: 'Software Change Management & Audit Logging',
      desc: 'Version-controlled pull request workflows, signed commits, and persistent administrative activity logs.',
      status: 'Internal Review',
      auditEvidence: 'Audit activity logs recorded to dedicated Firestore collection; access restricted to authenticated staff/platform owner.'
    }
  ];

  const [soc2Controls, setSoc2Controls] = useState(() => {
    try {
      const saved = safeStorage.getItem('bloom_soc2_controls');
      return saved ? JSON.parse(saved) : defaultSoc2Controls;
    } catch (e) {
      return defaultSoc2Controls;
    }
  });

  const [editingControlId, setEditingControlId] = useState<string | null>(null);
  const [editStatus, setEditStatus] = useState<string>('In-Development');
  const [editEvidence, setEditEvidence] = useState<string>('');

  const saveControlEdit = (id: string) => {
    const updated = soc2Controls.map((c: any) => 
      c.id === id ? { ...c, status: editStatus, auditEvidence: editEvidence } : c
    );
    setSoc2Controls(updated);
    try {
      safeStorage.setItem('bloom_soc2_controls', JSON.stringify(updated));
    } catch (e) {}
    setEditingControlId(null);
    triggerNotification('Control Updated', `Saved readiness details for ${id}.`, 'success');
  };

  // CDFI Funding Tracker state
  const [cdfiLoanAllocation, setCdfiLoanAllocation] = useState({
    totalLoanGranted: 50000,
    soc2AuditFundAllocated: 25000,
    spentToDate: 12500,
    auditorPartner: 'A-LIGN / Schellman (Target Partners)',
    status: 'Audit Planning'
  });

  // RBAC Tenant Isolation Test State
  const [testResult, setTestResult] = useState<{
    summary: string;
    serverDetails?: string;
    status: 'success' | 'warning' | 'error';
    details: string[];
  } | null>(null);
  const [isRunningIsolationTest, setIsRunningIsolationTest] = useState(false);

  // Signed agreements state
  const [signedAgreements, setSignedAgreements] = useState<Record<string, { signedBy: string; signedAt: string; hash: string }>>(() => {
    try {
      const saved = safeStorage.getItem('wl_signed_security_agreements');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  // Feature Toggles state
  const [mandatoryEnforcement, setMandatoryEnforcement] = useState<boolean>(() => {
    try {
      const saved = safeStorage.getItem('bloom_mandatory_enforcement');
      return saved !== null ? JSON.parse(saved) : true;
    } catch (e) {
      return true;
    }
  });

  const [automatedHashing, setAutomatedHashing] = useState<boolean>(() => {
    try {
      const saved = safeStorage.getItem('bloom_automated_hashing');
      return saved !== null ? JSON.parse(saved) : true;
    } catch (e) {
      return true;
    }
  });

  const [preSendApprovalGate, setPreSendApprovalGate] = useState<boolean>(() => {
    try {
      const saved = safeStorage.getItem('bloom_presend_approval_gate');
      return saved !== null ? JSON.parse(saved) : true;
    } catch (e) {
      return true;
    }
  });

  const [disabledClauses, setDisabledClauses] = useState<Record<string, boolean>>(() => {
    try {
      const saved = safeStorage.getItem('bloom_disabled_clauses');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  // Load real-time settings from Firestore if available
  useEffect(() => {
    if (!currentUser) return;
    const userPod = currentUser.subagency || currentUser.tenantId || currentUser.pod || 'pod_main';
    
    const unsubscribe = onSnapshot(doc(db, 'studio-enterprise-security-settings', userPod), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.mandatoryEnforcement !== undefined) {
          setMandatoryEnforcement(data.mandatoryEnforcement);
          safeStorage.setItem('bloom_mandatory_enforcement', JSON.stringify(data.mandatoryEnforcement));
        }
        if (data.automatedHashing !== undefined) {
          setAutomatedHashing(data.automatedHashing);
          safeStorage.setItem('bloom_automated_hashing', JSON.stringify(data.automatedHashing));
        }
        if (data.preSendApprovalGate !== undefined) {
          setPreSendApprovalGate(data.preSendApprovalGate);
          safeStorage.setItem('bloom_presend_approval_gate', JSON.stringify(data.preSendApprovalGate));
        }
        if (data.disabledClauses !== undefined) {
          setDisabledClauses(data.disabledClauses);
          safeStorage.setItem('bloom_disabled_clauses', JSON.stringify(data.disabledClauses));
        }
        console.log('[EnterpriseSecurity] Loaded security settings from Firestore:', data);
      }
    }, (err) => {
      console.warn('[EnterpriseSecurity] Failed to subscribe to enterprise settings:', err);
    });

    return () => unsubscribe();
  }, [currentUser]);

  const saveEnterpriseSettings = async (updates: {
    mandatoryEnforcement?: boolean;
    automatedHashing?: boolean;
    preSendApprovalGate?: boolean;
    disabledClauses?: Record<string, boolean>;
  }) => {
    const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
    try {
      if (db && userPod) {
        await setDoc(doc(db, 'studio-enterprise-security-settings', userPod), {
          mandatoryEnforcement: updates.mandatoryEnforcement !== undefined ? updates.mandatoryEnforcement : mandatoryEnforcement,
          automatedHashing: updates.automatedHashing !== undefined ? updates.automatedHashing : automatedHashing,
          preSendApprovalGate: updates.preSendApprovalGate !== undefined ? updates.preSendApprovalGate : preSendApprovalGate,
          disabledClauses: updates.disabledClauses !== undefined ? updates.disabledClauses : disabledClauses,
          pod: userPod,
          tenantId: userPod,
          subagency: userPod,
          updatedAt: new Date().toISOString()
        }, { merge: true });
        console.log('[EnterpriseSecurity] Saved settings to Firestore for pod:', userPod);
      }
    } catch (e) {
      console.error('[EnterpriseSecurity] Error saving settings to Firestore:', e);
    }
  };

  // Modal State for Clause Preview
  const [previewClauseModal, setPreviewClauseModal] = useState<{
    key: string;
    title: string;
    clauseNum: string;
    ruleText: string;
    penaltyText: string;
    legalSectionText: string;
  } | null>(null);

  const toggleMandatoryEnforcement = (val: boolean) => {
    setMandatoryEnforcement(val);
    safeStorage.setItem('bloom_mandatory_enforcement', JSON.stringify(val));
    saveEnterpriseSettings({ mandatoryEnforcement: val });
    triggerNotification('Rule Gate Updated', `Mandatory clause enforcement is now ${val ? 'ENABLED' : 'DISABLED'}.`, 'info');
  };

  const toggleAutomatedHashing = (val: boolean) => {
    setAutomatedHashing(val);
    safeStorage.setItem('bloom_automated_hashing', JSON.stringify(val));
    saveEnterpriseSettings({ automatedHashing: val });
    triggerNotification('Hashing Config Updated', `SHA-256 cryptographic hashing is now ${val ? 'ENABLED' : 'DISABLED'}.`, 'info');
  };

  const togglePreSendApprovalGate = (val: boolean) => {
    setPreSendApprovalGate(val);
    safeStorage.setItem('bloom_presend_approval_gate', JSON.stringify(val));
    saveEnterpriseSettings({ preSendApprovalGate: val });
    triggerNotification('Approval Gate Updated', `Pre-send Director review gate is now ${val ? 'ENABLED' : 'DISABLED'}.`, 'info');
  };

  const toggleClauseDisabled = (clauseKey: string) => {
    const next = { ...disabledClauses, [clauseKey]: !disabledClauses[clauseKey] };
    setDisabledClauses(next);
    safeStorage.setItem('bloom_disabled_clauses', JSON.stringify(next));
    saveEnterpriseSettings({ disabledClauses: next });
    triggerNotification('Clause Toggle Updated', `Clause enforcement for ${clauseKey} is now ${next[clauseKey] ? 'OFF' : 'ON'}.`, 'info');
  };

  const [brandTermsModalOpen, setBrandTermsModalOpen] = useState(false);

  const runTenantIsolationTest = async () => {
    setIsRunningIsolationTest(true);
    setTestResult(null);

    const scanDetails: string[] = [];
    let serverSummary = '';
    let isServerPass = false;

    try {
      // 1. Genuine Server-side Multi-Tenant Isolation Audit
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/security/test-isolation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders
        }
      });

      if (response.ok) {
        const serverData = await response.json();
        isServerPass = serverData.partitionStatus === 'VERIFIED_ISOLATED';
        serverSummary = serverData.auditSummary || `Audited ${serverData.collectionsAudited} collections for tenant ${serverData.callerPod}.`;
        scanDetails.push(`Server Audit: ${serverSummary}`);
        if (serverData.crossPodAnomalies > 0) {
          scanDetails.push(`Warning: ${serverData.crossPodAnomalies} potential partition boundary flags detected.`);
        }
      } else {
        scanDetails.push(`Server Audit Notice: Server returned status ${response.status}. Validating via local storage namespace scanner.`);
      }
    } catch (serverErr: any) {
      scanDetails.push(`Server Audit Connection Notice: ${serverErr.message || 'Offline verification active'}`);
    }

    // 2. Client-side Local Storage Namespace Integrity Check
    let totalScanned = 0;
    let localAnomalies = 0;

    try {
      const reviewRaw = safeStorage.getItem('bloom_review_queue');
      if (reviewRaw) {
        const queue = JSON.parse(reviewRaw);
        if (Array.isArray(queue)) {
          totalScanned += queue.length;
          queue.forEach((item: any, idx: number) => {
            if (!item.subagency && !item.tenantId) {
              localAnomalies++;
              scanDetails.push(`Client Queue Item #${idx + 1} (${item.title || 'Draft'}) lacks pod partition tag.`);
            }
          });
        }
      }

      const dealsRaw = safeStorage.getItem('bloom_deals');
      if (dealsRaw) {
        const deals = JSON.parse(dealsRaw);
        if (Array.isArray(deals)) {
          totalScanned += deals.length;
          deals.forEach((d: any, idx: number) => {
            if (!d.tenantId && !d.subagency) {
              localAnomalies++;
              scanDetails.push(`Client Deal #${idx + 1} (${d.title || d.brandName || 'Deal'}) lacks pod partition tag.`);
            }
          });
        }
      }
    } catch (e) {
      console.warn('[TenantIsolationTest] Error scanning client storage:', e);
    }

    setIsRunningIsolationTest(false);

    if (localAnomalies > 0) {
      const resultObj = {
        summary: `Tenant Isolation Check: Flagged ${localAnomalies} un-tagged local records. Server-side pod policies verified.`,
        serverDetails: serverSummary,
        status: 'warning' as const,
        details: scanDetails
      };
      setTestResult(resultObj);
      onAddActivityLog(
        currentUser?.name || 'Security Lead',
        currentRole,
        `⚠️ Tenant Isolation Audit completed with ${localAnomalies} local warning(s).`
      );
      triggerNotification(
        'Tenant Isolation Audit Notice',
        `Validated multi-tenant partitions with ${localAnomalies} client-side metadata flag(s).`,
        'warning'
      );
    } else {
      const resultObj = {
        summary: `PASSED: Multi-tenant partition boundaries and server-side authorization verified. 0 cross-tenant leaks detected.`,
        serverDetails: serverSummary,
        status: 'success' as const,
        details: scanDetails
      };
      setTestResult(resultObj);
      onAddActivityLog(
        currentUser?.name || 'Security Lead',
        currentRole,
        `🛡️ Completed Multi-Tenant Isolation Audit — Server & client partition checks verified.`
      );
      triggerNotification(
        'Tenant Isolation Verified',
        `Server-side and client multi-tenant partition verification passed with 0 leaks detected.`,
        'success'
      );
    }
  };

  const handleSignAgreement = async (agreementKey: string, title: string) => {
    setIsSubmittingSignature(agreementKey);
    try {
      const signerName = currentUser?.name || 'Authorized Agency Lead';
      const signedAt = new Date().toLocaleString();
      const nowIso = new Date().toISOString();
      const payloadToHash = `ENTERPRISE_AGREEMENT:${agreementKey}|SIGNED_BY:${signerName}|ROLE:${currentRole}|DATE:${nowIso}`;
      const hashStr = await computeRealSha256(payloadToHash);

      const recordId = `ent_agmt_${agreementKey}_${currentUser?.id || currentUser?.uid || Date.now()}`;
      
      const serverResult = await persistSignatureRecord({
        id: recordId,
        documentType: `Enterprise Security Agreement (${title})`,
        signerName: signerName,
        signerEmail: currentUser?.email,
        signerRole: currentRole || 'none',
        isoTimestamp: nowIso,
        formattedTimestamp: signedAt,
        digest: hashStr,
        payloadContent: payloadToHash,
        metadata: { agreementKey, title }
      });

      const verifiedDigest = serverResult.digest || hashStr;

      const signatureRecord = {
        signedBy: signerName,
        signedAt: signedAt,
        isoTimestamp: nowIso,
        hash: verifiedDigest
      };

      const updated = { ...signedAgreements, [agreementKey]: signatureRecord };
      setSignedAgreements(updated);
      try {
        safeStorage.setItem('wl_signed_security_agreements', JSON.stringify(updated));
      } catch (e) {}

      onAddActivityLog(
        currentUser?.name || 'Agency Director',
        currentRole,
        `⚖️ Executed enterprise agreement: ${title} [${verifiedDigest}]`
      );

      triggerNotification(
        'Agreement Executed & Recorded',
        `Signed ${title}. Server-verified cryptographic hash logged to security ledger.`,
        'success'
      );
    } catch (err: any) {
      console.error('[EnterpriseSecurity] Agreement signature failure:', err);
      triggerNotification(
        'Execution Failed',
        err.message || 'Failed to record secure digital signature.',
        'danger'
      );
    } finally {
      setIsSubmittingSignature(null);
    }
  };

  const implementedCount = soc2Controls.filter((c: any) => c.status === 'Implemented' || c.status === 'Audited').length;
  const readinessPercentage = Math.round((implementedCount / soc2Controls.length) * 100);

  return (
    <div id="enterprise-security-container" className="min-h-screen bg-[#070D18] text-white p-4 md:p-8 space-y-8 font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div className="space-y-1 text-left">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <ShieldCheck className="w-6 h-6" />
            </span>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
                Security &amp; White-Label Framework
                <span className="text-xs px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-400 font-mono border border-blue-500/30">
                  Compliance Readiness Dashboard
                </span>
              </h1>
              <p className="text-xs text-slate-400">
                Protocols designed for institutional-grade security, RBAC isolation models, and B2B protection frameworks.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            triggerNotification(
              'Information Requested',
              'The Enterprise Security & Compliance Roadmap (Draft) is being prepared for review.',
              'info'
            );
          }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-[#b08e58] text-[#070D18] font-mono font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-lg shadow-[#C9A46A]/10 self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Request Security Documentation</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-white/5 pb-2 overflow-x-auto">
        {[
          { id: 'soc2', label: 'SOC 2 Readiness & CDFI Audit', icon: ShieldCheck },
          { id: 'rbac', label: 'RBAC & Tenant Segregation', icon: Lock },
          { id: 'media-vault', label: 'Encrypted Media Hosting', icon: Server },
          { id: 'white-label-tos', label: 'Legal Review & White-Label Protection', icon: FileText }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-mono font-semibold transition cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-[#C9A46A] text-[#070D18] shadow-md shadow-[#C9A46A]/20'
                  : 'bg-[#0D1830] hover:bg-[#14254A] text-slate-400 hover:text-slate-200 border border-white/5'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: SOC 2 Readiness & CDFI Loan Funding */}
      {activeTab === 'soc2' && (
        <div className="space-y-6 text-left">
          {/* CDFI Loan Security Funding Overview */}
          <div className="bg-gradient-to-r from-[#0E1A2E] via-[#0E1A2E] to-[#122340] border border-blue-950 rounded-3xl p-6 space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30">
                  <Landmark className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider block">
                    Security Investment Roadmap
                  </span>
                  <h3 className="text-lg font-bold text-white">
                    Planned SOC 2 Type II Audit Framework
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-400 font-mono text-xs border border-blue-500/30">
                  Readiness: {readinessPercentage}%
                </span>
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-xs border border-emerald-500/30">
                  {cdfiLoanAllocation.status}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              Enterprise security review is an active operational priority. We are aligning our architecture with SOC 2 Trust Services Criteria to support formal independent CPA examinations through target audit partners like <strong>{cdfiLoanAllocation.auditorPartner}</strong>.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4">
                <span className="text-[10px] font-mono text-slate-400 block mb-1">TOTAL CDFI LOAN</span>
                <span className="text-xl font-bold text-white font-mono">
                  ${cdfiLoanAllocation.totalLoanGranted.toLocaleString()}
                </span>
              </div>

              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4">
                <span className="text-[10px] font-mono text-slate-400 block mb-1">SOC 2 AUDIT ALLOCATION</span>
                <span className="text-xl font-bold text-emerald-400 font-mono">
                  ${cdfiLoanAllocation.soc2AuditFundAllocated.toLocaleString()}
                </span>
              </div>

              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4">
                <span className="text-[10px] font-mono text-slate-400 block mb-1">DISBURSED / ALLOCATED</span>
                <span className="text-xl font-bold text-[#C9A46A] font-mono">
                  ${cdfiLoanAllocation.spentToDate.toLocaleString()} (50%)
                </span>
              </div>
            </div>
          </div>

          {/* SOC 2 Trust Services Criteria Checklist */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                Trust Services Criteria — Internal Self-Assessment &amp; Readiness Tracker
              </h3>
              <span className="text-[11px] font-mono text-slate-400">
                Self-Audit Framework ({implementedCount}/{soc2Controls.length} Controls Implemented)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {soc2Controls.map((ctrl: any) => {
                const isEditing = editingControlId === ctrl.id;
                return (
                  <div
                    key={ctrl.id}
                    className="bg-[#0E1A2E] border border-blue-950 rounded-2xl p-5 space-y-3 hover:border-blue-800/60 transition"
                  >
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-mono font-bold text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.5 rounded border border-[#C9A46A]/20">
                        {ctrl.id}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className={`flex items-center gap-1 text-[11px] font-mono font-bold px-2 py-0.5 rounded border ${
                          ctrl.status === 'Implemented' || ctrl.status === 'Audited'
                            ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
                            : ctrl.status === 'Internal Review'
                            ? 'text-amber-400 bg-amber-500/10 border-amber-500/20'
                            : 'text-blue-400 bg-blue-500/10 border-blue-500/20'
                        }`}>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {ctrl.status}
                        </span>
                        <button
                          onClick={() => {
                            if (isEditing) {
                              setEditingControlId(null);
                            } else {
                              setEditingControlId(ctrl.id);
                              setEditStatus(ctrl.status);
                              setEditEvidence(ctrl.auditEvidence);
                            }
                          }}
                          className="text-slate-400 hover:text-white p-1 rounded hover:bg-white/5 transition"
                          title="Update Control Readiness"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-bold text-white">{ctrl.title}</h4>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">{ctrl.desc}</p>
                    </div>

                    {isEditing ? (
                      <div className="p-3 rounded-xl bg-[#081222] border border-blue-500/30 space-y-2">
                        <label className="block text-[10px] font-mono text-[#C9A46A] uppercase">Update Status:</label>
                        <select
                          value={editStatus}
                          onChange={(e) => setEditStatus(e.target.value)}
                          className="w-full bg-[#0E1A2E] border border-white/10 rounded-lg px-2.5 py-1 text-xs text-white"
                        >
                          <option value="Roadmap">Roadmap</option>
                          <option value="In-Development">In-Development</option>
                          <option value="Internal Review">Internal Review</option>
                          <option value="Implemented">Implemented</option>
                          <option value="Audited">Audited</option>
                        </select>

                        <label className="block text-[10px] font-mono text-[#C9A46A] uppercase mt-2">Readiness Notes &amp; Evidence:</label>
                        <textarea
                          value={editEvidence}
                          onChange={(e) => setEditEvidence(e.target.value)}
                          rows={2}
                          className="w-full bg-[#0E1A2E] border border-white/10 rounded-lg p-2 text-xs text-white placeholder-slate-500"
                        />

                        <button
                          onClick={() => saveControlEdit(ctrl.id)}
                          className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
                        >
                          <Save className="w-3 h-3" /> Save Changes
                        </button>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-[#081222] border border-white/5 text-[11px] font-mono text-slate-300">
                        <span className="text-slate-500 block text-[9px] uppercase">Readiness Notes / Evidence:</span>
                        {ctrl.auditEvidence}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: RBAC & Tenant Segregation */}
      {activeTab === 'rbac' && (
        <div className="space-y-6 text-left">
          <div className="bg-[#0E1A2E] border border-blue-950 rounded-3xl p-6 space-y-4">
            <div className="flex items-center gap-3 border-b border-white/10 pb-4">
              <div className="p-3 rounded-2xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-wider block">
                  Multi-Tenant Sub-Agency Isolation
                </span>
                <h3 className="text-lg font-bold text-white">
                  Role-Based Access Control &amp; Tenant Partition Boundaries
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              When white-labeling the platform for sub-agencies, our backend and database rules enforce strict multi-tenant partition boundaries. Cross-pod access is blocked via server-side verification middleware and role authorization checks.
            </p>

            {/* Live Segregation Test Runner */}
            <div className="p-5 rounded-2xl bg-[#081222] border border-white/5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    Multi-Tenant Isolation &amp; Partition Verifier
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Runs live server-side partition validation across database collections and audits local storage namespaces.
                  </p>
                </div>

                <button
                  onClick={runTenantIsolationTest}
                  disabled={isRunningIsolationTest}
                  className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-mono font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center gap-2 shrink-0"
                >
                  <RefreshCw className={`w-4 h-4 ${isRunningIsolationTest ? 'animate-spin' : ''}`} />
                  <span>{isRunningIsolationTest ? 'Auditing Partitions...' : 'Run Partition Audit'}</span>
                </button>
              </div>

              {testResult && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-4 rounded-xl border font-mono text-xs space-y-2 ${
                    testResult.status === 'success'
                      ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                      : 'bg-amber-950/40 border-amber-500/30 text-amber-300'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{testResult.summary}</span>
                  </div>
                  {testResult.details.map((d, i) => (
                    <div key={i} className="text-[11px] opacity-90 pl-6 border-l border-white/10">
                      • {d}
                    </div>
                  ))}
                </motion.div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Encrypted Media Hosting Vault */}
      {activeTab === 'media-vault' && (
        <div className="space-y-6 text-left">
          <div className="bg-[#0E1A2E] border border-blue-950 rounded-3xl p-6 space-y-4">
            <div className="flex items-center gap-3 border-b border-white/10 pb-4">
              <div className="p-3 rounded-2xl bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30">
                <HardDrive className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-wider block">
                  Media Hosting Infrastructure
                </span>
                <h3 className="text-lg font-bold text-white">
                  Asset Protection Roadmap
                </h3>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Our storage architecture is designed to protect brand drafts and unreleased assets. We are building toward a multi-cloud strategy (Google Cloud &amp; AWS) with integrated envelope encryption to ensure unreleased content remains confidential.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase">AES-256 Framework</span>
                <h4 className="text-xs font-bold text-white">Encryption Roadmap</h4>
                <p className="text-[11px] text-slate-400">Planned integration for automatic encryption of all brand assets before disk write.</p>
              </div>

              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono font-bold text-blue-400 uppercase">Expiring Signed URLs</span>
                <h4 className="text-xs font-bold text-white">15-Minute Token TTL</h4>
                <p className="text-[11px] text-slate-400">Access tokens auto-expire to prevent unauthorized sharing or leakage.</p>
              </div>

              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase">Zero-Scrape Watermarking</span>
                <h4 className="text-xs font-bold text-white">Dynamic IP Stamping</h4>
                <p className="text-[11px] text-slate-400">Dynamic user timestamps watermark preview drafts to deter screen recordings.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: Legal Review & White-Label Protection Contracts */}
      {activeTab === 'white-label-tos' && (
        <div className="space-y-6 text-left">
          {/* Header Description */}
          <div className="bg-[#081222] border border-blue-950 rounded-2xl p-5 space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">B2B SaaS Terms &amp; Non-Solicitation Protection Suite</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Legal review contracts guaranteeing 100% agency source code ownership and anti-poaching NDA protections with electronic signature logging and server-verified SHA-256 audit hashes.
            </p>

            {/* Recipient Notice */}
            <div className="bg-[#070D18] border border-emerald-500/20 rounded-xl p-3 flex items-start gap-2.5 text-xs text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-mono text-[11px] uppercase tracking-wide">Where Do Signed Compliance Records Go?</strong>
                <p className="text-slate-400 text-[11px] mt-0.5">
                  Records are saved directly to your <strong className="text-emerald-400">Internal Agency Compliance Ledger</strong> (Target: <span className="font-mono text-slate-200">{currentUser?.email || currentUser?.name || 'Authenticated Director'}</span>). They are internal policy acknowledgments and are <strong className="text-white">NOT sent or emailed to external third parties</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Master System Controls & Feature Toggles */}
          <div className="bg-[#0E1A2E] border border-blue-900/40 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-[#C9A46A]" />
                <h3 className="text-sm font-bold text-white">System Feature Controls &amp; Enforcement Toggles</h3>
              </div>
              <span className="text-[10px] font-mono text-slate-400 uppercase">Director Master Controls</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Toggle 1: Mandatory Enforcement */}
              <div className="bg-[#081222] border border-white/10 rounded-2xl p-4 space-y-3 flex flex-col justify-between">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Mandatory Clause Gate</span>
                    <button
                      onClick={() => toggleMandatoryEnforcement(!mandatoryEnforcement)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        mandatoryEnforcement ? 'bg-emerald-500' : 'bg-slate-700'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          mandatoryEnforcement ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Require agency staff and brand clients to accept compliance clauses upon login.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-500">Status:</span>
                  <span className={mandatoryEnforcement ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
                    {mandatoryEnforcement ? 'ON (ACTIVE)' : 'OFF (DISABLED)'}
                  </span>
                </div>
              </div>

              {/* Toggle 2: SHA-256 Hashing */}
              <div className="bg-[#081222] border border-white/10 rounded-2xl p-4 space-y-3 flex flex-col justify-between">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">SHA-256 Hashing</span>
                    <button
                      onClick={() => toggleAutomatedHashing(!automatedHashing)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        automatedHashing ? 'bg-blue-500' : 'bg-slate-700'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          automatedHashing ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Generate cryptographic digital signature checksums for executed contracts.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-500">Status:</span>
                  <span className={automatedHashing ? 'text-blue-400 font-bold' : 'text-slate-400'}>
                    {automatedHashing ? 'ON (ACTIVE)' : 'OFF (PLAIN TEXT)'}
                  </span>
                </div>
              </div>

              {/* Toggle 3: Pre-Send Director Review Gate */}
              <div className="bg-[#081222] border border-white/10 rounded-2xl p-4 space-y-3 flex flex-col justify-between">
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">Pre-Send Review Gate</span>
                    <button
                      onClick={() => togglePreSendApprovalGate(!preSendApprovalGate)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        preSendApprovalGate ? 'bg-[#C9A46A]' : 'bg-slate-700'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          preSendApprovalGate ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Require Director preview &amp; approval tag before dispatching any agreement.
                  </p>
                </div>
                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-500">Status:</span>
                  <span className={preSendApprovalGate ? 'text-[#C9A46A] font-bold' : 'text-slate-400'}>
                    {preSendApprovalGate ? 'ON (REVIEW REQ)' : 'OFF (AUTO DISPATCH)'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Module 1: The Non-Circumvention Rule (No Platform Bypassing) */}
          <div className={`bg-[#0E1A2E] border border-blue-950 rounded-3xl p-6 space-y-4 transition ${disabledClauses['non_circumvention_rule'] ? 'opacity-50' : ''}`}>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/10 pb-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold text-rose-400 uppercase">Clause 1 • Anti-Bypassing</span>
                  <span className="text-[10px] font-mono text-slate-500">|</span>
                  <button
                    onClick={() => toggleClauseDisabled('non_circumvention_rule')}
                    className="text-[10px] font-mono underline hover:text-slate-200 cursor-pointer"
                  >
                    Rule Toggle: <strong className={disabledClauses['non_circumvention_rule'] ? 'text-rose-400' : 'text-emerald-400'}>{disabledClauses['non_circumvention_rule'] ? 'OFF' : 'ON'}</strong>
                  </button>
                </div>
                <h3 className="text-base font-bold text-white">The Non-Circumvention Rule (No Platform Bypassing)</h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPreviewClauseModal({
                    key: 'non_circumvention_rule',
                    title: 'The Non-Circumvention Rule (No Platform Bypassing)',
                    clauseNum: 'Clause 1',
                    ruleText: 'Users (Brands and Agencies) are strictly prohibited from bypassing the Platform to contact, negotiate, or book any Creator or Model introduced via the "Match or Pass" dashboard.',
                    penaltyText: 'Any off-platform booking of a talent match within 24 months of initial digital match will result in an immediate platform ban and liquidated damages equal to 30% of total estimated campaign value or $5,000 penalty.',
                    legalSectionText: `§ 1.1 NON-CIRCUMVENTION OBLIGATION: User covenants not to circumvent Licensor by directly or indirectly soliciting or engaging introduced talent outside the Platform.\n§ 1.2 LIQUIDATED DAMAGES: Breach shall incur liquidated damages of 30% or $5,000.00 USD, whichever is greater.`
                  })}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview Target</span>
                </button>

                {signedAgreements['non_circumvention_rule'] ? (
                  <div className="flex items-center gap-2 bg-emerald-950/50 border border-emerald-500/30 px-3 py-2 rounded-xl text-emerald-400 text-xs font-mono">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Executed ({signedAgreements['non_circumvention_rule'].hash.slice(0, 10)}...)</span>
                  </div>
                ) : (
                  <button
                    disabled={isSubmittingSignature === 'non_circumvention_rule' || disabledClauses['non_circumvention_rule']}
                    onClick={() => handleSignAgreement('non_circumvention_rule', 'Non-Circumvention Rule')}
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-xs font-mono font-bold uppercase transition cursor-pointer flex items-center gap-2"
                  >
                    {isSubmittingSignature === 'non_circumvention_rule' ? <RefreshCw className="w-3 h-3 animate-spin" /> : '✍️'}
                    <span>{isSubmittingSignature === 'non_circumvention_rule' ? 'Verifying...' : (automatedHashing ? 'Sign & Hash' : 'Sign Record')}</span>
                  </button>
                )}
              </div>
            </div>

            <div className="bg-[#070D18] border border-rose-500/10 rounded-xl p-2.5 text-[11px] font-mono text-slate-400 flex items-center gap-2">
              <span className="text-rose-400 font-bold uppercase">Destination Target:</span>
              <span>Internal Agency Compliance Vault ({currentUser?.email || currentUser?.name || 'Director'}) — No external email sent.</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-rose-400 uppercase">The Rule</span>
                <p className="text-slate-300">
                  Users (Brands and Agencies) are strictly prohibited from bypassing the Platform to contact, negotiate, or book any Creator or Model introduced via the "Match or Pass" dashboard.
                </p>
              </div>
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase">The Penalty</span>
                <p className="text-slate-300">
                  Any off-platform booking of a talent match within twenty-four (24) months of the initial digital match will result in an immediate platform ban and a liquidated damages fee equal to 30% of the talent's total estimated campaign value or a flat $5,000 penalty, whichever is greater.
                </p>
              </div>
            </div>

            <pre className="p-4 bg-[#081222] border border-white/5 rounded-2xl text-xs text-slate-400 font-mono leading-relaxed whitespace-pre-wrap max-h-32 overflow-y-auto">
{`§ 1.1 NON-CIRCUMVENTION OBLIGATION: During the term of this Agreement and for a period of twenty-four (24) months following any creator introduction via the Platform, User covenants not to circumvent Licensor by directly or indirectly soliciting, engaging, or contracting with introduced talent outside the Platform.
§ 1.2 LIQUIDATED DAMAGES: Breach of § 1.1 shall incur liquidated damages of thirty percent (30%) of the gross campaign contract or $5,000.00 USD, whichever is greater, plus reasonable attorney fees and immediate license termination.`}
            </pre>
          </div>

          {/* Module 2: Automated Matching Logic Protection */}
          <div className={`bg-[#0E1A2E] border border-blue-950 rounded-3xl p-6 space-y-4 transition ${disabledClauses['matching_logic_protection'] ? 'opacity-50' : ''}`}>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/10 pb-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase">Clause 2 • IP &amp; Architecture</span>
                  <span className="text-[10px] font-mono text-slate-500">|</span>
                  <button
                    onClick={() => toggleClauseDisabled('matching_logic_protection')}
                    className="text-[10px] font-mono underline hover:text-slate-200 cursor-pointer"
                  >
                    Rule Toggle: <strong className={disabledClauses['matching_logic_protection'] ? 'text-rose-400' : 'text-emerald-400'}>{disabledClauses['matching_logic_protection'] ? 'OFF' : 'ON'}</strong>
                  </button>
                </div>
                <h3 className="text-base font-bold text-white">Automated Matching Logic &amp; IP Protection</h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPreviewClauseModal({
                    key: 'matching_logic_protection',
                    title: 'Automated Matching Logic & IP Protection',
                    clauseNum: 'Clause 2',
                    ruleText: 'The proprietary user flow, swiping mechanics, and automated talent-matching algorithms utilized within the dashboard are the exclusive intellectual property of Bloom Studio, Inc.',
                    penaltyText: 'Users shall not reverse-engineer, screen-scrape, data-mine, copy, or replicate the user interface, layout, or underlying matching logic.',
                    legalSectionText: `§ 2.1 PROPRIETARY ARCHITECTURE: The matchmaking engine, UI layout, gesture choreography, and database schemas are the sole trade secrets of Bloom Studio, Inc.\n§ 2.2 NO REVERSE ENGINEERING: User shall not decompile or clone any portion of the software.`
                  })}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview Target</span>
                </button>

                {signedAgreements['matching_logic_protection'] ? (
                  <div className="flex items-center gap-2 bg-emerald-950/50 border border-emerald-500/30 px-3 py-2 rounded-xl text-emerald-400 text-xs font-mono">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Executed ({signedAgreements['matching_logic_protection'].hash.slice(0, 10)}...)</span>
                  </div>
                ) : (
                  <button
                    disabled={isSubmittingSignature === 'matching_logic_protection' || disabledClauses['matching_logic_protection']}
                    onClick={() => handleSignAgreement('matching_logic_protection', 'Automated Matching Logic Protection')}
                    className="px-4 py-2 rounded-xl bg-[#C9A46A] hover:bg-[#b08e58] disabled:opacity-50 text-[#070D18] text-xs font-mono font-bold uppercase transition cursor-pointer flex items-center gap-2"
                  >
                    {isSubmittingSignature === 'matching_logic_protection' ? <RefreshCw className="w-3 h-3 animate-spin" /> : '✍️'}
                    <span>{isSubmittingSignature === 'matching_logic_protection' ? 'Verifying...' : (automatedHashing ? 'Sign & Hash' : 'Sign Record')}</span>
                  </button>
                )}
              </div>
            </div>

            <div className="bg-[#070D18] border border-[#C9A46A]/10 rounded-xl p-2.5 text-[11px] font-mono text-slate-400 flex items-center gap-2">
              <span className="text-[#C9A46A] font-bold uppercase">Destination Target:</span>
              <span>Internal Agency Compliance Vault ({currentUser?.email || currentUser?.name || 'Director'}) — No external email sent.</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase">The Rule</span>
                <p className="text-slate-300">
                  The proprietary user flow, swiping mechanics, and automated talent-matching algorithms utilized within the dashboard are the exclusive intellectual property of Bloom Studio, Inc.
                </p>
              </div>
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-blue-400 uppercase">The Restriction</span>
                <p className="text-slate-300">
                  Users shall not reverse-engineer, screen-scrape, data-mine, copy, or replicate the user interface, layout, or underlying matching logic for the purpose of creating a competing platform or database.
                </p>
              </div>
            </div>

            <pre className="p-4 bg-[#081222] border border-white/5 rounded-2xl text-xs text-slate-400 font-mono leading-relaxed whitespace-pre-wrap max-h-32 overflow-y-auto">
{`§ 2.1 PROPRIETARY ARCHITECTURE: The matchmaking engine, UI layout, gesture choreography, and database schemas are the sole trade secrets of Bloom Studio, Inc.
§ 2.2 NO REVERSE ENGINEERING: User shall not decompile, disassemble, screen-scrape, automatedly query, or clone any portion of the software.`}
            </pre>
          </div>

          {/* Module 3: Account Access Security */}
          <div className={`bg-[#0E1A2E] border border-blue-950 rounded-3xl p-6 space-y-4 transition ${disabledClauses['account_access_security'] ? 'opacity-50' : ''}`}>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/10 pb-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold text-blue-400 uppercase">Clause 3 • Credential Integrity</span>
                  <span className="text-[10px] font-mono text-slate-500">|</span>
                  <button
                    onClick={() => toggleClauseDisabled('account_access_security')}
                    className="text-[10px] font-mono underline hover:text-slate-200 cursor-pointer"
                  >
                    Rule Toggle: <strong className={disabledClauses['account_access_security'] ? 'text-rose-400' : 'text-emerald-400'}>{disabledClauses['account_access_security'] ? 'OFF' : 'ON'}</strong>
                  </button>
                </div>
                <h3 className="text-base font-bold text-white">Account Access Security &amp; Anti-Sharing</h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPreviewClauseModal({
                    key: 'account_access_security',
                    title: 'Account Access Security & Anti-Sharing',
                    clauseNum: 'Clause 3',
                    ruleText: 'Account logins cannot be shared with third parties, independent contractors, or external scouts outside the registered organization.',
                    penaltyText: 'Unauthorized credential sharing will result in immediate termination of platform access and permanent revocation of active holds.',
                    legalSectionText: `§ 3.1 CREDENTIAL INTEGRITY: Account access credentials are unique to registered personnel.\n§ 3.2 ACCESS REVOCATION: Sharing logins outside authorized staff voids license rights.`
                  })}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview Target</span>
                </button>

                {signedAgreements['account_access_security'] ? (
                  <div className="flex items-center gap-2 bg-emerald-950/50 border border-emerald-500/30 px-3 py-2 rounded-xl text-emerald-400 text-xs font-mono">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Executed ({signedAgreements['account_access_security'].hash.slice(0, 10)}...)</span>
                  </div>
                ) : (
                  <button
                    disabled={isSubmittingSignature === 'account_access_security' || disabledClauses['account_access_security']}
                    onClick={() => handleSignAgreement('account_access_security', 'Account Access Security Agreement')}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-mono font-bold uppercase transition cursor-pointer flex items-center gap-2"
                  >
                    {isSubmittingSignature === 'account_access_security' ? <RefreshCw className="w-3 h-3 animate-spin" /> : '✍️'}
                    <span>{isSubmittingSignature === 'account_access_security' ? 'Verifying...' : (automatedHashing ? 'Sign & Hash' : 'Sign Record')}</span>
                  </button>
                )}
              </div>
            </div>

            <div className="bg-[#070D18] border border-blue-500/10 rounded-xl p-2.5 text-[11px] font-mono text-slate-400 flex items-center gap-2">
              <span className="text-blue-400 font-bold uppercase">Destination Target:</span>
              <span>Internal Agency Compliance Vault ({currentUser?.email || currentUser?.name || 'Director'}) — No external email sent.</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-blue-400 uppercase">The Rule</span>
                <p className="text-slate-300">
                  Account logins cannot be shared with third parties, independent contractors, or external scouts outside the registered organization.
                </p>
              </div>
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-rose-400 uppercase">The Restriction</span>
                <p className="text-slate-300">
                  Unauthorized credential sharing will result in immediate termination of platform access and permanent revocation of all active talent holds.
                </p>
              </div>
            </div>
          </div>

          {/* Module 4: Direct Messaging and Data Visibility */}
          <div className={`bg-[#0E1A2E] border border-blue-950 rounded-3xl p-6 space-y-4 transition ${disabledClauses['dm_data_visibility'] ? 'opacity-50' : ''}`}>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/10 pb-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase">Clause 4 • Compliance Oversight</span>
                  <span className="text-[10px] font-mono text-slate-500">|</span>
                  <button
                    onClick={() => toggleClauseDisabled('dm_data_visibility')}
                    className="text-[10px] font-mono underline hover:text-slate-200 cursor-pointer"
                  >
                    Rule Toggle: <strong className={disabledClauses['dm_data_visibility'] ? 'text-rose-400' : 'text-emerald-400'}>{disabledClauses['dm_data_visibility'] ? 'OFF' : 'ON'}</strong>
                  </button>
                </div>
                <h3 className="text-base font-bold text-white">Direct Messaging &amp; Master Data Visibility</h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPreviewClauseModal({
                    key: 'dm_data_visibility',
                    title: 'Direct Messaging & Master Data Visibility',
                    clauseNum: 'Clause 4',
                    ruleText: 'All initial campaign communication, casting calls, and content approvals must happen entirely inside the secure dashboard environment.',
                    penaltyText: 'Bloom Studio retains master database oversight to track platform metrics and verify compliance.',
                    legalSectionText: `§ 4.1 IN-PLATFORM COMMUNICATIONS: Campaign negotiations must occur inside the Platform.\n§ 4.2 AUDIT VISIBILITY: Master administrative access retained for safety & invoicing compliance.`
                  })}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview Target</span>
                </button>

                {signedAgreements['dm_data_visibility'] ? (
                  <div className="flex items-center gap-2 bg-emerald-950/50 border border-emerald-500/30 px-3 py-2 rounded-xl text-emerald-400 text-xs font-mono">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Executed ({signedAgreements['dm_data_visibility'].hash.slice(0, 10)}...)</span>
                  </div>
                ) : (
                  <button
                    disabled={isSubmittingSignature === 'dm_data_visibility' || disabledClauses['dm_data_visibility']}
                    onClick={() => handleSignAgreement('dm_data_visibility', 'Direct Messaging and Data Visibility Agreement')}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-mono font-bold uppercase transition cursor-pointer flex items-center gap-2"
                  >
                    {isSubmittingSignature === 'dm_data_visibility' ? <RefreshCw className="w-3 h-3 animate-spin" /> : '✍️'}
                    <span>{isSubmittingSignature === 'dm_data_visibility' ? 'Verifying...' : (automatedHashing ? 'Sign & Hash' : 'Sign Record')}</span>
                  </button>
                )}
              </div>
            </div>

            <div className="bg-[#070D18] border border-emerald-500/10 rounded-xl p-2.5 text-[11px] font-mono text-slate-400 flex items-center gap-2">
              <span className="text-emerald-400 font-bold uppercase">Destination Target:</span>
              <span>Internal Agency Compliance Vault ({currentUser?.email || currentUser?.name || 'Director'}) — No external email sent.</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase">The Rule</span>
                <p className="text-slate-300">
                  All initial campaign communication, casting calls, and content approvals must happen entirely inside the secure dashboard environment.
                </p>
              </div>
              <div className="bg-[#081222] border border-white/5 rounded-xl p-3.5 space-y-1">
                <span className="text-[10px] font-mono font-bold text-purple-400 uppercase">The Disclaimer</span>
                <p className="text-slate-300">
                  Bloom Studio, Inc. retains master administrative database access. We reserve the right to monitor platform data visibility to track user metrics, enforce safety guidelines, and verify invoicing compliance.
                </p>
              </div>
            </div>
          </div>

          {/* Brand Onboarding Gate Simulator & Live Certificate */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-blue-950/40 via-[#0E1A2E] to-blue-950/40 border border-blue-800/40 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="space-y-1">
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                  Interactive Enforcement Gate
                </span>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  Mandatory Brand Onboarding Terms Agreement Gate
                </h4>
                <p className="text-xs text-slate-400 max-w-xl">
                  Enforces that brand clients review and check all 4 mandatory clauses (Non-Circumvention, Proprietary App Architecture, Security &amp; Credentials, Direct Messaging &amp; Audit Visibility) before unlocking dashboard actions.
                </p>
              </div>

              <button
                onClick={() => setBrandTermsModalOpen(true)}
                className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-[#070D18] font-mono font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center gap-2 shrink-0 shadow-lg shadow-emerald-500/20"
              >
                <Eye className="w-4 h-4" />
                <span>Launch Terms Gate</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clause Document & Recipient Preview Modal */}
      {previewClauseModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0B1528] border border-blue-900/60 rounded-3xl max-w-xl w-full p-6 space-y-5 text-left shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-emerald-400" />
                <div>
                  <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase">{previewClauseModal.clauseNum} Preview</span>
                  <h3 className="text-base font-bold text-white">{previewClauseModal.title}</h3>
                </div>
              </div>
              <button
                onClick={() => setPreviewClauseModal(null)}
                className="text-slate-400 hover:text-white font-mono text-sm px-2 py-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-[#070D18] border border-emerald-500/30 rounded-2xl p-4 space-y-1.5">
                <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase block">📩 Destination &amp; Recipient Target</span>
                <p className="text-slate-200 leading-relaxed font-mono">
                  Target Account: <strong>{currentUser?.email || currentUser?.name || 'Director Account'}</strong>
                </p>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Notice: This action creates an internal administrative compliance record stored in the secure Firestore audit vault (<code className="text-emerald-400 font-mono">wl_signed_security_agreements</code>). It is <strong>NOT emailed</strong> to external third parties.
                </p>
              </div>

              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">Core Rule Summary</span>
                <p className="text-slate-300 leading-relaxed">{previewClauseModal.ruleText}</p>
              </div>

              <div className="bg-[#081222] border border-white/5 rounded-2xl p-4 space-y-2">
                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase">Legal Section</span>
                <pre className="text-[11px] text-slate-400 font-mono whitespace-pre-wrap leading-relaxed">
                  {previewClauseModal.legalSectionText}
                </pre>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 border-t border-white/10 pt-4">
              <button
                onClick={() => setPreviewClauseModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition cursor-pointer"
              >
                Close Preview
              </button>
              <button
                onClick={() => {
                  const key = previewClauseModal.key;
                  const title = previewClauseModal.title;
                  setPreviewClauseModal(null);
                  handleSignAgreement(key, title);
                }}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-[#070D18] font-mono font-bold text-xs uppercase transition cursor-pointer flex items-center gap-2"
              >
                <span>Confirm &amp; Sign Record</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Brand Terms Modal */}
      <BrandTermsAgreementModal
        isOpen={brandTermsModalOpen}
        onClose={() => setBrandTermsModalOpen(false)}
        currentUser={currentUser}
        currentRole={currentRole}
        onAgreed={(record) => {
          onAddActivityLog(
            record.signedBy,
            currentRole,
            `⚖️ Electronic Signature Verified: Platform Rules & Non-Circumvention Agreement [${record.hash}]`
          );
          triggerNotification(
            'Terms Acknowledged & Logged',
            `Signed Platform Non-Circumvention Agreement. Hash: ${record.hash}`,
            'success'
          );
        }}
      />
    </div>
  );
}
