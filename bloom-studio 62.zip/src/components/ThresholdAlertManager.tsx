import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  DollarSign, 
  AlertTriangle, 
  TrendingUp, 
  FileCheck2, 
  Zap, 
  ChevronRight, 
  ExternalLink,
  Tag,
  CheckCircle2,
  Lock,
  ArrowUpRight
} from 'lucide-react';
import { Deal, Creator } from '../types';
import { 
  HIGH_VALUE_DEAL_THRESHOLD, 
  isHighValueDeal, 
  parseDealBudget, 
  formatDealBudget,
  createHighValueAlertPayload
} from '../lib/dealThresholdAlert';
import { safeStorage } from '../utils/safeStorage';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface ThresholdAlertManagerProps {
  deals: Deal[];
  setDeals?: React.Dispatch<React.SetStateAction<Deal[]>>;
  creators?: Creator[];
  currentRole: string;
  currentUser?: any;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  onNavigateToDeal?: (dealId: string) => void;
  primaryBrandColor?: string;
}

export default function ThresholdAlertManager({
  deals,
  setDeals,
  creators = [],
  currentRole,
  currentUser,
  onAddActivityLog,
  triggerNotification,
  onNavigateToDeal,
  primaryBrandColor = '#C9A46A'
}: ThresholdAlertManagerProps) {
  const isDirector = ['director', 'agency', 'agentmgr'].includes((currentRole || '').toLowerCase());

  const [acknowledgedIds, setAcknowledgedIds] = useState<Set<string>>(() => {
    try {
      const saved = safeStorage.getItem('wl_acknowledged_deal_alerts');
      return saved ? new Set(JSON.parse(saved)) : new Set<string>();
    } catch {
      return new Set<string>();
    }
  });

  useEffect(() => {
    async function loadRemoteAcks() {
      try {
        const snap = await getDoc(doc(db, 'agency-settings', 'threshold-acknowledgments'));
        if (snap.exists()) {
          const data = snap.data();
          if (Array.isArray(data?.dealIds)) {
            setAcknowledgedIds(prev => {
              const next = new Set([...prev, ...data.dealIds]);
              safeStorage.setItem('wl_acknowledged_deal_alerts', JSON.stringify(Array.from(next)));
              return next;
            });
          }
        }
      } catch (err) {
        console.warn('[ThresholdAlertManager] Error loading remote acks:', err);
      }
    }
    loadRemoteAcks();
  }, []);

  const highValueDeals = deals.filter(d => isHighValueDeal(d.budget ?? (d as any).value));
  const totalHighValueGross = highValueDeals.reduce((sum, d) => sum + parseDealBudget(d.budget ?? (d as any).value), 0);
  const totalHighValueAgencyCut = totalHighValueGross * 0.20;

  const handleAcknowledge = async (deal: Deal) => {
    const dealId = String(deal.id);
    const ackTime = new Date().toISOString();
    const ackBy = currentUser?.name || currentUser?.email || 'Director';

    setAcknowledgedIds(prev => {
      const next = new Set(prev).add(dealId);
      const arr = Array.from(next);
      safeStorage.setItem('wl_acknowledged_deal_alerts', JSON.stringify(arr));
      setDoc(doc(db, 'agency-settings', 'threshold-acknowledgments'), {
        dealIds: arr,
        updatedAt: ackTime,
        updatedBy: ackBy
      }, { merge: true }).catch(err => console.warn('Failed to persist threshold ack:', err));
      return next;
    });

    // Update local state and deals array
    if (setDeals) {
      setDeals((prev: Deal[]) => {
        const updated = prev.map(d => String(d.id) === dealId ? {
          ...d,
          isAcknowledged: true,
          acknowledgedBy: ackBy,
          acknowledgedAt: ackTime
        } : d);
        safeStorage.setItem('wl_deals', JSON.stringify(updated));
        return updated;
      });
    }

    try {
      await setDoc(doc(db, "studio-deals", dealId), {
        ...deal,
        isAcknowledged: true,
        acknowledgedBy: ackBy,
        acknowledgedAt: ackTime,
        subagency: deal.subagency || currentUser?.subagency || 'pod_main',
        tenantId: deal.tenantId || currentUser?.tenantId || 'bloom_studio_default'
      }, { merge: true });
    } catch (err) {
      console.warn("[ThresholdAlertManager] Failed to persist deal acknowledgment to Firestore:", err);
    }

    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'User',
        currentRole,
        `Director executive sign-off completed for $${parseDealBudget(deal.budget).toLocaleString()} contract with ${deal.brand} (${deal.creator})`
      );
    }

    triggerNotification(
      'Executive Sign-Off Recorded',
      `High-value contract with ${deal.brand} ($${parseDealBudget(deal.budget).toLocaleString()}) marked as Director reviewed & approved for contract issuance.`,
      'success'
    );
  };

  const handleSimulateHighValueDeal = () => {
    const sampleBudget = 38500;
    const sampleBrand = 'Red Bull Global';
    const sampleCreator = creators.length > 0 ? (creators[0].name || creators[0].handle) : '@alexjones';
    
    const payload = createHighValueAlertPayload({
      brand: sampleBrand,
      creator: sampleCreator,
      budget: sampleBudget,
      platform: 'TikTok & YouTube Integration',
      stage: 'Negotiating',
      agent: currentUser?.name || 'User'
    });

    triggerNotification(payload.title, payload.detail, 'warning');

    if (onAddActivityLog) {
      onAddActivityLog(
        currentUser?.name || 'User',
        currentRole,
        `💎 HIGH-VALUE THRESHOLD TRIGGERED: Test contract alert executed for ${sampleBrand} ($${sampleBudget.toLocaleString()})`
      );
    }
  };

  return (
    <div className="bg-[#0D1830] border border-[#C9A46A]/20 rounded-2xl p-5 md:p-6 space-y-5 shadow-lg relative overflow-hidden">
      {/* Background ambient accent */}
      <div 
        className="absolute -top-24 -right-24 w-60 h-60 rounded-full blur-3xl pointer-events-none opacity-10"
        style={{ backgroundColor: primaryBrandColor }}
      />

      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 border border-amber-500/30 flex items-center justify-center text-amber-300 shadow-inner">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-serif text-lg font-medium text-white tracking-tight">
                High-Value Contract Threshold Monitor
              </h2>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                $25,000+ Alert Active
              </span>
            </div>
            <p className="text-xs text-[#7C8AA8] mt-0.5">
              Automatically notifies the Director via instant toast notification and mobile push whenever a single deal exceeds $25,000.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleSimulateHighValueDeal}
            className="px-3.5 py-1.5 rounded-xl bg-[#16243F] hover:bg-[#1C2E52] border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs"
            title="Simulate a >$25k deal threshold toast notification"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Test $25k+ Toast</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Counters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-[#7C8AA8] uppercase font-mono tracking-wider">Active $25k+ Deals</div>
            <div className="text-xl font-bold text-white mt-1 flex items-baseline gap-1.5">
              <span>{highValueDeals.length}</span>
              <span className="text-xs text-[#7C8AA8] font-normal font-sans">contracts</span>
            </div>
          </div>
          <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-amber-300">
            <Tag className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-[#7C8AA8] uppercase font-mono tracking-wider">Total Threshold Volume</div>
            <div className="text-xl font-bold text-emerald-400 font-mono mt-1">
              ${totalHighValueGross.toLocaleString()}
            </div>
          </div>
          <div className="w-9 h-9 rounded-lg bg-emerald-950/50 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <TrendingUp className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-[#111E33]/70 border border-white/5 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-[#7C8AA8] uppercase font-mono tracking-wider">Agency 20% Margin Yield</div>
            <div className="text-xl font-bold text-amber-300 font-mono mt-1">
              ${Math.round(totalHighValueAgencyCut).toLocaleString()}
            </div>
          </div>
          <div className="w-9 h-9 rounded-lg bg-amber-950/50 border border-amber-500/20 flex items-center justify-center text-amber-300">
            <DollarSign className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* List of High-Value Deals */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between text-xs text-[#7C8AA8]">
          <span className="font-semibold uppercase text-[10px] tracking-wider text-slate-300">
            Flagged High-Value Contracts in Active Roster
          </span>
          <span className="text-[11px]">
            {highValueDeals.length === 0 ? 'No deals currently meet the $25,000 threshold' : `${highValueDeals.length} contract${highValueDeals.length === 1 ? '' : 's'} registered`}
          </span>
        </div>

        {highValueDeals.length === 0 ? (
          <div className="bg-[#111E33]/40 border border-white/5 border-dashed rounded-xl p-6 text-center text-xs text-[#7C8AA8] space-y-1.5">
            <ShieldCheck className="w-6 h-6 text-[#7C8AA8] mx-auto opacity-70" />
            <div className="text-slate-300 font-medium">No $25,000+ Deals In Flight</div>
            <p className="max-w-md mx-auto text-[11px] leading-relaxed">
              When an agent logs or contracts a campaign with budget exceeding $25,000, the system immediately fires an executive toast notification to the Director and flags it here for legal oversight.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-2.5">
            {highValueDeals.map(deal => {
              const budgetVal = parseDealBudget(deal.budget ?? (deal as any).value);
              const agencyCut = budgetVal * 0.20;
              const talentNet = budgetVal - agencyCut;
              const isAck = !!deal.isAcknowledged || acknowledgedIds.has(String(deal.id));

              return (
                <div 
                  key={deal.id}
                  className={`bg-[#111E33] border rounded-xl p-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3 transition-all ${
                    isAck 
                      ? 'border-emerald-500/20 hover:border-emerald-500/30' 
                      : 'border-amber-500/40 bg-gradient-to-r from-[#111E33] to-[#15233D] shadow-sm'
                  }`}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className={`mt-0.5 p-2 rounded-lg ${isAck ? 'bg-emerald-950/50 text-emerald-400 border border-emerald-500/20' : 'bg-amber-950/80 text-amber-300 border border-amber-500/30'}`}>
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-white text-sm">{deal.brand}</span>
                        <span className="text-xs text-[#7C8AA8]">×</span>
                        <span className="text-xs font-medium text-slate-200">{deal.creator}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-[#16243F] border border-white/10 text-slate-300 font-mono">
                          {deal.platform || 'Multi-platform'}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-950/80 border border-amber-500/40 text-amber-300 font-semibold font-mono">
                          💎 High-Value Tier
                        </span>
                      </div>
                      <div className="text-[11px] text-[#7C8AA8] mt-1 flex items-center gap-3 flex-wrap">
                        <span>Stage: <strong className="text-slate-300">{deal.stage || 'Negotiating'}</strong></span>
                        <span>•</span>
                        <span>Agent: <strong className="text-slate-300">{deal.agent || 'Marcus Cole'}</strong></span>
                        <span>•</span>
                        <span>Agency Cut (20%): <strong className="text-amber-300 font-mono">${Math.round(agencyCut).toLocaleString()}</strong></span>
                        <span>•</span>
                        <span>Creator Net (80%): <strong className="text-emerald-400 font-mono">${Math.round(talentNet).toLocaleString()}</strong></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end md:self-center">
                    <div className="text-right">
                      <div className="text-xs text-[#7C8AA8] uppercase font-mono">Budget</div>
                      <div className="text-base font-bold text-emerald-400 font-mono">
                        ${budgetVal.toLocaleString()}
                      </div>
                    </div>

                    {isAck ? (
                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Director Approved</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleAcknowledge(deal)}
                        className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs"
                      >
                        <FileCheck2 className="w-3.5 h-3.5" />
                        <span>Director Review &amp; Sign-Off</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
