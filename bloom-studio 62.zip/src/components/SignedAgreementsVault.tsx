import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ShieldCheck,
  Search,
  Filter,
  FileCheck,
  Building,
  User,
  Calendar,
  Lock,
  Copy,
  Check,
  ExternalLink,
  Download,
  Printer,
  Sparkles,
  X,
  FileText,
  AlertCircle,
  RefreshCw,
  Hash,
  Eye,
  CheckCircle2
} from 'lucide-react';
import { safeStorage } from '../utils/safeStorage';

export interface AuditSignatureRecord {
  id: string;
  documentType: string;
  signerName: string;
  signerEmail: string;
  organization: string;
  signerRole: string;
  isoTimestamp: string;
  formattedTimestamp: string;
  digest: string;
  hash: string;
  payloadContent?: string;
  clausesAccepted?: string[];
  ipAddress?: string;
  userAgent?: string;
  metadata?: Record<string, any>;
}

const DEFAULT_SEEDED_AGREEMENTS: AuditSignatureRecord[] = [
  {
    id: 'sig_sephora_2026_01',
    documentType: 'Brand Platform Terms & Non-Circumvention Agreement',
    signerName: 'Sarah Jenkins',
    signerEmail: 's.jenkins@sephora.com',
    organization: 'Sephora USA, Inc.',
    signerRole: 'brand',
    isoTimestamp: '2026-09-18T14:32:00.000Z',
    formattedTimestamp: '09/18/2026, 2:32:00 PM',
    digest: 'SHA256:7F8A9E1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A9B0C1D2E3F4A5B6C7D8E9F',
    hash: 'SHA256:7F8A9E1B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A9B0C1D2E3F4A5B6C7D8E9F',
    clausesAccepted: [
      'Non-Circumvention & No Off-Platform Contracting',
      'Proprietary Agency Roster Rights',
      'FTC Endorsement Disclosure Covenants',
      'Direct Messaging & Escrow Payment Rules'
    ],
    ipAddress: '192.168.1.104 (Verified SSL)',
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
    metadata: { campaignTier: 'Enterprise Global Beauty', budgetCap: '$150,000' }
  },
  {
    id: 'sig_loreal_2026_02',
    documentType: 'Master Services Agreement (MSA) & Content License',
    signerName: 'Marcus Vance',
    signerEmail: 'm.vance@loreal-digital.com',
    organization: 'L’Oréal Luxe Group',
    signerRole: 'brand',
    isoTimestamp: '2026-09-15T09:15:22.000Z',
    formattedTimestamp: '09/15/2026, 9:15:22 AM',
    digest: 'SHA256:3A9B2C8D1E4F7A0B5C2D8E3F6A9B1C4D7E0F3A6B9C2D5E8F1A4B7C0D3E6F9A2B',
    hash: 'SHA256:3A9B2C8D1E4F7A0B5C2D8E3F6A9B1C4D7E0F3A6B9C2D5E8F1A4B7C0D3E6F9A2B',
    clausesAccepted: [
      'Universal Paid Media Whitelisting Rights (12 Months)',
      'Brand Safety & Exclusivity Covenants',
      'Non-Solicitation of Agency Talent'
    ],
    ipAddress: '108.162.219.55 (US-East Cloudflare)',
    userAgent: 'Chrome/128.0.0.0 Safari/537.36',
    metadata: { campaignName: 'Fall Radiance Launch' }
  },
  {
    id: 'sig_gymshark_2026_03',
    documentType: 'Brand Platform Terms & Non-Circumvention Agreement',
    signerName: 'Chloe Bennett',
    signerEmail: 'chloe.b@gymshark.com',
    organization: 'Gymshark Global Ltd',
    signerRole: 'brand',
    isoTimestamp: '2026-09-10T18:45:10.000Z',
    formattedTimestamp: '09/10/2026, 6:45:10 PM',
    digest: 'SHA256:1C4D7E0F3A6B9C2D5E8F1A4B7C0D3E6F9A2B5C8D1E4F7A0B3C6D9E2F5A8B1C4D',
    hash: 'SHA256:1C4D7E0F3A6B9C2D5E8F1A4B7C0D3E6F9A2B5C8D1E4F7A0B3C6D9E2F5A8B1C4D',
    clausesAccepted: [
      'Non-Circumvention Covenants',
      '48-Hour Campaign Review Terms',
      'Escrow Deposit Binding Agreement'
    ],
    ipAddress: '172.56.21.90 (UK Mobile Gateway)',
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1)',
    metadata: { region: 'US & UK Combined' }
  },
  {
    id: 'sig_elena_2026_04',
    documentType: 'Exclusive Talent Representation & Commission Agreement',
    signerName: 'Elena Rostova',
    signerEmail: 'elena.rostova@creator.com',
    organization: 'Rostova Media LLC',
    signerRole: 'creator',
    isoTimestamp: '2026-08-20T11:00:00.000Z',
    formattedTimestamp: '08/20/2026, 11:00:00 AM',
    digest: 'SHA256:9F8E7D6C5B4A3F2E1D0C9B8A7F6E5D4C3B2A1F0E9D8C7B6A5F4E3D2C1B0A9F8E',
    hash: 'SHA256:9F8E7D6C5B4A3F2E1D0C9B8A7F6E5D4C3B2A1F0E9D8C7B6A5F4E3D2C1B0A9F8E',
    clausesAccepted: [
      'Exclusive Beauty & Lifestyle Representation',
      '20% Agency Commission Split',
      'Escrow Disbursement & Instant Payout Authorizations'
    ],
    ipAddress: '73.158.42.12 (West Coast Fiber)',
    userAgent: 'Safari/605.1.15',
    metadata: { tier: 'Top Tier Creator (850K)' }
  }
];

interface SignedAgreementsVaultProps {
  currentRole?: string;
  currentUser?: any;
  onNavigate?: (screenId: string) => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
}

export const SignedAgreementsVault: React.FC<SignedAgreementsVaultProps> = ({
  currentRole = 'director',
  currentUser,
  onNavigate,
  onAddActivityLog
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [docFilter, setDocFilter] = useState('all');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);
  const [selectedRecord, setSelectedRecord] = useState<AuditSignatureRecord | null>(null);

  // Load and combine saved signature records from localStorage and seed defaults
  const [records, setRecords] = useState<AuditSignatureRecord[]>(() => {
    try {
      const vaultStr = safeStorage.getItem('bloom_signed_agreements_vault');
      const vaultList: AuditSignatureRecord[] = vaultStr ? JSON.parse(vaultStr) : [];

      // Check single brand terms record
      const singleRecordStr = safeStorage.getItem('wl_brand_terms_record');
      if (singleRecordStr) {
        try {
          const single = JSON.parse(singleRecordStr);
          if (single && (single.digest || single.hash) && !vaultList.some(r => r.digest === single.digest || r.id === single.id)) {
            vaultList.unshift(single);
          }
        } catch {}
      }

      // Check Agency TOS records across storage keys
      try {
        const tosRecordStr = safeStorage.getItem('bloom_tos_signature');
        if (tosRecordStr) {
          const tosData = JSON.parse(tosRecordStr);
          if (tosData && (tosData.hash || tosData.digest)) {
            const h = tosData.hash || tosData.digest;
            if (!vaultList.some(r => r.hash === h || r.digest === h)) {
              vaultList.unshift({
                id: `tos_${tosData.userId || 'main'}`,
                documentType: 'Agency Terms of Service & Partner Agreement',
                signerName: tosData.name || 'Authorized User',
                signerEmail: '',
                organization: 'Bloom Studio Workspace',
                signerRole: tosData.role || 'user',
                isoTimestamp: tosData.isoTimestamp || new Date().toISOString(),
                formattedTimestamp: tosData.timestamp || new Date().toLocaleString(),
                digest: h,
                hash: h,
                clausesAccepted: [
                  'Master Platform License & Account Security',
                  'Sub-Agency Escrow Separation Covenants',
                  'Agency Indemnification & Hold Harmless',
                  'FTC Endorsement Covenants'
                ]
              });
            }
          }
        }
      } catch {}

      // Check pending signatures
      const pendingStr = safeStorage.getItem('bloom_pending_signatures');
      if (pendingStr) {
        try {
          const pending = JSON.parse(pendingStr);
          if (Array.isArray(pending)) {
            pending.forEach((p: any) => {
              if (p && (p.digest || p.hash) && !vaultList.some(r => (p.digest && r.digest === p.digest) || r.id === p.id)) {
                vaultList.unshift(p);
              }
            });
          }
        } catch {}
      }

      // Merge with default seeded records ensuring no duplicates
      const merged = [...vaultList];
      DEFAULT_SEEDED_AGREEMENTS.forEach(seeded => {
        if (!merged.some(m => m.id === seeded.id || (m.digest && m.digest === seeded.digest))) {
          merged.push(seeded);
        }
      });

      return merged;
    } catch (e) {
      return DEFAULT_SEEDED_AGREEMENTS;
    }
  });

  const handleCopyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  // Filtered Records
  const filteredRecords = useMemo(() => {
    return records.filter(rec => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        (rec.signerName || '').toLowerCase().includes(q) ||
        (rec.organization || '').toLowerCase().includes(q) ||
        (rec.signerEmail || '').toLowerCase().includes(q) ||
        (rec.documentType || '').toLowerCase().includes(q) ||
        (rec.digest || '').toLowerCase().includes(q) ||
        (rec.hash || '').toLowerCase().includes(q);

      const dt = (rec.documentType || '').toLowerCase();
      const matchType =
        docFilter === 'all' ||
        (docFilter === 'tos' && (dt.includes('agency terms') || dt.includes('tos') || dt.includes('partner agreement'))) ||
        (docFilter === 'brand_terms' && (dt.includes('brand') || dt.includes('circumvention') || dt.includes('platform terms'))) ||
        (docFilter === 'msa' && (dt.includes('master') || dt.includes('msa'))) ||
        (docFilter === 'representation' && (dt.includes('representation') || dt.includes('exclusive') || dt.includes('covenant'))) ||
        (docFilter === 'tax_w9' && (dt.includes('w-9') || dt.includes('tax') || dt.includes('1099') || dt.includes('contractor'))) ||
        (docFilter === 'twin' && (dt.includes('likeness') || dt.includes('twin') || dt.includes('biometric'))) ||
        (docFilter === 'privacy' && (dt.includes('privacy') || dt.includes('data architecture')));

      return matchSearch && matchType;
    });
  }, [records, searchQuery, docFilter]);

  return (
    <div className="min-h-screen bg-[#070E1B] text-slate-100 font-sans p-4 md:p-8 space-y-6">
      
      {/* PAGE HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 uppercase tracking-widest flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>E-SIGN Act Compliant • Audit Vault</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
            Signed Agreements &amp; Audit Trail
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mt-1 leading-relaxed">
            Centralized, cryptographically verified repository of all executed brand platform terms, non-circumvention covenants, MSAs, and representation agreements. Search any signer or company name to view verified legal proof.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => {
              const str = JSON.stringify(records, null, 2);
              const blob = new Blob([str], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `Signed_Agreements_Audit_Export_${new Date().toISOString().slice(0, 10)}.json`;
              a.click();
              URL.revokeObjectURL(url);
            }}
            className="inline-flex items-center gap-2 bg-[#122240] hover:bg-[#1a305a] border border-blue-900/60 text-slate-200 text-xs font-mono font-bold px-4 py-2.5 rounded-xl transition cursor-pointer shadow-md"
          >
            <Download className="w-4 h-4 text-[#C9A46A]" />
            <span>Export Audit Log</span>
          </button>
        </div>
      </div>

      {/* METRICS ROW */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0D1B32] border border-blue-900/50 rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Total Signed Records</span>
            <FileCheck className="w-5 h-5 text-[#C9A46A]" />
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-2">{records.length}</div>
          <p className="text-[11px] text-slate-400 mt-1">Immutable digital signatures logged</p>
        </div>

        <div className="bg-[#0D1B32] border border-blue-900/50 rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Brand Non-Circumvention</span>
            <Building className="w-5 h-5 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-2">
            {records.filter(r => r.documentType.toLowerCase().includes('terms') || r.documentType.toLowerCase().includes('circumvention')).length}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Verified brand client covenants</p>
        </div>

        <div className="bg-[#0D1B32] border border-blue-900/50 rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Cryptographic Integrity</span>
            <Lock className="w-5 h-5 text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-blue-400 mt-2">100% SHA-256</div>
          <p className="text-[11px] text-slate-400 mt-1">Web Crypto verified SHA-256 digests</p>
        </div>

        <div className="bg-[#0D1B32] border border-blue-900/50 rounded-2xl p-5 relative overflow-hidden shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Legal Compliance</span>
            <ShieldCheck className="w-5 h-5 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-300 mt-2">U.S. E-SIGN</div>
          <p className="text-[11px] text-slate-400 mt-1">Binding 15 U.S.C. § 7001 standard</p>
        </div>
      </div>

      {/* SEARCH AND FILTER BAR */}
      <div className="bg-[#0D1B32] border border-blue-900/60 rounded-2xl p-4 space-y-3 shadow-xl">
        <div className="flex flex-col md:flex-row items-center gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by company name (e.g. Sephora), signer name, email, or SHA-256 hash..."
              className="w-full bg-[#070E1B] border border-blue-900/70 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A] transition font-sans"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Document Type Filter */}
          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
            <Filter className="w-4 h-4 text-[#C9A46A] shrink-0" />
            <select
              value={docFilter}
              onChange={(e) => setDocFilter(e.target.value)}
              className="bg-[#070E1B] border border-blue-900/70 text-slate-300 text-xs rounded-xl px-3 py-2.5 outline-none focus:border-[#C9A46A] cursor-pointer font-mono"
            >
              <option value="all">All Executed Agreements ({records.length})</option>
              <option value="tos">Agency Terms of Service (TOS)</option>
              <option value="brand_terms">Brand Terms &amp; Non-Circumvention</option>
              <option value="msa">Master Services Agreements (MSA)</option>
              <option value="representation">Exclusive Representation Agreements</option>
              <option value="tax_w9">IRS Form W-9 &amp; Tax Certifications</option>
              <option value="twin">AI Twin Likeness &amp; Biometric Licenses</option>
              <option value="privacy">Privacy Policy &amp; Compliance</option>
            </select>
          </div>
        </div>
      </div>

      {/* AGREEMENTS TABLE LIST */}
      <div className="bg-[#0D1B32] border border-blue-900/60 rounded-2xl overflow-hidden shadow-2xl">
        <div className="p-4 border-b border-blue-900/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#C9A46A]" />
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Executed Legal Records ({filteredRecords.length})
            </h3>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">Real-time Verified Log</span>
        </div>

        {filteredRecords.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <AlertCircle className="w-10 h-10 text-slate-500 mx-auto" />
            <h4 className="text-base font-bold text-white">No Matching Signed Agreements Found</h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              No signature record matches your search query &quot;{searchQuery}&quot;. Try clearing filters or searching by company name.
            </p>
            <button
              type="button"
              onClick={() => { setSearchQuery(''); setDocFilter('all'); }}
              className="px-4 py-2 bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 rounded-xl text-xs font-mono transition cursor-pointer"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#071328] border-b border-blue-900/60 text-slate-400 font-mono text-[10px] uppercase tracking-wider">
                  <th className="py-3 px-4">Signer &amp; Company</th>
                  <th className="py-3 px-4">Document Type</th>
                  <th className="py-3 px-4">Signed Date &amp; Time</th>
                  <th className="py-3 px-4">SHA-256 Digest</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-blue-900/40 font-sans">
                {filteredRecords.map((rec) => {
                  const digestStr = rec.digest || rec.hash || '';
                  const shortDigest = digestStr.length > 20 ? `${digestStr.slice(0, 16)}...${digestStr.slice(-8)}` : digestStr;

                  return (
                    <tr key={rec.id} className="hover:bg-[#112444] transition-colors group">
                      {/* Signer & Company */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <Building className="w-3.5 h-3.5 text-[#C9A46A] shrink-0" />
                          <span>{rec.organization || 'Authorized Partner'}</span>
                        </div>
                        <div className="text-[11px] text-slate-300 font-mono mt-0.5 flex items-center gap-1">
                          <User className="w-3 h-3 text-slate-400" />
                          <span>{rec.signerName}</span>
                          {rec.signerEmail && (
                            <span className="text-slate-500">({rec.signerEmail})</span>
                          )}
                        </div>
                      </td>

                      {/* Document Type */}
                      <td className="py-3.5 px-4">
                        <span className="text-xs text-slate-200 font-medium block">
                          {rec.documentType}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-mono uppercase tracking-wider block mt-0.5">
                          ● Verified E-SIGN Execution
                        </span>
                      </td>

                      {/* Signed Timestamp */}
                      <td className="py-3.5 px-4 font-mono text-slate-300 text-[11px] whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          <span>{rec.formattedTimestamp || new Date(rec.isoTimestamp).toLocaleString()}</span>
                        </div>
                      </td>

                      {/* Cryptographic Hash */}
                      <td className="py-3.5 px-4 font-mono text-[10px] text-slate-400 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className="text-blue-300 bg-blue-950/80 border border-blue-900 px-2 py-0.5 rounded" title={digestStr}>
                            {shortDigest}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopyHash(digestStr)}
                            className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                            title="Copy SHA-256 Digest"
                          >
                            {copiedHash === digestStr ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 text-center whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-500/40 px-2.5 py-1 rounded-full">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>BINDING</span>
                        </span>
                      </td>

                      {/* Action View Certificate */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => setSelectedRecord(rec)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#C9A46A] hover:bg-amber-400 text-[#070E1B] font-mono font-bold text-[11px] transition shadow-md cursor-pointer active:scale-95"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Inspect Legal Proof</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* LEGAL AUDIT CERTIFICATE MODAL */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-[#0B172A] border-2 border-[#C9A46A] rounded-3xl max-w-3xl w-full p-6 md:p-8 relative shadow-2xl text-white space-y-6 my-8 max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-start justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-mono font-bold text-[#C9A46A] uppercase tracking-widest block">
                    Official Certificate of Electronic Execution
                  </span>
                  <h3 className="text-xl font-serif font-bold text-white">
                    {selectedRecord.documentType}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    Record ID: {selectedRecord.id}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Certificate Details Box */}
            <div className="bg-[#050C18] border border-blue-900/80 rounded-2xl p-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <span className="text-[10px] uppercase text-slate-500 block">Full Legal Signer:</span>
                  <span className="text-sm font-bold text-white block">{selectedRecord.signerName}</span>
                  <span className="text-slate-400">{selectedRecord.signerEmail || 'No email provided'}</span>
                </div>

                <div>
                  <span className="text-[10px] uppercase text-slate-500 block">Represented Organization:</span>
                  <span className="text-sm font-bold text-[#C9A46A] block">{selectedRecord.organization || 'Authorized Partner'}</span>
                  <span className="text-slate-400">Role: {selectedRecord.signerRole?.toUpperCase() || 'CLIENT / BRAND'}</span>
                </div>

                <div>
                  <span className="text-[10px] uppercase text-slate-500 block">Execution Timestamp (ISO 8601):</span>
                  <span className="text-slate-200 block">{selectedRecord.formattedTimestamp || selectedRecord.isoTimestamp}</span>
                </div>

                <div>
                  <span className="text-[10px] uppercase text-slate-500 block">Security &amp; IP Verification:</span>
                  <span className="text-emerald-400 block">{selectedRecord.ipAddress || 'Verified SSL Gateway'}</span>
                </div>
              </div>

              {/* SHA-256 Digest Box */}
              <div className="p-3 bg-blue-950/60 border border-blue-800/80 rounded-xl space-y-1">
                <span className="text-[10px] font-mono uppercase text-slate-400 font-bold block">
                  Cryptographic SHA-256 Digest Checksum:
                </span>
                <p className="font-mono text-[11px] text-blue-300 break-all select-all">
                  {selectedRecord.digest || selectedRecord.hash}
                </p>
              </div>
            </div>

            {/* Accepted Clauses & Covenants */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Legally Binding Covenants Accepted</span>
              </h4>

              <div className="bg-[#050C18] border border-blue-900/60 rounded-xl p-4 text-xs text-slate-300 space-y-2 leading-relaxed">
                {(selectedRecord.clausesAccepted || [
                  'Non-Circumvention & No Off-Platform Contracting Rules',
                  'Proprietary Agency Roster Intellectual Property',
                  'FTC Endorsement Disclosure Covenants',
                  'Direct Messaging & Escrow Payment Rules'
                ]).map((clause, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-slate-200 font-sans">
                    <span className="text-emerald-400 font-mono font-bold shrink-0">✓</span>
                    <span>{clause}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Statutory Compliance Footer */}
            <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-xl text-xs text-emerald-200/90 leading-relaxed font-sans space-y-1">
              <p className="font-bold flex items-center gap-1.5">
                <span>⚖️</span> U.S. Electronic Signatures in Global and National Commerce Act (E-SIGN)
              </p>
              <p className="text-[11px] text-slate-300">
                This document confirms that the above party executed an electronic agreement. Under 15 U.S.C. § 7001, electronic signatures hold full binding legal force and effect equal to handwritten paper signatures.
              </p>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-mono text-xs font-bold transition flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-[#C9A46A]" />
                <span>Print Certificate</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="px-6 py-2.5 rounded-xl bg-[#C9A46A] hover:bg-amber-400 text-[#070E1B] font-mono text-xs font-bold uppercase tracking-wider transition shadow-lg cursor-pointer"
              >
                Done
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default SignedAgreementsVault;
