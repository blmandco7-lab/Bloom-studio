import React, { useState } from 'react';
import { Receipt, ShieldCheck, DollarSign, Clock, Layers } from 'lucide-react';
import GlobalPayrollSchedule, { GlobalPayrollCampaign } from './GlobalPayrollSchedule';
import { UserProfileWithRole } from './ManagerCommissionLog';

interface UnifiedPayrollEscrowHubProps {
  currentUser: UserProfileWithRole;
  onDisburseFunds?: (campaignId: string) => Promise<void> | void;
  initialCampaigns?: GlobalPayrollCampaign[];
  defaultTab?: 'payroll' | 'escrow';
}

export const UnifiedPayrollEscrowHub: React.FC<UnifiedPayrollEscrowHubProps> = ({
  currentUser,
  onDisburseFunds,
  initialCampaigns,
  defaultTab = 'payroll'
}) => {
  const [activeTab, setActiveTab] = useState<'payroll' | 'escrow'>(defaultTab);

  const primaryBrandColor = '#C9A46A';
  const cardBgColor = '#0D1830';

  return (
    <div className="space-y-6 animate-fade-in" id="unifiedPayrollEscrowHub">
      {/* Top Banner & Hub Header */}
      <div 
        className="rounded-2xl p-6 border shadow-2xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6"
        style={{
          backgroundColor: cardBgColor,
          borderColor: `${primaryBrandColor}30`
        }}
      >
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold px-2.5 py-1 rounded-full border text-[#C9A46A] border-[#C9A46A]/30 bg-[#C9A46A]/10 flex items-center gap-1.5">
              <Receipt className="w-3 h-3" />
              Treasury &amp; Financial Clearing
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
              Secure Ledger &amp; Disbursal Hub
            </span>
          </div>

          <h1 className="text-2xl lg:text-3xl font-serif font-bold text-white tracking-tight flex items-center gap-3">
            <ShieldCheck className="w-7 h-7 text-[#C9A46A]" />
            <span>Global Payroll &amp; Creator Escrow Settlement Hub</span>
          </h1>

          <p className="text-xs text-slate-300 leading-relaxed">
            Manage staff payroll schedules, review brand escrow deposits, and execute secure fund disbursals for campaign completions with real-time audit logging.
          </p>
        </div>

        {/* Master Tab Selector */}
        <div className="flex flex-col sm:flex-row items-center gap-2.5 shrink-0 bg-[#070D18] p-1.5 rounded-2xl border border-white/10 shadow-inner">
          <button
            type="button"
            id="tabBtnPayroll"
            onClick={() => setActiveTab('payroll')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeTab === 'payroll'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Global Payroll (Staff)</span>
          </button>

          <button
            type="button"
            id="tabBtnEscrow"
            onClick={() => setActiveTab('escrow')}
            className={`flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer w-full sm:w-auto ${
              activeTab === 'escrow'
                ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg font-extrabold'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Escrow Settlement (Creators)</span>
          </button>
        </div>
      </div>

      {/* Active Tab Component */}
      <div className="transition-all">
        <GlobalPayrollSchedule
          currentUser={currentUser}
          onDisburseFunds={onDisburseFunds}
          initialCampaigns={initialCampaigns}
          mode={activeTab}
        />
      </div>
    </div>
  );
};

export default UnifiedPayrollEscrowHub;
