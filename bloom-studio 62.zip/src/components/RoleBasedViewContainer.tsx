import React from 'react';
import { Truck, Video, CheckSquare, FileText, Award, Users, AlertTriangle } from 'lucide-react';

export type UserTier = 'Director' | 'AgentManager' | 'Agent' | 'Coordinator';

export interface RoleBasedUser {
  uid: string;
  name: string;
  email: string;
  role: UserTier;
  reportsToUserId?: string;
  compensation?: {
    campaignSplitPercentage?: number;
    flatRatePerCampaign?: number;
    hourlyRate?: number;
  };
}

interface RoleBasedViewContainerProps {
  user: RoleBasedUser;
  // Coordinator Views
  logisticsShippingSection?: React.ReactNode;
  rawUgcDropZoneSection?: React.ReactNode;
  taskChecklistSection?: React.ReactNode;
  
  // Agent Views
  creatorContractReviewSection?: React.ReactNode;
  individualCommissionBadgeSection?: React.ReactNode;
  
  // Agent Manager Views
  teamSubordinateOverviewSection?: React.ReactNode;
  subordinatePayrollListSection?: React.ReactNode;
  
  // Director / Executive Views
  directorExecutiveLedgerSection?: React.ReactNode;
  
  // General / Shared
  children?: React.ReactNode;
}

/**
 * RoleBasedViewContainer:
 * Defensive frontend permission and partitioning layout.
 * 
 * Strict Masking Controls:
 * 1. Coordinator:
 *    - Unmounts all financials, brand revenue summaries, contract payouts.
 *    - Only renders interactive shipping tracker, raw UGC dropzones, and task checklists.
 * 2. Agent:
 *    - Renders creator contract review panel and individual commission badge.
 *    - Masks macro team tracking and peers' payroll logs.
 * 3. Agent Manager:
 *    - Renders progress and payroll for subordinate Agents & Coordinators.
 *    - Masks top-level Gross Brand Deals and Agency Retained Profits.
 * 4. Director:
 *    - Full executive access to macro master ledgers and corporate overrides.
 */
export default function RoleBasedViewContainer({
  user,
  logisticsShippingSection,
  rawUgcDropZoneSection,
  taskChecklistSection,
  creatorContractReviewSection,
  individualCommissionBadgeSection,
  teamSubordinateOverviewSection,
  subordinatePayrollListSection,
  directorExecutiveLedgerSection,
  children
}: RoleBasedViewContainerProps) {
  return (
    <div className="bg-agency-navy min-h-screen text-agency-textLight p-4 md:p-8 space-y-8">
      {/* Tier Identification Banner */}
      <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-agency-navy border border-agency-gold/30 flex items-center justify-center font-mono font-bold text-agency-gold text-sm">
            {user.role.substring(0, 2).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-sm">{user.name}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-agency-gold/15 text-agency-gold border border-agency-gold/30 font-bold uppercase">
                {user.role} Tier
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono">{user.email}</span>
          </div>
        </div>

        <div className="text-right text-xs font-mono text-slate-400">
          {user.reportsToUserId && (
            <span>Reporting Line: <strong className="text-slate-200">{user.reportsToUserId}</strong></span>
          )}
        </div>
      </div>

      {/* TIER 1: COORDINATOR CANVAS (Logistics & Production Only) */}
      {user.role === 'Coordinator' && (
        <div className="space-y-6">
          <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-4.5 flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Truck className="w-4 h-4 text-agency-gold" /> Logistics &amp; Physical Seeding Workbench
            </span>
            <span className="text-[11px] font-mono text-slate-400 bg-agency-navy px-2.5 py-1 rounded-lg border border-white/5">
              Financial Modules Masked (Zero-Exposure)
            </span>
          </div>

          {logisticsShippingSection && (
            <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl">
              {logisticsShippingSection}
            </div>
          )}

          {rawUgcDropZoneSection && (
            <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl">
              {rawUgcDropZoneSection}
            </div>
          )}

          {taskChecklistSection && (
            <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl">
              {taskChecklistSection}
            </div>
          )}
        </div>
      )}

      {/* TIER 2: AGENT CANVAS (Talent Contract & Individual Commission Only) */}
      {user.role === 'Agent' && (
        <div className="space-y-6">
          <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-4.5 flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-agency-gold" /> Creator Contract &amp; Personal Talent Deliverables
            </span>
            <span className="text-[11px] font-mono text-slate-400 bg-agency-navy px-2.5 py-1 rounded-lg border border-white/5">
              Personal Commission View Active
            </span>
          </div>

          {individualCommissionBadgeSection && (
            <div>
              {individualCommissionBadgeSection}
            </div>
          )}

          {creatorContractReviewSection && (
            <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl">
              {creatorContractReviewSection}
            </div>
          )}
        </div>
      )}

      {/* TIER 3: AGENT MANAGER CANVAS (Subordinate Team Progress & Staff Payroll) */}
      {user.role === 'AgentManager' && (
        <div className="space-y-6">
          <div className="bg-agency-navyLight border border-white/10 rounded-2xl p-4.5 flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-agency-gold uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-agency-gold" /> Pod Operations &amp; Direct Report Tracking
            </span>
            <span className="text-[11px] font-mono text-slate-400 bg-agency-navy px-2.5 py-1 rounded-lg border border-white/5">
              Executive Brand Margins Masked
            </span>
          </div>

          {teamSubordinateOverviewSection && (
            <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl">
              {teamSubordinateOverviewSection}
            </div>
          )}

          {subordinatePayrollListSection && (
            <div className="bg-agency-navyLight border border-white/10 rounded-3xl p-6 shadow-xl">
              {subordinatePayrollListSection}
            </div>
          )}
        </div>
      )}

      {/* TIER 4: DIRECTOR / OWNER CANVAS (Full Executive Access) */}
      {user.role === 'Director' && (
        <div className="space-y-6">
          <div className="bg-agency-navyLight border border-agency-gold/30 rounded-2xl p-4.5 flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-agency-gold uppercase tracking-wider flex items-center gap-2">
              <Award className="w-4 h-4 text-agency-gold" /> Master Executive Control &amp; Corporate Ledger
            </span>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-lg">
              Full Financial Clearance
            </span>
          </div>

          {directorExecutiveLedgerSection && (
            <div>
              {directorExecutiveLedgerSection}
            </div>
          )}
        </div>
      )}

      {/* Shared Children Components */}
      {children && (
        <div className="space-y-6">
          {children}
        </div>
      )}
    </div>
  );
}
