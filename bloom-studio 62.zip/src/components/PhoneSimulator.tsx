/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Smartphone, Wifi, Battery, Bell, Send, CheckCircle2, AlertTriangle, ShieldCheck, 
  MessageSquare, User, Users, Shield, ArrowRight, Check
} from 'lucide-react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface SimulatedNotification {
  id: string;
  title: string;
  body: string;
  app: string;
  time: string;
  type: 'success' | 'warning' | 'info' | 'danger';
}

interface PhoneSimulatorProps {
  notifications: SimulatedNotification[];
  onTriggerNotification: (title: string, body: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  currentRole?: string;
  currentUser?: any;
  userProfile?: any;
  creators?: any[];
  staff?: any[];
}

export default function PhoneSimulator({ 
  notifications, 
  onTriggerNotification, 
  currentRole,
  currentUser,
  userProfile,
  creators = [],
  staff = []
}: PhoneSimulatorProps) {
  const [activeTab, setActiveTab] = useState<'preview' | 'opt-in' | 'sender'>('preview');
  const [phoneNumber, setPhoneNumber] = useState(userProfile?.phone || '');
  const [smsConsent, setSmsConsent] = useState(userProfile?.smsConsent || false);
  const [isSaving, setIsSaving] = useState(false);
  const [phoneTime, setPhoneTime] = useState('11:07 AM');
  
  // Sender state
  const [recipientType, setRecipientType] = useState<'individual' | 'creators' | 'staff'>('individual');
  const [selectedRecipientId, setSelectedRecipientId] = useState('');
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [isSending, setIsSending] = useState(false);

  const isDirector = (currentRole || '').toLowerCase() === 'director';
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const canSend = isDirector || isAgentMgr;

  useEffect(() => {
    if (userProfile?.phone) setPhoneNumber(userProfile.phone);
    if (userProfile?.smsConsent !== undefined) setSmsConsent(userProfile.smsConsent);
  }, [userProfile]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let h = now.getHours();
      const m = now.getMinutes();
      const ampm = h >= 12 ? 'PM' : 'AM';
      h = h % 12;
      h = h ? h : 12;
      const mStr = m < 10 ? '0' + m : m;
      setPhoneTime(`${h}:${mStr} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleSaveConsent = async () => {
    if (!currentUser?.uid) return;
    setIsSaving(true);
    try {
      const collectionName = (currentRole === 'creator') ? 'studio-creators' : 'studio-users';
      const userRef = doc(db, collectionName, currentUser.uid);
      await updateDoc(userRef, {
        phone: phoneNumber,
        smsConsent: smsConsent,
        updatedAt: new Date().toISOString()
      });
      onTriggerNotification(
        "SMS Preferences Updated",
        smsConsent 
          ? "✓ You have successfully opted in to SMS notifications." 
          : "✗ You have opted out of SMS notifications.",
        "success"
      );
    } catch (err) {
      console.error("Error saving SMS consent:", err);
      onTriggerNotification("Error", "Failed to update SMS preferences.", "danger");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSendBroadcast = async () => {
    if (!broadcastMsg.trim()) return;
    setIsSending(true);
    try {
      const response = await fetch('/api/send-sms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: recipientType === 'individual' ? selectedRecipientId : recipientType,
          message: broadcastMsg,
          recipientType: recipientType === 'individual' ? undefined : recipientType
        })
      });
      
      const result = await response.json();
      if (result.success) {
        onTriggerNotification(
          "Broadcast Sent",
          `Successfully dispatched SMS to ${recipientType === 'individual' ? 'recipient' : 'all ' + recipientType}.`,
          "success"
        );
        setBroadcastMsg('');
      } else {
        throw new Error(result.error);
      }
    } catch (err: any) {
      onTriggerNotification("Broadcast Error", err.message || "Failed to send SMS.", "danger");
    } finally {
      setIsSending(false);
    }
  };

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'danger': return <AlertTriangle className="w-4 h-4 text-rose-500" />;
      default: return <Bell className="w-4 h-4 text-[#C9A46A]" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 border-b border-white/5 pb-4 overflow-x-auto scrollbar-none">
        <button 
          onClick={() => setActiveTab('preview')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${activeTab === 'preview' ? 'bg-[#C9A46A] text-[#0A1220]' : 'bg-white/5 text-slate-400 hover:bg-white/10'}`}
        >
          <Smartphone className="w-3.5 h-3.5" /> Device Preview
        </button>
        <button 
          onClick={() => setActiveTab('opt-in')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${activeTab === 'opt-in' ? 'bg-[#C9A46A] text-[#0A1220]' : 'bg-white/5 text-slate-400 hover:bg-white/10'}`}
        >
          <ShieldCheck className="w-3.5 h-3.5" /> My Opt-In Status
        </button>
        {canSend && (
          <button 
            onClick={() => setActiveTab('sender')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${activeTab === 'sender' ? 'bg-[#C9A46A] text-[#0A1220]' : 'bg-white/5 text-slate-400 hover:bg-white/10'}`}
          >
            <Send className="w-3.5 h-3.5" /> SMS Broadcast Center
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Mobile Phone Simulation (Always Visible or Large) */}
        <div className="lg:col-span-5 flex justify-center">
          <div className="relative w-[300px] h-[600px] bg-slate-950 border-[8px] border-slate-800 rounded-[40px] shadow-2xl flex flex-col justify-between overflow-hidden ring-4 ring-slate-900/50">
            {/* Speaker & Notch */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-800 rounded-b-2xl z-30 flex items-center justify-center">
              <div className="w-12 h-1 bg-slate-950 rounded-full"></div>
            </div>

            {/* Screen Top Bar */}
            <div className="px-5 pt-7 pb-2 flex justify-between items-center text-[10px] text-slate-400 font-medium font-sans z-20 bg-slate-950/40 backdrop-blur-sm">
              <span>{phoneTime}</span>
              <div className="flex items-center gap-1.5">
                <Wifi className="w-3.5 h-3.5" />
                <span>5G</span>
                <Battery className="w-4 h-4 text-emerald-500" />
              </div>
            </div>

            {/* Screen Content: Lock Screen */}
            <div className="flex-1 px-4 py-3 flex flex-col justify-start space-y-4 overflow-y-auto max-h-[460px] relative z-10 scrollbar-none">
              {/* Lock Screen Time */}
              <div className="text-center py-6">
                <h2 className="text-4xl font-light text-white tracking-wide">
                  {phoneTime.split(' ')[0]}
                </h2>
                <p className="text-[10px] font-semibold tracking-wider text-[#C9A46A] uppercase mt-1">
                  Thursday, July 16
                </p>
              </div>

              {/* Notification Stack */}
              <div className="space-y-2.5">
                {notifications.length === 0 ? (
                  <div className="bg-white/5 border border-white/5 backdrop-blur-md rounded-2xl p-4 text-center space-y-1">
                    <p className="text-[11px] font-semibold text-white">No notifications</p>
                    <p className="text-[9px] text-slate-400 leading-relaxed">
                      Active agency alerts, brand inquiries, and mass broadcasts will pop up here.
                    </p>
                  </div>
                ) : (
                  notifications.slice().reverse().map(n => (
                    <div 
                      key={n.id} 
                      className="bg-white/5 hover:bg-white/10 border border-white/5 backdrop-blur-md rounded-2xl p-3 shadow-md flex gap-2.5 items-start animate-fade-in transition-all"
                    >
                      <div className="p-1.5 bg-[#16243F]/80 rounded-lg">
                        {getNotifIcon(n.type)}
                      </div>
                      <div className="flex-1 min-width-0 text-left">
                        <div className="flex justify-between items-center gap-1.5">
                          <span className="text-[9px] font-bold uppercase tracking-wider text-[#C9A46A]">
                            {n.app}
                          </span>
                          <span className="text-[8px] text-slate-400 font-mono">{n.time}</span>
                        </div>
                        <h4 className="text-[11px] font-bold text-white mt-0.5 leading-tight truncate">
                          {n.title}
                        </h4>
                        <p className="text-[10px] text-slate-300 mt-1 leading-normal break-words">
                          {n.body}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Screen Bottom bar / Home swipe bar */}
            <div className="pb-3 pt-2 bg-slate-950/40 backdrop-blur-sm flex justify-center z-20">
              <div className="w-28 h-1 bg-white/40 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Right Side: Tabbed Content */}
        <div className="lg:col-span-7 space-y-6">
          {activeTab === 'preview' && (
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-5">
              <div className="space-y-1">
                <h3 className="text-lg font-serif font-semibold text-white">Live Device Preview</h3>
                <p className="text-xs text-slate-400">Observe how SMS and push notifications appear on your mobile device in real-time.</p>
              </div>
              
              <div className="p-4 bg-[#111E33] rounded-xl border border-white/5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <Wifi className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">Connection: Bloom-Secure-Net</span>
                    <span className="text-[10px] text-slate-500 uppercase font-mono">Status: Latency 24ms</span>
                  </div>
                </div>
                <div className="text-[11px] text-slate-300 leading-relaxed">
                  This simulator mirrors the exact lockscreen experience of a creator or staff member receiving a Bloom Studio alert. When you trigger actions elsewhere in the agency, they route here instantly.
                </div>
              </div>

              {isDirector && (
                <div className="space-y-3 pt-4 border-t border-white/5">
                  <span className="text-[10px] font-bold text-[#C9A46A] uppercase tracking-wider">Director Sandbox Triggers</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => onTriggerNotification("New Brand Inquiry", "SportZone submitted an inquiry with $10K budget.", "success")}
                      className="p-3 bg-[#111E33] hover:bg-[#16243F] border border-white/5 text-left rounded-xl transition-all"
                    >
                      <span className="text-[11px] font-bold text-white block">Brand Inquiry</span>
                      <span className="text-[9px] text-slate-500">Mock landing page lead</span>
                    </button>
                    <button 
                      onClick={() => onTriggerNotification("FTC Violation Flag", "@creator draft held: Missing required #ad hashtag.", "warning")}
                      className="p-3 bg-[#111E33] hover:bg-[#16243F] border border-white/5 text-left rounded-xl transition-all"
                    >
                      <span className="text-[11px] font-bold text-white block">Compliance Alert</span>
                      <span className="text-[9px] text-slate-500">AI Safety Bot trigger</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'opt-in' && (
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6">
              <div className="space-y-1">
                <h3 className="text-lg font-serif font-semibold text-white">SMS Notification Preferences</h3>
                <p className="text-xs text-slate-400">Manage your phone number and legal consent for automated SMS alerts.</p>
              </div>

              <div className="p-5 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 shrink-0">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-white">TCPA Compliance & Consent</h4>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      To receive SMS notifications, you must explicitly provide your mobile number and agree to our terms. 
                      You can revoke this consent at any time by unchecking the box below or replying <strong>STOP</strong> to any message.
                    </p>
                  </div>
                </div>

                <div className="space-y-4 pt-2">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Mobile Phone Number</label>
                    <div className="relative">
                      <Smartphone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <input 
                        type="tel"
                        placeholder="+1 (555) 000-0000"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full bg-[#0A1220] border border-white/10 rounded-xl py-3 pl-10 pr-4 text-sm text-white focus:border-[#C9A46A] outline-none transition-all"
                      />
                    </div>
                  </div>

                  <label className="flex items-start gap-3 p-4 bg-black/20 border border-white/5 rounded-xl cursor-pointer group hover:bg-black/30 transition-all">
                    <div className="relative flex items-center h-5">
                      <input 
                        type="checkbox"
                        checked={smsConsent}
                        onChange={(e) => setSmsConsent(e.target.checked)}
                        className="peer h-5 w-5 rounded border-white/10 bg-white/5 text-[#C9A46A] focus:ring-[#C9A46A] cursor-pointer"
                      />
                    </div>
                    <div className="text-[11px] text-slate-300 leading-snug">
                      I agree to receive SMS notifications from Bloom Studio. Message and data rates may apply. Reply STOP to opt out.
                    </div>
                  </label>

                  <button 
                    onClick={handleSaveConsent}
                    disabled={isSaving || !phoneNumber}
                    className={`w-full py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                      isSaving ? 'bg-slate-700 text-slate-400 cursor-wait' : 'bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] shadow-lg hover:-translate-y-0.5'
                    }`}
                  >
                    {isSaving ? <ArrowRight className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                    {isSaving ? 'Updating Registry...' : 'Save Preferences & Sync'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'sender' && (
            <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-6 space-y-6">
              <div className="space-y-1">
                <h3 className="text-lg font-serif font-semibold text-white">SMS Broadcast Center</h3>
                <p className="text-xs text-slate-400">Dispatch legal, operational, or emergency SMS alerts to your roster.</p>
              </div>

              <div className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button 
                    onClick={() => setRecipientType('individual')}
                    className={`p-3 rounded-xl border text-left transition-all ${recipientType === 'individual' ? 'bg-[#C9A46A]/10 border-[#C9A46A] text-[#C9A46A]' : 'bg-[#111E33] border-white/5 text-slate-400'}`}
                  >
                    <User className="w-4 h-4 mb-2" />
                    <span className="text-[11px] font-bold block">Individual</span>
                    <span className="text-[9px] opacity-70">Single recipient</span>
                  </button>
                  <button 
                    onClick={() => setRecipientType('creators')}
                    className={`p-3 rounded-xl border text-left transition-all ${recipientType === 'creators' ? 'bg-purple-500/10 border-purple-500 text-purple-400' : 'bg-[#111E33] border-white/5 text-slate-400'}`}
                  >
                    <Users className="w-4 h-4 mb-2" />
                    <span className="text-[11px] font-bold block">All Creators</span>
                    <span className="text-[9px] opacity-70">Mass broadcast</span>
                  </button>
                  <button 
                    onClick={() => setRecipientType('staff')}
                    className={`p-3 rounded-xl border text-left transition-all ${recipientType === 'staff' ? 'bg-sky-500/10 border-sky-500 text-sky-400' : 'bg-[#111E33] border-white/5 text-slate-400'}`}
                  >
                    <Shield className="w-4 h-4 mb-2" />
                    <span className="text-[11px] font-bold block">All Staff</span>
                    <span className="text-[9px] opacity-70">Internal alert</span>
                  </button>
                </div>

                {recipientType === 'individual' && (
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Select Recipient</label>
                    <select 
                      value={selectedRecipientId}
                      onChange={(e) => setSelectedRecipientId(e.target.value)}
                      className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white focus:border-[#C9A46A] outline-none"
                    >
                      <option value="">Select a creator or staff member...</option>
                      <optgroup label="Creators">
                        {creators.map(c => (
                          <option key={c.id} value={c.id}>{c.name || c.handle}</option>
                        ))}
                      </optgroup>
                      <optgroup label="Staff">
                        {staff.map(s => (
                          <option key={s.id} value={s.id}>{s.name || s.email}</option>
                        ))}
                      </optgroup>
                    </select>
                  </div>
                )}

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Message Content</label>
                    <span className="text-[10px] text-slate-500">{broadcastMsg.length}/160</span>
                  </div>
                  <textarea 
                    placeholder="Type your SMS message here..."
                    value={broadcastMsg}
                    onChange={(e) => setBroadcastMsg(e.target.value.slice(0, 160))}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl p-4 text-sm text-white focus:border-[#C9A46A] outline-none h-32 resize-none"
                  />
                  <div className="flex items-center gap-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                    <p className="text-[9px] text-amber-200 leading-tight">
                      <strong>Audit Warning:</strong> This message will be logged in the agency audit trail. 
                      SMS will only be delivered to recipients with active <strong>smsConsent</strong>.
                    </p>
                  </div>
                </div>

                <button 
                  onClick={handleSendBroadcast}
                  disabled={isSending || !broadcastMsg.trim() || (recipientType === 'individual' && !selectedRecipientId)}
                  className={`w-full py-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                    isSending ? 'bg-slate-700 text-slate-400 cursor-wait' : 'bg-white text-[#0A1220] hover:bg-slate-200 shadow-xl'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  {isSending ? 'Dispatching SMS...' : 'Send SMS Broadcast'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

