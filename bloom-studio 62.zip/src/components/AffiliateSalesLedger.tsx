import React, { useState, useMemo } from 'react';
import { 
  DollarSign, TrendingUp, Link2, ShoppingBag, Percent, ArrowUpRight, 
  ExternalLink, Copy, Check, Filter, Search, Download, RefreshCw, 
  Building2, Globe, Shield, Sparkles, Plus, CheckCircle2, ChevronRight,
  Layers, Lock, Sliders, BarChart3, AlertCircle
} from 'lucide-react';
import { Creator, AffiliateTransaction, AffiliateTrackingLink } from '../types';

interface AffiliateSalesLedgerProps {
  creators: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

const INITIAL_LINKS: AffiliateTrackingLink[] = [
  {
    id: 'link-001',
    creatorId: 'c1',
    creatorName: 'Elena Rostova',
    creatorHandle: '@elenarostova',
    brandName: 'DripRoom Beauty',
    campaignTitle: 'Silk Velvet Lip Stain Launch',
    customUrl: 'bloom.studio/shop/elena-silk',
    discountCode: 'ELENA20',
    discountRate: '20% OFF',
    commissionRateCreator: 15, // 15% of gross
    agencyBrandSplitAgencyPercent: 80,
    agencyBrandSplitBrandPercent: 20,
    tenantId: 'agency_bloom_ny',
    status: 'active',
    totalClicks: 4820,
    totalConversions: 342,
    grossSalesGenerated: 24650.00
  },
  {
    id: 'link-002',
    creatorId: 'c2',
    creatorName: 'Marcus Vance',
    creatorHandle: '@marcusvance',
    brandName: 'GymPulse Apparel',
    campaignTitle: 'Core Compression Fall Drop',
    customUrl: 'bloom.studio/shop/marcus-core',
    discountCode: 'MARCUS15',
    discountRate: '15% OFF',
    commissionRateCreator: 12,
    agencyBrandSplitAgencyPercent: 80,
    agencyBrandSplitBrandPercent: 20,
    tenantId: 'agency_bloom_ny',
    status: 'active',
    totalClicks: 3190,
    totalConversions: 215,
    grossSalesGenerated: 18420.00
  },
  {
    id: 'link-003',
    creatorId: 'c3',
    creatorName: 'Chloe Bennett',
    creatorHandle: '@chloebennett',
    brandName: 'GlowBar Botanicals',
    campaignTitle: 'Matcha Clarifying Toner',
    customUrl: 'bloom.studio/shop/chloe-glow',
    discountCode: 'CHLOE25',
    discountRate: '25% OFF',
    commissionRateCreator: 18,
    agencyBrandSplitAgencyPercent: 80,
    agencyBrandSplitBrandPercent: 20,
    tenantId: 'agency_pod_west',
    status: 'active',
    totalClicks: 6240,
    totalConversions: 512,
    grossSalesGenerated: 39800.00
  }
];

const INITIAL_TRANSACTIONS: AffiliateTransaction[] = [
  {
    id: 'tx-881',
    orderId: 'ORD-SHP-99214',
    storefront: 'Shopify',
    timestamp: '2026-08-31 09:14',
    brandName: 'DripRoom Beauty',
    creatorId: 'c1',
    creatorHandle: '@elenarostova',
    creatorName: 'Elena Rostova',
    discountCodeUsed: 'ELENA20',
    trackingLinkUrl: 'bloom.studio/shop/elena-silk',
    customerCity: 'New York, NY',
    itemsCount: 3,
    grossAmount: 180.00,
    agencyGrossSplit: 144.00, // 80%
    brandGrossSplit: 36.00,   // 20%
    creatorCommissionAmount: 27.00, // 15%
    tenantId: 'agency_bloom_ny',
    status: 'settled'
  },
  {
    id: 'tx-882',
    orderId: 'ORD-TTS-44109',
    storefront: 'TikTok Shop',
    timestamp: '2026-08-31 08:45',
    brandName: 'GlowBar Botanicals',
    creatorId: 'c3',
    creatorName: 'Chloe Bennett',
    creatorHandle: '@chloebennett',
    discountCodeUsed: 'CHLOE25',
    trackingLinkUrl: 'bloom.studio/shop/chloe-glow',
    customerCity: 'Austin, TX',
    itemsCount: 2,
    grossAmount: 95.00,
    agencyGrossSplit: 76.00,
    brandGrossSplit: 19.00,
    creatorCommissionAmount: 17.10,
    tenantId: 'agency_pod_west',
    status: 'settled'
  },
  {
    id: 'tx-883',
    orderId: 'ORD-AMZ-77312',
    storefront: 'Amazon Storefront',
    timestamp: '2026-08-30 22:18',
    brandName: 'GymPulse Apparel',
    creatorId: 'c2',
    creatorName: 'Marcus Vance',
    creatorHandle: '@marcusvance',
    discountCodeUsed: 'MARCUS15',
    trackingLinkUrl: 'bloom.studio/shop/marcus-core',
    customerCity: 'Miami, FL',
    itemsCount: 4,
    grossAmount: 240.00,
    agencyGrossSplit: 192.00,
    brandGrossSplit: 48.00,
    creatorCommissionAmount: 28.80,
    tenantId: 'agency_bloom_ny',
    status: 'settled'
  },
  {
    id: 'tx-884',
    orderId: 'ORD-SHP-99215',
    storefront: 'Shopify',
    timestamp: '2026-08-30 19:30',
    brandName: 'DripRoom Beauty',
    creatorId: 'c1',
    creatorHandle: '@elenarostova',
    creatorName: 'Elena Rostova',
    discountCodeUsed: 'ELENA20',
    trackingLinkUrl: 'bloom.studio/shop/elena-silk',
    customerCity: 'Los Angeles, CA',
    itemsCount: 1,
    grossAmount: 65.00,
    agencyGrossSplit: 52.00,
    brandGrossSplit: 13.00,
    creatorCommissionAmount: 9.75,
    tenantId: 'agency_bloom_ny',
    status: 'settled'
  }
];

export const AffiliateSalesLedger: React.FC<AffiliateSalesLedgerProps> = ({
  creators,
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}) => {
  const isCreator = currentRole.toLowerCase() === 'creator';
  const isDirector = currentRole.toLowerCase() === 'director' || currentRole.toLowerCase() === 'owner';
  const currentCreatorHandle = currentUser?.handle || '@elenarostova';

  const [tenantFilter, setTenantFilter] = useState<'all' | 'agency_bloom_ny' | 'agency_pod_west'>('all');
  const [storefrontFilter, setStorefrontFilter] = useState<'all' | 'Shopify' | 'TikTok Shop' | 'Amazon Storefront' | 'WooCommerce'>('all');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  
  const [links, setLinks] = useState<AffiliateTrackingLink[]>(INITIAL_LINKS);
  const [transactions, setTransactions] = useState<AffiliateTransaction[]>(INITIAL_TRANSACTIONS);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Link State
  const [newBrandName, setNewBrandName] = useState('');
  const [newCampaignTitle, setNewCampaignTitle] = useState('');
  const [newCustomSlug, setNewCustomSlug] = useState('');
  const [newDiscountCode, setNewDiscountCode] = useState('');
  const [newDiscountRate, setNewDiscountRate] = useState('20% OFF');
  const [newCreatorCommission, setNewCreatorCommission] = useState(15);

  // Filter links and transactions based on Creator Isolation Rule:
  const filteredLinks = useMemo(() => {
    return links.filter(link => {
      if (isCreator && link.creatorHandle.toLowerCase() !== currentCreatorHandle.toLowerCase()) {
        return false;
      }
      if (tenantFilter !== 'all' && link.tenantId !== tenantFilter) {
        return false;
      }
      return true;
    });
  }, [links, isCreator, currentCreatorHandle, tenantFilter]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(tx => {
      if (isCreator && tx.creatorHandle.toLowerCase() !== currentCreatorHandle.toLowerCase()) {
        return false;
      }
      if (tenantFilter !== 'all' && tx.tenantId !== tenantFilter) {
        return false;
      }
      if (storefrontFilter !== 'all' && tx.storefront !== storefrontFilter) {
        return false;
      }
      return true;
    });
  }, [transactions, isCreator, currentCreatorHandle, tenantFilter, storefrontFilter]);

  // Aggregate Metrics
  const aggregateMetrics = useMemo(() => {
    const totalGmv = filteredTransactions.reduce((acc, curr) => acc + curr.grossAmount, 0);
    const totalAgencyShare = filteredTransactions.reduce((acc, curr) => acc + curr.agencyGrossSplit, 0);
    const totalBrandShare = filteredTransactions.reduce((acc, curr) => acc + curr.brandGrossSplit, 0);
    const totalCreatorCommission = filteredTransactions.reduce((acc, curr) => acc + curr.creatorCommissionAmount, 0);

    return {
      totalGmv,
      totalAgencyShare,
      totalBrandShare,
      totalCreatorCommission,
      totalOrders: filteredTransactions.length
    };
  }, [filteredTransactions]);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    triggerNotification?.('Copied to Clipboard', `Promo code ${code} copied.`, 'success');
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Simulate Background Storefront Webhook Inbound Order
  const handleTriggerSimulatedWebhook = (storefront: 'Shopify' | 'TikTok Shop' | 'Amazon Storefront') => {
    const targetLink = filteredLinks[0] || links[0];
    const orderNum = Math.floor(10000 + Math.random() * 90000);
    const gross = parseFloat((80 + Math.random() * 220).toFixed(2));
    const agencySplit = parseFloat((gross * 0.80).toFixed(2));
    const brandSplit = parseFloat((gross * 0.20).toFixed(2));
    const creatorCut = parseFloat((gross * (targetLink.commissionRateCreator / 100)).toFixed(2));

    const newTx: AffiliateTransaction = {
      id: `tx-${Date.now().toString().slice(-4)}`,
      orderId: `ORD-${storefront.slice(0, 3).toUpperCase()}-${orderNum}`,
      storefront,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      brandName: targetLink.brandName,
      creatorId: targetLink.creatorId,
      creatorHandle: targetLink.creatorHandle,
      creatorName: targetLink.creatorName,
      discountCodeUsed: targetLink.discountCode,
      trackingLinkUrl: targetLink.customUrl,
      customerCity: 'Seattle, WA',
      itemsCount: Math.floor(1 + Math.random() * 4),
      grossAmount: gross,
      agencyGrossSplit: agencySplit,
      brandGrossSplit: brandSplit,
      creatorCommissionAmount: creatorCut,
      tenantId: targetLink.tenantId || 'agency_bloom_ny',
      status: 'settled'
    };

    setTransactions(prev => [newTx, ...prev]);

    triggerNotification?.(
      `⚡ Webhook Received: ${storefront}`,
      `Order ${newTx.orderId} processed ($${gross.toFixed(2)}). 80/20 split calculated.`,
      'success'
    );

    onAddActivityLog?.(
      'Storefront Webhook Listener',
      'system',
      `Inbound ${storefront} Order #${newTx.orderId}: $${gross.toFixed(2)} via code ${newTx.discountCodeUsed}`
    );
  };

  const handleCreateLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBrandName || !newDiscountCode) return;

    const newLink: AffiliateTrackingLink = {
      id: `link-${Date.now().toString().slice(-4)}`,
      creatorId: 'c1',
      creatorName: isCreator ? (currentUser?.name || 'Alex Jones') : 'Elena Rostova',
      creatorHandle: isCreator ? currentCreatorHandle : '@elenarostova',
      brandName: newBrandName,
      campaignTitle: newCampaignTitle || `${newBrandName} Campaign`,
      customUrl: `bloom.studio/shop/${newCustomSlug || newDiscountCode.toLowerCase()}`,
      discountCode: newDiscountCode.toUpperCase(),
      discountRate: newDiscountRate,
      commissionRateCreator: newCreatorCommission,
      agencyBrandSplitAgencyPercent: 80,
      agencyBrandSplitBrandPercent: 20,
      tenantId: tenantFilter !== 'all' ? tenantFilter : 'agency_bloom_ny',
      status: 'active',
      totalClicks: 0,
      totalConversions: 0,
      grossSalesGenerated: 0
    };

    setLinks(prev => [newLink, ...prev]);
    setShowCreateModal(false);

    triggerNotification?.(
      'Tracking Link Created',
      `Custom link ${newLink.customUrl} with code ${newLink.discountCode} is now active.`,
      'success'
    );

    onAddActivityLog?.(
      currentUser?.name || 'User',
      currentRole,
      `Generated new affiliate tracking campaign for ${newLink.brandName} (${newLink.discountCode})`
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-[#0E1C38] via-[#142850] to-[#0A162B] border border-[#D4AF37]/20 rounded-3xl p-6 shadow-2xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#D4AF37]/10 rounded-xl text-[#D4AF37]">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white tracking-wide">
              Affiliate Sales Performance Ledgers
            </h1>
          </div>
          <p className="text-xs text-[#B8C0D4] max-w-2xl">
            {isCreator 
              ? 'Private creator affiliate view. Real-time commission earnings calculated from your custom discount codes and storefront links.'
              : 'Multi-tenant sales hub connecting client storefronts via background webhooks. Enforces 80/20 agency-to-brand splits while isolating creator earnings.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Simulated Webhook Trigger Buttons */}
          <button
            onClick={() => handleTriggerSimulatedWebhook('Shopify')}
            className="px-3.5 py-2.5 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/10 hover:border-emerald-500/40 text-white rounded-xl text-xs font-mono transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>+ Webhook (Shopify)</span>
          </button>
          <button
            onClick={() => handleTriggerSimulatedWebhook('TikTok Shop')}
            className="px-3.5 py-2.5 bg-[#0B1B3D] hover:bg-[#1A3260] border border-white/10 hover:border-rose-500/40 text-white rounded-xl text-xs font-mono transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-rose-400" />
            <span>+ Webhook (TikTok Shop)</span>
          </button>

          {!isCreator && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-4 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] font-bold rounded-xl text-xs transition-all shadow-lg flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Create Tracking Campaign</span>
            </button>
          )}
        </div>
      </div>

      {/* Multi-Tenant & Filter Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#142850] border border-white/5 rounded-2xl p-4 shadow-xl">
        <div className="flex flex-wrap items-center gap-3">
          {!isCreator && (
            <div className="flex items-center gap-2 bg-[#0B1B3D] px-3 py-1.5 rounded-xl border border-white/10">
              <Building2 className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs text-slate-400 font-mono">Tenant Pod:</span>
              <select
                value={tenantFilter}
                onChange={(e) => setTenantFilter(e.target.value as any)}
                className="bg-transparent text-xs font-bold text-white outline-none cursor-pointer"
              >
                <option value="all" className="bg-[#0B1B3D]">All Network Pods</option>
                <option value="agency_bloom_ny" className="bg-[#0B1B3D]">Bloom Studio NY (Main)</option>
                <option value="agency_pod_west" className="bg-[#0B1B3D]">Pod West (Sub-Agency)</option>
              </select>
            </div>
          )}

          <div className="flex items-center gap-2 bg-[#0B1B3D] px-3 py-1.5 rounded-xl border border-white/10">
            <ShoppingBag className="w-4 h-4 text-cyan-400" />
            <span className="text-xs text-slate-400 font-mono">Storefront:</span>
            <select
              value={storefrontFilter}
              onChange={(e) => setStorefrontFilter(e.target.value as any)}
              className="bg-transparent text-xs font-bold text-white outline-none cursor-pointer"
            >
              <option value="all" className="bg-[#0B1B3D]">All Storefronts</option>
              <option value="Shopify" className="bg-[#0B1B3D]">Shopify</option>
              <option value="TikTok Shop" className="bg-[#0B1B3D]">TikTok Shop</option>
              <option value="Amazon Storefront" className="bg-[#0B1B3D]">Amazon Storefront</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span>Role Isolation: {isCreator ? 'Private View Active' : 'Master Multi-Tenant'}</span>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Total GMV */}
        <div className="bg-[#142850] border border-white/5 rounded-2xl p-5 space-y-2 shadow-xl">
          <span className="text-[10px] uppercase font-mono text-slate-400 tracking-wider">Gross Sales (GMV)</span>
          <p className="text-2xl font-bold font-mono text-white">
            ${aggregateMetrics.totalGmv.toFixed(2)}
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>{aggregateMetrics.totalOrders} total orders</span>
            <span className="text-emerald-400 font-semibold">+18.4% WoW</span>
          </div>
        </div>

        {/* Metric 2: Agency 80% Cut (or Creator Cut if creator role) */}
        {!isCreator ? (
          <div className="bg-[#142850] border border-white/5 rounded-2xl p-5 space-y-2 shadow-xl">
            <span className="text-[10px] uppercase font-mono text-[#D4AF37] tracking-wider">Agency Split (80% Pool)</span>
            <p className="text-2xl font-bold font-mono text-[#D4AF37]">
              ${aggregateMetrics.totalAgencyShare.toFixed(2)}
            </p>
            <p className="text-[11px] text-slate-400">Automated 80/20 brand contract split</p>
          </div>
        ) : (
          <div className="bg-[#142850] border border-white/5 rounded-2xl p-5 space-y-2 shadow-xl">
            <span className="text-[10px] uppercase font-mono text-emerald-400 tracking-wider">My Earned Commission</span>
            <p className="text-2xl font-bold font-mono text-emerald-400">
              ${aggregateMetrics.totalCreatorCommission.toFixed(2)}
            </p>
            <p className="text-[11px] text-slate-400">Isolated to your private creator wallet</p>
          </div>
        )}

        {/* Metric 3: Brand 20% Cut */}
        {!isCreator ? (
          <div className="bg-[#142850] border border-white/5 rounded-2xl p-5 space-y-2 shadow-xl">
            <span className="text-[10px] uppercase font-mono text-cyan-400 tracking-wider">Brand Retained (20% Pool)</span>
            <p className="text-2xl font-bold font-mono text-cyan-400">
              ${aggregateMetrics.totalBrandShare.toFixed(2)}
            </p>
            <p className="text-[11px] text-slate-400">Direct client brand retention</p>
          </div>
        ) : (
          <div className="bg-[#142850] border border-white/5 rounded-2xl p-5 space-y-2 shadow-xl">
            <span className="text-[10px] uppercase font-mono text-[#D4AF37] tracking-wider">Active Promo Codes</span>
            <p className="text-2xl font-bold font-mono text-white">
              {filteredLinks.length} Active
            </p>
            <p className="text-[11px] text-slate-400">Ready for bio & video placement</p>
          </div>
        )}

        {/* Metric 4: Creator Commissions */}
        <div className="bg-[#142850] border border-white/5 rounded-2xl p-5 space-y-2 shadow-xl">
          <span className="text-[10px] uppercase font-mono text-emerald-400 tracking-wider">
            {isCreator ? 'Average Commission Rate' : 'Total Creator Payouts'}
          </span>
          <p className="text-2xl font-bold font-mono text-white">
            {isCreator ? '15.0% Direct' : `$${aggregateMetrics.totalCreatorCommission.toFixed(2)}`}
          </p>
          <p className="text-[11px] text-slate-400">Settled through escrow pipeline</p>
        </div>
      </div>

      {/* Active Tracking Links & Promo Codes */}
      <div className="bg-[#142850] border border-white/5 rounded-3xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Link2 className="w-4 h-4 text-[#D4AF37]" />
            Active Affiliate Tracking Links & Promo Codes
          </h3>
          <span className="text-[10px] text-slate-400 font-mono">Custom Redirect Endpoints</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {filteredLinks.map((link) => (
            <div 
              key={link.id}
              className="p-5 bg-[#0B1B3D] border border-white/5 rounded-2xl space-y-3 relative group hover:border-[#D4AF37]/30 transition-all"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono text-[#D4AF37] uppercase font-bold">{link.brandName}</span>
                  <h4 className="text-xs font-bold text-white">{link.campaignTitle}</h4>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[9px] font-bold text-emerald-400">
                  {link.status.toUpperCase()}
                </span>
              </div>

              {/* Promo Code & Link Box */}
              <div className="p-3 bg-white/5 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 font-mono">Promo Code</span>
                  <button
                    onClick={() => handleCopyCode(link.discountCode)}
                    className="flex items-center gap-1 text-xs font-mono font-bold text-[#D4AF37] hover:underline"
                  >
                    <span>{link.discountCode}</span>
                    {copiedCode === link.discountCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>Custom URL</span>
                  <span className="font-mono text-white/80 truncate max-w-[150px]">{link.customUrl}</span>
                </div>
              </div>

              {/* Stats Footer */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-white/5">
                <span>Creator: <strong className="text-white">{link.creatorHandle}</strong></span>
                <span className="text-emerald-400 font-mono font-bold">
                  {link.commissionRateCreator}% Cut
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Live Inbound Transactions Ledger */}
      <div className="bg-[#142850] border border-white/5 rounded-3xl p-6 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-emerald-400" />
              Live Storefront Transaction Feeds (80/20 Split Engine)
            </h3>
            <p className="text-xs text-[#7C8AA8] mt-0.5">
              Instant background webhook ingestion across Shopify, TikTok Shop & Amazon
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              Webhook Listener Live
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 font-mono text-[10px] uppercase">
                <th className="py-3 px-3">Order ID / Store</th>
                <th className="py-3 px-3">Timestamp</th>
                <th className="py-3 px-3">Creator / Code</th>
                <th className="py-3 px-3">Gross Sale</th>
                {!isCreator && <th className="py-3 px-3 text-[#D4AF37]">Agency Cut (80%)</th>}
                {!isCreator && <th className="py-3 px-3 text-cyan-400">Brand Cut (20%)</th>}
                <th className="py-3 px-3 text-emerald-400">Creator Commission</th>
                <th className="py-3 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono">
              {filteredTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-white/[0.02] transition-all">
                  <td className="py-3.5 px-3">
                    <div className="font-bold text-white">{tx.orderId}</div>
                    <span className="text-[10px] text-slate-400 font-sans">{tx.storefront} • {tx.brandName}</span>
                  </td>
                  <td className="py-3.5 px-3 text-slate-400 text-[11px]">{tx.timestamp}</td>
                  <td className="py-3.5 px-3">
                    <div className="font-sans font-semibold text-white">{tx.creatorHandle}</div>
                    <span className="text-[10px] text-[#D4AF37]">{tx.discountCodeUsed}</span>
                  </td>
                  <td className="py-3.5 px-3 font-bold text-white">
                    ${tx.grossAmount.toFixed(2)}
                  </td>
                  {!isCreator && (
                    <td className="py-3.5 px-3 font-bold text-[#D4AF37]">
                      ${tx.agencyGrossSplit.toFixed(2)}
                    </td>
                  )}
                  {!isCreator && (
                    <td className="py-3.5 px-3 font-bold text-cyan-400">
                      ${tx.brandGrossSplit.toFixed(2)}
                    </td>
                  )}
                  <td className="py-3.5 px-3 font-bold text-emerald-400">
                    ${tx.creatorCommissionAmount.toFixed(2)}
                  </td>
                  <td className="py-3.5 px-3 text-right">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[9px] font-bold text-emerald-400">
                      SETTLED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="text-xl font-serif font-bold text-white">New Affiliate Campaign</h3>
                <p className="text-xs text-slate-400">Provision custom links & promo codes with 80/20 split</p>
              </div>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateLink} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest">Brand Partner</label>
                <input
                  type="text"
                  required
                  value={newBrandName}
                  onChange={(e) => setNewBrandName(e.target.value)}
                  placeholder="e.g. Sephora Beauty"
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:border-[#D4AF37] outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest">Discount Code</label>
                  <input
                    type="text"
                    required
                    value={newDiscountCode}
                    onChange={(e) => setNewDiscountCode(e.target.value)}
                    placeholder="e.g. GLOW20"
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white font-mono uppercase focus:border-[#D4AF37] outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest">Discount Offer</label>
                  <input
                    type="text"
                    required
                    value={newDiscountRate}
                    onChange={(e) => setNewDiscountRate(e.target.value)}
                    placeholder="e.g. 20% OFF"
                    className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:border-[#D4AF37] outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-white/60 uppercase font-bold tracking-widest">Creator Direct Commission (%)</label>
                <input
                  type="number"
                  min={0.1}
                  max={50}
                  step="0.1"
                  required
                  value={newCreatorCommission}
                  onChange={(e) => setNewCreatorCommission(e.target.value === '' ? '' as any : parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#0B1B3D] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white font-mono focus:border-[#D4AF37] outline-none"
                />
              </div>

              <div className="p-3 bg-[#0B1B3D] rounded-xl text-xs space-y-1 border border-white/5">
                <div className="flex justify-between text-slate-400">
                  <span>Agency Master Split:</span>
                  <strong className="text-[#D4AF37]">80%</strong>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Brand Retained Split:</span>
                  <strong className="text-cyan-400">20%</strong>
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] rounded-xl text-xs font-bold shadow-lg"
                >
                  Publish Campaign
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AffiliateSalesLedger;
