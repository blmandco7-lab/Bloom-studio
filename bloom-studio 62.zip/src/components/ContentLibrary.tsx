import React, { useState, useMemo } from 'react';
import { Search, Download, Share2, Plus, Video, ShieldCheck, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';
import { Creator, Deal, ReviewItem } from '../types';
import { safeStorage } from '../utils/safeStorage';
import { DEFAULT_CONTENT_LIBRARY_ASSETS } from '../data/defaultAgencyData';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, where, doc, setDoc } from 'firebase/firestore';

interface LibraryAsset {
  id: string;
  title: string;
  creator: string;
  brand: string;
  platform: string;
  type: 'video' | 'image' | 'carousel';
  views: number;
  engagement: string;
  status: 'Live' | 'Approved' | 'Draft';
  thumbnailUrl: string;
  fileSize: string;
}

const DEFAULT_ASSETS: LibraryAsset[] = [
  {
    id: 'asset_1',
    title: 'Glow Serum Master Reel 4K',
    creator: '@emmagreen',
    brand: 'Glow Recipe',
    platform: 'Instagram',
    type: 'video',
    views: 420000,
    engagement: '8.4%',
    status: 'Live',
    thumbnailUrl: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=60',
    fileSize: '48.2 MB'
  },
  {
    id: 'asset_2',
    title: 'Sony Alpha 7IV Night Shoot Review',
    creator: '@marcus_vfx',
    brand: 'Sony',
    platform: 'YouTube',
    type: 'video',
    views: 289000,
    engagement: '9.1%',
    status: 'Live',
    thumbnailUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&auto=format&fit=crop&q=60',
    fileSize: '1.2 GB'
  },
  {
    id: 'asset_3',
    title: 'Autumn Lookbook 10-Slide Carousel',
    creator: '@sophiacodes',
    brand: 'Revolve',
    platform: 'Instagram',
    type: 'carousel',
    views: 185000,
    engagement: '6.7%',
    status: 'Approved',
    thumbnailUrl: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&auto=format&fit=crop&q=60',
    fileSize: '22.8 MB'
  },
  {
    id: 'asset_4',
    title: 'Pre-Workout Stack Unboxing & Taste Test',
    creator: '@alexrivera',
    brand: 'Gymshark',
    platform: 'TikTok',
    type: 'video',
    views: 650000,
    engagement: '11.2%',
    status: 'Live',
    thumbnailUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=60',
    fileSize: '36.4 MB'
  },
  {
    id: 'asset_5',
    title: 'BarkHydrate Eco Travel Bowl Demonstration',
    creator: '@paws_and_palette',
    brand: 'BarkHydrate',
    platform: 'TikTok',
    type: 'video',
    views: 310000,
    engagement: '9.8%',
    status: 'Live',
    thumbnailUrl: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=600&auto=format&fit=crop&q=60',
    fileSize: '42.1 MB'
  },
  {
    id: 'asset_6',
    title: 'Velvet Aromatherapy Evening Routine',
    creator: '@velvet_botanics',
    brand: 'Velvet Botanics',
    platform: 'Instagram',
    type: 'video',
    views: 195000,
    engagement: '7.3%',
    status: 'Approved',
    thumbnailUrl: 'https://images.unsplash.com/photo-1512290900672-1f4142cf6f74?w=600&auto=format&fit=crop&q=60',
    fileSize: '28.6 MB'
  }
];

interface ContentLibraryProps {
  creators: Creator[];
  deals: Deal[];
  onAddActivityLog: (user: string, role: string, action: string) => void;
  triggerNotification: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
  currentUser?: any;
  currentRole?: string;
  assets?: LibraryAsset[];
  setAssets?: React.Dispatch<React.SetStateAction<LibraryAsset[]>>;
  reviewsList?: ReviewItem[];
  onNavigate?: (screen: string) => void;
}

export default function ContentLibrary({ 
  creators = [], 
  deals = [], 
  onAddActivityLog, 
  triggerNotification, 
  currentUser, 
  currentRole,
  assets: remoteAssets,
  setAssets: setRemoteAssets,
  reviewsList,
  onNavigate
}: ContentLibraryProps) {
  const roleLower = (currentRole || '').toLowerCase();
  const isAgentMgr = roleLower === 'agentmgr';
  const isAgent = roleLower === 'agent';
  const isCoordinator = roleLower === 'coordinator';
  const isRestrictedRole = isAgentMgr || isAgent || isCoordinator;
  
  const userName = (currentUser?.name || '').toLowerCase();

  // Find creators assigned to this agent / manager / coordinator
  const myCreators = useMemo(() => {
    if (!isRestrictedRole) return creators;
    return (creators || []).filter(c => {
      const assignedAg = (c.assignedAgent || (c as any).agent || '').toLowerCase();
      const coord = (c.coordinator || '').toLowerCase();
      return (
        assignedAg.includes(userName) || 
        userName.includes(assignedAg) ||
        coord.includes(userName) ||
        userName.includes(coord) ||
        (userName.includes('marcus') && (c.assignedAgent?.toLowerCase().includes('marcus') || (c as any).agent?.toLowerCase().includes('marcus'))) ||
        (userName.includes('alex') && (c.assignedAgent?.toLowerCase().includes('alex') || (c as any).agent?.toLowerCase().includes('alex')))
      );
    });
  }, [creators, isRestrictedRole, userName]);

  const myHandlesSet = useMemo(() => {
    const set = new Set<string>();
    myCreators.forEach(c => {
      set.add(c.handle.toLowerCase());
      set.add(c.handle.toLowerCase().replace(/^@/, ''));
      set.add('@' + c.handle.toLowerCase().replace(/^@/, ''));
      set.add(c.name.toLowerCase());
    });
    // Add deals where agent is assigned
    (deals || []).forEach(d => {
      const dealAgent = ((d as any).assignedAgent || (d as any).agent || '').toLowerCase();
      if (dealAgent.includes(userName) || userName.includes(dealAgent)) {
        if (d.creator) {
          set.add(d.creator.toLowerCase());
          set.add(d.creator.toLowerCase().replace(/^@/, ''));
          set.add('@' + d.creator.toLowerCase().replace(/^@/, ''));
        }
      }
    });
    return set;
  }, [myCreators, deals, userName]);

  const [assets, setAssets] = useState<LibraryAsset[]>([]);

  React.useEffect(() => {
    let unsub = () => {};
    if (db) {
      const isPlatformOwner = currentUser?.isPlatformOwner || false;
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
      const myHandle = currentUser?.handle || '';
      const myFormattedHandle = myHandle.startsWith('@') ? myHandle : `@${myHandle}`;
      const isCreator = (currentRole || '').toLowerCase() === 'creator';

      let q: any = collection(db, 'studio-content-vault');

      if (!isPlatformOwner) {
        if (isCreator) {
          q = query(
            collection(db, 'studio-content-vault'),
            where('creatorHandle', '==', myFormattedHandle)
          );
        } else {
          q = query(
            collection(db, 'studio-content-vault'),
            where('tenantId', '==', userPod)
          );
        }
      }

      unsub = onSnapshot(q, (snapshot) => {
        const loadedAssets: LibraryAsset[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          loadedAssets.push({
            id: docSnap.id,
            title: data.title || '',
            creator: data.creator || '',
            brand: data.brand || '',
            platform: data.platform || 'Instagram',
            type: data.type || 'video',
            views: data.views || 0,
            engagement: data.engagement || '0.0%',
            status: data.status || 'Approved',
            thumbnailUrl: data.thumbnailUrl || 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=60',
            fileSize: data.fileSize || '15.5 MB'
          });
        });

        if (loadedAssets.length > 0) {
          setAssets(loadedAssets);
        } else {
          // If no assets exist in Firestore for this user/pod, seed them to Firestore to guarantee real persistence!
          const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';
          const defaultList = (DEFAULT_CONTENT_LIBRARY_ASSETS as any[]) || [];
          defaultList.forEach(async (item) => {
            try {
              const assetId = item.id;
              const formattedHandle = item.creator || '@elenarostova';
              const cleanAsset = {
                ...item,
                creatorId: currentUser?.uid || 'user_guest',
                creatorHandle: formattedHandle,
                tenantId: userPod,
                subagency: userPod,
                pod: userPod
              };
              await setDoc(doc(db, 'studio-content-vault', assetId), cleanAsset);
              await setDoc(doc(db, 'studio-content-library', assetId), cleanAsset);
            } catch (err) {
              console.warn("Seeding content asset failed:", err);
            }
          });
          setAssets(defaultList);
        }
      }, (error) => {
        console.warn("Firestore studio-content-vault listener warning:", error);
      });
    }
    return () => unsub();
  }, [currentUser, currentRole]);

  // Automatically integrate approved deliverables from reviewsList
  React.useEffect(() => {
    if (!reviewsList || reviewsList.length === 0 || !db) return;
    const approved = reviewsList.filter(r => 
      r.status === 'Approved' || 
      r.status === 'Posted' || 
      r.status === 'Approved with Warning' ||
      r.brandReviewStatus === 'Auto Approved' ||
      r.brandReviewStatus === 'Feedback Received' ||
      r.brandReviewStatus === 'Approved'
    );
    if (approved.length === 0) return;

    const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';

    approved.forEach(async (r) => {
      const assetId = `asset_${r.id}`;
      // Check if it already exists in our local assets list
      const alreadyExists = assets.some(a => a.id === assetId);
      if (!alreadyExists) {
        const newAsset = {
          id: assetId,
          title: `${r.brand} — ${r.contentType}`,
          creator: r.creator,
          creatorHandle: r.creator.startsWith('@') ? r.creator : `@${r.creator}`,
          brand: r.brand,
          platform: r.platform || 'Instagram',
          type: (r.contentType.toLowerCase().includes('video') || r.contentType.toLowerCase().includes('reel')) ? 'video' : r.contentType.toLowerCase().includes('carousel') ? 'carousel' : 'image',
          views: 0,
          engagement: '0.0%',
          status: 'Approved',
          thumbnailUrl: r.mediaUrl || 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=60',
          fileSize: '24.5 MB',
          tenantId: userPod,
          subagency: userPod,
          pod: userPod
        };
        try {
          await setDoc(doc(db, 'studio-content-vault', assetId), newAsset);
          await setDoc(doc(db, 'studio-content-library', assetId), newAsset);
        } catch (err) {
          console.error("Error auto-saving approved deliverable to Firestore:", err);
        }
      }
    });
  }, [reviewsList, assets, db, currentUser]);

  // Real-time listener for newly approved and vaulted assets
  React.useEffect(() => {
    const handleVaultUpdate = (e: any) => {
      const newAsset = e.detail;
      if (!newAsset) return;
      setAssets(prev => {
        if (prev.some(a => a.id === newAsset.id)) return prev;
        const next = [newAsset, ...prev];
        safeStorage.setItem('wl_content_library_assets', JSON.stringify(next));
        safeStorage.setItem('wl_content_vault_assets', JSON.stringify(next));
        return next;
      });
    };
    window.addEventListener('wl_content_vault_updated', handleVaultUpdate);
    return () => window.removeEventListener('wl_content_vault_updated', handleVaultUpdate);
  }, []);

  React.useEffect(() => {
    try {
      if (assets.length > 0) {
        safeStorage.setItem('wl_content_library_assets', JSON.stringify(assets));
      }
    } catch (e) {
      console.error(e);
    }
    if (setRemoteAssets && JSON.stringify(remoteAssets) !== JSON.stringify(assets)) {
      setRemoteAssets(assets);
    }
  }, [assets, remoteAssets, setRemoteAssets]);

  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAllRoster, setShowAllRoster] = useState(true);

  // New Asset Form State
  const [newTitle, setNewTitle] = useState('');
  const [newCreator, setNewCreator] = useState('');
  const [newBrand, setNewBrand] = useState('');
  const [newPlatform, setNewPlatform] = useState('TikTok');
  const [newType, setNewType] = useState<'video' | 'image' | 'carousel'>('video');
  const [newFileSize, setNewFileSize] = useState('15.5 MB');

  const filteredAssets = useMemo(() => {
    return assets.filter(asset => {
      if (isRestrictedRole && !showAllRoster && myHandlesSet.size > 0) {
        const assetCreator = asset.creator.toLowerCase();
        const assetCreatorClean = assetCreator.replace(/^@/, '');
        const isMatch = myHandlesSet.has(assetCreator) || myHandlesSet.has(assetCreatorClean) || myHandlesSet.has('@' + assetCreatorClean);
        if (!isMatch) {
          return false;
        }
      }
      const matchesSearch = asset.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            asset.creator.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            asset.brand.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPlatform = platformFilter === 'All' || asset.platform === platformFilter;
      const matchesStatus = statusFilter === 'All' || asset.status === statusFilter;
      return matchesSearch && matchesPlatform && matchesStatus;
    });
  }, [assets, isRestrictedRole, showAllRoster, myHandlesSet, searchQuery, platformFilter, statusFilter]);

  const handleDownload = (asset: LibraryAsset) => {
    triggerNotification(
      'Download Dispatched',
      `Simulating high-speed asset download for "${asset.title}" (${asset.fileSize})`,
      'success'
    );
    onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Downloaded media asset: ${asset.title}`);
  };

  const handleShare = (asset: LibraryAsset) => {
    triggerNotification(
      'Share Link Copied',
      `Pre-signed secure CDN delivery URL created for "${asset.title}". Shared link copied to clipboard.`,
      'info'
    );
    onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Generated share link for: ${asset.title}`);
  };

  const handleAddAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newCreator || !newBrand) {
      alert("Title, Creator and Brand are required!");
      return;
    }

    const placeholderImages = [
      'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?w=600&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=60',
      'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=600&auto=format&fit=crop&q=60'
    ];

    const randomImg = placeholderImages[Math.floor(Math.random() * placeholderImages.length)];
    const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'pod_main';

    const selectedCreatorObj = creators.find(c => c.handle === newCreator || c.handle.toLowerCase() === newCreator.toLowerCase());
    const creatorId = selectedCreatorObj?.id || (selectedCreatorObj as any)?.uid || currentUser?.uid || currentUser?.id || '';
    const creatorHandle = selectedCreatorObj?.handle || newCreator;
    const formattedHandle = creatorHandle.startsWith('@') ? creatorHandle : `@${creatorHandle}`;

    const assetId = 'asset_' + Date.now();
    const newAsset: LibraryAsset & { creatorId: string; creatorHandle: string; tenantId: string; subagency: string; pod: string } = {
      id: assetId,
      title: newTitle,
      creator: formattedHandle,
      creatorId: creatorId,
      creatorHandle: formattedHandle,
      tenantId: userPod,
      subagency: userPod,
      pod: userPod,
      brand: newBrand,
      platform: newPlatform,
      type: newType,
      views: 0,
      engagement: '0.0%',
      status: 'Approved',
      thumbnailUrl: randomImg,
      fileSize: newFileSize
    };

    setAssets(prev => [newAsset, ...prev]);
    setShowAddModal(false);
    setNewTitle('');
    setNewCreator('');
    setNewBrand('');

    try {
      if (db) {
        await setDoc(doc(db, 'studio-content-vault', assetId), newAsset);
        await setDoc(doc(db, 'studio-content-library', assetId), newAsset);
      }
    } catch (err) {
      console.error("Error saving asset to Firestore:", err);
    }

    triggerNotification('Asset Cataloged', `Saved "${newTitle}" to Content Vault.`, 'success');
    onAddActivityLog(currentUser?.name || 'Agent', currentRole || 'agent', `Cataloged asset: ${newTitle}`);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#111E33] to-[#0D1830] border border-white/10 rounded-2xl p-6 relative overflow-hidden shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-mono font-bold tracking-wider text-[#C9A46A] uppercase px-2.5 py-0.5 rounded-full bg-[#C9A46A]/10 border border-[#C9A46A]/20">
                {isAgent ? 'Assigned Talent Content Vault' : 'Enterprise Creative Asset Vault'}
              </span>
              {isRestrictedRole && (
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Scoped to Your Creators
                </span>
              )}
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
              {isAgent ? "My Creators' Content Vault & Asset Library" : 'Content Vault & Asset Library'}
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 max-w-2xl">
              {isAgent 
                ? 'Review, preview, and download master-quality deliverables submitted strictly by the creators on your active management roster.'
                : 'Central repository of all high-resolution creative deliverables, organic Reels, TikTok UGC masters, and licensed campaign assets.'}
            </p>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all shadow-lg shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Catalog New Deliverable
          </button>
        </div>
      </div>

      {/* Automated Pipeline Integration Notification */}
      <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-2xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs text-emerald-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Automated Content Pipeline Active:</strong> Deliverables approved in <em>Content Review &amp; Approvals</em> automatically populate here into the Content Vault for one-click downloading, brand syndication, and campaign tracking.
          </span>
        </div>
        {onNavigate && (
          <button
            type="button"
            onClick={() => onNavigate('content-review')}
            className="text-xs text-emerald-300 hover:text-emerald-100 font-semibold flex items-center gap-1 shrink-0 cursor-pointer underline underline-offset-2"
          >
            Review Pending Submissions <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0D1830] border border-white/5 p-3 rounded-2xl">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          {isRestrictedRole && (
            <div className="flex items-center bg-[#111E33] border border-white/10 rounded-xl p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setShowAllRoster(false)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${!showAllRoster ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                My Creators ({myCreators.length})
              </button>
              <button
                type="button"
                onClick={() => setShowAllRoster(true)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${showAllRoster ? 'bg-[#C9A46A] text-[#0A1220] font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                All Vault Assets ({assets.length})
              </button>
            </div>
          )}

          <div className="relative min-w-[200px] flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search title, creator, or brand..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-[#111E33] border border-white/10 text-white text-xs pl-9 pr-3 py-2 rounded-xl focus:outline-none focus:border-[#C9A46A]/50"
            />
          </div>

          <select
            value={platformFilter}
            onChange={e => setPlatformFilter(e.target.value)}
            className="bg-[#111E33] border border-white/10 text-slate-300 text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-[#C9A46A]/50 cursor-pointer"
          >
            <option value="All">Platform: All</option>
            <option value="TikTok">TikTok</option>
            <option value="Instagram">Instagram</option>
            <option value="YouTube">YouTube</option>
          </select>

          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="bg-[#111E33] border border-white/10 text-slate-300 text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-[#C9A46A]/50 cursor-pointer"
          >
            <option value="All">Status: All</option>
            <option value="Live">Live & Published</option>
            <option value="Approved">Approved Master</option>
            <option value="Draft">In Review / Draft</option>
          </select>
        </div>

        <span className="text-[10px] font-mono text-[#7C8AA8] px-2">
          Showing {filteredAssets.length} {filteredAssets.length === 1 ? 'asset' : 'assets'}
        </span>
      </div>

      {/* Assets Grid */}
      {filteredAssets.length === 0 ? (
        <div className="bg-[#0D1830] border border-white/5 rounded-2xl p-12 text-center text-slate-400 space-y-3">
          <Video className="w-12 h-12 text-[#C9A46A]/40 mx-auto" />
          <p className="font-semibold text-white">No Deliverable Assets Found</p>
          <p className="text-xs max-w-md mx-auto text-[#7C8AA8]">
            {isAgent 
              ? 'No media assets have been cataloged yet for your assigned creators. Use "Catalog New Deliverable" or approve submitted drafts in Content Review.'
              : 'Try clearing your search filters or catalog a new creative deliverable to build the agency asset library.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAssets.map(asset => (
            <div key={asset.id} className="bg-[#0D1830] border border-white/5 rounded-2xl overflow-hidden shadow-xl hover:border-[#C9A46A]/30 transition-all flex flex-col justify-between group">
              <div>
                <div className="relative aspect-video bg-[#111E33] overflow-hidden">
                  <img
                    src={asset.thumbnailUrl}
                    alt={asset.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                    <span className="text-[9px] font-mono font-bold bg-[#060B15]/80 text-[#C9A46A] px-2 py-0.5 rounded-full border border-white/10 backdrop-blur-sm">
                      {asset.platform}
                    </span>
                    <span className="text-[9px] font-mono text-white bg-[#060B15]/80 px-2 py-0.5 rounded-full border border-white/10 backdrop-blur-sm">
                      {asset.fileSize}
                    </span>
                  </div>

                  <span className={`absolute top-2.5 right-2.5 text-[9px] font-bold px-2 py-0.5 rounded-full border backdrop-blur-sm ${
                    asset.status === 'Live'
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                      : asset.status === 'Approved'
                      ? 'bg-purple-950/80 text-purple-300 border-purple-500/40'
                      : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                  }`}>
                    {asset.status}
                  </span>
                </div>

                <div className="p-4 space-y-2">
                  <h3 className="font-bold text-sm text-white line-clamp-1">{asset.title}</h3>
                  <div className="flex items-center justify-between text-xs text-[#7C8AA8]">
                    <span className="text-[#C9A46A] font-mono font-semibold">{asset.creator}</span>
                    <span>{asset.brand}</span>
                  </div>
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span>👁️ {(asset.views).toLocaleString()} Views</span>
                    <span>🔥 {asset.engagement} Eng.</span>
                  </div>
                </div>
              </div>

              <div className="p-4 pt-0 flex items-center gap-2">
                <button
                  onClick={() => handleShare(asset)}
                  className="flex-1 bg-[#111E33] hover:bg-[#16243F] border border-white/10 hover:text-white text-[#7C8AA8] py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5" /> Share
                </button>
                <button
                  onClick={() => handleDownload(asset)}
                  className="flex-1 bg-[#16243F] hover:bg-[#1f3050] text-[#C9A46A] border border-[#C9A46A]/20 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> Download
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Asset Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-[#060B15]/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="h-14 flex items-center justify-between px-6 border-b border-[#C9A46A]/20 bg-[#111E33]">
              <h3 className="font-serif font-medium text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#C9A46A]" /> Catalog Deliverable Asset
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#7C8AA8] hover:text-white cursor-pointer">&times;</button>
            </div>

            <form onSubmit={handleAddAsset} className="p-6 space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Asset / Deliverable Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lip Gloss Review Reel"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Creator</label>
                  <select
                    value={newCreator}
                    onChange={e => setNewCreator(e.target.value)}
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]/50 cursor-pointer"
                  >
                    <option value="">Select Creator</option>
                    {(isRestrictedRole ? myCreators : creators).map(c => (
                      <option key={c.id || c.handle} value={c.handle}>{c.name} ({c.handle})</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Associated Brand</label>
                  <select
                    value={newBrand}
                    onChange={e => setNewBrand(e.target.value)}
                    required
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#C9A46A]/50 cursor-pointer"
                  >
                    <option value="">Select Brand</option>
                    {deals.length > 0 ? (
                      deals.map(d => (
                        <option key={d.id} value={d.brand}>{d.brand}</option>
                      ))
                    ) : (
                      <>
                        <option value="Glow Recipe">Glow Recipe</option>
                        <option value="BarkHydrate">BarkHydrate</option>
                        <option value="Sony">Sony</option>
                        <option value="Revolve">Revolve</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Platform</label>
                  <select
                    value={newPlatform}
                    onChange={e => setNewPlatform(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#C9A46A]/50 cursor-pointer"
                  >
                    <option value="TikTok">TikTok</option>
                    <option value="Instagram">Instagram</option>
                    <option value="YouTube">YouTube</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">Asset Type</label>
                  <select
                    value={newType}
                    onChange={e => setNewType(e.target.value as any)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#C9A46A]/50 cursor-pointer"
                  >
                    <option value="video">Video Reel</option>
                    <option value="carousel">Carousel</option>
                    <option value="image">Photo Still</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-[#7C8AA8] uppercase font-mono">File Size</label>
                  <input
                    type="text"
                    value={newFileSize}
                    onChange={e => setNewFileSize(e.target.value)}
                    placeholder="e.g. 24.5 MB"
                    className="w-full bg-[#111E33] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-[#C9A46A]/50"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs text-[#7C8AA8] hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold text-xs px-5 py-2.5 rounded-xl shadow cursor-pointer"
                >
                  Catalog Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
