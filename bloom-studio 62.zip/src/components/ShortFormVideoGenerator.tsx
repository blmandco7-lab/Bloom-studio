import React, { useState, useRef } from 'react';
import { 
  Video, 
  Layers, 
  Play, 
  Pause, 
  Settings, 
  Download, 
  MonitorPlay,
  CheckCircle2,
  Trash2,
  Sparkles,
  RefreshCw,
  Plus,
  ShieldCheck,
  Upload,
  AlertCircle
} from 'lucide-react';

const SAMPLE_VIDEOS = [
  { name: 'Beauty & Skincare UGC Reel', url: 'https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-woman-holding-a-serum-dropper-40251-large.mp4' },
  { name: 'Pets & Outdoor Canine Active Reel', url: 'https://assets.mixkit.co/videos/preview/mixkit-dog-running-on-the-grass-in-the-park-34284-large.mp4' },
  { name: 'Lifestyle & Home Tour Showreel', url: 'https://assets.mixkit.co/videos/preview/mixkit-girl-in-neon-sign-posing-for-camera-34283-large.mp4' },
  { name: 'Fitness & Wellness Daily Vlog', url: 'https://assets.mixkit.co/videos/preview/mixkit-woman-doing-yoga-on-a-beach-40252-large.mp4' },
  { name: 'Tech & Unboxing High-Energy Reel', url: 'https://assets.mixkit.co/videos/preview/mixkit-hands-typing-on-a-laptop-40253-large.mp4' }
];

export default function ShortFormVideoGenerator() {
  const [rendering, setRendering] = useState(false);
  const [rendered, setRendered] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [keptStatus, setKeptStatus] = useState<boolean | null>(null);
  const [videoError, setVideoError] = useState(false);

  // AI vs Upload Mode State
  const [mode, setMode] = useState<'ai' | 'upload'>('ai');
  const [aiPrompt, setAiPrompt] = useState('Cinematic 9:16 slow-motion macro shot of a luxurious rose botanical serum bottle with shimmering golden sunlight');
  const [aiPresetStyle, setAiPresetStyle] = useState('Cinematic Product Glow');

  // Manual Custom Topic Input State
  const [customTopic, setCustomTopic] = useState('Organic Summer Botanical Serum Demo');
  const [metricOverlayText, setMetricOverlayText] = useState('450K Views | 3.2x ROAS | FTC Compliant');
  const [overlayStyle, setOverlayStyle] = useState('Metric Callouts (Agency Branding)');
  const [selectedVideoUrl, setSelectedVideoUrl] = useState(SAMPLE_VIDEOS[0].url);
  const [uploadedVideoName, setUploadedVideoName] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      alert('Please upload a valid video file (.mp4, .mov, .webm).');
      return;
    }

    const videoBlobUrl = URL.createObjectURL(file);
    setSelectedVideoUrl(videoBlobUrl);
    setUploadedVideoName(file.name);
    setVideoError(false);
  };

  const handleStartRender = () => {
    if (!customTopic.trim()) {
      alert('Please enter a video topic.');
      return;
    }
    setRendering(true);
    setKeptStatus(null);
    setRendered(false);
    setVideoError(false);

    if (mode === 'ai' && !uploadedVideoName) {
      const otherVideos = SAMPLE_VIDEOS.filter(v => v.url !== selectedVideoUrl);
      const nextVideo = otherVideos[Math.floor(Math.random() * otherVideos.length)] || SAMPLE_VIDEOS[0];
      setSelectedVideoUrl(nextVideo.url);
    }

    setTimeout(() => {
      setRendering(false);
      setRendered(true);
      setIsPlaying(true);
    }, 1800);
  };

  const handleDiscard = () => {
    // Generate a DIFFERENT video clip upon discard
    const otherVideos = SAMPLE_VIDEOS.filter(v => v.url !== selectedVideoUrl);
    const nextVideo = otherVideos[Math.floor(Math.random() * otherVideos.length)] || SAMPLE_VIDEOS[0];
    
    setSelectedVideoUrl(nextVideo.url);
    setUploadedVideoName(null);
    setVideoError(false);
    setKeptStatus(null);
    setRendered(false);
    setRendering(true);

    setTimeout(() => {
      setRendering(false);
      setRendered(true);
      setIsPlaying(true);
    }, 1400);
  };

  const handleKeep = () => {
    setKeptStatus(true);
  };

  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = selectedVideoUrl;
    a.download = `Showreel_${customTopic.replace(/[^a-zA-Z0-9]/g, '_')}.mp4`;
    a.click();
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      {/* Header Banner */}
      <div className="relative bg-[#0b1320] border-2 border-blue-500/30 rounded-3xl p-6 md:p-8 overflow-hidden shadow-2xl">
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-blue-400 font-bold uppercase tracking-[0.2em] font-mono px-2.5 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/20">
                Inbound Growth Engine
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
              Automated Short-Form Video Showreels
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl">
              Compile approved UGC clips for custom topics into 9:16 showreel video loops with real-time overlay metrics, live interactive preview, and keep/discard approval controls.
            </p>
          </div>
          <div className="bg-[#050d18] border border-blue-900/60 rounded-2xl p-4 flex items-center gap-3 shrink-0">
             <Video className="w-8 h-8 text-blue-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Editor Controls */}
        <div className="lg:col-span-5 bg-[#0b1320] border border-white/10 rounded-3xl p-6 space-y-6">
          <div>
            <h3 className="text-xs font-bold font-mono text-white uppercase mb-4 flex items-center gap-2 pb-2 border-b border-white/10">
              <Layers className="w-4 h-4 text-blue-400" />
              Custom Topic &amp; Render Settings
            </h3>
            
            {/* Mode Switcher Tabs */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-[#050e1a] rounded-2xl border border-white/10 mb-4">
              <button
                type="button"
                onClick={() => setMode('ai')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  mode === 'ai'
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-300" />
                <span>AI Video Engine</span>
              </button>

              <button
                type="button"
                onClick={() => setMode('upload')}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  mode === 'upload'
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Upload className="w-3.5 h-3.5 text-blue-300" />
                <span>Upload Video</span>
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Manual Topic Input */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest block">
                  1. Video Topic / Hook Theme
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Morning Skincare Routine &amp; Barrier Repair"
                  value={customTopic}
                  onChange={e => setCustomTopic(e.target.value)}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-blue-500"
                />
              </div>

              {/* AI Video Prompt vs Upload Inputs */}
              {mode === 'ai' ? (
                <div className="space-y-3 bg-[#050e1a] p-3.5 rounded-2xl border border-blue-500/30">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold text-blue-300 uppercase tracking-widest block flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                      2. Gemini AI Video Motion Prompt
                    </label>
                    <textarea
                      rows={3}
                      value={aiPrompt}
                      onChange={e => setAiPrompt(e.target.value)}
                      placeholder="Describe visual motion, lighting, subject, and style for AI video generation..."
                      className="w-full bg-[#0b1320] border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:border-blue-500 font-sans leading-relaxed"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest block">
                      AI Motion &amp; Aesthetic Style
                    </label>
                    <select
                      value={aiPresetStyle}
                      onChange={e => setAiPresetStyle(e.target.value)}
                      className="w-full bg-[#0b1320] border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-blue-500 font-mono"
                    >
                      <option value="Cinematic Product Glow">Cinematic Product Glow (Slow Motion Macro)</option>
                      <option value="Dynamic UGC Unboxing">Dynamic UGC Unboxing &amp; First Impressions</option>
                      <option value="Pet Outdoor Adventure">Pet Outdoor Adventure Sprint &amp; Play</option>
                      <option value="Lifestyle Morning Routine">Lifestyle Morning Routine &amp; Aesthetic Vibe</option>
                    </select>
                  </div>
                </div>
              ) : (
                /* Upload Custom Video or Select Source UGC Footage Loop */
                <div className="space-y-2">
                  <label className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest block">
                    2. Select or Upload Source Video (.MP4)
                  </label>

                  {/* Upload Button */}
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleVideoUpload} 
                    accept="video/*" 
                    className="hidden" 
                  />
                  
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-2.5 px-3 bg-blue-500/15 hover:bg-blue-500/25 border border-blue-500/40 text-blue-300 rounded-xl font-mono text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-blue-400" />
                    <span>{uploadedVideoName ? `Uploaded: ${uploadedVideoName}` : 'Upload Your Custom MP4 Video File'}</span>
                  </button>

                  <div className="text-[10px] font-mono text-slate-400 text-center uppercase">-- OR SELECT A PRESET SAMPLE --</div>

                  <select
                    value={selectedVideoUrl}
                    onChange={e => {
                      setSelectedVideoUrl(e.target.value);
                      setUploadedVideoName(null);
                      setVideoError(false);
                    }}
                    className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-blue-500"
                  >
                    <option value="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4">
                      Beauty &amp; Skincare UGC Reel (High-Res MP4)
                    </option>
                    <option value="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4">
                      Pets &amp; Outdoor Canine Active Reel (High-Res MP4)
                    </option>
                    <option value="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4">
                      Lifestyle &amp; Home Tour Showreel (High-Res MP4)
                    </option>
                  </select>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest block">
                  3. Overlay Style Format
                </label>
                <select
                  value={overlayStyle}
                  onChange={e => setOverlayStyle(e.target.value)}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-blue-500"
                >
                  <option>Metric Callouts (Agency Branding)</option>
                  <option>Subtitles &amp; FTC Safety Badge</option>
                  <option>Clean Aesthetic Overlay</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-widest block">
                  4. Custom Metric Banner Text
                </label>
                <input 
                  type="text" 
                  value={metricOverlayText}
                  onChange={e => setMetricOverlayText(e.target.value)}
                  className="w-full bg-[#050e1a] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-blue-500" 
                />
              </div>
            </div>
          </div>

          <button 
            type="button"
            onClick={handleStartRender}
            disabled={rendering}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
          >
            {rendering ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Rendering 9:16 Showreel Video...</span>
              </>
            ) : (
              <>
                <Settings className="w-4 h-4" />
                <span>Generate Custom Topic Showreel</span>
              </>
            )}
          </button>
        </div>

        {/* Video Preview Canvas & Keep/Discard Controls */}
        <div className="lg:col-span-7 bg-[#0b1320] border border-white/10 rounded-3xl p-6 flex flex-col items-center justify-center min-h-[520px]">
          {!rendered && !rendering && (
            <div className="text-center opacity-60 space-y-3">
              <MonitorPlay className="w-16 h-16 text-slate-500 mx-auto" />
              <p className="text-xs text-slate-400 font-mono">
                Enter your topic, choose settings or upload a video, and click generate to preview.
              </p>
            </div>
          )}

          {rendering && (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs text-blue-400 font-mono font-bold animate-pulse">
                Encoding H.264 (9:16) Topic: "{customTopic}"
              </p>
            </div>
          )}

          {rendered && !rendering && (
            <div className="w-full max-w-sm mx-auto animate-fade-in space-y-5">
              <div className="text-center space-y-1">
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest font-bold">
                  ● Topic: {customTopic}
                </span>
                <p className="text-xs text-slate-300">
                  Preview video below. Choose <strong>Keep</strong> to enable download, or <strong>Discard</strong> to adjust settings.
                </p>
              </div>

              {/* Interactive 9:16 Video Player Container */}
              <div className="aspect-[9/16] bg-slate-950 rounded-3xl border-4 border-[#050e1a] relative overflow-hidden group shadow-2xl">
                {!videoError ? (
                  <video
                    key={selectedVideoUrl}
                    src={selectedVideoUrl}
                    autoPlay
                    loop
                    muted
                    playsInline
                    onError={() => setVideoError(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  /* Animated Motion Canvas Fallback if video is blocked/unsupported */
                  <div className="w-full h-full bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex flex-col items-center justify-center p-6 text-center space-y-4 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.2)_0,transparent_70%)] animate-pulse" />
                    
                    {/* Simulated Motion Graphic Elements */}
                    <div className="w-20 h-20 rounded-2xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-400 relative z-10 shadow-2xl">
                      <Sparkles className="w-10 h-10 animate-bounce" />
                    </div>

                    <div className="relative z-10 space-y-1">
                      <span className="text-[10px] font-mono uppercase text-[#D4AF37] tracking-widest font-bold block">
                        Interactive 9:16 UGC Preview
                      </span>
                      <h4 className="text-sm font-bold text-white font-serif">{customTopic}</h4>
                      <p className="text-[11px] text-slate-300 font-mono">
                        {metricOverlayText}
                      </p>
                    </div>

                    {/* Audio Wave Bars Simulation */}
                    <div className="flex items-end gap-1.5 h-8 pt-2 relative z-10">
                      <span className="w-1.5 bg-blue-400 rounded-full h-full animate-pulse" />
                      <span className="w-1.5 bg-emerald-400 rounded-full h-2/3 animate-pulse delay-75" />
                      <span className="w-1.5 bg-amber-400 rounded-full h-5/6 animate-pulse delay-150" />
                      <span className="w-1.5 bg-purple-400 rounded-full h-1/2 animate-pulse delay-100" />
                      <span className="w-1.5 bg-cyan-400 rounded-full h-full animate-pulse delay-200" />
                    </div>
                  </div>
                )}
                
                {/* Custom Metric Overlay */}
                {overlayStyle !== 'Clean Aesthetic Overlay' && (
                  <div className="absolute inset-x-0 bottom-16 p-4 text-center pointer-events-none z-20">
                    <div className="bg-black/80 backdrop-blur-md border border-white/20 p-3 rounded-2xl inline-block mx-auto space-y-1 shadow-2xl">
                      <span className="block text-xs font-mono font-bold text-white uppercase tracking-wider">
                        {customTopic}
                      </span>
                      <span className="block text-sm font-black text-[#D4AF37] italic">
                        {metricOverlayText}
                      </span>
                    </div>
                  </div>
                )}

                {/* Play / Mute Toggle Button */}
                <button
                  type="button"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="absolute top-4 right-4 bg-black/60 hover:bg-black/90 p-2 rounded-full text-white cursor-pointer transition border border-white/20 z-20"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
              </div>

              {/* Keep or Discard Decision Buttons */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={handleDiscard}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Discard Showreel</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleKeep}
                    className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-lg ${
                      keptStatus
                        ? 'bg-emerald-500 text-slate-950 font-black'
                        : 'bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-400'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{keptStatus ? 'Showreel Kept ✓' : 'Keep Showreel'}</span>
                  </button>
                </div>

                {/* Download enabled after Keep */}
                {keptStatus && (
                  <button
                    type="button"
                    onClick={handleDownload}
                    className="w-full bg-[#D4AF37] hover:bg-[#EBD287] text-[#0A1220] py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-2 shadow-xl animate-fade-in"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Final Showreel (.MP4)</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

