import React, { useState } from 'react';
import { ShieldCheck, ShieldAlert, BadgeAlert, Plus, CheckCircle, RefreshCw, Send, HelpCircle, Code, AlignLeft, Music, FileText } from 'lucide-react';

import { Creator } from '../types';
import CopyrightAudioScanner from './CopyrightAudioScanner';
import { safeStorage } from '../utils/safeStorage';

interface CaptionCheck {
  id: string;
  creator: string;
  brand: string;
  caption: string;
  status: 'Safe' | 'Flagged' | 'Fixed';
  issues: string[];
}

interface FtcComplianceProps {
  creators?: Creator[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'warning' | 'info' | 'danger') => void;
}

export default function FtcCompliance({ creators, currentUser, currentRole, onAddActivityLog, triggerNotification }: FtcComplianceProps) {
  const [activeTab, setActiveTab] = useState<'ftc' | 'copyright'>('ftc');
  const isAgentMgr = (currentRole || '').toLowerCase() === 'agentmgr';
  const isAgent = (currentRole || '').toLowerCase() === 'agent';
  const isRestrictedRole = isAgentMgr || isAgent;
  const mgrName = currentUser?.name || 'Marcus Cole';
  const myCreators = (creators || []).filter(c => 
    c.assignedAgent?.toLowerCase() === mgrName.toLowerCase() &&
    c.name.toLowerCase() !== mgrName.toLowerCase() &&
    c.handle.toLowerCase() !== (currentUser?.handle || '').toLowerCase()
  );
  const myHandles = myCreators.map(c => c.handle.toLowerCase());
  const [captionsLedger, setCaptionsLedger] = useState<CaptionCheck[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_ftc_captions_ledger');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  React.useEffect(() => {
    try {
      safeStorage.setItem('wl_ftc_captions_ledger', JSON.stringify(captionsLedger));
    } catch (e) {}
  }, [captionsLedger]);

  // Persistent Audit History Log State
  const [auditHistory, setAuditHistory] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('ftc_audit_history');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Live text check state
  const [checkText, setCheckText] = useState('');
  const [liveScore, setLiveScore] = useState<number | null>(null);
  const [liveFindings, setLiveFindings] = useState<string[]>([]);
  const [isScanning, setIsScanning] = useState(false);

  const logVerifiedCompliance = async () => {
    if (!checkText.trim()) return;

    const auditData = {
      id: 'audit_' + Date.now(),
      auditedText: checkText,
      status: "approved_conspicuous",
      auditedBy: "Agency Compliance Officer",
      timestamp: new Date().toLocaleTimeString()
    };

    try {
      // Save locally to simulate db storage
      const updatedHistory = [auditData, ...auditHistory];
      setAuditHistory(updatedHistory);
      safeStorage.setItem('ftc_audit_history', JSON.stringify(updatedHistory));

      // Append to captions ledger as compliant
      const newLedgerItem: CaptionCheck = {
        id: 'cc_' + Date.now(),
        creator: '@alexjones', // auto allocated
        brand: 'Manual Audit',
        caption: checkText,
        status: 'Safe',
        issues: []
      };
      setCaptionsLedger(prev => [newLedgerItem, ...prev]);

      if (triggerNotification) {
        triggerNotification("⚖️ Audit Cleared", "Compliance tracking token committed permanently.", "info");
      } else {
        alert("⚖️ Audit Cleared: Compliance tracking token committed permanently.");
      }

      if (onAddActivityLog) {
        onAddActivityLog('Compliance Team', 'director', `Executed compliance audit logging for text: "${checkText.substring(0, 30)}..."`);
      }

      // Reset states
      setCheckText("");
      setLiveScore(null);
      setLiveFindings([]);
    } catch(err) {
      console.error("Logger block crashed:", err);
    }
  };

  const handleScanText = () => {
    if (!checkText.trim()) return;
    setIsScanning(true);
    setLiveScore(null);

    setTimeout(() => {
      const lowercase = checkText.toLowerCase();
      const findings: string[] = [];
      let score = 100;

      // Check for ad / sponsorship hashtags
      const hasAdTag = lowercase.includes('#ad') || lowercase.includes('#sponsored') || lowercase.includes('#paid') || lowercase.includes('#partnership');
      if (!hasAdTag) {
        findings.push('CRITICAL: Missing explicit disclosure hashtag (#ad, #sponsored, #paidpartnership).');
        score -= 50;
      } else {
        // Check if hashtags are hidden at the very bottom
        const lines = checkText.split('\n');
        const lastFewLines = lines.slice(-2).join(' ').toLowerCase();
        const hasAdAtBottom = lastFewLines.includes('#ad') || lastFewLines.includes('#sponsored');
        if (hasAdAtBottom && lines.length > 3) {
          findings.push('WARNING: Disclosure tag is buried at the bottom. FTC requires disclosure "above the fold" or visible in first 2 lines.');
          score -= 20;
        }
      }

      // Check for clear sponsor name
      const mentionsBrand = checkText.match(/#[a-zA-Z0-9]+/g);
      if (!mentionsBrand) {
        findings.push('INFO: Caption does not seem to tag any brand handle or hashtag.');
        score -= 10;
      }

      setLiveScore(score);
      setLiveFindings(findings);
      setIsScanning(false);
    }, 1200);
  };

  const handleAutoFixLive = () => {
    if (!checkText.trim()) return;
    const cleanText = checkText.replace(/#ad|#sponsored/gi, '').trim();
    const fixed = `#ad ${cleanText}`;
    setCheckText(fixed);
    setLiveScore(100);
    setLiveFindings([]);
  };

  const handleFixLedgerItem = (id: string) => {
    setCaptionsLedger(prev => prev.map(item => {
      if (item.id === id) {
        return {
          ...item,
          caption: `#ad ${item.caption}`,
          status: 'Fixed',
          issues: []
        };
      }
      return item;
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="relative bg-gradient-to-br from-[#111E33] to-[#0D1830] border border-[#rgba(201,164,106,0.14)] rounded-2xl p-6 overflow-hidden">
        <div className="absolute -top-1/4 -right-10 w-64 h-64 bg-radial-gradient(circle,rgba(201,164,106,0.06)_0%,transparent_70%) pointer-events-none"></div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] text-[#C9A46A] font-bold uppercase tracking-wider">
              Legal &amp; Compliance Hub
            </span>
            <h1 className="font-serif font-semibold text-2xl md:text-3xl text-white mt-1.5">
              Legal Compliance &amp; Media Protection Desk
            </h1>
            <p className="text-xs text-[#7C8AA8] mt-1 leading-relaxed">
              Scan caption copy for FTC disclosure compliance or check raw video drafts for unlicensed audio tracks and competitor logos.
            </p>
          </div>

          {/* Sub-tab Navigation */}
          <div className="flex items-center gap-1.5 bg-[#050e1a] p-1 rounded-xl border border-white/10 shrink-0">
            <button
              onClick={() => setActiveTab('ftc')}
              className={`px-3.5 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition cursor-pointer ${
                activeTab === 'ftc'
                  ? 'bg-agency-gold text-agency-navy'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>FTC Copy Scanner</span>
            </button>

            <button
              onClick={() => setActiveTab('copyright')}
              className={`px-3.5 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition cursor-pointer ${
                activeTab === 'copyright'
                  ? 'bg-agency-gold text-agency-navy'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Music className="w-3.5 h-3.5" />
              <span>AI Copyright &amp; Sound Scanner</span>
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'copyright' ? (
        <CopyrightAudioScanner />
      ) : (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Interactive Caption Testing Box */}
        <div className="lg:col-span-6 bg-[#0D1830] border border-white/5 rounded-2xl p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
              <Code className="text-[#C9A46A] w-5 h-5" /> Live Copy Scanner
            </h3>
            <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
              Paste copy or drafts below to scan the disclosure positioning, contrast tags, and FTC alignment scores.
            </p>

            <div className="space-y-1.5">
              <textarea
                placeholder="Paste creator caption here to test..."
                rows={5}
                value={checkText}
                onChange={e => {
                  setCheckText(e.target.value);
                  setLiveScore(null);
                  setLiveFindings([]);
                }}
                className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3.5 text-xs text-white outline-none font-mono focus:border-[#C9A46A]/50"
              />
            </div>
          </div>

          <div className="flex justify-between items-center pt-2">
            <button
              onClick={handleAutoFixLive}
              disabled={!checkText.trim() || liveScore === 100}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <AlignLeft className="w-3.5 h-3.5" /> Auto-insert #ad disclosure
            </button>
            <button
              onClick={handleScanText}
              disabled={!checkText.trim() || isScanning}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] disabled:opacity-50 text-[#0A1220] px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors font-mono"
            >
              {isScanning ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Scanning...
                </>
              ) : (
                <>
                  Analyze Copy &rarr;
                </>
              )}
            </button>
          </div>

          {/* Results Score Box */}
          {liveScore !== null && (
            <div className="bg-[#111E33] border border-white/5 rounded-xl p-4 mt-2 space-y-3 animate-fade-in">
              <div className="flex justify-between items-center">
                <span className="text-xs text-[#7C8AA8] uppercase font-semibold">Compliance Rating score</span>
                <span className={`text-base font-bold ${liveScore >= 80 ? 'text-emerald-400' : liveScore >= 50 ? 'text-amber-400' : 'text-rose-400'}`}>
                  {liveScore} / 100
                </span>
              </div>

              {liveFindings.length === 0 ? (
                <div className="space-y-3">
                  <div className="text-[11px] text-emerald-400 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 shrink-0" /> Safe for publishing! FTC guidelines perfectly respected.
                  </div>
                  <button
                    onClick={logVerifiedCompliance}
                    className="w-full mt-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] py-2 rounded-xl text-xs font-bold transition-all"
                  >
                    Log Verified Compliance &amp; Commit Token
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    {liveFindings.map((finding, idx) => (
                      <div key={idx} className="text-[11px] text-amber-400 flex items-start gap-2 leading-relaxed">
                        <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                        <span>{finding}</span>
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={logVerifiedCompliance}
                    className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 py-2 rounded-xl text-xs font-semibold transition-all"
                  >
                    Force Log Audit Token (Acknowledge Risks)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Caption Audit Ledger */}
        <div className="lg:col-span-6 bg-[#0D1830] border border-white/5 rounded-2xl p-5 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="font-serif font-medium text-lg text-white border-b border-white/5 pb-2">
              Caption Compliance Audit Ledger
            </h3>

            <div className="space-y-3.5 max-h-[360px] overflow-y-auto pr-1">
              {captionsLedger.filter(item => !isRestrictedRole || myHandles.includes(item.creator.toLowerCase())).map(item => (
                <div key={item.id} className="p-3.5 bg-[#111E33] border border-white/5 rounded-xl space-y-2">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-semibold text-xs text-white block">{item.creator} &middot; {item.brand}</span>
                    </div>
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                      item.status === 'Safe' ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/20' :
                      item.status === 'Fixed' ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/20' :
                      'bg-rose-950 text-rose-400 border border-rose-500/20'
                    }`}>
                      {item.status}
                    </span>
                  </div>

                  <p className="text-[11px] text-[#7C8AA8] italic leading-relaxed font-mono truncate">{item.caption}</p>

                  {item.issues.length > 0 ? (
                    <div className="space-y-1.5 pt-1">
                      {item.issues.map((issue, idx) => (
                        <div key={idx} className="text-[10px] text-rose-400 flex items-center gap-1">
                          <BadgeAlert className="w-3.5 h-3.5 shrink-0" /> {issue}
                        </div>
                      ))}
                      <button
                        onClick={() => handleFixLedgerItem(item.id)}
                        className="text-[10px] text-[#C9A46A] hover:underline font-bold mt-1 block flex items-center gap-1"
                      >
                        &rarr; Apply compliance hashtag auto-fix
                      </button>
                    </div>
                  ) : (
                    <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" /> Fully Compliant
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-amber-950/10 border border-amber-500/20 p-3.5 rounded-xl text-[11px] text-[#C9A46A] mt-4">
            <p className="font-semibold flex items-center gap-1">
              <ShieldAlert className="w-4 h-4 text-amber-500" /> Compliance Fine Liability Warn
            </p>
            <p className="text-[#7C8AA8] mt-1">FTC disclosure rules impose fines of up to $46,000 per post on brands and creators for missing transparent commercial indicators.</p>
          </div>
        </div>
      </div>
      )}
    </div>
  );
}
