import React, { useState, useEffect } from 'react';
import { DollarSign, ShieldCheck, UserCheck, Lock, HelpCircle, Briefcase, FileText, CheckCircle2, Award, Plus, Trash2, Sliders, Info } from 'lucide-react';
import OwnerOverrideToggle from './OwnerOverrideToggle';
import { getStoredDirectorDelegation, saveStoredDirectorDelegation, DirectorDelegationSettings } from './DirectorDelegationControls';

export interface UserProfile {
  id?: string;
  uid?: string;
  name: string;
  email: string;
  role: 'Owner' | 'Manager' | 'Agent' | 'director' | 'agency' | 'agentmgr' | string;
  position?: string;
  managerCompensation?: {
    payType: 'Per Campaign' | 'Percentage' | 'Monthly Retainer';
    amount: number;
  };
}

export interface CampaignData {
  id: string;
  title: string;
  brand: string;
  creatorHandle: string;
  grossBrandContractValue: number;
  influencerPayout: number;
  deliverables: string[];
}

interface RoleGuardedCampaignWorkspaceProps {
  user: UserProfile;
  campaign?: CampaignData;
  creators?: any[];
  allCampaigns?: any[];
  onSelectCampaign?: (c: any) => void;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: 'success' | 'warning' | 'info' | 'danger') => void;
  delegationSettings?: DirectorDelegationSettings;
}

export default function RoleGuardedCampaignWorkspace({
  user,
  campaign = {
    id: 'cmp_new',
    title: '',
    brand: '',
    creatorHandle: '',
    grossBrandContractValue: 0,
    influencerPayout: 0,
    deliverables: [],
  },
  creators = [],
  allCampaigns = [],
  onSelectCampaign,
  onAddActivityLog,
  triggerNotification,
  delegationSettings: propDelegationSettings,
}: RoleGuardedCampaignWorkspaceProps) {
  // Local state for Owner View Toggle (simulating manager masking without altering DB)
  const [isManagerPreview, setIsManagerPreview] = useState<boolean>(false);

  // Director delegation settings state
  const [delegationSettings, setDelegationSettings] = useState<DirectorDelegationSettings>(() => {
    if (propDelegationSettings) return propDelegationSettings;
    return getStoredDirectorDelegation();
  });

  useEffect(() => {
    if (propDelegationSettings) {
      setDelegationSettings(propDelegationSettings);
    }
  }, [propDelegationSettings]);

  useEffect(() => {
    const handleUpdate = (e: any) => {
      if (e.detail) setDelegationSettings(e.detail);
    };
    window.addEventListener('director_delegation_updated', handleUpdate);
    return () => window.removeEventListener('director_delegation_updated', handleUpdate);
  }, []);

  // Synced form states - strictly set to zero / empty until logged
  const [managerEscrowPayout, setManagerEscrowPayout] = useState<number | string>(
    campaign.influencerPayout ? campaign.influencerPayout : 0
  );
  const [creatorNotes, setCreatorNotes] = useState<string>('');

  // Master Director form state - set to zero until logged
  const [brandContractVal, setBrandContractVal] = useState<number | string>(
    campaign.grossBrandContractValue ? campaign.grossBrandContractValue : 0
  );

  // Dynamic deliverables schedule state - starts empty for sequential building
  const [deliverablesList, setDeliverablesList] = useState<string[]>(
    campaign.deliverables && campaign.deliverables.length > 0
      ? campaign.deliverables
      : []
  );
  const [newDeliverableInput, setNewDeliverableInput] = useState<string>('');

  // Multi-campaign logging state & history log - starts empty until user logs
  const [loggedCampaigns, setLoggedCampaigns] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('wl_workspace_logged_campaigns_' + (user?.uid || user?.email || 'default'));
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return allCampaigns && allCampaigns.length > 0 ? allCampaigns : [];
  });

  const [newCampTitle, setNewCampTitle] = useState<string>('');
  const [newCampBrand, setNewCampBrand] = useState<string>('');
  const [newCampCreator, setNewCampCreator] = useState<string>('');
  const [newCampValue, setNewCampValue] = useState<number | string>(0);
  const [newCampPayout, setNewCampPayout] = useState<number | string>(0);
  const [newCampNotes, setNewCampNotes] = useState<string>('');
  const [showLogNewModal, setShowLogNewModal] = useState<boolean>(false);

  const handleLogNewCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canAddDeliverables) {
      triggerNotification?.('Restricted by Director', 'Campaign logging requires Director permission toggle.', 'warning');
      return;
    }
    if (!newCampTitle.trim() || !newCampBrand.trim()) {
      triggerNotification?.('Missing Fields', 'Please enter a campaign title and brand name.', 'warning');
      return;
    }
    const newItem = {
      id: 'cmp_' + Date.now(),
      title: newCampTitle.trim(),
      brand: newCampBrand.trim(),
      creatorHandle: newCampCreator.trim() || '@assigned_creator',
      grossBrandContractValue: Number(newCampValue) || 0,
      influencerPayout: Number(newCampPayout) || 0,
      deliverables: [...deliverablesList],
      loggedAt: new Date().toLocaleString(),
      status: 'Active',
      notes: newCampNotes.trim() || creatorNotes
    };

    const updated = [newItem, ...loggedCampaigns];
    setLoggedCampaigns(updated);
    try {
      localStorage.setItem('wl_workspace_logged_campaigns_' + (user?.uid || user?.email || 'default'), JSON.stringify(updated));
    } catch (err) {}

    setNewCampTitle('');
    setNewCampBrand('');
    setNewCampCreator('');
    setNewCampValue(0);
    setNewCampPayout(0);
    setNewCampNotes('');
    setDeliverablesList([]);
    setBrandContractVal(0);
    setManagerEscrowPayout(0);
    setShowLogNewModal(false);
    triggerNotification?.('Campaign Logged', `Successfully logged "${newItem.title}" for ${newItem.brand}.`, 'success');
    onAddActivityLog?.(user.name, user.role, `Logged campaign: ${newItem.title} (${newItem.brand})`);
    if (onSelectCampaign) {
      onSelectCampaign(newItem);
    }
  };

  const handleDeleteLoggedCampaign = (campId: string) => {
    const updated = loggedCampaigns.filter(c => c.id !== campId);
    setLoggedCampaigns(updated);
    try {
      localStorage.setItem('wl_workspace_logged_campaigns_' + (user?.uid || user?.email || 'default'), JSON.stringify(updated));
    } catch (err) {}
    triggerNotification?.('Campaign Removed', 'Campaign entry deleted from workspace log.', 'info');
  };

  // Computed effective view permission: Director, Owner, Agency have full executive privileges
  const normRole = (user?.role || '').toLowerCase();
  const isOwner = ['owner', 'director', 'agency', 'admin', 'principal'].includes(normRole);
  const isAgentMgr = normRole === 'agentmgr' || normRole.includes('manager') || isManagerPreview;

  // Permission calculation: Can Agent Manager add deliverables?
  // When restricted, the add deliverable button should not show.
  const canAddDeliverables = isOwner && !isManagerPreview ? true : delegationSettings.agentManagerCanAddCampaigns;

  const handleAddDeliverable = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canAddDeliverables) {
      if (triggerNotification) {
        triggerNotification('Restricted by Director', 'Agent Manager deliverable scheduling requires Director permission.', 'warning');
      }
      return;
    }
    if (!newDeliverableInput.trim()) return;
    setDeliverablesList(prev => [...prev, newDeliverableInput.trim()]);
    setNewDeliverableInput('');
  };

  const handleRemoveDeliverable = (indexToRemove: number) => {
    if (!canAddDeliverables) {
      if (triggerNotification) {
        triggerNotification('Restricted by Director', 'Removing deliverables requires Director permission.', 'warning');
      }
      return;
    }
    setDeliverablesList(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleToggleDirectorSwitch = () => {
    const updated = {
      ...delegationSettings,
      agentManagerCanAddCampaigns: !delegationSettings.agentManagerCanAddCampaigns,
    };
    setDelegationSettings(updated);
    saveStoredDirectorDelegation(updated);
    if (triggerNotification) {
      triggerNotification(
        'Director Permission Updated',
        `Agent Manager Campaign & Deliverable Creation is now ${updated.agentManagerCanAddCampaigns ? 'ENABLED' : 'DISABLED'}.`,
        updated.agentManagerCanAddCampaigns ? 'success' : 'warning'
      );
    }
    if (onAddActivityLog) {
      onAddActivityLog(
        user.name,
        user.role,
        `Toggled Agent Manager Campaign & Deliverable access to ${updated.agentManagerCanAddCampaigns ? 'ENABLED' : 'DISABLED'}`
      );
    }
  };
  const showOwnerFinancials = isOwner && !isManagerPreview;

  const numBrand = Number(brandContractVal) || 0;
  const numPayout = Number(managerEscrowPayout) || 0;
  const agencyMargin = Math.max(0, numBrand - numPayout);

  const formatUSD = (val: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  return (
    <div className="bg-[#0D1830] border border-[#C9A46A]/30 rounded-3xl p-6 md:p-8 shadow-2xl text-white space-y-6 max-w-5xl mx-auto">
      {/* Top Header with Role Status & Owner Override Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-[#C9A46A] bg-[#111E33] border border-[#C9A46A]/30 px-3 py-0.5 rounded-full flex items-center gap-1">
              <Award className="w-3 h-3" />
              {showOwnerFinancials ? 'Director / Owner Admin Workspace' : 'Manager Operations Workspace'}
            </span>
            <span className="text-xs text-[#7C8AA8] font-mono">
              Active: <strong className="text-white">{user.name}</strong> ({user.role})
            </span>
          </div>
          <h2 className="font-serif font-bold text-xl md:text-2xl text-white mt-1.5">
            {campaign.title} &bull; <span className="text-[#C9A46A]">{campaign.brand}</span>
          </h2>
          <p className="text-xs text-[#7C8AA8] mt-0.5">
            Assigned Talent: <strong className="text-white">{campaign.creatorHandle}</strong>
          </p>
        </div>

        {/* OWNER OVERRIDE TOGGLE */}
        {isOwner && (
          <OwnerOverrideToggle
            userRole={user.role}
            isManagerPreview={isManagerPreview}
            onToggleManagerPreview={setIsManagerPreview}
          />
        )}
      </div>

      {/* DIRECTOR SWITCH CARD (Always visible to Director; indicates status to Manager) */}
      <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#C9A46A]" />
            <span className="text-xs font-mono font-bold uppercase text-white tracking-wider">
              Director Switch: Agent Manager Campaign &amp; Deliverable Access
            </span>
            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
              delegationSettings.agentManagerCanAddCampaigns 
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
            }`}>
              {delegationSettings.agentManagerCanAddCampaigns ? 'Authorized' : 'Restricted by Director'}
            </span>
          </div>
          <p className="text-xs text-slate-300">
            {isOwner && !isManagerPreview 
              ? 'As Director, you control whether Agent Managers can add campaigns or create deliverables. When toggled OFF, the "Add Deliverable" button will not show for them.'
              : delegationSettings.agentManagerCanAddCampaigns
                ? 'Director has granted you permission to add deliverables and schedule campaign commitments.'
                : 'Director has restricted campaign creation and deliverable scheduling. The "+ Add Deliverable" button is hidden until authorized.'
            }
          </p>
        </div>

        {isOwner && !isManagerPreview && (
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-xs font-mono text-slate-400">
              {delegationSettings.agentManagerCanAddCampaigns ? 'Granted' : 'Locked'}
            </span>
            <button
              type="button"
              id="switch-director-campaign-deliverables"
              onClick={handleToggleDirectorSwitch}
              className={`relative inline-flex h-7 w-14 items-center rounded-full transition-colors cursor-pointer focus:outline-none ${
                delegationSettings.agentManagerCanAddCampaigns ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
              title="Toggle Agent Manager campaign & deliverable permission"
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                  delegationSettings.agentManagerCanAddCampaigns ? 'translate-x-8' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        )}
      </div>

      {/* =========================================================================
          CONDITIONAL 1: OWNER / DIRECTOR FINANCIAL WORKSPACE
         ========================================================================= */}
      {showOwnerFinancials ? (
        <div className="space-y-5 animate-fade-in">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#C9A46A] uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-[#C9A46A]" />
            <span>Director Unmasked Master P&amp;L Controls</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Input 1: Gross Brand Contract Value */}
            <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4 space-y-2">
              <label className="text-[11px] font-mono uppercase text-[#7C8AA8] block">
                Total Brand Invoiced Fee ($)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-[#7C8AA8] font-mono">$</span>
                <input
                  type="number"
                  value={brandContractVal}
                  onChange={(e) => setBrandContractVal(e.target.value)}
                  className="w-full bg-[#0D1830] border border-white/10 rounded-xl py-2 pl-7 pr-3 text-sm font-mono text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>
              <span className="text-[10px] text-[#7C8AA8] block">
                Full contract value invoiced to brand.
              </span>
            </div>

            {/* Input 2: Manager Escrow Payout (Synced) */}
            <div className="bg-[#111E33] border border-white/10 rounded-2xl p-4 space-y-2">
              <label className="text-[11px] font-mono uppercase text-[#7C8AA8] block">
                Manager Escrow ($)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-[#7C8AA8] font-mono">$</span>
                <input
                  type="number"
                  value={managerEscrowPayout}
                  onChange={(e) => setManagerEscrowPayout(e.target.value)}
                  className="w-full bg-[#0D1830] border border-white/10 rounded-xl py-2 pl-7 pr-3 text-sm font-mono text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <span className="text-[10px] text-[#7C8AA8] block">
                Guaranteed manager &amp; fulfillment escrow payout.
              </span>
            </div>

            {/* Read-Only Computed Net Agency Margin */}
            <div className="bg-[#111E33] border border-[#C9A46A]/50 rounded-2xl p-4 space-y-1 relative overflow-hidden">
              <span className="text-[11px] font-mono uppercase text-[#C9A46A] block font-bold">
                Director Retained Margin ($)
              </span>
              <div className="text-2xl font-bold font-mono text-[#C9A46A] pt-1">
                {formatUSD(agencyMargin)}
              </div>
              <p className="text-[10px] text-slate-300 font-mono">
                {numBrand > 0 ? ((agencyMargin / numBrand) * 100).toFixed(1) : 0}% Net retained agency yield.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* =========================================================================
           CONDITIONAL 2: MANAGER / STAFF WORKSPACE (Financial Data Masked)
           ========================================================================= */
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
            <UserCheck className="w-4 h-4 text-slate-400" />
            <span>Fulfillment Operations (Financial Data Masked)</span>
          </div>

          <div className="bg-[#111E33] border border-white/10 rounded-2xl p-5 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] font-mono uppercase text-[#7C8AA8] block mb-1">
                  Manager Escrow Payout ($)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-[#7C8AA8] font-mono">$</span>
                  <input
                    type="number"
                    value={managerEscrowPayout}
                    onChange={(e) => setManagerEscrowPayout(e.target.value)}
                    className="w-full bg-[#0D1830] border border-white/10 rounded-xl py-2 pl-7 pr-3 text-sm font-mono text-emerald-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <span className="text-[10px] text-[#7C8AA8] block mt-1">
                  Synced escrow allocation for this campaign fulfillment.
                </span>
              </div>

              <div>
                <label className="text-[11px] font-mono uppercase text-[#7C8AA8] block mb-1">
                  Assigned Deliverables
                </label>
                <div className="text-xs font-mono text-slate-300 bg-[#0D1830] border border-white/10 p-2.5 rounded-xl">
                  {deliverablesList.join(', ') || 'No deliverables scheduled yet'}
                </div>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-mono uppercase text-[#7C8AA8] block mb-1">
                Internal Creator Production Guidelines &amp; Notes
              </label>
              <textarea
                value={creatorNotes}
                onChange={(e) => setCreatorNotes(e.target.value)}
                rows={2}
                className="w-full bg-[#0D1830] border border-white/10 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Deliverable Checkpoints & Deliverables Repository */}
      <div className="bg-[#111E33] border border-white/10 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-300 font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#C9A46A]" />
            Deliverables Schedule ({deliverablesList.length})
          </span>
          <span className="text-[11px] font-mono text-emerald-400">
            Escrow Guarded
          </span>
        </div>

        {/* Dynamic Deliverable Adder for Director / Manager
            User requirement: "when they can't the add deliverable button should not show"
        */}
        {canAddDeliverables ? (
          <form onSubmit={handleAddDeliverable} className="flex gap-2 animate-fade-in">
            <input
              type="text"
              value={newDeliverableInput}
              onChange={(e) => setNewDeliverableInput(e.target.value)}
              placeholder="Add new deliverable (e.g. 1x 30s TikTok Spark Ad, Raw 4K Footage)..."
              className="flex-1 bg-[#0D1830] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A46A]"
            />
            <button
              type="submit"
              id="btn-add-deliverable"
              className="px-4 py-2 bg-[#C9A46A] hover:brightness-110 text-[#070D18] font-bold text-xs rounded-xl flex items-center gap-1 transition shadow cursor-pointer shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Deliverable</span>
            </button>
          </form>
        ) : (
          <div className="p-3.5 bg-[#0D1830] border border-amber-500/30 rounded-xl flex items-center justify-between text-xs text-amber-200">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Deliverables Locked:</strong> The Director has not enabled deliverable modification for the Agent Manager. The "Add Deliverable" button is hidden.
              </span>
            </div>
            <span className="text-[10px] font-mono text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/30 shrink-0">
              Director Switch Required
            </span>
          </div>
        )}

        {/* Rendered Deliverables List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
          {deliverablesList.length === 0 ? (
            <div className="col-span-full py-4 text-center text-xs text-slate-400 font-mono bg-[#0D1830] rounded-xl border border-white/5">
              No deliverables scheduled. Use the form above to add deliverables.
            </div>
          ) : (
            deliverablesList.map((deliv, index) => (
              <div key={index} className="bg-[#0D1830] border border-white/5 p-3 rounded-xl flex items-center justify-between gap-2.5 text-xs text-slate-300 group hover:border-white/20 transition">
                <div className="flex items-center gap-2 truncate">
                  <CheckCircle2 className="w-4 h-4 text-[#C9A46A] shrink-0" />
                  <span className="truncate">{deliv}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveDeliverable(index)}
                  className="opacity-60 hover:opacity-100 text-rose-400 p-1 hover:bg-rose-950/40 rounded transition cursor-pointer shrink-0"
                  title="Remove deliverable"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* =========================================================================
          MULTI-CAMPAIGN LOGGING & PERSISTENT HISTORY LOG SECTION
          ========================================================================= */}
      <div className="bg-[#111E33] border border-[#C9A46A]/30 rounded-2xl p-5 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-[#C9A46A]" />
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Multi-Campaign Logging &amp; Workspace History ({loggedCampaigns.length})
              </h3>
            </div>
            <p className="text-xs text-[#7C8AA8] mt-0.5">
              Log multiple campaigns and track everything logged in real time on this page.
            </p>
          </div>

          {canAddDeliverables ? (
            <button
              type="button"
              onClick={() => setShowLogNewModal(!showLogNewModal)}
              className="px-4 py-2 bg-[#C9A46A] hover:brightness-110 text-[#070D18] font-bold text-xs rounded-xl flex items-center gap-1.5 transition shadow cursor-pointer shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>{showLogNewModal ? 'Close Form' : '+ Log Another Campaign'}</span>
            </button>
          ) : (
            <span className="text-[11px] font-mono text-amber-400 bg-amber-950/30 px-3 py-1.5 rounded-xl border border-amber-500/20">
              🔒 Campaign Logging Restricted (Awaiting Director Permission Toggle)
            </span>
          )}
        </div>

        {/* Collapsible Log New Campaign Form */}
        {showLogNewModal && canAddDeliverables && (
          <form onSubmit={handleLogNewCampaign} className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-xl p-4 space-y-4 animate-fade-in">
            <h4 className="text-xs font-mono font-bold uppercase text-[#C9A46A] flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5" /> Log New Campaign Entry
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className="text-[10px] font-mono uppercase text-[#7C8AA8] block mb-1">Campaign Title *</label>
                <input
                  type="text"
                  required
                  value={newCampTitle}
                  onChange={(e) => setNewCampTitle(e.target.value)}
                  placeholder="e.g. Winter Glow Up Launch"
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-[#7C8AA8] block mb-1">Brand Name *</label>
                <input
                  type="text"
                  required
                  value={newCampBrand}
                  onChange={(e) => setNewCampBrand(e.target.value)}
                  placeholder="e.g. Sephora Beauty"
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-[#7C8AA8] block mb-1">Creator Handle</label>
                <input
                  type="text"
                  value={newCampCreator}
                  onChange={(e) => setNewCampCreator(e.target.value)}
                  placeholder="e.g. @sarahstyle"
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>

              {showOwnerFinancials && (
                <div>
                  <label className="text-[10px] font-mono uppercase text-[#7C8AA8] block mb-1">Gross Contract Value ($)</label>
                  <input
                    type="number"
                    value={newCampValue}
                    onChange={(e) => setNewCampValue(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
              )}

              <div>
                <label className="text-[10px] font-mono uppercase text-[#7C8AA8] block mb-1">Manager Escrow Payout ($)</label>
                <input
                  type="number"
                  value={newCampPayout}
                  onChange={(e) => setNewCampPayout(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-[#7C8AA8] block mb-1">Notes / Guidelines</label>
                <input
                  type="text"
                  value={newCampNotes}
                  onChange={(e) => setNewCampNotes(e.target.value)}
                  placeholder="Optional campaign notes..."
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A46A]"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowLogNewModal(false)}
                className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-mono transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#C9A46A] hover:brightness-110 text-[#070D18] font-bold text-xs font-mono transition shadow cursor-pointer"
              >
                Commit Campaign Log →
              </button>
            </div>
          </form>
        )}

        {/* Persistent Campaign History Log List */}
        <div className="space-y-3">
          {loggedCampaigns.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400 font-mono bg-[#0D1830] rounded-xl border border-white/5">
              No campaigns logged in workspace history. Click "+ Log Another Campaign" above to add entries.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2.5">
              {loggedCampaigns.map((c) => (
                <div
                  key={c.id}
                  className="bg-[#0D1830] border border-white/10 hover:border-[#C9A46A]/50 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-white font-serif">{c.title}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#C9A46A]/20 text-[#C9A46A] border border-[#C9A46A]/30">
                        {c.brand}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        Talent: <strong className="text-slate-200">{c.creatorHandle}</strong>
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
                      <span>Logged: {c.loggedAt || 'Just now'}</span>
                      {showOwnerFinancials && c.grossBrandContractValue > 0 && (
                        <span className="text-amber-300">Contract: {formatUSD(c.grossBrandContractValue)}</span>
                      )}
                      <span className="text-emerald-400">Payout: {formatUSD(c.influencerPayout || 500)}</span>
                      {c.deliverables && (
                        <span className="text-slate-300">• {c.deliverables.length} Deliverable(s)</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        if (onSelectCampaign) onSelectCampaign(c);
                        triggerNotification?.('Campaign Selected', `Loaded "${c.title}" into active workspace.`, 'info');
                      }}
                      className="px-3 py-1.5 bg-white/5 hover:bg-[#C9A46A]/20 text-slate-200 hover:text-[#C9A46A] border border-white/10 rounded-lg text-xs font-mono transition cursor-pointer"
                    >
                      Load into Workspace
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteLoggedCampaign(c.id)}
                      className="p-1.5 text-rose-400 hover:bg-rose-950/40 rounded-lg transition cursor-pointer"
                      title="Delete campaign log entry"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
