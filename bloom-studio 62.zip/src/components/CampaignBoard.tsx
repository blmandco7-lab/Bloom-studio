import React, { useState } from 'react';
import { 
  Plus, Clock, CheckCircle, AlertTriangle, FileText, Layers, User, 
  Folder, Calendar, ChevronRight, Info, ShieldAlert, CheckSquare, ListTodo, Lock, Target, Trash2, DollarSign, Users, Eye
} from 'lucide-react';
import DeleteConfirmationModal, { DeleteConfirmConfig } from './DeleteConfirmationModal';
import ManualFinancialInputs, { CampaignFinancials } from './ManualFinancialInputs';
import { db, setDoc, doc, deleteDoc, cleanForFirestore } from '../lib/firebase';
import { moveToTrash } from '../lib/trashService';
import { safeStorage } from '../utils/safeStorage';

export interface Campaign {
  id: string;
  name: string;
  brand: string;
  creator: string;
  assignedCoordinator: string;
  stage: 'Brief' | 'Draft' | 'Agency Review' | 'Brand 48hr Review' | 'Content Library' | 'Live' | 'Brand Review' | 'Revisions' | 'Approved' | 'Report';
  deadline: string;
  deliverables: string[];
  completedDeliverables: string[];
  statusFlags: string[];
  value: number; // hidden from Campaign Coordinator
  financials?: CampaignFinancials;
  subagency?: string;
  tenantId?: string;
  creatorAcceptanceStatus?: 'Pending' | 'Accepted' | 'Declined';
  creatorDeclinedReason?: string;
  creatorAcceptedAt?: string;
}

interface CampaignBoardProps {
  campaigns: Campaign[];
  setCampaigns: React.Dispatch<React.SetStateAction<Campaign[]>>;
  currentRole: string;
  currentUser: any;
  triggerNotification: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'danger') => void;
  creators: any[]; // To get selectable creators when creating/assigning
  canLogCampaigns?: boolean;
  canCreateMissions?: boolean;
  onNavigate?: (screen: string) => void;
}

const STAGES: string[] = ['Brief', 'Draft', 'Agency Review', 'Brand 48hr Review', 'Content Library', 'Live'];

export default function CampaignBoard({ 
  campaigns, 
  setCampaigns, 
  currentRole, 
  currentUser, 
  triggerNotification,
  creators,
  canLogCampaigns = false,
  canCreateMissions = false,
  onNavigate
}: CampaignBoardProps) {
  const isCoordinator = currentRole.toLowerCase() === 'coordinator';
  const isDirector = currentRole.toLowerCase() === 'director';
  const isAgentMgr = currentRole.toLowerCase() === 'agentmgr' || currentRole.toLowerCase() === 'agent';
  const canModify = isDirector || isCoordinator;
  
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showMissionModal, setShowMissionModal] = useState(false);
  const [showDefinitionsTray, setShowDefinitionsTray] = useState(false);
  const [agentMgrView, setAgentMgrView] = useState<'all' | 'my'>('my');
  const [suggestModalCampaign, setSuggestModalCampaign] = useState<Campaign | null>(null);
  const [suggestSelectedCreator, setSuggestSelectedCreator] = useState<string>('');
  const [suggestNote, setSuggestNote] = useState<string>('');
  
  // Modal form states
  const [newName, setNewName] = useState('');
  const [newBrand, setNewBrand] = useState('');
  const [selectedCreators, setSelectedCreators] = useState<string[]>([]);
  const [newCoordinator, setNewCoordinator] = useState('Campaign Lead');
  const [newDeadline, setNewDeadline] = useState('2026-08-15');
  const [newValue, setNewValue] = useState(3000);
  const [newDeliverablesText, setNewDeliverablesText] = useState('Record draft, Submit review, Verify FTC disclosure, Live post');

  // Launch Mission form state
  const [missionTitle, setMissionTitle] = useState('');
  const [missionBrand, setMissionBrand] = useState('');
  const [missionPlatform, setMissionPlatform] = useState('TikTok');
  const [missionSlots, setMissionSlots] = useState(3);
  const [missionBountyPerCreator, setMissionBountyPerCreator] = useState(750);
  const [missionGuidelines, setMissionGuidelines] = useState('Include 60s product demo, mention promo code in caption, tag brand handle & FTC #ad disclosure');
  const [missionDeadline, setMissionDeadline] = useState('2026-09-01');

  // Inline Creator Selector & Decline modal state
  const [isEditingCreator, setIsEditingCreator] = useState(false);
  const [reassignCreatorHandle, setReassignCreatorHandle] = useState('');
  const [declineModalOpen, setDeclineModalOpen] = useState(false);
  const [declineReasonText, setDeclineReasonText] = useState('');

  // Compute myHandles for scoped filtering
  const mgrName = currentUser?.name || 'Agency Lead';
  const assignedCreators = (creators || []).filter(c => {
    const ag = (c.assignedAgent || '').toLowerCase();
    return ag === mgrName.toLowerCase() || ag === (currentUser?.handle || '').toLowerCase();
  });
  const myCreators = assignedCreators.length > 0 ? assignedCreators : (creators || []);
  const myHandles = Array.from(new Set(myCreators.map(c => (c.handle || '').toLowerCase()).filter(Boolean)));
  const myNames = Array.from(new Set(myCreators.map(c => (c.name || '').toLowerCase()).filter(Boolean)));

  // Filter campaigns
  const filteredCampaigns = campaigns.filter(c => {
    // 1. If Campaign Coordinator: only show their assigned campaigns, and apply self-exclusion
    if (isCoordinator) {
      const isAssigned = c.assignedCoordinator?.toLowerCase() === currentUser?.name?.toLowerCase();
      const isSelf = c.creator?.toLowerCase() === currentUser?.handle?.toLowerCase();
      return isAssigned && !isSelf;
    }
    // 2. If Creator: only show campaigns assigned to this creator's handle/name
    if (currentRole.toLowerCase() === 'creator') {
      const myHandle = (currentUser?.handle || creators?.[0]?.handle || '').toLowerCase();
      const myName = (currentUser?.name || creators?.[0]?.name || '').toLowerCase();
      const campaignCreators = (c.creator || '').split(',').map(s => s.trim().toLowerCase());
      return campaignCreators.some(h => h === myHandle || h.includes(myHandle) || (myName && h === myName));
    }
    // 3. If Agent or Agent Manager:
    if (isAgentMgr) {
      if (agentMgrView === 'all') {
        return true; // Browse all across agency
      }
      const campaignCreators = (c.creator || '').split(',').map(s => s.trim().toLowerCase());
      return campaignCreators.some(h => myHandles.includes(h) || myNames.some(mn => h.includes(mn) || mn.includes(h)));
    }
    // 4. Otherwise (Director/Agency), show all
    return true;
  });

  const handleToggleDeliverable = (campaignId: string, item: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        const alreadyDone = c.completedDeliverables.includes(item);
        const newCompleted = alreadyDone 
          ? c.completedDeliverables.filter(d => d !== item)
          : [...c.completedDeliverables, item];
        
        // Dynamic flags update based on checklist changes
        let updatedFlags = [...c.statusFlags];
        if (item.toLowerCase().includes('ftc') || item.toLowerCase().includes('disclosure')) {
          if (!alreadyDone) {
            updatedFlags = updatedFlags.filter(f => !f.toLowerCase().includes('ftc'));
          } else {
            if (!updatedFlags.includes('FTC disclosure missing')) {
              updatedFlags.push('FTC disclosure missing');
            }
          }
        }
        
        const updated = {
          ...c,
          completedDeliverables: newCompleted,
          statusFlags: updatedFlags,
          subagency: c.subagency || currentUser?.subagency || 'pod_main',
          tenantId: c.tenantId || currentUser?.tenantId || 'bloom_studio_default'
        };

        // Firestore Sync
        setDoc(doc(db, "studio-campaigns", campaignId), cleanForFirestore(updated), { merge: true }).catch(err => {
          console.warn("Failed to update campaign deliverable checklist in Firestore:", err);
        });

        setSelectedCampaign(prev => prev && prev.id === campaignId ? updated : prev);
        return updated;
      }
      return c;
    }));
    triggerNotification('Checklist Updated', 'Campaign deliverable progress updated successfully.', 'success');
  };

  const handleStageChange = (campaignId: string, newStage: Campaign['stage']) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        const updated = {
          ...c,
          stage: newStage,
          subagency: c.subagency || currentUser?.subagency || 'pod_main',
          tenantId: c.tenantId || currentUser?.tenantId || 'bloom_studio_default'
        };
        setDoc(doc(db, "studio-campaigns", campaignId), cleanForFirestore(updated), { merge: true }).catch(err => {
          console.warn("Failed to update campaign stage in Firestore:", err);
        });
        setSelectedCampaign(prev => prev && prev.id === campaignId ? updated : prev);
        return updated;
      }
      return c;
    }));
    triggerNotification('Campaign Stage Shifted', `Campaign shifted to ${newStage} stage.`, 'info');
  };

  const handleUpdateAssignedCreator = async (campaignId: string, newCreator: string) => {
    if (!newCreator) return;
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        const updatedFlags = (c.statusFlags || []).filter(f => !f.toLowerCase().includes('accepted') && !f.toLowerCase().includes('declined'));
        if (!updatedFlags.includes('Pending Creator Acceptance')) updatedFlags.push('Pending Creator Acceptance');
        const updated: Campaign = {
          ...c,
          creator: newCreator,
          creatorAcceptanceStatus: 'Pending',
          statusFlags: updatedFlags,
        };
        setDoc(doc(db, "studio-campaigns", campaignId), cleanForFirestore(updated), { merge: true }).catch(err => {
          console.warn("Failed to update creator in Firestore:", err);
        });
        setSelectedCampaign(prev => prev && prev.id === campaignId ? updated : prev);
        return updated;
      }
      return c;
    }));
    setIsEditingCreator(false);
    triggerNotification('Creator Assigned', `Campaign assigned to ${newCreator}. Creator acceptance pending.`, 'success');
  };

  const handleCreatorAcceptCampaign = async (campaignId: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        const updatedFlags = (c.statusFlags || []).filter(f => !f.toLowerCase().includes('pending') && !f.toLowerCase().includes('declined'));
        if (!updatedFlags.includes('Accepted by Creator')) updatedFlags.push('Accepted by Creator');
        const updated: Campaign = {
          ...c,
          creatorAcceptanceStatus: 'Accepted',
          creatorAcceptedAt: new Date().toISOString(),
          statusFlags: updatedFlags,
        };
        setDoc(doc(db, "studio-campaigns", campaignId), cleanForFirestore(updated), { merge: true }).catch(err => {
          console.warn("Failed to accept campaign in Firestore:", err);
        });
        setSelectedCampaign(prev => prev && prev.id === campaignId ? updated : prev);
        return updated;
      }
      return c;
    }));
    triggerNotification('Campaign Accepted!', `You have accepted the deal assignment for "${selectedCampaign?.name}". Director & Agent Manager notified!`, 'success');
  };

  const handleCreatorDeclineCampaign = async (campaignId: string, reason: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        const updatedFlags = (c.statusFlags || []).filter(f => !f.toLowerCase().includes('pending') && !f.toLowerCase().includes('accepted'));
        if (!updatedFlags.includes('Declined by Creator')) updatedFlags.push('Declined by Creator');
        const updated: Campaign = {
          ...c,
          creatorAcceptanceStatus: 'Declined',
          creatorDeclinedReason: reason || 'Schedule or rate mismatch',
          statusFlags: updatedFlags,
        };
        setDoc(doc(db, "studio-campaigns", campaignId), cleanForFirestore(updated), { merge: true }).catch(err => {
          console.warn("Failed to decline campaign in Firestore:", err);
        });
        setSelectedCampaign(prev => prev && prev.id === campaignId ? updated : prev);
        return updated;
      }
      return c;
    }));
    setDeclineModalOpen(false);
    setDeclineReasonText('');
    triggerNotification('Campaign Declined', `You declined "${selectedCampaign?.name}". Director & Agent Manager have been notified.`, 'info');
  };

  const handleAddCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newBrand || selectedCreators.length === 0) {
      triggerNotification('Missing Fields', 'Please fill in title, brand, and select at least 1 creator.', 'warning');
      return;
    }

    const newCamp: Campaign = {
      id: 'camp_' + Date.now(),
      name: newName,
      brand: newBrand,
      creator: selectedCreators.join(', '),
      assignedCoordinator: newCoordinator,
      stage: 'Brief',
      deadline: newDeadline,
      deliverables: newDeliverablesText.split(',').map(s => s.trim()).filter(Boolean),
      completedDeliverables: [],
      statusFlags: ['New Campaign', 'FTC disclosure missing'],
      value: Number(newValue),
      subagency: currentUser?.subagency || 'pod_main',
      tenantId: currentUser?.tenantId || 'bloom_studio_default'
    };

    setCampaigns(prev => [...prev, newCamp]);
    
    // Firestore Sync
    try {
      setDoc(doc(db, "studio-campaigns", newCamp.id), {
        ...newCamp,
        subagency: currentUser?.subagency || "pod_main",
        createdAt: new Date().toISOString()
      });
    } catch (err) {
      console.warn("Failed to sync new campaign to Firestore:", err);
    }

    setShowAddModal(false);
    triggerNotification('Campaign Dispatched', `New campaign "${newName}" assigned to ${selectedCreators.length} creator(s).`, 'success');

    // Reset fields
    setNewName('');
    setNewBrand('');
    setSelectedCreators([]);
    setNewDeadline('2026-08-15');
    setNewValue(3000);
    setNewDeliverablesText('Record draft, Submit review, Verify FTC disclosure, Live post');
  };

  const handleLaunchMission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!missionTitle || !missionBrand) {
      triggerNotification('Missing Details', 'Please fill in mission title and brand.', 'warning');
      return;
    }

    const totalBudget = Number(missionSlots) * Number(missionBountyPerCreator);
    const missionId = 'mission_' + Date.now();
    const newMission = {
      id: missionId,
      title: missionTitle,
      brand: missionBrand,
      platform: missionPlatform,
      slots: Number(missionSlots),
      filledSlots: 0,
      bountyPerCreator: Number(missionBountyPerCreator),
      totalBudget,
      guidelines: missionGuidelines,
      deadline: missionDeadline,
      status: 'Open for Roster Claim',
      createdAt: new Date().toISOString()
    };

    // Save to safeStorage for agency-wide persistence
    try {
      const storedMissions = JSON.parse(safeStorage.getItem('wl_missions') || '[]');
      storedMissions.unshift(newMission);
      safeStorage.setItem('wl_missions', JSON.stringify(storedMissions));
    } catch (e) {}

    // Save to Firestore open-casting-calls so multiple talent can audition/apply from Open Marketplace
    try {
      await setDoc(doc(db, 'open-casting-calls', missionId), {
        id: missionId,
        title: missionTitle,
        brand: missionBrand,
        category: 'UGC Campaign Blitz',
        platform: missionPlatform,
        budget: `$${missionBountyPerCreator.toLocaleString()} / Creator`,
        budgetValue: Number(missionBountyPerCreator),
        deadline: missionDeadline,
        spotsTotal: Number(missionSlots),
        spotsFilled: 0,
        deliverables: [`${missionPlatform} UGC Video`, 'FTC #ad disclosure', 'Raw Asset Upload'],
        requirements: missionGuidelines || 'High aesthetic lighting, authentic creator voice, FTC #ad disclosure.',
        description: `Multi-creator campaign mission launched by agency. Open for ${missionSlots} creators to pitch and claim.`,
        status: 'Open',
        verifiedBrand: true,
        featured: true,
        createdAt: new Date().toISOString(),
        subagency: currentUser?.subagency || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default'
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore open-casting-calls sync note:', err);
    }

    // Save to Firestore studio-missions
    try {
      await setDoc(doc(db, 'studio-missions', missionId), {
        ...newMission,
        subagency: currentUser?.subagency || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default'
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore studio-missions sync note:', err);
    }

    // Also auto-dispatch an active Campaign envelope so coordinators can track incoming submissions
    const newCamp: Campaign = {
      id: 'camp_' + Date.now(),
      name: `[Mission] ${missionTitle}`,
      brand: missionBrand,
      creator: `Open Roster Pool (${missionSlots} Slots Available)`,
      assignedCoordinator: 'Campaign Lead',
      stage: 'Brief',
      deadline: missionDeadline,
      deliverables: [`${missionPlatform} UGC Video`, 'FTC #ad disclosure', 'Raw Asset Upload'],
      completedDeliverables: [],
      statusFlags: ['Multi-Creator Mission', 'Bounty Active', 'Open in Marketplace'],
      value: totalBudget
    };

    setCampaigns(prev => [newCamp, ...prev]);

    try {
      await setDoc(doc(db, 'studio-campaigns', newCamp.id), {
        ...newCamp,
        subagency: currentUser?.subagency || 'pod_main',
        tenantId: currentUser?.tenantId || 'bloom_studio_default',
        createdAt: new Date().toISOString()
      }, { merge: true });
    } catch (err) {
      console.warn('Firestore studio-campaigns sync note:', err);
    }

    setShowMissionModal(false);
    triggerNotification(
      'Mission Launched Successfully',
      `"${missionTitle}" broadcasted to Open Marketplace & talent roster (${missionSlots} slots @ $${missionBountyPerCreator} bounty each).`,
      'success'
    );

    // Reset form
    setMissionTitle('');
    setMissionBrand('');
    setMissionSlots(3);
    setMissionBountyPerCreator(750);
  };

  const [deleteConfirmConfig, setDeleteConfirmConfig] = useState<DeleteConfirmConfig | null>(null);

  const handleDeleteCampaign = (id: string) => {
    const campaign = campaigns.find(c => c.id === id);
    if (!campaign) return;

    setDeleteConfirmConfig({
      isOpen: true,
      title: 'Terminate & Delete Campaign',
      itemName: `${campaign.name} (${campaign.brand})`,
      itemType: 'campaign',
      isPermanent: true,
      message: `Are you sure you want to delete and terminate "${campaign.name}"? All deliverables and milestones associated with this campaign will be removed.`,
      confirmButtonText: 'Delete Campaign',
      confirmButtonVariant: 'danger',
      onConfirm: async () => {
        setCampaigns(prev => prev.filter(c => c.id !== id));
        // Safe 30-Day Trash Bin Archive
        try {
          await moveToTrash("studio-campaigns", campaign, "campaign");
        } catch (err) {
          console.warn("Failed to move campaign to trash:", err);
        }
        setSelectedCampaign(null);
        triggerNotification('Campaign Moved to Trash', `Campaign "${campaign.name}" archived to Recoup Trash (30-day recovery window active).`, 'warning');
      }
    });
  };

  // Coordinator workload stats (No monetary metrics)
  const coordinatorCampaignCount = filteredCampaigns.length;

  return (
    <div className="space-y-6" id="campaign-board-view">
      {/* Header Widget */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#0D1830] border border-white/5 p-6 rounded-2xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xl">📋</span>
            <h1 className="text-xl font-serif font-semibold text-white">Campaign Execution Board</h1>
          </div>
          <p className="text-xs text-[#7C8AA8] leading-relaxed">
            {isCoordinator 
              ? `Manage and audit your active assigned deliverables and FTC disclosure compliance pipelines.`
              : `Create, allocate, and monitor active campaign workflows and brand deliverables.`}
          </p>
        </div>

        {isCoordinator && (
          <div className="p-4 bg-[#111E33] border border-[#C9A46A]/20 rounded-xl flex items-center gap-4 shrink-0">
            <div>
              <span className="text-[10px] text-[#7C8AA8] uppercase tracking-wider block font-mono">My Active Workload</span>
              <span className="text-sm font-bold text-white">{coordinatorCampaignCount} Campaigns</span>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => setShowDefinitionsTray(!showDefinitionsTray)}
            className="bg-[#111E33] hover:bg-[#16243F] text-[#C9A46A] border border-[#C9A46A]/30 text-xs font-semibold px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow cursor-pointer"
            title="View operational definitions for Campaigns, Missions, Casting Calls, Escrow and Metrics"
          >
            <Info className="w-4 h-4" />
            <span>Workflow &amp; Definitions Guide</span>
          </button>

          {!isCoordinator && (!isAgentMgr || canLogCampaigns) && canModify && (
            <button 
              onClick={() => setShowAddModal(true)}
              className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-xs font-semibold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-lg cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Campaign Setup
            </button>
          )}

          {!isCoordinator && (!isAgentMgr || canCreateMissions) && canModify && (
            <button 
              onClick={() => setShowMissionModal(true)}
              className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-semibold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-lg cursor-pointer"
            >
              <Target className="w-4 h-4" /> Launch Mission
            </button>
          )}
        </div>
      </div>

      {/* Operational Definitions and FAQs Tray */}
      {showDefinitionsTray && (
        <div className="bg-[#0D1830] border-2 border-[#C9A46A]/30 rounded-2xl p-5 space-y-4 animate-fade-in shadow-2xl">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <div className="flex items-center gap-2">
              <span className="text-base">📖</span>
              <h3 className="font-serif font-semibold text-base text-[#C9A46A]">Bloom Studio Operational Directory &amp; Terminology</h3>
            </div>
            <button
              onClick={() => setShowDefinitionsTray(false)}
              className="text-xs text-slate-400 hover:text-white px-2.5 py-1 bg-white/5 rounded-lg"
            >
              Close Guide
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* Launch Mission */}
            <div className="p-3.5 bg-[#111E33] border border-purple-500/20 rounded-xl space-y-1.5">
              <span className="font-bold text-purple-300 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5" /> Launch Mission
              </span>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Broadcasts an open multi-creator project with a fixed bounty per creator (e.g. 5 creators @ $750 each). Creators on your roster can claim open slots directly without requiring a bespoke 1-on-1 contract negotiation.
              </p>
            </div>

            {/* Select Campaign */}
            <div className="p-3.5 bg-[#111E33] border border-[#C9A46A]/20 rounded-xl space-y-1.5">
              <span className="font-bold text-[#C9A46A] flex items-center gap-1.5">
                <CheckSquare className="w-3.5 h-3.5" /> Select Campaign
              </span>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Clicking any campaign in the sidebar mounts its full execution workspace: deliverables checklist, FTC disclosure auditor, stage workflow switcher (Brief &rarr; Draft &rarr; Approved &rarr; Live), and revision notes.
              </p>
            </div>

            {/* Agency Content Library */}
            <div className="p-3.5 bg-[#111E33] border border-blue-500/20 rounded-xl space-y-1.5">
              <span className="font-bold text-blue-300 flex items-center gap-1.5">
                <Folder className="w-3.5 h-3.5" /> Catalog Deliverables
              </span>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                In the Content Library, "Catalog Deliverables" archives raw cuts, final MP4s, static photos, and usage rights for brand handoff. Assets are indexed with resolution tags, aspect ratios, and watermarks.
              </p>
            </div>

            {/* Roster & Metric Alert Scanning */}
            <div className="p-3.5 bg-[#111E33] border border-emerald-500/20 rounded-xl space-y-1.5">
              <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" /> Roster &amp; Metric Alerts
              </span>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                The platform monitors public social APIs and webhook feeds linked to each creator’s handle (@handle). When creators post to their own channels, the engine automatically tracks real-time views, likes, and engagement, alerting you if a post goes viral or drops below baseline.
              </p>
            </div>

            {/* Talent Onboarding & W9 Tracker */}
            <div className="p-3.5 bg-[#111E33] border border-amber-500/20 rounded-xl space-y-1.5">
              <span className="font-bold text-amber-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" /> Talent Onboarding &amp; W-9 Tracker
              </span>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Fully unified. When talent completes their digital onboarding form (W-9 / SSN &amp; Direct Deposit routing), it directly registers in the Director 1099 Tracker with a green "Verified" badge for year-end tax compliance.
              </p>
            </div>

            {/* Director Review Tray */}
            <div className="p-3.5 bg-[#111E33] border border-rose-500/20 rounded-xl space-y-1.5">
              <span className="font-bold text-rose-300 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5" /> Director Review Tray
              </span>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Intake submissions and creator contract drafts route directly to the <strong>Director Operations Desk &rarr; Review Tray</strong>. Only users logged in with the <em>Director</em> role have executive clearance to countersign and approve.
              </p>
            </div>

            {/* Casting Calls vs Missions vs Campaigns */}
            <div className="p-3.5 bg-[#111E33] border border-cyan-500/20 rounded-xl space-y-1.5 md:col-span-2">
              <span className="font-bold text-cyan-300 flex items-center gap-1.5">
                ⚖️ Casting Calls vs. Missions vs. Campaigns
              </span>
              <ul className="text-slate-300 leading-relaxed text-[11px] space-y-1 list-disc pl-4">
                <li><strong>Casting Calls:</strong> Open audition calls where multiple talent submit video reels and pitches to compete for a brand role.</li>
                <li><strong>Missions:</strong> First-come or pre-allocated group UGC blitzes where multiple creators execute uniform deliverables for a fixed payout bounty.</li>
                <li><strong>Campaigns:</strong> Bespoke, high-value 1-on-1 brand deals with customized schedules, dedicated coordinators, and milestone approvals.</li>
              </ul>
            </div>

            {/* Lock Brand Fund vs Invoice */}
            <div className="p-3.5 bg-[#111E33] border border-emerald-500/20 rounded-xl space-y-1.5">
              <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                💰 Lock Brand Fund (Escrow) vs. Invoice
              </span>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                <strong>Invoice:</strong> A post-service payment bill with standard Net 15/30 terms. <br/>
                <strong>Lock Brand Fund (Escrow):</strong> Requires the brand to deposit 100% of the funds upfront into agency escrow before production begins, securing creator payouts upon deliverable sign-off.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Agent Manager View Switcher - Disabled */}
      {/* Grid of campaigns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Campaign List Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="text-xs uppercase font-bold tracking-wider text-[#7C8AA8] font-mono">
            {isAgentMgr && agentMgrView === 'all' ? 'All Agency Campaigns (Browse Only)' : 'Assigned Campaigns'}
          </h3>
          {filteredCampaigns.length === 0 ? (
            <div className="p-6 bg-[#0D1830] border border-white/5 rounded-xl text-center">
              <span className="text-2xl block mb-2">📁</span>
              <p className="text-xs text-slate-400 font-medium">No assigned campaigns on your plate.</p>
              {isCoordinator && <p className="text-[10px] text-slate-500 mt-1 leading-relaxed">Self-exclusion or pending allocation may apply.</p>}
            </div>
          ) : (
            <div className="space-y-3 max-h-[600px] overflow-y-auto scrollbar-thin">
              {filteredCampaigns.map(c => {
                const isSelected = selectedCampaign?.id === c.id;
                const doneCount = c.completedDeliverables.length;
                const totalCount = c.deliverables.length;
                const pct = totalCount > 0 ? Math.round((doneCount / totalCount) * 100) : 0;
                
                return (
                  <div
                    key={c.id}
                    className={`w-full text-left p-4 rounded-xl border transition-all flex flex-col gap-3 ${
                      isSelected 
                        ? 'bg-[#111E33] border-[#C9A46A]/40 shadow-md' 
                        : 'bg-[#0D1830] border-white/5 hover:border-white/10'
                    }`}
                  >
                    <button
                      onClick={() => setSelectedCampaign(c)}
                      className="w-full text-left flex flex-col gap-3"
                    >
                      <div className="flex justify-between items-start w-full">
                        <div>
                          <span className="text-[10px] text-[#7C8AA8] font-mono block">{c.brand}</span>
                          <h4 className="text-xs font-semibold text-white truncate max-w-[150px]">{c.name}</h4>
                        </div>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                          isAgentMgr && agentMgrView === 'all'
                            ? c.creator && c.creator !== 'Unassigned' && c.creator.trim() !== ''
                              ? 'bg-slate-800 text-slate-300 border border-white/10'
                              : 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20'
                            : c.stage === 'Approved' || c.stage === 'Live' || c.stage === 'Report'
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20'
                            : c.stage === 'Revisions'
                            ? 'bg-amber-950/40 text-amber-400 border border-amber-500/20'
                            : 'bg-blue-950/40 text-blue-400 border border-blue-500/20'
                        }`}>
                          {isAgentMgr && agentMgrView === 'all'
                            ? c.creator && c.creator !== 'Unassigned' && c.creator.trim() !== '' ? 'Filled' : 'Open'
                            : c.stage}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-300">
                        <User className="w-3.5 h-3.5 text-[#C9A46A]" />
                        <span>Creator: <strong className="text-white">{c.creator}</strong></span>
                      </div>

                      {/* Progress Bar */}
                      <div className="space-y-1 w-full">
                        <div className="flex justify-between text-[10px] font-mono text-[#7C8AA8]">
                          <span>Tasks: {doneCount}/{totalCount}</span>
                          <span>{pct}%</span>
                        </div>
                        <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-[#C9A46A]" style={{ width: `${pct}%` }} />
                        </div>
                      </div>

                      {/* Flags */}
                      {c.statusFlags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {c.statusFlags.map((f, i) => (
                            <span key={i} className={`text-[9px] font-mono px-1.5 py-0.5 rounded flex items-center gap-1 ${
                              f.toLowerCase().includes('missing') || f.toLowerCase().includes('overdue')
                                ? 'bg-rose-950/40 text-rose-400 border border-rose-500/10'
                                : 'bg-white/5 text-[#7C8AA8]'
                            }`}>
                              {(f.toLowerCase().includes('missing') || f.toLowerCase().includes('overdue')) && <ShieldAlert className="w-2.5 h-2.5" />}
                              {f}
                            </span>
                          ))}
                        </div>
                      )}
                    </button>

                    {/* Card Actions & Delete Controls */}
                    <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2">
                      {isAgentMgr && agentMgrView === 'all' ? (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSuggestModalCampaign(c);
                            setSuggestSelectedCreator(myCreators[0]?.handle || '@partner_creator');
                            setSuggestNote('');
                          }}
                          className="bg-[#111E33] hover:bg-[#16243F] text-[#C9A46A] border border-[#C9A46A]/30 text-[11px] font-semibold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                        >
                          Suggest Creator
                        </button>
                      ) : (
                        <span className="text-[10px] text-slate-400 font-mono">
                          {isDirector ? `$${c.value ? c.value.toLocaleString() : '0'} Escrow` : '•••• Protected'}
                        </span>
                      )}

                      {!isCoordinator && canModify && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteCampaign(c.id);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/25 text-rose-400 border border-rose-500/25 hover:border-rose-500/45 text-[10px] font-semibold transition-all flex items-center gap-1 cursor-pointer shadow-sm ml-auto"
                          title="Delete / Terminate Campaign Board"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Campaign Detail / Execution Workspace */}
        <div className="lg:col-span-2">
          {selectedCampaign ? (
            <div className="bg-[#0D1830] border border-white/5 rounded-xl p-6 space-y-6 animate-fade-in">
              <div className="flex justify-between items-start border-b border-white/5 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-mono font-bold text-[#C9A46A] bg-[#111E33] px-2.5 py-1 rounded-lg">{selectedCampaign.brand}</span>
                    <span className="text-xs text-slate-400 font-mono">ID: {selectedCampaign.id}</span>
                  </div>
                  <h2 className="text-lg font-serif font-semibold text-white mt-2">{selectedCampaign.name}</h2>
                </div>
                
                {!isCoordinator && canModify && (
                  <button 
                    onClick={() => handleDeleteCampaign(selectedCampaign.id)}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 hover:border-rose-500/50 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Terminate &amp; Delete Campaign</span>
                  </button>
                )}
              </div>

              {/* Creator Decision / Approval Action Banner for Creators */}
              {currentRole.toLowerCase() === 'creator' && (
                <div className={`p-4 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                  selectedCampaign.creatorAcceptanceStatus === 'Accepted'
                    ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
                    : selectedCampaign.creatorAcceptanceStatus === 'Declined'
                    ? 'bg-rose-950/40 border-rose-500/30 text-rose-200'
                    : 'bg-amber-950/40 border-amber-500/30 text-amber-200'
                }`}>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 font-mono text-xs font-bold uppercase tracking-wider">
                      {selectedCampaign.creatorAcceptanceStatus === 'Accepted' ? (
                        <span className="flex items-center gap-1.5 text-emerald-400">
                          <CheckCircle className="w-4 h-4" /> Campaign Deal Accepted
                        </span>
                      ) : selectedCampaign.creatorAcceptanceStatus === 'Declined' ? (
                        <span className="flex items-center gap-1.5 text-rose-400">
                          <ShieldAlert className="w-4 h-4" /> Campaign Assignment Declined
                        </span>
                      ) : (
                        <span className="flex items-center gap-1.5 text-amber-400">
                          <Clock className="w-4 h-4" /> Creator Assignment Action Required
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300">
                      {selectedCampaign.creatorAcceptanceStatus === 'Accepted'
                        ? 'You accepted this campaign assignment. Follow the deliverables checklist below to submit your content.'
                        : selectedCampaign.creatorAcceptanceStatus === 'Declined'
                        ? `You declined this campaign assignment. Reason: "${selectedCampaign.creatorDeclinedReason || 'No reason specified'}".`
                        : `Are you available and willing to execute this campaign for ${selectedCampaign.brand}?`}
                    </p>
                  </div>

                  {/* Decision Buttons for Creator */}
                  {selectedCampaign.creatorAcceptanceStatus !== 'Accepted' && (
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                      <button
                        type="button"
                        onClick={() => handleCreatorAcceptCampaign(selectedCampaign.id)}
                        className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-mono text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 shadow-md"
                      >
                        <CheckCircle className="w-4 h-4" /> Accept Campaign
                      </button>
                      {selectedCampaign.creatorAcceptanceStatus !== 'Declined' && (
                        <button
                          type="button"
                          onClick={() => {
                            setDeclineReasonText('');
                            setDeclineModalOpen(true);
                          }}
                          className="px-3 py-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-mono text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5"
                        >
                          <ShieldAlert className="w-4 h-4" /> Decline
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Workload Assignment Info + Choose / Reassign Creator Control */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#111E33] p-4 rounded-xl border border-white/5 text-xs text-slate-300">
                <div className="space-y-2">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <p className="flex items-center gap-2">
                      <User className="w-4 h-4 text-[#C9A46A]" /> 
                      <strong className="text-white">Roster Talent:</strong> 
                      <span className="text-amber-300 font-semibold">{selectedCampaign.creator}</span>
                    </p>
                    
                    {/* Choose Creator / Reassign Button for Director, Agent Manager, Coordinator */}
                    {!isEditingCreator ? (
                      <button
                        type="button"
                        onClick={() => {
                          setReassignCreatorHandle(selectedCampaign.creator);
                          setIsEditingCreator(true);
                        }}
                        className="px-2.5 py-1 bg-[#1A2C4A] hover:bg-[#233A60] border border-[#C9A46A]/30 text-[#C9A46A] text-[10px] font-mono font-bold rounded-lg flex items-center gap-1 transition cursor-pointer"
                      >
                        <User className="w-3 h-3 text-[#C9A46A]" />
                        <span>Choose / Change Creator</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setIsEditingCreator(false)}
                        className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-slate-300 text-[10px] font-mono font-bold rounded-lg cursor-pointer"
                      >
                        Cancel
                      </button>
                    )}
                  </div>

                  {/* Inline Creator Selection Box */}
                  {isEditingCreator && (
                    <div className="p-3 bg-[#0D1830] border border-[#C9A46A]/40 rounded-xl space-y-2 animate-fade-in mt-1">
                      <label className="text-[10px] font-mono uppercase font-bold text-[#C9A46A] block">
                        Select Creator for this Campaign
                      </label>
                      <select
                        value={reassignCreatorHandle}
                        onChange={(e) => setReassignCreatorHandle(e.target.value)}
                        className="w-full bg-[#111E33] border border-white/20 rounded-lg p-2 text-xs text-white outline-none"
                      >
                        <option value="">-- Choose Creator --</option>
                        {creators && creators.map(c => (
                          <option key={c.id || c.handle} value={c.handle || c.name}>
                            {c.name} ({c.handle}) - {c.niche || 'Creator'}
                          </option>
                        ))}
                      </select>
                      <div className="flex justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => handleUpdateAssignedCreator(selectedCampaign.id, reassignCreatorHandle)}
                          className="px-3 py-1.5 bg-[#C9A46A] hover:bg-[#d8b57b] text-[#0A1220] text-xs font-mono font-bold rounded-lg transition cursor-pointer"
                        >
                          Save &amp; Assign Creator
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Creator Acceptance Status Badge for Directors & Agent Managers */}
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-slate-400 font-mono text-[11px]">Creator Decision:</span>
                    {selectedCampaign.creatorAcceptanceStatus === 'Accepted' ? (
                      <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> Accepted by Creator
                      </span>
                    ) : selectedCampaign.creatorAcceptanceStatus === 'Declined' ? (
                      <span className="text-[10px] font-mono font-bold text-rose-400 bg-rose-950/60 border border-rose-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1" title={selectedCampaign.creatorDeclinedReason}>
                        <ShieldAlert className="w-3 h-3" /> Declined by Creator
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-950/60 border border-amber-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Pending Creator Acceptance
                      </span>
                    )}
                  </div>

                  <p className="flex items-center gap-2 pt-1"><Calendar className="w-4 h-4 text-slate-500" /> <strong className="text-white">Next Deadline:</strong> {selectedCampaign.deadline}</p>
                </div>

                <div className="space-y-2 border-t md:border-t-0 md:border-l border-white/5 pt-2 md:pt-0 md:pl-4">
                  <p className="flex items-center gap-2"><Layers className="w-4 h-4 text-slate-500" /> <strong className="text-white">Assigned Coordinator:</strong> {selectedCampaign.assignedCoordinator}</p>
                  {isDirector ? (
                    <p className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-slate-500" /> 
                      <strong className="text-white">Financial Value:</strong> 
                      <span className="text-emerald-400 font-semibold">${selectedCampaign.value.toLocaleString()}</span>
                    </p>
                  ) : (
                    <p className="flex items-center gap-2 text-slate-400">
                      <Lock className="w-4 h-4 text-amber-500" /> 
                      <span>Financial metrics strictly masked per §7.</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Execution Stage Timeline */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs uppercase font-bold tracking-wider text-[#7C8AA8] font-mono">Campaign Execution Phase</h4>
                  <span className="text-[11px] font-mono text-[#C9A46A] bg-[#C9A46A]/10 px-2 py-0.5 rounded border border-[#C9A46A]/30 font-semibold">
                    Current Stage: {selectedCampaign.stage}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-1.5 bg-[#111E33] p-1.5 rounded-xl border border-white/5">
                  {STAGES.map((stg, i) => {
                    const isPassed = STAGES.indexOf(selectedCampaign.stage) >= i;
                    const isCurrent = selectedCampaign.stage === stg;
                    
                    return (
                      <button
                        key={stg}
                        disabled={(isAgentMgr && agentMgrView === 'all') || !canModify}
                        onClick={() => !((isAgentMgr && agentMgrView === 'all') || !canModify) && handleStageChange(selectedCampaign.id, stg as any)}
                        className={`py-2 px-1 text-[10px] font-semibold rounded-lg text-center transition-all flex flex-col items-center justify-center gap-1 ${
                          isCurrent 
                            ? 'bg-[#C9A46A] text-[#0A1220] font-bold shadow-md'
                            : isPassed 
                            ? 'bg-slate-800 text-slate-200' 
                            : 'text-slate-500 hover:text-slate-300'
                        } ${((isAgentMgr && agentMgrView === 'all') || !canModify) ? 'cursor-not-allowed opacity-80' : ''}`}
                      >
                        <span className="font-mono text-[9px] block">0{i+1}</span>
                        <span className="truncate max-w-full px-0.5">{stg}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Direct Workflow Phase Action Links */}
                {onNavigate && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {selectedCampaign.statusFlags.some(f => f.includes('Multi-Creator') || f.includes('Marketplace')) && (
                      <button
                        onClick={() => onNavigate('open-marketplace')}
                        className="px-2.5 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 text-[11px] font-mono flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <Users className="w-3.5 h-3.5" /> Review Auditions in Open Marketplace →
                      </button>
                    )}
                    <button
                      onClick={() => onNavigate('content-review')}
                      className="px-2.5 py-1 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 text-[11px] font-mono flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" /> Agency Content Review →
                    </button>
                    <button
                      onClick={() => onNavigate('brand-portal')}
                      className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-[11px] font-mono flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Clock className="w-3.5 h-3.5" /> Brand 48hr Portal →
                    </button>
                    <button
                      onClick={() => onNavigate('content-library')}
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 text-[11px] font-mono flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <CheckCircle className="w-3.5 h-3.5" /> Content Library →
                    </button>
                  </div>
                )}
              </div>

              {/* Deliverables Checklist */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs uppercase font-bold tracking-wider text-[#7C8AA8] font-mono flex items-center gap-1.5"><ListTodo className="w-4 h-4" /> Deliverables Checklist</h4>
                  <span className="text-[10px] font-mono text-[#C9A46A]">{selectedCampaign.completedDeliverables.length}/{selectedCampaign.deliverables.length} Completed</span>
                </div>

                <div className="space-y-2 bg-[#111E33] border border-white/5 p-4 rounded-xl">
                  {selectedCampaign.deliverables.map((item, i) => {
                    const isChecked = selectedCampaign.completedDeliverables.includes(item);
                    return (
                      <button
                        key={i}
                        disabled={(isAgentMgr && agentMgrView === 'all') || !canModify}
                        onClick={() => !((isAgentMgr && agentMgrView === 'all') || !canModify) && handleToggleDeliverable(selectedCampaign.id, item)}
                        className={`w-full text-left p-3 rounded-lg bg-[#0D1830] border border-white/5 hover:border-white/10 flex items-center justify-between group transition-all ${((isAgentMgr && agentMgrView === 'all') || !canModify) ? 'cursor-not-allowed opacity-80' : ''}`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                            isChecked ? 'bg-emerald-500 border-emerald-400' : 'border-white/20 group-hover:border-white/40'
                          }`}>
                            {isChecked && <CheckSquare className="w-3.5 h-3.5 text-black" />}
                          </div>
                          <span className={`text-xs ${isChecked ? 'line-through text-slate-500' : 'text-slate-200'}`}>{item}</span>
                        </div>
                        {isChecked ? (
                          <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/20 px-2 py-0.5 rounded-full">Completed</span>
                        ) : (
                          <span className="text-[9px] font-mono text-[#7C8AA8] opacity-0 group-hover:opacity-100 transition-opacity">Mark Complete</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* FTC Disclosure Auditor */}
              <div className="bg-[#111D33] border border-white/5 p-4 rounded-xl flex items-start gap-3 text-xs leading-relaxed text-slate-300">
                <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-bold text-white block">FTC Disclosure Compliance Lock</span>
                  <p className="text-[11px] text-[#7C8AA8]">
                    Campaign is flagged as requiring full #ad / paid sponsorship disclosures. As Campaign Coordinator, you must verify the draft contains visible, clear disclosure before submitting to the brand review step.
                  </p>
                  {selectedCampaign.completedDeliverables.some(d => d.toLowerCase().includes('disclosure') || d.toLowerCase().includes('ftc')) ? (
                    <span className="inline-flex items-center gap-1 text-emerald-400 text-[10px] font-mono mt-1 font-bold">
                      <CheckCircle className="w-3.5 h-3.5" /> FTC AUDIT PASSED: Disclosure verified in draft.
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-amber-500 text-[10px] font-mono mt-1 font-bold">
                      ⚠️ ACTION REQUIRED: Toggle "Verify FTC disclosure" on deliverable checklist once validated.
                    </span>
                  )}
                </div>
              </div>

              {/* Split Pricing & Manual Financial Inputs Block */}
              {isDirector && (
                <ManualFinancialInputs
                  initialFinancials={selectedCampaign.financials || {
                    brandContractValue: selectedCampaign.value || 10000,
                    influencerPayout: (selectedCampaign.value || 10000) * 0.5,
                    productRetailValue: 450,
                    agencyNetRetained: (selectedCampaign.value || 10000) * 0.5
                  }}
                  campaignTitle={selectedCampaign.name}
                  creatorHandle={selectedCampaign.creator || '@paws_and_palette'}
                  onFinancialsChange={(fin) => {
                    setCampaigns(prev => prev.map(c => c.id === selectedCampaign.id ? { ...c, financials: fin, value: fin.brandContractValue } : c));
                    setSelectedCampaign(prev => prev ? { ...prev, financials: fin, value: fin.brandContractValue } : null);
                    triggerNotification('Financial Split Saved', `Updated contract split: Brand ${fin.brandContractValue} / Creator ${fin.influencerPayout}`, 'success');
                  }}
                />
              )}
            </div>
          ) : (
            <div className="bg-[#0D1830] border border-white/5 rounded-xl p-12 text-center space-y-3 min-h-[400px] flex flex-col justify-center items-center">
              <span className="text-3xl">👈</span>
              <div>
                <h3 className="font-serif font-medium text-white text-base">Select a Campaign</h3>
                <p className="text-xs text-[#7C8AA8] mt-1 max-w-sm">Choose an active campaign from your assigned sidebar roster to review checklists, advance phases, and manage disclosures.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add Campaign Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <form onSubmit={handleAddCampaign} className="bg-[#0D1830] border border-white/10 p-6 rounded-2xl w-full max-w-lg space-y-4">
            <h3 className="text-base font-serif font-bold text-white border-b border-white/5 pb-2">Launch New Campaign Pipeline</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Campaign Title</label>
                <input 
                  type="text" 
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="e.g. Summer Outfit Promo" 
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white" 
                  required
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Brand Name</label>
                <input 
                  type="text" 
                  value={newBrand}
                  onChange={e => setNewBrand(e.target.value)}
                  placeholder="e.g. DripRoom" 
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white" 
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Creator Assignment (1 or More)</label>
                  <span className="text-[10px] font-mono text-[#C9A46A]">{selectedCreators.length} Selected</span>
                </div>
                <div className="bg-[#111E33] border border-white/10 rounded-lg p-2 max-h-32 overflow-y-auto space-y-1">
                  {creators.map(c => {
                    const isSelected = selectedCreators.includes(c.handle);
                    return (
                      <label
                        key={c.id}
                        className={`flex items-center justify-between p-1.5 rounded cursor-pointer text-xs transition-colors ${
                          isSelected ? 'bg-[#16243F] text-amber-300 font-semibold' : 'hover:bg-white/5 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {
                              if (isSelected) {
                                setSelectedCreators(prev => prev.filter(h => h !== c.handle));
                              } else {
                                setSelectedCreators(prev => [...prev, c.handle]);
                              }
                            }}
                            className="rounded border-white/20 bg-slate-800 text-amber-500 focus:ring-0 w-3.5 h-3.5"
                          />
                          <span className="truncate">{c.name} ({c.handle})</span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Execution Coordinator</label>
                <select 
                  value={newCoordinator}
                  onChange={e => setNewCoordinator(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white"
                >
                  <option value="Campaign Lead">Campaign Lead</option>
                  <option value="Agency Lead">Agency Lead (Director)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Completion Deadline</label>
                <input 
                  type="date" 
                  value={newDeadline}
                  onChange={e => setNewDeadline(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Stripe Budget Escrow Value ($)</label>
                <input 
                  type="number" 
                  value={newValue}
                  onChange={e => setNewValue(Number(e.target.value))}
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white" 
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Deliverables Checklist (Comma Separated)</label>
              <textarea 
                value={newDeliverablesText}
                onChange={e => setNewDeliverablesText(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white h-20"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button 
                type="button" 
                onClick={() => setShowAddModal(false)}
                className="bg-transparent border border-white/10 hover:bg-white/5 text-xs text-slate-300 font-semibold px-4 py-2 rounded-lg"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-xs font-semibold px-4 py-2 rounded-lg"
              >
                Deploy Campaign
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Suggest Campaign to Creator Modal (Agent Manager All Campaigns View) */}
      {suggestModalCampaign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-[#0D1830] border border-white/10 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-semibold text-white">Suggest Campaign to Creator</h3>
            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Suggesting &quot;<strong className="text-white">{suggestModalCampaign.name}</strong>&quot; ({suggestModalCampaign.brand}) will send a proposal to the Director for approval. It does not create or assign anything.
            </p>
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Select Creator from Your Roster</label>
              <select
                value={suggestSelectedCreator}
                onChange={(e) => setSuggestSelectedCreator(e.target.value)}
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-xs text-white"
              >
                {myCreators.length > 0 ? (
                  myCreators.map(c => (
                    <option key={c.id || c.handle} value={c.handle || c.name}>{c.name} ({c.handle})</option>
                  ))
                ) : (
                  <option value="@partner_creator">Partner Creator (@partner_creator)</option>
                )}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Add a Note for Director</label>
              <textarea
                value={suggestNote}
                onChange={(e) => setSuggestNote(e.target.value)}
                placeholder="e.g. Creator has high affinity for this brand and audience match..."
                rows={2}
                className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2.5 text-xs text-white outline-none"
              />
            </div>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSuggestModalCampaign(null)}
                className="bg-transparent border border-white/10 hover:bg-white/5 text-xs text-slate-300 font-semibold px-4 py-2 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerNotification(
                    'Suggestion Submitted',
                    `Suggested campaign "${suggestModalCampaign.name}" for ${suggestSelectedCreator} to Director for approval.${suggestNote ? ` Note: "${suggestNote}"` : ''}`,
                    'success'
                  );
                  setSuggestModalCampaign(null);
                }}
                className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] text-xs font-semibold px-4 py-2 rounded-lg"
              >
                Submit Suggestion to Director
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Launch Multi-Creator Mission Modal */}
      {showMissionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-[#0D1830] border border-purple-500/30 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-400" />
                <h3 className="font-serif font-semibold text-base text-white">Launch Multi-Creator Mission</h3>
              </div>
              <button 
                onClick={() => setShowMissionModal(false)}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 bg-white/5 rounded-lg"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-[#7C8AA8] leading-relaxed">
              Broadcast an open campaign blitz to your roster where multiple talent can claim fixed-payout deliverable slots.
            </p>

            <form onSubmit={handleLaunchMission} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Mission Title</label>
                  <input
                    type="text"
                    value={missionTitle}
                    onChange={e => setMissionTitle(e.target.value)}
                    placeholder="e.g. Summer Glow UGC Blitz"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white outline-none"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Sponsoring Brand</label>
                  <input
                    type="text"
                    value={missionBrand}
                    onChange={e => setMissionBrand(e.target.value)}
                    placeholder="e.g. DripRoom / GlowSkin"
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Target Platform</label>
                  <select
                    value={missionPlatform}
                    onChange={e => setMissionPlatform(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white outline-none"
                  >
                    <option value="TikTok">TikTok Video</option>
                    <option value="Instagram">Instagram Reel</option>
                    <option value="YouTube">YouTube Short / Video</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Creator Slots</label>
                  <input
                    type="number"
                    min={1}
                    max={25}
                    value={missionSlots}
                    onChange={e => setMissionSlots(Number(e.target.value))}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white outline-none"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Bounty / Slot ($)</label>
                  <input
                    type="number"
                    min={100}
                    step={50}
                    value={missionBountyPerCreator}
                    onChange={e => setMissionBountyPerCreator(Number(e.target.value))}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-emerald-400 font-mono font-bold outline-none"
                    required
                  />
                </div>
              </div>

              <div className="bg-[#111E33] p-2.5 rounded-xl border border-purple-500/20 flex justify-between items-center text-xs">
                <span className="text-slate-300">Total Campaign Escrow Allocation:</span>
                <span className="font-mono font-bold text-purple-300 text-sm">
                  ${(Number(missionSlots) * Number(missionBountyPerCreator)).toLocaleString()} USD
                </span>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Deliverable Requirements &amp; FTC Guidelines</label>
                <textarea
                  value={missionGuidelines}
                  onChange={e => setMissionGuidelines(e.target.value)}
                  rows={3}
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-mono text-[#7C8AA8]">Submission Deadline</label>
                <input
                  type="date"
                  value={missionDeadline}
                  onChange={e => setMissionDeadline(e.target.value)}
                  className="w-full bg-[#111E33] border border-white/10 rounded-lg p-2 text-xs text-white outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowMissionModal(false)}
                  className="bg-transparent border border-white/10 hover:bg-white/5 text-xs text-slate-300 font-semibold px-4 py-2 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-purple-500 hover:bg-purple-600 text-white text-xs font-semibold px-5 py-2 rounded-lg flex items-center gap-1.5 shadow"
                >
                  <Target className="w-3.5 h-3.5" /> Broadcast Mission
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Decline Reason Modal */}
      {declineModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-[#0D1830] border border-rose-500/30 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-400" /> Decline Campaign Assignment
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Please provide a brief reason for declining &quot;<strong className="text-white">{selectedCampaign?.name}</strong>&quot;. This helps Director and Agent Manager re-assign or adjust terms.
            </p>
            <textarea
              value={declineReasonText}
              onChange={(e) => setDeclineReasonText(e.target.value)}
              placeholder="e.g. Schedule conflict with existing brand travel, or deliverable timeframe too tight..."
              rows={3}
              className="w-full bg-[#111E33] border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-rose-500/50"
            />
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeclineModalOpen(false)}
                className="bg-transparent border border-white/10 hover:bg-white/5 text-xs text-slate-300 font-semibold px-4 py-2 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleCreatorDeclineCampaign(selectedCampaign!.id, declineReasonText)}
                className="bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-bold px-4 py-2 rounded-lg transition"
              >
                Confirm Decline
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        config={deleteConfirmConfig}
        onClose={() => setDeleteConfirmConfig(null)}
      />
    </div>
  );
}
