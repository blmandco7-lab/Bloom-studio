import React, { useState, useEffect } from 'react';
import { Sparkles, Shield, Camera, Wand2, History, Settings, CheckCircle, ShieldCheck, ShieldAlert, FileSignature, AlertCircle, X, Loader2 } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import CreatorLikenessLicensingAgreement from './CreatorLikenessLicensingAgreement';
import { safeStorage } from '../utils/safeStorage';

interface CreatorTwinDashboardProps {
  currentUser?: any;
}

const CreatorTwinDashboard: React.FC<CreatorTwinDashboardProps> = ({ currentUser }) => {
  const [isLicenseActive, setIsLicenseActive] = useState<boolean>(false);
  const [activeLicense, setActiveLicense] = useState<any>(null);
  const [isLicensingModalOpen, setIsLicensingModalOpen] = useState(false);
  const [isRevoking, setIsRevoking] = useState(false);
  const [showRevokeConfirm, setShowRevokeConfirm] = useState(false);

  const creatorId = currentUser?.uid || currentUser?.id || 'unknown';
  const creatorName = currentUser?.name || 'Creator';
  const creatorHandle = currentUser?.handle || '@creator';

  useEffect(() => {
    if (!creatorId || creatorId === 'unknown') return;

    // Local cached check
    try {
      const cached = safeStorage.getItem(`likeness_license_${creatorId}`);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.status === 'Active') {
          setIsLicenseActive(true);
          setActiveLicense(parsed);
        }
      }
    } catch (e) {}

    // Realtime Firestore subscription
    const docRef = doc(db, 'studio-likeness-licenses', `${creatorId}_likeness_license`);
    const unsubscribe = onSnapshot(docRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.status === 'Active') {
          setIsLicenseActive(true);
          setActiveLicense(data);
          try {
            safeStorage.setItem(`likeness_license_${creatorId}`, JSON.stringify(data));
          } catch (e) {}
        } else {
          setIsLicenseActive(false);
          setActiveLicense(null);
        }
      } else {
        setIsLicenseActive(false);
        setActiveLicense(null);
      }
    }, (err) => {
      console.warn('Likeness license subscription notice in dashboard:', err);
    });

    return () => unsubscribe();
  }, [creatorId]);

  const handleRevoke = async () => {
    setIsRevoking(true);
    try {
      const licenseDocId = `${creatorId}_likeness_license`;
      const revocationData = {
        status: 'Revoked',
        revokedAt: new Date().toISOString(),
        revokedBy: currentUser?.name || creatorName,
        biometricConsentGranted: false
      };

      await setDoc(doc(db, 'studio-likeness-licenses', licenseDocId), revocationData, { merge: true });
      try {
        await setDoc(doc(db, 'studio-creators', creatorId), {
          likenessLicenseStatus: 'Revoked',
          likenessConsentActive: false,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (e) {}

      safeStorage.removeItem(`likeness_license_${creatorId}`);
      setIsLicenseActive(false);
      setActiveLicense(null);
      setShowRevokeConfirm(false);
    } catch (err) {
      console.error('Failed to revoke license:', err);
    } finally {
      setIsRevoking(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            {isLicenseActive ? (
              <div className="flex items-center gap-1.5 text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
                <span className="text-[10px] font-mono uppercase tracking-wider font-bold">Biometric Likeness License Active</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-amber-400">
                <ShieldAlert className="w-4 h-4" />
                <span className="text-[10px] font-mono uppercase tracking-wider font-bold">Consent Required • Likeness Unlicensed</span>
              </div>
            )}
          </div>
          <h1 className="text-3xl font-serif font-bold text-white">My Verified AI Twin</h1>
          <p className="text-slate-400 text-sm mt-1">Manage your digital likeness permissions, legal licensing agreements, and synthetic content generations.</p>
        </div>
        
        <div className="flex items-center gap-3">
          {isLicenseActive ? (
            <>
              <div className="px-3.5 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-tight">License: Executed</span>
              </div>
              <button 
                onClick={() => setShowRevokeConfirm(true)}
                className="px-3.5 py-1.5 bg-rose-950/40 hover:bg-rose-900/50 border border-rose-500/30 text-rose-300 font-medium rounded-xl text-xs transition-colors cursor-pointer"
              >
                Revoke Consent
              </button>
            </>
          ) : (
            <button 
              onClick={() => setIsLicensingModalOpen(true)}
              className="px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#E5C378] hover:from-[#E5C378] hover:to-[#D4AF37] text-slate-950 font-bold rounded-xl text-xs transition-all flex items-center gap-2 shadow-lg shadow-amber-500/10 cursor-pointer"
            >
              <FileSignature className="w-4 h-4" />
              Review & Sign Likeness Agreement
            </button>
          )}
        </div>
      </div>

      {/* Revoke confirmation banner */}
      {showRevokeConfirm && (
        <div className="p-4 bg-rose-950/50 border border-rose-500/40 rounded-2xl flex items-start justify-between gap-4 animate-in fade-in duration-200">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-white">Revoke Biometric Likeness License?</h4>
              <p className="text-xs text-rose-200">
                Revoking will immediately pause all AI twin synthesis pipelines and lock down synthetic UGC asset creation across your account.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleRevoke}
              disabled={isRevoking}
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {isRevoking ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <X className="w-3.5 h-3.5" />}
              <span>Confirm Revocation</span>
            </button>
            <button
              onClick={() => setShowRevokeConfirm(false)}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white text-xs rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Model Preview */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-[#152238] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
            <div className="aspect-[3/4] bg-slate-900 relative">
              <img 
                src={currentUser?.image || currentUser?.avatar || "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=800&h=1200&fit=crop"} 
                className="w-full h-full object-cover opacity-80"
                alt="AI Twin Source"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#152238] via-transparent to-transparent" />
              
              <div className="absolute bottom-6 left-6 right-6">
                <div className="p-4 bg-white/5 backdrop-blur-md border border-white/10 rounded-xl space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-mono text-slate-300 uppercase tracking-widest">Base Model v2.4</span>
                    {isLicenseActive ? (
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <ShieldAlert className="w-4 h-4 text-amber-400" />
                    )}
                  </div>
                  <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                    <div className={`h-full ${isLicenseActive ? 'bg-amber-400 w-[94%]' : 'bg-slate-500 w-[30%]'}`} />
                  </div>
                  <p className="text-[10px] text-slate-400 text-center">
                    {isLicenseActive ? '94.8% Likeness Match Efficiency • Verified' : 'Awaiting Signed Likeness Consent'}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Neural Signature</h3>
              <div className="space-y-2">
                {[
                  { label: "Voice Synthesis", value: isLicenseActive ? "HD - Emotional Range v2" : "Locked (No License)" },
                  { label: "Motion Profile", value: isLicenseActive ? "Natural - Hand Gestures" : "Locked (No License)" },
                  { label: "Eye Tracking", value: isLicenseActive ? "Dynamic - Direct Look" : "Locked (No License)" }
                ].map((stat, i) => (
                  <div key={i} className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
                    <span className="text-xs text-slate-400">{stat.label}</span>
                    <span className="text-xs text-slate-200 font-medium">{stat.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Generation & Stats */}
        <div className="lg:col-span-2 space-y-6">
          {/* Licensing Status Card */}
          <div className="bg-[#152238] border border-white/5 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white flex items-center gap-2 text-sm">
                <Shield className="w-4 h-4 text-amber-400" />
                Biometric Likeness Grant & Compliance Record
              </h3>
              <span className="text-[10px] font-mono text-[#7C8AA8]">FTC 16 CFR § 255.5</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3 bg-[#0b1424] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Status</span>
                <span className={`text-xs font-bold font-mono ${isLicenseActive ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {isLicenseActive ? 'Active License' : 'Unsigned / Consent Required'}
                </span>
              </div>
              <div className="p-3 bg-[#0b1424] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Signed By</span>
                <span className="text-xs font-medium text-slate-200 font-mono">
                  {activeLicense?.signedBy || 'Pending Signature'}
                </span>
              </div>
              <div className="p-3 bg-[#0b1424] rounded-xl border border-white/5 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Execution Date</span>
                <span className="text-xs font-medium text-slate-200 font-mono">
                  {activeLicense?.signedAt ? new Date(activeLicense.signedAt).toLocaleDateString() : 'N/A'}
                </span>
              </div>
            </div>

            {!isLicenseActive && (
              <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-2 flex-1">
                  <p className="text-xs text-amber-200 leading-relaxed">
                    Under Bloom Studio compliance guidelines, your AI Twin cannot synthesize video assets or voice recordings without an active signed likeness license.
                  </p>
                  <button
                    onClick={() => setIsLicensingModalOpen(true)}
                    className="px-3.5 py-1.5 bg-[#D4AF37] hover:bg-[#E5C378] text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                  >
                    Open Likeness Agreement
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Usage Table */}
          <div className="bg-[#152238] border border-white/5 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-6 border-b border-white/5 flex justify-between items-center">
              <h3 className="font-bold text-white flex items-center gap-2">
                <Settings className="w-4 h-4 text-amber-400" />
                Active Usage & Campaign Permissions
              </h3>
              <span className="text-[10px] uppercase font-bold text-slate-400">Escrow Protected</span>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#0b1424]">
                  <tr>
                    <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">Brand / Campaign</th>
                    <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">Access Type</th>
                    <th className="px-6 py-4 text-left text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                    <th className="px-6 py-4 text-right text-[10px] font-bold text-slate-500 uppercase tracking-widest">Expiry</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {[
                    { brand: "Glow Skin Co.", campaign: "Winter Hydration", type: "Full Rights", status: isLicenseActive ? "Active" : "Paused", expiry: "31 Dec 2026" },
                    { brand: "Aura Home", campaign: "Modern Living", type: "Non-Exclusive", status: "Revoked", expiry: "Expired" },
                    { brand: "FitTrack", campaign: "Summer Sprint", type: "Milestone-Based", status: isLicenseActive ? "Active" : "Pending", expiry: "15 Oct 2026" }
                  ].map((row, i) => (
                    <tr key={i} className="hover:bg-white/[0.02] transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-xs font-bold text-white">{row.brand}</div>
                        <div className="text-[10px] text-slate-500">{row.campaign}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-[10px] font-mono px-2 py-1 bg-white/5 rounded-lg text-slate-400">{row.type}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className={`text-[10px] font-bold px-2 py-1 rounded-lg inline-flex items-center gap-1.5 ${
                          row.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400' : 
                          row.status === 'Revoked' ? 'bg-rose-500/10 text-rose-400' : 'bg-amber-500/10 text-amber-400'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${
                            row.status === 'Active' ? 'bg-emerald-500' : 
                            row.status === 'Revoked' ? 'bg-rose-500' : 'bg-amber-500'
                          }`} />
                          {row.status}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <span className="text-[10px] font-medium text-slate-400">{row.expiry}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="p-4 bg-[#0b1424] text-center border-t border-white/5">
              <p className="text-[9px] text-slate-500 uppercase tracking-widest italic">Cryptographic Likeness Verification • Bloom Studio Ledger</p>
            </div>
          </div>
        </div>
      </div>

      <CreatorLikenessLicensingAgreement 
        isOpen={isLicensingModalOpen}
        onClose={() => setIsLicensingModalOpen(false)}
        creatorId={creatorId}
        creatorName={creatorName}
        creatorHandle={creatorHandle}
        currentUser={currentUser}
        onLicenseActivated={(lic) => {
          setIsLicenseActive(true);
          setActiveLicense(lic);
        }}
      />
    </div>
  );
};

export default CreatorTwinDashboard;
