import React, { useState, useMemo, useEffect } from 'react';
import { 
  AlertTriangle, CheckSquare, RefreshCw, Sparkles, TrendingUp, CheckCircle, Clock, DollarSign,
  Bell, FileText, Receipt, Shield, Send, Check, Calendar, ArrowRight, Award, Info, ExternalLink,
  Megaphone, Plus, Trash2, ChevronRight, Eye, Briefcase, UserCheck, FileCheck, Inbox
} from 'lucide-react';
import { Creator, Deal, Mission, Notification } from '../types';
import { safeStorage } from '../utils/safeStorage';

interface DailyBriefingProps {
  currentUser: any;
  creators: Creator[];
  deals: Deal[];
  missions: Mission[];
  notifications: Notification[];
  setNotifications: React.Dispatch<React.SetStateAction<Notification[]>>;
  primaryBrandColor: string;
  cardBgColor: string;
  textMainColor: string;
  textMutedColor: string;
  triggerNotification?: (title: string, detail: string, type: 'success' | 'danger' | 'info' | 'warning') => void;
  campaigns?: any[];
  currentRole?: string;
  invoices?: any[];
  activityLogs?: any[];
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  onNavigate?: (screen: string) => void;
  actionQueue?: any[];
  inboundLeads?: any[];
  waitlistEntries?: any[];
  referrals?: any[];
  contentReviewsList?: any[];
  onConvertLeadToDeal?: (lead: any) => void;
  onApproveWaitlistEntry?: (entry: any) => void;
}

interface CustomTask {
  id: string;
  text: string;
  badge: string;
  badgeColor: 'rose' | 'amber' | 'sky' | 'purple' | 'emerald';
  completed: boolean;
  isCustom?: boolean;
  relatedScreen?: string;
}

export default function DailyBriefing({
  currentUser,
  creators = [],
  deals = [],
  missions = [],
  notifications = [],
  setNotifications,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830',
  textMainColor = '#ffffff',
  textMutedColor = '#7C8AA8',
  triggerNotification,
  campaigns = [],
  currentRole = 'none',
  invoices = [],
  activityLogs = [],
  onAddActivityLog,
  onNavigate,
  actionQueue = [],
  inboundLeads = [],
  waitlistEntries = [],
  referrals = [],
  contentReviewsList = [],
  onConvertLeadToDeal,
  onApproveWaitlistEntry
}: DailyBriefingProps) {
  const userRole = (currentRole || currentUser?.role || 'none').toLowerCase();
  const creatorHandle = (currentUser?.handle || '').toLowerCase();
  const userName = currentUser?.name || 'User';

  const isAgentMgr = userRole === 'agentmgr';
  const isAgent = userRole === 'agent';
  const isCoordinator = userRole === 'coordinator';
  const isCreator = userRole === 'creator';
  const isBrand = userRole === 'brand';
  const isDirector = userRole === 'director' || userRole === 'admin' || userRole === 'agency_owner';

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [customTaskInput, setCustomTaskInput] = useState('');
  const [showAddCustomTask, setShowAddCustomTask] = useState(false);
  const [nudgedAlerts, setNudgedAlerts] = useState<string[]>([]);
  const [intakeCategoryFilter, setIntakeCategoryFilter] = useState<'all' | 'leads' | 'applications' | 'referrals' | 'deliverables'>('all');
  const [completedTaskIds, setCompletedTaskIds] = useState<string[]>(() => {
    try {
      const saved = safeStorage.getItem('bloom_briefing_completed_tasks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Unified Intake Submissions Array for Director Intake Command Center
  const allIntakeItems = useMemo(() => {
    const items: any[] = [];

    // 1. Inbound Brand Showcase & Portfolio Inquiries
    if (inboundLeads && Array.isArray(inboundLeads)) {
      inboundLeads.forEach(lead => {
        if (!isDirector && (isAgentMgr || isAgent)) {
          const myName = (currentUser?.name || '').toLowerCase();
          const myEmail = (currentUser?.email || '').toLowerCase();
          const myHandle = (currentUser?.handle || '').toLowerCase();
          const myId = (currentUser?.id || currentUser?.uid || '').toLowerCase();

          const leadAssigned = (
            lead.assignedAgentId || 
            lead.assignedTo || 
            lead.agentEmail || 
            lead.reachedOutBy || 
            lead.manager || 
            lead.agent ||
            ''
          ).toLowerCase();

          const isWorkingWithLead = 
            (leadAssigned && (
              (myId && leadAssigned.includes(myId)) ||
              (myName && leadAssigned.includes(myName)) ||
              (myEmail && leadAssigned.includes(myEmail)) ||
              (myHandle && leadAssigned.includes(myHandle))
            )) ||
            (lead.history && Array.isArray(lead.history) && lead.history.some((h: any) => 
              (h.user || h.author || '').toLowerCase().includes(myName) ||
              (h.user || h.author || '').toLowerCase().includes(myEmail)
            ));

          if (!isWorkingWithLead) return;
        }

        items.push({
          id: `lead_${lead.id || Math.random()}`,
          category: 'leads',
          categoryLabel: 'Brand Showcase Inquiry',
          title: lead.brandName || lead.companyName || lead.clientName || lead.name || 'Brand Showcase Lead',
          subtitle: `${lead.campaignType || 'Sponsorship Booking'} • ${lead.platform || 'Portfolio Showcase'}`,
          detail: lead.notes || lead.details || lead.message || `Contact: ${lead.contactEmail || lead.email || 'Provided in form'}`,
          meta: lead.budget ? `$${Number(lead.budget).toLocaleString()}` : lead.contactEmail || 'Inbound Lead',
          time: lead.timestamp ? new Date(lead.timestamp).toLocaleDateString() : 'Just now',
          badgeColor: 'amber',
          screen: 'inbound-leads',
          raw: lead
        });
      });
    }

    // 2. Talent Waitlist & Onboarding Applications
    if (waitlistEntries && Array.isArray(waitlistEntries)) {
      waitlistEntries.forEach(entry => {
        items.push({
          id: `wl_${entry.id || Math.random()}`,
          category: 'applications',
          categoryLabel: 'Talent Application',
          title: `${entry.name || entry.handle || 'Creator Candidate'}`,
          subtitle: `@${(entry.handle || '').replace('@','') || 'handle'} • ${entry.niche || 'Digital Creator'}`,
          detail: `Followers: ${entry.followers || 'N/A'} • Status: ${entry.status || 'Pending Vetting'}`,
          meta: entry.email || 'Waitlist App',
          time: entry.createdAt ? new Date(entry.createdAt).toLocaleDateString() : 'Just now',
          badgeColor: 'purple',
          screen: 'waitlist',
          raw: entry
        });
      });
    }

    // 3. Creator Referrals
    if (referrals && Array.isArray(referrals)) {
      referrals.forEach(ref => {
        items.push({
          id: `ref_${ref.id || Math.random()}`,
          category: 'referrals',
          categoryLabel: 'Talent Referral',
          title: `Referral: ${ref.newclient || ref.name || 'Client/Creator'}`,
          subtitle: `Referred by: ${ref.referrer || 'Represented Creator'}`,
          detail: `Value: $${(ref.value || 0).toLocaleString()} • Status: ${ref.status || 'Pending Review'}`,
          meta: `$${(ref.value || 0).toLocaleString()} Bonus`,
          time: 'Recent',
          badgeColor: 'sky',
          screen: 'creator-referral',
          raw: ref
        });
      });
    }

    // 4. Content Deliverables Turned In
    if (contentReviewsList && Array.isArray(contentReviewsList)) {
      contentReviewsList.forEach(rev => {
        items.push({
          id: `rev_${rev.id || Math.random()}`,
          category: 'deliverables',
          categoryLabel: 'Deliverable Turned In',
          title: `Deliverable: "${rev.title || 'Submission'}"`,
          subtitle: `Creator: ${rev.creator} • Brand: ${rev.brand || 'Campaign'}`,
          detail: `Platform: ${rev.platform || 'Social'} • Status: ${rev.status || 'In Review'}`,
          meta: rev.status || 'Pending',
          time: 'Recent',
          badgeColor: 'emerald',
          screen: 'content-review',
          raw: rev
        });
      });
    }

    return items;
  }, [inboundLeads, waitlistEntries, referrals, contentReviewsList]);

  const [storedCustomTasks, setStoredCustomTasks] = useState<CustomTask[]>(() => {
    try {
      const saved = safeStorage.getItem('bloom_briefing_custom_tasks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      safeStorage.setItem('bloom_briefing_completed_tasks', JSON.stringify(completedTaskIds));
    } catch {}
  }, [completedTaskIds]);

  useEffect(() => {
    try {
      safeStorage.setItem('bloom_briefing_custom_tasks', JSON.stringify(storedCustomTasks));
    } catch {}
  }, [storedCustomTasks]);

  // Helpers to match creator handle or name
  const matchesMyCreator = (nameOrHandle: string = '') => {
    const handle = (currentUser?.handle || creatorHandle || '@alexjones').toLowerCase();
    const name = (currentUser?.name || 'Alexander Jones').toLowerCase();
    const target = (nameOrHandle || '').toLowerCase();
    if (!target) return false;
    return target.includes(handle) || handle.includes(target) || target.includes(name) || name.includes(target);
  };

  const myManagedCreators = useMemo(() => {
    const userName = (currentUser?.name || '').toLowerCase();
    if (!userName) return [];
    return creators.filter(c => {
      if (c.name.toLowerCase() === userName || c.handle.toLowerCase() === (currentUser?.handle || '').toLowerCase()) {
        return false;
      }
      const ag = (c.assignedAgent || (c as any).agent || '').toLowerCase();
      const mgr = (c.assignedManager || '').toLowerCase();
      const coord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
      return (
        ag.includes(userName) || userName.includes(ag) ||
        mgr.includes(userName) || userName.includes(mgr) ||
        coord.includes(userName) || userName.includes(coord) ||
        (userName.includes('marcus') && (ag.includes('marcus') || mgr.includes('marcus'))) ||
        (userName.includes('alex') && (ag.includes('alex') || coord.includes('alex')))
      );
    });
  }, [creators, currentUser]);
  const myManagedHandles = useMemo(() => myManagedCreators.map(c => c.handle.toLowerCase()), [myManagedCreators]);

  const coordName = (currentUser?.name || '').toLowerCase();
  const coordEmail = (currentUser?.email || '').toLowerCase();

  const myScopedCampaigns = useMemo(() => {
    if (isCoordinator) {
      return campaigns.filter(c => 
        (
          (c.assignedCoordinator && c.assignedCoordinator.toLowerCase() === coordName) ||
          ((c as any).coordinator && (c as any).coordinator.toLowerCase() === coordName) ||
          ((c as any).coordinatorEmail && (c as any).coordinatorEmail.toLowerCase() === coordEmail)
        ) &&
        c.creator?.toLowerCase() !== (currentUser?.handle || '').toLowerCase()
      );
    }
    return campaigns;
  }, [campaigns, isCoordinator, coordName, coordEmail, currentUser]);

  const coordinatorCreatorHandles = useMemo(() => {
    const creatorHandlesFromCampaigns = myScopedCampaigns.map(c => (c.creator || '').toLowerCase());
    const creatorHandlesDirect = creators
      .filter(c => 
        (c.assignedCoordinator?.toLowerCase() === coordName || c.coordinator?.toLowerCase() === coordName || (c as any).coordinatorEmail?.toLowerCase() === coordEmail)
      )
      .map(c => c.handle.toLowerCase());
    return Array.from(new Set([...creatorHandlesFromCampaigns, ...creatorHandlesDirect])).filter(Boolean);
  }, [myScopedCampaigns, creators, coordName, coordEmail]);

  // Scoped Reviews from storage
  const [localStoredReviews] = useState<any[]>(() => {
    try {
      const raw = safeStorage.getItem('wl_content_reviews');
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  });

  const myScopedReviews = useMemo(() => {
    if (isCoordinator) {
      return localStoredReviews.filter(r => 
        coordinatorCreatorHandles.includes((r.creator || '').toLowerCase()) ||
        (r as any).assignedCoordinator?.toLowerCase() === coordName
      );
    }
    return localStoredReviews;
  }, [isCoordinator, localStoredReviews, coordinatorCreatorHandles, coordName]);

  // Scoped Collections
  const myScopedDeals = useMemo(() => {
    if (isCreator) {
      return deals.filter(d => matchesMyCreator(d.creator) || matchesMyCreator((d as any).creatorHandle));
    }
    if (isBrand) {
      const brandName = (currentUser?.name || 'DripRoom').toLowerCase();
      return deals.filter(d => (d.brand || '').toLowerCase().includes(brandName) || brandName.includes((d.brand || '').toLowerCase()) || (d.brand || '').toLowerCase() === 'driproom');
    }
    if (isCoordinator) {
      return deals.filter(d => 
        (d as any).assignedCoordinator?.toLowerCase() === coordName ||
        (d as any).coordinator?.toLowerCase() === coordName ||
        coordinatorCreatorHandles.includes(((d as any).creatorHandle || d.creator || '').toLowerCase())
      );
    }
    if (isAgentMgr || isAgent) {
      return deals.filter(d => myManagedHandles.includes(((d as any).creatorHandle || d.creator || '').toLowerCase()));
    }
    return deals;
  }, [deals, isCreator, isBrand, isCoordinator, isAgentMgr, isAgent, currentUser, myManagedHandles, coordName, coordinatorCreatorHandles]);

  const myScopedCreators = useMemo(() => {
    if (isCreator) {
      return creators.filter(c => matchesMyCreator(c.handle) || matchesMyCreator(c.name));
    }
    if (isCoordinator) {
      return creators.filter(c => 
        (
          (c.assignedCoordinator && c.assignedCoordinator.toLowerCase() === coordName) ||
          (c.coordinator && c.coordinator.toLowerCase() === coordName) ||
          ((c as any).coordinatorEmail && (c as any).coordinatorEmail.toLowerCase() === coordEmail) ||
          coordinatorCreatorHandles.includes(c.handle.toLowerCase())
        ) &&
        c.name.toLowerCase() !== coordName &&
        c.handle.toLowerCase() !== (currentUser?.handle || '').toLowerCase()
      );
    }
    if (isAgentMgr || isAgent) {
      return myManagedCreators;
    }
    return creators;
  }, [creators, isCreator, isCoordinator, isAgentMgr, isAgent, myManagedCreators, coordName, coordEmail, coordinatorCreatorHandles, currentUser]);

  const myScopedMissions = useMemo(() => {
    if (isCreator) {
      return missions.filter(m => matchesMyCreator(m.creator) || matchesMyCreator((m as any).creatorHandle));
    }
    if (isBrand) {
      const brandName = (currentUser?.name || 'DripRoom').toLowerCase();
      return missions.filter(m => (m.brand || m.name || '').toLowerCase().includes(brandName) || brandName.includes((m.brand || '').toLowerCase()) || (m.brand || '').toLowerCase() === 'driproom');
    }
    if (isCoordinator) {
      return missions.filter(m => 
        coordinatorCreatorHandles.includes((m.creator || '').toLowerCase()) ||
        (m as any).coordinator?.toLowerCase() === coordName
      );
    }
    if (isAgentMgr || isAgent) {
      return missions.filter(m => myManagedHandles.includes((m.creator || '').toLowerCase()));
    }
    return missions;
  }, [missions, isCreator, isBrand, isCoordinator, isAgentMgr, isAgent, currentUser, myManagedHandles, coordinatorCreatorHandles, coordName]);

  // Real Dynamic Calculations (No fake fallback numbers)
  const digestDealsPending = useMemo(() => {
    return myScopedDeals.filter(d => d.stage === 'Negotiating' || d.stage === 'Lead' || d.stage === 'Pitched').length;
  }, [myScopedDeals]);

  const digestContractsExpiring = useMemo(() => {
    return myScopedDeals.filter(d => d.stage === 'Contracted' || d.stage === 'Live').length;
  }, [myScopedDeals]);

  const missingW9Creators = useMemo(() => {
    return myScopedCreators.filter(c => 
      (c as any).w9Status === 'Missing' || 
      (c as any).w9Status === 'Pending' || 
      !(c as any).w9Uploaded
    );
  }, [myScopedCreators]);
  const digestW9Missing = missingW9Creators.length;

  const overdueMissions = useMemo(() => {
    return myScopedMissions.filter(m => m.status === 'Delayed' || (m.completed < m.total && m.status !== 'Completed'));
  }, [myScopedMissions]);
  const digestDeliverablesOverdue = overdueMissions.length;

  const overdueInvoicesList = useMemo(() => {
    if (invoices && invoices.length > 0) {
      return invoices.filter(i => i.status === 'Overdue' || (i.status === 'Unpaid' && (i.dueInDays || 0) <= 0));
    }
    return [];
  }, [invoices]);

  const highValueContractsList = useMemo(() => {
    return myScopedDeals.filter(d => (d.budget || d.value || 0) >= 25000);
  }, [myScopedDeals]);

  // Dynamic Action Tasks compilation from REAL state
  const dynamicActionTasks: CustomTask[] = useMemo(() => {
    const list: CustomTask[] = [];

    if (isCoordinator) {
      // Coordinator-specific scoped action tasks
      overdueMissions.slice(0, 3).forEach(m => {
        list.push({
          id: `task_miss_${m.id}`,
          text: `Check deliverable submission pace for ${m.creator}: "${m.name}" (${m.completed}/${m.total} done)`,
          badge: m.status === 'Delayed' ? 'Overdue' : 'In Progress',
          badgeColor: m.status === 'Delayed' ? 'rose' : 'purple',
          completed: completedTaskIds.includes(`task_miss_${m.id}`),
          relatedScreen: 'content-review'
        });
      });

      myScopedCampaigns.slice(0, 2).forEach(c => {
        list.push({
          id: `task_coord_camp_${c.id}`,
          text: `Audit timeline & milestones for assigned campaign: ${c.name} (${c.creator || 'Talent'})`,
          badge: 'Assigned',
          badgeColor: 'amber',
          completed: completedTaskIds.includes(`task_coord_camp_${c.id}`),
          relatedScreen: 'campaign-board'
        });
      });

      storedCustomTasks.forEach(ct => {
        list.push({
          ...ct,
          completed: completedTaskIds.includes(ct.id)
        });
      });

      return list;
    }

    if (isAgentMgr || isAgent) {
      // Agent & Agent Manager scoped action tasks
      const pendingDeals = myScopedDeals.filter(d => d.stage === 'Pitched' || d.stage === 'Negotiating');
      pendingDeals.slice(0, 2).forEach(d => {
        list.push({
          id: `task_deal_${d.id}`,
          text: `Review terms for managed creator ${d.creator}: ${d.brand} deal`,
          badge: 'Negotiation',
          badgeColor: 'amber',
          completed: completedTaskIds.includes(`task_deal_${d.id}`),
          relatedScreen: 'all-deals'
        });
      });

      overdueMissions.slice(0, 2).forEach(m => {
        list.push({
          id: `task_miss_${m.id}`,
          text: `Check deliverable pace for ${m.creator}: "${m.name}" (${m.completed}/${m.total} done)`,
          badge: m.status === 'Delayed' ? 'Overdue' : 'In Progress',
          badgeColor: m.status === 'Delayed' ? 'rose' : 'purple',
          completed: completedTaskIds.includes(`task_miss_${m.id}`),
          relatedScreen: 'missions'
        });
      });

      storedCustomTasks.forEach(ct => {
        list.push({
          ...ct,
          completed: completedTaskIds.includes(ct.id)
        });
      });

      return list;
    }

    // Director / Agency wide Action Tasks
    // 0. Inbound Brand Showcase / Portfolio Booking Inquiries
    if (inboundLeads && Array.isArray(inboundLeads)) {
      inboundLeads.forEach(lead => {
        const name = lead.brandName || lead.companyName || lead.clientName || lead.name || 'Inbound Brand Lead';
        const budget = lead.budget || lead.estimatedBudget ? ` ($${Number(lead.budget || lead.estimatedBudget).toLocaleString()})` : '';
        list.push({
          id: `task_inbound_${lead.id || Math.random()}`,
          text: `📩 Review Inbound Brand Inquiry: ${name}${budget} - ${lead.campaignType || 'Showcase Request'}`,
          badge: 'Brand Lead',
          badgeColor: 'amber',
          completed: completedTaskIds.includes(`task_inbound_${lead.id}`),
          relatedScreen: 'inbound-leads'
        });
      });
    }

    // 0b. Waitlist & Talent Applications
    if (waitlistEntries && Array.isArray(waitlistEntries)) {
      waitlistEntries.filter(e => e.status !== 'Approved' && e.status !== 'Declined').forEach(entry => {
        list.push({
          id: `task_wl_${entry.id || Math.random()}`,
          text: `🌟 Vet Talent Application: ${entry.name || entry.handle} (${entry.niche || 'Creator'}, ${entry.followers || 'N/A'} followers)`,
          badge: 'Waitlist',
          badgeColor: 'purple',
          completed: completedTaskIds.includes(`task_wl_${entry.id}`),
          relatedScreen: 'waitlist'
        });
      });
    }

    // 0c. Creator Referrals
    if (referrals && Array.isArray(referrals)) {
      referrals.filter(r => r.status !== 'Paid' && r.status !== 'Closed').forEach(ref => {
        list.push({
          id: `task_ref_${ref.id || Math.random()}`,
          text: `🤝 Process Talent Referral: ${ref.newclient || ref.name} submitted by ${ref.referrer || 'Creator'} ($${(ref.value || 0).toLocaleString()})`,
          badge: 'Referral',
          badgeColor: 'sky',
          completed: completedTaskIds.includes(`task_ref_${ref.id}`),
          relatedScreen: 'creator-referral'
        });
      });
    }

    // 0d. Content Deliverables Turned In
    if (contentReviewsList && Array.isArray(contentReviewsList)) {
      contentReviewsList.filter(r => r.status === 'Submitted' || r.status === 'In Review' || r.status === 'Pending Approval').forEach(rev => {
        list.push({
          id: `task_rev_${rev.id || Math.random()}`,
          text: `🎬 Review Deliverable turned in by ${rev.creator}: "${rev.title || 'Submission'}" for ${rev.brand || 'Campaign'}`,
          badge: 'Review Due',
          badgeColor: 'emerald',
          completed: completedTaskIds.includes(`task_rev_${rev.id}`),
          relatedScreen: 'content-review'
        });
      });
    }

    // 0e. Pending Representation Contract Proposals & Waitlist Candidate Submissions from Agents
    const pendingApprovalCreators = myScopedCreators.filter(c => 
      c.status === 'Pending Director Approval' || (c as any).status === 'Pending Director Approval'
    );
    pendingApprovalCreators.forEach(c => {
      list.push({
        id: `task_repr_${c.id}`,
        text: `✍️ Review & Sign Representation Contract for ${c.name} (${c.handle}) - Submitted by ${c.assignedAgent || 'Agent'}`,
        badge: 'Talent Signing',
        badgeColor: 'rose',
        completed: completedTaskIds.includes(`task_repr_${c.id}`),
        relatedScreen: 'waitlist'
      });
    });

    // 1. Pending deals requiring contract review / signature
    const pendingDeals = myScopedDeals.filter(d => d.stage === 'Pitched' || d.stage === 'Negotiating');
    pendingDeals.slice(0, 2).forEach(d => {
      list.push({
        id: `task_deal_${d.id}`,
        text: `Review terms & prepare contract for ${d.brand} (${d.creator || 'Creator'}) - $${(d.budget || d.value || 0).toLocaleString()}`,
        badge: 'Negotiation',
        badgeColor: 'amber',
        completed: completedTaskIds.includes(`task_deal_${d.id}`),
        relatedScreen: 'all-deals'
      });
    });

    // 2. High-value contracts requiring director executive sign-off
    highValueContractsList.slice(0, 1).forEach(d => {
      list.push({
        id: `task_hv_${d.id}`,
        text: `💎 Executive review for $${(d.budget || d.value || 0).toLocaleString()} ${d.brand} campaign with ${d.creator}`,
        badge: '$25k+ Deal',
        badgeColor: 'rose',
        completed: completedTaskIds.includes(`task_hv_${d.id}`),
        relatedScreen: 'all-deals'
      });
    });

    // 3. Overdue / delayed deliverables
    overdueMissions.slice(0, 2).forEach(m => {
      list.push({
        id: `task_miss_${m.id}`,
        text: `Check on deliverable progress for ${m.creator}: "${m.name}" (${m.completed}/${m.total} done)`,
        badge: m.status === 'Delayed' ? 'Overdue' : 'In Progress',
        badgeColor: m.status === 'Delayed' ? 'rose' : 'purple',
        completed: completedTaskIds.includes(`task_miss_${m.id}`),
        relatedScreen: 'missions'
      });
    });

    // 4. Missing W-9 compliance items (Director only)
    if (missingW9Creators.length > 0) {
      const topMissing = missingW9Creators[0];
      list.push({
        id: `task_w9_${topMissing.id}`,
        text: `Collect Form W-9 tax compliance from ${topMissing.handle || topMissing.name} before payout`,
        badge: 'Compliance',
        badgeColor: 'sky',
        completed: completedTaskIds.includes(`task_w9_${topMissing.id}`),
        relatedScreen: 'w9-1099-tracker'
      });
    }

    // 5. Invoices needing reconciliation or overdue
    if (overdueInvoicesList.length > 0) {
      const topInv = overdueInvoicesList[0];
      list.push({
        id: `task_inv_${topInv.id}`,
        text: `Follow up on invoice ${topInv.invoiceNumber || topInv.id} to ${topInv.brandName || topInv.brand || 'Brand'} ($${Number(topInv.amount || 0).toLocaleString()})`,
        badge: 'Invoice Due',
        badgeColor: 'purple',
        completed: completedTaskIds.includes(`task_inv_${topInv.id}`),
        relatedScreen: 'invoices'
      });
    } else {
      // Default escrow milestone settlement item
      const activeDealsWithEscrow = myScopedDeals.filter(d => d.stage === 'Live' || d.stage === 'Contracted');
      if (activeDealsWithEscrow.length > 0) {
        const topEscrow = activeDealsWithEscrow[0];
        list.push({
          id: `task_escrow_${topEscrow.id}`,
          text: `Authorize milestone escrow verification for ${topEscrow.brand} (${topEscrow.creator})`,
          badge: 'Escrow',
          badgeColor: 'emerald',
          completed: completedTaskIds.includes(`task_escrow_${topEscrow.id}`),
          relatedScreen: 'escrow-settlement'
        });
      }
    }

    // Add items from global Action Queue
    if (actionQueue && Array.isArray(actionQueue)) {
      actionQueue.forEach(aq => {
        list.push({
          id: `aq_${aq.id || Math.random()}`,
          text: aq.title || 'Action item',
          badge: aq.tag || 'Action Item',
          badgeColor: 'sky',
          completed: !!aq.isCompleted,
          relatedScreen: 'director-dash'
        });
      });
    }

    // Inactive Brand CRM Reminders (30+ days without contact/update)
    try {
      const savedInactiveBrands = safeStorage.getItem('bloom_brand_crm_inactive_tasks');
      if (savedInactiveBrands) {
        const inactiveBrandsArr = JSON.parse(savedInactiveBrands);
        if (Array.isArray(inactiveBrandsArr)) {
          inactiveBrandsArr.forEach(task => {
            list.push({
              ...task,
              completed: completedTaskIds.includes(task.id)
            });
          });
        }
      }
    } catch (e) {}

    // Append any user custom tasks
    storedCustomTasks.forEach(ct => {
      list.push({
        ...ct,
        completed: completedTaskIds.includes(ct.id)
      });
    });

    return list;
  }, [isCoordinator, isAgentMgr, isAgent, myScopedCampaigns, myScopedDeals, highValueContractsList, overdueMissions, missingW9Creators, overdueInvoicesList, completedTaskIds, storedCustomTasks, actionQueue, inboundLeads, waitlistEntries, referrals, contentReviewsList]);

  // Brand-Specific Action Tasks
  const brandTasks: CustomTask[] = useMemo(() => {
    const list: CustomTask[] = [];
    const brandDeals = myScopedDeals;
    
    brandDeals.forEach(d => {
      list.push({
        id: `brand_task_${d.id}`,
        text: `Review deliverable timeline & milestones for ${d.creator} (${d.platform || 'Social'})`,
        badge: d.stage === 'Live' ? 'Active' : 'Pending',
        badgeColor: d.stage === 'Live' ? 'emerald' : 'amber',
        completed: completedTaskIds.includes(`brand_task_${d.id}`),
        relatedScreen: 'content-review'
      });
    });

    if (list.length === 0) {
      list.push({
        id: 'brand_task_default',
        text: 'Explore exclusive represented talent roster and propose a new campaign brief',
        badge: 'Discovery',
        badgeColor: 'sky',
        completed: completedTaskIds.includes('brand_task_default'),
        relatedScreen: 'roster'
      });
    }

    // Add items from global Action Queue
    if (actionQueue && Array.isArray(actionQueue)) {
      actionQueue.forEach(aq => {
        list.push({
          id: `aq_${aq.id || Math.random()}`,
          text: aq.title || 'Action item',
          badge: aq.tag || 'Action Item',
          badgeColor: 'sky',
          completed: !!aq.isCompleted,
          relatedScreen: 'director-dash'
        });
      });
    }

    return list;
  }, [myScopedDeals, completedTaskIds, actionQueue]);

  const activeTaskList = isBrand ? brandTasks : dynamicActionTasks;

  // Toggle task
  const toggleTask = (id: string, text: string) => {
    setCompletedTaskIds(prev => {
      const isCompleted = prev.includes(id);
      const next = isCompleted ? prev.filter(x => x !== id) : [...prev, id];
      if (!isCompleted && triggerNotification) {
        triggerNotification('Task Completed', `Action item: "${text}" checked off.`, 'success');
        if (onAddActivityLog) {
          onAddActivityLog(userName, currentRole, `Checked off task: "${text}"`);
        }
      }
      return next;
    });
  };

  const handleAddCustomTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTaskInput.trim()) return;
    const newTask: CustomTask = {
      id: `custom_${Date.now()}`,
      text: customTaskInput.trim(),
      badge: 'Custom',
      badgeColor: 'purple',
      completed: false,
      isCustom: true
    };
    setStoredCustomTasks(prev => [newTask, ...prev]);
    setCustomTaskInput('');
    setShowAddCustomTask(false);
    if (triggerNotification) {
      triggerNotification('Task Added', `Added custom action item: "${newTask.text}"`, 'info');
    }
  };

  const handleDeleteCustomTask = (id: string) => {
    setStoredCustomTasks(prev => prev.filter(t => t.id !== id));
    setCompletedTaskIds(prev => prev.filter(x => x !== id));
  };

  // Synchronize stats
  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      if (triggerNotification) {
        triggerNotification('Stats Synchronized', 'Daily Briefing dashboard statistics refreshed from live system state.', 'info');
      }
    }, 600);
  };

  // Auto-sync for non-directors
  useEffect(() => {
    if (!isDirector) {
      setIsRefreshing(true);
      const initialTimer = setTimeout(() => setIsRefreshing(false), 500);
      const interval = setInterval(() => {
        setIsRefreshing(true);
        setTimeout(() => setIsRefreshing(false), 400);
      }, 45000);
      return () => {
        clearTimeout(initialTimer);
        clearInterval(interval);
      };
    }
  }, [isDirector]);

  // Derived Top Stat Cards
  const statsList = useMemo(() => {
    if (isCreator) {
      const myActiveDeals = myScopedDeals.filter(d => d.stage === 'Live' || d.stage === 'Contracted');
      const pendingDeliverablesCount = myScopedMissions.reduce((acc, m) => acc + Math.max(0, m.total - m.completed), 0);
      const myEarningsThisMonth = myScopedDeals
        .filter(d => d.stage === 'Live' || d.stage === 'Contracted' || d.stage === 'Completed')
        .reduce((sum, d) => sum + (d.value || d.budget || 0), 0);
      const myPendingPayouts = myScopedDeals
        .filter(d => d.stage === 'Negotiating' || d.stage === 'Contracted' || d.stage === 'Live')
        .reduce((sum, d) => sum + Math.round((d.value || d.budget || 0) * 0.8), 0); // 80% talent split

      return [
        { label: 'My Active Deals', val: `${myActiveDeals.length} Active`, icon: TrendingUp, color: primaryBrandColor, screen: 'my-content' },
        { label: 'Deliverables Due', val: `${pendingDeliverablesCount} Due`, icon: CheckSquare, color: '#f43f5e', screen: 'missions' },
        { label: 'Earnings This Month', val: `$${myEarningsThisMonth.toLocaleString()}`, icon: DollarSign, color: '#10b981', screen: 'escrow-settlement' },
        { label: 'Pending Payouts', val: `$${myPendingPayouts.toLocaleString()}`, icon: Receipt, color: '#06b6d4', screen: 'escrow-settlement' }
      ];
    } 
    
    if (isCoordinator) {
      const pendingSubmissionsCount = myScopedReviews.filter(r => r.status === 'Pending' || r.status === 'Pending Agent Review').length;

      return [
        { label: 'My Assigned Campaigns', val: myScopedCampaigns.length + ' Active', icon: TrendingUp, color: primaryBrandColor, screen: 'campaign-board' },
        { label: 'Submitted Content to Review', val: pendingSubmissionsCount + ' Pending', icon: FileCheck, color: '#f43f5e', screen: 'submit-content' },
        { label: 'My Assigned Talent', val: myScopedCreators.length + ' Creators', icon: Sparkles, color: '#10b981', screen: 'roster' },
        { label: 'Missions & Deliverables', val: myScopedMissions.length + ' In Flight', icon: CheckSquare, color: '#06b6d4', screen: 'missions' }
      ];
    } 
    
    if (isBrand) {
      const myActiveCampaigns = myScopedDeals.filter(d => d.stage === 'Live' || d.stage === 'Contracted' || d.stage === 'Negotiating');
      const activeCreatorsCount = Array.from(new Set(myScopedDeals.map(d => d.creator))).length;
      const totalBudgetAllocated = myScopedDeals.reduce((sum, d) => sum + (d.budget || d.value || 0), 0);
      const deliverablesInReview = myScopedMissions.filter(m => m.status === 'In Progress' || m.completed < m.total).length;

      return [
        { label: 'Connected Talent', val: activeCreatorsCount, icon: Sparkles, color: '#f43f5e', screen: 'roster' },
        { label: 'Running Campaigns', val: myActiveCampaigns.length, icon: TrendingUp, color: primaryBrandColor, screen: 'all-deals' },
        { label: 'Review Approvals', val: deliverablesInReview, icon: CheckCircle, color: '#10b981', screen: 'content-review' },
        { label: 'Escrow Budget', val: `$${totalBudgetAllocated.toLocaleString()}`, icon: DollarSign, color: '#06b6d4', screen: 'escrow-settlement' }
      ];
    } 
    
    if (isAgentMgr || isAgent) {
      const activeMissionsCount = myScopedMissions.filter(m => m.status !== 'Completed').length;
      const completedDealsCount = myScopedDeals.filter(d => d.stage === 'Completed').length;
      const activeAlertsCount = notifications.filter(n => {
        const text = `${n.title} ${n.detail}`.toLowerCase();
        return myManagedHandles.some(h => text.includes(h));
      }).length;

      return [
        { label: 'Active Team Alerts', val: activeAlertsCount, icon: AlertTriangle, color: '#f43f5e', screen: 'performance-alerts' },
        { label: 'Assigned Missions', val: activeMissionsCount, icon: TrendingUp, color: primaryBrandColor, screen: 'missions' },
        { label: 'Assigned Talent', val: myManagedCreators.length, icon: Sparkles, color: '#10b981', screen: 'roster' },
        { label: 'Completed Deals', val: `${completedDealsCount} Closed`, icon: CheckCircle, color: '#06b6d4', screen: 'all-deals' }
      ];
    }

    // Default Director / Admin View
    const activeAlertsCount = notifications.length;
    const activeMissionsCount = missions.filter(m => m.status !== 'Completed').length;
    const rosterHeadcount = creators.length;
    const totalPipelineValue = deals.reduce((sum, d) => sum + (d.budget || d.value || 0), 0);

    return [
      { label: 'Active Alerts', val: activeAlertsCount, icon: AlertTriangle, color: '#f43f5e', screen: 'performance-alerts' },
      { label: 'Active Missions', val: activeMissionsCount, icon: TrendingUp, color: primaryBrandColor, screen: 'missions' },
      { label: 'Roster Headcount', val: rosterHeadcount, icon: Sparkles, color: '#10b981', screen: 'roster' },
      { label: 'Pipeline Volume', val: `$${totalPipelineValue.toLocaleString()}`, icon: DollarSign, color: '#06b6d4', screen: 'all-deals' }
    ];
  }, [isCreator, isCoordinator, isBrand, isAgentMgr, isAgent, myScopedDeals, myScopedMissions, myScopedCampaigns, myManagedCreators, myManagedHandles, notifications, missions, creators, deals, primaryBrandColor]);

  // Notifications filtering
  const filteredNotifications = useMemo(() => {
    if (isCreator) {
      return notifications.filter(n => n.detail?.toLowerCase().includes(creatorHandle) || n.title?.toLowerCase().includes(creatorHandle));
    }
    if (isBrand) {
      const brandName = (currentUser?.name || 'DripRoom').toLowerCase();
      return notifications.filter(n => {
        const text = `${n.title} ${n.detail}`.toLowerCase();
        return text.includes(brandName) || text.includes('driproom') || text.includes('campaign') || text.includes('contract');
      });
    }
    if (isAgentMgr || isAgent) {
      return notifications.filter(n => {
        const text = `${n.title} ${n.detail}`.toLowerCase();
        return myManagedHandles.some(h => text.includes(h));
      });
    }
    if (isCoordinator) {
      return notifications.filter(n => {
        const text = `${n.title} ${n.detail}`.toLowerCase();
        return coordinatorCreatorHandles.some(h => text.includes(h));
      });
    }
    return notifications;
  }, [notifications, isCreator, isBrand, isAgentMgr, isAgent, isCoordinator, creatorHandle, currentUser, myManagedHandles, coordinatorCreatorHandles]);

  // Dynamic Live Status Changes Feed (compiled from real activity logs)
  const statusChangeLogs = useMemo(() => {
    if (activityLogs && activityLogs.length > 0) {
      return activityLogs.slice(0, 6).map((log, index) => {
        const actionText = log.action || log.detail || 'System state synchronized';
        const isApprove = actionText.toLowerCase().includes('approved') || actionText.toLowerCase().includes('completed') || actionText.toLowerCase().includes('verified');
        return {
          id: log.id || `act_${index}`,
          time: log.timestamp ? (log.timestamp.includes(':') ? log.timestamp.split('T')[1]?.substring(0, 5) || 'Recent' : log.timestamp) : `${(index + 1) * 12}m ago`,
          text: `${log.user || 'User'} (${log.role || 'Member'}): ${actionText}`,
          type: isApprove ? 'approves' : 'submits',
          status: 'Consent-Verified'
        };
      });
    }

    // Default dynamic fallbacks built from actual deals & creators
    const fallbackLogs = [];
    if (deals.length > 0) {
      const topDeal = deals[0];
      fallbackLogs.push({
        id: 'fb_1',
        time: 'Just now',
        text: `Pipeline deal created: ${topDeal.brand} ($${(topDeal.budget || 0).toLocaleString()}) for ${topDeal.creator || 'Talent'}`,
        type: 'submits',
        status: 'Contracted'
      });
    }
    if (creators.length > 0) {
      const topCreator = creators[0];
      fallbackLogs.push({
        id: 'fb_2',
        time: '25m ago',
        text: `Creator profile updated: ${topCreator.handle || topCreator.name} (${topCreator.followers || '1.1M'} followers) - Active`,
        type: 'approves',
        status: 'Consent-Verified'
      });
    }
    fallbackLogs.push({
      id: 'fb_3',
      time: '1h ago',
      text: 'Compliance Engine: FDIC Escrow segregation check completed successfully',
      type: 'approves',
      status: 'Audited'
    });
    return fallbackLogs;
  }, [activityLogs, deals, creators]);

  // Dynamic Auto-Watcher nudges
  const handleNudge = (id: string, title: string, detail: string) => {
    setNudgedAlerts(prev => [...prev, id]);
    if (triggerNotification) {
      triggerNotification('Internal Reminder Sent', `${title}: ${detail}`, 'info');
    }
    if (onAddActivityLog) {
      onAddActivityLog(userName, currentRole, `Dispatched auto-watcher notification: ${title}`);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" style={{ color: textMainColor }}>
      
      {/* Header Banner */}
      <div 
        style={{ 
          backgroundColor: cardBgColor, 
          borderColor: `${primaryBrandColor}20`,
        }}
        className="relative border rounded-2xl p-6 overflow-hidden shadow-xl"
      >
        <div 
          className="absolute -top-12 -right-12 w-64 h-64 rounded-full pointer-events-none opacity-10"
          style={{ 
            background: `radial-gradient(circle, ${primaryBrandColor} 0%, transparent 70%)` 
          }}
        ></div>
        
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md font-mono" style={{ color: primaryBrandColor, backgroundColor: `${primaryBrandColor}15` }}>
                {isCreator ? 'Creator Space' : isBrand ? 'Brand Portal' : isCoordinator ? 'Coordinator Command' : isAgentMgr || isAgent ? 'Agent Desk' : 'Agency Command Center'}
              </span>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white">
              Good day, {currentUser?.name?.split(' ')[0] || 'User'}
            </h1>
            <p className="text-xs max-w-xl" style={{ color: textMutedColor }}>
              {isCreator 
                ? 'Review your live deliverables, track sponsorship payouts, and verify IRS tax compliance.'
                : isBrand
                  ? 'Track live campaign execution, oversee escrow deposits, and inspect talent drafts.'
                  : isCoordinator
                    ? 'Personal coordinator briefing: inspect submitted creator content, monitor assigned campaign deliverables, and submit drafts to leadership for final approval.'
                    : 'Live agency dashboard: monitor active campaigns, review submissions, track escrow cashflow, and unblock talent.'
              }
            </p>
          </div>
          
          <div className="flex items-center gap-4 flex-wrap sm:flex-nowrap">
            {!isCreator && (
              <button 
                type="button"
                onClick={() => onNavigate && onNavigate('match-or-pass')}
                className="relative group cursor-pointer overflow-hidden rounded-xl border border-[#C9A46A]/30 w-40 h-20 shadow-lg shadow-[#C9A46A]/10 transition-transform active:scale-[0.98] text-left p-0 block"
                aria-label="Navigate to Talent Discovery: Match or Pass Deck"
              >
                <img 
                  src="https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=400&auto=format&fit=crop&q=80" 
                  alt="" 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 opacity-60"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-2">
                  <span className="text-[9px] font-mono font-bold text-[#C9A46A] uppercase tracking-tighter">Talent Discovery</span>
                  <span className="text-[10px] font-bold text-white leading-tight">Match or Pass Deck</span>
                </div>
                <div className="absolute top-1 right-1">
                  <Sparkles className="w-3 h-3 text-[#C9A46A] animate-pulse" />
                </div>
              </button>
            )}
            {isDirector && (
              <button 
                onClick={handleRefresh}
                disabled={isRefreshing}
                style={{ 
                  color: primaryBrandColor, 
                  borderColor: `${primaryBrandColor}30`,
                  backgroundColor: `${primaryBrandColor}05`
                }}
                className="hover:bg-white/5 transition-colors border px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                {isRefreshing ? 'Syncing...' : 'Sync Live Stats'}
              </button>
            )}
            {!isDirector && (
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-500/20 px-3.5 py-1.5 rounded-xl font-mono">
                <span className={`w-1.5 h-1.5 rounded-full bg-emerald-400 ${isRefreshing ? 'animate-pulse' : ''}`}></span>
                {isRefreshing ? 'Auto-Syncing...' : 'Live Connected'}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Morning Briefing Digest Summary Card (100% Real Scoped Numbers) */}
      <div 
        style={{ backgroundColor: `${primaryBrandColor}10`, borderColor: `${primaryBrandColor}30` }}
        className="border rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm"
      >
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20 font-mono">
                LIVE EXECUTIVE DIGEST
              </span>
              <span className="text-[10px] font-mono text-[#7C8AA8]">Real-time scoped metrics</span>
            </div>
            <p className="text-xs sm:text-sm font-medium text-white mt-1">
              {isCreator ? (
                <>You have <span className="text-amber-300 font-semibold">{myScopedDeals.length} active campaigns</span>, <span className="text-purple-300 font-semibold">{digestDeliverablesOverdue} pending deliverables</span>, and <span className="text-emerald-300 font-semibold">{missingW9Creators.length === 0 ? 'Verified tax compliance' : 'W-9 form required'}</span>.</>
              ) : isBrand ? (
                <>Brand Overview: <span className="text-amber-300 font-semibold">{myScopedDeals.length} registered deals</span>, <span className="text-sky-300 font-semibold">{myScopedMissions.length} active missions</span>, and <span className="text-emerald-300 font-semibold">${myScopedDeals.reduce((s, d) => s + (d.budget || 0), 0).toLocaleString()} secured escrow</span>.</>
              ) : isCoordinator ? (
                <>Coordinator Briefing: <span className="text-amber-300 font-semibold">{myScopedCampaigns.length} assigned campaigns</span>, <span className="text-purple-300 font-semibold">{myScopedMissions.length} active deliverables</span>, <span className="text-sky-300 font-semibold">{myScopedReviews.filter(r => r.status === 'Pending' || r.status === 'Pending Agent Review').length} submissions to review</span>, and <span className="text-emerald-300 font-semibold">{myScopedCreators.length} assigned talent</span>.</>
              ) : (
                <>Morning briefing: <span className="text-amber-300 font-semibold">{digestDealsPending} deals in negotiation</span>, <span className="text-rose-400 font-semibold">{digestContractsExpiring} active contracts</span>, <span className="text-sky-300 font-semibold">{digestW9Missing} W-9s missing</span>, and <span className="text-purple-300 font-semibold">{digestDeliverablesOverdue} deliverables in flight</span>.</>
              )}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <span className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-black/30 text-slate-300 border border-white/5">
            {myScopedDeals.length} Scoped Deals
          </span>
          <span className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-black/30 text-slate-300 border border-white/5">
            {myScopedCreators.length} Scoped Roster
          </span>
        </div>
      </div>

      {/* Top 4 Statistics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statsList.map((stat, i) => (
          <button 
            key={i} 
            type="button"
            onClick={() => {
              if (onNavigate && stat.screen) {
                onNavigate(stat.screen);
              }
            }}
            disabled={!stat.screen}
            style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}10` }}
            className={`border p-5 rounded-2xl relative overflow-hidden flex flex-col justify-between h-28 group transition-all text-left w-full ${stat.screen ? 'cursor-pointer hover:border-white/20' : 'cursor-default'}`}
            aria-label={stat.screen ? `Navigate to ${stat.label}` : stat.label}
          >
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: textMutedColor }}>
                {stat.label}
              </span>
              <stat.icon className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: stat.color }} />
            </div>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-bold font-mono text-white" style={{ color: stat.color }}>
                {stat.val}
              </span>
              {stat.screen && (
                <ChevronRight className="w-4 h-4 text-white/30 group-hover:text-white group-hover:translate-x-0.5 transition-all" />
              )}
            </div>
          </button>
        ))}
      </div>

      {/* CREATOR-SPECIFIC VIEW */}
      {isCreator ? (
        <div className="space-y-6">
          {/* Creator Onboarding & Compliance Tracker */}
          {(() => {
            const myProfile = myScopedCreators[0] || creators[0];
            const isW9Missing = !myProfile || (myProfile as any).w9Status === 'Missing' || (myProfile as any).w9Status === 'Pending' || !(myProfile as any).w9Uploaded;
            const progressPct = isW9Missing ? 80 : 100;
            return (
              <div 
                style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}20` }}
                className="border rounded-2xl p-5 space-y-4 shadow-sm"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-xl ${isW9Missing ? 'bg-amber-500/15 text-amber-400' : 'bg-emerald-500/15 text-emerald-400'}`}>
                      <Shield className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-serif font-medium text-lg text-white">Creator Onboarding & Tax Compliance</h3>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                          isW9Missing ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        }`}>
                          {progressPct}% Complete
                        </span>
                      </div>
                      <p className="text-[11px]" style={{ color: textMutedColor }}>
                        {isW9Missing 
                          ? 'Upload your signed IRS Form W-9 to clear tax compliance and unlock automatic escrow payouts.'
                          : 'All compliance checks, talent contracts, and IRS W-9 tax forms are verified for 2026.'}
                      </p>
                    </div>
                  </div>
                  {isW9Missing ? (
                    <button
                      onClick={() => {
                        if (onNavigate) {
                          onNavigate('w9-1099-tracker');
                        } else if (triggerNotification) {
                          triggerNotification('Compliance Required', 'Please upload your signed Form W-9 in the Compliance Tracker.', 'info');
                        }
                      }}
                      className="bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] px-4 py-2 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
                    >
                      Upload W-9 <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-500/20 px-3.5 py-1.5 rounded-xl inline-flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5" /> Verified Profile
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-white">Onboarding Checklist Progress</span>
                    <span style={{ color: primaryBrandColor }}>{progressPct}%</span>
                  </div>
                  <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${isW9Missing ? 'bg-[#C9A46A]' : 'bg-emerald-500'}`}
                      style={{ width: `${progressPct}%` }}
                    ></div>
                  </div>
                  {isW9Missing && (
                    <p className="text-[11px] text-amber-300/90 pt-1">
                      ⚠️ 1 action remaining: Upload your IRS Form W-9 to clear tax compliance before next scheduled payout release.
                    </p>
                  )}
                </div>
              </div>
            );
          })()}

          {/* Active Deals & Deliverables Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* My Active Deals */}
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}15` }}
              className="border rounded-2xl p-5 space-y-4 shadow-sm"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" style={{ color: primaryBrandColor }} /> My Active Deals & Stages
                  </h3>
                  <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                    Live brand deals assigned to your profile
                  </p>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-[#C9A46A]/10 text-[#C9A46A] rounded-full border border-[#C9A46A]/20">
                  {myScopedDeals.length} Deals
                </span>
              </div>

              <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
                {myScopedDeals.length === 0 ? (
                  <div className="py-10 text-center space-y-2">
                    <TrendingUp className="w-8 h-8 text-white/20 mx-auto" />
                    <p className="text-xs text-white font-medium">No Active Deals</p>
                    <p className="text-[10px] text-[#7C8AA8]">You currently have no active deals assigned.</p>
                  </div>
                ) : (
                  myScopedDeals.map((deal, dIdx) => (
                    <div 
                      key={`${deal.id}_${dIdx}`}
                      className="p-3.5 bg-black/20 border border-white/5 rounded-xl flex items-center justify-between gap-3 hover:bg-black/30 transition-all"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-[#C9A46A] uppercase tracking-wider">
                            {deal.brand}
                          </span>
                          <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded border ${
                            deal.stage === 'Live' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' :
                            deal.stage === 'Contracted' ? 'bg-purple-500/10 border-purple-500/20 text-purple-400' :
                            'bg-amber-500/10 border-amber-500/20 text-amber-400'
                          }`}>
                            {deal.stage}
                          </span>
                        </div>
                        <h4 className="text-xs font-semibold text-white truncate mt-1">{deal.title || `${deal.brand} Campaign`}</h4>
                        <div className="text-[10px] text-[#7C8AA8] flex items-center gap-2 mt-1">
                          <span>Due: {deal.due || deal.dueDate || '30 Days'}</span>
                          <span>•</span>
                          <span>Platform: {deal.platform || 'TikTok'}</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xs font-bold text-white font-mono">${(deal.value || deal.budget || 0).toLocaleString()}</div>
                        <span className="text-[9px] text-emerald-400 font-mono">Secured</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Deliverables Due */}
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}15` }}
              className="border rounded-2xl p-5 space-y-4 shadow-sm"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-rose-400" /> Deliverables Due
                  </h3>
                  <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                    Upcoming submission dates for your assigned campaign missions
                  </p>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/20">
                  {myScopedMissions.length} Missions
                </span>
              </div>

              <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
                {myScopedMissions.length === 0 ? (
                  <div className="py-10 text-center space-y-2">
                    <CheckCircle className="w-8 h-8 text-emerald-400/40 mx-auto" />
                    <p className="text-xs text-white font-medium">All Deliverables Completed</p>
                    <p className="text-[10px] text-[#7C8AA8]">No upcoming campaign deliverables due.</p>
                  </div>
                ) : (
                  myScopedMissions.map(m => {
                    const pct = Math.min(100, Math.round((m.completed / Math.max(1, m.total)) * 100));
                    return (
                      <div 
                        key={m.id}
                        className="p-3.5 bg-black/20 border border-white/5 rounded-xl space-y-2 hover:bg-black/30 transition-all"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <span className="text-[9px] uppercase font-bold text-[#C9A46A]">
                              {m.brand} • {m.type}
                            </span>
                            <h4 className="text-xs font-semibold text-white truncate mt-0.5">{m.name}</h4>
                          </div>
                          <span className="text-[10px] font-bold text-rose-300 bg-rose-950/40 border border-rose-500/20 px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0">
                            <Calendar className="w-3 h-3 text-rose-400" /> Due: {m.due || 'Aug 15, 2026'}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-[#7C8AA8]">
                          <span>Progress: <strong className="text-white">{m.completed}/{m.total} completed</strong></span>
                          <span className="text-slate-300 font-semibold">{pct}%</span>
                        </div>
                        <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-[#C9A46A] h-1.5 rounded-full transition-all duration-300" style={{ width: `${pct}%` }}></div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Earnings Breakdown & Creator Notices */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}15` }}
              className="border rounded-2xl p-5 space-y-4 shadow-sm"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-emerald-400" /> Earnings & Payout Breakdown
                  </h3>
                  <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                    Your personal campaign earnings and escrow distribution timeline
                  </p>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
                  80% Talent Cut
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 bg-black/20 rounded-xl border border-white/5">
                  <span className="text-[10px] uppercase font-bold text-[#7C8AA8]">Earnings This Month</span>
                  <div className="text-lg font-bold text-emerald-400 mt-1 font-mono">
                    ${Math.round(myScopedDeals.filter(d => d.stage === 'Live' || d.stage === 'Contracted' || d.stage === 'Completed').reduce((s, d) => s + (d.value || d.budget || 0), 0) * 0.8).toLocaleString()}
                  </div>
                  <span className="text-[9px] text-[#7C8AA8]">From signed active deals</span>
                </div>
                <div className="p-3.5 bg-black/20 rounded-xl border border-white/5">
                  <span className="text-[10px] uppercase font-bold text-[#7C8AA8]">Pending In Escrow</span>
                  <div className="text-lg font-bold text-[#C9A46A] mt-1 font-mono">
                    ${Math.round(myScopedDeals.filter(d => d.stage === 'Negotiating' || d.stage === 'Contracted' || d.stage === 'Live').reduce((s, d) => s + (d.value || d.budget || 0), 0) * 0.8).toLocaleString()}
                  </div>
                  <span className="text-[9px] text-[#7C8AA8]">Awaiting milestone release</span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <span className="text-[10px] font-bold uppercase text-[#C9A46A] tracking-wider block">
                  Campaign Itemization
                </span>
                <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                  {myScopedDeals.map(d => (
                    <div key={d.id} className="p-2.5 bg-black/10 border border-white/5 rounded-xl flex items-center justify-between text-xs">
                      <div className="min-w-0">
                        <div className="font-semibold text-white truncate">{d.title || `${d.brand} Campaign`}</div>
                        <div className="text-[10px] text-[#7C8AA8]">Brand: {d.brand}</div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-bold text-white font-mono">${Math.round((d.value || d.budget || 0) * 0.8).toLocaleString()}</div>
                        <div className="text-[9px] text-emerald-400 font-mono">Escrow Held</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Creator Notices */}
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}15` }}
              className="border rounded-2xl p-5 space-y-4 shadow-sm"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
                    <Megaphone className="w-5 h-5 text-purple-400" /> Creator Announcements
                  </h3>
                  <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                    Studio notices, policy updates, and casting opportunities
                  </p>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-purple-500/10 text-purple-300 rounded-full border border-purple-500/20">
                  Live Feed
                </span>
              </div>

              <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
                <div className="p-3.5 bg-black/20 border border-white/5 rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-bold uppercase px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20">
                      Policy & Compliance
                    </span>
                    <span className="text-[9px] font-mono text-slate-400">Active Standard</span>
                  </div>
                  <h4 className="text-xs font-semibold text-white">FTC Clear Disclosure Standard</h4>
                  <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
                    Ensure #ad or #sponsored is placed in the first 3 lines of TikTok & Instagram captions for all sponsored campaign deliverables.
                  </p>
                </div>

                <div className="p-3.5 bg-black/20 border border-white/5 rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-bold uppercase px-2 py-0.5 rounded bg-[#C9A46A]/10 text-[#C9A46A] border border-[#C9A46A]/20">
                      Open Casting Call
                    </span>
                    <span className="text-[9px] font-mono text-slate-400">Open Now</span>
                  </div>
                  <h4 className="text-xs font-semibold text-white">Brand Pitch Opportunity: GlowLab & HydroDaily</h4>
                  <p className="text-[11px] text-[#7C8AA8] leading-relaxed">
                    Review open briefs in Casting Calls to apply for upcoming high-value brand sponsorships and retainers.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* DIRECTOR, BRAND & AGENT MANAGER SECTIONS */
        <>
          {/* DIRECTOR INBOUND INTAKE & SUBMISSIONS COMMAND CENTER */}
          {isDirector && (
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}20` }}
              className="border rounded-2xl p-6 space-y-4 shadow-lg mb-6"
            >
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-white/10 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <h3 className="font-serif font-medium text-xl text-white flex items-center gap-2">
                      <Inbox className="w-5 h-5" style={{ color: primaryBrandColor }} /> Director Submissions &amp; Live Inbound Intake Command
                    </h3>
                  </div>
                  <p className="text-xs text-[#7C8AA8] mt-1">
                    Real-time stream of all turned-in forms &amp; submissions: Brand Showcase Inquiries, Creator Applications, Talent Referrals, &amp; Deliverables Turned In.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold px-3 py-1 bg-amber-500/10 text-amber-400 rounded-lg border border-amber-500/20">
                    {allIntakeItems.length} Total Submissions
                  </span>
                </div>
              </div>

              {/* Category Filter Pills */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  onClick={() => setIntakeCategoryFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium font-mono transition-all cursor-pointer ${
                    intakeCategoryFilter === 'all'
                      ? 'bg-[#C9A46A] text-slate-950 font-bold'
                      : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/5'
                  }`}
                >
                  All Submissions ({allIntakeItems.length})
                </button>
                <button
                  onClick={() => setIntakeCategoryFilter('leads')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                    intakeCategoryFilter === 'leads'
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 border border-amber-500/20'
                  }`}
                >
                  📩 Brand Inquiries ({allIntakeItems.filter(i => i.category === 'leads').length})
                </button>
                <button
                  onClick={() => setIntakeCategoryFilter('applications')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                    intakeCategoryFilter === 'applications'
                      ? 'bg-purple-500 text-white font-bold'
                      : 'bg-purple-500/10 text-purple-300 hover:bg-purple-500/20 border border-purple-500/20'
                  }`}
                >
                  🌟 Talent Waitlist ({allIntakeItems.filter(i => i.category === 'applications').length})
                </button>
                <button
                  onClick={() => setIntakeCategoryFilter('referrals')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                    intakeCategoryFilter === 'referrals'
                      ? 'bg-sky-500 text-slate-950 font-bold'
                      : 'bg-sky-500/10 text-sky-300 hover:bg-sky-500/20 border border-sky-500/20'
                  }`}
                >
                  🤝 Referrals ({allIntakeItems.filter(i => i.category === 'referrals').length})
                </button>
                <button
                  onClick={() => setIntakeCategoryFilter('deliverables')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium font-mono transition-all cursor-pointer flex items-center gap-1.5 ${
                    intakeCategoryFilter === 'deliverables'
                      ? 'bg-emerald-500 text-slate-950 font-bold'
                      : 'bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20 border border-emerald-500/20'
                  }`}
                >
                  🎬 Deliverables Turned In ({allIntakeItems.filter(i => i.category === 'deliverables').length})
                </button>
              </div>

              {/* Items Feed */}
              <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
                {allIntakeItems.filter(item => intakeCategoryFilter === 'all' || item.category === intakeCategoryFilter).length === 0 ? (
                  <div className="text-center py-10 bg-black/20 rounded-xl border border-white/5 space-y-2">
                    <Inbox className="w-8 h-8 text-slate-500 mx-auto" />
                    <p className="text-xs text-slate-300 font-semibold">No Submissions in this Category</p>
                    <p className="text-[10px] text-slate-500">New turned-in submissions will appear here in real time as they arrive.</p>
                  </div>
                ) : (
                  allIntakeItems
                    .filter(item => intakeCategoryFilter === 'all' || item.category === intakeCategoryFilter)
                    .map((item, idx) => {
                      const badgeStyles: Record<string, string> = {
                        amber: 'bg-amber-950/50 border-amber-500/30 text-amber-300',
                        purple: 'bg-purple-950/50 border-purple-500/30 text-purple-300',
                        sky: 'bg-sky-950/50 border-sky-500/30 text-sky-300',
                        emerald: 'bg-emerald-950/50 border-emerald-500/30 text-emerald-300'
                      };

                      return (
                        <div 
                          key={`${item.id}_${idx}`}
                          className="p-4 bg-black/20 hover:bg-black/30 border border-white/10 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 transition-all"
                        >
                          <div className="space-y-1 min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded-full border uppercase ${badgeStyles[item.badgeColor] || badgeStyles.amber}`}>
                                {item.categoryLabel}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">{item.time}</span>
                            </div>
                            <h4 className="text-sm font-semibold text-white leading-snug">{item.title}</h4>
                            <p className="text-xs text-[#C9A46A] font-medium">{item.subtitle}</p>
                            <p className="text-[11px] text-[#7C8AA8] leading-relaxed line-clamp-2">{item.detail}</p>
                          </div>

                          <div className="flex items-center gap-3 shrink-0 self-end sm:self-center pt-2 sm:pt-0">
                            <span className="text-xs font-mono font-bold text-white px-2.5 py-1 bg-black/40 rounded-lg border border-white/5">
                              {item.meta}
                            </span>
                            {item.category === 'leads' && onConvertLeadToDeal && (
                              <button
                                onClick={() => onConvertLeadToDeal(item)}
                                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold font-mono rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                              >
                                Convert to Deal <Check className="w-3 h-3" />
                              </button>
                            )}
                            {item.category === 'applications' && onApproveWaitlistEntry && (
                              <button
                                onClick={() => onApproveWaitlistEntry(item)}
                                className="px-3 py-1.5 bg-purple-500 hover:bg-purple-400 text-white text-xs font-bold font-mono rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                              >
                                Approve to Roster <Check className="w-3 h-3" />
                              </button>
                            )}
                            {onNavigate && item.screen && (
                              <button
                                onClick={() => onNavigate(item.screen)}
                                className="px-3 py-1.5 bg-[#C9A46A] hover:bg-[#E3C48F] text-slate-950 text-xs font-bold font-mono rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                              >
                                Review Submission <ArrowRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                )}
              </div>
            </div>
          )}

          {/* Double Column split: Alerts and Action Queue */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Active Alerts */}
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}10` }}
              className="border rounded-2xl p-5 space-y-4 shadow-sm"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" style={{ color: primaryBrandColor }} /> Recent Alerts
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/20">
                  {filteredNotifications.length} Active
                </span>
              </div>
              
              <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                {filteredNotifications.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-10 text-center">
                    <CheckCircle className="w-8 h-8 text-emerald-500/60 mb-2" />
                    <p className="text-xs font-semibold text-white">All Clear</p>
                    <p className="text-[10px] mt-0.5" style={{ color: textMutedColor }}>No active system alerts detected</p>
                  </div>
                ) : (
                  filteredNotifications.map((n, nIdx) => (
                    <div 
                      key={`${n.id || 'notif'}_${nIdx}`} 
                      className="p-3 bg-black/10 border border-white/5 rounded-xl flex gap-3 items-start relative hover:bg-black/20 transition-all"
                    >
                      <div className={`p-1.5 rounded-lg shrink-0 ${
                        n.type === 'danger' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        <AlertTriangle className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start gap-2">
                          <h4 className="text-xs font-semibold text-white truncate">{n.title}</h4>
                          <span className="text-[8px] font-mono opacity-60 uppercase shrink-0">
                            {(n as any).time || 'Just now'}
                          </span>
                        </div>
                        <p className="text-[10px] mt-1 leading-relaxed" style={{ color: textMutedColor }}>
                          {n.detail}
                        </p>
                      </div>
                      <button 
                        onClick={() => setNotifications(prev => prev.filter(x => x.id !== n.id))}
                        className="text-white/40 hover:text-white transition-colors text-xs font-mono font-bold pl-1 cursor-pointer"
                        title="Dismiss alert"
                      >
                        &times;
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Daily Action Queue Checklist (Dynamically Generated from Real Events) */}
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}10` }}
              className="border rounded-2xl p-5 space-y-4 shadow-sm"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-5 h-5" style={{ color: primaryBrandColor }} />
                  <h3 className="font-serif font-medium text-lg text-white">Daily Action Queue</h3>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowAddCustomTask(!showAddCustomTask)}
                    className="text-[10px] font-mono font-semibold px-2 py-1 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded-lg border border-white/10 flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3 h-3" /> Add Task
                  </button>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
                    {activeTaskList.filter(t => !t.completed).length} Remaining
                  </span>
                </div>
              </div>

              {/* Add Custom Task Form */}
              {showAddCustomTask && (
                <form onSubmit={handleAddCustomTask} className="p-3 bg-black/20 border border-white/10 rounded-xl space-y-2">
                  <input
                    type="text"
                    required
                    placeholder="Enter custom agency action task..."
                    value={customTaskInput}
                    onChange={e => setCustomTaskInput(e.target.value)}
                    className="w-full bg-[#111E33] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white outline-none focus:border-amber-400"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddCustomTask(false)}
                      className="px-2.5 py-1 text-[10px] text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1 text-[10px] font-semibold bg-[#C9A46A] hover:bg-[#E3C48F] text-slate-950 rounded-lg cursor-pointer transition-colors"
                    >
                      Save Task
                    </button>
                  </div>
                </form>
              )}
              
              <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
                {activeTaskList.length === 0 ? (
                  <div className="text-center py-8 text-slate-400 text-xs">
                    No pending action tasks. Everything is up to date!
                  </div>
                ) : (
                  activeTaskList.map(task => {
                    const badgeColors: Record<string, string> = {
                      rose: 'bg-rose-950/40 border-rose-500/30 text-rose-400',
                      amber: 'bg-amber-950/40 border-amber-500/30 text-amber-400',
                      sky: 'bg-sky-950/40 border-sky-500/30 text-sky-400',
                      purple: 'bg-purple-950/40 border-purple-500/30 text-purple-400',
                      emerald: 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400'
                    };
                    
                    return (
                      <div
                        key={task.id} 
                        className={`flex items-start justify-between gap-3 p-3 rounded-xl border border-white/5 transition-all ${
                          task.completed 
                            ? 'bg-black/5 opacity-50' 
                            : 'bg-black/10 hover:bg-black/20'
                        }`}
                      >
                        <label className="flex items-start gap-3 flex-1 min-w-0 cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={task.completed}
                            onChange={() => toggleTask(task.id, task.text)}
                            style={{ accentColor: primaryBrandColor }}
                            className="mt-1 w-4 h-4 rounded cursor-pointer shrink-0" 
                          />
                          <div className="min-w-0 flex-1">
                            <span className={`text-xs font-medium text-white block leading-snug ${task.completed ? 'line-through text-white/40' : ''}`}>
                              {task.text}
                            </span>
                            <div className="flex items-center gap-2 mt-1.5">
                              <span className={`text-[9px] border font-semibold px-2 py-0.5 rounded-full inline-block ${badgeColors[task.badgeColor] || badgeColors.sky}`}>
                                {task.badge}
                              </span>
                              {task.relatedScreen && onNavigate && !task.completed && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    onNavigate(task.relatedScreen!);
                                  }}
                                  className="text-[9px] font-mono text-[#C9A46A] hover:underline flex items-center gap-0.5 cursor-pointer"
                                >
                                  Open <ArrowRight className="w-2.5 h-2.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        </label>

                        {task.isCustom && (
                          <button
                            onClick={() => handleDeleteCustomTask(task.id)}
                            className="text-slate-500 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                            title="Delete custom task"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>

          {/* Reminder / Alert Automation & Live Status Feed */}
          <div className={`grid grid-cols-1 ${isDirector ? 'lg:grid-cols-2' : 'lg:grid-cols-1'} gap-6`}>
            
            {/* 1. Reminder / Alert Automation (Watches Scoped Data) */}
            <div 
              style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}10` }}
              className="border rounded-2xl p-5 space-y-4 shadow-sm"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <div>
                  <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
                    <Bell className="w-5 h-5" style={{ color: primaryBrandColor }} /> Alert &amp; Reminder Automation
                  </h3>
                  <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                    {isCoordinator
                      ? 'Real-time triggers watching deliverables and milestone pacing for your assigned creators.'
                      : (isAgentMgr || isAgent)
                        ? 'Real-time triggers watching deliverables and deals for your managed creator roster.'
                        : 'Real-time triggers watching agency contracts, missions, tax forms & invoices.'}
                  </p>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/20">
                  {isCoordinator ? '2 Active Watchers' : (isAgentMgr || isAgent) ? '2 Active Watchers' : '4 Active Watchers'}
                </span>
              </div>

              <div className="space-y-3">
                {/* Director View: Contract Expiring Watcher */}
                {isDirector && (
                  <div className="p-3 bg-black/20 border border-white/5 rounded-xl flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-rose-500/10 text-rose-400 shrink-0 mt-0.5">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-white">Active Contract Expirations</span>
                          <span className="text-[9px] font-mono bg-rose-950/40 text-rose-300 border border-rose-500/20 px-1.5 py-0.5 rounded">
                            {digestContractsExpiring} Monitored
                          </span>
                        </div>
                        <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                          {digestContractsExpiring > 0
                            ? `Monitoring ${digestContractsExpiring} active brand contracts for deliverables & renewal milestones.`
                            : 'All active agreements are currently in compliance.'}
                        </p>
                      </div>
                    </div>
                    <button
                      title="Dispatches an automated internal notification to follow up on this milestone"
                      onClick={() => handleNudge('contract-exp', 'Contract Monitor Alert', `Nudge dispatched for ${digestContractsExpiring} monitored agreements`)}
                      disabled={nudgedAlerts.includes('contract-exp')}
                      className="px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold bg-[#16243F] text-[#C9A46A] hover:bg-[#C9A46A] hover:text-slate-950 transition-colors shrink-0 disabled:opacity-40 cursor-pointer"
                    >
                      {nudgedAlerts.includes('contract-exp') ? 'Nudged ✓' : 'Nudge Me'}
                    </button>
                  </div>
                )}

                {/* Coordinator View: Assigned Campaign Deadlines Watcher */}
                {isCoordinator && (
                  <div className="p-3 bg-black/20 border border-white/5 rounded-xl flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 shrink-0 mt-0.5">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-white">Assigned Campaign Deadlines</span>
                          <span className="text-[9px] font-mono bg-sky-950/40 text-sky-300 border border-sky-500/20 px-1.5 py-0.5 rounded">
                            {myScopedCampaigns.length} Active
                          </span>
                        </div>
                        <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                          {myScopedCampaigns.length > 0
                            ? `Tracking deadlines and delivery milestones for ${myScopedCampaigns.length} assigned campaigns.`
                            : 'All assigned campaign deliverables are up to date.'}
                        </p>
                      </div>
                    </div>
                    <button
                      title="Dispatches an automated internal notification to follow up on this milestone"
                      onClick={() => handleNudge('coord-camp', 'Campaign Delivery Alert', `Reminder dispatched for ${myScopedCampaigns.length} assigned campaigns`)}
                      disabled={nudgedAlerts.includes('coord-camp')}
                      className="px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold bg-[#16243F] text-[#C9A46A] hover:bg-[#C9A46A] hover:text-slate-950 transition-colors shrink-0 disabled:opacity-40 cursor-pointer"
                    >
                      {nudgedAlerts.includes('coord-camp') ? 'Nudged ✓' : 'Nudge Me'}
                    </button>
                  </div>
                )}

                {/* Agent View: Managed Creator Deals Watcher */}
                {(isAgentMgr || isAgent) && (
                  <div className="p-3 bg-black/20 border border-white/5 rounded-xl flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 shrink-0 mt-0.5">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-white">Managed Talent Deals</span>
                          <span className="text-[9px] font-mono bg-amber-950/40 text-amber-300 border border-amber-500/20 px-1.5 py-0.5 rounded">
                            {myScopedDeals.length} Monitored
                          </span>
                        </div>
                        <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                          {myScopedDeals.length > 0
                            ? `Monitoring ${myScopedDeals.length} active sponsorships across your managed creator roster.`
                            : 'No active talent deals currently require attention.'}
                        </p>
                      </div>
                    </div>
                    <button
                      title="Dispatches an automated internal notification to follow up on this milestone"
                      onClick={() => handleNudge('agent-deals', 'Talent Deal Alert', `Reminder dispatched for ${myScopedDeals.length} managed deals`)}
                      disabled={nudgedAlerts.includes('agent-deals')}
                      className="px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold bg-[#16243F] text-[#C9A46A] hover:bg-[#C9A46A] hover:text-slate-950 transition-colors shrink-0 disabled:opacity-40 cursor-pointer"
                    >
                      {nudgedAlerts.includes('agent-deals') ? 'Nudged ✓' : 'Nudge Me'}
                    </button>
                  </div>
                )}

                {/* Deliverable Overdue Watcher (Scoped to user's assigned creators) */}
                <div className="p-3 bg-black/20 border border-white/5 rounded-xl flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 shrink-0 mt-0.5">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white">Deliverables &amp; Milestone Pace</span>
                        <span className="text-[9px] font-mono bg-amber-950/40 text-amber-300 border border-amber-500/20 px-1.5 py-0.5 rounded">
                          {digestDeliverablesOverdue} In Flight
                        </span>
                      </div>
                      <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                        {digestDeliverablesOverdue > 0 
                          ? `Tracking submission pace for ${digestDeliverablesOverdue} ${isCoordinator ? 'assigned' : isAgentMgr || isAgent ? 'managed' : 'active'} creator missions.`
                          : 'All scheduled mission deliverables are on schedule.'}
                      </p>
                    </div>
                  </div>
                  <button
                    title="Dispatches an automated internal notification to follow up on this milestone"
                    onClick={() => handleNudge('deliv-overdue', 'Deliverables Alert', `Nudge dispatched for ${digestDeliverablesOverdue} creator missions`)}
                    disabled={nudgedAlerts.includes('deliv-overdue')}
                    className="px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold bg-[#16243F] text-[#C9A46A] hover:bg-[#C9A46A] hover:text-slate-950 transition-colors shrink-0 disabled:opacity-40 cursor-pointer"
                  >
                    {nudgedAlerts.includes('deliv-overdue') ? 'Nudged ✓' : 'Nudge Me'}
                  </button>
                </div>

                {/* W-9 Missing Watcher (Director ONLY) */}
                {isDirector && (
                  <div className="p-3 bg-black/20 border border-white/5 rounded-xl flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 shrink-0 mt-0.5">
                        <Shield className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-white">W-9 Tax Compliance Engine</span>
                          <span className="text-[9px] font-mono bg-sky-950/40 text-sky-300 border border-sky-500/20 px-1.5 py-0.5 rounded">
                            {digestW9Missing} Required
                          </span>
                        </div>
                        <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                          {digestW9Missing > 0 
                            ? `Requires Form W-9 verification for: ${missingW9Creators.map(c => c.handle || c.name).join(', ')}`
                            : '100% of represented talent have verified IRS W-9 tax forms on file.'}
                        </p>
                      </div>
                    </div>
                    <button
                      title="Dispatches an automated internal notification to follow up on this milestone"
                      onClick={() => handleNudge('w9-missing', 'W-9 Compliance Alert', `Nudge dispatched for ${digestW9Missing} talent tax forms`)}
                      disabled={nudgedAlerts.includes('w9-missing')}
                      className="px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold bg-[#16243F] text-[#C9A46A] hover:bg-[#C9A46A] hover:text-slate-950 transition-colors shrink-0 disabled:opacity-40 cursor-pointer"
                    >
                      {nudgedAlerts.includes('w9-missing') ? 'Nudged ✓' : 'Nudge Me'}
                    </button>
                  </div>
                )}

                {/* Escrow & Invoice Watcher (Director ONLY) */}
                {isDirector && (
                  <div className="p-3 bg-black/20 border border-white/5 rounded-xl flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 shrink-0 mt-0.5">
                        <Receipt className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-white">Escrow Settlement &amp; Billing</span>
                          <span className="text-[9px] font-mono bg-purple-950/40 text-purple-300 border border-purple-500/20 px-1.5 py-0.5 rounded">
                            {overdueInvoicesList.length > 0 ? `${overdueInvoicesList.length} Due` : 'Healthy'}
                          </span>
                        </div>
                        <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                          {overdueInvoicesList.length > 0
                            ? `Reconciliation needed for ${overdueInvoicesList.map(i => i.brandName || i.brand || 'Brand').join(', ')}`
                            : `Total active escrow pipeline secured: $${myScopedDeals.reduce((s, d) => s + (d.budget || d.value || 0), 0).toLocaleString()}`}
                        </p>
                      </div>
                    </div>
                    <button
                      title="Dispatches an automated internal notification to follow up on this milestone"
                      onClick={() => handleNudge('inv-overdue', 'Escrow Billing Alert', 'Nudge dispatched for escrow billing reconciliation')}
                      disabled={nudgedAlerts.includes('inv-overdue')}
                      className="px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold bg-[#16243F] text-[#C9A46A] hover:bg-[#C9A46A] hover:text-slate-950 transition-colors shrink-0 disabled:opacity-40 cursor-pointer"
                    >
                      {nudgedAlerts.includes('inv-overdue') ? 'Nudged ✓' : 'Nudge Me'}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* 2. Live Status-Change Stream (Real Activity Logs) - Director ONLY */}
            {isDirector && (
              <div 
                style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}10` }}
                className="border rounded-2xl p-5 space-y-4 shadow-sm"
              >
                <div className="flex justify-between items-center border-b border-white/5 pb-3">
                  <div>
                    <h3 className="font-serif font-medium text-lg text-white flex items-center gap-2">
                      <Send className="w-5 h-5 text-emerald-400" /> Live Event Stream
                    </h3>
                    <p className="text-[10px] text-[#7C8AA8] mt-0.5">
                      Real-time log of team actions, deal launches, approvals and verifications
                    </p>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
                    Live Stream
                  </span>
                </div>

                <div className="space-y-2.5 max-h-[310px] overflow-y-auto pr-1">
                  {statusChangeLogs.map(log => (
                    <div 
                      key={log.id}
                      className="p-3 bg-black/20 border border-white/5 rounded-xl flex items-start gap-3 text-xs"
                    >
                      <div className={`p-1.5 rounded-lg shrink-0 mt-0.5 ${
                        log.type === 'submits' ? 'bg-sky-500/10 text-sky-400' : 'bg-emerald-500/10 text-emerald-400'
                      }`}>
                        <Check className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] font-semibold text-white leading-snug truncate">{log.text}</span>
                          <span className="text-[9px] font-mono text-slate-500 shrink-0">{log.time}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[9px] font-mono bg-emerald-950/40 text-emerald-300 border border-emerald-500/20 px-1.5 py-0.5 rounded">
                            {log.status}
                          </span>
                          <span className="text-[10px] text-[#7C8AA8]">System recorded</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

          {/* Active Campaigns Roll-up */}
          <div 
            style={{ backgroundColor: cardBgColor, borderColor: `${primaryBrandColor}10` }}
            className="border rounded-2xl p-6 shadow-sm"
          >
            <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
              <div>
                <h3 className="font-serif font-medium text-lg text-white">Active Campaigns Roll-up</h3>
                <p className="text-[11px]" style={{ color: textMutedColor }}>Tracking milestones and publication progress across signed creators</p>
              </div>
              <div className="flex items-center gap-2">
                {onNavigate && (
                  <button
                    onClick={() => onNavigate('missions')}
                    className="text-xs text-[#C9A46A] hover:underline flex items-center gap-1 font-mono cursor-pointer"
                  >
                    View Missions <ArrowRight className="w-3 h-3" />
                  </button>
                )}
                <span className="text-xs font-bold text-white px-3 py-1 rounded-lg bg-black/20 font-mono" style={{ color: primaryBrandColor }}>
                  {myScopedMissions.length} Missions
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {myScopedMissions.length === 0 ? (
                <div className="col-span-3 text-center py-8 text-slate-400 text-xs">
                  No active missions found. Launch a new campaign to begin tracking.
                </div>
              ) : (
                myScopedMissions.map((mission) => {
                  const percent = Math.min(100, Math.round((mission.completed / Math.max(1, mission.total)) * 100));
                  return (
                    <div key={mission.id} className="p-4 bg-black/10 rounded-xl border border-white/5 space-y-3">
                      <div className="flex justify-between items-start gap-2">
                        <div className="min-w-0">
                          <h4 className="text-xs font-semibold text-white truncate max-w-[150px]">{mission.name}</h4>
                          <span className="text-[9px] block" style={{ color: textMutedColor }}>Creator: {mission.creator}</span>
                        </div>
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                          mission.status === 'Completed' 
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                            : mission.status === 'Delayed'
                            ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          {mission.status}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px]">
                          <span style={{ color: textMutedColor }}>Progress</span>
                          <span className="font-bold text-white font-mono">{mission.completed}/{mission.total} posts ({percent}%)</span>
                        </div>
                        <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                          <div 
                            className="h-full rounded-full transition-all duration-500"
                            style={{ 
                              width: `${percent}%`,
                              backgroundColor: mission.status === 'Completed' ? '#10b981' : primaryBrandColor
                            }}
                          ></div>
                        </div>
                      </div>

                      <div className="flex justify-between items-center text-[10px] border-t border-white/5 pt-2 mt-1">
                        <span style={{ color: textMutedColor }}>
                          Budget:{' '}
                          <span className="text-white font-semibold font-mono">
                            {isCoordinator ? (
                              <span className="text-amber-500 font-mono text-[9px] uppercase tracking-wider font-bold">Masked</span>
                            ) : (
                              `$${(mission.budget || 0).toLocaleString()}`
                            )}
                          </span>
                        </span>
                        <span style={{ color: textMutedColor }}>Due: <span className="text-white font-semibold">{mission.due || '30 Days'}</span></span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </>
      )}

    </div>
  );
}
