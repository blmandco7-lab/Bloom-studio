import React, { useState } from 'react';
import { 
  Film, FileText, CheckCircle2, Package, Sparkles, Layers, 
  Calendar, ShieldCheck, RefreshCw, Filter, Video, Search, ChevronRight
} from 'lucide-react';
import { Creator, Deal, Role } from '../types';
import CreativeBriefingStudio from './CreativeBriefingStudio';
import ContentReview from './ContentReview';
import ContentLibrary from './ContentLibrary';
import FulfillmentHub from './FulfillmentHub';
import { UnifiedCalendarHub } from './UnifiedCalendarHub';

interface CreativeProductionSuiteProps {
  creators: Creator[];
  deals: Deal[];
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (user: string, role: string, action: string) => void;
  triggerNotification?: (title: string, message: string, type?: any) => void;
  primaryBrandColor?: string;
  cardBgColor?: string;
}

export default function CreativeProductionSuite({
  creators = [],
  deals = [],
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification,
  primaryBrandColor = '#C9A46A',
  cardBgColor = '#0D1830'
}: CreativeProductionSuiteProps) {
  const [activeTab, setActiveTab] = useState<'briefs' | 'review' | 'fulfillment' | 'calendar'>('briefs');

  const userProfile = {
    id: currentUser?.id || 'dir_1',
    name: currentUser?.name || 'User',
    handle: currentUser?.handle || '@director',
    role: (currentRole === 'director' ? 'Owner' : 'Manager') as 'Owner' | 'Manager' | 'Talent'
  };

  return (
    <div className="space-y-6 animate-fade-in text-slate-100 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1830] border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#C9A46A]/20 border border-[#C9A46A]/40 flex items-center justify-center text-[#C9A46A] shrink-0">
            <Film className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#C9A46A] bg-[#C9A46A]/10 border border-[#C9A46A]/30 px-3 py-0.5 rounded-full">
                UNIFIED CREATIVE PRODUCTION WORKSPACE
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Live Workflow
              </span>
            </div>
            <h1 className="font-serif font-bold text-2xl md:text-3xl text-white mt-1">
              Creative Production Suite
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Unified hub for AI creative briefs, deliverable review queues, product sample fulfillment, and production calendars.
            </p>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('briefs')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'briefs'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Briefing Studio &amp; Library</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('review')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'review'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Review &amp; FTC Approvals</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fulfillment')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'fulfillment'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Gifting &amp; Sample Fulfillment</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('calendar')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
            activeTab === 'calendar'
              ? 'bg-[#C9A46A] text-[#0A1220] shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Production Calendar &amp; Deliverables</span>
        </button>
      </div>

      {/* TAB CONTENT: Briefs Studio & Content Library */}
      {activeTab === 'briefs' && (
        <div className="space-y-8">
          <CreativeBriefingStudio
            creators={creators}
            currentUser={currentUser}
            currentRole={currentRole}
            onAddActivityLog={onAddActivityLog}
            triggerNotification={triggerNotification}
          />
          <div className="pt-4 border-t border-white/10">
            <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-[#C9A46A] mb-4">
              Approved Assets &amp; Content Vault
            </h3>
            <ContentLibrary
              creators={creators}
              deals={deals}
              currentUser={currentUser}
              currentRole={currentRole}
              onAddActivityLog={onAddActivityLog || (() => {})}
              triggerNotification={triggerNotification || (() => {})}
            />
          </div>
        </div>
      )}

      {/* TAB CONTENT: Content Review */}
      {activeTab === 'review' && (
        <ContentReview
          creators={creators}
          deals={deals}
          currentUser={currentUser}
          currentRole={currentRole}
          onAddActivityLog={onAddActivityLog || (() => {})}
          triggerNotification={triggerNotification || (() => {})}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
        />
      )}

      {/* TAB CONTENT: Fulfillment Hub */}
      {activeTab === 'fulfillment' && (
        <FulfillmentHub
          user={userProfile as any}
          creators={creators}
        />
      )}

      {/* TAB CONTENT: Production Calendar */}
      {activeTab === 'calendar' && (
        <UnifiedCalendarHub defaultTab="production"
          creators={creators}
          deals={deals}
          currentRole={currentRole as Role}
          currentUser={currentUser}
          onAddActivityLog={onAddActivityLog}
          triggerNotification={triggerNotification}
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
        />
      )}
    </div>
  );
}
