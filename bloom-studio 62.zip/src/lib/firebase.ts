import { initializeApp, getApps, getApp } from 'firebase/app';
import { initializeAppCheck, ReCaptchaV3Provider, getToken } from 'firebase/app-check';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc,
  getDocs,
  deleteDoc, 
  onSnapshot, 
  writeBatch,
  query,
  where,
  orderBy
} from 'firebase/firestore';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  indexedDBLocalPersistence,
  inMemoryPersistence,
  User as FirebaseUser
} from 'firebase/auth';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';
import { safeStorage } from '../utils/safeStorage';

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize App Check with reCAPTCHA v3 if site key is provided
let appCheckInstance: any = null;

if (typeof window !== 'undefined' && (import.meta as any).env.VITE_RECAPTCHA_SITE_KEY) {
  try {
    appCheckInstance = initializeAppCheck(app, {
      provider: new ReCaptchaV3Provider((import.meta as any).env.VITE_RECAPTCHA_SITE_KEY),
      isTokenAutoRefreshEnabled: true
    });
  } catch (err) {
    console.warn('[AppCheck] Initialization failed:', err);
  }
}

/**
 * Retrieves a valid App Check token for authenticating backend requests.
 */
export async function getAppCheckToken(): Promise<string | null> {
  if (typeof window === 'undefined' || !appCheckInstance) return null;
  try {
    const res = await getToken(appCheckInstance);
    return res.token;
  } catch (err) {
    console.warn('[AppCheck] Failed to retrieve token:', err);
    return null;
  }
}

// Initialize Firestore using the specified database ID or default
export const db = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Initialize Firebase Storage
export const storage = getStorage(app);

// Initialize Firebase Auth with Resilient Persistence (IndexedDB -> Local -> Memory)
export const auth = getAuth(app);
(async () => {
  let isIdbUsable = false;
  try {
    if (typeof window !== 'undefined' && window.indexedDB) {
      const test = window.indexedDB.open('__ais_auth_probe__');
      if (test) {
        test.onerror = () => {};
        test.onsuccess = () => {
          try { test.result.close(); } catch (_) {}
        };
        isIdbUsable = true;
      }
    }
  } catch {}

  let isLsUsable = false;
  try {
    if (typeof window !== 'undefined') {
      const probe = '__ais_ls_probe__';
      safeStorage.setItem(probe, probe);
      safeStorage.removeItem(probe);
      isLsUsable = true;
    }
  } catch {}

  if (isIdbUsable) {
    try {
      await setPersistence(auth, indexedDBLocalPersistence);
      return;
    } catch {}
  }

  if (isLsUsable) {
    try {
      await setPersistence(auth, browserLocalPersistence);
      return;
    } catch {}
  }

  try {
    await setPersistence(auth, inMemoryPersistence);
  } catch (err) {
    console.warn('Could not set inMemoryPersistence:', err);
  }
})();

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export async function signInWithGoogle() {
  try {
    let idbOk = false;
    try {
      idbOk = typeof window !== 'undefined' && !!window.indexedDB;
    } catch {}
    if (idbOk) {
      await setPersistence(auth, indexedDBLocalPersistence).catch(() => 
        setPersistence(auth, inMemoryPersistence).catch(() => {})
      );
    } else {
      await setPersistence(auth, inMemoryPersistence).catch(() => {});
    }
  } catch {}
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (err: any) {
    if (err?.code === 'auth/popup-blocked') {
      const popupErr = new Error('Popup blocked by browser. Please allow popups or use the direct workspace sign-in option below.');
      (popupErr as any).code = 'auth/popup-blocked';
      throw popupErr;
    }
    throw err;
  }
}

export async function handleAuthRedirectResult() {
  try {
    const res = await getRedirectResult(auth);
    if (res?.user) {
      return res.user;
    }
  } catch (err) {
    console.error('Error handling auth redirect result:', err);
  }
  return null;
}

export async function logoutUser() {
  safeStorage.removeItem("wl_session_token");
  return await signOut(auth);
}

/**
 * Gets or creates user profile at top-level `studio-users/{uid}` and `tenants/{tenantId}/users/{uid}`.
 * Verified roles are fetched from the database; new unapproved users start with `role: 'none'`.
 */
export async function getOrCreateUserProfile(tenantId: string, user: FirebaseUser) {
  const studioUserRef = doc(db, 'studio-users', user.uid);
  const tenantUserRef = doc(db, 'tenants', tenantId || 'bloom_studio_default', 'users', user.uid);
  const topUsersRef = doc(db, 'users', user.uid);

  let snap: any = null;
  let primaryRef = studioUserRef;

  try {
    const readPromise = async () => {
      let s = await getDoc(studioUserRef);
      if (!s.exists()) {
        const topSnap = await getDoc(topUsersRef);
        if (topSnap.exists()) {
          s = topSnap;
          primaryRef = topUsersRef;
        } else {
          const tenantSnap = await getDoc(tenantUserRef);
          if (tenantSnap.exists()) {
            s = tenantSnap;
            primaryRef = tenantUserRef;
          }
        }
      }
      return s;
    };
    snap = await Promise.race([
      readPromise(),
      new Promise<null>((_, reject) => setTimeout(() => reject(new Error('Firestore profile read timeout / quota exceeded')), 4000))
    ]);
  } catch (err: any) {
    console.warn('[getOrCreateUserProfile] Non-fatal profile read warning (quota exceeded or timeout):', err?.message || err);
    snap = null;
  }

  const userEmailLower = user.email?.toLowerCase() || '';
  // Platform ownership is no longer hardcoded email strings in client code - it's a Firestore
  // lookup instead, so adding/removing an owner is a data change, not a code change/redeploy.
  // Uses the exact email string Firebase Auth returns (not lowercased) so it matches
  // request.auth.token.email exactly in the security rule - Firebase Auth returns the same
  // casing consistently for the same account every time, so this is reliable without needing
  // case-insensitive comparison in the rules language.
  let isOwner = false;
  try {
    const ownerCheckRef = doc(db, 'platform-owners', user.email || '__none__');
    const ownerSnap: any = await Promise.race([
      getDoc(ownerCheckRef),
      new Promise<null>((_, reject) => setTimeout(() => reject(new Error('Owner check timeout')), 2500))
    ]);
    isOwner = !!(ownerSnap && ownerSnap.exists() && ownerSnap.data()?.active !== false);
  } catch (err) {
    console.warn('[getOrCreateUserProfile] Could not verify platform owner status (defaulting to false):', err);
    isOwner = false;
  }

  let requestedRole = 'creator';
  let pod = 'Main Agency';
  let invitedByCode = '';
  let pendingStatus = 'Active';
  let initialRole = isOwner ? 'director' : 'none';

  try {
    const pendingCode = typeof window !== 'undefined' ? safeStorage.getItem('wl_pending_invite_code') : null;
    if (pendingCode && !isOwner) {
      const savedCodes = JSON.parse(safeStorage.getItem('wl_access_codes') || '[]');
      const matched = savedCodes.find((c: any) => c.code?.toUpperCase() === pendingCode.trim().toUpperCase());
      if (matched) {
        requestedRole = matched.role || 'creator';
        pod = matched.pod || 'Main Agency';
        invitedByCode = matched.code;
        pendingStatus = 'Pending Approval';
        initialRole = 'none'; // Walled into pod pending approval queue
      }
    }

    // Verify agency/director owner role legitimately: check if email matches tenant admin/owner email in Firestore
    if (!isOwner && userEmailLower) {
      try {
        const pendingSub = typeof window !== 'undefined' ? safeStorage.getItem('pending_paid_subdomain') : null;
        const checkTenantId = (tenantId && tenantId !== 'bloom_studio_default') ? tenantId : (pendingSub || '');
        if (checkTenantId) {
          const tenantDocRef = doc(db, 'tenants', checkTenantId);
          const tenantSnap: any = await Promise.race([
            getDoc(tenantDocRef),
            new Promise<null>((_, reject) => setTimeout(() => reject(new Error('Tenant doc read timeout')), 2000))
          ]);
          if (tenantSnap && tenantSnap.exists()) {
            const tData = tenantSnap.data();
            const tAdmin = (tData?.adminEmail || tData?.ownerEmail || '').toLowerCase();
            if (tAdmin === userEmailLower) {
              initialRole = 'director';
              requestedRole = 'director';
              pod = checkTenantId;
              pendingStatus = 'Active';
            }
          }
        }
      } catch (errInner) {
        // ignore read permission check or timeout on unassigned tenant doc
      }
    }
  } catch (e) {
    console.error('Error matching pending invite code:', e);
  }

  const computedName = user.displayName || user.email?.split('@')[0] || 'User';
  const computedHandle = `@${(computedName).toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '') || 'user'}`;

  if (snap && snap.exists()) {
    const data = snap.data() || {};
    let updatedProfile = { ...data };
    let changed = false;

    if (!updatedProfile.role) {
      updatedProfile.role = isOwner ? 'director' : 'creator';
      changed = true;
    }
    if (!updatedProfile.handle) {
      updatedProfile.handle = computedHandle;
      changed = true;
    }
    if (!updatedProfile.subagency) {
      updatedProfile.subagency = 'pod_main';
      changed = true;
    }
    if (!updatedProfile.tenantId) {
      updatedProfile.tenantId = tenantId || 'bloom_studio_default';
      changed = true;
    }
    if (isOwner && updatedProfile.role !== 'director') {
      updatedProfile.role = 'director';
      changed = true;
    }
    if ((initialRole === 'director' || initialRole === 'agency') && updatedProfile.role !== 'director') {
      updatedProfile.role = 'director';
      updatedProfile.subagency = pod || tenantId || 'pod_main';
      updatedProfile.tenantId = pod || tenantId || 'bloom_studio_default';
      updatedProfile.status = 'Active';
      changed = true;
    }
    if (updatedProfile.role === 'none' && invitedByCode && (!updatedProfile.invitedByCode || updatedProfile.invitedByCode !== invitedByCode)) {
      updatedProfile.requestedRole = requestedRole;
      updatedProfile.pod = pod;
      updatedProfile.invitedByCode = invitedByCode;
      updatedProfile.status = 'Pending Approval';
      changed = true;
    }

    let writeConfirmed = true;
    if (changed) {
      try {
        const writePromise = Promise.all([
          setDoc(studioUserRef, updatedProfile, { merge: true }),
          setDoc(tenantUserRef, updatedProfile, { merge: true }),
          setDoc(topUsersRef, updatedProfile, { merge: true })
        ]);
        await Promise.race([
          writePromise,
          new Promise((_, reject) => setTimeout(() => reject(new Error('Profile update write timeout')), 2500))
        ]);
        writeConfirmed = true;
      } catch (err: any) {
        console.warn('[getOrCreateUserProfile] Firestore write failed or unconfirmed when syncing existing profile docs:', err?.message || err);
        writeConfirmed = false;
      }
    }

    if (!writeConfirmed) {
      if (isOwner) {
        return updatedProfile;
      }
      // The database write failed to confirm these privilege changes.
      // Revert privilege fields to what the database write actually confirmed in `data`,
      // and stop returning privilege fields that only exist in memory.
      const safeProfile: any = { ...updatedProfile };
      if (data.role !== undefined) safeProfile.role = data.role; else delete safeProfile.role;
      if (data.status !== undefined) safeProfile.status = data.status; else delete safeProfile.status;
      if (data.subagency !== undefined) safeProfile.subagency = data.subagency; else delete safeProfile.subagency;
      if (data.tenantId !== undefined) safeProfile.tenantId = data.tenantId; else delete safeProfile.tenantId;
      return safeProfile;
    }

    if (typeof window !== 'undefined') {
      try {
        safeStorage.setItem(`wl_cached_profile_${user.uid}`, JSON.stringify(updatedProfile));
      } catch (_) {}
    }

    return updatedProfile;
  } else {
    // If the document definitely does not exist in Firestore, do not trust stale cached privilege fields
    if (snap && !snap.exists() && typeof window !== 'undefined') {
      try {
        safeStorage.removeItem(`wl_cached_profile_${user.uid}`);
      } catch (_) {}
    } else if (!snap && typeof window !== 'undefined') {
      try {
        const cached = safeStorage.getItem(`wl_cached_profile_${user.uid}`);
        if (cached) {
          const parsed = JSON.parse(cached);
          if (parsed && (parsed.role || isOwner)) {
            if (isOwner && parsed.role !== 'director') {
              parsed.role = 'director';
            }
            console.warn('[getOrCreateUserProfile] Using locally cached user profile due to Firestore read timeout/quota.');
            return parsed;
          }
        }
      } catch (_) {}
    }

    const newUserProfile: any = {
      uid: user.uid,
      id: user.uid,
      email: user.email || '',
      name: computedName,
      handle: computedHandle,
      subagency: 'pod_main',
      tenantId: tenantId || 'bloom_studio_default',
      photoURL: user.photoURL || '',
      role: initialRole,
      requestedRole: isOwner ? 'director' : requestedRole,
      pod: isOwner ? 'Main Agency' : pod,
      invitedByCode: isOwner ? 'OWNER_ACCOUNT' : invitedByCode,
      status: isOwner ? 'Active' : pendingStatus,
      isPlatformOwner: isOwner,
      createdAt: new Date().toISOString()
    };

    let writeConfirmed = false;
    try {
      const writePromise = Promise.all([
        setDoc(studioUserRef, newUserProfile),
        setDoc(tenantUserRef, newUserProfile),
        setDoc(topUsersRef, newUserProfile)
      ]);
      await Promise.race([
        writePromise,
        new Promise((_, reject) => setTimeout(() => reject(new Error('Profile create write timeout')), 2500))
      ]);
      writeConfirmed = true;
    } catch (err: any) {
      console.warn('[getOrCreateUserProfile] Firestore write failed or unconfirmed when creating new profile docs:', err?.message || err);
      writeConfirmed = false;
    }

    if (!writeConfirmed) {
      if (isOwner) {
        return newUserProfile;
      }
      // The Firestore write failed. Stop returning privilege fields that only exist in memory.
      const { role, status, subagency, tenantId: _tId, ...unconfirmedProfile } = newUserProfile;
      return unconfirmedProfile;
    }

    if (typeof window !== 'undefined') {
      try {
        safeStorage.setItem(`wl_cached_profile_${user.uid}`, JSON.stringify(newUserProfile));
      } catch (_) {}
    }

    return newUserProfile;
  }
}

/**
 * Updates a user's role and status in `studio-users/{uid}`, `tenants/{tenantId}/users/{uid}`, and `users/{uid}`.
 */
export async function setUserRoleInFirestore(tenantId: string, uid: string, role: string, status?: string) {
  const targetTenant = tenantId || 'bloom_studio_default';
  const studioUserRef = doc(db, 'studio-users', uid);
  const tenantUserRef = doc(db, 'tenants', targetTenant, 'users', uid);
  const topUsersRef = doc(db, 'users', uid);
  
  const finalStatus = status || (role === 'none' ? 'Pending Approval' : 'Active');
  const updatePayload = {
    role,
    status: finalStatus,
    subagency: 'pod_main',
    tenantId: targetTenant,
    updatedAt: new Date().toISOString()
  };

  try {
    await Promise.allSettled([
      setDoc(studioUserRef, updatePayload, { merge: true }),
      setDoc(tenantUserRef, updatePayload, { merge: true }),
      setDoc(topUsersRef, updatePayload, { merge: true })
    ]);
  } catch (err) {
    console.error('[setUserRoleInFirestore] Failed to sync role to Firestore:', err);
  }
}

/**
 * Subscribes to all users in `studio-users`, scoped to userPodId unless user is platform owner.
 */
export function subscribeTenantUsers(
  tenantId: string,
  onData: (users: any[]) => void,
  userPodId?: string,
  isPlatformOwner?: boolean
): () => void {
  const colRef = collection(db, 'studio-users');
  const targetQuery = (!isPlatformOwner && userPodId) ? query(colRef, where('subagency', '==', userPodId)) : colRef;
  return onSnapshot(targetQuery, (snapshot) => {
    const users: any[] = [];
    snapshot.forEach((docSnap) => {
      users.push({ ...docSnap.data(), id: docSnap.id });
    });
    if (users.length > 0) {
      onData(users);
    } else {
      // Fallback to tenants/.../users if studio-users is empty
      const tenantColRef = collection(db, 'tenants', tenantId || 'bloom_studio_default', 'users');
      onSnapshot(tenantColRef, (tenantSnap) => {
        const tenantUsers: any[] = [];
        tenantSnap.forEach((docSnap) => {
          tenantUsers.push({ ...docSnap.data(), id: docSnap.id });
        });
        onData(tenantUsers);
      }, (err) => {
        console.warn('Error subscribing to fallback tenant users:', err);
      });
    }
  }, (err) => {
    console.warn('Error subscribing to studio-users:', err);
  });
}

/**
 * Subscribes in real-time to a top-level operational Firestore collection (creators, deals, missions, etc.).
 * Automatically scopes the Firestore query to the current user's pod unless they are Platform Owner.
 */
export function subscribeOperationalCollection<T extends { id?: string; subagency?: string }>(
  collectionName: string,
  onData: (items: T[]) => void,
  userPodId?: string,
  isPlatformOwner?: boolean
): () => void {
  const colRef = collection(db, collectionName);
  const targetQuery = (!isPlatformOwner && userPodId)
    ? query(colRef, where('subagency', '==', userPodId))
    : colRef;
  return onSnapshot(targetQuery, (snapshot) => {
    const items: T[] = [];
    snapshot.forEach((docSnap) => {
      items.push({ ...docSnap.data(), id: docSnap.id } as T);
    });
    onData(items);
  }, (err) => {
    console.warn(`Error subscribing to operational collection [${collectionName}]:`, err);
  });
}


/**
 * Subscribes in real-time to a Firestore subcollection under `tenants/{tenantId}/{collectionName}`.
 * If the collection is empty in Firestore, automatically seeds it with `defaultSeed`.
 */
export function subscribeTenantCollection<T extends { id?: string; subagency?: string }>(
  tenantId: string,
  collectionName: string,
  onData: (items: T[]) => void,
  defaultSeed: T[] = [],
  userPodId?: string,
  isDirector?: boolean
): () => void {
  const colRef = collection(db, 'tenants', tenantId || 'bloom_studio_default', collectionName);
  const scopedPod = userPodId || (collectionName === 'creators' ? 'pod_main' : undefined);
  const targetQuery = scopedPod
    ? query(colRef, where('subagency', '==', scopedPod))
    : colRef;

  let isSeeding = false;

  const unsubscribe = onSnapshot(
    targetQuery,
    async (snapshot) => {
      if (snapshot.empty && defaultSeed.length > 0 && !isSeeding) {
        isSeeding = true;
        try {
          const batch = writeBatch(db);
          defaultSeed.forEach((item, index) => {
            const itemId = item.id || `${collectionName}_${Date.now()}_${index}`;
            const itemRef = doc(db, 'tenants', tenantId || 'bloom_studio_default', collectionName, itemId);
            const subagencyVal = item.subagency || 'pod_main';
            batch.set(itemRef, { ...item, id: itemId, subagency: subagencyVal });
          });
          await batch.commit();
        } catch (e) {
          console.error(`Error seeding Firestore collection [${collectionName}] for tenant [${tenantId}]:`, e);
          onData(defaultSeed);
        } finally {
          isSeeding = false;
        }
        return;
      }

      const items: T[] = [];
      snapshot.forEach((docSnap) => {
        items.push({ ...docSnap.data(), id: docSnap.id } as T);
      });

      if (items.length > 0) {
        onData(items);
      } else {
        onData(defaultSeed);
      }
    },
    (error) => {
      console.warn(`Firestore listener error on [${collectionName}] for tenant [${tenantId}]:`, error);
      // Fallback to local default data on error
      onData(defaultSeed);
    }
  );

  return unsubscribe;
}

/**
 * Removes any undefined fields from an object so Firestore setDoc/batch.set does not throw an error.
 */
/**
 * Deep cleans an object for Firestore by removing undefined values and optionally converting
 * nulls or other incompatible types.
 */
export function cleanForFirestore(obj: any): any {
  if (obj === undefined) return null;
  if (obj === null || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(cleanForFirestore);
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) out[k] = cleanForFirestore(v);
  }
  return out;
}

/**
 * Shorthand for shallow cleaning undefined properties.
 */
export function cleanUndefinedForFirestore(obj: any): any {
  if (obj === null || typeof obj !== 'object') return obj;
  const copy = { ...obj };
  Object.keys(copy).forEach(key => {
    if (copy[key] === undefined) {
      delete copy[key];
    }
  });
  return copy;
}

function cleanUndefinedProps(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;
  const copy = { ...obj };
  Object.keys(copy).forEach(key => {
    if (copy[key] === undefined) {
      delete copy[key];
    }
  });
  return copy;
}

/**
 * Saves or updates a document in a tenant collection.
 */
export async function saveTenantDocument(
  tenantId: string,
  collectionName: string,
  docId: string,
  data: any
): Promise<void> {
  try {
    const docRef = doc(db, 'tenants', tenantId || 'bloom_studio_default', collectionName, docId);
    const stampedData = cleanUndefinedProps({ ...data, subagency: data.subagency || 'pod_main', id: docId });
    await setDoc(docRef, stampedData, { merge: true });
  } catch (e) {
    console.error(`Error saving document [${docId}] to [${collectionName}]:`, e);
  }
}

/**
 * Deletes a document from a tenant collection.
 */
export async function deleteTenantDocument(
  tenantId: string,
  collectionName: string,
  docId: string
): Promise<void> {
  try {
    const docRef = doc(db, 'tenants', tenantId || 'bloom_studio_default', collectionName, docId);
    await deleteDoc(docRef);
  } catch (e) {
    console.error(`Error deleting document [${docId}] from [${collectionName}]:`, e);
  }
}

/**
 * Replaces or bulk updates an entire tenant collection in Firestore.
 */
export async function syncEntireTenantCollection(
  tenantId: string,
  collectionName: string,
  items: any[]
): Promise<void> {
  try {
    const batch = writeBatch(db);
    items.forEach((item, index) => {
      const itemId = item.id || `${collectionName}_${Date.now()}_${index}`;
      const itemRef = doc(db, 'tenants', tenantId || 'bloom_studio_default', collectionName, itemId);
      batch.set(itemRef, cleanUndefinedProps({ ...item, subagency: item.subagency || 'pod_main', id: itemId }));
    });
    await batch.commit();
  } catch (e) {
    console.error(`Error syncing bulk collection [${collectionName}]:`, e);
  }
}

/**
 * Saves or updates a document in a top-level studio collection (like studio-creators, studio-contracts, etc.).
 * Stamps subagency: 'pod_main' on every write.
 */
export async function saveStudioDocument(
  collectionName: string,
  docId: string,
  data: any
): Promise<void> {
  try {
    const docRef = doc(db, collectionName, docId);
    const stampedData = cleanUndefinedProps({
      ...data,
      subagency: data.subagency || 'pod_main',
      id: docId
    });
    await setDoc(docRef, stampedData, { merge: true });
  } catch (e) {
    console.error(`Error saving document [${docId}] to [${collectionName}]:`, e);
  }
}

/**
 * Deletes a document from a top-level studio collection.
 */
export async function deleteStudioDocument(
  collectionName: string,
  docId: string
): Promise<void> {
  try {
    const docRef = doc(db, collectionName, docId);
    await deleteDoc(docRef);
  } catch (e) {
    console.error(`Error deleting document [${docId}] from [${collectionName}]:`, e);
  }
}

/**
 * One-time backfill: stamps subagency: 'pod_main' onto every existing document across all studio-* collections
 * if subagency is missing or set to pod_unassigned.
 */
export async function backfillStudioCollectionsSubagency(): Promise<number> {
  const cols = [
    'studio-creators',
    'studio-contracts',
    'studio-staged-contracts',
    'studio-deals',
    'studio-brands',
    'studio-missions'
  ];
  let updatedCount = 0;
  for (const colName of cols) {
    try {
      const colRef = collection(db, colName);
      const snap = await getDocs(colRef);
      for (const docSnap of snap.docs) {
        const d = docSnap.data();
        if (!d.subagency || d.subagency === 'pod_unassigned') {
          const docRef = doc(db, colName, docSnap.id);
          await setDoc(docRef, { subagency: 'pod_main' }, { merge: true });
          updatedCount++;
        }
      }
    } catch (e) {
      console.warn(`[SubagencyBackfill] Error in ${colName}:`, e);
    }
  }
  console.log(`[SubagencyBackfill] Backfill complete. Updated ${updatedCount} documents.`);
  return updatedCount;
}

export async function migrateCreatorsToStudioCreators(creators: any[]): Promise<number> {
  let count = 0;
  for (const c of creators) {
    try {
      const docRef = doc(db, 'studio-creators', c.id);
      await setDoc(docRef, {
        ...c,
        subagency: c.subagency || 'pod_main',
        updatedAt: new Date().toISOString()
      }, { merge: true });
      count++;
    } catch (err) {
      console.error(`[MigrateCreators] Error writing creator [${c.id}]:`, err);
    }
  }
  console.log(`[MigrateCreators] Migrated ${count} creators to studio-creators collection.`);
  return count;
}

export async function purgeLegacySeedDataFromFirestore() {
  const seedIds = new Set([
    'c1', 'c2', 'c3', 'c4', 'c5',
    'CON-2026-101', 'CON-2026-901', 'CON-2026-902', 'con_1', 'con_2',
    'c_rachel_2026', 'c_liam_2026', 'c_marcus_2026', 'c_marcus_agent_mgr_2026',
    'c_rachel_agent_dual_2026', 'c_jordan_agent_mgr_2026', 'c_sarah_agent_2026',
    'c_devon_agent_2026', 'c_alex_coord_2026', 'c_maya_coord_2026', 'c_sophia_2026',
    'c_elena_2026', 'c_david_2026',
    'ag_marcus_cole', 'ag_jordan_lee', 'ag_rachel_sterling', 'ag_sarah_chen',
    'ag_devon_brooks', 'ag_alex_vance', 'ag_maya_lin',
    'rd_1', 'rd_2', 'rd_3',
    'gi_1', 'gi_2', 'gi_3',
    'd_sports_1', 'd_viral_1',
    'mission_101', 'mission_102',
    'pl_1', 'pl_2', 'pl_3', 'pl_4',
    'sub-1', 'sub-2',
    'INV-2026-089', 'INV-2026-042',
    'an_default_1', 'an_default_2', 'an_old_default'
  ]);
  const seedNames = [
    'zach king', 'zack king', 'zachking', 'zackking', 'zachary king', '@zachking', '@zackking',
    'alex jones', 'kayla laurent', 'sophia wells', 'serena williams creator', 'liam sterling',
    '@alexjones', '@kaylalooks', '@shopwithsoph', '@serena_creator', '@liam_viral',
    'rachel sterling', 'tyler styles', '@new_signing', '@represented_creator',
    'marcus cole', 'jordan lee', 'sarah chen', 'devon brooks', 'alex vance', 'maya lin',
    'liam vance', 'marcus chen', 'sophia taylor', 'elena rostova', 'david miller',
    'tasha adams', 'chloe bennett', 'david kim', 'alex rivera', 'jordan reed',
    'nike athletics', 'nike x bloom', 'redbull digital', 'jane doe', 'jane@nike.com',
    'sephora holiday spotlight', 'glossier cloud paint', 'lululemon studio reel',
    'bellaglows', 'mrealness', 'sarah jenkins', 'david beckham jr', 'david sterling',
    '@rachelsterling', '@sarah_fit', '@alexperry', '@davidtech', '@elena_art',
    '@maya_vlogs', '@sam_culinary', '@marcusgaming', '@sophiataylor', '@elenarostova', '@davidmiller'
  ];

  const cols = [
    'studio-creators',
    'studio-contracts',
    'studio-staged-contracts',
    'studio-deals',
    'studio-brands',
    'studio-missions',
    'studio-agents',
    'studio-creator-roadmaps',
    'studio-growth-items',
    'studio-content-reviews',
    'studio-casting-applications',
    'studio-w9-forms'
  ];

  let deletedCount = 0;
  for (const colName of cols) {
    try {
      const colRef = collection(db, colName);
      const snap = await getDocs(colRef);
      const deletePromises: Promise<any>[] = [];
      snap.forEach((docSnap) => {
        const d = docSnap.data();
        const id = docSnap.id;
        const textToTest = `${id} ${d.name || ''} ${d.handle || ''} ${d.creatorName || ''} ${d.creator || ''} ${d.party || ''} ${d.partner || ''} ${d.client || ''} ${d.brand || ''} ${d.email || ''} ${d.title || ''} ${d.author || ''}`.toLowerCase();
        if (seedIds.has(id) || seedNames.some(s => textToTest.includes(s.toLowerCase()))) {
          console.log(`[PurgeSeedData] Deleting legacy seed document [${colName}/${id}]`);
          deletedCount++;
          deletePromises.push(deleteDoc(doc(db, colName, id)).catch(() => {}));
        }
      });
      if (deletePromises.length > 0) {
        await Promise.allSettled(deletePromises);
      }
    } catch (e) {
      console.warn(`[PurgeSeedData] Error checking collection [${colName}]:`, e);
    }
  }

  // Also clean legacy localStorage keys with fake people
  if (typeof window !== 'undefined') {
    const keysToClean = [
      'wl_agents', 'wl_contracts', 'wl_threads', 'wl_agentNotes',
      'wl_payout_ledger', 'wl_growthItems', 'wl_rateHistory', 'wl_subagency_pods',
      'wl_boardReferrals', 'wl_retainers', 'wl_castingCalls', 'wl_exclusivityItems',
      'wl_retentionItems', 'wl_brandInquiries_op', 'wl_brands', 'wl_announcements',
      'wl_workspaces', 'wl_creator_roadmaps', 'wl_creators', 'wl_deals', 'wl_missions'
    ];
    for (const key of keysToClean) {
      const item = safeStorage.getItem(key);
      if (item && seedNames.some(s => item.toLowerCase().includes(s.toLowerCase()))) {
        safeStorage.removeItem(key);
      }
    }
  }
  return { deletedCount };
}

/**
 * Subscribes to tenant configuration in `tenants/{tenantId}/config/branding` and `tenants/{tenantId}/branding/default`.
 * Since `tenants/{tenantId}/branding/default` has public read rules, the sign-in page can render before authentication.
 */
export function subscribeTenantConfig(
  tenantId: string,
  onConfigData: (config: any) => void
): () => void {
  const tid = tenantId || 'bloom_studio_default';
  let latestConfig: any = {
    agencyName: "Bloom Studio",
    legalEntityName: "Bloom Studio LLC",
    primaryBrandColor: "#C9A46A",
    sidebarBgColor: "#0D1830",
    mainDashboardBg: "#050C18",
    cardBgColor: "#111E33",
    textMainColor: "#ffffff",
    textMutedColor: "#6b7c96",
    billingProfile: { status: "active", plan: "Core OS", fee: 199, billingPeriod: "monthly" },
    subscriptionStatus: "active"
  };

  const publicRef = doc(db, 'tenants', tid, 'branding', 'default');
  const configRef = doc(db, 'tenants', tid, 'config', 'branding');
  const tenantDocRef = doc(db, 'tenants', tid);

  const unsub1 = onSnapshot(publicRef, (snap) => {
    if (snap.exists()) {
      latestConfig = { ...latestConfig, ...snap.data() };
      onConfigData(latestConfig);
    }
  }, () => {});

  const unsub2 = onSnapshot(configRef, (snap) => {
    if (snap.exists()) {
      latestConfig = { ...latestConfig, ...snap.data() };
      onConfigData(latestConfig);
    }
  }, () => {});

  const unsub3 = onSnapshot(tenantDocRef, (snap) => {
    if (snap.exists()) {
      const d = snap.data();
      latestConfig = {
        ...latestConfig,
        agencyName: d.agencyName || latestConfig.agencyName,
        legalEntityName: d.legalEntityName || latestConfig.legalEntityName,
        primaryBrandColor: d.primaryBrandColor || latestConfig.primaryBrandColor,
        sidebarBgColor: d.sidebarBgColor || latestConfig.sidebarBgColor,
        mainDashboardBg: d.mainDashboardBg || latestConfig.mainDashboardBg,
        cardBgColor: d.cardBgColor || latestConfig.cardBgColor,
        textMainColor: d.textMainColor || latestConfig.textMainColor,
        textMutedColor: d.textMutedColor || latestConfig.textMutedColor,
        billingProfile: d.billingProfile || latestConfig.billingProfile,
        subscriptionStatus: d.subscriptionStatus || latestConfig.subscriptionStatus
      };
      onConfigData(latestConfig);
    }
  }, () => {});

  return () => {
    unsub1();
    unsub2();
    unsub3();
  };
}

/**
 * Saves tenant configuration to `tenants/{tenantId}/config/branding` and `tenants/{tenantId}/branding/default`.
 */
export async function saveTenantConfigInFirestore(tenantId: string, config: any) {
  const tid = tenantId || 'bloom_studio_default';
  const configRef = doc(db, 'tenants', tid, 'config', 'branding');
  const publicRef = doc(db, 'tenants', tid, 'branding', 'default');
  const tenantDocRef = doc(db, 'tenants', tid);

  try {
    const cleaned = cleanForFirestore(config);
    await Promise.all([
      setDoc(configRef, cleaned, { merge: true }),
      setDoc(publicRef, cleaned, { merge: true }),
      setDoc(tenantDocRef, cleaned, { merge: true })
    ]);
  } catch (err: any) {
    console.warn(`[saveTenantConfigInFirestore] Could not save config for tenant [${tid}]:`, err?.message || err);
  }
}

/**
 * Saves delegation settings specifically to `tenants/{tenantId}/config/delegation`.
 */
export async function saveDirectorDelegationInFirestore(tenantId: string, settings: any) {
  const tid = tenantId || 'bloom_studio_default';
  const delegationRef = doc(db, 'tenants', tid, 'config', 'delegation');
  const brandingRef = doc(db, 'tenants', tid, 'config', 'branding');
  
  try {
    const cleaned = cleanForFirestore(settings);
    // Sync to both delegation specific and branding (where rules currently look)
    await Promise.all([
      setDoc(delegationRef, cleaned, { merge: true }),
      setDoc(brandingRef, cleaned, { merge: true })
    ]);
  } catch (err: any) {
    console.warn(`[saveDirectorDelegationInFirestore] Error for tenant [${tid}]:`, err?.message || err);
  }
}

/**
 * Creates a new tenant document in `tenants/{tenantId}` and initializes its branding.
 */
export async function createTenantInFirestore(tenantData: any) {
  const tid = tenantData.id || tenantData.subdomain;
  const tenantDocRef = doc(db, 'tenants', tid);
  const now = new Date().toISOString();
  const baseDoc = {
    ...tenantData,
    id: tid,
    subdomain: tid,
    createdAt: tenantData.createdAt || now,
    creatorCount: tenantData.creatorCount || 0,
    userCount: tenantData.userCount || 1,
  };
  await setDoc(tenantDocRef, baseDoc, { merge: true });
  await saveTenantConfigInFirestore(tid, baseDoc);
  return baseDoc;
}

/**
 * Updates a tenant document in `tenants/{tenantId}`.
 */
export async function updateTenantInFirestore(tenantId: string, updateData: any) {
  const tid = tenantId || 'bloom_studio_default';
  const tenantDocRef = doc(db, 'tenants', tid);
  await setDoc(tenantDocRef, updateData, { merge: true });
  await saveTenantConfigInFirestore(tid, updateData);
}

/**
 * Deletes a tenant document and its branding config from Firestore.
 */
export async function deleteTenantInFirestore(tenantId: string) {
  const tid = tenantId;
  await deleteDoc(doc(db, 'tenants', tid, 'config', 'branding')).catch(() => {});
  await deleteDoc(doc(db, 'tenants', tid, 'branding', 'default')).catch(() => {});
  await deleteDoc(doc(db, 'tenants', tid)).catch(() => {});
}

/**
 * Subscribes to all live tenant workspaces in Firestore `tenants` collection.
 */
export function subscribeAllTenants(onTenants: (tenants: any[]) => void): () => void {
  const colRef = collection(db, 'tenants');
  return onSnapshot(colRef, (snap) => {
    const list: any[] = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() });
    });
    onTenants(list);
  }, (err) => {
    console.warn('[subscribeAllTenants] Error reading tenants:', err);
  });
}

export {
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  or,
  orderBy,
  writeBatch
} from 'firebase/firestore';

/**
 * Exchanges direct workspace user credentials for a cryptographically verified server session token.
 */
export async function getDirectSessionToken(forceRefresh = false): Promise<string | null> {
  try {
    const existing = safeStorage.getItem("wl_session_token");
    if (existing && !forceRefresh) {
      const cleanExisting = typeof existing === "string" ? existing.trim() : "";
      if (cleanExisting && /^bloom_sess_[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+$/.test(cleanExisting)) {
        return cleanExisting;
      }
      // If the stored token is invalid, corrupted, or not in expected format, purge it immediately
      safeStorage.removeItem("wl_session_token");
    }
    const userStr = safeStorage.getItem("wl_currentUser");
    if (!userStr) return null;
    let parsedUser: any = null;
    try {
      parsedUser = JSON.parse(userStr);
    } catch {
      return null;
    }
    if (!parsedUser || !parsedUser.email) return null;

    let idToken = "";
    if (auth.currentUser) {
      try {
        idToken = await auth.currentUser.getIdToken(forceRefresh);
      } catch (err) {
        // non-blocking token fetch
      }
    }

    // Only make the session exchange if we have an authentic Firebase ID token
    if (!idToken) {
      return null;
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken.trim()}`,
    };

    const res = await fetch("/api/auth/session", {
      method: "POST",
      headers,
      body: JSON.stringify({
        uid: parsedUser.id || parsedUser.uid || auth.currentUser?.uid || `user_${Date.now()}`,
        email: parsedUser.email || auth.currentUser?.email,
        name: parsedUser.name || auth.currentUser?.displayName,
        role: parsedUser.role || "creator",
        tenantId: parsedUser.tenantId || "bloom_studio_default",
        subagency: parsedUser.subagency || "pod_main",
        isPlatformOwner: !!parsedUser.isPlatformOwner,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.token && typeof data.token === "string" && /^bloom_sess_[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+$/.test(data.token.trim())) {
        const cleanToken = data.token.trim();
        safeStorage.setItem("wl_session_token", cleanToken);
        return cleanToken;
      }
    }
  } catch (err) {
    console.warn("[getDirectSessionToken] Session exchange error:", err);
  }
  return null;
}

/**
 * Retrieves the current user's Firebase ID token or verified session token for authenticating backend API requests.
 */
export async function getAuthToken(forceRefresh = false): Promise<string | null> {
  const user = auth.currentUser;
  if (user) {
    try {
      const idToken = await user.getIdToken(forceRefresh);
      if (idToken) return idToken;
    } catch (err) {
      console.warn("Failed to retrieve Firebase ID token from current user:", err);
    }
  }

  // Check for verified direct workspace session token
  const directToken = await getDirectSessionToken(forceRefresh);
  if (directToken) {
    return directToken;
  }

  // If currentUser is initializing, wait briefly for onAuthStateChanged
  return new Promise<string | null>((resolve) => {
    let done = false;
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!done) {
        done = true;
        unsub();
        if (u) {
          try {
            const token = await u.getIdToken();
            resolve(token);
          } catch {
            resolve(null);
          }
        } else {
          const retryDirect = await getDirectSessionToken(forceRefresh);
          resolve(retryDirect);
        }
      }
    });

    setTimeout(async () => {
      if (!done) {
        done = true;
        unsub();
        const retryDirect = await getDirectSessionToken(forceRefresh);
        resolve(retryDirect);
      }
    }, 400);
  });
}

/**
 * Returns Authorization headers with Bearer token or session token if signed in.
 * Guaranteed to only include strictly valid HTTP ByteString characters so fetch never throws DOMException.
 */
export async function getAuthHeaders(forceRefresh = false): Promise<Record<string, string>> {
  try {
    const rawToken = await getAuthToken(forceRefresh);
    if (rawToken && typeof rawToken === "string") {
      const cleanToken = rawToken.trim().replace(/[\r\n\t]/g, "");
      // Validate that cleanToken contains only printable ASCII characters (0x21 to 0x7E)
      if (cleanToken && cleanToken !== "undefined" && cleanToken !== "null" && cleanToken !== "[object Object]" && /^[\x21-\x7E]+$/.test(cleanToken)) {
        return {
          Authorization: `Bearer ${cleanToken}`,
          "x-session-token": cleanToken,
        };
      }
    }
  } catch (err) {
    console.warn("[getAuthHeaders] Error retrieving auth headers:", err);
  }
  return {};
}

/**
 * Submits a pod registration invite application to Firestore `studio-invite-applications`
 * and syncs to `/api/submit-invite-application`.
 */
export async function submitPodInviteApplication(appData: {
  name: string;
  email: string;
  handle?: string;
  requestedRole?: string;
  pod?: string;
  subagency?: string;
  tenantId?: string;
  invitedByCode?: string;
  bio?: string;
  source?: string;
  uid?: string;
  w9Status?: string;
  w9FileName?: string;
}): Promise<{ success: boolean; id: string; error?: string }> {
  const cleanEmail = appData.email.trim().toLowerCase();
  const cleanName = appData.name.trim();
  const cleanHandle = appData.handle
    ? (appData.handle.startsWith('@') ? appData.handle : `@${appData.handle}`)
    : `@${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
  
  const appId = appData.uid ? `app_${appData.uid}` : `app_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const timestamp = new Date().toISOString();

  const fullPayload = {
    id: appId,
    uid: appData.uid || null,
    name: cleanName,
    email: cleanEmail,
    handle: cleanHandle,
    role: 'none',
    requestedRole: appData.requestedRole || 'creator',
    pod: appData.pod || 'Main Agency',
    subagency: appData.subagency || 'pod_main',
    tenantId: appData.tenantId || 'bloom_studio_default',
    invitedByCode: (appData.invitedByCode || '').trim().toUpperCase(),
    status: 'Pending Approval',
    bio: (appData.bio || '').trim(),
    source: appData.source || 'direct_form',
    w9Status: appData.w9Status || 'Pending',
    w9FileName: appData.w9FileName || '',
    joined: timestamp.split('T')[0],
    createdAt: timestamp
  };

  // 1. Direct Firestore write
  try {
    const appDocRef = doc(db, 'studio-invite-applications', appId);
    await setDoc(appDocRef, fullPayload, { merge: true });

    // Also write pending profile to studio-users so it exists globally
    const userDocRef = doc(db, 'studio-users', appData.uid || appId);
    await setDoc(userDocRef, {
      id: appData.uid || appId,
      uid: appData.uid || appId,
      name: cleanName,
      email: cleanEmail,
      handle: cleanHandle,
      role: 'none',
      requestedRole: fullPayload.requestedRole,
      pod: fullPayload.pod,
      subagency: fullPayload.subagency,
      tenantId: fullPayload.tenantId,
      invitedByCode: fullPayload.invitedByCode,
      status: 'Pending Approval',
      accountUnlocked: false,
      bio: fullPayload.bio,
      joined: fullPayload.joined,
      createdAt: timestamp,
      updatedAt: timestamp
    }, { merge: true });
  } catch (err: any) {
    console.warn('[submitPodInviteApplication] Direct Firestore write issue, proceeding with server endpoint:', err?.message || err);
  }

  // 2. Call server endpoint to ensure server-side Firebase Admin write + notifications
  try {
    const authHeaders = await getAuthHeaders();
    await fetch('/api/submit-invite-application', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders
      },
      body: JSON.stringify(fullPayload)
    });
  } catch (err) {
    console.warn('[submitPodInviteApplication] Server endpoint call error:', err);
  }

  return { success: true, id: appId };
}

/**
 * Subscribes to real-time invite applications from `studio-invite-applications`.
 */
export function subscribeInviteApplications(onData: (apps: any[]) => void): () => void {
  const colRef = collection(db, 'studio-invite-applications');
  return onSnapshot(colRef, (snapshot) => {
    const apps: any[] = [];
    snapshot.forEach((docSnap) => {
      apps.push({ ...docSnap.data(), id: docSnap.id });
    });
    onData(apps);
  }, (err) => {
    console.warn('[subscribeInviteApplications] Error subscribing:', err);
  });
}

/**
 * Approves a user application and unlocks access in Firestore across studio-invite-applications,
 * studio-users, tenants, and studio-creators if applicable.
 */
export async function approveInviteApplicationInFirestore(tenantId: string, applicant: any, targetRole: string) {
  const targetTenant = tenantId || 'bloom_studio_default';
  const targetId = applicant.uid || applicant.id;
  const now = new Date().toISOString();

  // 1. Update application doc if exists
  if (applicant.id) {
    try {
      const appRef = doc(db, 'studio-invite-applications', applicant.id);
      await setDoc(appRef, {
        status: 'Active',
        role: targetRole,
        reviewedAt: now,
        reviewedBy: 'Staff Member'
      }, { merge: true });
    } catch (e) {
      console.warn('[approveInviteApplicationInFirestore] Failed to update application doc:', e);
    }
  }

  // 2. Update studio-users and tenant user
  const userProfile = {
    id: targetId,
    uid: targetId,
    name: applicant.name || applicant.email?.split('@')[0] || 'User',
    email: applicant.email || '',
    handle: applicant.handle || `@${(applicant.name || 'user').toLowerCase().replace(/[^a-z0-9]/g, '')}`,
    role: targetRole,
    requestedRole: targetRole,
    pod: applicant.pod || 'Main Agency',
    subagency: applicant.subagency || applicant.pod || 'pod_main',
    tenantId: targetTenant,
    status: 'Active',
    accountUnlocked: true,
    updatedAt: now
  };

  try {
    await Promise.allSettled([
      setDoc(doc(db, 'studio-users', targetId), userProfile, { merge: true }),
      setDoc(doc(db, 'tenants', targetTenant, 'users', targetId), userProfile, { merge: true }),
      setDoc(doc(db, 'users', targetId), userProfile, { merge: true })
    ]);
  } catch (e) {
    console.warn('[approveInviteApplicationInFirestore] Failed to update user profile in Firestore:', e);
  }

  // 3. If targetRole is creator, ensure record exists in studio-creators so talent roster renders them
  if (targetRole === 'creator') {
    try {
      const creatorRef = doc(db, 'studio-creators', targetId);
      await setDoc(creatorRef, {
        id: targetId,
        name: applicant.name || 'Creator',
        handle: applicant.handle || `@${(applicant.name || 'creator').toLowerCase().replace(/[^a-z0-9]/g, '')}`,
        email: applicant.email || '',
        subagency: applicant.subagency || applicant.pod || 'pod_main',
        niche: applicant.bio || applicant.niche || 'Lifestyle & Creator',
        status: 'Active',
        joinedAt: now
      }, { merge: true });
    } catch (e) {
      console.warn('[approveInviteApplicationInFirestore] Failed to sync creator:', e);
    }
  }
}

/**
 * Permanently deletes an invite application and associated user profile from Firestore.
 */
export async function deleteInviteApplicationInFirestore(applicantId: string) {
  try {
    await Promise.allSettled([
      deleteDoc(doc(db, 'studio-invite-applications', applicantId)),
      deleteDoc(doc(db, 'studio-users', applicantId))
    ]);
  } catch (err) {
    console.warn('[deleteInviteApplicationInFirestore] Error deleting docs:', err);
  }
}

/**
 * Subscribes to real-time shared invite codes from `studio-invite-codes`.
 */
export function subscribeInviteCodes(onData: (codes: any[]) => void): () => void {
  const colRef = collection(db, 'studio-invite-codes');
  return onSnapshot(colRef, (snapshot) => {
    const codes: any[] = [];
    snapshot.forEach((docSnap) => {
      codes.push({ ...docSnap.data(), id: docSnap.id });
    });
    onData(codes);
  }, (err) => {
    console.warn('[subscribeInviteCodes] Error subscribing to invite codes:', err);
  });
}

/**
 * Saves or updates an invite code in `studio-invite-codes`.
 */
export async function saveInviteCodeInFirestore(codeObj: any) {
  if (!codeObj?.code) return;
  const cleanCode = codeObj.code.trim().toUpperCase();
  try {
    const codeRef = doc(db, 'studio-invite-codes', cleanCode);
    await setDoc(codeRef, {
      ...codeObj,
      code: cleanCode,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err) {
    console.warn('[saveInviteCodeInFirestore] Error saving code:', err);
  }
}
