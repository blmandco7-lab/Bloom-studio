// Automated Compliance System Engine Script

export interface AuditableContract {
  id: string;
  creatorName: string;
  expirationDate: string;
  party?: string;
  partyEmail?: string;
  type?: string;
}

// Visual Mock Dataset representing your system's private Contract Vault values
export const activeContractVault: AuditableContract[] = [
  { id: "CON_99812", creatorName: "Serena Brooks", expirationDate: "2026-11-15" },
  { id: "CON_44102", creatorName: "Alex Jones", expirationDate: "2026-09-02" }, // Expiring soon (< 45 days)
  { id: "CON_11204", creatorName: "Marcus Vance", expirationDate: "2027-04-20" }
];

export function triggerDirectorAlert(
  creatorName: string, 
  daysLeft: number, 
  contractId: string,
  onNotify?: (title: string, message: string, type: 'warning' | 'error' | 'info') => void
): string {
  // 1. Logs details natively inside your live Bot Activity Console Feed
  console.warn(`[ALERT] Contract for ${creatorName} expires in ${daysLeft} days! (ID: ${contractId})`);
  
  // 2. Logic to trigger the physical notification inside your Dashboard Inbox UI
  const systemNotificationText = `Urgent Action Required: The Exclusive Representation Agreement for ${creatorName} is expiring in ${daysLeft} days. Click to process renewal options.`;
  
  if (onNotify) {
    onNotify(
      `Contract Expiration Warning: ${creatorName}`,
      systemNotificationText,
      'warning'
    );
  }
  
  // In production, this pushes the alert string to internal platform notification box
  return systemNotificationText;
}

export function auditContractExpirations(
  contractsList: AuditableContract[] = [],
  onAlertTriggered?: (alertText: string, alertData: { contractId: string; creatorName: string; daysLeft: number }) => void
): string[] {
  const DAYS_THRESHOLD = 45; // Triggers alert if contract expires within 45 days
  const millisecondsInDay = 24 * 60 * 60 * 1000;
  const today = new Date();
  const alertsGenerated: string[] = [];

  console.log("Initializing Automated Contract Compliance Audit...");

  contractsList.forEach(contract => {
    // Parse YYYY-MM-DD as local time by splitting and using the Date constructor with components
    const [year, month, day] = contract.expirationDate.split('-').map(Number);
    const expiryDate = new Date(year, month - 1, day);
    
    // Calculate the physical mathematical difference in days
    const timeDifference = expiryDate.getTime() - today.getTime();
    const daysRemaining = Math.ceil(timeDifference / millisecondsInDay);

    // Check if the file matches our critical alert boundary threshold
    if (daysRemaining <= DAYS_THRESHOLD && daysRemaining > 0) {
      const alertMsg = triggerDirectorAlert(contract.creatorName, daysRemaining, contract.id);
      alertsGenerated.push(alertMsg);
      if (onAlertTriggered) {
        onAlertTriggered(alertMsg, {
          contractId: contract.id,
          creatorName: contract.creatorName,
          daysLeft: daysRemaining
        });
      }
    }
  });

  return alertsGenerated;
}

// End of module
