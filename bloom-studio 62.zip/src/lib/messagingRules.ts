/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Role, Creator, Deal } from '../types';
import { safeStorage } from '../utils/safeStorage';

export interface DirectoryPerson {
  name: string;
  role: string;
  handle?: string;
  category: string;
  isWorkingWith?: boolean;
  relationshipNote?: string;
  avatar?: string;
}

export interface PermissionCheckResult {
  allowed: boolean;
  reason?: string;
  targetRole?: string;
}

export function getActiveDirectorName(): string {
  try {
    if (typeof window !== 'undefined') {
      const tid = new URLSearchParams(window.location.search).get('subdomain') || 'bloom_studio_default';
      const saved = safeStorage.getItem(`wl_tenant_${tid}_directorName`);
      if (saved && saved.trim()) return saved;
    }
  } catch (e) {}
  return 'Director';
}

// Master list of agency staff members and their roles (Clean - dynamically populated from registered staff/agents)
export const STUDIO_STAFF: DirectoryPerson[] = [
  { name: 'Director Desk', role: 'Director', category: 'Leadership & Directors' }
];

export const STUDIO_BRANDS: DirectoryPerson[] = [];

export const STUDIO_BROADCASTS: DirectoryPerson[] = [
  { name: 'Everyone (Broadcast to All)', role: 'Studio Broadcast', category: 'Studio Broadcasts' },
  { name: 'All Creators (Talent Broadcast)', role: 'All Creators', category: 'Studio Broadcasts' },
  { name: 'All Agents & Managers (Staff Broadcast)', role: 'All Staff', category: 'Studio Broadcasts' },
  { name: 'All Brands & Sponsors', role: 'All Brands', category: 'Studio Broadcasts' },
  { name: 'All Agency & Sub-Agency Pods', role: 'All Partners', category: 'Studio Broadcasts' },
];

/**
 * Normalizes a role string to standard lowercase Role type
 */
export function normalizeRole(roleStr?: string): Role {
  if (!roleStr || roleStr.trim() === '') return 'creator';
  const r = roleStr.toLowerCase().trim();
  if (r.includes('director') || r === 'admin' || r === 'lead') return 'director';
  if (r.includes('mgr') || r.includes('manager') || r === 'agentmgr') return 'agentmgr';
  if (r.includes('coordinator')) return 'coordinator';
  if (r.includes('agent') || r.includes('rep')) return 'agent';
  if (r.includes('brand') || r.includes('sponsor')) return 'brand';
  if (r.includes('creator') || r.includes('talent')) return 'creator';
  if (r.includes('subagency') || r.includes('sub-agency')) return 'subagency';
  if (r.includes('agency') || r.includes('partner')) return 'agency';
  return 'director';
}

/**
 * Helper to identify what role a recipient has by name, role string, or handle
 */
export function identifyPersonRole(person: { name: string; role?: string; handle?: string }): string {
  const name = (person.name || '').toLowerCase();
  const role = (person.role || '').toLowerCase();
  const handle = (person.handle || '').toLowerCase();

  if (role.includes('broadcast') || name.includes('broadcast') || name.includes('everyone')) return 'broadcast';
  if (role.includes('director') || name.includes('sarah jenkins') || handle.includes('director')) return 'director';
  if (role.includes('agent manager') || name.includes('marcus cole') || handle.includes('manager')) return 'agentmgr';
  if (role.includes('coordinator') || name.includes('david kim') || name.includes('alex rivera') || handle.includes('coordinator')) return 'coordinator';
  if (role.includes('agent') || name.includes('tasha') || name.includes('chloe') || name.includes('elena')) return 'agent';
  if (role.includes('brand') || name.includes('driproom') || name.includes('nike') || name.includes('sephora') || name.includes('bloom partners') || name.includes('spotify') || name.includes('gymshark') || name.includes('apple')) return 'brand';
  if (role.includes('creator') || handle.startsWith('@') || name.startsWith('@')) return 'creator';
  if (role.includes('subagency') || role.includes('pod') || name.includes('pod') || name.includes('sub-agency')) return 'subagency';
  if (role.includes('agency')) return 'agency';
  
  return role || 'staff';
}

/**
 * Check if an Agent is currently working with a given Creator
 */
export function isAgentWorkingWithCreator(agentName: string, creator: Creator, deals: Deal[] = []): boolean {
  const normAgent = (agentName || '').toLowerCase().trim();
  const cAgent = (creator.assignedAgent || '').toLowerCase().trim();

  // Direct match on assigned agent
  if (cAgent && (cAgent === normAgent || normAgent.includes(cAgent) || cAgent.includes(normAgent))) {
    return true;
  }

  // Check if agent is on any deals for this creator
  const hasDeal = deals.some(d => {
    const dCreator = (d.creator || d.creatorHandle || '').toLowerCase().trim();
    const dAgent = (d.agent || '').toLowerCase().trim();
    const isThisCreator = dCreator === creator.name.toLowerCase() || dCreator === creator.handle.toLowerCase();
    return isThisCreator && (dAgent === normAgent || dAgent.includes(normAgent) || normAgent.includes(dAgent));
  });

  if (hasDeal) return true;

  return false;
}

/**
 * Check if an Agent Manager is working with a given Creator
 */
export function isManagerWorkingWithCreator(managerName: string, creator: Creator, deals: Deal[] = []): boolean {
  // Agent Manager oversees the entire agency roster and all agent-creator assignments
  if (!creator.status || creator.status !== 'Offboarded') {
    return true;
  }
  return false;
}

/**
 * Check if a Coordinator is working with a given Creator
 */
export function isCoordinatorWorkingWithCreator(
  coordinatorName: string, 
  creator: Creator, 
  deals: Deal[] = [], 
  campaigns: any[] = []
): boolean {
  const normCoord = (coordinatorName || '').toLowerCase().trim();

  // Check campaigns
  const hasCampaign = campaigns.some(c => {
    const cTalent = (c.talent || c.creator || c.creatorName || '').toLowerCase().trim();
    const isThisCreator = cTalent === creator.name.toLowerCase() || cTalent === creator.handle.toLowerCase();
    const cCoord = (c.coordinator || c.assignedCoordinator || '').toLowerCase().trim();
    return isThisCreator && (!cCoord || cCoord === normCoord || normCoord.includes('coord'));
  });

  if (hasCampaign) return true;

  // Check active deals / deliverables
  const hasActiveDeal = deals.some(d => {
    const dCreator = (d.creator || d.creatorHandle || '').toLowerCase().trim();
    return dCreator === creator.name.toLowerCase() || dCreator === creator.handle.toLowerCase();
  });

  if (hasActiveDeal) return true;

  return false;
}

/**
 * Core Permission Evaluator: Determines whether a sender role is allowed to message a target recipient
 * 
 * Rules:
 * 1. Director can message everyone.
 * 2. Agent Manager can message Director, Agents, Coordinators, and creators they are working with.
 * 3. Agents can message Director, Agent Manager, Coordinators, and creators they are working with.
 * 4. Creators can message Director, Agent Manager, and Agent, and coordinators they are working with.
 * 5. Coordinators can message Director, Agent Manager, Agents, and creators they are working with.
 * 6. Brand can ONLY message Director.
 */
export function isAllowedToMessage(
  senderRole: Role | string,
  senderUser: any,
  recipient: { name: string; role?: string; handle?: string },
  creators: Creator[] = [],
  deals: Deal[] = [],
  campaigns: any[] = []
): PermissionCheckResult {
  const normSenderRole = normalizeRole(senderRole);
  const targetRoleType = identifyPersonRole(recipient);
  const senderName = senderUser?.name || 'User';

  // RULE 1: DIRECTOR CAN MESSAGE EVERYONE
  if (normSenderRole === 'director') {
    return { allowed: true, targetRole: targetRoleType };
  }

  // RULE 6: BRAND CAN ONLY MESSAGE DIRECTOR
  if (normSenderRole === 'brand') {
    if (targetRoleType === 'director') {
      return { allowed: true, targetRole: 'director' };
    }
    return {
      allowed: false,
      reason: 'Safety policy: Brands can only message the Director directly. All communications with talent and staff must be managed through the Director.',
      targetRole: targetRoleType
    };
  }

  // RULE 2: AGENT MANAGER CAN MESSAGE: Director, Agents, Coordinators, and Creators they are working with
  if (normSenderRole === 'agentmgr') {
    if (targetRoleType === 'director') return { allowed: true, targetRole: 'director' };
    if (targetRoleType === 'agent') return { allowed: true, targetRole: 'agent' };
    if (targetRoleType === 'coordinator') return { allowed: true, targetRole: 'coordinator' };
    if (targetRoleType === 'agentmgr') return { allowed: true, targetRole: 'agentmgr' };

    if (targetRoleType === 'creator') {
      // Find creator in roster
      const targetCreator = creators.find(c => 
        c.name.toLowerCase() === recipient.name.toLowerCase() || 
        c.handle.toLowerCase() === (recipient.handle || recipient.name).toLowerCase()
      );
      
      if (!targetCreator || isManagerWorkingWithCreator(senderName, targetCreator, deals)) {
        return { allowed: true, targetRole: 'creator' };
      }
      return {
        allowed: false,
        reason: 'You can only message active roster creators managed by your talent department.',
        targetRole: 'creator'
      };
    }

    if (targetRoleType === 'brand') {
      return {
        allowed: false,
        reason: 'Brand partner messaging is restricted to the Director.',
        targetRole: 'brand'
      };
    }

    if (targetRoleType === 'broadcast') {
      if (recipient.name.includes('Staff') || recipient.name.includes('Creator')) {
        return { allowed: true, targetRole: 'broadcast' };
      }
      return {
        allowed: false,
        reason: 'Studio-wide global broadcasts are reserved for the Director.',
        targetRole: 'broadcast'
      };
    }

    return { allowed: true, targetRole: targetRoleType };
  }

  // RULE 3: AGENTS CAN MESSAGE: Director, Agent Manager, Coordinators, and Creators they are working with
  if (normSenderRole === 'agent') {
    if (targetRoleType === 'director') return { allowed: true, targetRole: 'director' };
    if (targetRoleType === 'agentmgr') return { allowed: true, targetRole: 'agentmgr' };
    if (targetRoleType === 'coordinator') return { allowed: true, targetRole: 'coordinator' };

    if (targetRoleType === 'agent') {
      // Agent to agent internal sync
      return { allowed: true, targetRole: 'agent' };
    }

    if (targetRoleType === 'creator') {
      const targetCreator = creators.find(c => 
        c.name.toLowerCase() === recipient.name.toLowerCase() || 
        c.handle.toLowerCase() === (recipient.handle || recipient.name).toLowerCase()
      );

      if (!targetCreator || isAgentWorkingWithCreator(senderName, targetCreator, deals)) {
        return { allowed: true, targetRole: 'creator' };
      }
      return {
        allowed: false,
        reason: `You can only message creators you are assigned to represent (${targetCreator.name} is currently assigned to ${targetCreator.assignedAgent || 'another agent'}).`,
        targetRole: 'creator'
      };
    }

    if (targetRoleType === 'brand') {
      return {
        allowed: false,
        reason: 'Brand communication is managed exclusively through the Director.',
        targetRole: 'brand'
      };
    }

    if (targetRoleType === 'broadcast') {
      return {
        allowed: false,
        reason: 'Broadcast channels are restricted to Director and Management.',
        targetRole: 'broadcast'
      };
    }

    return { allowed: false, reason: 'Unauthorized messaging recipient.', targetRole: targetRoleType };
  }

  // RULE 4: CREATORS CAN MESSAGE: Director, Agent Manager, Assigned Agent, and Coordinators they are working with
  if (normSenderRole === 'creator') {
    if (targetRoleType === 'director') return { allowed: true, targetRole: 'director' };
    if (targetRoleType === 'agentmgr') return { allowed: true, targetRole: 'agentmgr' };
    if (targetRoleType === 'agent') return { allowed: true, targetRole: 'agent' };
    if (targetRoleType === 'coordinator') return { allowed: true, targetRole: 'coordinator' };

    if (targetRoleType === 'creator') {
      return {
        allowed: false,
        reason: 'Creator-to-Creator direct messaging is restricted to protect confidential deal rates and exclusive terms.',
        targetRole: 'creator'
      };
    }

    if (targetRoleType === 'brand') {
      return {
        allowed: false,
        reason: '🚨 Strict Compliance Rule: Direct Creator-to-Brand messaging is blocked. All brand negotiations and inquiries must go through the Director and your assigned talent rep.',
        targetRole: 'brand'
      };
    }

    if (targetRoleType === 'broadcast') {
      return {
        allowed: false,
        reason: 'Broadcast channels are read-only for talent.',
        targetRole: 'broadcast'
      };
    }

    return { allowed: false, reason: 'Unauthorized recipient.', targetRole: targetRoleType };
  }

  // RULE 5: COORDINATORS CAN MESSAGE: Director, Agent Manager, Agents, and Creators they are working with
  if (normSenderRole === 'coordinator') {
    if (targetRoleType === 'director') return { allowed: true, targetRole: 'director' };
    if (targetRoleType === 'agentmgr') return { allowed: true, targetRole: 'agentmgr' };
    if (targetRoleType === 'agent') return { allowed: true, targetRole: 'agent' };
    if (targetRoleType === 'coordinator') return { allowed: true, targetRole: 'coordinator' };

    if (targetRoleType === 'creator') {
      const targetCreator = creators.find(c => 
        c.name.toLowerCase() === recipient.name.toLowerCase() || 
        c.handle.toLowerCase() === (recipient.handle || recipient.name).toLowerCase()
      );

      if (!targetCreator || isCoordinatorWorkingWithCreator(senderName, targetCreator, deals, campaigns)) {
        return { allowed: true, targetRole: 'creator' };
      }
      return {
        allowed: false,
        reason: 'You can only message creators with active campaigns or deliverables you are coordinating.',
        targetRole: 'creator'
      };
    }

    if (targetRoleType === 'brand') {
      return {
        allowed: false,
        reason: 'Campaign coordinators must route brand messages through the Director.',
        targetRole: 'brand'
      };
    }

    return { allowed: false, reason: 'Unauthorized recipient.', targetRole: targetRoleType };
  }

  // Default fallback for Agency / Subagency Pods
  if (normSenderRole === 'subagency' || normSenderRole === 'agency') {
    if (targetRoleType === 'director' || targetRoleType === 'agentmgr' || targetRoleType === 'agent') {
      return { allowed: true, targetRole: targetRoleType };
    }
    if (targetRoleType === 'creator') {
      return { allowed: true, targetRole: 'creator' };
    }
    return { allowed: false, reason: 'Communication must route through Director or Agent Management.', targetRole: targetRoleType };
  }

  return { allowed: true, targetRole: targetRoleType };
}

/**
 * Returns the exact list of authorized recipients for the active role
 */
export function getRecipientsForRole(
  senderRole: Role | string,
  senderUser: any,
  creators: Creator[] = [],
  deals: Deal[] = [],
  campaigns: any[] = []
): DirectoryPerson[] {
  const normRole = normalizeRole(senderRole);
  const senderName = senderUser?.name || 'User';
  const list: DirectoryPerson[] = [];

  // 1. DIRECTOR: CAN MESSAGE EVERYONE
  if (normRole === 'director') {
    STUDIO_BROADCASTS.forEach(b => list.push(b));
    STUDIO_STAFF.forEach(s => list.push(s));
    STUDIO_BRANDS.forEach(b => list.push(b));

    creators.forEach(c => {
      list.push({
        name: c.name,
        role: 'Creator',
        handle: c.handle,
        category: 'Creators & Roster Talent',
        relationshipNote: `Rep: ${c.assignedAgent || 'Agency Lead'} • ${c.followers || '0'} Followers`
      });
    });
    return list;
  }

  // 2. BRAND: CAN ONLY MESSAGE DIRECTOR
  if (normRole === 'brand') {
    list.push({
      name: getActiveDirectorName(),
      role: 'Director',
      category: 'Director & Executive Hotline',
      relationshipNote: 'Agency Director (Primary Point of Contact)'
    });
    return list;
  }

  // 3. AGENT MANAGER: CAN MESSAGE Director, Agents, Coordinators, and Creators they are working with
  if (normRole === 'agentmgr') {
    list.push({ name: getActiveDirectorName(), role: 'Director', category: 'Agency Leadership', relationshipNote: 'Agency Director' });

    // Agents
    const agents = STUDIO_STAFF.filter(s => s.role === 'Agent');
    agents.forEach(a => {
      list.push({ ...a, category: 'Talent Agents', relationshipNote: 'Roster Agent' });
    });

    // Coordinators
    const coordinators = STUDIO_STAFF.filter(s => s.role === 'Coordinator');
    coordinators.forEach(c => {
      list.push({ ...c, category: 'Campaign Coordinators', relationshipNote: 'Operations & Execution' });
    });

    // Creators working with the talent department
    creators.forEach(c => {
      if (isManagerWorkingWithCreator(senderName, c, deals)) {
        list.push({
          name: c.name,
          role: 'Creator',
          handle: c.handle,
          category: 'Managed Roster Talent (Working With)',
          isWorkingWith: true,
          relationshipNote: `Assigned Rep: ${c.assignedAgent || 'Agency Lead'} • ${c.agreement || 'Exclusive'}`
        });
      }
    });

    return list;
  }

  // 4. AGENT: CAN MESSAGE Director, Agent Manager, Coordinators, and Creators they are working with
  if (normRole === 'agent') {
    list.push({ name: getActiveDirectorName(), role: 'Director', category: 'Agency Leadership', relationshipNote: 'Agency Director' });

    // Coordinators
    const coordinators = STUDIO_STAFF.filter(s => s.role === 'Coordinator');
    coordinators.forEach(c => {
      list.push({ ...c, category: 'Campaign Coordinators', relationshipNote: 'Deliverable Coordination' });
    });

    // Creators assigned to / working with this agent
    const workingCreators = creators.filter(c => isAgentWorkingWithCreator(senderName, c, deals));
    
    const creatorListToShow = workingCreators.length > 0 ? workingCreators : creators;
    creatorListToShow.forEach(c => {
      list.push({
        name: c.name,
        role: 'Creator',
        handle: c.handle,
        category: 'My Assigned Creators (Working With)',
        isWorkingWith: true,
        relationshipNote: `Assigned Talent • ${c.followers || '0'} Followers`
      });
    });

    return list;
  }

  // 5. CREATOR: CAN MESSAGE Director, Assigned Agent, and Coordinators
  if (normRole === 'creator') {
    list.push({ name: getActiveDirectorName(), role: 'Director', category: 'Agency Leadership', relationshipNote: 'Agency Director' });

    // Assigned Agent(s)
    const myHandle = senderUser?.handle || '';
    const myProfile = creators.find(c => (myHandle && c.handle.toLowerCase() === myHandle.toLowerCase()) || (senderName && c.name.toLowerCase() === senderName.toLowerCase()));
    const assignedAgentName = myProfile?.assignedAgent;

    if (assignedAgentName) {
      list.push({
        name: assignedAgentName,
        role: 'Agent',
        category: 'My Assigned Talent Agent',
        relationshipNote: 'Primary Talent Representative'
      });
    }

    // Coordinators
    const coordinators = STUDIO_STAFF.filter(s => s.role === 'Coordinator');
    coordinators.forEach(c => {
      list.push({
        ...c,
        category: 'Campaign Coordinators (Working With)',
        isWorkingWith: true,
        relationshipNote: 'Campaign & Deliverables Support'
      });
    });

    return list;
  }

  // 6. COORDINATOR: CAN MESSAGE Director, Agents, and Creators they are working with
  if (normRole === 'coordinator') {
    list.push({ name: getActiveDirectorName(), role: 'Director', category: 'Agency Leadership', relationshipNote: 'Agency Director' });

    // Agents
    const agents = STUDIO_STAFF.filter(s => s.role === 'Agent');
    agents.forEach(a => {
      list.push({ ...a, category: 'Talent Agents', relationshipNote: 'Creator Representation' });
    });

    // Creators working on active campaigns/deliverables
    const workingCreators = creators.filter(c => isCoordinatorWorkingWithCreator(senderName, c, deals, campaigns));
    const creatorListToShow = workingCreators.length > 0 ? workingCreators : creators;

    creatorListToShow.forEach(c => {
      list.push({
        name: c.name,
        role: 'Creator',
        handle: c.handle,
        category: 'Campaign Creators (Working With)',
        isWorkingWith: true,
        relationshipNote: `Active Campaign Deliverables • Rep: ${c.assignedAgent || 'Agency Lead'}`
      });
    });

    return list;
  }

  // 7. SUBAGENCY / AGENCY PODS
  list.push({ name: getActiveDirectorName(), role: 'Director', category: 'Agency Leadership', relationshipNote: 'Agency Director' });
  
  creators.forEach(c => {
    list.push({
      name: c.name,
      role: 'Creator',
      handle: c.handle,
      category: 'Pod Talent Roster',
      relationshipNote: `Pod Member • Rep: ${c.assignedAgent || 'Agency Lead'}`
    });
  });

  return list;
}

/**
 * Returns role badge title and permission summary text
 */
export function getRoleMessagingDescription(role?: Role | string): { title: string; summary: string; allowedSummary: string } {
  const normRole = normalizeRole(role);

  switch (normRole) {
    case 'director':
      return {
        title: 'Director Mode (Full Studio Access)',
        summary: 'Direct broadcast & 1-on-1 messaging with all staff, talent creators, brand partners, and agency pods.',
        allowedSummary: 'Can message Everyone: Staff, Agents, Managers, Coordinators, Creators, Brands, and Broadcast Channels.'
      };
    case 'agentmgr':
      return {
        title: 'Agent Manager Mode',
        summary: 'Authorized communications channel with Director, Talent Agents, Campaign Coordinators, and assigned Roster Creators.',
        allowedSummary: 'Can message: Director, Agents, Coordinators, and working Creators.'
      };
    case 'agent':
      return {
        title: 'Talent Agent Mode',
        summary: 'Authorized communications channel with Director, Agent Manager, Coordinators, and your assigned Roster Creators.',
        allowedSummary: 'Can message: Director, Agent Manager, Coordinators, and working Creators.'
      };
    case 'creator':
      return {
        title: 'Creator Partner Mode',
        summary: 'Secure communication channel with your Director, Agent Manager, Assigned Agent, and Campaign Coordinators.',
        allowedSummary: 'Can message: Director, Agent Manager, Assigned Agent, and working Coordinators.'
      };
    case 'coordinator':
      return {
        title: 'Campaign Coordinator Mode',
        summary: 'Operations channel to sync with Director, Agent Manager, Talent Agents, and active Campaign Creators.',
        allowedSummary: 'Can message: Director, Agent Manager, Agents, and working Creators.'
      };
    case 'brand':
      return {
        title: 'Brand Partner Mode (Direct to Director)',
        summary: 'Secure communications line routed exclusively to the Studio Director.',
        allowedSummary: 'Can ONLY message: Director.'
      };
    case 'subagency':
    case 'agency':
      return {
        title: 'Agency Pod Partner Mode',
        summary: 'Dedicated channel to communicate with Studio Director, Agent Management, and Pod Talent.',
        allowedSummary: 'Can message: Director, Agent Manager, and Pod Talent.'
      };
    default:
      return {
        title: 'Studio Messaging',
        summary: 'Direct role-based communication channel.',
        allowedSummary: 'Role-based access enforced.'
      };
  }
}
