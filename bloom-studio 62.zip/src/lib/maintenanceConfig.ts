import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';
import { safeStorage } from '../utils/safeStorage';

export interface MaintenanceConfig {
  enabled: boolean;
  reason: string;
  activatedAt: string | null;
  activatedBy: string | null;
  estimatedDowntime?: string;
  updatedAt?: string;
}

const STORAGE_KEY = 'bloom_emergency_maintenance_config';
const DEFAULT_CONFIG: MaintenanceConfig = {
  enabled: false,
  reason: 'This platform is currently undergoing scheduled security maintenance, architecture upgrades, and system verifications. All transactions, contract signings, and public actions are temporarily locked for integrity protection.',
  activatedAt: null,
  activatedBy: null,
  estimatedDowntime: 'Temporary maintenance window. Resuming shortly.',
};

export const getStoredMaintenanceConfig = (): MaintenanceConfig => {
  try {
    const raw = safeStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_CONFIG, ...parsed };
    }
  } catch (e) {
    console.warn('[maintenanceConfig] Failed to parse local maintenance state:', e);
  }
  return DEFAULT_CONFIG;
};

export const saveStoredMaintenanceConfig = async (
  config: Partial<MaintenanceConfig>,
  callerEmail?: string
): Promise<MaintenanceConfig> => {
  const current = getStoredMaintenanceConfig();
  const updated: MaintenanceConfig = {
    ...current,
    ...config,
    updatedAt: new Date().toISOString(),
    ...(config.enabled === true && !current.enabled
      ? {
          activatedAt: new Date().toISOString(),
          activatedBy: callerEmail || 'Platform Owner',
        }
      : {}),
    ...(config.enabled === false
      ? {
          activatedAt: null,
          activatedBy: null,
        }
      : {}),
  };

  try {
    safeStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent('bloom_maintenance_updated', { detail: updated }));

    if (db) {
      const docRef = doc(db, 'studio-config', 'maintenance');
      await setDoc(docRef, updated, { merge: true });
      console.log('[maintenanceConfig] Successfully synchronized emergency kill switch with Firestore:', updated.enabled);
    }
  } catch (e) {
    console.error('[maintenanceConfig] Error updating maintenance state in Firestore:', e);
  }

  return updated;
};

export const subscribeMaintenanceConfig = (
  onChange: (config: MaintenanceConfig) => void
): (() => void) => {
  // 1. Initial emission from local storage
  onChange(getStoredMaintenanceConfig());

  // 2. Listen for custom events across components
  const handleLocalEvent = (e: Event) => {
    const custom = e as CustomEvent<MaintenanceConfig>;
    if (custom.detail) {
      onChange(custom.detail);
    }
  };
  window.addEventListener('bloom_maintenance_updated', handleLocalEvent);

  // 3. Real-time Firestore subscription
  let unsubscribeFirestore = () => {};
  if (db) {
    try {
      const docRef = doc(db, 'studio-config', 'maintenance');
      unsubscribeFirestore = onSnapshot(
        docRef,
        (snap) => {
          if (snap.exists()) {
            const data = snap.data() as Partial<MaintenanceConfig>;
            const merged: MaintenanceConfig = {
              ...DEFAULT_CONFIG,
              ...data,
            };
            safeStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
            onChange(merged);
          }
        },
        (error) => {
          console.warn('[maintenanceConfig] Real-time subscription error:', error.message);
        }
      );
    } catch (err) {
      console.warn('[maintenanceConfig] Failed to attach Firestore onSnapshot:', err);
    }
  }

  return () => {
    window.removeEventListener('bloom_maintenance_updated', handleLocalEvent);
    unsubscribeFirestore();
  };
};
