/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ReviewItem } from '../types';

/**
 * FTC disclosure markers required for paid partnerships & sponsored campaigns.
 * Checked case-insensitively.
 */
export const FTC_DISCLOSURE_MARKERS = [
  '#ad',
  '#sponsored',
  '#paidpartnership',
  'paid partnership',
  'sponsored by'
];

/**
 * Scans caption draft text for any valid FTC disclosure marker.
 */
export function checkFtcDisclosure(caption?: string): boolean {
  if (!caption) return false;
  const lower = caption.toLowerCase();
  return FTC_DISCLOSURE_MARKERS.some(marker => lower.includes(marker));
}

/**
 * Determines if a review item is linked to a paid deal or brand campaign.
 */
export function isLinkedToPaidCampaign(dealId?: string, brand?: string): boolean {
  const d = (dealId || '').trim().toLowerCase();
  const b = (brand || '').trim().toLowerCase();
  
  // Any deal Id that isn't none/organic is linked to a paid campaign
  if (d && d !== 'none' && d !== 'n/a' && d !== 'organic' && d !== '0') {
    return true;
  }
  
  // Any brand that isn't organic/personal is a brand campaign
  if (
    b &&
    b !== 'none' &&
    b !== 'n/a' &&
    b !== 'organic' &&
    b !== 'personal' &&
    b !== 'organic / personal'
  ) {
    return true;
  }

  return false;
}

/**
 * Evaluates whether a caption draft complies with FTC guidelines.
 * Returns { ftcFlagged: true, ftcFlagReason: 'Missing disclosure' } if non-compliant.
 */
export function evaluateFtcCompliance(
  caption?: string,
  dealId?: string,
  brand?: string
): { ftcFlagged: boolean; ftcFlagReason?: string } {
  const isPaid = isLinkedToPaidCampaign(dealId, brand);
  if (!isPaid) {
    return { ftcFlagged: false };
  }

  const hasMarker = checkFtcDisclosure(caption);
  if (!hasMarker) {
    return {
      ftcFlagged: true,
      ftcFlagReason: 'Missing disclosure'
    };
  }

  return { ftcFlagged: false };
}

/**
 * Prepares a ReviewItem for Firestore saving:
 * - Scans caption draft for FTC compliance if not already staff-overridden.
 * - ALWAYS stamps subagency: 'pod_main'.
 */
export function prepareReviewItemForFirestore(item: Partial<ReviewItem> & { id: string }): ReviewItem {
  const existingPod = item.subagency || (item as any).tenantId || (typeof window !== 'undefined' ? (window as any).currentAgencyId : 'pod_main');
  const stamped: ReviewItem = {
    ...item,
    subagency: existingPod
  } as ReviewItem;

  // If staff has NOT explicitly overridden this hold, re-evaluate automatically
  if (!stamped.ftcOverrideBy) {
    const compliance = evaluateFtcCompliance(stamped.captionDraft, stamped.dealId, stamped.brand);
    stamped.ftcFlagged = compliance.ftcFlagged;
    if (compliance.ftcFlagReason) {
      stamped.ftcFlagReason = compliance.ftcFlagReason;
    } else {
      delete stamped.ftcFlagReason;
    }
  }

  // Remove any undefined properties so Firestore setDoc does not reject them
  Object.keys(stamped).forEach(key => {
    if ((stamped as any)[key] === undefined) {
      delete (stamped as any)[key];
    }
  });

  return stamped;
}
