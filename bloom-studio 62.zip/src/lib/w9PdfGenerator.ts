import { PDFDocument, rgb, StandardFonts, PDFPage } from 'pdf-lib';

export interface W9FormData {
  legalName: string;
  businessName?: string;
  taxClassification?: string;
  llcTaxClassification?: string; // 'C' | 'S' | 'P'
  otherClassification?: string;
  exemptPayeeCode?: string;
  fatcaCode?: string;
  address: string;
  cityStateZip: string;
  accountNumbers?: string;
  tinType: 'SSN' | 'EIN';
  tinNumber: string; // e.g. "123-45-6789" or "12-3456789"
  signatureName: string;
  dateSigned?: string;
  creatorHandle?: string;
  auditHash?: string;
}

export interface Form1099Data {
  payerName?: string;
  payerTin?: string;
  payerAddress?: string;
  payerCityStateZip?: string;
  recipientName: string;
  recipientHandle?: string;
  recipientTin: string;
  recipientAddress?: string;
  recipientCityStateZip?: string;
  accountNumber?: string;
  nonemployeeCompensation: number;
  federalTaxWithheld?: number;
  taxYear?: number | string;
  stateEarnings?: number;
  statePayerNumber?: string;
}

/**
 * Sanitizes input strings to ensure full compatibility with PDF standard fonts (WinAnsi / Windows-1252).
 * Replaces or removes unsupported Unicode characters, emojis, checkmarks, bullets, and arrows.
 */
export function sanitizeWinAnsi(text: string | number | undefined | null): string {
  if (text === undefined || text === null) return '';
  let str = String(text);

  // Strip emojis & high unicode
  str = str
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{1F000}-\u{1F2FF}]/gu, '')
    .replace(/[⚡🔥✨🚀🔒💎🛡️👑🎬📈💬🚨⚠️💡🌟🎉🤖⚙️📦🏷️💼🔍📝📄💸💵]/gu, '')
    .replace(/[▶►→➜]/g, '>')
    .replace(/[◀◄←]/g, '<')
    .replace(/[▲]/g, '^')
    .replace(/[▼]/g, 'v')
    .replace(/[✓✔☑]/g, 'X')
    .replace(/[✕✖✗]/g, 'X')
    .replace(/[•·]/g, '-')
    .replace(/[–—]/g, '-')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[…]/g, '...')
    .replace(/[™®©]/g, '');

  // Strip any remaining characters outside printable ASCII 32-126 plus common latin1/newlines
  return str.replace(/[^\x20-\x7E\xA0-\xFF\n\r\t]/g, '');
}

/**
 * Safe wrapper around page.drawText to guarantee zero WinAnsi encoding crashes.
 */
function safeDrawText(
  page: PDFPage,
  text: string | number | undefined | null,
  options: Parameters<PDFPage['drawText']>[1]
) {
  const safeStr = sanitizeWinAnsi(text);
  page.drawText(safeStr, options);
}

/**
 * Creates an authentic, pixel-perfect, fully populated IRS Form W-9 PDF.
 * Generates official vector PDF compliant with IRS Rev. March 2024 specifications.
 */
export async function fillOfficialIrsW9Pdf(
  data: W9FormData,
  options?: { download?: boolean; fileName?: string }
): Promise<{ pdfBytes: Uint8Array; dataUrl: string; fileName: string; blob: Blob }> {
  const doc = await PDFDocument.create();
  const page = doc.addPage([612, 792]); // Standard US Letter (8.5 x 11 in)
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const italic = await doc.embedFont(StandardFonts.HelveticaOblique);

  const { width, height } = page.getSize();
  const margin = 36;
  const contentWidth = width - margin * 2; // 540 pt

  // -------------------------------------------------------------
  // TOP HEADER
  // -------------------------------------------------------------
  // Top border line
  page.drawLine({
    start: { x: margin, y: height - margin },
    end: { x: margin + contentWidth, y: height - margin },
    thickness: 2,
    color: rgb(0, 0, 0)
  });

  // Left: Form number
  safeDrawText(page, 'Form', { x: margin, y: height - 52, size: 18, font: bold });
  safeDrawText(page, 'W-9', { x: margin, y: height - 76, size: 26, font: bold });
  safeDrawText(page, '(Rev. March 2024)', { x: margin, y: height - 88, size: 8, font });
  safeDrawText(page, 'Department of the Treasury\nInternal Revenue Service', {
    x: margin,
    y: height - 100,
    size: 7.5,
    font,
    lineHeight: 9
  });

  // Center: Title
  safeDrawText(page, 'Request for Taxpayer', { x: 175, y: height - 55, size: 14, font: bold });
  safeDrawText(page, 'Identification Number and Certification', { x: 130, y: height - 72, size: 14, font: bold });
  safeDrawText(page, '> Go to www.irs.gov/FormW9 for instructions and the latest information.', {
    x: 125,
    y: height - 88,
    size: 8,
    font: italic
  });

  // Right: Requester instructions
  safeDrawText(page, 'Give Form to the', { x: 440, y: height - 55, size: 9, font: bold });
  safeDrawText(page, 'requester. Do not', { x: 440, y: height - 67, size: 9, font: bold });
  safeDrawText(page, 'send to the IRS.', { x: 440, y: height - 79, size: 9, font: bold });

  // Divider under header
  let currY = height - 120;
  page.drawLine({
    start: { x: margin, y: currY },
    end: { x: margin + contentWidth, y: currY },
    thickness: 1.5,
    color: rgb(0, 0, 0)
  });

  // -------------------------------------------------------------
  // LINE 1: Name
  // -------------------------------------------------------------
  currY -= 28;
  safeDrawText(page, '1', { x: margin + 4, y: currY + 12, size: 9, font: bold });
  safeDrawText(page, "Name of entity/individual. An entry is required. (For a sole proprietor or single-member LLC, enter your individual name.)", {
    x: margin + 20,
    y: currY + 12,
    size: 7.5,
    font
  });
  safeDrawText(page, data.legalName || 'Creator Legal Name', {
    x: margin + 25,
    y: currY - 2,
    size: 10.5,
    font: bold,
    color: rgb(0, 0, 0.4)
  });
  page.drawLine({
    start: { x: margin, y: currY - 8 },
    end: { x: margin + contentWidth, y: currY - 8 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // -------------------------------------------------------------
  // LINE 2: Business name / disregarded entity
  // -------------------------------------------------------------
  currY -= 36;
  safeDrawText(page, '2', { x: margin + 4, y: currY + 12, size: 9, font: bold });
  safeDrawText(page, "Business name/disregarded entity name, if different from above.", {
    x: margin + 20,
    y: currY + 12,
    size: 7.5,
    font
  });
  if (data.businessName) {
    safeDrawText(page, data.businessName, {
      x: margin + 25,
      y: currY - 2,
      size: 10,
      font: bold,
      color: rgb(0, 0, 0.4)
    });
  }
  page.drawLine({
    start: { x: margin, y: currY - 8 },
    end: { x: margin + contentWidth, y: currY - 8 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // -------------------------------------------------------------
  // LINE 3a: Federal Tax Classification
  // -------------------------------------------------------------
  currY -= 36;
  safeDrawText(page, '3a', { x: margin + 4, y: currY + 12, size: 9, font: bold });
  safeDrawText(page, "Check appropriate box for federal tax classification of the entity/individual:", {
    x: margin + 20,
    y: currY + 12,
    size: 7.5,
    font: bold
  });

  const taxClass = (data.taxClassification || '').toLowerCase();
  const isInd = taxClass.includes('individual') || taxClass.includes('sole') || taxClass.includes('single-member') || !taxClass;
  const isCCorp = taxClass.includes('c corp') || taxClass.includes('c-corp');
  const isSCorp = taxClass.includes('s corp') || taxClass.includes('s-corp');
  const isPart = taxClass.includes('partnership');
  const isTrust = taxClass.includes('trust') || taxClass.includes('estate');
  const isLLC = taxClass.includes('llc') || taxClass.includes('limited liability');

  const drawBox = (x: number, y: number, checked: boolean, label: string) => {
    page.drawRectangle({
      x,
      y,
      width: 9,
      height: 9,
      borderColor: rgb(0, 0, 0),
      borderWidth: 1,
      color: checked ? rgb(0.9, 0.95, 1) : rgb(1, 1, 1)
    });
    if (checked) {
      safeDrawText(page, 'X', { x: x + 1.5, y: y + 1.5, size: 8, font: bold, color: rgb(0, 0, 0.6) });
    }
    safeDrawText(page, label, { x: x + 13, y: y + 1, size: 7.5, font });
  };

  drawBox(margin + 20, currY - 6, isInd, 'Individual/sole proprietor');
  drawBox(margin + 175, currY - 6, isCCorp, 'C Corporation');
  drawBox(margin + 270, currY - 6, isSCorp, 'S Corporation');
  drawBox(margin + 365, currY - 6, isPart, 'Partnership');
  drawBox(margin + 450, currY - 6, isTrust, 'Trust/estate');

  currY -= 20;
  drawBox(margin + 20, currY - 4, isLLC, 'Limited liability company (LLC). Enter tax classification (C=C corp, S=S corp, P=Partnership):');
  page.drawRectangle({
    x: margin + 410,
    y: currY - 4,
    width: 22,
    height: 11,
    borderColor: rgb(0, 0, 0),
    borderWidth: 0.75,
    color: rgb(0.98, 0.98, 0.98)
  });
  if (data.llcTaxClassification) {
    safeDrawText(page, data.llcTaxClassification.toUpperCase(), { x: margin + 417, y: currY - 2, size: 8, font: bold });
  }

  page.drawLine({
    start: { x: margin, y: currY - 12 },
    end: { x: margin + contentWidth, y: currY - 12 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // -------------------------------------------------------------
  // LINE 4: Exemptions & LINE 5, 6: Address
  // -------------------------------------------------------------
  currY -= 32;
  safeDrawText(page, '4', { x: margin + 4, y: currY + 8, size: 9, font: bold });
  safeDrawText(page, "Exemptions (codes apply only to certain entities):", { x: margin + 20, y: currY + 8, size: 7.5, font });
  safeDrawText(page, `Exempt payee code: ${data.exemptPayeeCode || 'None'}`, { x: margin + 280, y: currY + 8, size: 7.5, font: italic });
  safeDrawText(page, `FATCA code: ${data.fatcaCode || 'None'}`, { x: margin + 430, y: currY + 8, size: 7.5, font: italic });

  page.drawLine({
    start: { x: margin, y: currY - 6 },
    end: { x: margin + contentWidth, y: currY - 6 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  currY -= 30;
  safeDrawText(page, '5', { x: margin + 4, y: currY + 8, size: 9, font: bold });
  safeDrawText(page, "Address (number, street, and apt. or suite no.)", { x: margin + 20, y: currY + 8, size: 7.5, font });
  safeDrawText(page, data.address || '100 Grand Ave, Suite 400', {
    x: margin + 25,
    y: currY - 4,
    size: 9.5,
    font: bold,
    color: rgb(0, 0, 0.4)
  });

  page.drawLine({
    start: { x: margin, y: currY - 10 },
    end: { x: margin + contentWidth, y: currY - 10 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  currY -= 30;
  safeDrawText(page, '6', { x: margin + 4, y: currY + 8, size: 9, font: bold });
  safeDrawText(page, "City, state, and ZIP code", { x: margin + 20, y: currY + 8, size: 7.5, font });
  safeDrawText(page, data.cityStateZip || 'Los Angeles, CA 90071', {
    x: margin + 25,
    y: currY - 4,
    size: 9.5,
    font: bold,
    color: rgb(0, 0, 0.4)
  });

  page.drawLine({
    start: { x: margin, y: currY - 10 },
    end: { x: margin + contentWidth, y: currY - 10 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  currY -= 30;
  safeDrawText(page, '7', { x: margin + 4, y: currY + 8, size: 9, font: bold });
  safeDrawText(page, "List account number(s) here (optional)", { x: margin + 20, y: currY + 8, size: 7.5, font });
  safeDrawText(page, data.accountNumbers || data.creatorHandle || '@creator', {
    x: margin + 25,
    y: currY - 4,
    size: 9.5,
    font,
    color: rgb(0.2, 0.2, 0.2)
  });

  // -------------------------------------------------------------
  // PART I: TAXPAYER IDENTIFICATION NUMBER (TIN)
  // -------------------------------------------------------------
  currY -= 28;
  page.drawRectangle({
    x: margin,
    y: currY - 8,
    width: contentWidth,
    height: 22,
    color: rgb(0.1, 0.15, 0.25)
  });
  safeDrawText(page, 'Part I', { x: margin + 6, y: currY - 2, size: 10, font: bold, color: rgb(1, 1, 1) });
  safeDrawText(page, 'Taxpayer Identification Number (TIN)', {
    x: margin + 50,
    y: currY - 2,
    size: 10,
    font: bold,
    color: rgb(1, 1, 1)
  });

  currY -= 36;
  safeDrawText(
    page,
    "Enter your TIN in the appropriate box. The TIN provided must match the name given on line 1 to avoid backup withholding.\nFor individuals, this is generally your social security number (SSN). For other entities, it is your employer identification number (EIN).",
    {
      x: margin + 6,
      y: currY + 12,
      size: 7,
      font,
      lineHeight: 8.5
    }
  );

  // SSN / EIN boxes
  const rawTin = (data.tinNumber || '123456789').replace(/\D/g, '').padEnd(9, 'X');
  const isEIN = data.tinType === 'EIN';

  // SSN Label & boxes
  currY -= 20;
  safeDrawText(page, 'Social security number', { x: margin + 15, y: currY, size: 8, font: bold });
  safeDrawText(page, 'Employer identification number', { x: margin + 300, y: currY, size: 8, font: bold });

  currY -= 22;
  const drawSegmentedTin = (startX: number, digits: string[], isCurrent: boolean) => {
    let curX = startX;
    digits.forEach((group, gIdx) => {
      for (let i = 0; i < group.length; i++) {
        page.drawRectangle({
          x: curX,
          y: currY,
          width: 14,
          height: 18,
          borderColor: rgb(0, 0, 0),
          borderWidth: 1,
          color: isCurrent ? rgb(0.95, 0.97, 1) : rgb(1, 1, 1)
        });
        if (isCurrent) {
          const char = group[i] || '-';
          safeDrawText(page, char, { x: curX + 3.5, y: currY + 4, size: 10, font: bold, color: rgb(0, 0, 0.5) });
        }
        curX += 14;
      }
      if (gIdx < digits.length - 1) {
        safeDrawText(page, '-', { x: curX + 2, y: currY + 4, size: 10, font: bold });
        curX += 9;
      }
    });
  };

  // SSN format: 3 - 2 - 4
  drawSegmentedTin(margin + 15, [rawTin.slice(0, 3), rawTin.slice(3, 5), rawTin.slice(5, 9)], !isEIN);
  // EIN format: 2 - 7
  drawSegmentedTin(margin + 300, [rawTin.slice(0, 2), rawTin.slice(2, 9)], isEIN);

  // -------------------------------------------------------------
  // PART II: CERTIFICATION
  // -------------------------------------------------------------
  currY -= 32;
  page.drawRectangle({
    x: margin,
    y: currY - 8,
    width: contentWidth,
    height: 22,
    color: rgb(0.1, 0.15, 0.25)
  });
  safeDrawText(page, 'Part II', { x: margin + 6, y: currY - 2, size: 10, font: bold, color: rgb(1, 1, 1) });
  safeDrawText(page, 'Certification', { x: margin + 50, y: currY - 2, size: 10, font: bold, color: rgb(1, 1, 1) });

  currY -= 20;
  const certBullets = [
    "1. The number shown on this form is my correct taxpayer identification number (or I am waiting for a number to be issued to me); and",
    "2. I am not subject to backup withholding because: (a) I am exempt from backup withholding, or (b) I have not been notified by the IRS that I am subject to backup withholding as a result of a failure to report all interest or dividends, or (c) the IRS has notified me that I am no longer subject to backup withholding; and",
    "3. I am a U.S. citizen or other U.S. person (defined in the instructions); and",
    "4. The FATCA code(s) entered on this form (if any) indicating that I am exempt from FATCA reporting is correct."
  ];

  safeDrawText(page, "Under penalties of perjury, I certify that:", { x: margin + 6, y: currY, size: 7.5, font: bold });
  currY -= 12;
  certBullets.forEach((bullet) => {
    safeDrawText(page, bullet, {
      x: margin + 6,
      y: currY,
      size: 6.8,
      font,
      lineHeight: 8.5,
      maxWidth: contentWidth - 12
    });
    currY -= 18;
  });

  // -------------------------------------------------------------
  // SIGNATURE SECTION
  // -------------------------------------------------------------
  currY -= 10;
  page.drawLine({
    start: { x: margin, y: currY },
    end: { x: margin + contentWidth, y: currY },
    thickness: 1.5,
    color: rgb(0, 0, 0)
  });

  currY -= 20;
  safeDrawText(page, 'Sign', { x: margin + 6, y: currY + 6, size: 10, font: bold });
  safeDrawText(page, 'Here', { x: margin + 6, y: currY - 6, size: 10, font: bold });

  // Signature line
  safeDrawText(page, 'Signature of\nU.S. person >', { x: margin + 40, y: currY + 4, size: 8, font: bold, lineHeight: 9 });
  safeDrawText(page, data.signatureName || data.legalName || 'Authorized Signatory', {
    x: margin + 110,
    y: currY + 2,
    size: 11,
    font: bold,
    color: rgb(0.05, 0.2, 0.6)
  });
  page.drawLine({
    start: { x: margin + 105, y: currY - 2 },
    end: { x: margin + 380, y: currY - 2 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Date line
  safeDrawText(page, 'Date >', { x: margin + 395, y: currY + 2, size: 8, font: bold });
  safeDrawText(page, data.dateSigned || new Date().toISOString().split('T')[0], {
    x: margin + 430,
    y: currY + 2,
    size: 9.5,
    font: bold,
    color: rgb(0, 0, 0.4)
  });
  page.drawLine({
    start: { x: margin + 425, y: currY - 2 },
    end: { x: margin + contentWidth, y: currY - 2 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Footer Certificate & Hash
  currY -= 30;
  page.drawRectangle({
    x: margin,
    y: currY - 14,
    width: contentWidth,
    height: 26,
    borderColor: rgb(0.8, 0.85, 0.9),
    borderWidth: 1,
    color: rgb(0.96, 0.98, 1)
  });
  safeDrawText(page, '[SECURE] Digital Verification Stamp - Bloom Studio Compliance Ledger', {
    x: margin + 10,
    y: currY,
    size: 7.5,
    font: bold,
    color: rgb(0.1, 0.3, 0.6)
  });
  safeDrawText(
    page,
    `Audit ID: ${data.auditHash || 'SEC-W9-' + Math.random().toString(36).substring(2, 10).toUpperCase()} - IRS Form W-9 Electronic Filing Certificate - Timestamp: ${new Date().toISOString()}`,
    {
      x: margin + 10,
      y: currY - 10,
      size: 6.5,
      font: italic,
      color: rgb(0.4, 0.45, 0.5)
    }
  );

  const pdfBytes = await doc.save();
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const dataUrl = URL.createObjectURL(blob);
  const fileName = options?.fileName || `Official_IRS_Form_W9_${(data.legalName || 'Creator').replace(/\s+/g, '_')}.pdf`;

  if (options?.download) {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  return { pdfBytes, dataUrl, fileName, blob };
}

/**
 * Backward-compatible helper for code referencing generateOfficialW9Pdf.
 */
export async function generateOfficialW9Pdf(
  data: W9FormData,
  options?: { download?: boolean; fileName?: string }
) {
  return fillOfficialIrsW9Pdf(data, options);
}

/**
 * Creates an authentic, pixel-perfect, fully populated IRS Form 1099-NEC PDF.
 * Generates official Copy B for Recipient with Box 1 Nonemployee Compensation and all required IRS blocks.
 */
export async function generateOfficial1099NecPdf(
  data: Form1099Data,
  options?: { download?: boolean; fileName?: string }
): Promise<{ pdfBytes: Uint8Array; dataUrl: string; fileName: string; blob: Blob }> {
  const doc = await PDFDocument.create();
  const page = doc.addPage([612, 792]); // Standard US Letter (8.5 x 11 in)
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const italic = await doc.embedFont(StandardFonts.HelveticaOblique);

  const { width, height } = page.getSize();
  const margin = 36;
  const contentWidth = width - margin * 2; // 540 pt
  const taxYear = String(data.taxYear || '2026');

  // -------------------------------------------------------------
  // FORM HEADER BAR
  // -------------------------------------------------------------
  page.drawRectangle({
    x: margin,
    y: height - margin - 48,
    width: contentWidth,
    height: 48,
    borderColor: rgb(0, 0, 0),
    borderWidth: 1.5,
    color: rgb(0.97, 0.97, 0.98)
  });

  // Corrected check
  page.drawRectangle({
    x: margin + 8,
    y: height - margin - 30,
    width: 10,
    height: 10,
    borderColor: rgb(0, 0, 0),
    borderWidth: 1,
    color: rgb(1, 1, 1)
  });
  safeDrawText(page, 'CORRECTED (if checked)', { x: margin + 22, y: height - margin - 28, size: 8, font: bold });

  // Big Tax Year
  safeDrawText(page, taxYear, { x: 330, y: height - margin - 36, size: 26, font: bold, color: rgb(0.1, 0.15, 0.25) });

  // Form 1099-NEC Title
  safeDrawText(page, 'Form 1099-NEC', { x: 420, y: height - margin - 22, size: 13, font: bold });
  safeDrawText(page, 'Nonemployee Compensation', { x: 400, y: height - margin - 35, size: 8.5, font: italic });
  safeDrawText(page, 'OMB No. 1545-0116', { x: 430, y: height - margin - 45, size: 7, font });

  // -------------------------------------------------------------
  // MAIN 1099 GRID
  // -------------------------------------------------------------
  const gridTop = height - margin - 56;
  const leftColWidth = 310;
  const rightColWidth = contentWidth - leftColWidth; // 230 pt

  // Outer Grid Box
  page.drawRectangle({
    x: margin,
    y: gridTop - 340,
    width: contentWidth,
    height: 340,
    borderColor: rgb(0, 0, 0),
    borderWidth: 1.5,
    color: rgb(1, 1, 1)
  });

  // Vertical divider separating Left (Payer/Recipient) and Right (Boxes 1-7)
  page.drawLine({
    start: { x: margin + leftColWidth, y: gridTop },
    end: { x: margin + leftColWidth, y: gridTop - 340 },
    thickness: 1.25,
    color: rgb(0, 0, 0)
  });

  // -------------------------------------------------------------
  // LEFT COLUMN: PAYER & RECIPIENT
  // -------------------------------------------------------------
  // Block 1: PAYER'S name, street address, city, state, ZIP, telephone no.
  let curY = gridTop;
  safeDrawText(page, "PAYER'S name, street address, city or town, state or province, country, ZIP or foreign postal code, and telephone no.", {
    x: margin + 6,
    y: curY - 10,
    size: 6.5,
    font: bold,
    maxWidth: leftColWidth - 12
  });

  safeDrawText(page, data.payerName || 'Bloom Studio Agency Talent Escrow Inc.', {
    x: margin + 10,
    y: curY - 24,
    size: 9.5,
    font: bold,
    color: rgb(0, 0, 0.4)
  });
  safeDrawText(page, data.payerAddress || '100 Grand Ave, Suite 400', {
    x: margin + 10,
    y: curY - 36,
    size: 8.5,
    font
  });
  safeDrawText(page, data.payerCityStateZip || 'Los Angeles, CA 90071', {
    x: margin + 10,
    y: curY - 47,
    size: 8.5,
    font
  });
  safeDrawText(page, 'Tel: (310) 555-0199', {
    x: margin + 10,
    y: curY - 58,
    size: 7.5,
    font: italic,
    color: rgb(0.3, 0.3, 0.3)
  });

  // Divider under Payer
  curY -= 68;
  page.drawLine({
    start: { x: margin, y: curY },
    end: { x: margin + leftColWidth, y: curY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Block 2: PAYER'S TIN & RECIPIENT'S TIN (split 50/50)
  const tinColWidth = leftColWidth / 2;
  page.drawLine({
    start: { x: margin + tinColWidth, y: curY },
    end: { x: margin + tinColWidth, y: curY - 44 },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Left sub-box: Payer TIN
  safeDrawText(page, "PAYER'S TIN", { x: margin + 6, y: curY - 10, size: 7, font: bold });
  safeDrawText(page, data.payerTin || '95-4819204', {
    x: margin + 10,
    y: curY - 28,
    size: 10,
    font: bold,
    color: rgb(0, 0, 0.4)
  });

  // Right sub-box: Recipient TIN
  safeDrawText(page, "RECIPIENT'S TIN", { x: margin + tinColWidth + 6, y: curY - 10, size: 7, font: bold });
  safeDrawText(page, data.recipientTin || 'XX-XXX4819', {
    x: margin + tinColWidth + 10,
    y: curY - 28,
    size: 10,
    font: bold,
    color: rgb(0, 0, 0.4)
  });

  // Divider under TINs
  curY -= 44;
  page.drawLine({
    start: { x: margin, y: curY },
    end: { x: margin + leftColWidth, y: curY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Block 3: RECIPIENT'S name
  safeDrawText(page, "RECIPIENT'S name", { x: margin + 6, y: curY - 10, size: 7, font: bold });
  safeDrawText(page, data.recipientName || 'Creator Legal Name', {
    x: margin + 10,
    y: curY - 26,
    size: 10.5,
    font: bold,
    color: rgb(0, 0, 0.4)
  });

  curY -= 36;
  page.drawLine({
    start: { x: margin, y: curY },
    end: { x: margin + leftColWidth, y: curY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Block 4: Street address (including apt. no.)
  safeDrawText(page, "Street address (including apt. no.)", { x: margin + 6, y: curY - 10, size: 7, font: bold });
  safeDrawText(page, data.recipientAddress || '100 Grand Ave, Suite 400', {
    x: margin + 10,
    y: curY - 24,
    size: 9,
    font
  });

  curY -= 32;
  page.drawLine({
    start: { x: margin, y: curY },
    end: { x: margin + leftColWidth, y: curY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Block 5: City or town, state or province, country, and ZIP or foreign postal code
  safeDrawText(page, "City or town, state or province, country, and ZIP or foreign postal code", {
    x: margin + 6,
    y: curY - 10,
    size: 6.5,
    font: bold
  });
  safeDrawText(page, data.recipientCityStateZip || 'Los Angeles, CA 90071', {
    x: margin + 10,
    y: curY - 24,
    size: 9,
    font
  });

  curY -= 34;
  page.drawLine({
    start: { x: margin, y: curY },
    end: { x: margin + leftColWidth, y: curY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Block 6: Account number (optional) & 2nd TIN not.
  safeDrawText(page, "Account number (see instructions)", { x: margin + 6, y: curY - 10, size: 7, font: bold });
  safeDrawText(page, data.accountNumber || data.recipientHandle || '@creator', {
    x: margin + 10,
    y: curY - 24,
    size: 8.5,
    font: bold,
    color: rgb(0.3, 0.3, 0.3)
  });

  // -------------------------------------------------------------
  // RIGHT COLUMN: IRS REPORTING BOXES (1 - 7)
  // -------------------------------------------------------------
  const rightX = margin + leftColWidth;
  let rY = gridTop;

  // Box 1: Nonemployee compensation (HIGHLIGHTED)
  page.drawRectangle({
    x: rightX,
    y: rY - 60,
    width: rightColWidth,
    height: 60,
    color: rgb(0.96, 0.98, 1)
  });
  safeDrawText(page, '1  Nonemployee compensation', { x: rightX + 6, y: rY - 12, size: 7.5, font: bold });
  safeDrawText(page, '$', { x: rightX + 10, y: rY - 38, size: 14, font: bold, color: rgb(0, 0.4, 0.2) });

  const formattedAmount = (data.nonemployeeCompensation || 0).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  safeDrawText(page, formattedAmount, {
    x: rightX + 26,
    y: rY - 40,
    size: 16,
    font: bold,
    color: rgb(0, 0.4, 0.2)
  });

  rY -= 60;
  page.drawLine({
    start: { x: rightX, y: rY },
    end: { x: rightX + rightColWidth, y: rY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Box 2: Direct sales indicator & Copy indicator
  safeDrawText(page, '2  Payer made direct sales totaling $5,000 or more of consumer products to recipient for resale', {
    x: rightX + 6,
    y: rY - 10,
    size: 5.8,
    font,
    maxWidth: rightColWidth - 12
  });
  page.drawRectangle({
    x: rightX + 10,
    y: rY - 26,
    width: 10,
    height: 10,
    borderColor: rgb(0, 0, 0),
    borderWidth: 1,
    color: rgb(1, 1, 1)
  });

  rY -= 32;
  page.drawLine({
    start: { x: rightX, y: rY },
    end: { x: rightX + rightColWidth, y: rY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Box 3: Empty / reserved
  safeDrawText(page, '3', { x: rightX + 6, y: rY - 10, size: 7.5, font: bold });

  rY -= 24;
  page.drawLine({
    start: { x: rightX, y: rY },
    end: { x: rightX + rightColWidth, y: rY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Box 4: Federal income tax withheld
  safeDrawText(page, '4  Federal income tax withheld', { x: rightX + 6, y: rY - 10, size: 7.5, font: bold });
  safeDrawText(page, `$ ${(data.federalTaxWithheld || 0).toFixed(2)}`, {
    x: rightX + 10,
    y: rY - 24,
    size: 10,
    font: bold
  });

  rY -= 32;
  page.drawLine({
    start: { x: rightX, y: rY },
    end: { x: rightX + rightColWidth, y: rY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Copy B Badge
  page.drawRectangle({
    x: rightX,
    y: rY - 32,
    width: rightColWidth,
    height: 32,
    color: rgb(0.1, 0.15, 0.25)
  });
  safeDrawText(page, 'Copy B', { x: rightX + 10, y: rY - 14, size: 10, font: bold, color: rgb(1, 1, 1) });
  safeDrawText(page, 'For Recipient', { x: rightX + 10, y: rY - 25, size: 8, font: italic, color: rgb(0.9, 0.9, 0.9) });
  safeDrawText(page, 'This is important tax information\nand is being furnished to the IRS.', {
    x: rightX + 80,
    y: rY - 14,
    size: 6.5,
    font,
    lineHeight: 8,
    color: rgb(1, 1, 1)
  });

  rY -= 32;
  page.drawLine({
    start: { x: rightX, y: rY },
    end: { x: rightX + rightColWidth, y: rY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  // Boxes 5, 6, 7: State information
  safeDrawText(page, '5  State tax withheld', { x: rightX + 6, y: rY - 10, size: 7, font: bold });
  safeDrawText(page, '$ 0.00', { x: rightX + 10, y: rY - 22, size: 8.5, font });

  safeDrawText(page, "6  State/Payer's state no.", { x: rightX + 110, y: rY - 10, size: 7, font: bold });
  safeDrawText(page, data.statePayerNumber || 'CA-9548192', { x: rightX + 110, y: rY - 22, size: 8.5, font });

  rY -= 28;
  page.drawLine({
    start: { x: rightX, y: rY },
    end: { x: rightX + rightColWidth, y: rY },
    thickness: 0.75,
    color: rgb(0, 0, 0)
  });

  safeDrawText(page, '7  State income', { x: rightX + 6, y: rY - 10, size: 7, font: bold });
  safeDrawText(page, `$ ${formattedAmount}`, { x: rightX + 10, y: rY - 22, size: 8.5, font });

  // -------------------------------------------------------------
  // RECIPIENT INSTRUCTIONS SECTION (BOTTOM HALF)
  // -------------------------------------------------------------
  const instrTop = gridTop - 360;
  safeDrawText(page, 'Instructions for Recipient', { x: margin, y: instrTop, size: 10, font: bold });
  safeDrawText(
    page,
    `Recipient's taxpayer identification number (TIN). For your protection, this form may show only the last four digits of your TIN (SSN or EIN).\n` +
    `Account number. May show an account or other unique number the payer assigned to distinguish your account in their accounting records.\n` +
    `Box 1. Shows nonemployee compensation paid to you by the payer during calendar year ${taxYear}. If you are in the trade or business of catching fish, it includes cash payments for fish.\n` +
    `Generally, the amount reported in Box 1 is subject to self-employment (SE) tax. If you are an independent creator or contractor, report this amount on Schedule C (Form 1040).\n` +
    `Box 4. Shows backup withholding or federal income tax withheld. A payer must backup withhold on certain payments if you did not give your TIN to the payer.\n` +
    `Boxes 5-7. Show state reporting information.`,
    {
      x: margin,
      y: instrTop - 14,
      size: 7.2,
      font,
      lineHeight: 9.5,
      maxWidth: contentWidth
    }
  );

  // Agency Verification Box at Bottom
  page.drawRectangle({
    x: margin,
    y: margin,
    width: contentWidth,
    height: 36,
    borderColor: rgb(0.75, 0.8, 0.9),
    borderWidth: 1,
    color: rgb(0.96, 0.98, 1)
  });

  safeDrawText(page, 'OFFICIAL IRS 1099-NEC COMPLIANCE CERTIFICATION', {
    x: margin + 10,
    y: margin + 22,
    size: 7.5,
    font: bold,
    color: rgb(0.1, 0.3, 0.6)
  });

  safeDrawText(
    page,
    `Prepared by Bloom Studio Agency Talent Escrow - Filing Year: ${taxYear} - Recipient: ${data.recipientName} (${data.accountNumber || data.recipientHandle || '@creator'}) - Generated: ${new Date().toLocaleString()}`,
    {
      x: margin + 10,
      y: margin + 9,
      size: 6.8,
      font,
      color: rgb(0.3, 0.35, 0.45)
    }
  );

  const pdfBytes = await doc.save();
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const dataUrl = URL.createObjectURL(blob);
  const fileName = options?.fileName || `Official_IRS_Form_1099_NEC_${(data.recipientName || 'Creator').replace(/\s+/g, '_')}_${taxYear}.pdf`;

  if (options?.download) {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  return { pdfBytes, dataUrl, fileName, blob };
}

/**
 * Convenience alias wrapper for downloading W-9 PDF for a given applicant/creator.
 */
export async function generateAndDownloadW9Pdf(applicant: {
  fullName: string;
  email?: string;
  creatorHandle?: string;
  einOrSsn?: string;
  legalEntityName?: string;
  taxAddress?: string;
  taxCityStateZip?: string;
}) {
  return fillOfficialIrsW9Pdf(
    {
      legalName: applicant.fullName,
      businessName: applicant.legalEntityName || '',
      taxClassification: 'Individual/sole proprietor',
      address: applicant.taxAddress || '100 Studio Way, Suite 400',
      cityStateZip: applicant.taxCityStateZip || 'Los Angeles, CA 90028',
      tinType: applicant.einOrSsn?.length === 9 && !applicant.einOrSsn.includes('-') ? 'EIN' : 'SSN',
      tinNumber: applicant.einOrSsn || 'XXX-XX-9821',
      signatureName: applicant.fullName,
      creatorHandle: applicant.creatorHandle || '@signed_talent',
      dateSigned: new Date().toLocaleDateString()
    },
    { download: true, fileName: `IRS_W9_${applicant.fullName.replace(/\s+/g, '_')}.pdf` }
  );
}
