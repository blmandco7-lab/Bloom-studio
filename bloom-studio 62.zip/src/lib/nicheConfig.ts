import { useState, useEffect } from 'react';
import { safeStorage } from '../utils/safeStorage';

export const CORE_AGENCY_NICHES = ['Pets', 'Beauty', 'Lifestyle'] as const;
export type CoreAgencyNiche = typeof CORE_AGENCY_NICHES[number];

export interface NicheInfo {
  value: string;
  label: string;
  emoji: string;
  description: string;
  isCore: boolean;
  colorClass: string;
  bgClass: string;
  borderClass: string;
}

export const NICHE_DEFINITIONS: Record<string, NicheInfo> = {
  Pets: {
    value: 'Pets',
    label: 'Pets',
    emoji: '🐾',
    description: 'Pet influencers, animal wellness, training, & pet nutrition',
    isCore: true,
    colorClass: 'text-emerald-300',
    bgClass: 'bg-emerald-950/60',
    borderClass: 'border-emerald-500/40'
  },
  Beauty: {
    value: 'Beauty',
    label: 'Beauty & Skincare',
    emoji: '💄',
    description: 'Cosmetics, skincare routines, haircare & beauty tutorials',
    isCore: true,
    colorClass: 'text-pink-300',
    bgClass: 'bg-pink-950/60',
    borderClass: 'border-pink-500/40'
  },
  Lifestyle: {
    value: 'Lifestyle',
    label: 'Lifestyle',
    emoji: '✨',
    description: 'Curated daily vlogs, home aesthetics, wellness & daily living',
    isCore: true,
    colorClass: 'text-amber-300',
    bgClass: 'bg-amber-950/60',
    borderClass: 'border-amber-500/40'
  },
  // Extended / optional niches (accessible only if Director enables Extended Niches toggle)
  Fashion: {
    value: 'Fashion',
    label: 'Fashion',
    emoji: '👗',
    description: 'Apparel, lookbooks, streetwear & runway fashion',
    isCore: false,
    colorClass: 'text-purple-300',
    bgClass: 'bg-purple-950/60',
    borderClass: 'border-purple-500/40'
  },
  Fitness: {
    value: 'Fitness',
    label: 'Fitness & Health',
    emoji: '🏋️',
    description: 'Workouts, nutrition, athlete training & wellness',
    isCore: false,
    colorClass: 'text-orange-300',
    bgClass: 'bg-orange-950/60',
    borderClass: 'border-orange-500/40'
  },
  Tech: {
    value: 'Tech',
    label: 'Tech & Gadgets',
    emoji: '💻',
    description: 'Hardware, consumer electronics & software reviews',
    isCore: false,
    colorClass: 'text-cyan-300',
    bgClass: 'bg-cyan-950/60',
    borderClass: 'border-cyan-500/40'
  },
  Gaming: {
    value: 'Gaming',
    label: 'Gaming & Streaming',
    emoji: '🎮',
    description: 'Gameplay walkthroughs, esports & streaming',
    isCore: false,
    colorClass: 'text-indigo-300',
    bgClass: 'bg-indigo-950/60',
    borderClass: 'border-indigo-500/40'
  },
  'Food & Cooking': {
    value: 'Food & Cooking',
    label: 'Food & Cooking',
    emoji: '🍳',
    description: 'Recipes, culinary reviews & kitchen guides',
    isCore: false,
    colorClass: 'text-agency-gold',
    bgClass: 'bg-amber-950/60',
    borderClass: 'border-[#C9A46A]/40'
  },
  Travel: {
    value: 'Travel',
    label: 'Luxury & Travel',
    emoji: '✈️',
    description: 'Destinations, hotel reviews & travel guides',
    isCore: false,
    colorClass: 'text-teal-300',
    bgClass: 'bg-teal-950/60',
    borderClass: 'border-teal-500/40'
  }
};

const STORAGE_KEY = 'wl_agency_strict_core_niches';
const EXTENDED_LIST_KEY = 'wl_agency_niches';

export function getStrictCoreNichesSetting(): boolean {
  try {
    const item = safeStorage.getItem(STORAGE_KEY);
    // By default, strict core mode is TRUE: ONLY Pets, Beauty, Lifestyle
    return item === null ? true : JSON.parse(item);
  } catch {
    return true;
  }
}

export function setStrictCoreNichesSetting(strict: boolean): void {
  try {
    safeStorage.setItem(STORAGE_KEY, JSON.stringify(strict));
    window.dispatchEvent(new CustomEvent('agency-niche-config-changed', { detail: { strict } }));
  } catch (err) {
    console.error('Error saving agency niche configuration:', err);
  }
}

export function getActiveAgencyNiches(): NicheInfo[] {
  const strict = getStrictCoreNichesSetting();
  if (strict) {
    return [
      NICHE_DEFINITIONS.Pets,
      NICHE_DEFINITIONS.Beauty,
      NICHE_DEFINITIONS.Lifestyle
    ];
  }

  // If strict is false, read custom / extended list
  try {
    const saved = safeStorage.getItem(EXTENDED_LIST_KEY);
    const names: string[] = saved ? JSON.parse(saved) : ['Pets', 'Beauty', 'Lifestyle', 'Fashion', 'Fitness', 'Tech', 'Gaming'];
    return names.map(name => {
      if (NICHE_DEFINITIONS[name]) return NICHE_DEFINITIONS[name];
      return {
        value: name,
        label: name,
        emoji: '🏷️',
        description: `${name} category`,
        isCore: false,
        colorClass: 'text-slate-300',
        bgClass: 'bg-slate-900/60',
        borderClass: 'border-slate-600'
      };
    });
  } catch {
    return [
      NICHE_DEFINITIONS.Pets,
      NICHE_DEFINITIONS.Beauty,
      NICHE_DEFINITIONS.Lifestyle
    ];
  }
}

export function useAgencyNiches() {
  const [strictCoreOnly, setStrictCoreOnlyState] = useState<boolean>(getStrictCoreNichesSetting);
  const [activeNiches, setActiveNiches] = useState<NicheInfo[]>(getActiveAgencyNiches);

  useEffect(() => {
    const handleUpdate = () => {
      const isStrict = getStrictCoreNichesSetting();
      setStrictCoreOnlyState(isStrict);
      setActiveNiches(getActiveAgencyNiches());
    };

    window.addEventListener('agency-niche-config-changed', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('agency-niche-config-changed', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, []);

  const toggleStrictCoreMode = (newVal: boolean) => {
    setStrictCoreNichesSetting(newVal);
    setStrictCoreOnlyState(newVal);
    setActiveNiches(getActiveAgencyNiches());
  };

  return {
    strictCoreOnly,
    setStrictCoreOnly: toggleStrictCoreMode,
    activeNiches,
    coreNiches: ['Pets', 'Beauty', 'Lifestyle'] as const,
    isNicheAllowed: (nicheName: string) => {
      if (!strictCoreOnly) return true;
      const normalized = (nicheName || '').toLowerCase();
      return (
        normalized.includes('pet') ||
        normalized.includes('beauty') ||
        normalized.includes('skincare') ||
        normalized.includes('cosmetic') ||
        normalized.includes('lifestyle')
      );
    }
  };
}
