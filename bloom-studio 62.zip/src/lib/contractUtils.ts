export interface ExpiryCalculation {
  days: number | null;
  label: string;
  badgeText: string;
  colorClass: string;
  dotColorClass: string;
  variant: 'red' | 'amber' | 'green' | 'gray';
  isExpiringSoon: boolean;
}

/**
 * Calculates the number of days remaining from the current date until contract expiry.
 * Color coding rules:
 * - Red for under 30 days (< 30 days, including expired <= 0)
 * - Amber for under 90 days (>= 30 and < 90 days)
 * - Green otherwise (>= 90 days)
 * - Gray if no date is provided or invalid
 */
export function getDaysUntilExpiry(endDateStr?: string): ExpiryCalculation {
  if (!endDateStr || endDateStr === 'N/A' || endDateStr.trim() === '') {
    return {
      days: null,
      label: 'No Expiry Set',
      badgeText: 'No Expiry',
      colorClass: 'bg-slate-800/80 text-slate-400 border border-slate-700/50',
      dotColorClass: 'bg-slate-500',
      variant: 'gray',
      isExpiringSoon: false
    };
  }

  const endParsed = new Date(endDateStr);
  if (isNaN(endParsed.getTime())) {
    return {
      days: null,
      label: 'Invalid Date',
      badgeText: 'Invalid Date',
      colorClass: 'bg-slate-800/80 text-slate-400 border border-slate-700/50',
      dotColorClass: 'bg-slate-500',
      variant: 'gray',
      isExpiringSoon: false
    };
  }

  const now = new Date();
  // Normalize both dates to calendar midnight for accurate integer day calculation
  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const targetMidnight = new Date(endParsed.getFullYear(), endParsed.getMonth(), endParsed.getDate()).getTime();

  const diffMs = targetMidnight - todayMidnight;
  const days = Math.round(diffMs / (1000 * 60 * 60 * 24));

  // Under 30 days (including expired/zero days) -> RED
  if (days < 0) {
    const absDays = Math.abs(days);
    return {
      days,
      label: `Expired (${absDays}d ago)`,
      badgeText: `${absDays}d Expired`,
      colorClass: 'bg-rose-950/80 text-rose-300 border border-rose-500/40 shadow-xs shadow-rose-950/50',
      dotColorClass: 'bg-rose-500 animate-pulse',
      variant: 'red',
      isExpiringSoon: true
    };
  }

  if (days === 0) {
    return {
      days,
      label: 'Expires Today (0 days)',
      badgeText: '0 days left',
      colorClass: 'bg-rose-950/80 text-rose-300 border border-rose-500/40 shadow-xs shadow-rose-950/50 font-bold',
      dotColorClass: 'bg-rose-400 animate-pulse',
      variant: 'red',
      isExpiringSoon: true
    };
  }

  if (days < 30) {
    return {
      days,
      label: `${days} ${days === 1 ? 'day' : 'days'} left`,
      badgeText: `${days}d left`,
      colorClass: 'bg-rose-950/80 text-rose-300 border border-rose-500/40 shadow-xs shadow-rose-950/50',
      dotColorClass: 'bg-rose-400 animate-pulse',
      variant: 'red',
      isExpiringSoon: true
    };
  }

  // Under 90 days (30 to 89 days) -> AMBER
  if (days < 90) {
    return {
      days,
      label: `${days} days left`,
      badgeText: `${days}d left`,
      colorClass: 'bg-amber-950/80 text-amber-300 border border-amber-500/40 shadow-xs shadow-amber-950/50',
      dotColorClass: 'bg-amber-400',
      variant: 'amber',
      isExpiringSoon: false
    };
  }

  // 90 days or more -> GREEN
  return {
    days,
    label: `${days} days left`,
    badgeText: `${days}d left`,
    colorClass: 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 shadow-xs shadow-emerald-950/50',
    dotColorClass: 'bg-emerald-400',
    variant: 'green',
    isExpiringSoon: false
  };
}
