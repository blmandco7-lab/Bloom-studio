import { collection, doc, getDocs, setDoc, deleteDoc, query, where, limit } from 'firebase/firestore';
import { db } from './firebase';

export interface BlacklistEntry {
  id: string;
  brand: string;
  reason: string;
  date?: string;
  blockedBy?: string;
  subagency?: string;
  tenantId?: string;
  createdAt?: string;
}

export interface BlacklistCheckResult {
  isBlacklisted: boolean;
  reason?: string;
  blockedBy?: string;
  item?: BlacklistEntry;
  matchedBrand?: string;
}

/**
 * Normalizes a brand name string for flexible, robust matching:
 * lowercase, trimmed, with consecutive whitespace and special symbols condensed.
 */
export function normalizeBrandName(name: string): string {
  if (!name) return '';
  return name
    .toLowerCase()
    .trim()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ');
}

/**
 * Synchronously checks if a given brand string matches any entry in a list of blacklist entries.
 */
export function isBrandBlacklistedSync(brandInput: string, blacklist: BlacklistEntry[]): BlacklistCheckResult {
  if (!brandInput || !blacklist || blacklist.length === 0) {
    return { isBlacklisted: false };
  }

  const cleanInput = brandInput.trim().toLowerCase();
  const normalizedInput = normalizeBrandName(brandInput);

  if (!normalizedInput) {
    return { isBlacklisted: false };
  }

  for (const item of blacklist) {
    if (!item.brand) continue;
    const itemRaw = item.brand.trim().toLowerCase();
    const itemNorm = normalizeBrandName(item.brand);

    // Exact string match (case-insensitive)
    if (cleanInput === itemRaw || normalizedInput === itemNorm) {
      return {
        isBlacklisted: true,
        reason: item.reason || 'Banned by Agency Management',
        blockedBy: item.blockedBy || 'Agency Director',
        item,
        matchedBrand: item.brand
      };
    }

    // Substring word match if significant length (avoid 1-2 char false positives)
    if (itemNorm.length >= 3 && (normalizedInput.includes(itemNorm) || itemNorm.includes(normalizedInput))) {
      return {
        isBlacklisted: true,
        reason: item.reason || 'Banned by Agency Management',
        blockedBy: item.blockedBy || 'Agency Director',
        item,
        matchedBrand: item.brand
      };
    }
  }

  return { isBlacklisted: false };
}

/**
 * Queries the Firestore 'global-blacklist' collection (and fallback 'studio-brand-blacklist')
 * to verify whether a brand is blocked before initiating contracts or creating deals.
 */
export async function checkBrandBlacklist(
  brandName: string,
  tenantId?: string
): Promise<BlacklistCheckResult> {
  if (!brandName || !brandName.trim()) {
    return { isBlacklisted: false };
  }

  const cleanBrand = brandName.trim();

  // 1. Try server-side API check first if available
  try {
    const res = await fetch('/api/global-blacklist/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ brand: cleanBrand, tenantId })
    });

    if (res.ok) {
      const data = await res.json();
      if (data.isBlacklisted) {
        return {
          isBlacklisted: true,
          reason: data.reason || 'Banned by Agency Director',
          blockedBy: data.blockedBy || 'Agency Director',
          item: data.item,
          matchedBrand: data.matchedBrand || cleanBrand
        };
      }
    }
  } catch (apiErr) {
    // Graceful client fallback to direct Firestore check
  }

  // 2. Direct Firestore query against 'global-blacklist'
  try {
    const colRef = collection(db, 'global-blacklist');
    const snap = await getDocs(colRef);
    const items: BlacklistEntry[] = [];
    
    snap.forEach((docSnap) => {
      const data = docSnap.data();
      if (data && data.brand) {
        items.push({ id: docSnap.id, ...data } as BlacklistEntry);
      }
    });

    // Also check studio-brand-blacklist for backward compatibility
    try {
      const legacyColRef = collection(db, 'studio-brand-blacklist');
      const legacySnap = await getDocs(legacyColRef);
      legacySnap.forEach((docSnap) => {
        const data = docSnap.data();
        if (data && data.brand && !items.some(x => x.id === docSnap.id)) {
          items.push({ id: docSnap.id, ...data } as BlacklistEntry);
        }
      });
    } catch (_) {}

    return isBrandBlacklistedSync(cleanBrand, items);
  } catch (fsErr) {
    console.warn('[blacklistService] Firestore query error:', fsErr);
    return { isBlacklisted: false };
  }
}

/**
 * Adds a brand to the Firestore 'global-blacklist' collection and syncs with the server API.
 */
export async function addBrandToGlobalBlacklist(entry: {
  brand: string;
  reason: string;
  blockedBy?: string;
  subagency?: string;
  tenantId?: string;
  authHeaders?: Record<string, string>;
}): Promise<BlacklistEntry> {
  const brandTrimmed = entry.brand.trim();
  const reasonTrimmed = entry.reason.trim();
  const id = 'bl_' + Date.now();
  const dateFormatted = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const createdAt = new Date().toISOString();

  const record: BlacklistEntry = {
    id,
    brand: brandTrimmed,
    reason: reasonTrimmed,
    date: dateFormatted,
    blockedBy: entry.blockedBy || 'Agency Director',
    subagency: entry.subagency || 'pod_main',
    tenantId: entry.tenantId || 'bloom_studio_default',
    createdAt
  };

  // 1. Direct Firestore write to 'global-blacklist'
  try {
    await setDoc(doc(db, 'global-blacklist', id), record, { merge: true });
  } catch (fsErr) {
    console.warn('[blacklistService] Failed direct write to global-blacklist in Firestore:', fsErr);
  }

  // 2. Also mirror to legacy 'studio-brand-blacklist'
  try {
    await setDoc(doc(db, 'studio-brand-blacklist', id), record, { merge: true });
  } catch (fsErr) {}

  // 3. Server-side API sync
  try {
    await fetch('/api/global-blacklist/add', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(entry.authHeaders || {})
      },
      body: JSON.stringify(record)
    });
  } catch (apiErr) {
    console.warn('[blacklistService] Server API sync warning:', apiErr);
  }

  return record;
}

/**
 * Removes a brand from the Firestore 'global-blacklist' collection and syncs with the server API.
 * Accepts either a blacklist record ID (e.g. 'bl_123') or the raw brand name (e.g. 'Nike Athletics').
 */
export async function removeBrandFromGlobalBlacklist(
  idOrBrand: string,
  authHeaders?: Record<string, string>
): Promise<boolean> {
  const target = (idOrBrand || '').trim();
  if (!target) return true;

  // 1. Direct Firestore delete from 'global-blacklist' by ID
  try {
    await deleteDoc(doc(db, 'global-blacklist', target));
  } catch (fsErr) {
    console.warn('[blacklistService] Direct delete by ID attempted:', fsErr);
  }

  // 2. Also query 'global-blacklist' by brand name if target is a brand name
  try {
    const q1 = query(collection(db, 'global-blacklist'), where('brand', '==', target));
    const snap1 = await getDocs(q1);
    for (const d of snap1.docs) {
      await deleteDoc(d.ref);
    }
  } catch (fsErr) {
    console.warn('[blacklistService] Query delete by brand attempted:', fsErr);
  }

  // 3. Also clean from legacy 'studio-brand-blacklist'
  try {
    await deleteDoc(doc(db, 'studio-brand-blacklist', target));
  } catch (fsErr) {}
  try {
    const q2 = query(collection(db, 'studio-brand-blacklist'), where('brand', '==', target));
    const snap2 = await getDocs(q2);
    for (const d of snap2.docs) {
      await deleteDoc(d.ref);
    }
  } catch (fsErr) {}

  // 4. Server-side API sync
  try {
    await fetch('/api/global-blacklist/remove', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(authHeaders || {})
      },
      body: JSON.stringify({ id: target, brand: target })
    });
  } catch (apiErr) {
    console.warn('[blacklistService] Server API sync warning:', apiErr);
  }

  return true;
}
