import { safeStorage } from '../utils/safeStorage';

/**
 * Deal Threshold Alert Utility
 * Threshold: Single deal budget exceeding $25,000 USD triggers a high-value contract alert for the Director.
 */

export const HIGH_VALUE_DEAL_THRESHOLD = 25000;
export const AGENCY_COMMISSION_RATE = 0.20; // 20% agency cut

export interface HighValueAlertPayload {
  dealId: string;
  brand: string;
  creator: string;
  budget: number;
  agencyCut: number;
  talentPayout: number;
  platform: string;
  stage: string;
  agent: string;
  title: string;
  detail: string;
  timestamp: string;
}

/**
 * Checks whether a budget or deal value exceeds or meets the high-value contract threshold ($25,000).
 */
export function isHighValueDeal(budgetOrValue: number | string | undefined | null): boolean {
  if (budgetOrValue === undefined || budgetOrValue === null) return false;
  const num = typeof budgetOrValue === 'number' 
    ? budgetOrValue 
    : parseFloat(String(budgetOrValue).replace(/[^0-9.-]+/g, ''));
  return !isNaN(num) && num >= HIGH_VALUE_DEAL_THRESHOLD;
}

/**
 * Parses numeric budget safely
 */
export function parseDealBudget(budgetOrValue: number | string | undefined | null): number {
  if (budgetOrValue === undefined || budgetOrValue === null) return 0;
  const num = typeof budgetOrValue === 'number' 
    ? budgetOrValue 
    : parseFloat(String(budgetOrValue).replace(/[^0-9.-]+/g, ''));
  return isNaN(num) ? 0 : num;
}

/**
 * Formats USD currency cleanly
 */
export function formatDealBudget(amount: number): string {
  return '$' + Math.round(amount).toLocaleString();
}

/**
 * Generates notification payload for a high-value deal exceeding $25,000
 */
export function createHighValueAlertPayload(deal: {
  id?: string;
  brand?: string;
  creator?: string;
  budget?: number | string;
  value?: number | string;
  platform?: string;
  stage?: string;
  agent?: string;
}): HighValueAlertPayload {
  const budgetNum = parseDealBudget(deal.budget ?? deal.value);
  const agencyCut = budgetNum * AGENCY_COMMISSION_RATE;
  const talentPayout = budgetNum - agencyCut;
  const brandName = deal.brand?.trim() || 'Brand Partner';
  const creatorName = deal.creator?.trim() || 'Assigned Talent';
  const platform = deal.platform?.trim() || 'Multi-platform';
  const dealId = deal.id || `deal_${Date.now()}`;

  const title = `💎 High-Value Contract Alert ($25,000+ Threshold)`;
  const detail = `Major deal detected: ${brandName} for ${creatorName} at ${formatDealBudget(budgetNum)} (${platform}). Agency 20% margin: ${formatDealBudget(agencyCut)}. Director executive sign-off & legal contract review required.`;

  return {
    dealId,
    brand: brandName,
    creator: creatorName,
    budget: budgetNum,
    agencyCut,
    talentPayout,
    platform,
    stage: deal.stage || 'Contracted',
    agent: deal.agent || 'Marcus Cole',
    title,
    detail,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };
}

const STORAGE_KEY = 'bloom_alerted_high_value_deal_ids';

/**
 * Retrieves set of deal IDs that have already triggered a threshold notification
 */
export function getAlertedDealIds(): Set<string> {
  if (typeof window === 'undefined') return new Set();
  try {
    const raw = safeStorage.getItem(STORAGE_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

/**
 * Marks a deal ID as alerted so duplicate toast spam is prevented
 */
export function markDealAsAlerted(dealId: string): void {
  if (typeof window === 'undefined' || !dealId) return;
  try {
    const set = getAlertedDealIds();
    set.add(String(dealId));
    safeStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(set)));
  } catch {
    // ignore
  }
}

/**
 * Checks if a specific deal has already triggered a threshold notification
 */
export function hasDealBeenAlerted(dealId: string): boolean {
  if (!dealId) return false;
  return getAlertedDealIds().has(String(dealId));
}
