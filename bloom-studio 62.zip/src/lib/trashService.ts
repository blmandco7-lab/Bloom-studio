import { doc, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from './firebase';
import { TrashItem } from '../types';
import { safeStorage } from '../utils/safeStorage';

const TRASH_COLLECTION = 'studio-trash-bin';

/**
 * Move a document to the 30-Day Safe Recovery Trash Bin
 * Safely stores a full snapshot of original data with metadata before deleting from active collection.
 */
export async function moveToTrash(
  collectionName: string,
  item: any,
  itemType: TrashItem['type'],
  currentUser?: any
): Promise<TrashItem> {
  const itemId = item.id || `item_${Date.now()}`;
  const itemName = item.name || item.brand || item.title || item.handle || item.brandName || item.agentName || 'Untitled Item';
  const subagency = item.subagency || currentUser?.subagency || currentUser?.pod || 'Bloom & Co';

  const trashItem: TrashItem = {
    id: itemId,
    type: itemType,
    name: itemName,
    deletedAt: new Date().toISOString(),
    originalCollection: collectionName,
    originalData: { ...item },
    subagency,
    deletedBy: currentUser?.name || currentUser?.email || 'User'
  };

  try {
    // 1. Write snapshot to studio-trash-bin
    await setDoc(doc(db, TRASH_COLLECTION, itemId), trashItem);
  } catch (err) {
    console.error(`[trashService] Failed to write to ${TRASH_COLLECTION}:`, err);
  }

  try {
    // 2. Delete original active document
    await deleteDoc(doc(db, collectionName, itemId));
  } catch (err) {
    console.error(`[trashService] Failed to delete original doc from ${collectionName}:`, err);
  }

  // 3. Local fallback persistence
  try {
    const existing = safeStorage.getItem('wl_trash_items');
    const list: TrashItem[] = existing ? JSON.parse(existing) : [];
    const updated = [trashItem, ...list.filter(i => i.id !== itemId)];
    safeStorage.setItem('wl_trash_items', JSON.stringify(updated));
  } catch (e) {
    // ignore local storage error
  }

  return trashItem;
}

/**
 * Restore an item from the Trash Bin back to its original active collection
 */
export async function restoreFromTrash(item: TrashItem): Promise<void> {
  if (!item || !item.originalCollection) return;

  try {
    // 1. Restore the document to original collection
    await setDoc(doc(db, item.originalCollection, item.id), item.originalData);
  } catch (err) {
    console.error(`[trashService] Failed to restore to ${item.originalCollection}:`, err);
    throw err;
  }

  try {
    // 2. Remove from trash bin
    await deleteDoc(doc(db, TRASH_COLLECTION, item.id));
  } catch (err) {
    console.error(`[trashService] Failed to delete from ${TRASH_COLLECTION}:`, err);
  }

  // 3. Sync local storage
  try {
    const existing = safeStorage.getItem('wl_trash_items');
    if (existing) {
      const list: TrashItem[] = JSON.parse(existing);
      const filtered = list.filter(i => i.id !== item.id);
      safeStorage.setItem('wl_trash_items', JSON.stringify(filtered));
    }
  } catch (e) {
    // ignore
  }
}

/**
 * Permanently purge an item from the Trash Bin
 */
export async function purgeFromTrash(itemId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, TRASH_COLLECTION, itemId));
  } catch (err) {
    console.error(`[trashService] Failed to purge ${itemId}:`, err);
  }

  try {
    const existing = safeStorage.getItem('wl_trash_items');
    if (existing) {
      const list: TrashItem[] = JSON.parse(existing);
      const filtered = list.filter(i => i.id !== itemId);
      safeStorage.setItem('wl_trash_items', JSON.stringify(filtered));
    }
  } catch (e) {
    // ignore
  }
}

/**
 * Purge all items from the Trash Bin
 */
export async function emptyTrashBin(items: TrashItem[]): Promise<void> {
  const promises = items.map(item => deleteDoc(doc(db, TRASH_COLLECTION, item.id)).catch(() => {}));
  await Promise.all(promises);

  try {
    safeStorage.removeItem('wl_trash_items');
  } catch (e) {
    // ignore
  }
}
