import { motion } from "motion/react";
import InboundLeadsScreen from "./components/InboundLeadsScreen";
import StripeDebitCardController from "./components/StripeDebitCardController";
import StripeExpenseNotificationHandler from "./components/StripeExpenseNotificationHandler";
import JustInTimeStripeCard from "./components/JustInTimeStripeCard";
import { UnifiedStripeCardsHub } from "./components/UnifiedStripeCardsHub";
import AffiliateSalesLedger from "./components/AffiliateSalesLedger";
import DigitalAssetProtectionSystem from "./components/DigitalAssetProtectionSystem";
import IrsTaxIntakeVault from "./components/IrsTaxIntakeVault";
import { UnifiedTaxHub } from "./components/UnifiedTaxHub";
import { UnifiedPayrollEscrowHub } from "./components/UnifiedPayrollEscrowHub";
import FinancialContractHub from "./components/FinancialContractHub";
import WorkflowMilestonesHub from "./components/WorkflowMilestonesHub";
import GrowthPlanningGenerator from "./components/GrowthPlanningGenerator";
import BrandReviewPortal from "./components/BrandReviewPortal";
import BrandCrm from "./components/BrandCrm";
import CopyrightAudioScanner from "./components/CopyrightAudioScanner";
import ExecutiveWrapUpReport from "./components/ExecutiveWrapUpReport";
import BrandContractUpsellManifest from "./components/BrandContractUpsellManifest";
import MonthlyRetainerQuotaLedgers from "./components/MonthlyRetainerQuotaLedgers";
import SystemStatusDashboard from "./components/SystemStatusDashboard";
import TalentRightsBuyoutManager from "./components/TalentRightsBuyoutManager";
import AnnouncementCenter from "./components/AnnouncementCenter";
import DealsAndRevenueHub from "./components/DealsAndRevenueHub";
import PartyDealAssignments from "./components/PartyDealAssignments";
import CreativeProductionSuite from "./components/CreativeProductionSuite";
import AiMediaStudio from "./components/AiMediaStudio";
import ManagerDashboardConsole from "./components/ManagerDashboardConsole";
import DirectorDashboardConsole from "./components/DirectorDashboardConsole";
import AgentManagementHub from "./components/AgentManagementHub";
import TalentHQ from "./components/TalentHQ";
import AgencyAcademyAndSOPs from "./components/AgencyAcademyAndSOPs";
import SignedAgreementsVault from "./components/SignedAgreementsVault";
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import CreatorPitchForwarder from "./components/CreatorPitchForwarder";
import { SyntheticMediaStudio } from "./pages/portal/synthetic-media-studio";
import { OneTimeCreatorPortal } from "./components/OneTimeCreatorPortal";
import { AgencyVSLHero } from "./components/AgencyVSLHero";
import { PublicContractSigningModal } from "./components/PublicContractSigningModal";
import { formatCsvRow, sanitizeCsvCell } from "./utils/security";
import { checkBrandBlacklist } from "./lib/blacklistService";
import { DEFAULT_CONTENT_REVIEWS } from "./data/defaultAgencyData";

import StripeProductionCardWidget from "./components/StripeProductionCardWidget";
import TalentComplianceDirectory from "./components/TalentComplianceDirectory";
import TalentOnboardingModule from "./components/TalentOnboardingModule";
import AgentOnboardingDashboard from "./components/AgentOnboardingDashboard";
import AgentManagerTraining from "./components/AgentManagerTraining";
import HistoricalCampaignVault from "./components/HistoricalCampaignVault";
import ClientReportCenter from "./components/ClientReportCenter";
import OwnerFinancialSummary from "./components/OwnerFinancialSummary";
import CreatorEarningsEscrowPanel from "./components/CreatorEarningsEscrowPanel";
import ManagerCommissionLog from "./components/ManagerCommissionLog";
import AccountingIntegrations from "./components/AccountingIntegrations";
import WaitlistDashboard from "./components/WaitlistDashboard";
import BotControlPanel from "./components/BotControlPanel";
import BrandPortalDashboard from "./components/BrandPortalDashboard";
import BrandPartnerJoinModal from "./components/BrandPartnerJoinModal";
import AgencyPublicInsights from "./components/AgencyPublicInsights";
import InvoiceGenerator from "./components/InvoiceGenerator";
import SystemAuditLogView from "./components/SystemAuditLogView";
import SiteUnderConstructionNotice from "./components/SiteUnderConstructionNotice";
import { EmergencyKillSwitchPanel, EmergencyKillSwitchNavButton } from "./components/EmergencyKillSwitchControls";
import {
  MaintenanceConfig,
  getStoredMaintenanceConfig,
  subscribeMaintenanceConfig,
  saveStoredMaintenanceConfig,
} from "./lib/maintenanceConfig";
import React, {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from "react";
import {
  BarChart3,
  Box,
  Inbox,
  LayoutDashboard,
  PackageCheck,
  Percent,
  Truck,
  UploadCloud,
  Users,
  Tag,
  Cpu,
  Receipt,
  FileText,
  Smartphone,
  Trash2,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Award,
  Landmark,
  Bell,
  HelpCircle,
  LogOut,
  Home,
  ArrowLeft,
  CheckCircle,
  CheckCircle2,
  RefreshCw,
  Plus,
  Trash,
  Menu,
  X,
  BookOpen,
  ExternalLink,
  Calendar,
  MapPin,
  DollarSign,
  TrendingUp,
  Award as AwardIcon,
  CheckSquare,
  MessageSquare,
  AlertTriangle,
  FileCheck,
  Activity,
  Clock,
  Settings,
  Sliders,
  Lock,
  Heart,
  Megaphone,
  Key,
  Layout,
  XCircle,
  Layers,
  Database,
  History,
  UserPlus,
  Upload,
  Sparkles,
  User,
  Download,
  FileSpreadsheet,
  BarChart2,
  PieChart,
  Filter,
  ArrowUpDown,
  ChevronDown,
  Eye,
  Send,
  Mail,
  Target,
  Zap,
  CreditCard,
  Briefcase,
  Share2,
  Check,
  Copy,
  Clapperboard,
  Film,
  CalendarDays,
  Music,
  Video,
  Package,
  Globe,
  MonitorPlay,
  FileSignature,
  Building2,
  LifeBuoy,
} from "lucide-react";
import { VeoVideoAnimator } from "./components/VeoVideoAnimator";
import { MusicGeneratorView } from "./components/MusicGeneratorView";
import {
  Role,
  Creator,
  Deal,
  Mission,
  Invoice,
  Contract,
  Bot,
  TrashItem,
  AppNotification,
  Referral,
  Thread,
  Message,
  KBArticle,
  TrainingGuide,
  ActiveCampaign,
  EscrowHold,
  ReviewItem,
  HiringSettings,
} from "./types";
import { prepareReviewItemForFirestore } from "./lib/ftcBot";
import { safeStorage } from "./utils/safeStorage";

// Moved cleanForFirestore and cleanUndefinedForFirestore to lib/firebase.ts
import { DEFAULT_KB_ARTICLES } from "./data/kbData";
import TrainingHub from "./components/TrainingHub";
import BotHub from "./components/BotHub";
import OutreachTracker from "./components/OutreachTracker";
import OpenMarketplace from "./components/OpenMarketplace";
import TrashBin from "./components/TrashBin";
import PhoneSimulator from "./components/PhoneSimulator";
import ChatSystem from "./components/ChatSystem";
import ContentReview from "./components/ContentReview";
import SubmitContent from "./components/SubmitContent";
import ContentUpload, { ContentSubmission } from "./components/ContentUpload";
import ContentLibrary from "./components/ContentLibrary";
import PerformanceAlerts from "./components/PerformanceAlerts";
import RepurposingLog from "./components/RepurposingLog";
import Analytics from "./components/Analytics";
import FtcCompliance from "./components/FtcCompliance";
import MatchOrPass from "./components/MatchOrPass";
import EnterpriseSecurity from "./components/EnterpriseSecurity";
import PrivacyComplianceCenter from "./components/PrivacyComplianceCenter";
import CashflowNotificationCenter from "./components/CashflowNotificationCenter";
import BrandSurveys from "./components/BrandSurveys";
import MediaKits from "./components/MediaKits";
import W9And1099Tracker from "./components/W9And1099Tracker";
import TermsOfServiceModal from "./components/TermsOfServiceModal";
import PrivacyPolicyModal from "./components/PrivacyPolicyModal";
import AccessibilityStatementModal from "./components/AccessibilityStatementModal";
import CastingCalls from "./components/CastingCalls";
import CastingDashboard from "./components/CastingDashboard";
import OperationBoard from "./components/OperationBoard";
import CreatorTwinDashboard from "./components/CreatorTwinDashboard";
import StockAvatarStudio from "./components/StockAvatarStudio";
import DailyBriefing from "./components/DailyBriefing";
import LandingPage from "./components/LandingPage";
import CampaignBoard, { Campaign } from "./components/CampaignBoard";
import { ProductionCalendar } from "./components/ProductionCalendar";
import { TalentAvailabilityCalendar } from "./components/TalentAvailabilityCalendar";
import { UnifiedCalendarHub } from "./components/UnifiedCalendarHub";
import RosterCharts from "./components/RosterCharts";
import ActivityChart from "./components/ActivityChart";
import RealtimeDealsSync from "./components/RealtimeDealsSync";
import DealSearchModal from "./components/DealSearchModal";
import CommandPalette from "./components/CommandPalette";
import AuditToolLoop from "./components/AuditToolLoop";
import DeleteConfirmationModal, {
  DeleteConfirmConfig,
} from "./components/DeleteConfirmationModal";
import { AutoSaveIndicator } from "./components/AutoSaveIndicator";
import { QuickActionsBar } from "./components/QuickActionsBar";
import { RosterHeatMap } from "./components/RosterHeatMap";
import QuickAddCreatorModal from "./components/QuickAddCreatorModal";
import CreatorRosterManager, {
  getSmartEngagementInfo,
  getNicheBadge,
  parseFollowerCount,
  parseEngagementRate,
} from "./components/CreatorRosterManager";
import { BatchActionsBar } from "./components/BatchActionsBar";
import PodInviteSignupPage from "./components/PodInviteSignupPage";
import { CreatorPortalView } from "./components/CreatorPortalView";
import { AgencyDebitCard } from "./components/AgencyDebitCard";
import DaysUntilExpiryBadge from "./components/DaysUntilExpiryBadge";
import RoleGuardedCampaignWorkspace from "./components/RoleGuardedCampaignWorkspace";
import ManagerCampaignView from "./components/ManagerCampaignView";
import CreativeBriefingStudio from "./components/CreativeBriefingStudio";
import GlobalPayrollSchedule, { DEFAULT_PAYROLL_CAMPAIGNS } from "./components/GlobalPayrollSchedule";
import PublicTalentShowcase from "./components/PublicTalentShowcase";
import FulfillmentHub from "./components/FulfillmentHub";
import DynamicCreatorMediaKit from "./components/DynamicCreatorMediaKit";
import PublicCreatorPortfolio from "./components/PublicCreatorPortfolio";
import { getPortfolioViewMode } from "./utils/portfolioViewMode";
import CreatorAssignedMissionsView from "./components/CreatorAssignedMissionsView";
import CreatorDealBriefsView from "./components/CreatorDealBriefsView";
import UgcCaseStudyGenerator from "./components/UgcCaseStudyGenerator";
import CreatorReferralNetwork from "./components/CreatorReferralNetwork";
import ProgrammaticSeoBlog from "./components/ProgrammaticSeoBlog";
import ShortFormVideoGenerator from "./components/ShortFormVideoGenerator";
import { getDaysUntilExpiry } from "./lib/contractUtils";
import RevenueIntelligenceChart from "./components/RevenueIntelligenceChart";
import ThresholdAlertManager from "./components/ThresholdAlertManager";
import { ContractsVault } from "./components/ContractsVault";
import { ExclusivityTracker } from "./components/ExclusivityTracker";
import LiveBotActivityLog from "./components/LiveBotActivityLog";
import {
  useAgencyNiches,
  setStrictCoreNichesSetting,
  getStrictCoreNichesSetting,
  CORE_AGENCY_NICHES,
  NICHE_DEFINITIONS,
} from "./lib/nicheConfig";
import {
  HIGH_VALUE_DEAL_THRESHOLD,
  isHighValueDeal,
  parseDealBudget,
  formatDealBudget,
  createHighValueAlertPayload,
  markDealAsAlerted,
  hasDealBeenAlerted,
} from "./lib/dealThresholdAlert";
import { isAllowedToMessage } from "./lib/messagingRules";
import {
  AnnouncementsModal,
  AnnouncementItem,
} from "./components/AnnouncementsModal";
import { DirectMessageLookupModal } from "./components/DirectMessageLookupModal";
import { MassBroadcastModal } from "./components/MassBroadcastModal";

const iconMap: Record<string, React.ComponentType<any>> = {
  Users,
  Tag,
  Cpu,
  Receipt,
  FileText,
  Smartphone,
  Trash2,
  Search,
  ShieldAlert,
  ShieldCheck,
  Award,
  Landmark,
  Bell,
  HelpCircle,
  LogOut,
  CheckCircle,
  RefreshCw,
  Plus,
  Trash,
  Menu,
  X,
  BookOpen,
  ExternalLink,
  Calendar,
  MapPin,
  DollarSign,
  TrendingUp,
  AwardIcon,
  CheckSquare,
  MessageSquare,
  AlertTriangle,
  FileCheck,
  Activity,
  Clock,
  Settings,
  Sliders,
  Lock,
  Heart,
  Megaphone,
  Key,
  Layout,
  XCircle,
  Layers,
  Database,
  History,
  UserPlus,
  Upload,
  Sparkles,
  Clapperboard,
  Music,
  Film,
  CalendarDays,
  CreditCard,
  Package,
  Building2,
};

import {
  db,
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  or,
  orderBy,
  backfillStudioCollectionsSubagency,
  subscribeTenantCollection,
  saveTenantDocument,
  deleteTenantDocument,
  syncEntireTenantCollection,
  subscribeTenantConfig,
  saveTenantConfigInFirestore,
  createTenantInFirestore,
  updateTenantInFirestore,
  deleteTenantInFirestore,
  subscribeAllTenants,
  auth,
  getOrCreateUserProfile,
  logoutUser,
  signInWithGoogle,
  handleAuthRedirectResult,
  purgeLegacySeedDataFromFirestore,
  migrateCreatorsToStudioCreators,
  backfillStudioCollectionsSubagency as runSubagencyBackfill,
  getAuthToken,
  getDirectSessionToken,
  cleanForFirestore,
  cleanUndefinedForFirestore,
} from "./lib/firebase";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";

// --- Newly wired screens: these 4 components had no import at all yet ---
import CreatorPortalDashboard from "./components/CreatorPortalDashboard";
import CreatorSampleFulfillmentTracker from "./components/CreatorSampleFulfillmentTracker";
import CreatorProductSamplesInventory from "./components/CreatorProductSamplesInventory";
import KnowledgeBase from "./components/KnowledgeBase";
import PodConfigurationDashboard from "./components/PodConfigurationDashboard";
import AgencySignupForm from "./components/AgencySignupForm";
import OpenMissionsWorkspace from "./components/OpenMissionsWorkspace";
import DirectorDelegationControls from "./components/DirectorDelegationControls";
import WorkPodSelector from "./components/WorkPodSelector";
import { moveToTrash } from "./lib/trashService";

// Moved to lib/firebase.ts

export const DEFAULT_LANDING_SCREEN_PER_ROLE: Record<string, string> = {
  director: "briefing",
  agentmgr: "roster",
  agent: "campaign-board",
  brand: "briefing",
  creator: "creator-dash",
  contractor: "one-time-contractor",
  subagency: "roster",
  agency: "roster",
  coordinator: "briefing",
};

export const ALLOWED_SCREENS_PER_ROLE: Record<string, string[]> = {
  director: [
    "one-time-contractor",
    "client-reports",
    "brand-reports",
    "cashflow-alerts",
    "agency-insights",
    "public-insights",
    "manager-campaign",
    "creator-portal",
    "casting-dashboard",
    "pod-invite",
    "briefing",
    "pod-configuration",
    "system-audit-log",
    "director-dash",
    "creator-dash",
    "creator-payouts",
    "announcement-center",
    "campaign-workspace",
    "audit-tool-loop",
    "enterprise-security",
    "privacy-compliance",
    "notifications",
    "roster",
    "talent-hq",
    "inbound-leads",
    "public-portfolio",
    "talent-showcase",
    "match-or-pass",
    "media-kits",
    "daps-shield",
    
    "calendar",
    "availability-calendar",
    "casting",
    "missions",
    "ugc-case-study",
    "creator-referral",
    "pitch-forwarder",
    "exclusivity-tracker",
    "campaign-board",
    "open-marketplace",
    "creative-production-suite",
    "creative-briefing",
    "unified-calendar",
    "fulfillment-hub",
    "creator-financials",
    "content-review",
    "submit-content",
    "content-library",
    "ftc-compliance",
    "performance-alerts",
    "repurposing-log",
    "analytics",
    "stripe-debit-controller",
    "stripe-expense-handler",
    "affiliate-sales",
    "irs-tax-vault",
    "w9-1099-tracker",
    "deals-revenue-hub",
    "commission",
    "party-deal-assignments",
    "payroll-schedule",
    "invoices",
    "contracts",
    "signed-agreements-vault",
    "signed-agreements",
    "brand-crm",
    "retainer-quota-ledgers",
    "director-delegation",
    "financial-contract-hub",
    "brand-review-portal",
    "brand-review",
    "workflow-milestones-hub",
    "copyright-scanner",
    "executive-wrapup",
    "upsell-manifest",
    "rights-buyout",
    "system-status",
    "stock-avatar-studio",
    "growth-generator",
    "growth",
    "seo-blog",
    "outreach",
    "waitlist",
    "bot-control",
    "bot-hub",
    "chat-system",
    "agency-academy-sop",
    "training",
    "kb",
    "procedures",
    "agent-management-hub",
    "agent-onboard",
    "onboarding",
    "ai-media-studio",
    "synthetic-media-studio",
    "agency-vsl-hero",
    "creator-ai-twin",
    "animate-video",
    "generate-music",
    "agency-setup",
    "agency-branding",
    "integrations",
    "access-codes",
    "user-accounts",
    "trash-bin",
    "audit-trail",
    "activity-log",
    "activity-chart",
    "compliance-directory",
    "brand-briefing",
    "brand-portal",
    "brand-dash",
    "brand-messages",
    "brand-billing",
    "brand-vault",
    "brand-surveys",
    "brand-support",
    "synthetic-media-studio",
    "agency-vsl-hero",
  ],
  agency: [
    "stock-avatar-studio",
    "briefing",
    "roster",
    "talent-hq",
    "waitlist",
    "deals-revenue-hub",
    "activity-chart",
    "party-deal-assignments",
    "match-or-pass",
    "campaign-workspace",
    "open-marketplace",
    "creative-briefing",
    "payroll-schedule",
    "talent-showcase",
    "public-portfolio",
    "contracts",
    "invoices",
    "w9-1099-tracker",
    "irs-tax-vault",
    "stripe-debit-controller",
    "stripe-expense-handler",
    "affiliate-sales",
    "daps-shield",
    "ftc-compliance",
    "onboarding",
    "chat-system",
    "kb",
    "training",
    "procedures",
    "campaign-board",
    "unified-calendar",
    "content-review",
    "fulfillment-hub",
    "media-kits",
    "agent-onboard",
    "commission",
    
    "access-codes",
    "user-accounts",
    "agency-branding",
    "audit-tool-loop",
    "copyright-scanner",
    "executive-wrapup",
    "upsell-manifest",
    "rights-buyout",
    "retainer-quota-ledgers",
    "system-status",
    "financial-contract-hub",
    "workflow-milestones-hub",
    "brand-review-portal",
    "brand-review",
    "announcement-center",
    "creative-production-suite",
    "ai-media-studio",
    "synthetic-media-studio",
    "agency-vsl-hero",
    "creator-ai-twin",
    "agency-academy-sop",
    "synthetic-media-studio",
    "agency-vsl-hero",
    "brand-dash",
    "brand-messages",
    "brand-billing",
    "brand-vault",
    "brand-surveys",
    "brand-support",
  ],
  subagency: [
    "stock-avatar-studio",
    "briefing",
    "roster",
    "talent-hq",
    "waitlist",
    "activity-chart",
    "open-marketplace",
    "party-deal-assignments",
    "match-or-pass",
    "campaign-workspace",
    "creative-briefing",
    "talent-showcase",
    "public-portfolio",
    "contracts",
    "missions",
    "ftc-compliance",
    "onboarding",
    "chat-system",
    "kb",
    "training",
    "procedures",
    "campaign-board",
    "unified-calendar",
    "content-review",
    "fulfillment-hub",
    "media-kits",
    
    "audit-tool-loop",
    "copyright-scanner",
    "executive-wrapup",
    "upsell-manifest",
    "rights-buyout",
    "retainer-quota-ledgers",
    "system-status",
    "financial-contract-hub",
    "workflow-milestones-hub",
    "brand-review-portal",
    "brand-review",
    "announcement-center",
    "creative-production-suite",
    "ai-media-studio",
    "synthetic-media-studio",
    "agency-vsl-hero",
    "creator-ai-twin",
    "agent-management-hub",
    "agency-academy-sop",
    "daps-shield",
    "synthetic-media-studio",
    "agency-vsl-hero",
    "brand-dash",
    "brand-messages",
    "brand-billing",
    "brand-vault",
    "brand-surveys",
    "brand-support",
  ],
  agent: [
    "briefing",
    "roster",
    "talent-hq",
    "public-portfolio",
    "talent-showcase",
    "match-or-pass",
    "media-kits",
    "daps-shield",
    "announcement-center",
    "trash-bin",
    "audit-trail",
    "casting",
    "missions",
    "exclusivity-tracker",
    "campaign-board",
    "unified-calendar",
    "creator-inventory",
    "creator-briefs",
    "content-review",
    "fulfillment-hub",
    "ftc-compliance",
    "submit-content",
    "content-library",
    "creative-briefing",
    "creative-production-suite",
    "contracts",
    "open-marketplace",
    "party-deal-assignments",
    "chat-system",
    "kb",
    "training",
    "onboarding",
    "agent-onboard",
    "outreach",
  ],
  agentmgr: [
    "creative-production-suite",
    "one-time-contractor",
    "briefing",
    "roster",
    "talent-hq",
    "inbound-leads",
    "waitlist",
    "campaign-board",
    "unified-calendar",
    "content-review",
    "fulfillment-hub",
    "match-or-pass",
    "campaign-workspace",
    "creative-briefing",
    "creator-briefs",
    "talent-showcase",
    "public-portfolio",
    "media-kits",
    "daps-shield",
    "ftc-compliance",
    "missions",
    "agent-onboard",
    "party-deal-assignments",
    "chat-system",
    "announcement-center",
    "kb",
    "training",
    "procedures",
    "onboarding",
    "agency-insights",
    "activity-chart",
    "trash-bin",
    "audit-trail",
    "agent-management-hub",
    "exclusivity-tracker",
    "performance-alerts",
    "repurposing-log",
    "brand-crm",
    "outreach",
    "activity-log",
    "copyright-scanner",
    "casting",
    "workflow-milestones-hub",
    "retainer-quota-ledgers",
    "executive-wrapup",
    "commission",
    "brand-review-portal",
    "brand-review",
    "agency-vsl-hero",
    "brand-dash",
    "brand-messages",
    "brand-support",
  ],
  coordinator: [
    "briefing",
    "roster",
    "campaign-board",
    "unified-calendar",
    "announcement-center",
    "trash-bin",
    "audit-trail",
    "content-review",
    "fulfillment-hub",
    "submit-content",
    "my-content",
    "creative-briefing",
    "creator-briefs",
    "party-deal-assignments",
    "chat-system",
    "ftc-compliance",
    "kb",
    "training",
    "procedures",
    "media-kits",
    "daps-shield",
    "content-library",
    "creative-production-suite",
    "workflow-milestones-hub",
    "contracts",
    "missions",
    "brand-support",
    "talent-showcase",
    "public-portfolio",
    "agency-vsl-hero",
  ],
  creator: [
    "creator-dash",
    "creator-portal",
    "creator-payouts",
    "missions",
    "fulfillment-hub",
    "stripe-debit-controller",
    "irs-tax-vault",
    "chat-system",
    "agency-academy-sop",
    "stripe-expense-handler",
    "affiliate-sales",
    "animate-video",
    "generate-music",
    "briefing",
    "training",
    "kb",
    "media-kits",
    "deal-pipeline",
    "payroll-schedule",
    "submit-content",
    "onboarding",
    "announcement-center",
    "ai-media-studio",
    "synthetic-media-studio",
    "creator-ai-twin",
    "unified-calendar",
    "procedures",
    "casting",
    "contracts",
    "open-marketplace",
    "creator-briefs",
    "public-portfolio",
    "talent-showcase",
    "agency-vsl-hero",
    "creator-referral",
    "pitch-forwarder",
    "casting-dashboard",
    "one-time-contractor",
  ],
  contractor: [
    "one-time-contractor",
    "briefing",
    "creator-dash",
    "submit-content",
    "fulfillment-hub",
    "chat-system",
    "irs-tax-vault",
    "w9-1099-tracker",
    "contracts",
    "kb",
    "training",
    "public-portfolio",
    "talent-showcase",
    "agency-vsl-hero",
  ],
  brand: [
    "client-reports",
    "brand-reports",
    "public-insights",
    "briefing",
    "brand-dash",
    "brand-messages",
    "brand-vault",
    "brand-surveys",
    "brand-support",
    "chat-system",
    "kb",
    "training",
    "public-portfolio",
    "talent-showcase",
    "agency-vsl-hero",
    "contracts",
    "analytics",
    "match-or-pass",
    "brand-review-portal",
    "brand-review"
  ],
  none: [
    "briefing",
    "agency-vsl-hero",
    "talent-showcase",
    "public-portfolio",
    "pod-invite-signup"
  ],
};

const INITIAL_NAV_CATEGORIES = [
  {
    title: "CREATOR WORKSPACE",
    items: [
      {
        id: "creator-dash",
        label: "Creator Dashboard",
        iconName: "Eye",
        icon: Eye,
        isActive: true,
      },
      {
        id: "media-kits",
        label: "Profile Overview & Media Kit",
        iconName: "User",
        icon: User,
        isActive: true,
      },
      {
        id: "missions",
        label: "My Active Missions",
        iconName: "CheckSquare",
        icon: CheckSquare,
        isActive: true,
      },
      {
        id: "fulfillment-hub",
        label: "Sample Locker & Fulfillment",
        iconName: "PackageCheck",
        icon: PackageCheck,
        isActive: true,
      },
      {
        id: "creator-payouts",
        label: "Earnings & Escrow Payouts",
        iconName: "DollarSign",
        icon: DollarSign,
        isActive: true,
      },
      {
        id: "stripe-debit-controller",
        label: "Production Debit Card (JIT)",
        iconName: "CreditCard",
        icon: CreditCard,
        isActive: false,
      },
      {
        id: "irs-tax-vault",
        label: "Tax & W-9 Vault",
        iconName: "Landmark",
        icon: Landmark,
        isActive: true,
      },
      {
        id: "chat-system",
        label: "Direct Messages",
        iconName: "MessageSquare",
        icon: MessageSquare,
        isActive: true,
      },
      {
        id: "agency-academy-sop",
        label: "Agency Academy & SOPs",
        iconName: "BookOpen",
        icon: BookOpen,
        isActive: true,
      },
    ],
  },
  {
    title: "EXECUTIVE INTELLIGENCE",
    items: [
      {
        id: "agency-insights",
        label: "Agency Insights",
        iconName: "BarChart3",
        icon: BarChart3,
        isActive: true,
      },
      {
        id: "activity-chart",
        label: "Live Activity Charts",
        iconName: "Activity",
        icon: Activity,
        isActive: true,
      },
    ],
  },
  {
    title: "COMMAND & HUBS",
    items: [
      {
        id: "briefing",
        label: "Daily Briefing",
        iconName: "Clock",
        icon: Clock,
        isActive: true,
      },
      {
        id: "agency-vsl-hero",
        label: "Agency Pitch (VSL)",
        iconName: "MonitorPlay",
        icon: MonitorPlay,
        isActive: true,
      },
      {
        id: "pod-configuration",
        label: "Pod Configuration",
        iconName: "Building2",
        icon: Building2,
        isActive: true,
      },
      {
        id: "system-audit-log",
        label: "System Audit Log",
        iconName: "Database",
        icon: Database,
        isActive: true,
      },
      {
        id: "director-dash",
        label: "Agency Revenue & Pay Command",
        iconName: "Cpu",
        icon: Cpu,
        isActive: true,
      },
      {
        id: "campaign-workspace",
        label: "Campaign Workspace",
        iconName: "Layers",
        icon: Layers,
        isActive: true,
      },
      {
        id: "audit-tool-loop",
        label: "Audit Watchdog Loop",
        iconName: "ShieldAlert",
        icon: ShieldAlert,
        isActive: true,
      },
      {
        id: "enterprise-security",
        label: "Enterprise Security & Audit",
        iconName: "Shield",
        icon: Shield,
        isActive: true,
      },
      {
        id: "privacy-compliance",
        label: "Privacy & Compliance (GDPR)",
        iconName: "FileCheck",
        icon: FileCheck,
        isActive: true,
      },
      {
        id: "notifications",
        label: "Notifications",
        iconName: "Bell",
        icon: Bell,
        isActive: true,
      },
    ],
  },
  {
    title: "TALENT MANAGEMENT",
    items: [
      {
        id: "roster",
        label: "Creator Roster",
        iconName: "Users",
        icon: Users,
        isActive: true,
      },
      {
        id: "inbound-leads",
        label: "Inbound Leads & Inquiries",
        iconName: "Inbox",
        icon: Inbox,
        isActive: true,
      },
      {
        id: "public-portfolio",
        label: "Public Creator Portfolio",
        iconName: "Globe",
        icon: Globe,
        isActive: true,
      },
      {
        id: "talent-showcase",
        label: "Talent Showcase",
        iconName: "Sparkles",
        icon: Sparkles,
        isActive: true,
      },
      {
        id: "match-or-pass",
        label: "Match or Pass",
        iconName: "Sparkles",
        icon: Sparkles,
        isActive: true,
      },
      {
        id: "media-kits",
        label: "Dynamic Media Kits",
        iconName: "Layout",
        icon: Layout,
        isActive: true,
      },
      {
        id: "daps-shield",
        label: "Digital Asset Shield (DAPS)",
        iconName: "ShieldCheck",
        icon: ShieldCheck,
        isActive: true,
      },
      {
        id: "casting",
        label: "Casting Calls & Auditions",
        iconName: "Megaphone",
        icon: Megaphone,
        isActive: true,
      },
      {
        id: "missions",
        label: "My Missions & Tasks",
        iconName: "CheckSquare",
        icon: CheckSquare,
        isActive: true,
      },
      {
        id: "ugc-case-study",
        label: "UGC Case Studies",
        iconName: "FileText",
        icon: FileText,
        isActive: true,
      },
      {
        id: "creator-referral",
        label: "Creator Referral Program",
        iconName: "Share2",
        icon: Share2,
        isActive: true,
      },
      {
        id: "pitch-forwarder",
        label: "Brand Pitch Forwarder",
        iconName: "Send",
        icon: Send,
        isActive: true,
      },
      {
        id: "exclusivity-tracker",
        label: "Exclusivity & Conflict Tracker",
        iconName: "ShieldAlert",
        icon: ShieldAlert,
        isActive: true,
      },
      {
        id: "one-time-contractor",
        label: "Contractor Standby Bench",
        iconName: "CheckSquare",
        icon: CheckSquare,
        isActive: true,
      },
    ],
  },
  {
    title: "CAMPAIGNS & DELIVERABLES",
    items: [
      {
        id: "campaign-board",
        label: "Campaign Board",
        iconName: "LayoutDashboard",
        icon: LayoutDashboard,
        isActive: true,
      },
      {
        id: "open-marketplace",
        label: "Open Marketplace",
        iconName: "Megaphone",
        icon: Megaphone,
        isActive: true,
      },
      {
        id: "creative-production-suite",
        label: "Creative Production Suite",
        iconName: "Video",
        icon: Video,
        isActive: true,
      },
      {
        id: "unified-calendar",
        label: "Unified Calendar Hub",
        iconName: "Calendar",
        icon: Calendar,
        isActive: true,
      },
      {
        id: "fulfillment-hub",
        label: "Fulfillment & Sample Hub",
        iconName: "PackageCheck",
        icon: PackageCheck,
        isActive: true,
      },
      {
        id: "creator-briefs",
        label: "Creator Briefs",
        iconName: "FileText",
        icon: FileText,
        isActive: true,
      },
      {
        id: "content-review",
        label: "Content Review & QA",
        iconName: "CheckCircle",
        icon: CheckCircle,
        isActive: true,
      },
      {
        id: "submit-content",
        label: "Submitted Content",
        iconName: "UploadCloud",
        icon: UploadCloud,
        isActive: true,
      },
      {
        id: "content-library",
        label: "Master Content Library",
        iconName: "Layers",
        icon: Layers,
        isActive: true,
      },
      {
        id: "ftc-compliance",
        label: "FTC Compliance Audit",
        iconName: "ShieldCheck",
        icon: ShieldCheck,
        isActive: true,
      },
      {
        id: "performance-alerts",
        label: "Performance Alerts",
        iconName: "AlertTriangle",
        icon: AlertTriangle,
        isActive: true,
      },
      {
        id: "repurposing-log",
        label: "Repurposing Log",
        iconName: "RefreshCw",
        icon: RefreshCw,
        isActive: true,
      },
      {
        id: "analytics",
        label: "Campaign Analytics",
        iconName: "BarChart3",
        icon: BarChart3,
        isActive: true,
      },
    ],
  },
  {
    title: "DEALS & MY EARNINGS",
    items: [
      {
        id: "deals-revenue-hub",
        label: "Deals & Revenue Hub",
        iconName: "DollarSign",
        icon: DollarSign,
        isActive: true,
      },
      {
        id: "invoices",
        label: "Invoices & Billing Workspace",
        iconName: "Receipt",
        icon: Receipt,
        isActive: true,
      },
      {
        id: "stripe-debit-controller",
        label: "Stripe Cards & JIT Issuing Hub",
        iconName: "CreditCard",
        icon: CreditCard,
        isActive: false,
      },
      {
        id: "affiliate-sales",
        label: "Affiliate Sales Ledgers",
        iconName: "TrendingUp",
        icon: TrendingUp,
        isActive: true,
      },
      {
        id: "irs-tax-vault",
        label: "Official Tax Vault & W-9/1099 Hub",
        iconName: "Landmark",
        icon: Landmark,
        isActive: true,
      },
      {
        id: "commission",
        label: "Commission Split Engine",
        iconName: "Percent",
        icon: Percent,
        isActive: true,
      },
      {
        id: "cashflow-alerts",
        label: "Cashflow Alerts",
        iconName: "AlertTriangle",
        icon: AlertTriangle,
        isActive: true,
      },
      {
        id: "party-deal-assignments",
        label: "My Deal Assignments",
        iconName: "FileSignature",
        icon: FileSignature,
        isActive: true,
      },
      {
        id: "payroll-schedule",
        label: "Global Payroll & Escrow Hub",
        iconName: "Receipt",
        icon: Receipt,
        isActive: true,
      },
      {
        id: "contracts",
        label: "Contract Vault & E-Sign",
        iconName: "FileCheck",
        icon: FileCheck,
        isActive: true,
      },
      {
        id: "signed-agreements-vault",
        label: "Signed Agreements Vault",
        iconName: "ShieldCheck",
        icon: ShieldCheck,
        isActive: true,
      },
      {
        id: "brand-crm",
        label: "Brand CRM",
        iconName: "Users",
        icon: Users,
        isActive: true,
      },
      {
        id: "brand-blacklist",
        label: "Agency Brand Blacklist",
        iconName: "ShieldAlert",
        icon: ShieldAlert,
        isActive: true,
      },
      {
        id: "retainer-quota-ledgers",
        label: "Monthly Retainer Ledger",
        iconName: "Layers",
        icon: Layers,
        isActive: true,
      },
    ],
  },
  {
    title: "BRAND PARTNER ACCESS",
    items: [
      {
        id: "brand-messages",
        label: "Secure Messaging",
        iconName: "MessageSquare",
        icon: MessageSquare,
        isActive: true,
      },
      {
        id: "brand-review-portal",
        label: "Brand Review Portal",
        iconName: "CheckCircle",
        icon: CheckCircle,
        isActive: true,
      },
      {
        id: "brand-support",
        label: "Support Desk",
        iconName: "LifeBuoy",
        icon: LifeBuoy,
        isActive: true,
      },
    ],
  },
  {
    title: "DIRECTOR CONTROLS & AUTOMATION",
    items: [
      {
        id: "client-reports",
        label: "Client Report Center",
        iconName: "BarChart2",
        icon: BarChart2,
        isActive: true,
      },
      {
        id: "director-delegation",
        label: "Director Delegation",
        iconName: "ShieldAlert",
        icon: ShieldAlert,
        isActive: true,
      },
      {
        id: "financial-contract-hub",
        label: "Financial & Contract Automation",
        iconName: "Landmark",
        icon: Landmark,
        isActive: true,
      },
      {
        id: "workflow-milestones-hub",
        label: "Workflow & Milestones",
        iconName: "Clock",
        icon: Clock,
        isActive: true,
      },
      {
        id: "copyright-scanner",
        label: "AI Copyright & Sound Scanner",
        iconName: "ShieldCheck",
        icon: ShieldCheck,
        isActive: true,
      },
      {
        id: "executive-wrapup",
        label: "Corporate Wrap-Up Report",
        iconName: "FileText",
        icon: FileText,
        isActive: true,
      },
      {
        id: "upsell-manifest",
        label: "Contract Upsell Manifest",
        iconName: "DollarSign",
        icon: DollarSign,
        isActive: true,
      },
      {
        id: "rights-buyout",
        label: "Flat-Fee Copyright Buyouts",
        iconName: "Lock",
        icon: Lock,
        isActive: true,
      },
      {
        id: "system-status",
        label: "System Status & Backups",
        iconName: "Cpu",
        icon: Cpu,
        isActive: true,
      },
    ],
  },
  {
    title: "MARKETING & GROWTH",
    items: [
      {
        id: "stock-avatar-studio",
        label: "Stock Avatar Studio",
        iconName: "MonitorPlay",
        icon: MonitorPlay,
        isActive: true,
      },
      {
        id: "growth",
        label: "Growth Planning Engine",
        iconName: "TrendingUp",
        icon: TrendingUp,
        isActive: true,
      },
      {
        id: "seo-blog",
        label: "Programmatic SEO Engine",
        iconName: "Globe",
        icon: Globe,
        isActive: true,
      },
      {
        id: "outreach",
        label: "Outreach Tracker",
        iconName: "TrendingUp",
        icon: TrendingUp,
        isActive: true,
      },
      {
        id: "waitlist",
        label: "Waitlist",
        iconName: "Clock",
        icon: Clock,
        isActive: true,
      },
      {
        id: "bot-hub",
        label: "Bot Hub",
        iconName: "Cpu",
        icon: Cpu,
        isActive: true,
      },
    ],
  },
  {
    title: "COMMUNICATION & LEARNING",
    items: [
      {
        id: "chat-system",
        label: "Direct Messages (1-on-1)",
        iconName: "MessageSquare",
        icon: MessageSquare,
        isActive: true,
      },
      {
        id: "announcement-center",
        label: "Creator Announcements",
        iconName: "Bell",
        icon: Bell,
        isActive: true,
      },
      {
        id: "agency-academy-sop",
        label: "Agency Academy & SOPs",
        iconName: "BookOpen",
        icon: BookOpen,
        isActive: true,
      },
      {
        id: "training",
        label: "Training Hub",
        iconName: "Award",
        icon: Award,
        isActive: true,
      },
      {
        id: "kb",
        label: "Knowledge Base & Wiki",
        iconName: "BookOpen",
        icon: BookOpen,
        isActive: true,
      },
      {
        id: "brand-support",
        label: "Support Desk & Brand Tickets",
        iconName: "LifeBuoy",
        icon: LifeBuoy,
        isActive: true,
      },
      {
        id: "agent-management-hub",
        label: "User & Staff Management",
        iconName: "Users",
        icon: Users,
        isActive: true,
      },
      {
        id: "onboarding",
        label: "Agent & Staff Onboarding",
        iconName: "UserPlus",
        icon: UserPlus,
        isActive: true,
      },
    ],
  },
  {
    title: "AI MEDIA STUDIO",
    items: [
      {
        id: "ai-media-studio",
        label: "AI Media Studio",
        iconName: "Sparkles",
        icon: Sparkles,
        isActive: true,
      },
      {
        id: "creator-ai-twin",
        label: "My Verified AI Twin",
        iconName: "Sparkles",
        icon: Sparkles,
        isActive: true,
      },
      {
        id: "animate-video",
        label: "Animate Images into Video",
        iconName: "Film",
        icon: Film,
        isActive: true,
      },
      {
        id: "generate-music",
        label: "AI Music Studio",
        iconName: "Music",
        icon: Music,
        isActive: true,
      },
      {
        id: "synthetic-media-studio",
        label: "Synthetic Media Lab",
        iconName: "Zap",
        icon: Zap,
        isActive: true,
      },
    ],
  },
  {
    title: "RESOURCES & SYSTEM",
    items: [
      {
        id: "creator-dash",
        label: "Creator Dashboard Mirror",
        iconName: "Eye",
        icon: Eye,
        isActive: true,
      },
      {
        id: "agency-setup",
        label: "Settings, Branding & Permissions",
        iconName: "Settings",
        icon: Settings,
        isActive: true,
      },
      {
        id: "integrations",
        label: "Integrations",
        iconName: "Sliders",
        icon: Sliders,
        isActive: true,
      },
      {
        id: "access-codes",
        label: "Access Codes",
        iconName: "Key",
        icon: Key,
        isActive: true,
      },
      {
        id: "user-accounts",
        label: "User Accounts",
        iconName: "Users",
        icon: Users,
        isActive: true,
      },
      {
        id: "trash-bin",
        label: "Recoup Trash (30-Day Recovery)",
        iconName: "Trash2",
        icon: Trash2,
        isActive: true,
      },
      {
        id: "audit-trail",
        label: "Audit Trail",
        iconName: "FileCheck",
        icon: FileCheck,
        isActive: true,
      },
      {
        id: "activity-log",
        label: "Activity Log",
        iconName: "History",
        icon: History,
        isActive: true,
      },
      {
        id: "compliance-directory",
        label: "Legal & Compliance Directory",
        iconName: "ShieldCheck",
        icon: ShieldCheck,
        isActive: true,
      },
    ],
  },
];

interface ActivityLogItem {
  id: string;
  user: string;
  role: string;
  action: string;
  timestamp: string;
}


const INITIAL_AGENCIES_DATA: Record<string, any> = {};
const MOCK_AGENCIES: Record<string, any> = INITIAL_AGENCIES_DATA;

export interface SimulatedNotification {
  id: string;
  title: string;
  body: string;
  app: string;
  time: string;
  type: 'success' | 'info' | 'warning' | 'danger';
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<any>(() => {
    try {
      const saved = safeStorage.getItem("wl_currentUser");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [currentRole, setCurrentRole] = useState<Role>(() => {
    return (currentUser?.role as Role) || "none";
  });

  const [realRole, setRealRole] = useState<Role>(() => {
    return (currentUser?.role as Role) || "none";
  });

  const isPlatformOwner = Boolean(
    currentUser?.isPlatformOwner ||
    currentUser?.role === 'owner'
  );

  const [maintenanceConfig, setMaintenanceConfig] = useState<MaintenanceConfig>(getStoredMaintenanceConfig);
  const [showKillSwitchModal, setShowKillSwitchModal] = useState<boolean>(false);

  useEffect(() => {
    const unsub = subscribeMaintenanceConfig((cfg) => {
      setMaintenanceConfig(cfg);
    });
    return () => unsub();
  }, []);

  const onRequestRoleSwitch = (role: Role, customUser?: any) => {
    setCurrentRole(role);
    if (customUser) setCurrentUser(customUser);
  };

  const getUrlCreatorHandle = (): string => {
    if (typeof window === "undefined") return "@elenarostova";
    const searchParams = new URLSearchParams(window.location.search);
    const qCreator = searchParams.get("creator");
    if (qCreator) {
      const decoded = decodeURIComponent(qCreator);
      return decoded.startsWith("@") ? decoded : `@${decoded}`;
    }
    const hash = window.location.hash;
    const hashCreatorMatch = hash.match(/creator=([^&]+)/);
    if (hashCreatorMatch && hashCreatorMatch[1]) {
      const decoded = decodeURIComponent(hashCreatorMatch[1]);
      return decoded.startsWith("@") ? decoded : `@${decoded}`;
    }
    const kitMatch = hash.match(/#kit-([a-zA-Z0-9_-]+)/);
    if (kitMatch && kitMatch[1]) {
      const decoded = decodeURIComponent(kitMatch[1]);
      return `@${decoded}`;
    }
    return "@elenarostova";
  };

  const SCREEN_TO_ROUTE_MAP: Record<string, string> = {
    'director-dash': '/agency/dashboard',
    'briefing': '/agency/briefing',
    'roster': '/agency/roster',
    'pod-configuration': '/agency/pods',
    'campaign-board': '/agency/campaigns',
    'content-review': '/agency/content-review',
    'invoicing': '/agency/invoicing',
    'brand-crm': '/agency/brands',
    'system-audit-log': '/agency/audit-log',
    'creator-dash': '/creator/dashboard',
    'creator-portal': '/creator/dashboard',
    'creator-hub': '/creator/dashboard',
    'creator-workspace': '/creator/dashboard',
    'media-kits': '/media-kits',
    'my-portfolio': '/media-kits',
    'public-portfolio': '/showcase',
    'open-marketplace': '/marketplace',
    'announcement-center': '/announcements',
    'creator-announcements': '/announcements',
    'team-announcements': '/announcements',
    'pod-invite-signup': '/join',
    'chat-system': '/chat',
    'chat': '/chat',
    'unified-calendar': '/calendar',
  };

  const getRoutePathForScreen = (screenId: string): string => {
    return SCREEN_TO_ROUTE_MAP[screenId] || `/${screenId}`;
  };

  const getScreenForRoutePath = (pathname: string): { screenId: string; param?: string } => {
    const cleanPath = pathname.toLowerCase().replace(/\/$/, '') || '/';
    
    if (cleanPath === '/join' || cleanPath === '/creator/apply' || cleanPath === '/apply') {
      return { screenId: 'pod-invite-signup' };
    }
    if (cleanPath === '/showcase' || cleanPath === '/roster/public' || cleanPath === '/portfolio') {
      return { screenId: 'public-portfolio' };
    }
    if (cleanPath.startsWith('/creator/@') || cleanPath.startsWith('/mediakit/')) {
      const handle = cleanPath.replace('/creator/@', '').replace('/mediakit/', '');
      return { screenId: 'media-kits', param: handle };
    }
    if (cleanPath.startsWith('/briefs/') || cleanPath.startsWith('/campaigns/')) {
      const briefId = cleanPath.replace('/briefs/', '').replace('/campaigns/', '');
      return { screenId: 'campaign-board', param: briefId };
    }

    for (const [screenId, route] of Object.entries(SCREEN_TO_ROUTE_MAP)) {
      if (route.toLowerCase() === cleanPath) {
        return { screenId };
      }
    }

    if (cleanPath.includes('creator')) return { screenId: 'creator-dash' };
    if (cleanPath.includes('pods')) return { screenId: 'pod-configuration' };
    if (cleanPath.includes('roster')) return { screenId: 'roster' };
    if (cleanPath.includes('campaign')) return { screenId: 'campaign-board' };

    return { screenId: 'briefing' };
  };

  const [activeScreen, setActiveScreen] = useState<string>(() => {
    if (typeof window !== "undefined") {
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();
      const pathname = window.location.pathname.toLowerCase();
      
      const routeInfo = getScreenForRoutePath(pathname);
      if (routeInfo.screenId && routeInfo.screenId !== 'briefing') {
        return routeInfo.screenId;
      }

      if (
        hash.includes("match-pass") ||
        hash === "#sneak-peek" ||
        hash.includes("casting") ||
        search.includes("mode=sneak-peek")
      ) {
        return "match-or-pass";
      }
      if (
        hash.includes("showcase") ||
        hash.includes("talent-showcase") ||
        pathname.includes("showcase") ||
        search.includes("showcase")
      ) {
        return "talent-showcase";
      }
      if (
        hash.includes("public-portfolio") ||
        hash.includes("portfolio") ||
        pathname.includes("portfolio") ||
        hash.startsWith("#kit-") ||
        search.includes("public-portfolio") ||
        (search.includes("brand=true") && (search.includes("creator=") || hash.includes("creator=")))
      ) {
        return "public-portfolio";
      }
    }
    return "briefing";
  });
  const [screenHistory, setScreenHistory] = useState<string[]>([]);

  // Browser Back/Forward navigation listener for clean URL paths
  useEffect(() => {
    const handlePopState = () => {
      if (typeof window !== 'undefined') {
        const routeInfo = getScreenForRoutePath(window.location.pathname);
        if (routeInfo.screenId) {
          setActiveScreen(routeInfo.screenId);
        }
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigateToScreen = (screenId: string) => {
    if (screenId !== activeScreen) {
      setScreenHistory(prev => [...prev, activeScreen]);
      setActiveScreen(screenId);

      if (typeof window !== 'undefined') {
        const targetRoute = getRoutePathForScreen(screenId);
        if (window.location.pathname !== targetRoute) {
          window.history.pushState({ screenId }, '', targetRoute);
        }
      }
    }
  };

  const handleGoBack = () => {
    if (screenHistory.length > 0) {
      const prev = screenHistory[screenHistory.length - 1];
      setScreenHistory(prevStack => prevStack.slice(0, prevStack.length - 1));
      setActiveScreen(prev);
    } else {
      setActiveScreen("briefing");
    }
  };

  const handleGoHome = () => {
    navigateToScreen("briefing");
  };

  // Collapsible Navigation Accordion: By default shows section titles; clicking a title expands only that section's dropdown ("shows only")
  const [expandedNavCategory, setExpandedNavCategory] = useState<string | null>(null);

  const handleToggleNavCategory = (categoryTitle: string) => {
    setExpandedNavCategory((prev) => (prev === categoryTitle ? null : categoryTitle));
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
    } catch (err) {
      console.error("Firebase logout failed:", err);
    }
    
    // Clear all application state
    setIsAuthenticated(false);
    setUserProfile(null);
    setFirebaseAuthUser(null);
    setCurrentUser(null);
    
    // Security: Clear ALL storage to prevent data leakage on shared computers.
    safeStorage.clear();
    
    // Clear sessionStorage as a secondary precaution
    if (typeof window !== 'undefined') {
      try {
        sessionStorage.clear();
      } catch {}
    }

    triggerSimulatedNotification("Signed Out", "Session ended. All local data has been cleared for security.", "info");

    // Force a full page reload to clear all in-memory state and prevent unmounting components 
    // from potentially writing stale state back to storage.
    setTimeout(() => {
      window.location.href = '/';
    }, 800);
  };
  const [tenantId, setTenantId] = useState<string>("main");
  const [agencyName, setAgencyName] = useState<string>("Bloom Studio");
  const [legalEntityName, setLegalEntityName] = useState<string>("Bloom Studio LLC");
  const [primaryBrandColor, setPrimaryBrandColor] = useState<string>("#C9A46A");
  const [sidebarBgColor, setSidebarBgColor] = useState<string>("#0D1830");
  const [mainDashboardBg, setMainDashboardBg] = useState<string>("#050C18");
  const [cardBgColor, setCardBgColor] = useState<string>("#111E33");
  const [textMainColor, setTextMainColor] = useState<string>("#ffffff");
  const [textMutedColor, setTextMutedColor] = useState<string>("#6b7c96");
  const [directorName, setDirectorName] = useState<string>("Executive Director");
  const [systemLogo, setSystemLogo] = useState<string>("");
  const [vslVideoUrl, setVslVideoUrl] = useState<string>(() => {
    try {
      return safeStorage.getItem('bloom_vsl_video_url') || "";
    } catch {
      return "";
    }
  });
  const [isCoreMvpMode, setIsCoreMvpMode] = useState<boolean>(false);

  const [agentMgrCanAnnounce, setAgentMgrCanAnnounce] = useState<boolean>(false);
  const [agentManagerCanAddCampaigns, setAgentManagerCanAddCampaigns] = useState<boolean>(false);
  const [agentManagerCanAddToPortfolio, setAgentManagerCanAddToPortfolio] = useState<boolean>(false);
  const [agentManagerCanDraftBriefs, setAgentManagerCanDraftBriefs] = useState<boolean>(false);

  const delegationSettings = {
    agentMgrCanAnnounce,
    agentManagerCanAddCampaigns,
    agentManagerCanAddToPortfolio,
    agentManagerCanDraftBriefs,
    allowBrandMediaKitShare: false, // Default or fetch if needed
    staffCanViewInvoices: false,
    staffCanCreateInvoices: false,
  };
  const [discoveryNiches, setDiscoveryNiches] = useState<string[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_discovery_niches");
      return saved ? JSON.parse(saved) : ["Pets", "Beauty", "Lifestyle"];
    } catch {
      return ["Pets", "Beauty", "Lifestyle"];
    }
  });

  const [strictCoreOnly, setStrictCoreOnly] = useState<boolean>(false);

  // Missing application state variables
  const [liveTenantsMap, setLiveTenantsMap] = useState<Record<string, any>>(INITIAL_AGENCIES_DATA);
  const activeTenantConfig = liveTenantsMap[tenantId] || INITIAL_AGENCIES_DATA[tenantId] || INITIAL_AGENCIES_DATA.main;
  const [firebaseAuthUser, setFirebaseAuthUser] = useState<any>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const activeLocal = safeStorage.getItem("wl_currentUser");
      if (activeLocal) {
        const parsed = JSON.parse(activeLocal);
        if (parsed && parsed.role && parsed.role !== "none") return true;
      }
      return !!safeStorage.getItem("wl_currentUser") && !!safeStorage.getItem("wl_firebase_user");
    } catch {
      return false;
    }
  });
  const [showAgencySignup, setShowAgencySignup] = useState<boolean>(false);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(() => {
    try {
      const activeLocal = safeStorage.getItem("wl_currentUser");
      if (activeLocal) {
        const parsed = JSON.parse(activeLocal);
        if (parsed && parsed.role && parsed.role !== "none") return false;
      }
      return !!safeStorage.getItem("wl_firebase_user");
    } catch {
      return false;
    }
  });
  const [userProfile, setUserProfile] = useState<any>(null);
  const [allUsers, setAllUsers] = useState<any[]>([]);

  // Real-time Firestore sync for studio-users (Staff Roster)
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-users");
    const q = isPlatformOwner 
      ? colRef 
      : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: any[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...docSnap.data() });
        });
        setAllUsers(items);
        safeStorage.setItem("wl_user_accounts", JSON.stringify(items));
      },
      (err) => {
        console.warn("[studio-users] onSnapshot subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentUser?.uid, currentUser?.isPlatformOwner, currentUser?.subagency]);
  const [tenantAccessDenied, setTenantAccessDenied] = useState<boolean>(false);

  const triggerNotification = (title: string, description: string, alertType: string = "info") => {
    if (typeof window !== "undefined" && (window as any).launchLiveSystemToast) {
      (window as any).launchLiveSystemToast(title, description, alertType);
    } else {
      console.log(`[Notification] ${title}: ${description}`);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setIsAuthLoading(true);
      if (user) {
        const previousUid = safeStorage.getItem("wl_active_uid");
        if (previousUid && previousUid !== user.uid) {
          const keysToPurge = [
            "wl_creators", "wl_deals", "wl_campaigns", "wl_brands", "wl_threads",
            "wl_content_reviews", "wl_announcements", "wl_trash_items", "wl_missions",
            "wl_referrals", "wl_agency_schedules", "wl_external_integrations",
            "wl_roster_profile_submissions", "wl_casting_referrals", "wl_creator_briefs",
            "wl_agent_briefs", "wl_fulfillment_items", "wl_open_marketplace_opps",
            "wl_open_marketplace_apps", "wl_rejected_content_log", "wl_content_library_assets"
          ];
          keysToPurge.forEach(k => safeStorage.removeItem(k));
        }
        safeStorage.setItem("wl_active_uid", user.uid);

        setFirebaseAuthUser(user);
        safeStorage.setItem("wl_firebase_user", JSON.stringify({ uid: user.uid, email: user.email }));
        
        try {
          let profile = await getOrCreateUserProfile(tenantId, user);

          // Check if user has a pending paid workspace subdomain to claim
          const pendingSub = safeStorage.getItem("pending_paid_subdomain");
          if (pendingSub && user) {
            try {
              const token = await getAuthToken();
              if (token) {
                const claimRes = await fetch("/api/claim-paid-workspace", {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                  },
                  body: JSON.stringify({ subdomain: pendingSub }),
                }).then((r) => r.json());

                if (claimRes.success) {
                  profile = {
                    ...profile,
                    role: "director",
                    subagency: claimRes.subdomain,
                    tenantId: claimRes.subdomain,
                  };
                  safeStorage.removeItem("pending_paid_subdomain");
                  triggerNotification(
                    "🎉 Workspace Claimed",
                    `You are now active as Director of ${claimRes.agencyName || claimRes.subdomain}.`,
                    "success"
                  );
                }
              }
            } catch (claimErr) {
              console.warn("[onAuthStateChanged] Claim paid workspace error:", claimErr);
            }
          }

          if (profile) {
            const isOwner = profile.role === "director" || profile.isPlatformOwner;
            const mappedUser = {
              id: user.uid,
              name: profile.displayName || user.displayName || (isOwner ? "Executive Director" : "Studio User"),
              email: user.email,
              role: (profile.role as Role) || "none",
              handle: profile.handle || (isOwner ? "@director" : "@user"),
              avatarUrl: user.photoURL || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80",
              tenantId: profile.tenantId || tenantId || "bloom_studio_default",
              subagency: profile.subagency || "pod_main",
              isPlatformOwner: !!profile.isPlatformOwner,
              hasSignedToS: Boolean(
                profile.hasSignedToS || 
                profile.tosSignedAt || 
                safeStorage.getItem(`bloom_agency_tos_v2026_signed_${user.uid}`) === "true" ||
                (user.email && safeStorage.getItem(`bloom_tos_signed_${user.email}`) === "true") ||
                safeStorage.getItem("bloom_agency_tos_v2026_signed") === "true"
              ),
              tosSignedAt: profile.tosSignedAt || (safeStorage.getItem(`bloom_agency_tos_v2026_signed_${user.uid}`) === "true" ? new Date().toISOString() : null),
              tosVersion: profile.tosVersion || "v2026.1",
              tosDigest: profile.tosDigest || null,
              tosSignerName: profile.tosSignerName || profile.displayName || user.displayName || null,
            };
            setCurrentUser(mappedUser);
            setCurrentRole(mappedUser.role as Role);
            setRealRole(mappedUser.role as Role);
            safeStorage.setItem("wl_currentUser", JSON.stringify(mappedUser));
            setUserProfile(profile);
            setIsAuthenticated(true);
          } else {
            console.warn("Could not retrieve user profile from database.");
            setIsAuthenticated(false);
            setCurrentUser(null);
            setUserProfile(null);
            setCurrentRole("none");
            setRealRole("none");
            safeStorage.removeItem("wl_currentUser");
          }
        } catch (err) {
          console.error("Error fetching user profile:", err);
          setIsAuthenticated(false);
          setCurrentUser(null);
          setUserProfile(null);
          setCurrentRole("none");
          setRealRole("none");
          safeStorage.removeItem("wl_currentUser");
        }
      } else {
        setFirebaseAuthUser(null);
        // Check if there is an active local or direct workspace session
        const activeLocal = safeStorage.getItem("wl_currentUser");
        if (activeLocal) {
          try {
            const parsed = JSON.parse(activeLocal);
            if (parsed && parsed.role && parsed.role !== "none") {
              setCurrentUser(parsed);
              setCurrentRole(parsed.role as Role);
              setRealRole(parsed.role as Role);
              setIsAuthenticated(true);
              setIsAuthLoading(false);
              return;
            }
          } catch {}
        }
        setIsAuthenticated(false);
        setCurrentUser(null);
        setUserProfile(null);
        setCurrentRole("none");
        setRealRole("none");
        safeStorage.removeItem("wl_firebase_user");
        safeStorage.removeItem("wl_currentUser");
      }
      setIsAuthLoading(false);
    });
    return () => unsubscribe();
  }, [tenantId]);

  // Handle Stripe paid-signup redirect (?signup=success&subdomain=X)
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const signupStatus = urlParams.get("signup");
    const paramSubdomain = urlParams.get("subdomain");

    if (signupStatus === "success" && paramSubdomain) {
      const cleanSubdomain = paramSubdomain.toLowerCase().trim();
      safeStorage.setItem("pending_paid_subdomain", cleanSubdomain);

      // Clean URL query parameters cleanly
      try {
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.delete("signup");
        window.history.replaceState({}, document.title, newUrl.pathname + newUrl.search);
      } catch (e) {}

      triggerNotification(
        "🎉 Payment Received!",
        `Workspace '${cleanSubdomain}' is active! Setting up your Director account...`,
        "success"
      );

      // If user is already signed in, attempt claim immediately
      if (firebaseAuthUser) {
        getAuthToken().then((token) => {
          if (!token) return;
          fetch("/api/claim-paid-workspace", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ subdomain: cleanSubdomain }),
          })
            .then((r) => r.json())
            .then((res) => {
              if (res.success) {
                safeStorage.removeItem("pending_paid_subdomain");
                const updatedUser = {
                  ...(currentUser || {}),
                  role: "director" as Role,
                  subagency: cleanSubdomain,
                  tenantId: cleanSubdomain,
                };
                setCurrentUser(updatedUser as any);
                setCurrentRole("director" as Role);
                setRealRole("director" as Role);
                safeStorage.setItem("wl_currentUser", JSON.stringify(updatedUser));
                triggerNotification(
                  "Director Workspace Active",
                  `Welcome! You are logged in as Director of ${res.agencyName || cleanSubdomain}.`,
                  "success"
                );
              }
            })
            .catch((err) => console.warn("[SignupSuccess] Auto-claim error:", err));
        });
      }
    } else if (signupStatus === "cancelled") {
      try {
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.delete("signup");
        window.history.replaceState({}, document.title, newUrl.pathname + newUrl.search);
      } catch (e) {}
      triggerNotification("Checkout Cancelled", "Agency registration checkout was cancelled.", "info");
    }
  }, [firebaseAuthUser]);

  const handleDirectLogin = (email: string, role: string) => {
    const isDirector = role === "director" || role === "owner";
    const userDirectKey = isDirector ? "user_director" : `user_${role}`;
    const isLocallySigned = 
      safeStorage.getItem(`bloom_agency_tos_v2026_signed_${userDirectKey}`) === "true" ||
      (email && safeStorage.getItem(`bloom_tos_signed_${email}`) === "true") ||
      safeStorage.getItem("bloom_agency_tos_v2026_signed") === "true";

    const mappedUser = {
      id: isDirector ? "user_director" : `user_${role}_${email.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
      name: isDirector 
        ? "Executive Director" 
        : role === "creator" 
        ? "Elena Rostova" 
        : role === "contractor"
        ? "Jordan Taylor (Contractor)"
        : role === "brand" 
        ? "Sephora Partnerships" 
        : role === "agentmgr" 
        ? "Marcus Vance" 
        : "Studio Manager",
      email: email,
      role: role as Role,
      handle: isDirector 
        ? "@director" 
        : role === "creator" 
        ? "@elena" 
        : role === "contractor"
        ? "@jordan_ugc"
        : role === "brand" 
        ? "@sephora" 
        : role === "agentmgr" 
        ? "@marcus" 
        : "@studio",
      avatarUrl: isDirector
        ? "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80"
        : role === "contractor"
        ? "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=256&q=80"
        : "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80",
      tenantId: tenantId || "bloom_studio_default",
      subagency: "pod_main",
      isPlatformOwner: false,
      hasSignedToS: isLocallySigned,
      tosSignedAt: isLocallySigned ? new Date().toISOString() : null,
      tosVersion: "v2026.1",
      tosSignerName: isDirector ? "Executive Director" : role === "creator" ? "Elena Rostova" : role === "contractor" ? "Jordan Taylor" : role === "brand" ? "Sephora Partnerships" : "Marcus Vance"
    };
    setCurrentUser(mappedUser);
    setCurrentRole(role as Role);
    setRealRole(role as Role);
    setUserProfile(mappedUser);
    setIsAuthenticated(true);
    safeStorage.setItem("wl_currentUser", JSON.stringify(mappedUser));
    safeStorage.setItem("wl_firebase_user", JSON.stringify({ uid: mappedUser.id, email: mappedUser.email }));
    safeStorage.setItem("wl_auth_mode", "direct");

    // Mint verified session token for server endpoints immediately in background
    getDirectSessionToken(true).catch((e) => console.warn("[DirectLogin] Session token prefetch:", e));

    const landing = DEFAULT_LANDING_SCREEN_PER_ROLE[role.toLowerCase()] || "briefing";
    setActiveScreen(landing);
    triggerSimulatedNotification(
      "Workspace Connected",
      `Authenticated as ${mappedUser.name} (${role.toUpperCase()})`,
      "success"
    );
  };

  const hasRedirectedRef = useRef(false);
  useEffect(() => {
    if (isAuthenticated && currentRole && !isAuthLoading && !hasRedirectedRef.current) {
      const hash = typeof window !== 'undefined' ? window.location.hash.toLowerCase() : '';
      const path = typeof window !== 'undefined' ? window.location.pathname.toLowerCase() : '';
      const search = typeof window !== 'undefined' ? window.location.search.toLowerCase() : '';

      let urlScreen: string | null = null;
      if (hash.includes('showcase') || path.includes('showcase') || search.includes('showcase')) {
        urlScreen = 'talent-showcase';
      } else if (hash.includes('portfolio') || path.includes('portfolio') || search.includes('portfolio')) {
        urlScreen = 'public-portfolio';
      } else if (hash.includes('join') || path.includes('join') || search.includes('join')) {
        urlScreen = 'pod-invite-signup';
      } else if (hash.includes('vsl') || path.includes('vsl') || search.includes('vsl')) {
        urlScreen = 'agency-vsl-hero';
      }

      if (urlScreen) {
        setActiveScreen(urlScreen);
        hasRedirectedRef.current = true;
      } else {
        const landing = DEFAULT_LANDING_SCREEN_PER_ROLE[currentRole.toLowerCase()];
        if (landing) {
          setActiveScreen(landing);
          hasRedirectedRef.current = true;
        }
      }
    }
  }, [isAuthenticated, currentRole, isAuthLoading]);

  const [brandActiveTab, setBrandActiveTab] = useState<string>("briefing");
  const [brandInquiries, setBrandInquiries] = useState<any[]>([
    { id: "inq-1", brandName: "Luxe Glow Cosmetics", contactPerson: "Sarah Jenkins", email: "sarah@luxeglow.com", requestedTalent: "@sarahglows", budget: "$15,000", status: "Pending Review", date: "2026-08-28" },
    { id: "inq-2", brandName: "Paws & Whiskers", contactPerson: "Mike Ross", email: "mike@pawsandwhiskers.co", requestedTalent: "@barkandpurr", budget: "$8,500", status: "In Progress", date: "2026-08-29" },
  ]);
  const [brandInvoices, setBrandInvoices] = useState<any[]>([
    { id: "INV-2026-001", brandName: "Luxe Glow Cosmetics", description: "Q3 Campaign Phase 1 - 3x TikTok Videos & Spark Ads Rights", amount: 15000, status: "Pending Payment", dueDate: "2026-09-15" },
    { id: "INV-2026-002", brandName: "Paws & Whiskers", description: "Product UGC Launch Asset Deliverables (4 Videos)", amount: 8500, status: "Paid", dueDate: "2026-08-30" },
  ]);
  const [brandMatches, setBrandMatches] = useState<any[]>([]);
  const [curatedBrandCreators, setCuratedBrandCreators] = useState<string[]>([]);
  const [payingInvoice, setPayingInvoice] = useState<any>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [ccName, setCcName] = useState<string>("");
  const [ccNumber, setCcNumber] = useState<string>("");
  const [ccExpiry, setCcExpiry] = useState<string>("");
  const [ccCvv, setCcCvv] = useState<string>("");
  const [contentSubmissions, setContentSubmissions] = useState<any[]>([]);
  const [agentMgrMissionsView, setAgentMgrMissionsView] = useState<string>("active");
  const [suggestMissionModal, setSuggestMissionModal] = useState<any>(null);
  const [suggestMissionCreator, setSuggestMissionCreator] = useState<string>("");
  const [suggestMissionNote, setSuggestMissionNote] = useState<string>("");
  const [hiringSettings, setHiringSettings] = useState<any>(() => {
    try {
      const saved = safeStorage.getItem("wl_hiring_settings");
      return saved ? JSON.parse(saved) : {
        isHiringActive: true,
        targetNiches: ["Pets", "Beauty", "Lifestyle"],
        autoReviewWaitlist: true,
        minFollowers: 1000,
        notificationEmail: "director@bloomstudio.com",
      };
    } catch {
      return {
        isHiringActive: true,
        targetNiches: ["Pets", "Beauty", "Lifestyle"],
        autoReviewWaitlist: true,
        minFollowers: 1000,
        notificationEmail: "director@bloomstudio.com",
      };
    }
  });
  const [selectedCreatorForDetail, setSelectedCreatorForDetail] = useState<any>(null);
  const [creatorDetailActiveTab, setCreatorDetailActiveTab] = useState<string>("overview");
  const [messageChannel, setMessageChannel] = useState<"sms" | "email" | "portal">("sms");
  const [smsMessageText, setSmsMessageText] = useState<string>("");
  const [emailSubjectText, setEmailSubjectText] = useState<string>("");
  const [emailMessageText, setEmailMessageText] = useState<string>("");
  const [sendingMessage, setSendingMessage] = useState<boolean>(false);
  const [showRosterCharts, setShowRosterCharts] = useState<boolean>(false);
  const [agencySchedules, setAgencySchedules] = useState<any[]>([]);
  const [agentManagerPermissions, setAgentManagerPermissions] = useState<Record<string, any>>({
    default: { canManageRoster: true, canViewFinancials: false, canLogCampaigns: false, canCreateMissions: true, canApproveContent: true, canIssueCards: false },
  });
  const [billingStatus, setBillingStatus] = useState<string>("active");
  const [bulkEmailBody, setBulkEmailBody] = useState<string>("");
  const [bulkEmailSubject, setBulkEmailSubject] = useState<string>("");
  const [showBulkEmailModal, setShowBulkEmailModal] = useState<boolean>(false);
  const [copiedSneakEmailPitch, setCopiedSneakEmailPitch] = useState<boolean>(false);
  const [copiedSneakPeekLink, setCopiedSneakPeekLink] = useState<boolean>(false);
  const [createTenantForm, setCreateTenantForm] = useState<any>({ name: "", subdomain: "", plan: "Core OS", adminEmail: "" });
  const [createdTenantInvite, setCreatedTenantInvite] = useState<any>(null);
  const [showCreateTenantModal, setShowCreateTenantModal] = useState<boolean>(false);
  const [editTenantForm, setEditTenantForm] = useState<any>(null);
  const [editingTenantId, setEditingTenantId] = useState<string | null>(null);
  const [showEditTenantModal, setShowEditTenantModal] = useState<boolean>(false);
  const [showBrandPartnerModal, setShowBrandPartnerModal] = useState<boolean>(false);
  const [pendingBrandAccess, setPendingBrandAccess] = useState<{ token?: string; deliverableId?: string; brandName?: string; subagency?: string; url?: string } | null>(null);
  const [expandedTenantTileId, setExpandedTenantTileId] = useState<string | null>(null);
  const [globalSearchOpen, setGlobalSearchOpen] = useState<boolean>(false);
  const [globalSearchQuery, setGlobalSearchQuery] = useState<string>("");
  const [newNicheInput, setNewNicheInput] = useState<string>("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isDealSearchModalOpen, setIsDealSearchModalOpen] = useState<boolean>(false);
  const [platformSwitches, setPlatformSwitches] = useState<any>({
    tiktok: true,
    instagram: true,
    youtube: true,
    botEngine: true,
    aiMediaStudio: true,
    autoCompliance: true,
  });
  const [actionQueueSort, setActionQueueSort] = useState<string>("urgent");
  const [deleteConfirmModalConfig, setDeleteConfirmModalConfig] = useState<any>(null);
  const [onboardingItems, setOnboardingItems] = useState<any[]>([]);
  const [viewAsDropdownOpen, setViewAsDropdownOpen] = useState<boolean>(false);
  const inviteToken = new URLSearchParams(window.location.search).get("invite");

  // Global Keyboard Shortcut for Command Palette (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setGlobalSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const getManagerPerms = useCallback(() => {
    return (
      agentManagerPermissions[currentUser?.name] ||
      agentManagerPermissions.default || {
        canManageRoster: true,
        canViewFinancials: true,
        canLogCampaigns: true,
        canCreateMissions: true,
        canApproveContent: true,
        canIssueCards: true,
      }
    );
  }, [agentManagerPermissions, currentUser]);

  const handleToggleOrAddNiche = useCallback((niche: string) => {
    setDiscoveryNiches((prev) =>
      prev.includes(niche) ? prev.filter((n) => n !== niche) : [...prev, niche]
    );
  }, []);




  const handleResetToCoreNiches = () => {
    const core = ["Pets", "Beauty", "Lifestyle"];
    setDiscoveryNiches(core);
    safeStorage.setItem("wl_discovery_niches", JSON.stringify(core));
    window.dispatchEvent(new Event("storage"));
    triggerSimulatedNotification(
      "Core Niches Locked",
      "Match or Pass filter locked strictly to Pets, Beauty, and Lifestyle.",
      "success",
    );
  };

  // Dynamic Sidebar Modules Configuration State
  const [navCategoriesState, setNavCategoriesState] = useState(() => {
    // Obsolete category titles that must be removed completely
    const OBSOLETE_CATEGORIES = [
      "BRAND WORKSPACE",
      "BRANDS",
      "MY AGENCY SETUP",
      "OUTREACH & BOTS",
      "CONTENT OPERATIONS",
      "CREATORS",
      "ADMIN & ONBOARDING",
      "DEALS",
      "FINANCE",
      "TEAM",
      "CONFIGURATION",
      "ADMIN",
      "SUB-AGENCIES",
      "RESOURCES",
      "CREATOR STUDIO & WORKFLOW",
      "TALENT DISCOVERY",
      "INBOUND GROWTH ENGINES",
      "TALENT HQ & ROSTER",
    ];

    // Redundant navigation items consolidated to single destinations
    const REDUNDANT_NAV_ITEM_IDS = [
      "revenue",
      "all-deals",
      "deal-pipeline",
      "deal-search",
      "realtime-deals-sync",
    ];

    try {
      const saved = safeStorage.getItem("wl_navCategories");
      if (saved) {
        const parsed = JSON.parse(saved);
        // If the saved state has obsolete categories, discard and reset to the new streamlined INITIAL_NAV_CATEGORIES
        const hasLegacyCategories = parsed.some((cat: any) =>
          OBSOLETE_CATEGORIES.includes(cat.title),
        );
        if (hasLegacyCategories) {
          safeStorage.removeItem("wl_navCategories");
          return INITIAL_NAV_CATEGORIES;
        }

        // Otherwise ensure all modern initial hubs are synchronized and redundant items stripped
        return INITIAL_NAV_CATEGORIES.map((initCat) => {
          const matched = parsed.find((p: any) => p.title === initCat.title);
          if (!matched) return initCat;
          return {
            ...initCat,
            items: initCat.items
              .filter((item) => !REDUNDANT_NAV_ITEM_IDS.includes(item.id))
              .map((item) => {
                const savedItem = matched.items?.find(
                  (si: any) => si.id === item.id,
                );
                return {
                  ...item,
                  isActive: savedItem ? savedItem.isActive !== false : true,
                  icon: item.icon,
                };
              }),
          };
        });
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_NAV_CATEGORIES;
  });

  // Auto-expand category containing activeScreen
  useEffect(() => {
    for (const cat of navCategoriesState) {
      if (cat.items.some(item => item.id === activeScreen)) {
        setExpandedNavCategory(cat.title);
        break;
      }
    }
  }, [activeScreen, navCategoriesState]);

  // Sync styling and configuration changes dynamically to root CSS variables
  useEffect(() => {
    document.documentElement.style.setProperty(
      "--agency-sidebar-bg",
      sidebarBgColor,
    );
    document.documentElement.style.setProperty(
      "--agency-accent-gold",
      primaryBrandColor,
    );
    document.documentElement.style.setProperty(
      "--agency-bg-dark",
      mainDashboardBg,
    );
    document.documentElement.style.setProperty("--agency-card-bg", cardBgColor);
    document.documentElement.style.setProperty(
      "--agency-text-main",
      textMainColor,
    );
    document.documentElement.style.setProperty(
      "--agency-text-muted",
      textMutedColor,
    );
  }, [
    sidebarBgColor,
    primaryBrandColor,
    mainDashboardBg,
    cardBgColor,
    textMainColor,
    textMutedColor,
  ]);

  // Subscribe to real-time Firestore tenant branding changes across all signed-in users
  useEffect(() => {
    const unsubscribe = subscribeTenantConfig(tenantId, (remoteConfig) => {
      if (!remoteConfig) return;
      if (remoteConfig.agencyName) setAgencyName(remoteConfig.agencyName);
      if (remoteConfig.legalEntityName)
        setLegalEntityName(remoteConfig.legalEntityName);
      if (remoteConfig.primaryBrandColor)
        setPrimaryBrandColor(remoteConfig.primaryBrandColor);
      if (remoteConfig.sidebarBgColor)
        setSidebarBgColor(remoteConfig.sidebarBgColor);
      if (remoteConfig.mainDashboardBg)
        setMainDashboardBg(remoteConfig.mainDashboardBg);
      if (remoteConfig.cardBgColor) setCardBgColor(remoteConfig.cardBgColor);
      if (remoteConfig.textMainColor)
        setTextMainColor(remoteConfig.textMainColor);
      if (remoteConfig.textMutedColor)
        setTextMutedColor(remoteConfig.textMutedColor);
      if (remoteConfig.directorName) setDirectorName(remoteConfig.directorName);
      if (remoteConfig.systemLogo !== undefined)
        setSystemLogo(remoteConfig.systemLogo);
      if (remoteConfig.agentMgrCanAnnounce !== undefined)
        setAgentMgrCanAnnounce(remoteConfig.agentMgrCanAnnounce);
      if (remoteConfig.agentManagerCanAddCampaigns !== undefined)
        setAgentManagerCanAddCampaigns(remoteConfig.agentManagerCanAddCampaigns);
      if (remoteConfig.agentManagerCanAddToPortfolio !== undefined)
        setAgentManagerCanAddToPortfolio(remoteConfig.agentManagerCanAddToPortfolio);
      if (remoteConfig.agentManagerCanDraftBriefs !== undefined)
        setAgentManagerCanDraftBriefs(remoteConfig.agentManagerCanDraftBriefs);
    });
    return () => unsubscribe();
  }, [tenantId]);

  // Subscribe to all live tenants from Firestore for the Multi-Tenant Workspace Selector
  useEffect(() => {
    if (!isAuthenticated) return;
    const unsubscribe = subscribeAllTenants((remoteTenants) => {
      if (remoteTenants && remoteTenants.length > 0) {
        const newMap: Record<string, any> = { ...INITIAL_AGENCIES_DATA };
        remoteTenants.forEach((t) => {
          if (t.id) {
            newMap[t.id] = {
              ...newMap[t.id],
              ...t,
              agencyName: t.agencyName || t.id,
              legalEntityName: t.legalEntityName || t.agencyName || t.id,
              primaryBrandColor: t.primaryBrandColor || "#C9A46A",
              sidebarBgColor: t.sidebarBgColor || "#0D1830",
              mainDashboardBg: t.mainDashboardBg || "#050C18",
              cardBgColor: t.cardBgColor || "#111E33",
              textMainColor: t.textMainColor || "#ffffff",
              textMutedColor: t.textMutedColor || "#6b7c96",
              billingProfile: t.billingProfile || {
                status: t.status || "active",
                plan: "Core OS",
                fee: 199,
                billingPeriod: "monthly",
              },
            };
          }
        });
        setLiveTenantsMap(newMap);
      }
    });
    return () => unsubscribe();
  }, [isAuthenticated]);

  // Synchronize active tenant billing status to enforce subscription access locks
  useEffect(() => {
    const isPlatformOwner = currentUser?.isPlatformOwner === true;
    if (isPlatformOwner) {
      setBillingStatus("active");
      return;
    }
    const currentPodKey = tenantId || currentUser?.subagency || currentUser?.tenantId;
    if (!currentPodKey || currentPodKey === "bloom_studio_default" || currentPodKey === "pod_main") {
      setBillingStatus("active");
      return;
    }
    const activeTenant = liveTenantsMap[currentPodKey];
    if (activeTenant) {
      const statusFromTenant = (activeTenant.status || activeTenant.billingProfile?.status || "active").toLowerCase();
      setBillingStatus(statusFromTenant);
    }
  }, [tenantId, liveTenantsMap, currentUser]);

  // Mandatory Agency Terms of Service onboarding gate for authenticated users
  useEffect(() => {
    if (isAuthenticated && currentUser && currentRole !== "none") {
      const userKey = currentUser.id || currentUser.uid || currentUser.email || "guest";
      const roleKey = `user_${currentRole}`;
      const userEmail = currentUser.email || "";
      const isSigned =
        currentUser.hasSignedToS === true ||
        Boolean(currentUser.tosSignedAt) ||
        safeStorage.getItem("bloom_agency_tos_v2026_signed") === "true" ||
        (userEmail && safeStorage.getItem(`bloom_tos_signed_${userEmail}`) === "true") ||
        safeStorage.getItem(`bloom_agency_tos_v2026_signed_${userKey}`) === "true" ||
        safeStorage.getItem(`bloom_agency_tos_v2026_signed_${roleKey}`) === "true";

      if (!isSigned) {
        setIsMandatoryTosGate(true);
        setShowTermsModal(true);
      } else {
        setIsMandatoryTosGate(false);
        setShowTermsModal(false);
      }
    } else {
      setIsMandatoryTosGate(false);
      setShowTermsModal(false);
    }
  }, [isAuthenticated, currentUser?.id, currentUser?.email, currentUser?.hasSignedToS, currentUser?.tosSignedAt, currentRole]);

  // Map individual brand sidebar screens to the Brand Portal sub-tabs dynamically
  useEffect(() => {
    if (
      activeScreen === "briefing" ||
      activeScreen === "daily-briefing" ||
      activeScreen === "brand-briefing" ||
      activeScreen === "brand-dash"
    )
      setBrandActiveTab("briefing");
    else if (activeScreen === "brand-inquiries" || activeScreen === "inquiries")
      setBrandActiveTab("inquiries");
    else if (
      activeScreen === "brand-surveys" ||
      activeScreen === "brand-feedback" ||
      activeScreen === "surveys"
    )
      setBrandActiveTab("surveys");
    else if (
      activeScreen === "brand-billing" ||
      activeScreen === "pay-invoices" ||
      activeScreen === "billing"
    )
      setBrandActiveTab("billing");
    else if (
      activeScreen === "brand-support" ||
      activeScreen === "support"
    )
      setBrandActiveTab("support");
    else if (
      activeScreen === "brand-matchmaking" ||
      activeScreen === "creator-match" ||
      activeScreen === "matchmaking" ||
      activeScreen === "talent-showcase" ||
      activeScreen === "match-or-pass" ||
      activeScreen === "public-portfolio"
    )
      setBrandActiveTab("matchmaking");
    else if (
      activeScreen === "brand-review" ||
      activeScreen === "content-review" ||
      activeScreen === "review"
    )
      setBrandActiveTab("review");
    else if (
      activeScreen === "brand-vault" ||
      activeScreen === "contract-vault" ||
      activeScreen === "vault"
    )
      setBrandActiveTab("vault");
    else if (
      activeScreen === "brand-messages" ||
      activeScreen === "secure-messages" ||
      activeScreen === "messages"
    )
      setBrandActiveTab("messages");
    else if (
      activeScreen === "brand-training" ||
      activeScreen === "brand-playbook" ||
      activeScreen === "how-it-works" ||
      activeScreen === "training"
    )
      setBrandActiveTab("training");
  }, [activeScreen]);

  // Subdomain & White-Label Resolver + Stackable Toast Registry
  useEffect(() => {
    // 1. Setup global variable holding active client's unique database ID
    (window as any).currentAgencyId = "bloom_studio_default";

    // 2. Resolve white-label subdomain
    (window as any).resolveWhiteLabelSubdomain = () => {
      const hostname = window.location.hostname;
      const urlParams = new URLSearchParams(window.location.search);
      const querySubdomain =
        urlParams.get("subdomain") || urlParams.get("agency");

      let activeAgencyId = "bloom_studio_default";

      if (querySubdomain) {
        activeAgencyId = querySubdomain.toLowerCase();
      } else {
        const parts = hostname.split(".");
        // Extract subdomain if it exists (e.g. glowlab.localhost or glowlab.yourdomain.com)
        // Bypass temporary ais-dev and ais-pre system routing subdomains to allow proper default fallback
        if (
          parts.length > 2 &&
          parts[0] !== "www" &&
          !parts[0].includes("ais-dev") &&
          !parts[0].includes("ais-pre")
        ) {
          activeAgencyId = parts[0].toLowerCase();
        }
      }

      (window as any).currentAgencyId = activeAgencyId;
      console.log(
        `📡 System routing activated for Agency Workspace ID: [${activeAgencyId}]`,
      );
      (window as any).initializeWhiteLabelWorkspace(activeAgencyId);
    };

    // 3. Intercept database settings to paint CSS variables & enforce subscription status checks
    (window as any).initializeWhiteLabelWorkspace = (agencyId: string) => {
      const isBuiltInDemoTenant = agencyId === "bloom_studio_default" || agencyId === "main";

      const applyConfig = (config: any) => {
        if (!config) return;
        if (config.agencyName) setAgencyName(config.agencyName);
        if (config.legalEntityName) setLegalEntityName(config.legalEntityName);
        if (config.primaryBrandColor) setPrimaryBrandColor(config.primaryBrandColor);
        if (config.sidebarBgColor) setSidebarBgColor(config.sidebarBgColor);
        if (config.mainDashboardBg) setMainDashboardBg(config.mainDashboardBg);
        if (config.cardBgColor) setCardBgColor(config.cardBgColor);
        if (config.textMainColor) setTextMainColor(config.textMainColor);
        if (config.textMutedColor) setTextMutedColor(config.textMutedColor);
        if (config.agencyName) {
          document.title = `${config.agencyName} — Core Portal`;
        }
        const billing = config.billingProfile?.status || "active";
        setBillingStatus(billing);
      };

      const fallbackConfig =
        INITIAL_AGENCIES_DATA[agencyId] ||
        INITIAL_AGENCIES_DATA["bloom_studio_default"] ||
        INITIAL_AGENCIES_DATA["main"] ||
        Object.values(INITIAL_AGENCIES_DATA)[0] ||
        {};

      if (isBuiltInDemoTenant) {
        applyConfig(fallbackConfig);
        return;
      }

      try {
        const tenantRef = doc(db, "tenants", agencyId);
        onSnapshot(
          tenantRef,
          (snap) => {
            if (snap.exists()) {
              applyConfig(snap.data());
            } else {
              applyConfig(fallbackConfig);
            }
          },
          (err) => {
            console.warn("[initializeWhiteLabelWorkspace] Could not subscribe to tenant config, using fallback:", err);
            applyConfig(fallbackConfig);
          }
        );
      } catch (err) {
        console.warn("[initializeWhiteLabelWorkspace] Tenant config lookup failed, using fallback:", err);
        applyConfig(fallbackConfig);
      }
    };

    // 4. WIRE HOOK: Monitor incoming text streams dynamically for real notification feed
    (window as any).initiateIncomingMessageWatcher = (userId: string) => {
      console.log("📨 Real Message Watcher activated for user ID:", userId);

      // Clean stream shutdown
      (window as any).chatMessagesStream = () => {
        console.log(
          "🛑 Safe clean shutdown: Message Watcher stream terminated.",
        );
      };

      return () => {};
    };

    // 6. Register dynamic stackable popup chimes globally
    (window as any).launchLiveSystemToast = (
      title: string,
      description: string,
      alertType: string = "info",
    ) => {
      const stack = document.getElementById("toastNotificationStack");
      if (!stack) return;

      const toast = document.createElement("div");
      toast.className = "live-toast-alert";

      if (alertType === "danger") {
        toast.style.borderLeftColor = "#e63946";
      } else if (alertType === "success") {
        toast.style.borderLeftColor = "#10b981";
      } else if (alertType === "warning") {
        toast.style.borderLeftColor = "#f59e0b";
      } else if (
        alertType === "high_value" ||
        title.includes("💎") ||
        title.includes("High-Value")
      ) {
        toast.style.borderLeftColor = "#D4AF37";
        toast.style.boxShadow =
          "0 14px 40px rgba(212, 175, 55, 0.35), 0 4px 14px rgba(0, 0, 0, 0.6)";
        toast.style.background =
          "linear-gradient(135deg, #18233C 0%, #111A2E 100%)";
      } else {
        toast.style.borderLeftColor = primaryBrandColor || "#C9A46A";
      }

      const contentDiv = document.createElement("div");
      contentDiv.style.cssText = "flex: 1; text-align: left;";

      const titleEl = document.createElement("strong");
      titleEl.style.cssText = `color: ${alertType === "high_value" || title.includes("💎") ? "#F3E5AB" : "#ffffff"}; font-size: 13px; display: block; margin-bottom: 2px; font-weight: 600;`;
      titleEl.textContent = title;

      const descEl = document.createElement("span");
      descEl.style.cssText =
        "color: #94a3b8; font-size: 11px; line-height: 1.35; display: block;";
      descEl.textContent = description;

      contentDiv.appendChild(titleEl);
      contentDiv.appendChild(descEl);

      const closeBtn = document.createElement("button");
      closeBtn.style.cssText =
        "background: transparent; border: none; color: #8892b0; cursor: pointer; font-size: 16px; padding: 0 2px; line-height: 1; outline: none; margin-left: 8px;";
      closeBtn.textContent = "\u00d7";
      closeBtn.onclick = () => toast.remove();

      toast.appendChild(contentDiv);
      toast.appendChild(closeBtn);

      stack.appendChild(toast);

      // Play audio chime safely
      try {
        const AudioCtx =
          window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          const oscillator = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();
          oscillator.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          oscillator.type = "sine";
          if (alertType === "high_value" || title.includes("💎")) {
            // High-value contract executive dual harmonic alert
            oscillator.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
            oscillator.frequency.setValueAtTime(
              880.0,
              audioCtx.currentTime + 0.09,
            ); // A5
            gainNode.gain.setValueAtTime(0.06, audioCtx.currentTime);
            oscillator.start();
            oscillator.stop(audioCtx.currentTime + 0.26);
          } else {
            oscillator.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5 note chime
            gainNode.gain.setValueAtTime(0.04, audioCtx.currentTime);
            oscillator.start();
            oscillator.stop(audioCtx.currentTime + 0.12);
          }
        }
      } catch (e) {
        /* Context block catch */
      }

      // Auto fadeout (longer duration for high value alerts to allow reading)
      const fadeTimeout =
        alertType === "high_value" || title.includes("💎") ? 8000 : 5000;
      setTimeout(() => {
        toast.style.animation = "fadeOutNotification 0.4s ease forwards";
        setTimeout(() => toast.remove(), 400);
      }, fadeTimeout);
    };

    // Execute resolving on mount
    (window as any).resolveWhiteLabelSubdomain();

    window.addEventListener(
      "DOMContentLoaded",
      (window as any).resolveWhiteLabelSubdomain,
    );
    return () => {
      window.removeEventListener(
        "DOMContentLoaded",
        (window as any).resolveWhiteLabelSubdomain,
      );
      if ((window as any).chatMessagesStream) {
        (window as any).chatMessagesStream();
      }
    };
  }, [primaryBrandColor]);

  // Check for public portfolio, brand sharing, or sneak peek hash on URL navigation
  useEffect(() => {
    const checkUrlRouting = () => {
      if (typeof window !== "undefined") {
        const hash = window.location.hash.toLowerCase();
        const search = window.location.search.toLowerCase();
        const pathname = window.location.pathname.toLowerCase();
        if (
          hash === "#sneak-peek" ||
          hash.includes("match-pass") ||
          hash.includes("casting") ||
          search.includes("mode=sneak-peek")
        ) {
          setActiveScreen("match-or-pass");
        } else if (
          hash.includes("showcase") ||
          hash.includes("talent-showcase") ||
          pathname.includes("showcase") ||
          search.includes("showcase")
        ) {
          setActiveScreen("talent-showcase");
        } else if (
          hash.includes("public-portfolio") ||
          hash.includes("portfolio") ||
          pathname.includes("portfolio") ||
          hash.startsWith("#kit-") ||
          search.includes("public-portfolio") ||
          (search.includes("brand=true") && (search.includes("creator=") || hash.includes("creator=")))
        ) {
          setActiveScreen("public-portfolio");
        } else if (
          search.includes("brand-room=true")
        ) {
          const urlParams = new URLSearchParams(window.location.search);
          const token = urlParams.get('token');
          const deliverableId = urlParams.get('deliverable');
          const brandName = urlParams.get('brand');
          const subagency = urlParams.get('subagency') || 'pod_main';

          // Security: DO NOT automatically log in or jump inside the portal.
          // Require Agency Name & Access Link verification.
          setPendingBrandAccess({
            token: token || undefined,
            deliverableId: deliverableId || undefined,
            brandName: brandName ? decodeURIComponent(brandName) : undefined,
            subagency: decodeURIComponent(subagency),
            url: window.location.href
          });
          setShowBrandPartnerModal(true);
        }
      }
    };
    checkUrlRouting();
    window.addEventListener("hashchange", checkUrlRouting);
    const handleOpenSignup = () => setShowAgencySignup(true);
    window.addEventListener("open-agency-signup", handleOpenSignup);
    return () => {
      window.removeEventListener("hashchange", checkUrlRouting);
      window.removeEventListener("open-agency-signup", handleOpenSignup);
    };
  }, []);

  // Simulate Firebase auth subscription listener for session synchronization
  useEffect(() => {
    if (isAuthenticated && currentUser) {
      const userUID =
        currentUser.handle || currentUser.name || "user_uid_default";
      console.log("User authenticated successfully:", userUID);

      // Fire up the live notification engine for this specific user session
      if ((window as any).initiateIncomingMessageWatcher) {
        (window as any).initiateIncomingMessageWatcher(userUID);
      }
    } else {
      console.log("User session detached. Awaiting auth state change.");
      if ((window as any).chatMessagesStream) {
        (window as any).chatMessagesStream();
      }
    }
  }, [isAuthenticated, currentUser]);

  // Sync state transitions or triggers to launch global live chimes
  const runAgencyDatabaseMaintenance = async () => {
    console.log("🧹 Initializing database archival protocol...");

    // Filter completed tasks
    const completedItems = actionQueue.filter((aq) => aq.isCompleted);
    const completedCount = completedItems.length;

    if (completedCount > 0) {
      setActionQueue((prev) => prev.filter((aq) => !aq.isCompleted));
      handleAddActivityLog(
        currentUser?.name || "User",
        currentRole,
        `🧹 SYSTEM MAINTENANCE: Archived and cleared ${completedCount} completed tasks to secondary historical data archives.`,
      );

      if ((window as any).launchLiveSystemToast) {
        (window as any).launchLiveSystemToast(
          "🧹 System Cleaned",
          `Archived and cleared ${completedCount} completed items successfully.`,
          "success",
        );
      }
    } else {
      if ((window as any).launchLiveSystemToast) {
        (window as any).launchLiveSystemToast(
          "🧹 Clean Completed",
          "No records met current database archival cleanup criteria.",
          "info",
        );
      }
    }
  };

  // --- Creator Management ---
  const [creators, setCreators] = useState<Creator[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_creators");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Failed to parse saved creators:", e);
    }
    return [
      {
        id: "c_alexjones",
        handle: "@alexjones",
        name: "Alex Jones",
        email: "alex@bloompartners.com",
        phone: "+13105550191",
        smsConsent: true,
        platform: "TikTok & Instagram",
        niche: "Fitness & Lifestyle",
        followers: "850K",
        eng: "4.8%",
        agreement: "Exclusive (80%)",
        agreementType: "Exclusive",
        status: "Active",
        subagency: "Bloom & Co",
        agency: "Bloom & Co"
      },
      {
        id: "c_kaylalooks",
        handle: "@kaylalooks",
        name: "Kayla Laurent",
        email: "kayla@bloompartners.com",
        phone: "+13055550192",
        smsConsent: true,
        platform: "Instagram & YouTube",
        niche: "Beauty & Fashion",
        followers: "1.2M",
        eng: "5.2%",
        agreement: "Exclusive (80%)",
        agreementType: "Exclusive",
        status: "Active",
        subagency: "Bloom & Co",
        agency: "Bloom & Co"
      },
      {
        id: "c_shopwithsoph",
        handle: "@shopwithsoph",
        name: "Sophia Wells",
        email: "sophia@bloompartners.com",
        phone: "+12125550193",
        smsConsent: true,
        platform: "TikTok",
        niche: "UGC & Consumer Tech",
        followers: "420K",
        eng: "6.1%",
        agreement: "Non-Exclusive (70%)",
        agreementType: "Non-Exclusive",
        status: "Active",
        subagency: "Bloom & Co",
        agency: "Bloom & Co"
      }
    ];
  });

  useEffect(() => {
    safeStorage.setItem("wl_creators", JSON.stringify(creators));
  }, [creators]);

  // --- Chat System Threads State ---
  const [threads, setThreads] = useState<Thread[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_threads");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Failed to parse saved threads:", e);
    }
    return [
      {
        id: "th_general_broadcast",
        name: "Agency Broadcast Channel",
        role: "All Agency",
        handle: "@everyone",
        messages: [
          {
            id: "m_welcome",
            from: "other",
            senderRole: "director",
            senderName: "Marcus Cole (Director)",
            text: "Official Agency Directives & Announcements Gateway. Real-time announcements from director desks will be mirrored here.",
            time: "09:00 AM"
          }
        ]
      },
      {
        id: "th_alexjones",
        name: "Alex Jones",
        role: "Creator",
        handle: "@alexjones",
        creator: "@alexjones",
        messages: [
          {
            id: "m_alex_1",
            from: "other",
            senderRole: "creator",
            senderName: "Alex Jones",
            text: "Hi team! Checked my schedule for the upcoming brand deliverables.",
            time: "10:15 AM"
          }
        ]
      }
    ];
  });

  useEffect(() => {
    safeStorage.setItem("wl_threads", JSON.stringify(threads));
  }, [threads]);

  // Real-time Firestore sync for studio-threads and studio-messages
  useEffect(() => {
    let unsubscribeThreads = () => {};
    let unsubscribeMessages = () => {};

    try {
      if (!isAuthenticated) return;
      const isStaff = ['director', 'agentmgr', 'agent', 'coordinator', 'subagency', 'owner', 'admin', 'agency'].includes((currentRole || '').toLowerCase());
      const uId = currentUser?.id || currentUser?.uid || "none";
      const cHandle = currentUser?.handle || currentUser?.email || "none";
      const cName = currentUser?.name || "none";
      const rawHandle = cHandle.replace('@', '');

      let threadsQuery;
      if (isStaff) {
        // Pod isolation for staff: ONLY true platform-owner sees all threads; sub-agency directors & staff only see their pod
        const isPlatformOwner = !!currentUser?.isPlatformOwner;
        if (isPlatformOwner) {
          threadsQuery = collection(db, "studio-threads");
        } else {
          threadsQuery = query(
            collection(db, "studio-threads"),
            where("subagency", "==", currentUser?.subagency || "pod_main")
          );
        }
      } else {
        threadsQuery = query(
          collection(db, "studio-threads"),
          or(
            where("ownerUid", "==", uId),
            where("handle", "==", cHandle),
            where("name", "==", cHandle),
            where("name", "==", cName),
            where("id", "==", "th_general_broadcast"),
            where("id", "==", `th_${rawHandle}`),
            where("id", "==", `th_${uId}`)
          )
        );
      }

      unsubscribeThreads = onSnapshot(
        threadsQuery,
        (snapshot) => {
          setThreads(prev => {
            let updated = [...prev];
            let changed = false;
            snapshot.forEach(docSnap => {
              const data = docSnap.data();
              const existingIndex = updated.findIndex(t => t.id === docSnap.id);
              if (existingIndex >= 0) {
                if (updated[existingIndex].name !== data.name) {
                  updated[existingIndex] = { ...updated[existingIndex], ...data, id: docSnap.id };
                  changed = true;
                }
              } else {
                updated.push({ ...data, id: docSnap.id, messages: [] } as any);
                changed = true;
              }
            });
            return changed ? updated : prev;
          });
        },
        (err) => {
          console.warn("[studio-threads] Real-time subscription error:", err);
        }
      );

      if (isStaff) {
        const isPlatformOwner = !!currentUser?.isPlatformOwner;
        const msgColRef = collection(db, "studio-messages");
        const messagesQuery = isPlatformOwner 
          ? msgColRef 
          : query(msgColRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

        unsubscribeMessages = onSnapshot(
          messagesQuery,
          (snapshot) => {
            setThreads(prev => {
              let updated = [...prev];
              let changed = false;
              snapshot.forEach(docSnap => {
                const data = docSnap.data();
                const threadId = data.threadId;
                const tIndex = updated.findIndex(t => t.id === threadId);
                if (tIndex >= 0) {
                  const msgExists = updated[tIndex].messages.some(m => m.id === docSnap.id);
                  if (!msgExists) {
                    updated[tIndex] = {
                      ...updated[tIndex],
                      messages: [...updated[tIndex].messages, { ...data, id: docSnap.id } as any]
                    };
                    changed = true;
                  }
                }
              });
              return changed ? updated : prev;
            });
          },
          (err) => {
            console.warn("[studio-messages] Real-time subscription error:", err);
          }
        );
      }
    } catch(e) {
      console.warn("Failed to subscribe to chat threads", e);
    }
    
    return () => {
      unsubscribeThreads();
      unsubscribeMessages();
    };
  }, [isAuthenticated, currentUser, currentRole]);

  // For non-staff, subscribe to messages for discovered threads
  useEffect(() => {
    const isStaff = ['director', 'agentmgr', 'agent', 'coordinator', 'subagency', 'owner', 'admin', 'agency'].includes((currentRole || '').toLowerCase());
    if (isStaff || threads.length === 0) return;

    const unsubscribes = threads.map(t => {
      const q = query(collection(db, "studio-messages"), where("threadId", "==", t.id));
      return onSnapshot(
        q,
        (snapshot) => {
          setThreads(prev => {
            let updated = [...prev];
            let changed = false;
            snapshot.forEach(docSnap => {
              const data = docSnap.data();
              const tIndex = updated.findIndex(existing => existing.id === t.id);
              if (tIndex >= 0) {
                const msgExists = updated[tIndex].messages.some(m => m.id === docSnap.id);
                if (!msgExists) {
                  updated[tIndex] = {
                    ...updated[tIndex],
                    messages: [...updated[tIndex].messages, { ...data, id: docSnap.id } as any]
                  };
                  changed = true;
                }
              }
            });
            return changed ? updated : prev;
          });
        },
        (err) => {
          console.warn(`[studio-messages thread ${t.id}] Subscription error:`, err);
        }
      );
    });

    return () => unsubscribes.forEach(u => u());
  }, [threads.map(t => t.id).join(','), currentRole]);

  const handleSendMessage = async (threadId: string, text: string, attachment?: any) => {
    const newMsg: Message = {
      id: `m_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      from: "me",
      senderRole: currentRole,
      senderName: currentUser?.name || (currentRole === "director" ? "Marcus Cole (Director)" : "User"),
      text,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      attachment
    };
    
    setThreads((prev) =>
      prev.map((t) =>
        t.id === threadId ? { ...t, messages: [...t.messages, newMsg] } : t
      )
    );

    try {
      const thread = threads.find(t => t.id === threadId);
      await setDoc(doc(db, "studio-messages", newMsg.id), {
        ...newMsg,
        threadId,
        createdAt: new Date().toISOString(),
        senderUid: currentUser?.id || currentUser?.uid || "unknown",
        subagency: currentUser?.subagency || "pod_main",
        tenantId: currentUser?.tenantId || "bloom_studio_default",
        participantIds: thread?.participantIds || [currentUser?.id || currentUser?.uid || "unknown"]
      });
    } catch (e) {
      console.warn("Error saving message to Firestore:", e);
    }
  };

  const handleAddThread = async (name: string, role: string, handle?: string) => {
    // Attempt to find the recipient's UID if they are a creator
    let recipientUid = "unknown";
    if (handle) {
      const creator = creators.find(c => c.handle === handle || c.id === handle);
      if (creator) recipientUid = creator.id;
    } else {
      const creator = creators.find(c => c.name === name);
      if (creator) recipientUid = creator.id;
    }

    const myUid = currentUser?.id || currentUser?.uid || "unknown";
    const participantIds = [myUid];
    if (recipientUid !== "unknown" && recipientUid !== myUid) {
      participantIds.push(recipientUid);
    }

    const newThread: Thread = {
      id: `th_${Date.now()}`,
      name,
      role,
      handle,
      messages: [],
      participantIds
    };
    setThreads((prev) => [newThread, ...prev]);

    try {
      await setDoc(doc(db, "studio-threads", newThread.id), {
        ...newThread,
        createdAt: new Date().toISOString(),
        ownerUid: myUid,
        subagency: currentUser?.subagency || "pod_main",
        tenantId: currentUser?.tenantId || "bloom_studio_default",
        participantIds
      });
    } catch (e) {
      console.warn("Error saving thread to Firestore:", e);
    }
    return newThread.id;
  };

  const handleDeleteThread = async (threadId: string) => {
    setThreads((prev) => {
      const updated = prev.filter((t) => t.id !== threadId);
      safeStorage.setItem("wl_threads", JSON.stringify(updated));
      return updated;
    });
    try {
      await deleteDoc(doc(db, "studio-threads", threadId));
      // Delete all child messages associated with this thread
      const msgSnap = await getDocs(query(collection(db, "studio-messages"), where("threadId", "==", threadId)));
      const deletePromises = msgSnap.docs.map((d) => deleteDoc(d.ref));
      await Promise.all(deletePromises);
    } catch (e) {
      console.warn("Error deleting thread from Firestore:", e);
    }
  };

  // --- Deal Management ---
  const [deals, setDeals] = useState<Deal[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_deals");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    safeStorage.setItem("wl_deals", JSON.stringify(deals));
  }, [deals]);

  // --- Mission Management ---
  const [missions, setMissions] = useState<Mission[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_missions");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    safeStorage.setItem("wl_missions", JSON.stringify(missions));
  }, [missions]);

  // --- Notification Management ---
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // --- Idle-Session Timeout Management ---
  const [idleWarningOpen, setIdleWarningOpen] = useState(false);
  const [idleSecondsRemaining, setIdleSecondsRemaining] = useState(60);

  useEffect(() => {
    if (!isAuthenticated) return;

    let inactivityTimer: any;
    let warningTimer: any;
    let countdownInterval: any;

    const IDLE_LIMIT_MS = 15 * 60 * 1000; // 15 minutes
    const WARNING_BEFORE_MS = 60 * 1000; // 1 minute warning

    const resetTimers = () => {
      clearTimeout(inactivityTimer);
      clearTimeout(warningTimer);
      clearInterval(countdownInterval);
      setIdleWarningOpen(false);

      warningTimer = setTimeout(() => {
        setIdleSecondsRemaining(60);
        setIdleWarningOpen(true);
        countdownInterval = setInterval(() => {
          setIdleSecondsRemaining((prev) => {
            if (prev <= 1) {
              clearInterval(countdownInterval);
              handleLogout();
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
      }, IDLE_LIMIT_MS - WARNING_BEFORE_MS);

      inactivityTimer = setTimeout(() => {
        handleLogout();
      }, IDLE_LIMIT_MS);
    };

    const activityEvents = ['mousemove', 'keydown', 'mousedown', 'touchstart', 'scroll'];
    activityEvents.forEach((ev) => window.addEventListener(ev, resetTimers));

    resetTimers();

    return () => {
      clearTimeout(inactivityTimer);
      clearTimeout(warningTimer);
      clearInterval(countdownInterval);
      activityEvents.forEach((ev) => window.removeEventListener(ev, resetTimers));
    };
  }, [isAuthenticated]);

  // --- Referrals Management ---
  const [referrals, setReferrals] = useState<Referral[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_referrals");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [
      {
        id: 'ref_001',
        referrer: '@elenarostova',
        referrerName: 'Elena Rostova',
        type: 'Creator',
        what: 'Beauty & Skincare',
        newclient: 'Chloe Bennett (@chloeglows)',
        referredCreatorName: 'Chloe Bennett',
        referredCreatorHandle: '@chloeglows',
        value: 500,
        reward: 'Roster Referral',
        date: '2026-08-14',
        status: 'Paid',
        notes: 'Referred Chloe Bennett for beauty campaigns.'
      },
      {
        id: 'ref_002',
        referrer: '@kai_lifestyle',
        referrerName: 'Kai Lindqvist',
        type: 'Creator',
        what: 'Fitness & Lifestyle',
        newclient: 'Marcus Brody (@brody_wellness)',
        referredCreatorName: 'Marcus Brody',
        referredCreatorHandle: '@brody_wellness',
        value: 750,
        reward: '$750.00 Director Bonus',
        date: '2026-08-20',
        status: 'Approved',
        notes: 'Referred Marcus Brody for wellness roster.'
      },
      {
        id: 'ref_003',
        referrer: '@golden_leo',
        referrerName: 'Leo & Chloe',
        type: 'Creator',
        what: 'Pets & Animals',
        newclient: 'Maya Lin (@maya_pets)',
        referredCreatorName: 'Maya Lin',
        referredCreatorHandle: '@maya_pets',
        value: 350,
        reward: '$350.00 Director Bonus',
        date: '2026-09-01',
        status: 'Pending review',
        notes: 'Inbound referral awaiting final director bonus payout.'
      }
    ];
  });
  const [contentLibrary, setContentLibrary] = useState<any[]>([]);
  const [repurposingLogs, setRepurposingLogs] = useState<any[]>([]);

  // Real-time Firestore sync for studio-referrals
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-referrals");
    const q = isPlatformOwner 
      ? colRef 
      : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: Referral[] = [];
      snapshot.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() } as Referral);
      });
      setReferrals(items);
      safeStorage.setItem("wl_referrals", JSON.stringify(items));
    }, (err) => {
      console.warn("[studio-referrals] onSnapshot error:", err);
    });
    return () => unsubscribe();
  }, [isAuthenticated, currentUser]);

  // Real-time Firestore sync for studio-content-library
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-content-library");
    const q = isPlatformOwner 
      ? colRef 
      : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() });
      });
      setContentLibrary(items);
      safeStorage.setItem("wl_content_library_assets", JSON.stringify(items));
    }, (err) => {
      console.warn("[studio-content-library] onSnapshot error:", err);
    });
    return () => unsubscribe();
  }, [isAuthenticated, currentUser]);

  // Real-time Firestore sync for studio-repurposing-logs
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-repurposing-logs");
    const q = isPlatformOwner 
      ? colRef 
      : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items: any[] = [];
      snapshot.forEach((docSnap) => {
        items.push({ id: docSnap.id, ...docSnap.data() });
      });
      setRepurposingLogs(items);
      safeStorage.setItem("wl_rejected_content_log", JSON.stringify(items));
    }, (err) => {
      console.warn("[studio-repurposing-logs] onSnapshot error:", err);
    });
    return () => unsubscribe();
  }, [isAuthenticated, currentUser]);

  useEffect(() => {
    safeStorage.setItem("wl_referrals", JSON.stringify(referrals));
  }, [referrals]);

  const handleAddReferral = async (newRef: Referral) => {
    setReferrals(prev => [newRef, ...prev]);
    try {
      safeStorage.setItem("wl_referrals", JSON.stringify([newRef, ...referrals]));
    } catch {}

    try {
      const referralPayload = cleanUndefinedForFirestore({
        ...newRef,
        createdAt: new Date().toISOString(),
        creatorId: (newRef as any).creatorId || currentUser?.id || currentUser?.uid || auth.currentUser?.uid || 'creator_guest',
        subagency: (newRef as any).subagency || currentUser?.subagency || "pod_main",
        tenantId: (newRef as any).tenantId || currentUser?.tenantId || "bloom_studio_default"
      });
      await setDoc(doc(db, "studio-referrals", newRef.id), referralPayload, { merge: true });
    } catch (err) {
      console.warn("[handleAddReferral] Firestore write error:", err);
    }

    triggerSimulatedNotification(
      'Creator Referral Logged',
      `Referral for ${newRef.newclient} submitted to Agency Director for bonus determination.`,
      'success'
    );
    handleAddActivityLog(
      currentUser?.name || newRef.referrer || 'Creator',
      'creator',
      `Submitted creator referral: ${newRef.newclient}`
    );
  };

  const handleUpdateReferral = async (updatedRef: Referral) => {
    setReferrals(prev => prev.map(r => r.id === updatedRef.id ? updatedRef : r));
    try {
      safeStorage.setItem("wl_referrals", JSON.stringify(referrals.map(r => r.id === updatedRef.id ? updatedRef : r)));
    } catch {}

    try {
      const updatePayload = cleanUndefinedForFirestore({
        ...updatedRef,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser?.name || 'Director',
        subagency: (updatedRef as any).subagency || currentUser?.subagency || "pod_main",
        tenantId: (updatedRef as any).tenantId || currentUser?.tenantId || "bloom_studio_default"
      });
      await setDoc(doc(db, "studio-referrals", updatedRef.id), updatePayload, { merge: true });
    } catch (err) {
      console.warn("[handleUpdateReferral] Firestore write error:", err);
    }

    triggerSimulatedNotification(
      'Referral Bonus Set',
      `Bonus for ${updatedRef.newclient} set to $${(updatedRef.value || 0).toLocaleString()} USD by Director.`,
      'success'
    );
    handleAddActivityLog(
      currentUser?.name || 'Director',
      currentRole || 'director',
      `Director updated referral bonus for ${updatedRef.newclient}: $${updatedRef.value || 0} (${updatedRef.status})`
    );
  };

  // --- Missing State & Functions ---
  const [inboundLeads, setInboundLeads] = useState<any[]>(() => {
    try {
      const saved1 = safeStorage.getItem("wl_inbound_leads");
      const saved2 = safeStorage.getItem("bloom_inbound_leads");
      const parsed1 = saved1 ? JSON.parse(saved1) : [];
      const parsed2 = saved2 ? JSON.parse(saved2) : [];
      const combined = [...parsed1, ...parsed2.filter((p: any) => !parsed1.some((x: any) => x.id === p.id || x.brandName === p.brandName))];
      if (combined.length === 0) {
        return [
          {
            id: "sample_lead_1",
            brandName: "Acme Luxury Co.",
            contactEmail: "partnerships@acmeluxury.com",
            targetedVertical: "Fashion & Lifestyle",
            budgetScope: "$25,000 - $50,000",
            campaignNotes: "Looking to partner with top creator talent for our upcoming Spring luxury drop campaign.",
            source: "Public Talent Showcase",
            status: "New",
            submittedAt: new Date(Date.now() - 3600000).toISOString()
          }
        ];
      }
      return combined;
    } catch {
      return [
        {
          id: "sample_lead_1",
          brandName: "Acme Luxury Co.",
          contactEmail: "partnerships@acmeluxury.com",
          targetedVertical: "Fashion & Lifestyle",
          budgetScope: "$25,000 - $50,000",
          campaignNotes: "Looking to partner with top creator talent for our upcoming Spring luxury drop campaign.",
          source: "Public Talent Showcase",
          status: "New",
          submittedAt: new Date(Date.now() - 3600000).toISOString()
        }
      ];
    }
  });

  const [waitlistEntries, setWaitlistEntries] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_waitlist_entries");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [actionQueue, setActionQueue] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_activity_logs");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      safeStorage.setItem("wl_activity_logs", JSON.stringify(activityLogs));
    } catch {}
  }, [activityLogs]);
  const [phoneNotifications, setPhoneNotifications] = useState<SimulatedNotification[]>([]);
  const [rosterViewMode, setRosterViewMode] = useState<'table' | 'heatmap' | 'profiles'>('table');
  const INITIAL_CONTRACTS_SEED: Contract[] = [];

  const [contracts, setContracts] = useState<Contract[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_contracts");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Failed to parse local contracts:", e);
    }
    return INITIAL_CONTRACTS_SEED;
  });
  const [selectedCreatorIds, setSelectedCreatorIds] = useState<string[]>([]);
  const [assignAgentSelectedCreator, setAssignAgentSelectedCreator] = useState<string | null>(null);
  const [contentReviewsList, setContentReviewsList] = useState<ReviewItem[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_content_reviews");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Failed to parse content reviews:", e);
    }
    return DEFAULT_CONTENT_REVIEWS;
  });

  useEffect(() => {
    safeStorage.setItem("wl_content_reviews", JSON.stringify(contentReviewsList));
  }, [contentReviewsList]);

  // Real-time Firestore sync for studio-content-reviews
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-content-reviews");
    const q = isPlatformOwner 
      ? colRef 
      : currentRole === "creator"
        ? query(colRef, where("creator", "==", currentUser?.handle || "@creator"))
        : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: ReviewItem[] = [];
        snapshot.forEach(docSnap => {
          items.push({ ...docSnap.data(), id: docSnap.id } as ReviewItem);
        });
        if (items.length > 0) {
          setContentReviewsList(items);
          safeStorage.setItem("wl_content_reviews", JSON.stringify(items));
        }
      },
      (err) => {
        console.warn("[studio-content-reviews] onSnapshot error in App.tsx:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentRole, currentUser]);

  // Requirement: Global Auto-Approval Checker
  // If Brand Partners don't review in two days, it is automatically marked approved.
  useEffect(() => {
    const checkAutoApprovals = () => {
      const now = Date.now();
      let hasChanges = false;
      const updatedList = contentReviewsList.map(r => {
        if (r.status === 'Approved' || r.status === 'Approved with Warning') {
          if (r.brandReviewStartedAt && r.brandReviewStatus !== 'Auto Approved') {
            const startTime = new Date(r.brandReviewStartedAt).getTime();
            const twoDaysInMs = 2 * 24 * 60 * 60 * 1000;
            
            if (now - startTime >= twoDaysInMs) {
              hasChanges = true;
              return {
                ...r,
                status: 'Posted' as const,
                brandReviewStatus: 'Auto Approved' as const,
                brandReviewCompletedAt: new Date().toISOString()
              };
            }
          }
        }
        return r;
      });

      if (hasChanges) {
        setContentReviewsList(updatedList);
      }
    };

    const interval = setInterval(checkAutoApprovals, 60000); // Check every minute
    checkAutoApprovals(); // Initial check
    return () => clearInterval(interval);
  }, [contentReviewsList]);

  const triggerSimulatedNotification = (title: string, detail: string, type: 'info' | 'warning' | 'success' | 'danger' = 'info') => {
    const newNote: AppNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      title,
      detail,
      type,
      created: new Date().toISOString(),
      read: false,
    };
    setNotifications((prev) => [newNote, ...prev].slice(0, 50));
  };

  const handleAddActivityLog = (user: string, role: string, action: string) => {
    const newItem: ActivityLogItem = {
      id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      user,
      role,
      action,
      timestamp: new Date().toISOString(),
    };
    setActivityLogs((prev) => [newItem, ...prev].slice(0, 200));

    // Also persist to Firestore studio-activity-log collection
    try {
      const docRef = doc(db, "studio-activity-log", newItem.id);
      setDoc(docRef, cleanForFirestore({
        ...newItem,
        subagency: currentUser?.subagency || activeTenantConfig?.agencyName || "pod_main",
        tenantId: activeTenantConfig?.agencyName || "bloom_studio_default"
      }), { merge: true }).catch(err => {
        console.warn("Error writing activity log to Firestore:", err);
      });
    } catch (e) {
      console.warn("Error dispatching activity log:", e);
    }
  };

  const checkUserExplicitlyBelongsToPod = (user: any, podId: string, podName: string): boolean => {
    if (!user) return false;
    const targetId = (podId || '').trim().toLowerCase();
    const targetName = (podName || '').trim().toLowerCase();

    const explicitBelongList: string[] = [];
    if (Array.isArray(user.authorizedPods)) {
      explicitBelongList.push(...user.authorizedPods);
    }
    if (Array.isArray(user.authorizedSubagencies)) {
      explicitBelongList.push(...user.authorizedSubagencies);
    }
    if (typeof user.authorizedPods === 'string') {
      explicitBelongList.push(...user.authorizedPods.split(',').map((s: string) => s.trim()));
    }
    if (typeof user.authorizedSubagencies === 'string') {
      explicitBelongList.push(...user.authorizedSubagencies.split(',').map((s: string) => s.trim()));
    }
    if (user.homePod) explicitBelongList.push(user.homePod);
    if (user.assignedPod) explicitBelongList.push(user.assignedPod);
    if (user.homeSubagency) explicitBelongList.push(user.homeSubagency);
    if (user.assignedSubagency) explicitBelongList.push(user.assignedSubagency);

    // If no explicit list is configured, default to their initial assigned desk or pod_main
    if (explicitBelongList.length === 0) {
      if (user.subagency) explicitBelongList.push(user.subagency);
      if (user.subagencyName) explicitBelongList.push(user.subagencyName);
      if (user.pod) explicitBelongList.push(user.pod);
      if (user.tenantId) explicitBelongList.push(user.tenantId);
      if (explicitBelongList.length === 0) {
        explicitBelongList.push('pod_main', 'Bloom & Co');
      }
    }

    return explicitBelongList.some((item: string) => {
      const s = (item || '').trim().toLowerCase();
      return (
        s === targetId ||
        s === targetName ||
        ((targetId === 'pod_main' || targetId === 'main') && (s === 'bloom & co' || s === 'main agency')) ||
        (targetName === 'bloom & co' && (s === 'pod_main' || s === 'main'))
      );
    });
  };

  const handleSwitchWorkPod = (podId: string, podName: string) => {
    if (!currentUser) return;

    const isDirector =
      (currentRole || '').toLowerCase() === 'director' ||
      Boolean(currentUser?.isPlatformOwner) ||
      (currentRole || '').toLowerCase() === 'owner';

    const userExplicitBelongs = checkUserExplicitlyBelongsToPod(currentUser, podId, podName);

    // Automated permission check: ONLY users with the 'director' role can switch into pods they don't explicitly belong to
    if (!userExplicitBelongs && !isDirector) {
      handleAddActivityLog(
        currentUser.name || currentUser.email || "Staff User",
        currentRole,
        `SECURITY VIOLATION: Blocked unauthorized attempt to switch into unassigned work pod: ${podName} (${podId})`
      );
      triggerSimulatedNotification(
        "Permission Denied",
        "Only users with the Director role can switch into work pods they don't explicitly belong to.",
        "danger"
      );
      return;
    }

    const updatedUser = {
      ...currentUser,
      subagency: podName,
      subagencyName: podName,
      pod: podId,
      tenantId: podId,
    };

    setCurrentUser(updatedUser);
    safeStorage.setItem("wl_currentUser", JSON.stringify(updatedUser));

    // Dispatch global event for real-time listeners across components
    window.dispatchEvent(
      new CustomEvent("wl_workpod_switched", { detail: { podId, podName } })
    );

    // Log security-audited activity
    handleAddActivityLog(
      currentUser.name || currentUser.email || "Staff User",
      currentRole,
      `Switched active work pod to: ${podName} (${isDirector && !userExplicitBelongs ? 'Director Cross-Pod Oversight' : 'Assigned Desk'})`
    );

    triggerSimulatedNotification(
      "Active Pod Switched",
      `Active desk switched to "${podName}". Scoped creators, deals, and finances are now loaded.`,
      "success"
    );
  };

  // Automated permission check in App state:
  // Ensures that only users with the 'director' role can operate in or switch into pods they don't explicitly belong to.
  // If a non-director is detected in an unassigned pod, automatically re-scope/revert them back to their assigned home pod.
  useEffect(() => {
    if (!isAuthenticated || !currentUser || currentRole === "none") return;

    const isDirector =
      (currentRole || '').toLowerCase() === 'director' ||
      Boolean(currentUser?.isPlatformOwner) ||
      (currentRole || '').toLowerCase() === 'owner';

    // Directors have permission to view all registered pods
    if (isDirector) return;

    const activePodId = (currentUser?.pod || currentUser?.tenantId || "pod_main").trim();
    const activePodName = (currentUser?.subagency || currentUser?.subagencyName || "Bloom & Co").trim();

    const explicitlyBelongs = checkUserExplicitlyBelongsToPod(currentUser, activePodId, activePodName);

    if (!explicitlyBelongs) {
      const homePodId =
        currentUser?.homePod ||
        (Array.isArray(currentUser?.authorizedPods) && currentUser.authorizedPods[0]) ||
        currentUser?.assignedPod ||
        "pod_main";

      const homePodName =
        currentUser?.homeSubagency ||
        (Array.isArray(currentUser?.authorizedSubagencies) && currentUser.authorizedSubagencies[0]) ||
        "Bloom & Co";

      console.warn(
        `[WorkPod Automated Security Enforcement] User ${currentUser.email || currentUser.name} (${currentRole}) lacks Director privileges for unassigned pod "${activePodName}". Automatically resetting to home pod "${homePodName}".`
      );

      const securedUser = {
        ...currentUser,
        pod: homePodId,
        tenantId: homePodId,
        subagency: homePodName,
        subagencyName: homePodName,
      };

      setCurrentUser(securedUser);
      safeStorage.setItem("wl_currentUser", JSON.stringify(securedUser));

      window.dispatchEvent(
        new CustomEvent("wl_workpod_switched", { detail: { podId: homePodId, podName: homePodName } })
      );

      handleAddActivityLog(
        currentUser.name || currentUser.email || "Staff User",
        currentRole,
        `Automated security: Reverted unauthorized work pod "${activePodName}" to assigned home pod "${homePodName}"`
      );

      triggerSimulatedNotification(
        "Work Pod Auto-Secured",
        `As a ${currentRole}, your workspace is strictly scoped to your assigned desk "${homePodName}". Only users with the Director role can access other pods.`,
        "warning"
      );
    }
  }, [currentRole, currentUser?.pod, currentUser?.tenantId, currentUser?.subagency, isAuthenticated]);

  const isRestrictedRole = useMemo(() => ["creator", "brand"].includes(currentRole), [currentRole]);
  const isAgentMgr = useMemo(() => currentRole === "agentmgr", [currentRole]);
  const myHandles = useMemo(() => [currentUser?.handle || ""], [currentUser]);

  const handleSaveReviewItem = async (item: ReviewItem) => {
    const prepared = prepareReviewItemForFirestore(item);
    setContentReviewsList((prev) => prev.map(r => r.id === prepared.id ? prepared : r));
    const subagency = (prepared as any).subagency || currentUser?.subagency || "pod_main";
    const tenantId = (prepared as any).tenantId || currentUser?.tenantId || "pod_main";

    try {
      await setDoc(doc(db, "studio-content-reviews", prepared.id), cleanForFirestore({
        ...prepared,
        subagency,
        tenantId
      }), { merge: true });

      // If approved by agency or brand, ensure it is mirrored in the Content Library & Vault
      const isApprovedForLibrary = 
        prepared.status === 'Approved' || 
        prepared.status === 'Posted' || 
        prepared.status === 'Approved with Warning' ||
        prepared.brandReviewStatus === 'Auto Approved' ||
        prepared.brandReviewStatus === 'Feedback Received' ||
        prepared.brandReviewStatus === 'Approved';

      if (isApprovedForLibrary) {
        const assetId = `asset_${prepared.id}`;
        const cleanAsset = {
          id: assetId,
          title: `${prepared.brand} — ${prepared.contentType || 'Deliverable'}`,
          creator: prepared.creator,
          creatorHandle: prepared.creator.startsWith('@') ? prepared.creator : `@${prepared.creator}`,
          brand: prepared.brand,
          dealId: prepared.dealId || '',
          platform: prepared.platform || 'Instagram',
          type: (prepared.contentType?.toLowerCase().includes('video') || prepared.contentType?.toLowerCase().includes('reel')) ? 'video' : prepared.contentType?.toLowerCase().includes('carousel') ? 'carousel' : 'image',
          views: 0,
          engagement: '0.0%',
          status: 'Approved',
          thumbnailUrl: prepared.mediaUrl || 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&auto=format&fit=crop&q=60',
          mediaUrl: prepared.mediaUrl || '',
          caption: prepared.captionDraft || '',
          fileSize: '24.5 MB',
          approvedBy: currentUser?.name || 'Director',
          approvedAt: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          tenantId,
          subagency,
          pod: subagency
        };

        await setDoc(doc(db, "studio-content-library", assetId), cleanForFirestore(cleanAsset), { merge: true });
        await setDoc(doc(db, "studio-content-vault", assetId), cleanForFirestore(cleanAsset), { merge: true });

        // Storage & real-time dispatch
        const existingLibRaw = safeStorage.getItem('wl_content_library_assets');
        const currentLib = existingLibRaw ? JSON.parse(existingLibRaw) : [];
        const updatedLib = [cleanAsset, ...currentLib.filter((a: any) => a.id !== assetId)];
        safeStorage.setItem('wl_content_library_assets', JSON.stringify(updatedLib));
        safeStorage.setItem('wl_content_vault_assets', JSON.stringify(updatedLib));

        window.dispatchEvent(new CustomEvent('wl_content_vault_updated', { detail: cleanAsset }));
      }
    } catch (e) {
      console.warn("Error saving review item to Firestore:", e);
    }
    triggerSimulatedNotification("Review Updated", "Review item and lifecycle stages have been updated.", "success");
  };

  const handleDeleteCreator = async (id: string) => {
    const creatorToDelete = creators.find(c => c.id === id);
    setCreators((prev) => {
      const updated = prev.filter(c => c.id !== id);
      safeStorage.setItem("wl_creators", JSON.stringify(updated));
      return updated;
    });

    if (creatorToDelete) {
      try {
        await moveToTrash('studio-creators', creatorToDelete, 'creator', currentUser);
      } catch (err) {
        console.warn("[handleDeleteCreator] Error moving to trash, falling back to deleteDoc:", err);
        try {
          await deleteDoc(doc(db, "studio-creators", id));
        } catch (e) {
          console.error("[handleDeleteCreator] Failed to delete creator from Firestore:", e);
        }
      }
    } else {
      try {
        await deleteDoc(doc(db, "studio-creators", id));
      } catch (e) {
        console.error("[handleDeleteCreator] Failed to delete creator from Firestore:", e);
      }
    }

    triggerSimulatedNotification("Creator Deleted", "Creator has been safely moved to recovery trash and removed from the active roster.", "success");
    handleAddActivityLog(currentUser?.name || "Staff", currentRole, `Deleted creator ${creatorToDelete?.name || id} from roster`);
  };
  
  const handleUpdateCreatorStatusImmediate = async (id: string, status: string, date?: string, why?: string) => {
    setCreators((prev) => {
      const updated = prev.map(c => c.id === id ? { ...c, status: status as any } : c);
      safeStorage.setItem("wl_creators", JSON.stringify(updated));
      return updated;
    });

    try {
      await setDoc(doc(db, "studio-creators", id), {
        status,
        statusUpdatedAt: date || new Date().toISOString(),
        statusUpdateReason: why || null
      }, { merge: true });
    } catch (err) {
      console.warn("[handleUpdateCreatorStatusImmediate] Firestore sync error:", err);
    }

    triggerSimulatedNotification("Status Updated", `Creator status set to ${status}.`, "success");
    handleAddActivityLog(currentUser?.name || "Staff", currentRole, `Updated creator (${id}) status to ${status}`);
  };

  const handleExportRosterCSV = () => {
    const targetList = visibleCreators && visibleCreators.length > 0 ? visibleCreators : creators;
    if (!targetList || targetList.length === 0) {
      triggerSimulatedNotification("Export Notice", "No creator records available to export.", "warning");
      return;
    }

    const headers = [
      "ID",
      "Name",
      "Handle",
      "Email",
      "Platform",
      "Category",
      "Followers",
      "Engagement Rate",
      "Status",
      "Tier",
      "Assigned Agent",
      "Subagency",
      "Monthly GMV",
      "Commission Rate",
      "Joined Date"
    ];

    const rows = targetList.map((c: any) => formatCsvRow([
      c.id,
      c.name,
      c.handle,
      c.email || "",
      c.platform || "TikTok",
      c.category || "General",
      c.followers || c.followerCount || 0,
      c.engagementRate || c.engagement || "0%",
      c.status || "Active",
      c.tier || "Standard",
      c.assignedAgent || c.agent || "Unassigned",
      c.subagency || c.pod || "pod_main",
      c.monthlyGmv || c.gmv || 0,
      c.commissionRate || "20%",
      c.joinedDate || c.createdAt || new Date().toISOString().split("T")[0]
    ]));

    const csvContent = [
      headers.map(sanitizeCsvCell).join(","),
      ...rows
    ].join("\r\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `creator_roster_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    triggerSimulatedNotification("CSV Exported", `Downloaded official roster CSV containing ${targetList.length} creator records.`, "success");
    handleAddActivityLog(currentUser?.name || "Staff", currentRole, `Exported creator roster CSV (${targetList.length} records)`);
  };

  const handleBatchDeleteCreators = async (creatorIds?: string[]) => {
    const idsToDelete = creatorIds && creatorIds.length > 0 ? creatorIds : selectedCreatorIds;
    if (!idsToDelete || idsToDelete.length === 0) return;

    const creatorsToDelete = creators.filter(c => idsToDelete.includes(c.id));
    
    setCreators((prev) => {
      const updated = prev.filter(c => !idsToDelete.includes(c.id));
      safeStorage.setItem("wl_creators", JSON.stringify(updated));
      return updated;
    });
    setSelectedCreatorIds([]);

    for (const creator of creatorsToDelete) {
      try {
        await moveToTrash('studio-creators', creator, 'creator', currentUser);
      } catch (err) {
        console.warn(`[handleBatchDeleteCreators] moveToTrash failed for ${creator.id}, falling back:`, err);
        try {
          await deleteDoc(doc(db, "studio-creators", creator.id));
        } catch (e) {
          console.error(`[handleBatchDeleteCreators] deleteDoc failed for ${creator.id}:`, e);
        }
      }
    }

    triggerSimulatedNotification("Creators Deleted", `${idsToDelete.length} creator(s) have been safely moved to recovery trash.`, "success");
    handleAddActivityLog(currentUser?.name || "Staff", currentRole, `Batch deleted ${idsToDelete.length} creator(s) from roster`);
  };

  const handleConvertInboundLeadToDeal = async (lead: any) => {
    const newDeal: Deal = {
      id: `deal_inbound_${Date.now()}`,
      brand: lead.subtitle || lead.brandName || "Partner Brand",
      title: lead.title || lead.brandName || "Inbound Brand Campaign",
      creator: "Unassigned Roster",
      budget: 10000,
      platform: "TikTok/IG",
      stage: "Lead",
      due: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      subagency: currentUser?.subagency || "default",
      tenantId: currentUser?.tenantId || "bloom_studio_default",
      createdAt: new Date().toISOString()
    };
    setDeals((prev: Deal[]) => [newDeal, ...prev]);
    try {
      await setDoc(doc(db, "studio-deals", newDeal.id), cleanUndefinedForFirestore(newDeal));
    } catch (err) {
      console.warn("[ConvertLead] Error saving deal:", err);
    }
    triggerSimulatedNotification("Inbound Lead Converted", `Converted inquiry from ${lead.title || lead.subtitle || 'Brand'} into a live pipeline deal.`, "success");
    handleAddActivityLog(currentUser?.name || "Director", currentRole, `Converted inbound lead to deal: ${newDeal.title}`);
  };

  const handleApproveWaitlistEntry = async (entry: any) => {
    const newCreator = {
      id: `creator_waitlist_${Date.now()}`,
      name: entry.title || entry.name || "Talent Candidate",
      email: entry.email || "talent@creator.com",
      handle: entry.handle || "@talent",
      subagency: currentUser?.subagency || "default",
      tenantId: currentUser?.tenantId || "bloom_studio_default",
      status: "Active Roster",
      createdAt: new Date().toISOString()
    };
    try {
      await setDoc(doc(db, "studio-creators", newCreator.id), cleanUndefinedForFirestore(newCreator));
      await setDoc(doc(db, "studio_waitlist", entry.id), { status: "Approved" }, { merge: true });
    } catch (err) {
      console.warn("[ApproveWaitlist] Error:", err);
    }
    triggerSimulatedNotification("Candidate Approved", `Approved ${newCreator.name} to the active creator roster.`, "success");
    handleAddActivityLog(currentUser?.name || "Director", currentRole, `Approved waitlist candidate to roster: ${newCreator.name}`);
  };

  // --- Quick Actions & Modals State ---
  const [showQuickAddCreatorModal, setShowQuickAddCreatorModal] =
    useState(false);
  const [showQuickLogDealModal, setShowQuickLogDealModal] = useState(false);
  const [showBroadcastModal, setShowBroadcastModal] = useState(false);
  const [showAnnouncementsModal, setShowAnnouncementsModal] = useState(false);
  const [showDirectMessageLookupModal, setShowDirectMessageLookupModal] =
    useState(false);
  const [showQuickAssignAgentModal, setShowQuickAssignAgentModal] =
    useState(false);
  const [showQuickWaitlistModal, setShowQuickWaitlistModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showPrivacyPolicyModal, setShowPrivacyPolicyModal] = useState(false);
  const [showAccessibilityModal, setShowAccessibilityModal] = useState(false);
  const [isMandatoryTosGate, setIsMandatoryTosGate] = useState(false);

  // Quick Action Modal Form States
  const [quickDealTitle, setQuickDealTitle] = useState("");
  const [quickDealBrand, setQuickDealBrand] = useState("");
  const [quickDealCreator, setQuickDealCreator] = useState("");
  const [quickDealAmount, setQuickDealAmount] = useState("10000");
  const [quickDealStage, setQuickDealStage] = useState("Inquiry");

  const [quickAssignCreatorId, setQuickAssignCreatorId] = useState("");
  const [quickAssignAgentName, setQuickAssignAgentName] = useState("");

  const [quickWaitlistName, setQuickWaitlistName] = useState("");
  const [quickWaitlistHandle, setQuickWaitlistHandle] = useState("");
  const [quickWaitlistPlatform, setQuickWaitlistPlatform] = useState("TikTok");

  // Agency Announcements State (Everyone, Per Creator, Per Team)
  const [announcements, setAnnouncements] = useState<AnnouncementItem[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_announcements");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: "an_clean_1",
        title: "Agency Operations & Compliance Guidance",
        text: "All creator deliverables must ensure clear FTC disclosure tags (#ad or #sponsored) are positioned within the top lines of campaign captions.",
        date: "Today",
        createdAt: new Date().toISOString(),
        author: "Agency Director",
        audience: "All Agency",
        readBy: ["@alexjones", "Marcus Cole"],
      },
      {
        id: "an_clean_2",
        title: "Q3 Brand Matchmaking & Rate Card Adjustments",
        text: "Updated commercial rate cards for TikTok Shorts & Reels have been posted to your media kits. Please review with your assigned talent agent.",
        date: "Today",
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        author: "Sarah Jenkins",
        audience: "Creators Only",
        readBy: ["@alexjones", "@kaylalooks"],
      },
      {
        id: "an_clean_3",
        title: "Weekly Agent & Coordinator Tactical Sync",
        text: "Mandatory pod briefing this Friday at 10:00 AM EST to review high-tier brand outreach and escrow milestone clearance.",
        date: "Today",
        createdAt: new Date(Date.now() - 7200000).toISOString(),
        author: "Director Sarah Jenkins",
        audience: "Staff Only",
        targetTeamName: "All Staff & Agents",
        readBy: ["Marcus Cole", "Rachel Sterling"],
      },
    ];
  });

  useEffect(() => {
    safeStorage.setItem("wl_announcements", JSON.stringify(announcements));
  }, [announcements]);

  useEffect(() => {
    if (activeScreen === "announcement-center") {
      const isDir = ['director', 'agency'].includes((currentRole || '').toLowerCase());
      if (!isDir) {
        const viewerName = currentUser?.handle || currentUser?.name || (currentRole === 'creator' ? '@alexjones' : 'Marcus Cole');
        setAnnouncements(prev => {
          let changed = false;
          const updated = prev.map(ann => {
            const readList = ann.readBy || [];
            if (!readList.includes(viewerName)) {
              changed = true;
              return { ...ann, readBy: [...readList, viewerName] };
            }
            return ann;
          });
          return changed ? updated : prev;
        });
      }
    }
  }, [activeScreen, currentRole, currentUser]);

  // Real-time Firestore sync for studio-announcements collection
  useEffect(() => {
    try {
      if (!isAuthenticated) return;
      const q = query(collection(db, "studio-announcements"));
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteItems: AnnouncementItem[] = [];
            snapshot.forEach((docSnap) => {
              const data = docSnap.data() as any;
              remoteItems.push({
                id: docSnap.id,
                title: data.title || "Agency Notice",
                text: data.text || "",
                date: data.date || "Today",
                createdAt: data.createdAt || new Date().toISOString(),
                author: data.author || "Agency Director",
                authorRole: data.authorRole || "director",
                audience: data.audience || "All Agency",
                targetCreatorName: data.targetCreatorName,
                targetCreatorHandle: data.targetCreatorHandle,
                targetTeamName: data.targetTeamName,
                priority: data.priority || "normal",
                channels: data.channels || [],
                readBy: data.readBy || []
              });
            });

            setAnnouncements((prev) => {
              const map = new Map<string, AnnouncementItem>();
              remoteItems.forEach((item) => map.set(item.id, item));
              prev.forEach((item) => {
                if (!map.has(item.id)) map.set(item.id, item);
              });
              return Array.from(map.values()).sort((a, b) => {
                const tA = new Date(a.createdAt || 0).getTime();
                const tB = new Date(b.createdAt || 0).getTime();
                return tB - tA;
              });
            });
          }
        },
        (err) => {
          console.warn("[App] studio-announcements listener warning:", err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn("[App] Failed to listen to studio-announcements:", e);
    }
  }, [isAuthenticated]);

  // Real-time Firestore sync for studio-notifications collection (Resolving Finding #73)
  useEffect(() => {
    try {
      if (!isAuthenticated) return;
      const q = query(collection(db, "studio-notifications"));
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteNotifications: AppNotification[] = [];
            snapshot.forEach((docSnap) => {
              const data = docSnap.data() as any;
              const userHandle = currentUser?.handle?.toLowerCase();
              const userEmail = currentUser?.email?.toLowerCase();
              const recipient = data.recipientHandle?.toLowerCase();
              
              const isForMe = !recipient || 
                (userHandle && recipient.includes(userHandle)) || 
                (userEmail && recipient.includes(userEmail)) ||
                currentRole === "director" || currentRole === "agency";

              if (isForMe) {
                const priorityType = data.priority === "urgent" ? "danger" : data.priority === "important" ? "warning" : "info";
                remoteNotifications.push({
                  id: docSnap.id,
                  title: data.title || "Notification",
                  detail: data.message || data.detail || "",
                  type: data.type === "success" ? "success" : data.type === "danger" ? "danger" : priorityType,
                  created: data.createdAt || data.created || new Date().toISOString(),
                  read: !!data.read
                });
              }
            });

            if (remoteNotifications.length > 0) {
              setNotifications((prev) => {
                const map = new Map<string, AppNotification>();
                prev.forEach((n) => map.set(n.id, n));
                remoteNotifications.forEach((n) => map.set(n.id, n));
                return Array.from(map.values()).sort((a, b) => {
                  const tA = new Date(a.created || 0).getTime();
                  const tB = new Date(b.created || 0).getTime();
                  return tB - tA;
                }).slice(0, 50);
              });
            }
          }
        },
        (err) => {
          console.warn("[App] studio-notifications listener warning:", err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn("[App] Failed to listen to studio-notifications:", e);
    }
  }, [isAuthenticated, currentUser, currentRole]);

  // Real-time Firestore sync for studio-action-queue collection
  useEffect(() => {
    try {
      if (!isAuthenticated) return;
      const isPlatformOwner = !!currentUser?.isPlatformOwner;
      const colRef = collection(db, "studio-action-queue");
      const q = isPlatformOwner
        ? colRef
        : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const remoteItems: any[] = [];
            snapshot.forEach((docSnap) => {
              const data = docSnap.data();
              remoteItems.push({ id: docSnap.id, ...data });
            });
            setActionQueue((prev) => {
              const map = new Map<string, any>();
              remoteItems.forEach((item) => map.set(item.id, item));
              prev.forEach((item) => {
                if (!map.has(item.id)) map.set(item.id, item);
              });
              return Array.from(map.values());
            });
          }
        },
        (err) => {
          console.warn("[App] studio-action-queue listener warning:", err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn("[App] Failed to listen to studio-action-queue:", e);
    }
  }, [isAuthenticated, currentUser?.subagency, currentUser?.isPlatformOwner]);

  // Real-time Firestore sync for inbound-agency-leads, inboundLeads, and leads
  useEffect(() => {
    try {
      if (!isAuthenticated) return;
      
      // Listen to inbound-agency-leads
      const colRef1 = collection(db, "inbound-agency-leads");
      const unsub1 = onSnapshot(
        query(colRef1, orderBy("timestamp", "desc")),
        (snapshot) => {
          const items: any[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ id: docSnap.id, ...docSnap.data() });
          });
          setInboundLeads(prev => {
            const combined = [...items, ...prev.filter(i => !items.some(x => x.id === i.id))];
            safeStorage.setItem("wl_inbound_leads", JSON.stringify(combined));
            return combined;
          });
        },
        (err) => console.warn("[App] inbound-agency-leads warning:", err)
      );

      // Listen to inboundLeads (public portfolio inquiry footer writes)
      const colRef2 = collection(db, "inboundLeads");
      const unsub2 = onSnapshot(
        colRef2,
        (snapshot) => {
          const items: any[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ id: docSnap.id, ...docSnap.data() });
          });
          setInboundLeads(prev => {
            const combined = [...items, ...prev.filter(i => !items.some(x => x.id === i.id))];
            safeStorage.setItem("wl_inbound_leads", JSON.stringify(combined));
            return combined;
          });
        },
        (err) => console.warn("[App] inboundLeads warning:", err)
      );

      return () => {
        unsub1();
        unsub2();
      };
    } catch (e) {
      console.warn("[App] Failed to listen to inbound leads collections:", e);
    }
  }, [isAuthenticated]);

  // Real-time Firestore sync for studio_waitlist
  useEffect(() => {
    try {
      if (!isAuthenticated) return;
      const colRef = collection(db, "studio_waitlist");
      const unsubscribe = onSnapshot(
        query(colRef, orderBy("createdAt", "desc")),
        (snapshot) => {
          const items: any[] = [];
          snapshot.forEach((docSnap) => {
            items.push({ id: docSnap.id, ...docSnap.data() });
          });
          setWaitlistEntries(items);
          safeStorage.setItem("wl_waitlist_entries", JSON.stringify(items));
        },
        (err) => {
          console.warn("[App] studio_waitlist listener warning:", err);
        }
      );
      return () => unsubscribe();
    } catch (e) {
      console.warn("[App] Failed to listen to studio_waitlist:", e);
    }
  }, [isAuthenticated]);

  const handleSendMassBroadcast = async (
    payload: Partial<AnnouncementItem>,
    options: { sendPush: boolean; sendSms: boolean; sendChat: boolean; sendEmail?: boolean }
  ) => {
    const announcementId = payload.id || `an_${Date.now()}`;
    const now = new Date();
    const formattedDate = now.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

    const fullAnnouncement: AnnouncementItem = {
      id: announcementId,
      title: payload.title?.trim() || "Agency Notice",
      text: payload.text?.trim() || "",
      date: payload.date || formattedDate,
      createdAt: payload.createdAt || now.toISOString(),
      author: payload.author || currentUser?.name || (currentRole === "director" ? "Agency Director" : "Director"),
      authorRole: currentRole || "director",
      audience: payload.audience || "All Agency",
      targetCreatorName: payload.targetCreatorName,
      targetCreatorHandle: payload.targetCreatorHandle,
      targetTeamName: payload.targetTeamName,
      priority: payload.priority || "normal",
      channels: [
        ...(options.sendPush ? ["In-App Feed"] : []),
        ...(options.sendSms ? ["Live SMS"] : []),
        ...(options.sendChat ? ["Chat System"] : []),
        ...(options.sendEmail ? ["SendGrid Email"] : [])
      ],
      readBy: [currentUser?.name || currentUser?.handle || "Director"]
    };

    // 1. Immediately update local state and localStorage
    setAnnouncements((prev) => [fullAnnouncement, ...prev.filter((a) => a.id !== announcementId)]);
    try {
      const existing = safeStorage.getItem("wl_announcements");
      const currentList: AnnouncementItem[] = existing ? JSON.parse(existing) : [];
      safeStorage.setItem(
        "wl_announcements",
        JSON.stringify([fullAnnouncement, ...currentList.filter((a) => a.id !== announcementId)])
      );
    } catch (e) {
      console.error("Failed to update safeStorage announcements:", e);
    }

    // 2. Persist to Firestore: studio-announcements collection
    try {
      await setDoc(doc(db, "studio-announcements", announcementId), {
        ...fullAnnouncement,
        publishedAt: now.toISOString(),
        sentByUid: currentUser?.id || currentUser?.uid || "director_01",
        createdByPlatformOwner: !!currentUser?.isPlatformOwner,
        channelsDispatched: fullAnnouncement.channels,
        deliveryOptions: options,
        subagency: currentUser?.subagency || currentUser?.tenantId || "pod_main",
        tenantId: currentUser?.tenantId || currentUser?.subagency || "bloom_studio_default"
      });
      console.log(`[MassBroadcast] Successfully saved announcement ${announcementId} to Firestore studio-announcements`);
    } catch (firestoreErr) {
      console.warn("[MassBroadcast] Error writing to studio-announcements in Firestore:", firestoreErr);
    }

    // 3. Resolve Target Creators for SMS / Email / Chat / Notifications
    let recipients: Creator[] = [];
    const audLower = (fullAnnouncement.audience || "").toLowerCase();

    if (payload.targetCreatorHandle) {
      const match = visibleCreators.find(
        (c) =>
          (c.handle && c.handle.toLowerCase() === payload.targetCreatorHandle?.toLowerCase()) ||
          (c.name && c.name.toLowerCase() === payload.targetCreatorName?.toLowerCase())
      );
      if (match) {
        recipients = [match];
      } else {
        recipients = [
          {
            id: `c_${payload.targetCreatorHandle.replace("@", "")}`,
            handle: payload.targetCreatorHandle,
            name: payload.targetCreatorName || payload.targetCreatorHandle,
            phone: "+13105550191",
            email: `${payload.targetCreatorHandle.replace("@", "")}@bloompartners.com`,
            smsConsent: true,
            platform: "Social",
            niche: "General",
            followers: "100K",
            eng: "4.0%",
            agreement: "Exclusive",
            status: "Active"
          }
        ];
      }
    } else if (
      audLower.includes("creator") ||
      audLower.includes("talent") ||
      audLower.includes("everyone") ||
      audLower.includes("all")
    ) {
      recipients =
        visibleCreators.length > 0
          ? visibleCreators
          : [
              {
                id: "c_alexjones",
                handle: "@alexjones",
                name: "Alex Jones",
                email: "alex@bloompartners.com",
                phone: "+13105550191",
                smsConsent: true,
                platform: "TikTok & Instagram",
                niche: "Fitness & Lifestyle",
                followers: "850K",
                eng: "4.8%",
                agreement: "Exclusive (80%)",
                status: "Active"
              }
            ];
    }

    // 4. Multi-Channel Execution: SMS Dispatch (/api/send-sms)
    let smsCount = 0;
    if (options.sendSms && recipients.length > 0) {
      const token = await getAuthToken();
      const authHeaders: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (token) {
        authHeaders["Authorization"] = `Bearer ${token}`;
      }

      const smsBody = `[${(fullAnnouncement.priority || "NORMAL").toUpperCase()}] ${fullAnnouncement.title}: ${fullAnnouncement.text.slice(0, 160)}`;
      const audLower = (fullAnnouncement.audience || "").toLowerCase();
      
      // Optimization: If broadcasting to All Creators/Staff, use the server-side bulk endpoint
      const isBulkCreators = audLower.includes("all creators") || audLower.includes("everyone") || audLower.includes("all talent");
      const isBulkStaff = audLower.includes("all staff") || audLower.includes("team only");

      if (isBulkCreators || isBulkStaff) {
        try {
          const resp = await fetch("/api/send-sms", {
            method: "POST",
            headers: authHeaders,
            body: JSON.stringify({
              message: smsBody,
              recipientType: isBulkCreators ? 'creators' : 'staff',
              to: isBulkCreators ? 'creators' : 'staff'
            })
          });
          const resData = await resp.json();
          if (resp.ok && resData.success) {
            smsCount = resData.count || recipients.length;
          }
        } catch (smsErr) {
          console.warn("[MassBroadcast] Bulk SMS failure:", smsErr);
        }
      } else {
        // Individual Dispatch loop
        for (const creator of recipients) {
          const phone =
            creator.phone && /^\+[1-9]\d{1,14}$/.test(creator.phone.trim())
              ? creator.phone.trim()
              : "+18005550199";

          try {
            const resp = await fetch("/api/send-sms", {
              method: "POST",
              headers: authHeaders,
              body: JSON.stringify({
                phoneNumber: phone,
                message: smsBody,
                creatorId: creator.id || creator.handle,
                recipientType: 'individual'
              })
            });
            const resData = await resp.json();
            if (resp.ok && (resData.status === "delivered" || resData.status === "simulated_success" || resData.isSimulated || resData.sid || resData.success)) {
              smsCount++;
            }
          } catch (smsErr) {
            console.warn(`[MassBroadcast] Failed sending SMS to ${creator.handle}:`, smsErr);
          }
        }
      }
    }

    // 5. Multi-Channel Execution: Email Dispatch (/api/send-email)
    let emailCount = 0;
    if (options.sendEmail && recipients.length > 0) {
      const token = await getAuthToken();
      const authHeaders: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (token) {
        authHeaders["Authorization"] = `Bearer ${token}`;
      }

      for (const creator of recipients) {
        const email =
          creator.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(creator.email.trim())
            ? creator.email.trim()
            : `${(creator.handle || "talent").replace("@", "")}@bloomagency.com`;

        try {
          const resp = await fetch("/api/send-email", {
            method: "POST",
            headers: authHeaders,
            body: JSON.stringify({
              email,
              subject: `[Agency Notice] ${fullAnnouncement.title}`,
              message: fullAnnouncement.text,
              creatorId: creator.id || creator.handle,
              emailConsent: true
            })
          });
          if (resp.ok) {
            emailCount++;
          }
        } catch (emailErr) {
          console.warn(`[MassBroadcast] Failed sending Email to ${creator.handle}:`, emailErr);
        }
      }
    }

    // 6. Multi-Channel Execution: In-App Chat Messages
    if (options.sendChat) {
      const chatBroadcastMsg: Message = {
        id: `m_bc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        from: "other",
        senderRole: currentRole || "director",
        senderName: currentUser?.name || (currentRole === "director" ? "Agency Director" : "Marcus Cole"),
        text: `📢 [${(fullAnnouncement.priority || "NORMAL").toUpperCase()} BROADCAST] ${fullAnnouncement.title}\n\n${fullAnnouncement.text}`,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      const persistMessage = async (threadId: string, msg: Message) => {
        try {
          await setDoc(doc(db, "studio-messages", msg.id), {
            ...msg,
            threadId,
            createdAt: new Date().toISOString(),
            senderUid: currentUser?.id || currentUser?.uid || "unknown"
          });
        } catch (e) {
          console.warn("Failed saving broadcast to messages:", e);
        }
      };

      setThreads((prevThreads) => {
        let updated = [...prevThreads];
        let mainBcThreadId = "th_general_broadcast";
        const bcIndex = updated.findIndex(
          (t) => t.id === "th_general_broadcast" || t.name.toLowerCase().includes("broadcast")
        );
        if (bcIndex >= 0) {
          mainBcThreadId = updated[bcIndex].id;
          updated[bcIndex] = {
            ...updated[bcIndex],
            messages: [...updated[bcIndex].messages, chatBroadcastMsg]
          };
        } else {
          updated.unshift({
            id: mainBcThreadId,
            name: "Agency Broadcast Channel",
            role: "All Agency",
            handle: "@everyone",
            messages: [chatBroadcastMsg]
          });
          // Also persist new thread
          setDoc(doc(db, "studio-threads", mainBcThreadId), {
            id: mainBcThreadId,
            name: "Agency Broadcast Channel",
            role: "All Agency",
            handle: "@everyone",
            createdAt: new Date().toISOString(),
            ownerUid: "system"
          }).catch(console.warn);
        }
        persistMessage(mainBcThreadId, chatBroadcastMsg);

        if (payload.targetCreatorHandle) {
          const handleClean = payload.targetCreatorHandle.toLowerCase();
          let targetBcThreadId = `th_${handleClean.replace("@", "")}`;
          const targetIndex = updated.findIndex(
            (t) =>
              (t.handle || "").toLowerCase() === handleClean ||
              (t.name || "").toLowerCase() === (payload.targetCreatorName || "").toLowerCase()
          );
          
          if (targetIndex >= 0) {
            targetBcThreadId = updated[targetIndex].id;
            updated[targetIndex] = {
              ...updated[targetIndex],
              messages: [...updated[targetIndex].messages, chatBroadcastMsg]
            };
          } else {
            updated.push({
              id: targetBcThreadId,
              name: payload.targetCreatorName || payload.targetCreatorHandle,
              role: "Creator",
              handle: payload.targetCreatorHandle,
              messages: [chatBroadcastMsg]
            });
            setDoc(doc(db, "studio-threads", targetBcThreadId), {
              id: targetBcThreadId,
              name: payload.targetCreatorName || payload.targetCreatorHandle,
              role: "Creator",
              handle: payload.targetCreatorHandle,
              createdAt: new Date().toISOString(),
              ownerUid: "system"
            }).catch(console.warn);
          }
          persistMessage(targetBcThreadId, chatBroadcastMsg);
        }
        return updated;
      });
    }

    // 7. Multi-Channel Execution: In-App Notifications & Toast
    if (options.sendPush) {
      const toastType =
        fullAnnouncement.priority === "urgent"
          ? "danger"
          : fullAnnouncement.priority === "important"
            ? "warning"
            : "info";
      triggerSimulatedNotification(
        `📢 ${fullAnnouncement.title}`,
        `${fullAnnouncement.text.slice(0, 90)}${fullAnnouncement.text.length > 90 ? "..." : ""} (Dispatched to ${fullAnnouncement.audience})`,
        toastType
      );

      try {
        for (const r of recipients) {
          const recipientPod = (r as any).subagency || (r as any).tenantId || currentUser?.subagency || "pod_main";
          const recipientTenant = (r as any).tenantId || (r as any).subagency || currentUser?.tenantId || "bloom_studio_default";
          
          await setDoc(doc(db, "studio-notifications", `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`), {
            title: `[Broadcast] ${fullAnnouncement.title}`,
            message: fullAnnouncement.text,
            priority: fullAnnouncement.priority,
            recipientHandle: r.handle || r.id,
            recipientName: r.name,
            sender: fullAnnouncement.author,
            senderRole: currentRole,
            type: "broadcast",
            read: false,
            createdAt: now.toISOString(),
            subagency: recipientPod,
            tenantId: recipientTenant
          }).catch(() => {});
        }
      } catch (notifErr) {
        console.warn("[MassBroadcast] Failed to record in studio-notifications:", notifErr);
      }
    }

    // 8. Record in Activity Log with actual delivery details
    const channelSummary = [
      options.sendPush ? "In-App/Feed" : null,
      options.sendSms ? `SMS (${smsCount || recipients.length} dispatched)` : null,
      options.sendChat ? "Chat System" : null,
      options.sendEmail ? `Email (${emailCount || recipients.length} dispatched)` : null
    ]
      .filter(Boolean)
      .join(", ");

    handleAddActivityLog(
      currentUser?.name || "Director",
      currentRole,
      `Broadcast Dispatched: "${fullAnnouncement.title}" to ${fullAnnouncement.audience} via [${channelSummary}]`
    );

    setShowBroadcastModal(false);
  };

  // Agency Deliverable & Availability Schedules State
  const DEFAULT_INITIAL_SCHEDULES: any[] = [];

  const [localAgencySchedules, setLocalAgencySchedules] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_agency_schedules');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_INITIAL_SCHEDULES;
  });

  useEffect(() => {
    safeStorage.setItem('wl_agency_schedules', JSON.stringify(agencySchedules));
  }, [agencySchedules]);

  const [isAddAvailabilityModalOpen, setIsAddAvailabilityModalOpen] = useState(false);
  const [newAvailabilityForm, setNewAvailabilityForm] = useState({
    creator: '@alexjones',
    title: '',
    dayNum: new Date().getDate(),
    status: 'available' as 'available' | 'busy' | 'onset' | 'blockout' | 'tentative',
    timeWindow: 'All Day',
    location: 'Los Angeles, CA',
    notes: ''
  });

  // External Service Integrations (Live Connected Tools Manager)
  const DEFAULT_EXTERNAL_INTEGRATIONS: any[] = [];

  const [externalIntegrations, setExternalIntegrations] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_external_integrations');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {}
    return DEFAULT_EXTERNAL_INTEGRATIONS;
  });

  useEffect(() => {
    safeStorage.setItem('wl_external_integrations', JSON.stringify(externalIntegrations));
  }, [externalIntegrations]);


  const [brands, setBrands] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_brands');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [
      { id: 'br_nike', name: 'Nike Athletics', contact: 'Sarah Lin (VP Partnerships)', email: 'sarah.lin@nike.com', spent: 75000, activeCampaigns: 2, status: 'Active Partner', category: 'Sportswear & Fitness', escrowPreference: '100% Pre-funded Escrow', notes: 'Corporate AP billing contact.' },
      { id: 'br_gymshark', name: 'Gymshark', contact: 'Alex Rivera (Influencer Lead)', email: 'alex.rivera@gymshark.com', spent: 42000, activeCampaigns: 1, status: 'Active Partner', category: 'Apparel & Athleisure', escrowPreference: '100% Pre-funded Escrow', notes: 'Prefers TikTok & IG Reels bundles.' },
      { id: 'br_aloyoga', name: 'Alo Yoga', contact: 'Jessica Vance (Talent Coordinator)', email: 'jessica@aloyoga.com', spent: 18500, activeCampaigns: 1, status: 'Contracted', category: 'Wellness & Lifestyle', escrowPreference: '100% Pre-funded Escrow', notes: 'Monthly recurring retainers.' }
    ];
  });

  // Real-time Firestore sync for studio-deals
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-deals");
    let q;
    if (isPlatformOwner) {
      q = colRef;
    } else if (currentRole === 'brand') {
      q = query(colRef, where("brand", "==", currentUser?.name || currentUser?.email || ""));
    } else if (currentRole === 'creator') {
      q = query(colRef, where("creator", "==", currentUser?.handle || currentUser?.name || ""));
    } else {
      q = query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));
    }

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: Deal[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (!data.isDeleted) {
            items.push({ id: docSnap.id, ...data } as Deal);
          }
        });
        
        setDeals(items);
        safeStorage.setItem("wl_deals", JSON.stringify(items));
      },
      (err) => {
        console.warn("[studio-deals] onSnapshot subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentRole, currentUser]);

  // Real-time Firestore sync for studio-campaigns
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-campaigns");
    let q;
    if (isPlatformOwner) {
      q = colRef;
    } else if (currentRole === 'brand') {
      q = query(colRef, where("brand", "==", currentUser?.name || currentUser?.email || ""));
    } else if (currentRole === 'creator') {
      q = query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));
    } else {
      q = query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));
    }

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: Campaign[] = [];
        snapshot.forEach(docSnap => {
          items.push({ ...docSnap.data(), id: docSnap.id } as Campaign);
        });
        setCampaigns(items);
        safeStorage.setItem("wl_campaigns", JSON.stringify(items));
      },
      (err) => {
        console.warn("[studio-campaigns] onSnapshot subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentRole, currentUser]);

  // Real-time Firestore sync for studio-creators (Roster Source of Truth)
  useEffect(() => {
    if (!isAuthenticated) return;

    if (currentRole === 'brand') {
      getAuthToken().then(token => {
        fetch("/api/creators/public-discovery", {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        })
        .then(res => res.json())
        .then(data => {
          if (data.success && data.creators) {
            setCreators(data.creators);
            safeStorage.setItem("wl_creators", JSON.stringify(data.creators));
          }
        })
        .catch(err => console.warn("[discovery-creators] Error fetching public creators:", err));
      });
      return;
    }

    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-creators");
    let q;
    if (isPlatformOwner) {
      q = colRef;
    } else if (currentRole === 'creator') {
      q = query(colRef, where("handle", "==", currentUser?.handle || ""));
    } else {
      q = query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));
    }

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: Creator[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (!data.isDeleted) {
            items.push({ id: docSnap.id, ...data } as Creator);
          }
        });
        if (items.length > 0) {
          setCreators(items);
          safeStorage.setItem("wl_creators", JSON.stringify(items));
        } else if (snapshot.empty && creators.length > 0) {
          const userSubagency = currentUser?.subagency || "pod_main";
          const mapped = creators.map(c => ({
            ...c,
            subagency: userSubagency,
            tenantId: userSubagency,
            pod: userSubagency
          }));
          migrateCreatorsToStudioCreators(mapped).catch((err) => {
            console.warn("[studio-creators] Error seeding initial creators:", err);
          });
        }
      },
      (err) => {
        console.warn("[studio-creators] onSnapshot subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentRole, currentUser]);

  // Real-time Firestore sync for studio-brands (Brands Roster Source of Truth)
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-brands");
    const q = isPlatformOwner 
      ? colRef 
      : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: any[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (!data.isDeleted) {
            items.push({ id: docSnap.id, ...data });
          }
        });
        if (items.length > 0) {
          setBrands(items);
          safeStorage.setItem("wl_brands", JSON.stringify(items));
        } else if (snapshot.empty && brands.length > 0) {
          brands.forEach(async (b) => {
            try {
              await setDoc(doc(db, "studio-brands", b.id), {
                ...b,
                subagency: b.subagency || currentUser?.subagency || "pod_main",
                updatedAt: new Date().toISOString()
              }, { merge: true });
            } catch (err) {
              console.warn("[studio-brands] Error seeding initial brand:", err);
            }
          });
        }
      },
      (err) => {
        console.warn("[studio-brands] onSnapshot subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentRole, currentUser]);

  // Real-time Firestore sync & persistence handlers for studio-contracts (Contracts Vault Source of Truth)
  const handleSaveContract = useCallback(async (contract: Contract) => {
    const tokens = (contract.dispatchedEmails || []).map((d: any) => d.secureToken).filter(Boolean);
    const stampedContract = {
      ...contract,
      dispatchedTokens: tokens,
      subagency: contract.subagency || currentUser?.subagency || "pod_main",
      updatedAt: new Date().toISOString()
    };
    setContracts((prev) => {
      const updated = [stampedContract, ...prev.filter((c: any) => c.id !== contract.id)];
      safeStorage.setItem("wl_contracts", JSON.stringify(updated));
      return updated;
    });
    try {
      await setDoc(doc(db, "studio-contracts", contract.id), stampedContract, { merge: true });
      // Direct token indexing for O(1) contract lookups and DoS defense
      if (contract.dispatchedEmails && contract.dispatchedEmails.length > 0) {
        for (const d of contract.dispatchedEmails) {
          if (d.secureToken) {
            await setDoc(doc(db, "studio-contract-tokens", d.secureToken), {
              contractId: contract.id,
              dispatchId: d.id,
              token: d.secureToken,
              subagency: stampedContract.subagency,
              createdAt: d.sentAt || new Date().toISOString()
            }, { merge: true }).catch(() => {});
          }
        }
      }
    } catch (err) {
      console.warn("[studio-contracts] Failed to save contract to Firestore:", err);
    }
  }, [currentUser]);

  const handleDeleteContract = useCallback(async (contractId: string) => {
    setContracts((prev) => {
      const updated = prev.filter((c: any) => c.id !== contractId);
      safeStorage.setItem("wl_contracts", JSON.stringify(updated));
      return updated;
    });
    try {
      await deleteDoc(doc(db, "studio-contracts", contractId));
    } catch (err) {
      console.warn("[studio-contracts] Failed to delete contract from Firestore:", err);
    }
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-contracts");
    const q = isPlatformOwner 
      ? colRef 
      : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: Contract[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (!data.isDeleted) {
            items.push({ id: docSnap.id, ...data } as Contract);
          }
        });
        if (items.length > 0) {
          setContracts(items);
          safeStorage.setItem("wl_contracts", JSON.stringify(items));
        } else if (snapshot.empty && contracts.length > 0) {
          contracts.forEach(async (c) => {
            try {
              await setDoc(doc(db, "studio-contracts", c.id), {
                ...c,
                subagency: c.subagency || currentUser?.subagency || "pod_main",
                updatedAt: new Date().toISOString()
              }, { merge: true });
            } catch (err) {
              console.warn("[studio-contracts] Error seeding initial contract:", err);
            }
          });
        }
      },
      (err) => {
        console.warn("[studio-contracts] onSnapshot subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentRole, currentUser]);

  // Real-time Firestore sync for studio-invoices (Strict per-agency isolation)
  useEffect(() => {
    if (!isAuthenticated) return;
    const isPlatformOwner = !!currentUser?.isPlatformOwner;
    const colRef = collection(db, "studio-invoices");
    const userPod = (currentUser?.subagency || currentUser?.subagencyName || currentUser?.pod || currentUser?.tenantId || tenantId || "pod_main").trim();
    const q = isPlatformOwner 
      ? colRef 
      : query(colRef, where("subagency", "==", userPod));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: Invoice[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          if (!isPlatformOwner) {
            const invPod = (data.subagency || data.tenantId || '').trim().toLowerCase();
            if (invPod !== userPod.toLowerCase()) return;
          }
          items.push({ id: docSnap.id, ...data } as any);
        });
        setInvoices(items);
        safeStorage.setItem(`wl_invoices_${userPod}`, JSON.stringify(items));
      },
      (err) => {
        console.warn("[studio-invoices] onSnapshot subscription error:", err);
      }
    );

    return () => unsubscribe();
  }, [isAuthenticated, currentRole, currentUser, tenantId]);

  const [campaigns, setCampaigns] = useState<Campaign[]>(() => {
    try {
      const saved = safeStorage.getItem("wl_campaigns");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Recoup Trash Bin State & Persistence
  const [wl_trashItems, setWlTrashItems] = useState<TrashItem[]>(() => {
    try {
      const saved = safeStorage.getItem('wl_trash_items');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Real-time Firestore sync on studio-trash-bin
  useEffect(() => {
    let unsubscribe = () => {};
    try {
      if (!isAuthenticated) return;
      const isPlatformOwner = !!currentUser?.isPlatformOwner;
      const colRef = collection(db, "studio-trash-bin");
      const q = isPlatformOwner 
        ? colRef 
        : query(colRef, where("subagency", "==", currentUser?.subagency || "pod_main"));

      unsubscribe = onSnapshot(q, (snapshot) => {
        const items: TrashItem[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...docSnap.data() } as TrashItem);
        });
        setWlTrashItems(items);
        safeStorage.setItem('wl_trash_items', JSON.stringify(items));
      }, (err) => {
        console.warn("[studio-trash-bin] subscription error:", err);
      });
    } catch (e) {
      console.warn("Failed to subscribe to studio-trash-bin", e);
    }
    return () => unsubscribe();
  }, [isAuthenticated, currentUser, currentRole]);

  // Real-time Firestore sync on studio-activity-log
  useEffect(() => {
    let unsubscribe = () => {};
    try {
      if (!isAuthenticated) return;
      const colRef = collection(db, "studio-activity-log");

      unsubscribe = onSnapshot(colRef, (snapshot) => {
        const logs: ActivityLogItem[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          logs.push({
            id: docSnap.id,
            user: data.user || data.operatorName || 'System',
            role: data.role || 'system',
            action: data.action || data.description || JSON.stringify(data),
            timestamp: data.timestamp || new Date().toISOString()
          } as ActivityLogItem);
        });
        logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        if (logs.length > 0) {
          setActivityLogs(logs.slice(0, 200));
          safeStorage.setItem('wl_activity_logs', JSON.stringify(logs.slice(0, 200)));
        }
      }, (err) => {
        console.warn("[studio-activity-log] subscription error:", err);
      });
    } catch (e) {
      console.warn("Failed to subscribe to studio-activity-log", e);
    }
    return () => unsubscribe();
  }, [isAuthenticated]);

  // Real-time Firestore sync on tenant-config delegation to sync permissions across all devices/users in the pod
  useEffect(() => {
    let unsubscribe = () => {};
    try {
      if (!isAuthenticated) return;
      const userPod = currentUser?.subagency || currentUser?.tenantId || currentUser?.pod || 'bloom_studio_default';
      
      // Subscribe to the dedicated delegation config
      unsubscribe = onSnapshot(doc(db, "tenants", userPod, "config", "delegation"), (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          safeStorage.setItem('wl_director_delegation', JSON.stringify(data));
          window.dispatchEvent(new CustomEvent('director_delegation_updated', { detail: data }));
          console.log('[App] Real-time Director Delegation Settings updated via Tenant Config:', data);
        }
      }, (err) => {
        console.warn("[tenant-delegation] subscription error:", err);
      });
    } catch (e) {
      console.warn("Failed to subscribe to tenant-delegation config", e);
    }
    return () => unsubscribe();
  }, [isAuthenticated, currentUser]);

  const handleRestoreTrash = async (item: TrashItem) => {
    try {
      const { restoreFromTrash } = await import("./lib/trashService");
      await restoreFromTrash(item);
      
      // Update local array if corresponding collection is in memory
      if (item.type === 'creator') {
        setCreators(prev => {
          if (prev.some(c => c.id === item.id)) return prev;
          return [item.originalData, ...prev];
        });
      } else if (item.type === 'campaign') {
        setCampaigns(prev => {
          if (prev.some(c => c.id === item.id)) return prev;
          return [item.originalData, ...prev];
        });
      } else if (item.type === 'deal') {
        setDeals(prev => {
          if (prev.some(d => d.id === item.id)) return prev;
          return [item.originalData, ...prev];
        });
      }

      setWlTrashItems(prev => prev.filter(i => i.id !== item.id));
      triggerSimulatedNotification('Record Restored', `${item.name} (${item.type}) successfully restored to active records.`, 'success');
      handleAddActivityLog(currentUser?.name || 'User', currentRole || 'director', `Restored ${item.type} "${item.name}" from 30-day trash bin`);
    } catch (err) {
      console.error('Failed to restore trash item:', err);
      triggerSimulatedNotification('Restore Error', 'Could not restore record from trash bin.', 'danger');
    }
  };

  const handlePurgeSeedData = async () => {
    try {
      const { purgeLegacySeedDataFromFirestore } = await import("./lib/firebase");
      await purgeLegacySeedDataFromFirestore();

      // Clean local React state and storage so demo data disappears immediately
      const seedIds = new Set(['c_alexjones', 'c_kaylalooks', 'c_sophiawells', 'c_marcusv', 'c_elena_r', 'c_charlie_d']);
      const seedNames = ['Alex Jones', 'Kayla Laurent', 'Sophia Wells', 'Marcus Vance', 'Elena Rostova', 'Charlie Davis'];

      setCreators(prev => {
        const filtered = prev.filter(c => !seedIds.has(c.id) && !seedNames.some(s => (c.name || '').toLowerCase().includes(s.toLowerCase()) || (c.handle || '').toLowerCase().includes(s.toLowerCase().replace(/\s+/g, ''))));
        safeStorage.setItem('wl_creators', JSON.stringify(filtered));
        return filtered;
      });

      setDeals(prev => {
        const filtered = prev.filter(d => !seedNames.some(s => ((d as any).creatorName || (d as any).creator || '').toLowerCase().includes(s.toLowerCase()) || ((d as any).creator || '').toLowerCase().includes(s.toLowerCase().replace(/\s+/g, ''))));
        safeStorage.setItem('wl_deals', JSON.stringify(filtered));
        return filtered;
      });

      setMissions(prev => {
        const filtered = prev.filter(m => !seedNames.some(s => ((m as any).assignedTo || '').toLowerCase().includes(s.toLowerCase())));
        safeStorage.setItem('wl_missions', JSON.stringify(filtered));
        return filtered;
      });

      triggerSimulatedNotification('Seed Data Purged', 'Sample data removed successfully from database and workspace state.', 'success');
      handleAddActivityLog(currentUser?.name || 'User', currentRole || 'director', 'Purged seed data');
    } catch (err) {
      console.error('Failed to purge seed data:', err);
      triggerSimulatedNotification('Purge Error', 'Failed to purge seed data.', 'danger');
      throw err;
    }
  };

  const handleMigrateCreatorsToStudio = async (): Promise<void> => {
    try {
      const { migrateCreatorsToStudioCreators } = await import("./lib/firebase");
      const count = await migrateCreatorsToStudioCreators(creators);
      triggerSimulatedNotification('Migration Complete', `Migrated ${count} creators to studio schema.`, 'success');
      handleAddActivityLog(currentUser?.name || 'User', currentRole || 'director', `Migrated ${count} creators to studio`);
    } catch (err) {
      console.error('Failed to migrate creators:', err);
      triggerSimulatedNotification('Migration Error', 'Failed to migrate creators.', 'danger');
      throw err;
    }
  };

  const handlePurgeTrash = async (itemId: string) => {
    try {
      const { purgeFromTrash } = await import("./lib/trashService");
      await purgeFromTrash(itemId);
      setWlTrashItems(prev => prev.filter(i => i.id !== itemId));
      triggerSimulatedNotification('Record Purged', 'Item permanently removed from trash bin.', 'info');
      handleAddActivityLog(currentUser?.name || 'User', currentRole || 'director', `Permanently purged item ${itemId} from trash bin`);
    } catch (err) {
      console.error('Failed to purge trash item:', err);
    }
  };

  const handleEmptyTrash = async () => {
    try {
      const { emptyTrashBin } = await import("./lib/trashService");
      await emptyTrashBin(wl_trashItems);
      setWlTrashItems([]);
      triggerSimulatedNotification('Trash Emptied', 'All items in 30-day trash bin have been permanently erased.', 'warning');
      handleAddActivityLog(currentUser?.name || 'User', currentRole || 'director', 'Emptied recoup trash bin');
    } catch (err) {
      console.error('Failed to empty trash:', err);
    }
  };

  const [wl_prospects, setWlProspects] = useState<any[]>([]);
  const [wl_isAddProspectModalOpen, setWlIsAddProspectModalOpen] = useState(false);
  const [wl_botLogs, setWlBotLogs] = useState<string[]>([]);

  
  
  // Filter for Subagency Isolation & Roster Isolation (Platform Owner sees all; sub-agency directors & staff are strictly scoped to pod, restricted roles only see assigned creators)
  const visibleCreators = React.useMemo(() => {
    if (currentUser?.isPlatformOwner) return creators;
    const roleLower = (currentRole || '').toLowerCase();
    const isDirector = roleLower === 'director';
    const isRestrictedStaff = ['agent', 'agentmgr', 'coordinator'].includes(roleLower);
    
    const defaultPod = (currentUser?.email || currentUser?.uid || currentUser?.name || 'pod_main').toLowerCase();
    const pod = (currentUser?.subagency || currentUser?.subagencyName || currentUser?.pod || currentUser?.tenantId || (isDirector ? defaultPod : 'pod_main')).toLowerCase();
    
    const podCreators = creators.filter(c => {
      const cAny = c as any;
      const cSub = (cAny.subagency || '').toLowerCase();
      const cAgency = (cAny.agency || '').toLowerCase();
      const cDirector = (cAny.directorName || cAny.directorEmail || cAny.agent || '').toLowerCase();
      const myEmail = (currentUser?.email || '').toLowerCase();
      const myName = (currentUser?.name || '').toLowerCase();
      if (isDirector && (myEmail || myName)) {
        if (cDirector && (cDirector.includes(myEmail) || cDirector.includes(myName))) return true;
      }
      return cSub === pod || cAgency === pod;
    });

    if (isRestrictedStaff) {
      const userName = (currentUser?.name || '').toLowerCase();
      const userEmail = (currentUser?.email || '').toLowerCase();
      if (!userName && !userEmail) return podCreators;
      
      return podCreators.filter(c => {
        const ag = (c.assignedAgent || (c as any).agent || '').toLowerCase();
        const mgr = (c.assignedManager || '').toLowerCase();
        const coord = (c.assignedCoordinator || c.coordinator || '').toLowerCase();
        
        const isAssigned = 
          (ag && (ag.includes(userName) || userName.includes(ag) || ag.includes(userEmail) || userEmail.includes(ag))) ||
          (mgr && (mgr.includes(userName) || userName.includes(mgr) || mgr.includes(userEmail) || userEmail.includes(mgr))) ||
          (coord && (coord.includes(userName) || userName.includes(coord) || coord.includes(userEmail) || userEmail.includes(coord))) ||
          (userName.includes('alex') && (ag.includes('alex') || mgr.includes('alex'))) ||
          (userName.includes('marcus') && (ag.includes('marcus') || mgr.includes('marcus'))) ||
          (userName.includes('chloe') && (ag.includes('chloe') || coord.includes('chloe') || mgr.includes('chloe')));
          
        return isAssigned;
      });
    }

    return podCreators;
  }, [creators, currentRole, currentUser]);

  const visibleStaff = React.useMemo(() => {
    if (currentUser?.isPlatformOwner) return allUsers;
    const isDirector = (currentRole || '').toLowerCase() === 'director';
    const defaultPod = (currentUser?.email || currentUser?.uid || currentUser?.name || 'pod_main').toLowerCase();
    const pod = (currentUser?.subagency || currentUser?.subagencyName || currentUser?.pod || currentUser?.tenantId || (isDirector ? defaultPod : 'pod_main')).toLowerCase();
    return allUsers.filter(u => {
      const uSub = (u.subagency || '').toLowerCase();
      const uTen = (u.tenantId || '').toLowerCase();
      const uEmail = (u.email || '').toLowerCase();
      const myEmail = (currentUser?.email || '').toLowerCase();
      if (isDirector && myEmail && uEmail === myEmail) return true;
      return uSub === pod || uTen === pod;
    });
  }, [allUsers, currentUser, currentRole]);

  const visibleDeals = React.useMemo(() => {
    if (currentUser?.isPlatformOwner) return deals;
    const isDirector = (currentRole || '').toLowerCase() === 'director';
    if (currentRole === 'brand') {
      const bName = (currentUser?.name || '').toLowerCase().split(' ')[0];
      return deals.filter((d: any) => (d.brand || '').toLowerCase().includes(bName));
    }
    if (currentRole === 'creator') {
      const h = (currentUser?.handle || '').toLowerCase();
      return deals.filter((d: any) => (d.creatorHandle || d.creator || '').toLowerCase() === h);
    }
    const validHandles = visibleCreators.map(c => (c.handle || '').toLowerCase());
    return deals.filter((d: any) => {
      const myEmail = (currentUser?.email || '').toLowerCase();
      const myName = (currentUser?.name || '').toLowerCase();
      const dDirector = (d.directorName || d.directorEmail || d.agent || d.createdBy || '').toLowerCase();
      if (isDirector && (myEmail || myName) && dDirector) {
        if (dDirector.includes(myEmail) || dDirector.includes(myName)) return true;
      }
      if (d.subagency && currentUser?.subagency && d.subagency.toLowerCase() === currentUser.subagency.toLowerCase()) return true;
      const h = (d.creatorHandle || d.creator || '').toLowerCase();
      return validHandles.includes(h);
    });
  }, [deals, visibleCreators, currentRole, currentUser]);

  const visibleInvoices = React.useMemo(() => {
    if (currentUser?.isPlatformOwner) return invoices;
    const isDirector = (currentRole || '').toLowerCase() === 'director';
    if (currentRole === 'brand') {
      const bName = (currentUser?.name || '').toLowerCase().split(' ')[0];
      return invoices.filter((i: any) => (i.brand || i.to || i.client || i.brandName || '').toLowerCase().includes(bName));
    }
    if (currentRole === 'creator') {
      const h = (currentUser?.handle || '').toLowerCase();
      return invoices.filter((i: any) => (i.creator || i.creatorName || i.creatorHandle || '').toLowerCase() === h);
    }
    // Staff & Directors: strictly isolated per agency pod or personal director identity
    const defaultPod = (currentUser?.email || currentUser?.uid || currentUser?.name || 'pod_main').toLowerCase();
    const userPod = (currentUser?.subagency || currentUser?.subagencyName || currentUser?.pod || currentUser?.tenantId || tenantId || (isDirector ? defaultPod : 'pod_main')).toLowerCase();
    return invoices.filter((i: any) => {
      const invPod = (i.subagency || i.tenantId || i.pod || '').toLowerCase();
      const iDirector = (i.directorName || i.directorEmail || i.submittedBy || '').toLowerCase();
      const myEmail = (currentUser?.email || '').toLowerCase();
      const myName = (currentUser?.name || '').toLowerCase();
      if (isDirector && (myEmail || myName) && iDirector) {
        if (iDirector.includes(myEmail) || iDirector.includes(myName)) return true;
      }
      return invPod === userPod;
    });
  }, [invoices, currentRole, currentUser, tenantId]);

  const visibleContracts = React.useMemo(() => {
    if (currentUser?.isPlatformOwner) return contracts;
    if (currentRole === 'brand') {
      const bName = (currentUser?.name || '').toLowerCase().split(' ')[0];
      return contracts.filter((c: any) => (c.brand || c.partyName || c.client || '').toLowerCase().includes(bName));
    }
    if (currentRole === 'creator') {
      const h = (currentUser?.handle || '').toLowerCase().replace('@', '').trim();
      const n = (currentUser?.name || '').toLowerCase().trim();
      const id = (currentUser?.id || currentUser?.creatorId || '').toLowerCase().trim();
      return contracts.filter((c: any) => {
        const cntHandle = (c.creatorHandle || c.party || c.partyName || c.creator || c.creatorName || '').toLowerCase().replace('@', '').trim();
        const cntParty = (c.party || c.partyName || c.name || '').toLowerCase().trim();
        const cntId = (c.creatorId || '').toLowerCase().trim();
        if (id && cntId === id) return true;
        if (h && (cntHandle === h || cntHandle.includes(h) || cntParty.includes(h))) return true;
        if (n && (cntParty === n || cntParty.includes(n))) return true;
        return false;
      });
    }
    const validHandles = visibleCreators.map(c => (c.handle || '').toLowerCase().replace('@', '').trim());
    return contracts.filter((c: any) => {
      if (c.subagency && currentUser?.subagency && c.subagency.toLowerCase() === currentUser.subagency.toLowerCase()) return true;
      const h = (c.creatorHandle || c.partyName || c.creator || c.creatorName || '').toLowerCase().replace('@', '').trim();
      return validHandles.includes(h) || validHandles.some(vh => h.includes(vh));
    });
  }, [contracts, visibleCreators, currentRole, currentUser]);

  const visibleReviews = React.useMemo(() => {
    if (currentUser?.isPlatformOwner || ['director', 'agency'].includes((currentRole || '').toLowerCase())) return contentReviewsList;
    if (currentRole === 'brand') {
      const bName = (currentUser?.name || '').toLowerCase().split(' ')[0];
      return contentReviewsList.filter((r: any) => (r.brand || r.client || '').toLowerCase().includes(bName));
    }
    if (currentRole === 'creator') {
      const h = (currentUser?.handle || '').toLowerCase();
      return contentReviewsList.filter((r: any) => (r.creator || r.creatorName || '').toLowerCase() === h);
    }
    const validHandles = visibleCreators.map(c => (c.handle || '').toLowerCase());
    const myAssignedBrands = new Set<string>();
    deals.forEach((d: any) => {
      const cName = (d.creator || '').toLowerCase();
      const cHandle = (d.creatorHandle || '').toLowerCase();
      if (validHandles.some(vh => cName.includes(vh) || cHandle.includes(vh))) {
        if (d.brand) myAssignedBrands.add(d.brand.toLowerCase());
      }
    });

    return contentReviewsList.filter((r: any) => {
      const rBrand = (r.brand || r.client || '').toLowerCase();
      const rCreator = (r.creator || r.creatorName || '').toLowerCase();
      const matchesCreator = validHandles.some(vh => rCreator.includes(vh));
      const matchesBrand = Array.from(myAssignedBrands).some(b => rBrand.includes(b));
      return matchesCreator || matchesBrand;
    });
  }, [contentReviewsList, visibleCreators, deals, currentRole, currentUser]);

  const visibleMissions = React.useMemo(() => {
    if (currentUser?.isPlatformOwner) return missions;
    if (currentRole === 'brand') {
      const bName = (currentUser?.name || '').toLowerCase().split(' ')[0];
      return missions.filter((m: any) => (m.brand || '').toLowerCase().includes(bName));
    }
    if (currentRole === 'creator') {
      const h = (currentUser?.handle || '').toLowerCase();
      return missions.filter((m: any) => (m.creatorHandle || m.creator || '').toLowerCase() === h);
    }
    const validHandles = visibleCreators.map(c => (c.handle || '').toLowerCase());
    return missions.filter((m: any) => {
      if (m.subagency && currentUser?.subagency && m.subagency.toLowerCase() === currentUser.subagency.toLowerCase()) return true;
      const h = (m.creatorHandle || m.creator || '').toLowerCase();
      return validHandles.includes(h);
    });
  }, [missions, visibleCreators, currentRole, currentUser]);

  const visibleCampaigns = React.useMemo(() => {
    if (currentUser?.isPlatformOwner) return campaigns;
    if (currentRole === 'brand') {
      const bName = (currentUser?.name || '').toLowerCase().split(' ')[0];
      return campaigns.filter((c: any) => (c.brand || '').toLowerCase().includes(bName));
    }
    if (currentRole === 'creator') {
      const h = (currentUser?.handle || '').toLowerCase();
      return campaigns.filter((c: any) => (c.creator || '').toLowerCase() === h);
    }
    const validHandles = visibleCreators.map(c => (c.handle || '').toLowerCase());
    return campaigns.filter((c: any) => {
      if (c.subagency && currentUser?.subagency && c.subagency.toLowerCase() === currentUser.subagency.toLowerCase()) return true;
      const h = (c.creator || '').toLowerCase();
      return validHandles.includes(h) || validHandles.some(vh => h.includes(vh));
    });
  }, [campaigns, visibleCreators, currentRole, currentUser]);

  const renderScreenContent = () => {
    // Structural Role-Based Screen Guard (Finding #72)
    const allowedScreens = ALLOWED_SCREENS_PER_ROLE[currentRole] || ALLOWED_SCREENS_PER_ROLE.none || [];
    const isAllowed = allowedScreens.includes(activeScreen) || !!currentUser?.isPlatformOwner || activeScreen === 'talent-showcase' || activeScreen === 'agency-vsl-hero' || activeScreen === 'public-portfolio' || activeScreen === 'pod-invite-signup';

    if (!isAllowed) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[500px] p-8 text-center bg-[#0D1830]/80 border border-red-500/20 rounded-2xl animate-fade-in text-xs">
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-500/10 text-red-500 mb-4">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m0-6V9m0 12a9 9 0 110-18 9 9 0 010 18z" />
            </svg>
          </div>
          <h2 className="text-sm font-semibold text-red-400 mb-1">Access Restricted</h2>
          <p className="text-gray-400 max-w-md mb-4 leading-relaxed">
            The screen <code className="px-1.5 py-0.5 bg-red-500/10 rounded text-red-300 font-mono text-[10px]">{activeScreen}</code> is not permitted under your current role of <strong className="text-gray-300 capitalize">{currentRole || "Guest"}</strong>.
          </p>
          <button
            onClick={() => setActiveScreen("briefing")}
            className="px-3 py-1.5 text-[10px] font-semibold text-[#111E33] bg-[#C9A46A] hover:bg-[#B89359] rounded-lg transition-colors"
          >
            Return to Dashboard
          </button>
        </div>
      );
    }

    switch (activeScreen) {
        case "brand-briefing":
        case "briefing":
            return <DailyBriefing
                    currentRole={currentRole || undefined}
                    currentUser={currentUser}
                    creators={visibleCreators}
                    deals={visibleDeals}
                    missions={visibleMissions}
                    notifications={notifications}
                    setNotifications={setNotifications}
                    primaryBrandColor={primaryBrandColor}
                    cardBgColor={cardBgColor}
                    textMainColor={textMainColor}
                    textMutedColor={textMutedColor}
                    triggerNotification={triggerSimulatedNotification}
                    campaigns={visibleCampaigns}
                    invoices={visibleInvoices}
                    activityLogs={activityLogs}
                    onAddActivityLog={handleAddActivityLog}
                    onNavigate={(screen) => setActiveScreen(screen)}
                    actionQueue={actionQueue}
                    inboundLeads={inboundLeads}
                    waitlistEntries={waitlistEntries}
                    referrals={referrals}
                    contentReviewsList={contentReviewsList}
                    onConvertLeadToDeal={handleConvertInboundLeadToDeal}
                    onApproveWaitlistEntry={handleApproveWaitlistEntry}
                  />
        case "campaign-board":
            return <CampaignBoard
                    campaigns={visibleCampaigns}
                    setCampaigns={setCampaigns}
                    currentRole={currentRole}
                    currentUser={currentUser}
                    creators={visibleCreators}
                    canLogCampaigns={getManagerPerms().canLogCampaigns}
                    onNavigate={(screen) => setActiveScreen(screen)}
                    triggerNotification={(title, message, type) =>
                      triggerSimulatedNotification(
                        title,
                        message,
                        type === "warning" ? "danger" : type,
                      )
                    }
                  />
        case "unified-calendar":
            return <UnifiedCalendarHub
                    agencySchedules={agencySchedules}
                    setAgencySchedules={setAgencySchedules}
                    creators={visibleCreators}
                    deals={visibleDeals}
                    currentRole={currentRole}
                    currentUser={currentUser}
                    defaultTab="production"
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                    primaryBrandColor={primaryBrandColor}
                    cardBgColor={cardBgColor}
                    onNavigateToScreen={(screenId) => setActiveScreen(screenId)}
                    myHandles={myHandles}
                  />
        case "calendar-avail":
        case "calendar":
        case "availability-calendar":
            return <UnifiedCalendarHub
                    agencySchedules={agencySchedules}
                    setAgencySchedules={setAgencySchedules}
                    creators={visibleCreators}
                    deals={visibleDeals}
                    currentRole={currentRole}
                    currentUser={currentUser}
                    defaultTab="availability"
                    myHandles={myHandles}
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                    primaryBrandColor={primaryBrandColor}
                    cardBgColor={cardBgColor}
                    onNavigateToScreen={(screenId) => setActiveScreen(screenId)}
                  />
        case "content-review":
            return <ContentReview
                    creators={visibleCreators}
                    deals={visibleDeals}
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                    currentRole={currentRole}
                    currentUser={currentUser}
                    primaryBrandColor={primaryBrandColor}
                    cardBgColor={cardBgColor}
                    reviewsList={visibleReviews}
                    onSaveReview={handleSaveReviewItem}
                    onNavigate={(screenId) => setActiveScreen(screenId)}
                  />
        case "brand-dash":
        case "brand-portal":
        case "brand-support":
            return (
              <BrandPortalDashboard
                currentUser={currentUser}
                currentRole={currentRole}
                creators={visibleCreators}
                initialTab={activeScreen === "brand-support" ? "support" : "vault"}
                reviews={visibleReviews}
                onSaveReview={handleSaveReviewItem}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "brand-review":
        case "brand-review-portal":
            return <BrandReviewPortal reviews={visibleReviews} onSaveReview={handleSaveReviewItem} currentUser={currentUser} triggerNotification={triggerSimulatedNotification} onAddActivityLog={handleAddActivityLog} onExit={handleLogout} />;
        case "brand-messages":
            return <ChatSystem currentRole={(currentRole as any) || "none"} currentUser={currentUser} creators={visibleCreators} deals={visibleDeals} campaigns={visibleCampaigns} threads={threads} onSendMessage={handleSendMessage} onAddThread={handleAddThread} onDeleteThread={handleDeleteThread} />;
        case "brand-billing":
            return (
              <BrandPortalDashboard
                currentUser={currentUser}
                initialTab="invoices"
                reviews={visibleReviews}
                onSaveReview={handleSaveReviewItem}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "brand-vault":
            return (
              <BrandPortalDashboard
                currentUser={currentUser}
                initialTab="vault"
                reviews={visibleReviews}
                onSaveReview={handleSaveReviewItem}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "brand-surveys":
            return <BrandSurveys currentRole={currentRole} currentUser={currentUser} triggerNotification={triggerSimulatedNotification} onAddActivityLog={handleAddActivityLog} />;
        case "director-dash":
            return (
              <DirectorDashboardConsole
                currentUser={currentUser}
                currentRole={currentRole}
                primaryBrandColor={primaryBrandColor}
                cardBgColor={cardBgColor}
                onNavigateToScreen={(screenId) => setActiveScreen(screenId)}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
                creators={visibleCreators}
                deals={visibleDeals}
                agencyName={activeTenantConfig?.agencyName || agencyName || "Bloom & Co. Studio"}
              />
            );
        case "talent-hq":
            return <TalentHQ
                  creators={visibleCreators}
                  setCreators={setCreators}
                  deals={visibleDeals}
                  currentUser={currentUser}
                  currentRole={currentRole}
                  primaryBrandColor={primaryBrandColor}
                  cardBgColor={cardBgColor}
                  onAddActivityLog={handleAddActivityLog}
                  triggerNotification={triggerSimulatedNotification}
                />
        case "roster":
            return (
                <CreatorRosterManager
                    creators={visibleCreators}
                    setCreators={setCreators}
                    currentRole={currentRole}
                    currentUser={currentUser}
                    isRestrictedRole={isRestrictedRole}
                    isAgentMgr={isAgentMgr}
                    myHandles={myHandles}
                    primaryBrandColor={primaryBrandColor}
                    onSelectCreatorForDetail={(c, defaultTab) => {
                      setSelectedCreatorForDetail(c);
                      const isDirector =
                        (currentRole || "").toLowerCase() === "director";
                      setCreatorDetailActiveTab(
                        isDirector ? defaultTab || "payouts" : "profile",
                      );
                      setMessageChannel("sms");
                      setSmsMessageText("");
                      setEmailSubjectText("");
                      setEmailMessageText("");
                    }}
                    onDeleteCreator={handleDeleteCreator}
                    onUpdateCreatorStatus={handleUpdateCreatorStatusImmediate}
                    onExportCSV={handleExportRosterCSV}
                    onOpenQuickAddModal={() =>
                      setShowQuickAddCreatorModal(true)
                    }
                    onOpenLogDealModal={() => setShowQuickLogDealModal(true)}
                    onOpenLaunchMission={() => {
                      setActiveScreen("missions");
                      triggerSimulatedNotification(
                        "Mission Control",
                        "Opening mission creator for your roster.",
                        "info",
                      );
                    }}
                    onAssignAgent={(creatorId) => {
                      setAssignAgentSelectedCreator(creatorId);
                      setShowQuickAssignAgentModal(true);
                    }}
                    rosterViewMode={rosterViewMode}
                    setRosterViewMode={setRosterViewMode}
                    showRosterCharts={showRosterCharts}
                    setShowRosterCharts={setShowRosterCharts}
                    selectedCreatorIds={selectedCreatorIds}
                    setSelectedCreatorIds={setSelectedCreatorIds}
                    onBatchDeleteCreators={handleBatchDeleteCreators}
                    triggerNotification={triggerSimulatedNotification}
                    onAddActivityLog={handleAddActivityLog}
                    getManagerPerms={getManagerPerms}
                  />
            );
        case "deal-pipeline":
            return (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h1 className="font-sans font-medium text-2xl tracking-tight text-white flex items-center gap-2">
                        <Tag className="text-[#C9A46A] w-6 h-6" /> Deal Pipeline
                      </h1>
                    </div>
                  </div>
                  <ThresholdAlertManager
                    deals={visibleDeals}
                    setDeals={setDeals}
                    creators={visibleCreators}
                    currentRole={currentRole}
                    currentUser={currentUser}
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                    primaryBrandColor={primaryBrandColor}
                  />
                </div>
            );
        case "missions":
             if (currentRole === "creator") {
               return (
                 <CreatorAssignedMissionsView
                   missions={missions}
                   currentUser={currentUser}
                   primaryBrandColor={primaryBrandColor}
                   cardBgColor={cardBgColor}
                   onNavigateToSubmit={() => setActiveScreen("submit-content")}
                   onNavigateToMarketplace={() => setActiveScreen("open-marketplace")}
                   triggerNotification={triggerSimulatedNotification}
                 />
               );
             }
             return (
                 <OpenMissionsWorkspace
                   creators={visibleCreators}
                   currentRole={currentRole}
                   currentUser={currentUser}
                   primaryBrandColor={primaryBrandColor}
                   cardBgColor={cardBgColor}
                   onAddActivityLog={handleAddActivityLog}
                   triggerNotification={triggerSimulatedNotification}
                   onNavigateToCampaignWorkspace={() => setActiveScreen("campaigns")}
                 />
             );
        case "director-delegation":
            return (
              <DirectorDelegationControls 
                currentUser={currentUser}
                currentRole={currentRole}
                onUpdateSettings={(s) => triggerSimulatedNotification('Settings Updated', 'Director delegation settings updated.')}
                onAddActivityLog={handleAddActivityLog}
                triggerNotification={triggerSimulatedNotification}
                primaryBrandColor={primaryBrandColor}
                cardBgColor={cardBgColor}
              />
            );
        case "invoices":
            return (
              <InvoiceGenerator 
                currentUser={currentUser}
                currentRole={currentRole}
                tenantId={tenantId}
                agencyName={activeTenantConfig?.agencyName || (agencyName === "Bloom Studio" ? "Bloom & Co Network" : agencyName) || "Bloom & Co Network"}
                triggerNotification={triggerSimulatedNotification} 
                onAddActivityLog={handleAddActivityLog} 
                onNavigate={(screenId) => setActiveScreen(screenId)}
              />
            );
        case "party-deal-assignments":
            return (
              <PartyDealAssignments
                currentUser={currentUser}
                currentRole={currentRole}
                creators={visibleCreators}
                deals={visibleDeals}
                onAddActivityLog={handleAddActivityLog}
                triggerNotification={triggerSimulatedNotification}
              />
            );
        case "revenue":
        case "deals-revenue-hub":
        case "creator-financials":
            return (
                <DealsAndRevenueHub
                  deals={visibleDeals}
                  setDeals={setDeals}
                  creators={visibleCreators}
                  currentRole={currentRole}
                  currentUser={currentUser}
                  tenantId={
                    activeTenantConfig?.agencyName || "bloom_studio_default"
                  }
                  primaryBrandColor={primaryBrandColor}
                  cardBgColor={cardBgColor}
                  onAddActivityLog={handleAddActivityLog}
                  triggerNotification={triggerSimulatedNotification}
                  onOpenNewDealModal={() => setShowQuickLogDealModal(true)}
                />
            );
        case "payroll-schedule":
        case "escrow-settlement":
            return (
                <UnifiedPayrollEscrowHub
                  currentUser={{
                    uid: currentUser?.id || "agent_01",
                    name: currentUser?.name || "Staff User",
                    email: currentUser?.email || "staff@bloomstudio.com",
                    role: (currentRole === "agent"
                      ? "Agent"
                      : isAgentMgr
                        ? "AgentManager"
                        : currentRole === "director"
                          ? "Director"
                          : "none") as any,
                  }}
                  defaultTab={activeScreen === "escrow-settlement" ? "escrow" : "payroll"}
                  onDisburseFunds={async (campaignId: string) => {
                    const target = (campaigns as any[]).find(c => c.id === campaignId) ||
                      DEFAULT_PAYROLL_CAMPAIGNS.find(c => c.id === campaignId);
                    const campaignTitle = target?.campaignTitle || target?.title || target?.campaignName || campaignId;
                    const amount = target?.grossContractValue || target?.budget || 0;

                    try {
                      if (target) {
                        await setDoc(doc(db, "studio-campaigns", campaignId), cleanForFirestore({
                          ...target,
                          escrowStatus: 'Disbursed',
                          subagency: currentUser?.subagency || 'pod_main',
                          tenantId: currentUser?.tenantId || 'bloom_studio_default'
                        }), { merge: true });
                      }
                    } catch (err) {
                      console.warn("[GlobalPayrollSchedule] Failed to disburse campaign on Firestore:", err);
                    }

                    // Update ledger and activity log
                    try {
                      const ledgerEntry = {
                        id: `disb_${campaignId}_${Date.now()}`,
                        campaignId,
                        campaignTitle,
                        amount,
                        type: 'PAYOUT_DISBURSEMENT',
                        status: 'Disbursed',
                        disbursedAt: new Date().toISOString(),
                        disbursedBy: currentUser?.name || currentUser?.email || "Director",
                        subagency: currentUser?.subagency || 'pod_main',
                        tenantId: currentUser?.tenantId || 'bloom_studio_default'
                      };
                      await setDoc(doc(db, "studio-ledger", ledgerEntry.id), cleanForFirestore(ledgerEntry));
                    } catch (ledgerErr) {
                      console.warn("[GlobalPayrollSchedule] Ledger entry error:", ledgerErr);
                    }

                    // Update campaigns state in App
                    setCampaigns(prev => prev.map(c => c.id === campaignId ? { ...c, escrowStatus: 'Disbursed' } : c));
                    handleAddActivityLog(currentUser?.name || "Director", currentRole, `Disbursed funds for campaign ${campaignTitle} ($${Number(amount).toLocaleString()})`);
                    triggerSimulatedNotification("Disbursement Executed", `Released funds for ${campaignTitle}. Ledger updated.`, "success");
                  }}
                />
            );
        case "notifications":
            return (
                <PhoneSimulator
                  notifications={phoneNotifications}
                  onTriggerNotification={(title, body, type) => {
                    const newId = "p_" + Date.now();
                    setPhoneNotifications((prev) => [
                      ...prev,
                      {
                        id: newId,
                        title,
                        body,
                        app: "Bloom Studio",
                        time: "Now",
                        type,
                      },
                    ]);
                    setNotifications((prev) => [
                      {
                        id: "not_" + Date.now(),
                        title,
                        detail: body,
                        type: type || "info",
                        created: "Just now",
                        read: false,
                      },
                      ...prev,
                    ].slice(0, 50));
                  }}
                  currentRole={currentRole}
                  currentUser={firebaseAuthUser}
                  userProfile={userProfile}
                  creators={visibleCreators}
                  staff={visibleStaff}
                />
            );
        case "ai-media-studio":
            return (
                <AiMediaStudio
                  currentUser={currentUser}
                  currentRole={currentRole}
                  primaryBrandColor={primaryBrandColor}
                  cardBgColor={cardBgColor}
                  onAddActivityLog={handleAddActivityLog}
                  triggerNotification={triggerSimulatedNotification}
                />
            );
        case "creator-ai-twin":
             return <CreatorTwinDashboard currentUser={currentUser} />;
        case "synthetic-media-studio":
             return (
               <SyntheticMediaStudio
                 currentUser={currentUser}
                 currentRole={currentRole}
                 onAddActivityLog={handleAddActivityLog}
                 triggerNotification={triggerSimulatedNotification}
               />
             );
        case "pitch-forwarder":
             return (
                <CreatorPitchForwarder
                  creatorHandle={currentUser?.handle}
                  currentRole={currentRole}
                  currentUser={currentUser}
                  onAddActivityLog={handleAddActivityLog}
                  triggerNotification={triggerSimulatedNotification}
                />
             );
        case "compliance-directory":
             return (
               <TalentComplianceDirectory 
                 currentUser={currentUser} 
                 currentRole={currentRole}
                 creators={visibleCreators}
                 onNotify={triggerSimulatedNotification}
                 triggerNotification={triggerSimulatedNotification}
                 onAddActivityLog={handleAddActivityLog}
                 defaultTab="tos-registry"
               />
             );
        case "stock-avatar-studio":
             return <StockAvatarStudio />;
        case "agency-vsl-hero":
             return <AgencyVSLHero />;
        case "talent-showcase":
             return (
               <div className="bg-[#0b1320] rounded-2xl overflow-hidden shadow-2xl min-h-screen">
                 <PublicTalentShowcase
                   currentRole={currentRole || "brand"}
                   currentUser={currentUser}
                   onStartAgencySignup={() => setShowAgencySignup(true)}
                 />
               </div>
             );
        case "public-portfolio": {
             const { effectiveRole, isBrandShareView } = getPortfolioViewMode(currentUser, currentRole);
             return (
                <div className="bg-[#0b1320] rounded-2xl overflow-hidden shadow-2xl">
                  <PublicCreatorPortfolio
                    initialCreatorHandle={getUrlCreatorHandle() || currentUser?.handle || "@elenarostova"}
                    onStartAgencySignup={() => setShowAgencySignup(true)}
                    onNavigateHome={isAuthenticated ? () => {
                      if (typeof window !== 'undefined' && window.location.hash.includes('portfolio')) {
                        window.history.replaceState(null, '', window.location.pathname);
                      }
                      setActiveScreen("briefing");
                    } : undefined}
                    currentRole={effectiveRole}
                    currentUser={currentUser}
                    creators={isBrandShareView ? [] : visibleCreators}
                    delegationSettings={delegationSettings}
                  />
                </div>
             );
        }
        case "creator-match":
        case "match-or-pass":
             return (
                <div className="bg-[#0b1320] rounded-2xl overflow-hidden shadow-2xl">
                  <MatchOrPass
                    creators={visibleCreators}
                    setCreators={setCreators}
                    deals={visibleDeals}
                    onAddDeal={async (newDeal) => {
                      const completeDeal: Deal = {
                        ...newDeal,
                        subagency: (newDeal as any).subagency || currentUser?.subagency || "pod_main",
                        tenantId: (newDeal as any).tenantId || currentUser?.tenantId || "bloom_studio_default",
                        createdAt: (newDeal as any).createdAt || new Date().toISOString()
                      };
                      setDeals((prev) => {
                        const updated = [completeDeal, ...prev];
                        safeStorage.setItem("wl_deals", JSON.stringify(updated));
                        return updated;
                      });
                      try {
                        await setDoc(doc(db, "studio-deals", completeDeal.id), cleanUndefinedForFirestore(completeDeal));
                      } catch (err) {
                        console.warn("[MatchOrPass] Firestore save error:", err);
                      }
                    }}
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                  />
                </div>
             );
        case "pod-configuration":
            return <PodConfigurationDashboard currentUser={currentUser} currentRole={currentRole} creators={visibleCreators} setCreators={setCreators} deals={visibleDeals} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "activity-log":
        case "activity-chart":
            return <LiveBotActivityLog externalLogs={wl_botLogs} isActive={true} />;
        case "affiliate-sales":
            return <AffiliateSalesLedger creators={visibleCreators} currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "agency-academy-sop":
        case "procedures":
            return <AgencyAcademyAndSOPs currentRole={(currentRole as any) || "none"} onNavigateToScreen={(screenId) => setActiveScreen(screenId)} />;
        case "agent-management-hub":
            return <AgentManagementHub creators={visibleCreators} deals={visibleDeals} currentUser={currentUser} currentRole={currentRole} primaryBrandColor={primaryBrandColor} cardBgColor={cardBgColor} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} onNavigateToScreen={(screenId) => setActiveScreen(screenId)} />;
        case "agent-manager-training":
            return <AgentManagerTraining currentUser={currentUser} onBack={() => setActiveScreen("agent-management-hub")} />;
        case "agent-onboard":
        case "agent-onboarding":
            return <AgentOnboardingDashboard currentUser={currentUser} currentRole={currentRole} onNavigateToScreen={(screenId) => setActiveScreen(screenId)} />;
        case "analytics":
            return <Analytics creators={visibleCreators} deals={visibleDeals} invoices={visibleInvoices} contracts={visibleContracts} currentRole={currentRole} currentUser={currentUser} primaryBrandColor={primaryBrandColor} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "animate-video":
            return <VeoVideoAnimator creatorName={currentUser?.name} creatorHandle={currentUser?.handle} primaryBrandColor={primaryBrandColor} cardBgColor={cardBgColor} onTriggerNotification={triggerSimulatedNotification} onAddActivityLog={handleAddActivityLog} />;
        case "announcement-center":
            return <AnnouncementCenter announcements={announcements} setAnnouncements={setAnnouncements} currentRole={(currentRole as any) || "none"} currentUser={currentUser} creators={visibleCreators} triggerNotification={triggerSimulatedNotification} onAddActivityLog={handleAddActivityLog} agentMgrCanAnnounce={agentMgrCanAnnounce} />;
        case "audit-tool-loop":
            return <AuditToolLoop deals={visibleDeals} creators={visibleCreators} reviews={visibleReviews} contracts={visibleContracts} invoices={visibleInvoices} currentRole={currentRole} currentUser={currentUser} tenantId={activeTenantConfig?.agencyName || "bloom_studio_default"} primaryBrandColor={primaryBrandColor} cardBgColor={cardBgColor} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "bot-hub":
            return <BotHub currentUser={currentUser} tenantId={tenantId} onAddBotLog={(log) => setWlBotLogs((prev) => [log, ...prev])} botLogs={wl_botLogs} creators={visibleCreators} deals={visibleDeals} invoices={visibleInvoices} contracts={visibleContracts} contentReviewsList={visibleReviews} missions={visibleMissions} />;
        case "client-reports":
        case "brand-reports":
            return (
              <ClientReportCenter 
                currentRole={currentRole} 
                userRole={currentRole} 
                reports={visibleCampaigns.map((c: any) => ({
                    id: c.id || Math.random().toString(),
                    campaignName: c.name || "Untitled Campaign",
                    brandName: c.brand || currentUser?.name || "Brand",
                    date: c.deadline || "TBD",
                    niche: "Lifestyle",
                    totalViews: c.statusFlags?.includes("Viral") ? "1.2M Views" : "125K Views",
                    totalReach: "350K+",
                    engagementRate: "4.8%",
                    ugcAssetYield: Array.isArray(c.deliverables) ? c.deliverables.length : 0
                }))}
              />
            );
        case "manager-campaign":
        case "manager-deliverables":
            {
              const selectedCampaign = campaigns[0]; // Fallback to first available campaign
              const deliverables = selectedCampaign?.deliverables.map((d: string, idx: number) => ({
                id: `del_${selectedCampaign.id}_${idx}`,
                creatorHandle: selectedCampaign.creator.split(',')[0].trim() || "@creator",
                niche: "Lifestyle" as const,
                contractStatus: "Active" as const,
                currentMilestone: d,
                dueDate: selectedCampaign.deadline,
                complianceChecked: true
              })) || [];

              return (
                <ManagerCampaignView
                  user={{
                    uid: currentUser?.id || "agent_01",
                    name: currentUser?.name || "Staff Manager",
                    email: currentUser?.email || "staff@bloomstudio.com",
                    role: (currentRole === "agent" ? "Agent" : isAgentMgr ? "AgentManager" : currentRole === "director" ? "Director" : "none") as any,
                  } as any}
                  campaignTitle={selectedCampaign?.name || "Q3 Influencer Deliverables & Approvals"}
                  brandName={selectedCampaign?.brand || activeTenantConfig?.agencyName || "Bloom & Co. Studio"}
                  deliverables={deliverables}
                />
              );
            }
        case "campaigns":
        case "campaign-workspace":
            return <RoleGuardedCampaignWorkspace
                    user={{
                      uid: currentUser?.id || "agent_01",
                      name: currentUser?.name || "Staff User",
                      email: currentUser?.email || "staff@bloomstudio.com",
                      role: (currentRole === "agent" ? "Agent" : isAgentMgr ? "AgentManager" : currentRole === "director" ? "Director" : "none") as any,
                    } as any}
                    delegationSettings={delegationSettings}
                    campaign={{
                      id: campaigns?.[0]?.id || "camp_default",
                      name: campaigns?.[0]?.name || "Untitled Campaign",
                      grossBrandContractValue: 0,
                      influencerPayout: 0,
                    } as any}
                  />;
        case "chat":
        case "messages":
        case "chat-system":
            return <ChatSystem currentRole={(currentRole as any) || "none"} currentUser={currentUser} creators={visibleCreators} deals={visibleDeals} campaigns={visibleCampaigns} threads={threads} onSendMessage={handleSendMessage} onAddThread={handleAddThread} onDeleteThread={handleDeleteThread} />;
        case "commission":
            return <ManagerCommissionLog
                    currentUser={{
                      uid: currentUser?.id || "agent_01",
                      name: currentUser?.name || "Assigned Agent",
                      email: currentUser?.email || "agent@bloomstudio.com",
                      role: (currentRole === "agent" ? "Agent" : isAgentMgr ? "AgentManager" : currentRole === "director" ? "Director" : "none") as any,
                      position: currentRole === "agent" ? "Talent Agent & Deal Negotiator" : "Agent Operations Manager",
                      assignedPod: activeTenantConfig?.agencyName || "Default Pod",
                      totalEarnedToDate: 48500,
                      pendingDisbursal: 6200,
                      managerCompensation: { payType: "Percentage", amount: 15 },
                    } as any}
                  />;
        case "content-library":
        case "my-content":
        case "creative-assets-bank":
            return <ContentLibrary creators={visibleCreators} deals={visibleDeals} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} currentUser={currentUser} currentRole={currentRole} assets={contentLibrary} setAssets={setContentLibrary} reviewsList={visibleReviews} onNavigate={(screenId) => setActiveScreen(screenId)} />;
        case "contracts":
            return <ContractsVault
                    contracts={visibleContracts}
                    stagedContracts={[]}
                    creators={visibleCreators}
                    currentRole={currentRole || "none"}
                    currentUser={currentUser}
                    isRestrictedRole={isAgentMgr}
                    onSaveContract={handleSaveContract}
                    onDeleteContract={handleDeleteContract}
                    onStageContract={() => {}}
                    onDeleteStagedContract={() => {}}
                    onAddActivityLog={handleAddActivityLog}
                    onTriggerNotification={(title, message, type) =>
                      triggerSimulatedNotification(title, message, type === "error" ? "danger" : type)
                    }
                  />;
        case "signed-agreements-vault":
        case "signed-agreements":
        case "signed-agreements-audit":
            return (
              <SignedAgreementsVault
                currentRole={currentRole || "director"}
                currentUser={currentUser}
                onNavigate={(screenId) => setActiveScreen(screenId)}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "copyright-scanner":
            return <CopyrightAudioScanner />;
        case "creative-production-suite":
            return <CreativeProductionSuite creators={visibleCreators} deals={visibleDeals} currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} primaryBrandColor={primaryBrandColor} cardBgColor={cardBgColor} />;
        case "creative-briefing":
            return (
              <CreativeBriefingStudio 
                creators={visibleCreators}
                currentUser={currentUser}
                currentRole={currentRole}
                deals={visibleDeals}
                onAddActivityLog={handleAddActivityLog}
                triggerNotification={triggerSimulatedNotification}
                delegationSettings={delegationSettings}
              />
            );
        case "creator-briefs":
            if (currentRole === "creator") {
              return (
                <CreatorDealBriefsView
                  deals={deals}
                  currentUser={currentUser}
                  currentRole={currentRole}
                  primaryBrandColor={primaryBrandColor}
                  cardBgColor={cardBgColor}
                  onNavigateToSubmit={() => setActiveScreen("submit-content")}
                  onNavigateToMarketplace={() => setActiveScreen("open-marketplace")}
                  triggerNotification={triggerSimulatedNotification}
                />
              );
            }
            return <CreatorPortalDashboard creatorHandle={currentUser?.handle} creatorName={currentUser?.name} />;
        case "creator-delivery":
        case "creator-inventory":
        case "fulfillment-hub":
            return <FulfillmentHub
                    user={({
                      ...(userProfile || {}),
                      ...(currentUser || {}),
                      uid: currentUser?.id || currentUser?.uid || userProfile?.uid || "user_01",
                      name: currentUser?.name || userProfile?.displayName || "Elena Rostova",
                      email: currentUser?.email || userProfile?.email || "user@bloomstudio.com",
                      role: (currentRole === "creator" ? "Creator" : currentRole === "agent" ? "Agent" : isAgentMgr ? "AgentManager" : currentRole === "coordinator" ? "Coordinator" : currentRole === "director" ? "Director" : currentRole === "brand" ? "Brand" : "Director") as any,
                      handle: currentUser?.handle || userProfile?.handle || (currentRole === "creator" ? "@alexjones" : undefined),
                      isPlatformOwner: currentRole === "director" ? !!(currentUser?.isPlatformOwner || userProfile?.isPlatformOwner) : false
                    }) as any}
                    currentRole={currentRole}
                    currentUser={currentUser}
                    creators={visibleCreators}
                    triggerNotification={triggerSimulatedNotification}
                  />;
        case "creator-referral":
            return (
              <CreatorReferralNetwork
                currentRole={currentRole}
                currentUser={currentUser}
                referrals={referrals}
                onAddReferral={handleAddReferral}
                onUpdateReferral={handleUpdateReferral}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "enterprise-security":
            return <EnterpriseSecurity onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} currentUser={currentUser} currentRole={currentRole} />;
        case "system-audit-log":
        case "audit-trail":
            return (
              <SystemAuditLogView
                currentUser={currentUser}
                currentRole={currentRole}
                primaryBrandColor={primaryBrandColor}
                onNavigate={(screenId) => setActiveScreen(screenId)}
                triggerNotification={triggerSimulatedNotification}
              />
            );
        case "privacy-compliance":
            return <PrivacyComplianceCenter currentUser={currentUser} currentRole={currentRole} triggerNotification={triggerSimulatedNotification} onAddActivityLog={handleAddActivityLog} />;
        case "executive-wrapup":
            return <ExecutiveWrapUpReport onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} currentRole={currentRole} />;
        case "financial-contract-hub":
            return (
              <FinancialContractHub 
                userRole={currentRole || "none"} 
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "ftc-compliance":
            return <FtcCompliance creators={visibleCreators} currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "generate-music":
            return <MusicGeneratorView creatorName={currentUser?.name} creatorHandle={currentUser?.handle} primaryBrandColor={primaryBrandColor} cardBgColor={cardBgColor} onTriggerNotification={triggerSimulatedNotification} onAddActivityLog={handleAddActivityLog} />;
        case "growth":
        case "growth-generator":
            return <GrowthPlanningGenerator currentRole={currentRole || "none"} creators={visibleCreators} />;
        case "irs-tax-vault":
            return (
              <UnifiedTaxHub 
                creators={visibleCreators} 
                currentUser={currentUser} 
                currentRole={currentRole} 
                onAddActivityLog={handleAddActivityLog} 
                triggerNotification={triggerSimulatedNotification} 
                defaultTab="vault" 
              />
            );
        case "jit-stripe-card":
            return <UnifiedStripeCardsHub creators={visibleCreators} currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} defaultTab="jit" />;
        case "kb":
            return <KnowledgeBase currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "media-kits":
            return <MediaKits creators={visibleCreators} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} currentRole={currentRole} currentUser={currentUser} />;
        case "onboarding":
            return <TalentOnboardingModule currentRole={currentRole} userRole={currentRole} />;
        case "open-marketplace":
            return <OpenMarketplace creators={visibleCreators} deals={visibleDeals} setDeals={setDeals} currentUser={currentUser} currentRole={currentRole} triggerNotification={triggerSimulatedNotification} onAddActivityLog={handleAddActivityLog} />;
        case "outreach":
            return <OutreachTracker
                    prospects={wl_prospects}
                    setProspects={setWlProspects}
                    handleAddProspect={(e) => { e.preventDefault(); }}
                    isAddProspectModalOpen={wl_isAddProspectModalOpen}
                    setIsAddProspectModalOpen={setWlIsAddProspectModalOpen}
                    onMoveReadyProspectsToIntake={() => {}}
                    handleAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                    primaryBrandColor={primaryBrandColor}
                    cardBgColor={cardBgColor}
                    currentUser={currentUser}
                    currentRole={currentRole || "none"}
                    setCreators={setCreators}
                    creators={visibleCreators}
                  />;
        case "alerts":
        case "performance-alerts":
            return <PerformanceAlerts creators={visibleCreators} deals={visibleDeals} currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} onNavigate={(screenId) => setActiveScreen(screenId)} reviewsList={visibleReviews} />;
        case "repurposing-log":
            return <RepurposingLog creators={visibleCreators} deals={visibleDeals} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} currentUser={currentUser} currentRole={currentRole} logs={repurposingLogs} setLogs={setRepurposingLogs} />;
        case "retainer-quota-ledgers":
            return <MonthlyRetainerQuotaLedgers creators={visibleCreators} currentUser={currentUser} currentRole={currentRole || "none"} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "rights-buyout":
            return <TalentRightsBuyoutManager userRole={currentRole || "none"} availableCreators={visibleCreators as any} />;
        case "seo-blog":
            return <ProgrammaticSeoBlog />;
        case "stripe-debit-controller":
            return <UnifiedStripeCardsHub creators={visibleCreators} currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} defaultTab="controller" />;
        case "stripe-expense-handler":
            return <StripeExpenseNotificationHandler currentUser={currentUser} currentCreatorHandle={currentUser?.handle} triggerNotification={triggerSimulatedNotification} />;
        case "submit-content":
            return <SubmitContent creators={visibleCreators} deals={visibleDeals} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} currentRole={currentRole || "none"} currentUser={currentUser} primaryBrandColor={primaryBrandColor} cardBgColor={cardBgColor} mode="submit" reviewsList={visibleReviews} onSaveReview={handleSaveReviewItem} onNavigate={(screenId) => setActiveScreen(screenId)} />;
        case "system-status":
            return <SystemStatusDashboard user={{ role: currentRole || "none", email: currentUser?.email, name: currentUser?.name }} />;
        case "trash-bin":
            return <TrashBin
                    trashItems={wl_trashItems.filter(item => {
                      if (isPlatformOwner || currentRole === 'director' || currentRole === 'agency') return true;
                      // Staff only see what they or their pod deleted
                      const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
                      return item.subagency === userPod || item.deletedBy === (currentUser?.name || currentUser?.email);
                    })}
                    onRestore={handleRestoreTrash}
                    onPurge={handlePurgeTrash}
                    onEmptyTrash={() => {
                      if (isPlatformOwner || currentRole === 'director' || currentRole === 'agency') {
                        wl_trashItems.forEach(item => handlePurgeTrash(item.id));
                      } else {
                        const userPod = currentUser?.subagency || currentUser?.tenantId || 'pod_main';
                        wl_trashItems.filter(item => item.subagency === userPod).forEach(item => handlePurgeTrash(item.id));
                      }
                    }}
                  />;
        case "ugc-case-study":
            return <UgcCaseStudyGenerator />;
        case "upsell-manifest":
            return (
              <BrandContractUpsellManifest 
                userRole={currentRole || "none"} 
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "w9-1099-tracker":
            return (
              <UnifiedTaxHub 
                creators={visibleCreators} 
                currentUser={currentUser} 
                currentRole={currentRole} 
                onAddActivityLog={handleAddActivityLog} 
                triggerNotification={triggerSimulatedNotification} 
                defaultTab="tracker" 
              />
            );
        case "workflow-milestones-hub":
            return <WorkflowMilestonesHub />;
        case "daps-shield":
            return <DigitalAssetProtectionSystem creators={visibleCreators} currentUser={currentUser} currentRole={currentRole} onAddActivityLog={handleAddActivityLog} triggerNotification={triggerSimulatedNotification} />;
        case "talent-showcase":
            return (
              <PublicTalentShowcase
                creators={visibleCreators}
                currentRole={currentRole}
                currentUser={currentUser}
                onStartAgencySignup={() => setShowAgencySignup(true)}
              />
            );
        case "inbound-leads":
            return (
              <InboundLeadsScreen
                inboundLeads={inboundLeads}
                currentRole={currentRole}
                currentUser={currentUser}
                primaryBrandColor={primaryBrandColor}
                cardBgColor={cardBgColor}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
                onNavigate={(screen) => setActiveScreen(screen)}
              />
            );
        case "casting":
        case "casting-calls":
            return (
              <CastingCalls
                currentRole={currentRole || "none"}
                currentUser={currentUser}
                creators={visibleCreators}
                deals={visibleDeals}
                setDeals={setDeals}
                primaryBrandColor={primaryBrandColor}
                onAddActivityLog={handleAddActivityLog}
                triggerNotification={triggerSimulatedNotification}
              />
            );
        case "exclusivity-tracker":
            return (
              <ExclusivityTracker 
                creators={visibleCreators} 
                deals={visibleDeals} 
                currentRole={currentRole}
                currentUser={currentUser}
              />
            );
        case "waitlist":
        case "access-codes":
            return (
                <WaitlistDashboard 
                    currentUser={currentUser}
                    currentRole={currentRole}
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                />
            );
        case "brand-crm":
            return <BrandCrm 
                    currentUser={currentUser} 
                    currentRole={currentRole}
                    triggerNotification={triggerSimulatedNotification} 
                    onAddActivityLog={handleAddActivityLog} 
                    onNavigate={(screen) => setActiveScreen(screen)}
                  />;
        case "agency-insights":
        case "public-insights":
        case "insights":
            return <AgencyPublicInsights currentRole={currentRole} />;
        case "agency-vsl-hero":
            return (
              <AgencyVSLHero 
                vslVideoUrl={vslVideoUrl} 
                onNavigate={(screenId) => setActiveScreen(screenId)} 
                currentUser={currentUser}
                currentRole={currentRole}
                setVslVideoUrl={setVslVideoUrl}
              />
            );
        case "cashflow-alerts":
        case "cashflow":
            return (
              <CashflowNotificationCenter
                currentUser={{
                  uid: currentUser?.id || "dir_01",
                  name: currentUser?.name || "Director",
                  email: currentUser?.email || "director@bloomstudio.com",
                  role: (currentRole === "agent" ? "Agent" : isAgentMgr ? "AgentManager" : currentRole === "director" ? "Director" : "none") as any,
                  position: "Executive Operations",
                  assignedPod: activeTenantConfig?.agencyName || "Main Agency Pod",
                  totalEarnedToDate: 125000,
                  pendingDisbursal: 15400,
                  managerCompensation: { payType: "Percentage", amount: 20 },
                } as any}
              />
            );
        case "casting-dashboard":
        case "casting-auditions":
            return (
              <CastingDashboard
                currentUser={currentUser}
                currentRole={currentRole}
                canAgentMgrCreateCastingCalls={true}
                creators={visibleCreators}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
              />
            );
        case "creator-payouts":
            return (
              <CreatorPortalView
                currentUser={currentUser}
                creators={visibleCreators}
                setCreators={setCreators}
                setActiveScreen={navigateToScreen}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
                primaryBrandColor={primaryBrandColor}
                cardBgColor="#0D1830"
                deals={visibleDeals}
                missions={missions}
                agencySchedules={agencySchedules}
                setAgencySchedules={setAgencySchedules}
                referrals={referrals}
                onAddReferral={handleAddReferral}
                onUpdateReferral={handleUpdateReferral}
                contentReviewsList={visibleReviews}
                onSaveReview={handleSaveReviewItem}
                initialAnchor="creator-payouts"
              />
            );
        case "creator-portal":
        case "creator-hub":
        case "creator-workspace":
        case "creator-dash":
            return (
              <CreatorPortalView
                currentUser={currentUser}
                creators={visibleCreators}
                setCreators={setCreators}
                setActiveScreen={navigateToScreen}
                triggerNotification={triggerSimulatedNotification}
                onAddActivityLog={handleAddActivityLog}
                primaryBrandColor={primaryBrandColor}
                cardBgColor="#0D1830"
                deals={visibleDeals}
                missions={missions}
                agencySchedules={agencySchedules}
                setAgencySchedules={setAgencySchedules}
                referrals={referrals}
                onAddReferral={handleAddReferral}
                onUpdateReferral={handleUpdateReferral}
                contentReviewsList={visibleReviews}
                onSaveReview={handleSaveReviewItem}
              />
            );
        case "one-time-contractor":
        case "contractor-portal":
        case "contractor-bench":
            return (
              <OneTimeCreatorPortal
                currentUser={currentUser}
                currentRole={currentRole}
                contractorName={currentUser?.name || "Jordan Taylor"}
                contractorEmail={currentUser?.email || "contractor@bloomstudio.internal"}
                contractorRole="Contractor"
                onSignComplete={() => {
                  triggerSimulatedNotification(
                    "Contractor Legal E-Sign",
                    "W-9 and Flat-Fee Contractor Agreement successfully executed.",
                    "success"
                  );
                  handleAddActivityLog(currentUser?.name || "Jordan Taylor", currentRole, "Signed Standby Contractor Agreement & W-9 Tax Certification");
                }}
                onAddActivityLog={handleAddActivityLog}
                triggerNotification={triggerSimulatedNotification}
              />
            );
        case "pod-invite":
            return (
              <PodInviteSignupPage
                inviteCode={inviteToken || "POD-ALPHA"}
                onExitInvite={() => navigateToScreen("briefing")}
                agencyName={activeTenantConfig?.agencyName || "Bloom & Co. Studio"}
              />
            );
        case "creator-pipeline-dash":
            return <CreatorPortalDashboard creatorHandle={currentUser?.handle} creatorName={currentUser?.name} />;
        case "bot-control":
            return (
                <BotControlPanel 
                    currentUser={currentUser}
                    currentRole={currentRole}
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                />
            );
        case "training":
            return (
              <TrainingHub
                currentRole={currentRole || "none"}
                onAskKB={() => {}}
                kbAnswer={""}
                isKBLoading={false}
              />
            );
        case "integrations":
            return (
                <AccountingIntegrations 
                    creators={visibleCreators}
                    deals={visibleDeals}
                    taxItems={[]}
                    currentUser={currentUser}
                    onAddActivityLog={handleAddActivityLog}
                    triggerNotification={triggerSimulatedNotification}
                />
            );
        case "audit-trail":
            return <LiveBotActivityLog externalLogs={wl_botLogs} />;
        case "agency-setup":
        case "agency-branding":
        case "team-announcements":
        case "creator-announcements":
        case "brand-blacklist":
        case "brand-block":
            return (
              <OperationBoard 
                activeScreen={activeScreen}
                setActiveScreen={setActiveScreen}
                tenantId={tenantId}
                creators={visibleCreators}
                setCreators={setCreators}
                deals={visibleDeals}
                setDeals={setDeals}
                invoices={[]}
                onAddActivityLog={handleAddActivityLog}
                triggerNotification={triggerSimulatedNotification}
                agencyName={agencyName}
                setAgencyName={setAgencyName}
                legalEntityName={legalEntityName}
                setLegalEntityName={setLegalEntityName}
                primaryBrandColor={primaryBrandColor}
                setPrimaryBrandColor={setPrimaryBrandColor}
                sidebarBgColor={sidebarBgColor}
                setSidebarBgColor={setSidebarBgColor}
                mainDashboardBg={mainDashboardBg}
                setMainDashboardBg={setMainDashboardBg}
                cardBgColor={cardBgColor}
                setCardBgColor={setCardBgColor}
                textMainColor={textMainColor}
                setTextMainColor={setTextMainColor}
                textMutedColor={textMutedColor}
                setTextMutedColor={setTextMutedColor}
                currentRole={currentRole || "none"}
                directorName={directorName}
                setDirectorName={setDirectorName}
                systemLogo={systemLogo}
                setSystemLogo={setSystemLogo}
                vslVideoUrl={vslVideoUrl}
                setVslVideoUrl={setVslVideoUrl}
                navCategoriesState={navCategoriesState}
                setNavCategoriesState={setNavCategoriesState}
                agentMgrCanAnnounce={agentMgrCanAnnounce}
                setAgentMgrCanAnnounce={setAgentMgrCanAnnounce}
                agentManagerCanAddCampaigns={agentManagerCanAddCampaigns}
                agentManagerCanAddToPortfolio={agentManagerCanAddToPortfolio}
                agentManagerCanDraftBriefs={agentManagerCanDraftBriefs}
                currentUser={currentUser}
                announcements={announcements}
                setAnnouncements={setAnnouncements}
                actionQueue={actionQueue}
                setActionQueue={setActionQueue}
                onboardingItems={onboardingItems}
                setOnboardingItems={setOnboardingItems}
                onSendMassBroadcast={handleSendMassBroadcast}
                onOpenMassBroadcast={() => setShowBroadcastModal(true)}
                onPurgeSeedData={handlePurgeSeedData}
                onMigrateCreatorsToStudio={handleMigrateCreatorsToStudio}
              />
            );
        case "user-accounts":
            return <SystemStatusDashboard user={{ role: currentRole || "none", email: currentUser?.email, name: currentUser?.name }} />;
        default:
            return null;
    }
  };

  return (
    <>
      {isAuthLoading && (
        <div className="min-h-screen bg-[#060B14] text-white flex flex-col items-center justify-center p-6 select-none">
          <div className="flex flex-col items-center space-y-4">
            <div className="w-10 h-10 border-2 border-[#C9A46A] border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-slate-300 font-sans tracking-wide">
              Verifying workspace credentials & permissions...
            </p>
          </div>
        </div>
      )}
      {/* Platform Emergency Kill Switch Barrier for Public / Non-Platform Owners */}
      {!isAuthLoading && maintenanceConfig.enabled && !isPlatformOwner && (
        <SiteUnderConstructionNotice
          config={maintenanceConfig}
          currentUser={currentUser}
          onDeactivateKillSwitch={async () => {
            const updated = await saveStoredMaintenanceConfig({ enabled: false }, currentUser?.email);
            setMaintenanceConfig(updated);
          }}
        />
      )}

      {!isAuthLoading && (!maintenanceConfig.enabled || isPlatformOwner) && !isAuthenticated && showAgencySignup && (
        <AgencySignupForm
          primaryBrandColor={primaryBrandColor}
          cardBgColor={cardBgColor}
          onBack={() => setShowAgencySignup(false)}
        />
      )}
      {!isAuthLoading && (!maintenanceConfig.enabled || isPlatformOwner) && !isAuthenticated && !showAgencySignup && (
        (typeof window !== 'undefined' && (
          window.location.hash.includes('match-pass') ||
          window.location.hash.includes('sneak-peek') ||
          window.location.hash.includes('casting') ||
          window.location.search.includes('mode=sneak-peek') ||
          activeScreen === "match-or-pass"
        )) ? (
          <div className="min-h-screen bg-[#0A1220] text-slate-100 font-sans p-4 md:p-8">
            <MatchOrPass
              currentRole="brand"
              currentUser={null}
              creators={visibleCreators}
              onAddActivityLog={handleAddActivityLog}
              triggerNotification={triggerSimulatedNotification}
            />
          </div>
        ) : (typeof window !== 'undefined' && (
          window.location.hash.includes('showcase') ||
          window.location.hash.includes('talent-showcase') ||
          window.location.pathname.includes('showcase') ||
          window.location.search.includes('showcase') ||
          activeScreen === "talent-showcase"
        )) ? (
          <div className="min-h-screen bg-[#0A1220] text-slate-100 font-sans">
            <PublicTalentShowcase
              currentRole="brand"
              currentUser={null}
              onStartAgencySignup={() => setShowAgencySignup(true)}
            />
          </div>
        ) : (typeof window !== 'undefined' && (
          window.location.hash.includes('public-portfolio') ||
          window.location.hash.includes('portfolio') ||
          window.location.pathname.includes('portfolio') ||
          window.location.hash.startsWith('#kit-') ||
          window.location.search.includes('screen=public-portfolio') ||
          (window.location.search.includes('brand=true') && (window.location.search.includes('creator=') || window.location.hash.includes('creator='))) ||
          activeScreen === "public-portfolio"
        )) ? (
          <div className="min-h-screen bg-[#0A1220] text-slate-100 font-sans">
            <PublicCreatorPortfolio
              initialCreatorHandle={getUrlCreatorHandle() || "@elenarostova"}
              currentRole="brand"
              currentUser={null}
              creators={visibleCreators}
              delegationSettings={delegationSettings}
              onLogin={handleDirectLogin}
              onStartAgencySignup={() => setShowAgencySignup(true)}
              onNavigateHome={() => {
                if (typeof window !== 'undefined') {
                  window.history.replaceState(null, '', window.location.pathname);
                }
                setActiveScreen("briefing");
              }}
            />
          </div>
        ) : (
          <LandingPage
            agencyName={activeTenantConfig?.agencyName || agencyName}
            legalEntityName={activeTenantConfig?.legalEntityName || legalEntityName}
            primaryBrandColor={primaryBrandColor}
            cardBgColor={cardBgColor}
            mainDashboardBg={mainDashboardBg}
            textMainColor={textMainColor}
            textMutedColor={textMutedColor}
            hiringSettings={activeTenantConfig?.hiringSettings}
            vslVideoUrl={vslVideoUrl}
            onLogin={handleDirectLogin}
            onOpenBrandPartnerModal={() => setShowBrandPartnerModal(true)}
            onBrandSubmit={() => {}}
            onCreatorSubmit={() => {}}
            onAgentSubmit={() => {}}
            onStartAgencySignup={() => setShowAgencySignup(true)}
          />
        )
      )}

      {/* Standalone Brand Share Portfolio View when authenticated as Brand or viewing shared portfolio */}
      {!isAuthLoading && (!maintenanceConfig.enabled || isPlatformOwner) && isAuthenticated && activeScreen === "public-portfolio" && getPortfolioViewMode(currentUser, currentRole).isBrandShareView ? (
        <div className="min-h-screen bg-[#0A1220] text-slate-100 font-sans">
          <PublicCreatorPortfolio
            initialCreatorHandle={getUrlCreatorHandle() || currentUser?.handle || "@elenarostova"}
            onStartAgencySignup={() => setShowAgencySignup(true)}
            currentRole={getPortfolioViewMode(currentUser, currentRole).effectiveRole}
            currentUser={currentUser}
            creators={visibleCreators}
            delegationSettings={delegationSettings}
            onNavigateHome={() => {
              if (typeof window !== 'undefined') {
                window.history.replaceState(null, '', window.location.pathname);
              }
              setActiveScreen("briefing");
            }}
          />
        </div>
      ) : null}

      {!isAuthLoading && (!maintenanceConfig.enabled || isPlatformOwner) && isAuthenticated && !(activeScreen === "public-portfolio" && getPortfolioViewMode(currentUser, currentRole).isBrandShareView) && (
        <div
          className="flex h-screen h-[100dvh] max-h-[100dvh] bg-[#0A1220] text-slate-100 overflow-hidden font-sans w-full max-w-full"
          style={{ backgroundColor: mainDashboardBg }}
        >
      {/* Container for dynamic stackable popups */}
      <div
        id="toastNotificationStack"
        style={{
          position: "fixed",
          top: "20px",
          right: "20px",
          zIndex: 9999,
          display: "flex",
          flexDirection: "column",
          gap: "10px",
          maxWidth: "350px",
          width: "calc(100vw - 40px)",
        }}
      ></div>

      {/* Fullscreen Billing Block Cover Grid */}
      {(billingStatus === "suspended" || billingStatus === "past_due") && (
        <div
          id="billingLockoutScreen"
          className="fixed inset-0 z-50 flex flex-col justify-center items-center text-center p-6 bg-[#0b1424]"
        >
          <div className="bg-[#152238] border border-white/5 p-12 rounded-2xl max-w-md shadow-2xl relative overflow-hidden text-center">
            <div
              className="absolute top-0 inset-x-0 h-1.5"
              style={{ backgroundColor: primaryBrandColor }}
            ></div>
            <div className="text-5xl mb-6">💳</div>
            <h1 className="text-white text-2xl font-bold tracking-tight mb-3">
              Workspace Access Suspended
            </h1>
            <p className="text-[#8892b0] text-xs leading-relaxed mb-8">
              The subscription account for this custom subdomain has been paused
              due to a billing issue. Please contact your administrative
              director to restore workspace data channels.
            </p>
          </div>
        </div>
      )}

      {/* Access Pending Approval Screen for users without an assigned workspace role */}
      {currentRole === "none" && !currentUser?.isPlatformOwner && (
        <div
          id="pendingApprovalScreen"
          className="fixed inset-0 z-50 flex flex-col justify-center items-center text-center p-6 bg-[#060B14]"
        >
          <div className="bg-[#0D1628] border border-[#C9A46A]/40 p-8 rounded-2xl max-w-md shadow-2xl relative overflow-hidden text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-[#C9A46A]/20 text-[#C9A46A] flex items-center justify-center mx-auto text-xl">
              ⏳
            </div>
            <h1 className="text-white text-xl font-bold tracking-tight">
              Access Pending Approval
            </h1>
            <p className="text-slate-300 text-xs leading-relaxed">
              Your account ({currentUser?.email || "user"}) has signed in successfully.
              An agency Director or Administrator must assign your workspace role before you can access operational dashboards.
            </p>
            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                onClick={handleLogout}
                className="w-full px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-all cursor-pointer border border-slate-700"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Drawer Backdrop */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/75 backdrop-blur-xs transition-opacity duration-300"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Responsive Slide-out / Desktop Persistent Navigation Sidebar */}
      <aside
        style={{
          backgroundColor: sidebarBgColor,
          borderRightColor: `${primaryBrandColor}20`,
        }}
        className={`fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] lg:max-w-72 lg:static lg:z-auto border-r flex flex-col transition-transform duration-300 ease-in-out shadow-2xl ${
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}
      >
        {/* Sidebar Header */}
        <div
          style={{ borderBottomColor: `${primaryBrandColor}20` }}
          className="h-16 flex items-center justify-between px-5 border-b bg-black/20 shrink-0"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {systemLogo ? (
              <img
                src={systemLogo}
                alt="Agency Logo"
                className="w-8 h-8 rounded-lg object-cover shadow-md shrink-0"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div
                style={{ backgroundColor: primaryBrandColor }}
                className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-[#0A1220] font-serif text-lg shadow-md shrink-0"
              >
                {agencyName.charAt(0)}
              </div>
            )}
            <div className="min-w-0">
              <h2
                style={{ color: primaryBrandColor }}
                className="text-sm font-semibold tracking-wide leading-tight font-serif truncate"
              >
                {agencyName}
              </h2>
              <p className="text-[10px] text-[#6b7c96] truncate capitalize">{currentRole} Portal</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(false)}
            className="lg:hidden text-[#7C8AA8] hover:text-white p-1 rounded-lg hover:bg-white/5"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Items: Collapsible sections showing only titles by default; clicking expands that section's dropdown only */}
        <nav className="flex-1 px-3 py-3 overflow-y-auto space-y-2 scrollbar-thin">
          {navCategoriesState.map((category) => {
            const allowedForRole = ALLOWED_SCREENS_PER_ROLE[currentRole] || ALLOWED_SCREENS_PER_ROLE.none || [];
            const validItems = category.items.filter(
              (item) => {
                if (item.id === "pod-configuration" && !currentUser?.isPlatformOwner) {
                  return false;
                }
                if (item.id === "system-audit-log" && !currentUser?.isPlatformOwner) {
                  return false;
                }
                return item.isActive !== false && allowedForRole.includes(item.id) && ![
                  "deals-revenue-hub"
                ].includes(item.id);
              }
            );

            if (validItems.length === 0) return null;

            const isCategoryOpen = expandedNavCategory === category.title;
            const containsActiveScreen = validItems.some((item) => item.id === activeScreen);

            return (
              <div key={category.title} className="space-y-1">
                {/* Section Title Dropdown Trigger */}
                <button
                  type="button"
                  id={`nav-category-toggle-${category.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
                  onClick={() => handleToggleNavCategory(category.title)}
                  aria-expanded={isCategoryOpen}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-all cursor-pointer group select-none border ${
                    isCategoryOpen
                      ? "bg-white/10 text-white shadow-sm border-white/10"
                      : containsActiveScreen
                      ? "bg-white/5 text-white/90 hover:bg-white/10 border-white/5"
                      : "text-[#8b9bb4] hover:text-white hover:bg-white/5 border-transparent"
                  }`}
                  title={`Click to ${isCategoryOpen ? "collapse" : "view"} ${category.title} items`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {containsActiveScreen && (
                      <span
                        className="w-1.5 h-1.5 rounded-full shrink-0 animate-pulse"
                        style={{ backgroundColor: primaryBrandColor }}
                        title="Active screen in this section"
                      />
                    )}
                    <span className="text-[11px] font-bold tracking-wider uppercase font-mono truncate">
                      {category.title}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded-md font-semibold transition-colors ${
                        isCategoryOpen
                          ? "bg-[#C9A46A]/20 text-[#C9A46A]"
                          : "bg-white/5 text-slate-400 group-hover:text-slate-300"
                      }`}
                    >
                      {validItems.length}
                    </span>
                    <ChevronDown
                      className={`w-3.5 h-3.5 transition-transform duration-200 shrink-0 ${
                        isCategoryOpen
                          ? "rotate-180 text-[#C9A46A]"
                          : "text-slate-400 group-hover:text-slate-200"
                      }`}
                    />
                  </div>
                </button>

                {/* Dropdown Items: shown exclusively for the active category */}
                {isCategoryOpen && (
                  <div
                    id={`nav-category-dropdown-${category.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
                    className="pt-1 pb-1 pl-2 space-y-1 border-l-2 ml-3.5 mt-1 animate-in fade-in slide-in-from-top-1 duration-150"
                    style={{ borderColor: `${primaryBrandColor}40` }}
                  >
                    {validItems.map((item, itemIdx) => {
                      const ItemIcon = item.icon || iconMap[item.iconName] || LayoutDashboard;
                      const isCurrent = activeScreen === item.id;

                      return (
                        <button
                          key={`${category.title}_${item.id}_${itemIdx}`}
                          id={`nav-item-${item.id}`}
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            navigateToScreen(item.id);
                          }}
                          style={
                            isCurrent
                              ? {
                                  backgroundColor: `${primaryBrandColor}18`,
                                  color: primaryBrandColor,
                                  borderLeftColor: primaryBrandColor,
                                }
                              : {}
                          }
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-all border-l-2 ${
                            isCurrent
                              ? "border-l-2 font-semibold shadow-sm"
                              : "border-transparent text-[#7C8AA8] hover:text-white hover:bg-white/5"
                          }`}
                        >
                          <div className="flex items-center gap-2.5 truncate">
                            <ItemIcon
                              className="w-4 h-4 shrink-0"
                              style={{ color: isCurrent ? primaryBrandColor : undefined }}
                            />
                            <span className="truncate">
                              {item.id === "party-deal-assignments" &&
                              (currentRole === "director" || currentRole === "agency")
                                ? "Staff Deals & Assignments"
                                : item.label}
                            </span>
                          </div>
                          {isCurrent && (
                            <span
                              className="w-1.5 h-1.5 rounded-full shrink-0"
                              style={{ backgroundColor: primaryBrandColor }}
                            />
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>
      </aside>

      {/* Main Content Area (Right) */}
      <div className="flex-1 flex flex-col h-full overflow-hidden min-w-0 w-full">
        {/* Top Emergency Lockdown Alert Banner for Platform Owner */}
        {maintenanceConfig.enabled && isPlatformOwner && (
          <div className="bg-rose-950/95 border-b border-rose-500/60 px-4 py-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-rose-200 z-50 shadow-lg">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping shrink-0" />
              <span className="font-bold uppercase tracking-wider text-rose-300 font-mono">
                EMERGENCY KILL SWITCH ACTIVE:
              </span>
              <span className="text-rose-100 text-xs">
                The platform is locked in Maintenance Mode. Visitors and non-owners see the "Under Construction" notice and contract signing is blocked.
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setShowKillSwitchModal(true)}
                className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold cursor-pointer transition-all"
              >
                Configure Notice
              </button>
              <button
                onClick={async () => {
                  const updated = await saveStoredMaintenanceConfig({ enabled: false }, currentUser?.email);
                  setMaintenanceConfig(updated);
                  triggerSimulatedNotification(
                    "Platform Restored Live",
                    "Emergency Kill Switch deactivated. System returned to live status.",
                    "success"
                  );
                }}
                className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow cursor-pointer"
              >
                Deactivate Kill Switch (Go Live)
              </button>
            </div>
          </div>
        )}

        {/* Topbar */}
        <header className="h-16 border-b border-white/5 bg-[#0D1830] flex items-center justify-between px-2.5 sm:px-6 shrink-0 relative z-40 w-full max-w-full overflow-x-auto lg:overflow-visible scrollbar-none gap-2">
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0 min-w-0">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden text-[#7C8AA8] hover:text-white p-2 rounded-xl hover:bg-white/10 border border-white/10 flex items-center gap-2 shrink-0 cursor-pointer transition-all shadow-sm group"
              title="Toggle Menu"
            >
              <Menu className="w-5 h-5 text-[#C9A46A] group-hover:scale-110 transition-transform" />
            </button>

            {/* Back Button */}
            <button
              onClick={handleGoBack}
              className="text-[#7C8AA8] hover:text-white p-2 rounded-xl hover:bg-white/10 border border-white/10 flex items-center justify-center shrink-0 cursor-pointer transition-all shadow-sm"
              title="Go Back"
            >
              <ArrowLeft className="w-4 h-4 text-[#C9A46A]" />
            </button>

            {/* Home Button */}
            <button
              onClick={handleGoHome}
              className="text-[#7C8AA8] hover:text-white p-2 rounded-xl hover:bg-white/10 border border-white/10 flex items-center justify-center shrink-0 cursor-pointer transition-all shadow-sm"
              title="Go to Home Screen (Daily Briefing)"
            >
              <Home className="w-4 h-4 text-[#C9A46A]" />
            </button>

            <div className="hidden md:flex items-center gap-1.5 text-xs text-[#7C8AA8] truncate">
              <span className="capitalize">{currentRole}</span>
              <span>/</span>
              <span className="text-white font-medium capitalize truncate">
                {activeScreen.replace(/-/g, " ")}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* Subagency / Pod Isolation & Work Pod Selector Scoped Exclusively to Authorized Pods */}
            <WorkPodSelector
              currentUser={currentUser}
              currentRole={currentRole}
              liveTenantsMap={liveTenantsMap}
              onSelectPod={handleSwitchWorkPod}
              campaigns={campaigns}
              deals={deals}
              invoices={invoices}
              creators={visibleCreators}
              onNavigate={(screenId) => setActiveScreen(screenId)}
              onOpenExecutiveComparison={() => setActiveScreen("executive-wrapup")}
            />

            {/* Role Switching Selector */}
            <div className="relative shrink-0">
              <select
                value={currentRole}
                onChange={(e) => onRequestRoleSwitch(e.target.value as Role)}
                className="bg-[#111E33] border border-white/10 text-xs text-white rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-[#C9A46A] cursor-pointer"
              >
                <option value="director">Director Portal</option>
                <option value="agentmgr">Agent Manager</option>
                <option value="agent">Talent Agent</option>
                <option value="coordinator">Campaign Coordinator</option>
                <option value="creator">Creator Portal</option>
                <option value="brand">Brand Portal</option>
              </select>
            </div>

            {/* Director Main Navigation Emergency Kill Switch (Platform Owner Control) */}
            <EmergencyKillSwitchNavButton
              config={maintenanceConfig}
              currentUser={currentUser}
              onOpenPanel={() => setShowKillSwitchModal(true)}
            />

            {/* Platform Owner Exclusive: System Audit Log */}
            {isPlatformOwner && (
              <button
                onClick={() => navigateToScreen("system-audit-log")}
                className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 text-xs font-medium shrink-0 ${
                  activeScreen === "system-audit-log"
                    ? "bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm"
                    : "text-[#7C8AA8] hover:text-amber-300 hover:bg-white/5 border-white/10"
                }`}
                title="Platform Owner: System Audit Log (Firestore Telemetry)"
              >
                <Database className="w-4 h-4 text-amber-400" />
                <span className="hidden xl:inline text-[11px]">Audit Log</span>
              </button>
            )}

            {/* Notifications Chime Icon */}
            <button
              onClick={() => navigateToScreen("notifications")}
              className="relative p-2 rounded-xl text-[#7C8AA8] hover:text-white hover:bg-white/5 transition-all shrink-0"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {notifications.some((n) => !n.read) && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#C9A46A] ring-2 ring-[#0D1830]" />
              )}
            </button>

            {/* Quick Public Showcase Access Pill (Touch-friendly for iPad & Desktop) */}
            <button
              onClick={() => navigateToScreen("talent-showcase")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                activeScreen === "talent-showcase" || activeScreen === "public-portfolio"
                  ? "bg-[#C9A46A]/20 text-[#C9A46A] border-[#C9A46A]/50 shadow-sm"
                  : "bg-[#111E33] text-[#C9A46A] hover:bg-[#C9A46A]/10 border-[#C9A46A]/30"
              }`}
              title="Open Public Creator Showcase Page"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#C9A46A]" />
              <span className="font-sans font-medium">🌐 Public Showcase</span>
            </button>

            {/* Universal Global Search Bar */}
            <button
              onClick={() => setGlobalSearchOpen(true)}
              className="flex items-center gap-2.5 bg-[#111E33] border border-white/10 hover:border-[#C9A46A]/50 text-slate-300 hover:text-white px-3.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-inner text-xs group shrink-0"
              title="Global Platform Search & Navigation (Cmd+K)"
            >
              <Search className="w-4 h-4 text-[#C9A46A] group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline font-sans text-slate-400 group-hover:text-slate-200">
                Search creators, deals, pages...
              </span>
              <kbd className="hidden md:inline-flex items-center gap-0.5 bg-[#0D1830] border border-white/10 text-[10px] text-slate-400 px-1.5 py-0.5 rounded font-mono">
                ⌘K
              </kbd>
            </button>

            {/* Terms of Service Button */}
            <button
              onClick={() => {
                setIsMandatoryTosGate(false);
                setShowTermsModal(true);
              }}
              className="p-2 rounded-xl text-[#7C8AA8] hover:text-indigo-300 hover:bg-white/5 transition-all cursor-pointer shrink-0"
              title="Agency Terms of Service & E-Sign"
              aria-label="Agency Terms of Service & E-Sign"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>

            {/* Master Privacy Policy Button */}
            <button
              onClick={() => setShowPrivacyPolicyModal(true)}
              className="p-2 rounded-xl text-[#7C8AA8] hover:text-[#D4AF37] hover:bg-white/5 transition-all cursor-pointer shrink-0"
              title="Master Privacy Policy & Data Architecture"
              aria-label="Master Privacy Policy & Data Architecture"
            >
              <Lock className="w-4 h-4" />
            </button>

            {/* Accessibility Statement Button */}
            <button
              onClick={() => setShowAccessibilityModal(true)}
              className="p-2 rounded-xl text-[#7C8AA8] hover:text-blue-400 hover:bg-white/5 transition-all cursor-pointer shrink-0"
              title="Accessibility Statement (WCAG 2.1 AA)"
              aria-label="Accessibility Statement (WCAG 2.1 AA)"
            >
              <Eye className="w-4 h-4" />
            </button>

            {/* Log Out Button */}
            <button
              onClick={handleLogout}
              className="p-2 rounded-xl text-rose-400 hover:text-white hover:bg-rose-950/40 border border-rose-500/30 transition-all flex items-center gap-1.5 text-xs font-semibold cursor-pointer shrink-0"
              title="Log Out"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden xl:inline">Log Out</span>
            </button>

            {/* User Profile Info */}
            <div className="flex items-center gap-2 pl-2 border-l border-white/10 shrink-0">
              <img
                src={currentUser?.avatarUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80"}
                alt={currentUser?.name || "User"}
                className="w-8 h-8 rounded-full object-cover border border-white/10 shrink-0"
              />
              <div className="hidden lg:block text-left min-w-0 max-w-[120px]">
                <div className="text-xs font-semibold text-white truncate leading-tight">
                  {currentUser?.name || "User"}
                </div>
                <div className="text-[10px] text-[#7C8AA8] truncate leading-tight">
                  {currentUser?.handle || currentUser?.email}
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic Screen View Content */}
        {(() => {
          const isStaffUser = ['director', 'agentmgr', 'agent', 'coordinator', 'subagency', 'owner', 'admin', 'agency'].includes((currentRole || '').toLowerCase()) || currentUser?.isPlatformOwner === true;
          return (
            <main className="flex-1 overflow-y-auto overflow-x-hidden p-3 sm:p-5 lg:p-7 space-y-6 bg-[#0A1220] min-w-0 w-full max-w-full pb-32">
                {/* Quick Actions Ribbon */}
                <QuickActionsBar
                  currentRole={currentRole}
                  primaryBrandColor={primaryBrandColor}
                  canLogCampaigns={true}
                  canCreateMissions={true}
                  agentMgrCanAnnounce={agentMgrCanAnnounce}
                  onOpenAddCreator={() => isStaffUser && setShowQuickAddCreatorModal(true)}
                  onOpenLogDeal={() => isStaffUser && setShowQuickLogDealModal(true)}
                  onOpenBroadcast={() => isStaffUser && setShowBroadcastModal(true)}
                  onOpenAssignAgent={() => isStaffUser && setShowQuickAssignAgentModal(true)}
                  onOpenWaitlist={() => isStaffUser && setShowQuickWaitlistModal(true)}
                  onNavigate={(screen) => navigateToScreen(screen)}
                />

                {renderScreenContent()}
            </main>
          );
        })()}

        {/* Active Modals & Dialogs Layer */}
        {(() => {
          const isStaffUser = ['director', 'agentmgr', 'agent', 'coordinator', 'subagency', 'owner', 'admin', 'agency'].includes((currentRole || '').toLowerCase()) || currentUser?.isPlatformOwner === true;
          return (
            <>
              {isStaffUser && showQuickAddCreatorModal && (
                <QuickAddCreatorModal
                  isOpen={showQuickAddCreatorModal}
                  onClose={() => setShowQuickAddCreatorModal(false)}
                  onAddCreator={(newCreator) => {
                    setCreators((prev) => [newCreator, ...prev]);
                    triggerSimulatedNotification(
                      "Creator Registered",
                      `${newCreator.name} (${newCreator.handle}) added to agency roster.`,
                      "success"
                    );
                    setShowQuickAddCreatorModal(false);
                  }}
                />
              )}

        {/* Universal Global Search & Navigation Command Palette */}
        <CommandPalette
          isOpen={globalSearchOpen}
          onClose={() => setGlobalSearchOpen(false)}
          onNavigate={(screenId) => {
            navigateToScreen(screenId);
            setGlobalSearchOpen(false);
          }}
          creators={visibleCreators}
          deals={visibleDeals}
          campaigns={missions}
          invoices={[]}
          currentRole={currentRole}
          primaryBrandColor={primaryBrandColor}
        />

        {isDealSearchModalOpen && (
          <DealSearchModal
            isOpen={isDealSearchModalOpen}
            onClose={() => setIsDealSearchModalOpen(false)}
            deals={visibleDeals}
            creators={visibleCreators}
            onSelectDeal={(deal) => {
              navigateToScreen("deal-pipeline");
              setIsDealSearchModalOpen(false);
              triggerSimulatedNotification("Deal Selected", `Navigating to ${deal.brand} deal details`, "info");
            }}
            currentRole={currentRole}
            currentUser={currentUser}
          />
        )}

        {showDirectMessageLookupModal && (
          <DirectMessageLookupModal
            isOpen={showDirectMessageLookupModal}
            onClose={() => setShowDirectMessageLookupModal(false)}
            currentRole={currentRole}
            currentUser={currentUser}
            creators={visibleCreators}
            deals={visibleDeals}
            onSendDirectMessage={async (recipientName, recipientRole, messageText, recipientHandle) => {
              let existingThread = threads.find(t => 
                t.name === recipientName || (recipientHandle && t.handle === recipientHandle)
              );

              let tId = existingThread?.id;
              if (!tId) {
                tId = await handleAddThread(recipientName, recipientRole, recipientHandle);
              }
              
              if (tId) {
                await handleSendMessage(tId, messageText);
              }

              triggerSimulatedNotification("Direct Message Dispatched", `Securely sent to ${recipientName} and saved to agency database.`, "success");
              handleAddActivityLog(currentUser?.name || "User", currentRole, `Sent direct message to ${recipientName}`);
              setShowDirectMessageLookupModal(false);
            }}
          />
        )}

        {isStaffUser && showBroadcastModal && (
          <MassBroadcastModal
            isOpen={showBroadcastModal}
            onClose={() => setShowBroadcastModal(false)}
            creators={visibleCreators}
            currentRole={currentRole}
            currentUser={currentUser}
            onSendBroadcast={handleSendMassBroadcast}
          />
        )}

        {showAnnouncementsModal && (
          <AnnouncementsModal
            isOpen={showAnnouncementsModal}
            onClose={() => setShowAnnouncementsModal(false)}
            announcements={announcements}
            setAnnouncements={setAnnouncements}
            currentRole={currentRole}
            currentUser={currentUser}
            creators={visibleCreators}
            onOpenMassBroadcast={() => {
              setShowAnnouncementsModal(false);
              setShowBroadcastModal(true);
            }}
            onOpenDirectMessageLookup={() => {
              setShowAnnouncementsModal(false);
              setShowDirectMessageLookupModal(true);
            }}
            onOpenPhoneSimulator={() => {
              setShowAnnouncementsModal(false);
              navigateToScreen("notifications");
            }}
            triggerNotification={triggerSimulatedNotification}
            onAddActivityLog={handleAddActivityLog}
          />
        )}

        {showTermsModal && (
          <TermsOfServiceModal
            isOpen={showTermsModal}
            onClose={() => {
              if (!isMandatoryTosGate) {
                setShowTermsModal(false);
              }
            }}
            isMandatoryGate={isMandatoryTosGate}
            onSignTerms={(finalName, dateIso) => {
              const userKey = currentUser?.id || currentUser?.uid || currentUser?.email || "guest";
              const roleKey = `user_${currentRole}`;
              const nowIso = dateIso || new Date().toISOString();
              safeStorage.setItem("bloom_agency_tos_v2026_signed", "true");
              safeStorage.setItem(`bloom_agency_tos_v2026_signed_${userKey}`, "true");
              safeStorage.setItem(`bloom_agency_tos_v2026_signed_${roleKey}`, "true");
              if (currentUser?.email) {
                safeStorage.setItem(`bloom_tos_signed_${currentUser.email}`, "true");
              }

              // Persist to Firestore studio-users record if valid UID
              if (currentUser?.id && !currentUser.id.startsWith("guest_")) {
                try {
                  const userRef = doc(db, 'studio-users', currentUser.id);
                  setDoc(userRef, {
                    hasSignedToS: true,
                    tosSignedAt: nowIso,
                    tosSignerName: finalName || currentUser.name || "Authorized Partner",
                    tosVersion: "v2026.1",
                    updatedAt: nowIso
                  }, { merge: true }).catch(err => console.warn("Firestore ToS sync warn:", err));
                } catch (e) {}
              }

              setCurrentUser((prev: any) => {
                if (!prev) return prev;
                const updated = {
                  ...prev,
                  hasSignedToS: true,
                  tosSignedAt: nowIso,
                  tosSignerName: finalName || prev.name,
                  tosVersion: "v2026.1"
                };
                safeStorage.setItem("wl_currentUser", JSON.stringify(updated));
                return updated;
              });
              setIsMandatoryTosGate(false);
              setShowTermsModal(false);
              triggerSimulatedNotification(
                "Agency Terms Executed",
                `Signed agreement on file for ${finalName || currentUser?.name || "User"}.`,
                "success"
              );
            }}
            onDecline={() => {
              handleLogout();
            }}
            currentUser={currentUser}
            currentRole={currentRole}
            triggerNotification={triggerSimulatedNotification}
          />
        )}

        {/* Global Privacy Policy Modal */}
        <PrivacyPolicyModal
          isOpen={showPrivacyPolicyModal}
          onClose={() => setShowPrivacyPolicyModal(false)}
          onAcknowledge={() => {
            handleAddActivityLog(
              currentUser?.name || currentRole.toUpperCase(),
              currentRole,
              'Reviewed and acknowledged Master Privacy Policy & Data Architecture'
            );
          }}
          triggerNotification={triggerSimulatedNotification}
        />

        {/* Global Accessibility Statement Modal (WCAG 2.1 AA) */}
        <AccessibilityStatementModal
          isOpen={showAccessibilityModal}
          onClose={() => setShowAccessibilityModal(false)}
          triggerNotification={triggerSimulatedNotification}
        />

        {isStaffUser && showQuickLogDealModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#0D1830] border border-[#C9A46A]/40 rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-[#C9A46A]" />
                  <h3 className="text-base font-serif font-bold text-white">Log New Deal &amp; Revenue</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowQuickLogDealModal(false)}
                  className="text-slate-400 hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const targetBrand = (quickDealBrand || "Brand Partner").trim();

                  // Query Global Blacklist before allowing deal creation
                  const blCheck = await checkBrandBlacklist(targetBrand, currentUser?.tenantId);
                  if (blCheck.isBlacklisted) {
                    triggerSimulatedNotification(
                      "Deal Initiation Blocked",
                      `Brand '${blCheck.matchedBrand || targetBrand}' is on the Global Blacklist (${blCheck.reason}). Deal and contract initiation is prohibited.`,
                      "danger"
                    );
                    return;
                  }

                  const newDeal: any = {
                    id: "deal_" + Date.now(),
                    title: quickDealTitle || "Sponsored Partnership Campaign",
                    brand: targetBrand,
                    creator: quickDealCreator || visibleCreators[0]?.name || "Creator",
                    creatorHandle: visibleCreators.find(c => c.name === quickDealCreator)?.handle || "@creator",
                    budget: parseFloat(quickDealAmount) || 10000,
                    stage: quickDealStage || "Inquiry",
                    status: "Active",
                    date: new Date().toISOString().split('T')[0],
                    subagency: currentUser?.subagency || "pod_main",
                    tenantId: currentUser?.tenantId || "bloom_studio_default",
                    createdAt: new Date().toISOString()
                  };
                  setDeals(prev => {
                    const updated = [newDeal, ...prev];
                    safeStorage.setItem("wl_deals", JSON.stringify(updated));
                    return updated;
                  });

                  try {
                    await setDoc(doc(db, "studio-deals", newDeal.id), cleanUndefinedForFirestore(newDeal));
                  } catch (err) {
                    console.warn("[QuickLogDeal] Firestore save error:", err);
                  }

                  triggerSimulatedNotification("Deal Logged", `Successfully logged deal "${quickDealTitle || 'Sponsored Campaign'}" for ${quickDealBrand || 'Brand Partner'}.`, "success");
                  handleAddActivityLog(currentUser?.name || "User", currentRole, `Logged new deal: ${quickDealTitle || 'Sponsored Campaign'} (${quickDealBrand || 'Brand Partner'})`);
                  setQuickDealTitle("");
                  setQuickDealBrand("");
                  setShowQuickLogDealModal(false);
                }}
                className="space-y-4 text-xs font-mono"
              >
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Campaign Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Summer Skincare UGC Series"
                    value={quickDealTitle}
                    onChange={e => setQuickDealTitle(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Brand Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. GlowLab / Nike"
                    value={quickDealBrand}
                    onChange={e => setQuickDealBrand(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Creator</label>
                  <select
                    value={quickDealCreator}
                    onChange={e => setQuickDealCreator(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                  >
                    <option value="">Select Creator...</option>
                    {visibleCreators.map(c => (
                      <option key={c.id} value={c.name}>{c.name} ({c.handle})</option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Budget ($)</label>
                    <input
                      type="number"
                      value={quickDealAmount}
                      onChange={e => setQuickDealAmount(e.target.value)}
                      className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Pipeline Stage</label>
                    <select
                      value={quickDealStage}
                      onChange={e => setQuickDealStage(e.target.value)}
                      className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-[#C9A46A]"
                    >
                      <option value="Inquiry">Inquiry</option>
                      <option value="Negotiation">Negotiation</option>
                      <option value="Contract Signed">Contract Signed</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>
                </div>
                <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setShowQuickLogDealModal(false)}
                    className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#C9A46A] hover:bg-[#E3C48F] text-[#0A1220] font-bold rounded-xl cursor-pointer shadow-lg"
                  >
                    Save &amp; Log Deal
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {isStaffUser && showQuickAssignAgentModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#0D1830] border border-purple-500/40 rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl relative">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-purple-400" />
                  <h3 className="text-base font-serif font-bold text-white">Assign Agent to Creator</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowQuickAssignAgentModal(false)}
                  className="text-slate-400 hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!quickAssignCreatorId) {
                    triggerSimulatedNotification("Selection Required", "Please select a creator to assign an agent.", "danger");
                    return;
                  }
                  const agentName = quickAssignAgentName || "Alex Vance (Lead Agent)";
                  setCreators(prev => {
                    const updated = prev.map(c => c.id === quickAssignCreatorId ? { ...c, assignedAgent: agentName } : c);
                    safeStorage.setItem("wl_creators", JSON.stringify(updated));
                    return updated;
                  });

                  try {
                    await setDoc(doc(db, "studio-creators", quickAssignCreatorId), {
                      assignedAgent: agentName,
                      agentAssignedAt: new Date().toISOString()
                    }, { merge: true });
                  } catch (err) {
                    console.warn("[QuickAssignAgent] Firestore sync error:", err);
                  }

                  const creatorObj = visibleCreators.find(c => c.id === quickAssignCreatorId);
                  triggerSimulatedNotification("Agent Assigned", `Successfully assigned ${agentName} to ${creatorObj?.name || 'Creator'}.`, "success");
                  handleAddActivityLog(currentUser?.name || "User", currentRole, `Assigned agent ${agentName} to ${creatorObj?.name || 'Creator'}`);
                  setShowQuickAssignAgentModal(false);
                }}
                className="space-y-4 text-xs font-mono"
              >
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Select Creator *</label>
                  <select
                    value={quickAssignCreatorId}
                    onChange={e => setQuickAssignCreatorId(e.target.value)}
                    required
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-purple-400"
                  >
                    <option value="">Select creator roster member...</option>
                    {visibleCreators.map(c => (
                      <option key={c.id} value={c.id}>{c.name} ({c.handle}) - Current Agent: {c.assignedAgent || 'Unassigned'}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Assign Agent / Manager Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex Vance, Marcus Brody, Sarah Chen"
                    value={quickAssignAgentName}
                    onChange={e => setQuickAssignAgentName(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-purple-400"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setShowQuickAssignAgentModal(false)}
                    className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl cursor-pointer shadow-lg"
                  >
                    Confirm Assignment
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {isStaffUser && showQuickWaitlistModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#0D1830] border border-indigo-500/40 rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl relative">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-400" />
                  <h3 className="text-base font-serif font-bold text-white">Add Candidate to Vetting Waitlist</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowQuickWaitlistModal(false)}
                  className="text-slate-400 hover:text-white p-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const name = quickWaitlistName || "New Creator Candidate";
                  const handle = quickWaitlistHandle || "@newcreator";
                  const newEntryId = "wl_" + Date.now();
                  const newEntry = {
                    id: newEntryId,
                    name,
                    handle,
                    platform: quickWaitlistPlatform || "TikTok",
                    type: "Creator",
                    niche: "Lifestyle",
                    priority: "Standard",
                    status: "Pending",
                    appliedDate: new Date().toISOString().split("T")[0],
                    createdAt: new Date().toISOString(),
                    subagency: currentUser?.subagency || "pod_main",
                    tenantId: currentUser?.tenantId || "bloom_studio_default"
                  };

                  try {
                    await setDoc(doc(db, "studio_waitlist", newEntryId), newEntry);
                  } catch (err) {
                    console.warn("[QuickWaitlist] Firestore sync error:", err);
                  }

                  try {
                    const existing = safeStorage.getItem('wl_waitlist_entries');
                    const list = existing ? JSON.parse(existing) : [];
                    safeStorage.setItem('wl_waitlist_entries', JSON.stringify([newEntry, ...list]));
                  } catch (e) {}

                  navigateToScreen("waitlist");
                  triggerSimulatedNotification("Added to Waitlist", `${name} (${handle}) successfully added to agency vetting waitlist.`, "success");
                  handleAddActivityLog(currentUser?.name || "User", currentRole, `Added candidate ${name} (${handle}) to waitlist`);
                  setQuickWaitlistName("");
                  setQuickWaitlistHandle("");
                  setShowQuickWaitlistModal(false);
                }}
                className="space-y-4 text-xs font-mono"
              >
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Candidate Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Jordan Taylor"
                    value={quickWaitlistName}
                    onChange={e => setQuickWaitlistName(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-400"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Handle / Social Link *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. @jordantaylor"
                    value={quickWaitlistHandle}
                    onChange={e => setQuickWaitlistHandle(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-400"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-[#7C8AA8] uppercase block mb-1">Primary Platform</label>
                  <select
                    value={quickWaitlistPlatform}
                    onChange={e => setQuickWaitlistPlatform(e.target.value)}
                    className="w-full bg-[#091122] border border-white/10 rounded-xl p-2.5 text-white focus:outline-none focus:border-indigo-400"
                  >
                    <option value="TikTok">TikTok</option>
                    <option value="Instagram">Instagram</option>
                    <option value="YouTube">YouTube</option>
                    <option value="Twitch">Twitch</option>
                  </select>
                </div>
                <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
                  <button
                    type="button"
                    onClick={() => setShowQuickWaitlistModal(false)}
                    className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl cursor-pointer shadow-lg"
                  >
                    Add to Waitlist
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
            </>
          );
        })()}

        {deleteConfirmModalConfig && (
          <DeleteConfirmationModal
            config={deleteConfirmModalConfig}
            onClose={() => setDeleteConfirmModalConfig(null)}
            primaryBrandColor={primaryBrandColor}
          />
        )}

        {(() => {
          const contractToken = new URLSearchParams(window.location.search).get("contract_token");
          if (!contractToken) return null;
          return (
            <PublicContractSigningModal
              contractToken={contractToken}
              onSignContract={(contractId, dispatchId, signerName) => {
                const targetContract = contracts.find(c => c.id === contractId);
                if (targetContract) {
                  const updatedDispatches = (targetContract.dispatchedEmails || []).map((d: any) => {
                    if (d.id === dispatchId) {
                      return {
                        ...d,
                        status: 'Executed',
                        signedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
                        signerName
                      };
                    }
                    return d;
                  });
                  const updatedContract: Contract = {
                    ...targetContract,
                    status: 'Active',
                    dispatchedEmails: updatedDispatches
                  };
                  handleSaveContract(updatedContract);
                }
                triggerSimulatedNotification(
                  'Contract Executed & Sealed',
                  `Legal agreement signed by ${signerName}. Status updated to Active.`,
                  'success'
                );
                handleAddActivityLog(
                  signerName,
                  'External Counterparty',
                  `Executed and digitally signed contract [${contractId}] via secure dispatch token.`
                );
              }}
              onClose={() => {
                try {
                  const url = new URL(window.location.href);
                  url.searchParams.delete('contract_token');
                  window.history.replaceState({}, '', url.toString());
                } catch (e) {}
                window.location.reload();
              }}
              triggerNotification={(title, message, type) => triggerSimulatedNotification(title, message, type === 'error' ? 'danger' : (type as any))}
            />
          );
        })()}
        {/* Platform Owner Emergency Kill Switch Modal Dialog */}
        {showKillSwitchModal && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="relative max-w-3xl w-full">
              <button
                onClick={() => setShowKillSwitchModal(false)}
                className="absolute -top-10 right-0 text-slate-300 hover:text-white text-xs font-semibold px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg cursor-pointer transition-all border border-white/10"
              >
                Close ✕
              </button>
              <EmergencyKillSwitchPanel
                config={maintenanceConfig}
                currentUser={currentUser}
                onUpdateConfig={(cfg) => setMaintenanceConfig(cfg)}
                triggerNotification={triggerSimulatedNotification}
              />
            </div>
          </div>
        )}

        {idleWarningOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm animate-fade-in p-4">
            <div className="w-full max-w-md bg-[#0D1830] border border-amber-500/30 p-6 rounded-2xl shadow-2xl text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="text-base font-bold text-white">Inactivity Timeout Warning</h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                For security compliance, your session will automatically sign out due to inactivity in <strong className="text-amber-400 font-mono text-sm">{idleSecondsRemaining}s</strong>.
              </p>
              <div className="flex gap-3 justify-center pt-2">
                <button
                  onClick={() => setIdleWarningOpen(false)}
                  className="px-4 py-2 bg-[#C9A46A] hover:bg-[#B89359] text-[#111E33] font-semibold text-xs rounded-xl transition-colors"
                >
                  Continue Session
                </button>
                <button
                  onClick={() => {
                    setIdleWarningOpen(false);
                    handleLogout();
                  }}
                  className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold text-xs rounded-xl transition-colors"
                >
                  Sign Out Now
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
    )}
      {showBrandPartnerModal && (
        <BrandPartnerJoinModal
          isOpen={showBrandPartnerModal}
          onClose={() => {
            setShowBrandPartnerModal(false);
            setPendingBrandAccess(null);
          }}
          agencyName={activeTenantConfig?.agencyName || "Bloom Studio"}
          reviewsList={contentReviewsList}
          initialToken={pendingBrandAccess?.token || ""}
          initialLink={pendingBrandAccess?.url || ""}
          initialBrandName={pendingBrandAccess?.brandName || ""}
          onBrandPartnerLogin={(email, brandName, token, activeDeliverableId) => {
            // Find the verified review matching this deliverable/token
            const matchingReview = contentReviewsList.find(r => {
              if (activeDeliverableId && r.id === activeDeliverableId) return true;
              if (token) {
                const generatedToken = `ROOM-${r.id.substring(0, 8).toUpperCase()}`;
                if (generatedToken === token.toUpperCase() || r.id === token) return true;
              }
              return false;
            });

            if (matchingReview) {
              const actualBrand = matchingReview.brand || brandName;
              
              setCurrentUser({
                id: `brand_token_${Date.now()}`,
                name: actualBrand,
                email: email,
                role: 'brand',
                company: actualBrand,
                isBrand: true,
                tokenAccess: true,
                activeDeliverableId: matchingReview.id,
                subagency: matchingReview.subagency || pendingBrandAccess?.subagency || 'pod_main'
              });
              setIsAuthenticated(true);
              setCurrentRole('brand');
              setActiveScreen("brand-review-portal");
              setShowBrandPartnerModal(false);
              setPendingBrandAccess(null);
              
              triggerSimulatedNotification(
                "Access Link Verified",
                `Verified authorized access for ${actualBrand}. Pulling up deliverable queue.`,
                "success"
              );
            } else if (brandName && email) {
              // Direct Account Sign-In (Account Tab)
              setCurrentUser({
                id: `brand_account_${Date.now()}`,
                name: brandName,
                email: email,
                role: 'brand',
                company: brandName,
                isBrand: true
              });
              setIsAuthenticated(true);
              setCurrentRole('brand');
              setActiveScreen("brand-dash");
              setShowBrandPartnerModal(false);
              setPendingBrandAccess(null);
              triggerSimulatedNotification(
                "Brand Portal Accessed",
                `Welcome back, ${brandName}. Accessing your partner dashboard.`,
                "success"
              );
            }
          }}
        />
      )}
    </>
  );
}
