import { initializeSafeStoragePolyfill } from './utils/safeStorage.ts';

// Initialize storage polyfill before any component or Firebase initializes
initializeSafeStoragePolyfill();

// Safeguard against benign browser security errors (e.g. sandboxed iframe websocket / storage restrictions)
if (typeof window !== 'undefined') {
  const isSecurityError = (err: any) => {
    if (!err) return false;
    const str = String(err.message || err.reason?.message || err.reason || err || '').toLowerCase();
    const name = String(err.name || err.reason?.name || '').toLowerCase();
    return (
      str.includes('insecure') ||
      str.includes('securityerror') ||
      str.includes('access is denied') ||
      str.includes('storage') ||
      str.includes('indexeddb') ||
      str.includes('websocket') ||
      name.includes('securityerror')
    );
  };

  window.addEventListener('error', (event) => {
    if (isSecurityError(event) || isSecurityError(event.error)) {
      event.preventDefault();
      event.stopImmediatePropagation();
      console.warn('[Handled Browser Security Warning]:', event.error || event.message);
    }
  }, true);

  window.addEventListener('unhandledrejection', (event) => {
    if (isSecurityError(event.reason)) {
      event.preventDefault();
      event.stopImmediatePropagation();
      console.warn('[Handled Browser Security Rejection]:', event.reason);
    }
  }, true);
}

import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import ErrorBoundary from './components/ErrorBoundary.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
