/**
 * @file shippingTrackingSync.ts
 * @description Creator delivery self-attestation status synchronizer for Bloom Studio & Bloom & Co.
 * 
 * OPERATIONAL LOGIC:
 * 1. Attestation trigger for creator delivery confirmation ("Sample Received").
 * 2. On confirmed delivery state: Automatically mutates targeted creator's deliverable field
 *    ('deliverables.contentStatus' / 'contentStatus') from "Pending Sample" to "Sample Received" in Firestore.
 * 3. System Synchronization: Instantly emits real-time event updates to both Manager Fulfillment Hub
 *    and Creator Active Mission Hub without requiring page refresh.
 * 4. Critical Safety: Zero modifications to financial totals or payouts.
 */

import { db } from '../lib/firebase';
import { doc, updateDoc, collection, getDocs, query, where } from 'firebase/firestore';
import { safeStorage } from './safeStorage';

export interface ShippingCarrierUpdate {
  trackingNumber: string;
  carrier: 'UPS' | 'USPS' | 'FedEx' | 'DHL';
  status: 'In Transit' | 'Out for Delivery' | 'Delivered' | 'Exception';
  campaignId: string;
  creatorHandle: string;
  deliveryTimestamp?: string;
  location?: string;
}

export interface DeliverySyncResult {
  success: boolean;
  trackingNumber: string;
  campaignId: string;
  creatorHandle: string;
  previousStatus: string;
  updatedStatus: string;
  timestamp: string;
}

// Custom event identifier for instant, zero-reload cross-component UI updates
export const SHIPPING_DELIVERY_SYNC_EVENT = 'bloom:shipping-delivery-synced';

/**
 * Automated listener function that evaluates external shipping status and syncs delivery nodes.
 */
export async function syncShippingDeliveryNodes(
  update: ShippingCarrierUpdate
): Promise<DeliverySyncResult> {
  const previousStatus = "Pending Sample";
  const updatedStatus = "Sample Received";
  const now = new Date().toISOString();

  console.log(`[ShippingSync] Processing delivery node for tracking #${update.trackingNumber} (${update.carrier})`);

  // If state is Delivered, execute state transition
  if (update.status === 'Delivered') {
    try {
      if (db) {
        // 1. Update studio-campaigns (and fallback campaigns collection)
        const campaignUpdate = {
          'deliverables.contentStatus': updatedStatus,
          'deliverables.sampleReceivedAt': now,
          'shipping.status': 'Delivered',
          'shipping.deliveredAt': now,
          'shipping.lastSyncTimestamp': now
        };
        await updateDoc(doc(db, 'studio-campaigns', update.campaignId), campaignUpdate).catch(() => {});
        await updateDoc(doc(db, 'campaigns', update.campaignId), campaignUpdate).catch(() => {});

        // 2. Also sync studio-missions and missions collections
        const missionUpdate = {
          contentStatus: updatedStatus,
          sampleReceivedDate: now,
          trackingStatus: 'Delivered'
        };

        const checkAndUpdateMissions = async (colName: string) => {
          try {
            const mRef = collection(db, colName);
            const q = query(
              mRef,
              where('campaignId', '==', update.campaignId),
              where('creatorHandle', '==', update.creatorHandle)
            );
            const snap = await getDocs(q).catch(() => null);
            if (snap && !snap.empty) {
              for (const mDoc of snap.docs) {
                await updateDoc(doc(db, colName, mDoc.id), missionUpdate).catch(() => {});
              }
            }
          } catch (_) {}
        };

        await Promise.allSettled([
          checkAndUpdateMissions('studio-missions'),
          checkAndUpdateMissions('missions')
        ]);
      }
    } catch (error) {
      console.warn('[ShippingSync] Firebase sync fallback to local memory event:', error);
    }

    // 3. Dispatch global browser event for zero-refresh reactive UI updates
    const syncDetail: DeliverySyncResult = {
      success: true,
      trackingNumber: update.trackingNumber,
      campaignId: update.campaignId,
      creatorHandle: update.creatorHandle,
      previousStatus,
      updatedStatus,
      timestamp: now
    };

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent(SHIPPING_DELIVERY_SYNC_EVENT, { detail: syncDetail }));
      
      // Store local sync registry for offline or local preview consistency
      try {
        const existingSyncs = JSON.parse(safeStorage.getItem('bloom_shipping_sync_log') || '[]');
        existingSyncs.unshift(syncDetail);
        safeStorage.setItem('bloom_shipping_sync_log', JSON.stringify(existingSyncs.slice(0, 50)));
      } catch (e) {
        // ignore storage quota errors
      }
    }

    return syncDetail;
  }

  return {
    success: false,
    trackingNumber: update.trackingNumber,
    campaignId: update.campaignId,
    creatorHandle: update.creatorHandle,
    previousStatus: update.status,
    updatedStatus: update.status,
    timestamp: now
  };
}

/**
 * Helper listener hook for React components to subscribe to automated shipping updates.
 */
export function subscribeToShippingDeliverySync(
  callback: (result: DeliverySyncResult) => void
): () => void {
  if (typeof window === 'undefined') return () => {};

  const handler = (e: Event) => {
    const customEvent = e as CustomEvent<DeliverySyncResult>;
    if (customEvent.detail) {
      callback(customEvent.detail);
    }
  };

  window.addEventListener(SHIPPING_DELIVERY_SYNC_EVENT, handler);
  return () => {
    window.removeEventListener(SHIPPING_DELIVERY_SYNC_EVENT, handler);
  };
}
