export function generateSecureToken(prefix: string = 'sgn_'): string {
  if (typeof globalThis !== 'undefined' && globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') {
    return `${prefix}${globalThis.crypto.randomUUID().replace(/-/g, '')}`;
  }
  const array = new Uint8Array(24);
  if (typeof globalThis !== 'undefined' && globalThis.crypto && typeof globalThis.crypto.getRandomValues === 'function') {
    globalThis.crypto.getRandomValues(array);
  }
  const hex = Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
  return `${prefix}${hex}`;
}

export function generateSecureInviteCode(prefix: string = 'BLOOM_'): string {
  const array = new Uint8Array(6);
  if (typeof globalThis !== 'undefined' && globalThis.crypto && typeof globalThis.crypto.getRandomValues === 'function') {
    globalThis.crypto.getRandomValues(array);
  }
  const hex = Array.from(array, b => b.toString(16).padStart(2, '0')).join('').toUpperCase().substring(0, 8);
  return `${prefix}${hex}`;
}

export function generateSecurePinCode(): string {
  if (typeof globalThis !== 'undefined' && globalThis.crypto && typeof globalThis.crypto.getRandomValues === 'function') {
    const arr = new Uint32Array(1);
    globalThis.crypto.getRandomValues(arr);
    const pin = 1000 + (arr[0] % 9000);
    return pin.toString();
  }
  return Math.floor(1000 + Math.random() * 9000).toString();
}

