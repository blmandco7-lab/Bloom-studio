import { PDFDocument, rgb, StandardFonts, PDFFont, PDFPage, RGB } from 'pdf-lib';

/**
 * Standardize RGB color creation from hex or 0-255 values
 */
export const hexToRgb = (hex: string): RGB => {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  return rgb(r, g, b);
};

export const nRgb = (r: number, g: number, b: number): RGB => rgb(r / 255, g / 255, b / 255);

/**
 * Sanitizes input strings to ensure full compatibility with PDF standard fonts (WinAnsi / Windows-1252).
 * Replaces or removes unsupported Unicode characters, emojis, checkmarks, bullets, and arrows.
 */
export function sanitizeWinAnsi(text: string | number | undefined | null): string {
  if (text === undefined || text === null) return '';
  let str = String(text);

  str = str
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{1F000}-\u{1F2FF}]/gu, '')
    .replace(/[⚡🔥✨🚀🔒💎🛡️👑🎬📈💬🚨⚠️💡🌟🎉🤖⚙️📦🏷️💼🔍📝📄💸💵]/gu, '')
    .replace(/[▶►→➜]/g, '>')
    .replace(/[◀◄←]/g, '<')
    .replace(/[▲]/g, '^')
    .replace(/[▼]/g, 'v')
    .replace(/[✓✔☑]/g, '[OK]')
    .replace(/[✕✖✗]/g, '[X]')
    .replace(/[•·]/g, '-')
    .replace(/[–—]/g, '-')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[…]/g, '...')
    .replace(/[™®©]/g, '');

  return str.replace(/[^\x20-\x7E\xA0-\xFF\n\r\t]/g, '');
}

export class PdfLibWriter {
  doc: PDFDocument;
  page: PDFPage;
  fonts: Record<string, PDFFont> = {};
  width: number;
  height: number;
  margin: number = 40;

  private constructor(doc: PDFDocument, page: PDFPage) {
    this.doc = doc;
    this.page = page;
    const { width, height } = page.getSize();
    this.width = width;
    this.height = height;
  }

  static async create() {
    const doc = await PDFDocument.create();
    const page = doc.addPage([612, 792]); // Standard US Letter (8.5 x 11 in)
    const writer = new PdfLibWriter(doc, page);
    
    // Embed standard fonts
    writer.fonts.helvetica = await doc.embedFont(StandardFonts.Helvetica);
    writer.fonts.helveticaBold = await doc.embedFont(StandardFonts.HelveticaBold);
    writer.fonts.helveticaOblique = await doc.embedFont(StandardFonts.HelveticaOblique);
    writer.fonts.times = await doc.embedFont(StandardFonts.TimesRoman);
    writer.fonts.timesBold = await doc.embedFont(StandardFonts.TimesRomanBold);
    writer.fonts.timesItalic = await doc.embedFont(StandardFonts.TimesRomanItalic);
    
    return writer;
  }

  /**
   * Translates top-down coordinates (0 = top) to PDF bottom-up coordinates.
   */
  translateY(y: number): number {
    return this.height - y;
  }

  /**
   * Draws text with alignment support.
   */
  drawText(str: string | string[], x: number, y: number, options: {
    size?: number;
    font?: 'helvetica' | 'helveticaBold' | 'helveticaOblique' | 'times' | 'timesBold' | 'timesItalic';
    color?: RGB;
    align?: 'left' | 'right' | 'center';
    maxWidth?: number;
    lineHeight?: number;
  } = {}) {
    const font = this.fonts[options.font || 'helvetica'];
    const size = options.size || 10;
    const color = options.color || rgb(0, 0, 0);
    const lineHeight = options.lineHeight || size * 1.2;

    const lines = (Array.isArray(str) ? str : [str]).map(l => sanitizeWinAnsi(l));
    
    lines.forEach((line, idx) => {
      const curY = y + (idx * lineHeight);
      let drawX = x;
      
      if (options.align === 'right') {
        const textWidth = font.widthOfTextAtSize(line, size);
        drawX = x - textWidth;
      } else if (options.align === 'center') {
        const textWidth = font.widthOfTextAtSize(line, size);
        drawX = x - textWidth / 2;
      }

      this.page.drawText(line, {
        x: drawX,
        y: this.translateY(curY + size), // Adjust for top-down baseline
        size,
        font,
        color,
        maxWidth: options.maxWidth,
        lineHeight: options.lineHeight
      });
    });
  }

  /**
   * Draws a rectangle. Radius is ignored (pdf-lib doesn't support it directly without paths).
   */
  drawRect(x: number, y: number, w: number, h: number, options: {
    fill?: boolean;
    color?: RGB;
    stroke?: boolean;
    borderColor?: RGB;
    borderWidth?: number;
  } = {}) {
    this.page.drawRectangle({
      x,
      y: this.translateY(y + h),
      width: w,
      height: h,
      color: options.fill ? options.color : undefined,
      borderColor: options.stroke ? options.borderColor : undefined,
      borderWidth: options.borderWidth || 0
    });
  }

  /**
   * Draws a line.
   */
  drawLine(x1: number, y1: number, x2: number, y2: number, options: {
    color?: RGB;
    thickness?: number;
  } = {}) {
    this.page.drawLine({
      start: { x: x1, y: this.translateY(y1) },
      end: { x: x2, y: this.translateY(y2) },
      color: options.color || rgb(0, 0, 0),
      thickness: options.thickness || 1
    });
  }

  /**
   * Manual text splitting for layout calculations.
   */
  splitText(text: string, fontKey: string, size: number, maxWidth: number): string[] {
    const safeText = sanitizeWinAnsi(text);
    const font = this.fonts[fontKey] || this.fonts.helvetica;
    const words = safeText.split(/\s+/);
    const lines: string[] = [];
    let currentLine = '';

    words.forEach(word => {
      const testLine = currentLine ? `${currentLine} ${word}` : word;
      const testWidth = font.widthOfTextAtSize(testLine, size);
      if (testWidth <= maxWidth) {
        currentLine = testLine;
      } else {
        if (currentLine) lines.push(currentLine);
        currentLine = word;
      }
    });
    if (currentLine) lines.push(currentLine);
    return lines;
  }

  /**
   * Saves the PDF and triggers a download.
   */
  async save(filename: string) {
    const pdfBytes = await this.doc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
