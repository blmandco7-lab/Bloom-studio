/**
 * Validates that a URL uses a safe protocol to prevent XSS (javascript: etc.)
 */
export function getSafeUrl(url: string | undefined | null): string {
  if (!url) return '';
  const trimmed = url.trim();
  const lower = trimmed.toLowerCase();
  
  if (lower.startsWith('http://') || lower.startsWith('https://')) {
    return trimmed;
  }
  
  // If no protocol, prefix with https:// (if it looks like a domain)
  if (!trimmed.includes('://')) {
    // Basic check to see if it might be a relative path or a domain
    if (trimmed.startsWith('/') || trimmed.startsWith('./') || trimmed.startsWith('../')) {
      return trimmed;
    }
    return `https://${trimmed}`;
  }
  
  // Block any other protocols (javascript:, data:, etc.)
  return '#';
}

/**
 * Sanitizes a single CSV cell value to prevent CSV / Formula Injection attacks (OWASP).
 * Prefixes cells starting with '=', '+', '-', '@', '\t', or '\r' with a single quote '\''.
 */
export function sanitizeCsvCell(value: any): string {
  if (value === null || value === undefined) {
    return '""';
  }
  let str = String(value);
  // Neutralize potential spreadsheet formulas (=, +, -, @, \t, \r)
  if (/^[=+\-@\t\r]/.test(str)) {
    str = "'" + str;
  }
  // Escape internal double quotes by doubling them
  const escaped = str.replace(/"/g, '""');
  return `"${escaped}"`;
}

/**
 * Converts an array of cell values into a safely sanitized CSV row string.
 */
export function formatCsvRow(row: any[]): string {
  return row.map(sanitizeCsvCell).join(',');
}

