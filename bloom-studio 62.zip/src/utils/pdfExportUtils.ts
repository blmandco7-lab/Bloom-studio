import { rgb } from 'pdf-lib';
import { UserProfile } from '../components/RoleGuardedCampaignWorkspace';
import { PdfLibWriter, hexToRgb, nRgb } from './pdfLibHelpers';

export interface ClientWrapUpData {
  brandName: string;
  campaignTitle: string;
  date: string;
  niche: 'Pets' | 'Beauty' | 'Lifestyle';
  grossBrandContractValue?: number;
  totalReach: string;
  totalViews: string;
  engagementRate: string;
  ugcAssetYield: number;
  ftcComplianceScore: string;
  copyrightStatus: string;
  creatorDeliverables: Array<{
    creatorHandle: string;
    niche: string;
    deliverableType: string;
    views: string;
    engagement: string;
    ftcTag: string;
  }>;
}

export interface DirectorLedgerData {
  campaigns: Array<{
    id: string;
    brandName: string;
    campaignType: string;
    niche: string;
    creatorHandle: string;
    grossBrandContractValue: number;
    influencerPayout: number;
    managerCompensation: number;
    agencyMargin: number;
    status: string;
  }>;
  grossRevenue: number;
  totalCreatorPayouts: number;
  totalManagerPay: number;
  netRetainedProfit: number;
  generatedDate?: string;
}

/**
 * CLIENT-FACING PDF EXPORT FUNCTION: exportClientWrapUpPDF
 */
export async function exportClientWrapUpPDF(data: ClientWrapUpData) {
  const w = await PdfLibWriter.create();
  const navy = hexToRgb('#0B1B3D');
  const gold = hexToRgb('#D4AF37');
  const gray = nRgb(120, 130, 145);
  const lightGray = nRgb(230, 233, 240);
  const bgGray = nRgb(248, 249, 252);

  const margin = 40;
  const contentWidth = w.width - margin * 2;

  // Header & Brand Accent
  w.drawRect(margin, margin, contentWidth, 3, { fill: true, color: gold });

  w.drawText('BLOOM STUDIO', margin, margin + 28, { font: 'helveticaBold', size: 20, color: navy });
  w.drawText('INFLUENCER MANAGEMENT & CAMPAIGN WRAP-UP', margin, margin + 42, { size: 10, color: gray });

  w.drawText(`DATE: ${data.date || new Date().toLocaleDateString()}`, w.width - margin, margin + 28, { align: 'right', font: 'helveticaBold', size: 10, color: navy });
  w.drawText(`CLIENT: ${data.brandName.toUpperCase()}`, w.width - margin, margin + 42, { align: 'right', size: 10, color: navy });

  w.drawLine(margin, margin + 55, w.width - margin, margin + 55, { color: lightGray });

  w.drawText(data.campaignTitle, margin, margin + 80, { font: 'helveticaBold', size: 16, color: navy });
  w.drawText(`Campaign Category: ${data.niche} Niche | Formal Executive Summary`, margin, margin + 96, { size: 11, color: nRgb(90, 100, 115) });

  // Performance Grid
  const gridY = margin + 115;
  const colWidth = (contentWidth - 20) / 3;

  const drawCard = (x: number, title: string, main: string, sub: string, mainColor = navy) => {
    w.drawRect(x, gridY, colWidth, 65, { fill: true, color: bgGray, stroke: true, borderColor: gold, borderWidth: 1 });
    w.drawText(title, x + 12, gridY + 20, { font: 'helveticaBold', size: 9, color: gray });
    w.drawText(main, x + 12, gridY + 42, { font: 'helveticaBold', size: 16, color: mainColor });
    w.drawText(sub, x + 12, gridY + 55, { size: 8, color: nRgb(100, 110, 125) });
  };

  drawCard(margin, 'AGGREGATE VIEWS & REACH', data.totalViews, `Total Reach: ${data.totalReach}`);
  drawCard(margin + colWidth + 10, 'AUDIENCE ENGAGEMENT', data.engagementRate, 'Benchmark: Above Industry Avg', gold);
  drawCard(margin + (colWidth * 2) + 20, 'ASSET PRODUCTION YIELD', `${data.ugcAssetYield} UGC Videos`, '100% Milestone Completion');

  // Legal Panel
  const legalY = gridY + 80;
  w.drawRect(margin, legalY, contentWidth, 55, { fill: true, color: nRgb(252, 253, 255), stroke: true, borderColor: nRgb(220, 225, 235), borderWidth: 1 });
  w.drawText('LEGAL & SAFETY COMPLIANCE CERTIFICATION', margin + 14, legalY + 20, { font: 'helveticaBold', size: 10, color: navy });
  w.drawText(`• FTC Caption Disclosure: ${data.ftcComplianceScore} (Strict Unambiguous #ad Standard)`, margin + 14, legalY + 36, { size: 9, color: nRgb(60, 70, 85) });
  w.drawText(`• Audio & Trademark Security: ${data.copyrightStatus} (Cleared for Paid Whitelisting)`, margin + 14, legalY + 48, { size: 9, color: nRgb(60, 70, 85) });

  // Table
  const tableY = legalY + 75;
  w.drawText('CAMPAIGN ASSET OUTCOMES & CREATOR BREAKDOWN', margin, tableY, { font: 'helveticaBold', size: 12, color: navy });

  const headerY = tableY + 12;
  w.drawRect(margin, headerY, contentWidth, 22, { fill: true, color: nRgb(240, 243, 248) });
  w.drawText('CREATOR HANDLE', margin + 10, headerY + 14, { font: 'helveticaBold', size: 8, color: navy });
  w.drawText('NICHE / CATEGORY', margin + 140, headerY + 14, { font: 'helveticaBold', size: 8, color: navy });
  w.drawText('DELIVERABLE ASSET', margin + 260, headerY + 14, { font: 'helveticaBold', size: 8, color: navy });
  w.drawText('VIEWS', margin + 380, headerY + 14, { font: 'helveticaBold', size: 8, color: navy });
  w.drawText('FTC SAFETY', margin + 460, headerY + 14, { font: 'helveticaBold', size: 8, color: navy });

  let curY = headerY + 22;
  data.creatorDeliverables.forEach((row, idx) => {
    if (idx % 2 === 1) {
      w.drawRect(margin, curY, contentWidth, 22, { fill: true, color: nRgb(250, 251, 254) });
    }
    w.drawText(row.creatorHandle, margin + 10, curY + 15, { font: 'helveticaBold', size: 9, color: navy });
    w.drawText(row.niche, margin + 140, curY + 15, { size: 9, color: nRgb(80, 90, 105) });
    w.drawText(row.deliverableType, margin + 260, curY + 15, { size: 9, color: nRgb(80, 90, 105) });
    w.drawText(row.views, margin + 380, curY + 15, { size: 9, color: nRgb(80, 90, 105) });
    w.drawText(row.ftcTag, margin + 460, curY + 15, { font: 'helveticaBold', size: 9, color: nRgb(46, 125, 50) });
    curY += 22;
  });

  const footerY = w.height - margin - 20;
  w.drawLine(margin, footerY, w.width - margin, footerY, { color: gold, thickness: 0.5 });
  w.drawText('Confidential Client Wrap-Up Report \u2022 Prepared by Bloom Studio Agency \u2022 All Rights Reserved', margin, footerY + 14, { size: 8, color: nRgb(140, 150, 165) });
  w.drawText('Verified Safe for Organic & Paid Digital Ads', w.width - margin, footerY + 14, { align: 'right', size: 8, color: nRgb(140, 150, 165) });

  await w.save(`${data.brandName.toLowerCase().replace(/\s+/g, '_')}_campaign_wrapup.pdf`);
}

/**
 * DIRECTOR-ONLY EXECUTIVE LEDGER PDF EXPORT
 */
export async function exportDirectorLedgerPDF(user: UserProfile, data: DirectorLedgerData) {
  if (user.role !== 'Owner') {
    throw new Error('Unauthorized: Only Agency Principal (Owner) can export executive ledgers.');
  }

  const w = await PdfLibWriter.create();
  const navy = hexToRgb('#0B1B3D');
  const gold = hexToRgb('#D4AF37');
  const offWhite = nRgb(244, 246, 249);
  const margin = 40;
  const contentWidth = w.width - margin * 2;

  // Background
  w.drawRect(0, 0, w.width, w.height, { fill: true, color: navy });
  w.drawRect(margin, margin, contentWidth, 3, { fill: true, color: gold });

  w.drawText('BLOOM STUDIO - CONFIDENTIAL EXECUTIVE DIRECTORY REPORT', margin, margin + 26, { font: 'helveticaBold', size: 18, color: gold });
  w.drawText(`Internal Agency Ledger \u2022 Master Corporate Balance \u2022 Authorized for: ${user.name}`, margin, margin + 42, { size: 10, color: offWhite });
  w.drawText(`AUDIT DATE: ${data.generatedDate || new Date().toLocaleDateString()}`, w.width - margin, margin + 42, { align: 'right', font: 'helveticaBold', size: 9, color: gold });

  w.drawLine(margin, margin + 52, w.width - margin, margin + 52, { color: gold, thickness: 0.75 });

  const cardY = margin + 65;
  const colWidth = (contentWidth - 20) / 3;

  const drawSummaryCard = (x: number, title: string, main: string, sub: string, mainColor = offWhite) => {
    w.drawRect(x, cardY, colWidth, 68, { fill: true, color: nRgb(17, 34, 64), stroke: true, borderColor: gold, borderWidth: 0.5 });
    w.drawText(title, x + 12, cardY + 18, { font: 'helveticaBold', size: 8, color: nRgb(180, 190, 205) });
    w.drawText(main, x + 12, cardY + 40, { font: 'helveticaBold', size: 16, color: mainColor });
    w.drawText(sub, x + 12, cardY + 56, { size: 7.5, color: gold });
  };

  drawSummaryCard(margin, 'GROSS INBOUND REVENUE', `$${data.grossRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 'Invoiced Client Total');
  drawSummaryCard(margin + colWidth + 10, 'TOTAL CREATOR EXPENSES', `$${data.totalCreatorPayouts.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, 'Direct Escrow Allocation', nRgb(74, 222, 128));
  
  const marginPct = data.grossRevenue > 0 ? ((data.netRetainedProfit / data.grossRevenue) * 100).toFixed(1) : '0.0';
  drawSummaryCard(margin + (colWidth * 2) + 20, 'TRUE NET AGENCY MARGIN', `$${data.netRetainedProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, `Retained Margin: ${marginPct}%`, gold);

  const tableY = cardY + 85;
  w.drawText('INDIVIDUAL TALENT CONTRACTS & CASHFLOW ROSTER', margin, tableY, { font: 'helveticaBold', size: 11, color: gold });

  const headerY = tableY + 10;
  w.drawRect(margin, headerY, contentWidth, 20, { fill: true, color: nRgb(17, 34, 64) });
  w.drawText('BRAND & CAMPAIGN', margin + 8, headerY + 13, { font: 'helveticaBold', size: 8, color: gold });
  w.drawText('TALENT HANDLE', margin + 140, headerY + 13, { font: 'helveticaBold', size: 8, color: gold });
  w.drawText('CLIENT FEE ($)', margin + 230, headerY + 13, { font: 'helveticaBold', size: 8, color: gold });
  w.drawText('PAYOUT ($)', margin + 310, headerY + 13, { font: 'helveticaBold', size: 8, color: gold });
  w.drawText('MGR ($)', margin + 380, headerY + 13, { font: 'helveticaBold', size: 8, color: gold });
  w.drawText('RETAINED MARGIN', margin + 435, headerY + 13, { font: 'helveticaBold', size: 8, color: gold });

  let curY = headerY + 20;
  data.campaigns.forEach((camp, i) => {
    if (i % 2 === 1) {
      w.drawRect(margin, curY, contentWidth, 22, { fill: true, color: nRgb(13, 24, 48) });
    }
    w.drawText(camp.brandName, margin + 8, curY + 14, { font: 'helveticaBold', size: 8.5, color: offWhite });
    w.drawText(camp.creatorHandle, margin + 140, curY + 14, { font: 'helveticaBold', size: 8.5, color: gold });
    w.drawText(`$${camp.grossBrandContractValue.toLocaleString()}`, margin + 230, curY + 14, { size: 8.5, color: offWhite });
    w.drawText(`$${camp.influencerPayout.toLocaleString()}`, margin + 310, curY + 14, { size: 8.5, color: nRgb(74, 222, 128) });
    w.drawText(`$${camp.managerCompensation.toLocaleString()}`, margin + 380, curY + 14, { size: 8.5, color: nRgb(180, 190, 205) });
    w.drawText(`$${camp.agencyMargin.toLocaleString()}`, margin + 435, curY + 14, { font: 'helveticaBold', size: 8.5, color: gold });
    curY += 22;
  });

  const footerY = w.height - margin - 15;
  w.drawLine(margin, footerY, w.width - margin, footerY, { color: gold, thickness: 0.5 });
  w.drawText('STRICTLY CONFIDENTIAL \u2022 FOR AGENCY PRINCIPAL EYES ONLY \u2022 INTERNAL LEDGER', margin, footerY + 12, { size: 8, color: nRgb(180, 190, 205) });
  w.drawText('Bloom Studio Corporate Operating System', w.width - margin, footerY + 12, { align: 'right', size: 8, color: nRgb(180, 190, 205) });

  await w.save(`BloomStudio_Director_Master_Ledger_${new Date().toISOString().slice(0, 10)}.pdf`);
}

/**
 * Creative Brief PDF Generator
 */
export async function exportCreativeBriefPDF(brief: {
  brandName: string;
  campaignGoals: string;
  styleGuidelines: string;
  requiredHooks: string;
  contractLegalText: string;
  niche: string;
}) {
  const w = await PdfLibWriter.create();
  const navy = hexToRgb('#0B1B3D');
  const gold = hexToRgb('#D4AF37');
  const margin = 40;
  const contentWidth = w.width - margin * 2;

  w.drawRect(margin, margin, contentWidth, 3, { fill: true, color: gold });
  w.drawText('BLOOM STUDIO CREATIVE CAMPAIGN BRIEF', margin, margin + 26, { font: 'helveticaBold', size: 18, color: navy });
  w.drawText(`Brand Partner: ${brief.brandName.toUpperCase()} \u2022 Niche: ${brief.niche}`, margin, margin + 40, { size: 10, color: nRgb(120, 130, 145) });
  w.drawLine(margin, margin + 50, w.width - margin, margin + 50, { color: gold, thickness: 0.5 });

  let curY = margin + 70;

  const drawSection = (title: string, text: string, fontSize = 9.5) => {
    w.drawText(title, margin, curY, { font: 'helveticaBold', size: 11, color: navy });
    curY += 16;
    const lines = w.splitText(text, 'helvetica', fontSize, contentWidth);
    w.drawText(lines, margin, curY, { size: fontSize, color: nRgb(60, 70, 85), lineHeight: fontSize * 1.3 });
    curY += lines.length * (fontSize * 1.3) + 12;
  };

  drawSection('1. CAMPAIGN GOALS & OBJECTIVES', brief.campaignGoals || 'Deliver premium UGC storytelling with high organic reach.');
  drawSection('2. VISUAL STYLE & AESTHETIC GUIDELINES', brief.styleGuidelines || 'Natural daylight, 4K resolution, product closeups with genuine authentic reaction.');
  drawSection('3. REQUIRED CONTENT HOOKS & PRODUCT CALLOUTS', brief.requiredHooks || 'First 3 seconds: "This completely changed my routine..." with on-screen text overlay.');
  drawSection('4. DELIVERABLE CONTRACT & FTC SAFETY STIPULATIONS', brief.contractLegalText, 8.5);

  const footerY = w.height - margin - 15;
  w.drawLine(margin, footerY, w.width - margin, footerY, { color: gold, thickness: 0.5 });
  w.drawText('Bloom Studio Creative Brief \u2022 Client & Creator Reference Document', margin, footerY + 12, { size: 8, color: nRgb(140, 150, 165) });

  await w.save(`${brief.brandName.toLowerCase().replace(/\s+/g, '_')}_creative_brief.pdf`);
}

export interface CopyrightClearanceData {
  campaignName: string;
  brandName: string;
  creatorHandle: string;
  creatorLegalName?: string;
  niche?: string;
  creatorRightsPayout: number | string;
  effectiveDate?: string;
  creatorSignature?: string;
  signedAt?: string;
  verificationHash?: string;
}

/**
 * CLIENT & CREATOR FACING PDF EXPORT FUNCTION: downloadCopyrightClearancePDF
 */
export async function downloadCopyrightClearancePDF(data: CopyrightClearanceData) {
  const w = await PdfLibWriter.create();
  const navy = hexToRgb('#0B1B3D');
  const gold = hexToRgb('#D4AF37');
  const margin = 48;
  const contentWidth = w.width - margin * 2;

  let curY = margin + 10;
  w.drawLine(margin, curY, w.width - margin, curY, { color: gold, thickness: 1.5 });
  curY += 20;

  w.drawText('BLOOM STUDIO TALENT & PRODUCTION NETWORK', margin, curY, { font: 'timesBold', size: 18, color: navy });
  curY += 16;
  w.drawText('COMMERCIAL RIGHTS & COPYRIGHT BUYOUT AGREEMENT', margin, curY, { font: 'helveticaBold', size: 12, color: gold });
  curY += 14;
  w.drawText(`Certificate Identifier: BSM-CR-${Date.now().toString().slice(-8)} \u2022 Legal Clearance`, margin, curY, { size: 8.5, color: nRgb(90, 100, 115) });
  curY += 16;

  w.drawLine(margin, curY, w.width - margin, curY, { color: gold, thickness: 0.75 });
  curY += 20;

  w.drawRect(margin, curY, contentWidth, 54, { fill: true, color: nRgb(252, 252, 252), stroke: true, borderColor: gold, borderWidth: 0.5 });
  
  w.drawText('CAMPAIGN ASSET:', margin + 12, curY + 18, { font: 'helveticaBold', size: 8.5, color: navy });
  w.drawText(data.campaignName || 'Commercial Campaign Asset', margin + 115, curY + 18, { size: 8.5, color: nRgb(60, 70, 85) });
  
  w.drawText('ASSIGNING CREATOR:', margin + 12, curY + 36, { font: 'helveticaBold', size: 8.5, color: navy });
  w.drawText(`${data.creatorHandle} ${data.creatorLegalName ? `(${data.creatorLegalName})` : ''}`, margin + 130, curY + 36, { size: 8.5, color: nRgb(60, 70, 85) });

  w.drawText('BENEFICIARY BRAND:', margin + 260, curY + 18, { font: 'helveticaBold', size: 8.5, color: navy });
  w.drawText(data.brandName || 'Brand Partner', margin + 370, curY + 18, { size: 8.5, color: nRgb(60, 70, 85) });

  w.drawText('EFFECTIVE DATE:', margin + 260, curY + 36, { font: 'helveticaBold', size: 8.5, color: navy });
  w.drawText(data.effectiveDate || new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }), margin + 355, curY + 36, { size: 8.5, color: nRgb(60, 70, 85) });

  curY += 72;

  const drawClause = (title: string, text: string) => {
    w.drawText(title, margin, curY, { font: 'helveticaBold', size: 9.5, color: navy });
    curY += 14;
    const lines = w.splitText(text, 'helvetica', 8.5, contentWidth);
    w.drawText(lines, margin, curY, { size: 8.5, color: nRgb(50, 60, 75), lineHeight: 11.5 });
    curY += lines.length * 11.5 + 14;
  };

  drawClause('1. TRANSFER OF INTELLECTUAL PROPERTY & GLOBAL USAGE RIGHTS', `The Assigning Creator hereby irrevocably and permanently assigns, transfers, and conveys to Bloom Co Network and its designated brand beneficiary (${data.brandName}) all worldwide rights, titles, and copyright interests...`);
  
  const formattedPayout = typeof data.creatorRightsPayout === 'number' 
    ? `$${data.creatorRightsPayout.toLocaleString()}`
    : data.creatorRightsPayout.startsWith('$') ? data.creatorRightsPayout : `$${data.creatorRightsPayout}`;
  drawClause('2. COMPENSATION & EXCLUSIVE CONSIDERATION', `In full, complete, and final consideration... shall receive a standalone, all-inclusive flat fee consideration of ${formattedPayout} USD...`);
  
  drawClause('3. NICHE CLEARANCE CERTIFICATES & PRODUCTION INTEGRITY', `\u2022 Cosmetics & Beauty Vertical: Creator certifies that all demonstration footage is original...\n\u2022 Pet Care & Lifestyle Vertical: Creator warrants that all featured animals were handled under humane conditions...\n\u2022 Originality Warranty: Creator warrants that content does not infringe upon any third-party rights.`);
  drawClause('4. FTC COMPLIANCE & TRANSPARENCY WARRANTY', `Creator warrants that all initial organic postings comply fully with 16 C.F.R. Part 255 (FTC Endorsement Guides)...`);

  curY += 6;
  w.drawLine(margin, curY, w.width - margin, curY, { color: gold, thickness: 0.5 });
  curY += 16;

  w.drawText('EXECUTION & ELECTRONIC VERIFICATION RECORD', margin, curY, { font: 'helveticaBold', size: 9.5, color: navy });
  curY += 20;

  w.drawText('ASSIGNING CREATOR ELECTRONIC SIGNATURE:', margin, curY, { size: 8, color: nRgb(100, 110, 125) });
  w.drawText(data.creatorSignature || data.creatorLegalName || data.creatorHandle || 'Electronically Authorized', margin, curY + 18, { font: 'timesItalic', size: 13, color: navy });
  w.drawText(`Signed: ${data.signedAt || new Date().toISOString()}`, margin, curY + 32, { size: 8, color: nRgb(100, 110, 125) });

  w.drawText('AUTHORIZED AGENCY COUNSEL / DIRECTOR:', margin + 260, curY, { size: 8, color: nRgb(100, 110, 125) });
  w.drawText('Bloom Co Network IP Vault & Principal', margin + 260, curY + 18, { font: 'timesItalic', size: 13, color: navy });
  w.drawText(`Verification Token: ${data.verificationHash || 'VERIFIED-AES256-CLEARANCE'}`, margin + 260, curY + 32, { size: 8, color: nRgb(100, 110, 125) });

  const footerY = w.height - margin;
  w.drawLine(margin, footerY, w.width - margin, footerY, { color: gold, thickness: 0.5 });
  w.drawText('Bloom Co Network Legal Repository \u2022 Legal Clearance Certificate \u2022 Pure White Print Standard', margin, footerY + 10, { size: 7.5, color: nRgb(140, 150, 165) });

  await w.save(`${(data.campaignName || 'copyright').toLowerCase().replace(/[^a-z0-9]/g, '_')}_copyright_clearance_certificate.pdf`);
}

export interface WhitePaperMediaKitData {
  creatorName: string;
  creatorHandle: string;
  niche: string;
  totalReach: string;
  avgViews: string;
  engagementRate: string;
  avatarUrl?: string;
  bio?: string;
  nicheParams?: Array<{ label: string; value: string }>;
  topDeliverables?: Array<{ title: string; views: string; format: string }>;
  agencyName?: string;
  bookingEmail?: string;
}

/**
 * CLIENT-FACING WHITE PAPER PDF EXPORT FUNCTION: exportWhitePaperMediaKitPDF
 */
export async function exportWhitePaperMediaKitPDF(data: WhitePaperMediaKitData) {
  const w = await PdfLibWriter.create();
  const navy = hexToRgb('#0B1B3D');
  const gold = hexToRgb('#D4AF37');
  const margin = 40;
  const contentWidth = w.width - margin * 2;

  w.drawRect(margin, margin, contentWidth, 3, { fill: true, color: gold });

  w.drawText(data.agencyName || 'CLOONEY & CO. TALENT MANAGEMENT', margin, margin + 26, { font: 'helveticaBold', size: 20, color: navy });
  w.drawText('OFFICIAL VERIFIED TALENT MEDIA KIT & CAPABILITY PROFILE', margin, margin + 38, { size: 9, color: nRgb(120, 130, 145) });

  w.drawText('EXCLUSIVELY REPRESENTED', w.width - margin, margin + 26, { align: 'right', font: 'helveticaBold', size: 8.5, color: nRgb(180, 140, 30) });
  w.drawText(`Desk: ${data.bookingEmail || 'bookings@clooneyandco.com'}`, w.width - margin, margin + 38, { align: 'right', size: 8, color: nRgb(100, 110, 125) });

  w.drawLine(margin, margin + 50, w.width - margin, margin + 50, { color: nRgb(230, 233, 240) });

  let curY = margin + 70;
  w.drawText(data.creatorName, margin, curY, { font: 'helveticaBold', size: 24, color: navy });
  w.drawText(data.creatorHandle, margin, curY + 16, { font: 'helveticaBold', size: 11, color: nRgb(180, 140, 30) });
  w.drawText(`Primary Vertical: ${data.niche} \u2022 Certified FTC Compliant`, margin, curY + 30, { size: 9.5, color: nRgb(100, 110, 125) });

  curY += 46;
  const colWidth = (contentWidth - 20) / 3;

  const drawStat = (x: number, label: string, val: string, valColor = navy) => {
    w.drawRect(x, curY, colWidth, 54, { fill: true, color: nRgb(248, 249, 252), stroke: true, borderColor: nRgb(220, 225, 235), borderWidth: 0.8 });
    w.drawText(label, x + 12, curY + 18, { font: 'helveticaBold', size: 8, color: nRgb(120, 130, 145) });
    w.drawText(val, x + 12, curY + 40, { font: 'helveticaBold', size: 16, color: valColor });
  };

  drawStat(margin, 'VERIFIED AUDIENCE REACH', data.totalReach);
  drawStat(margin + colWidth + 10, 'AVG VIDEO VELOCITY', data.avgViews);
  drawStat(margin + (colWidth + 10) * 2, 'AUDIENCE ENGAGEMENT', data.engagementRate, nRgb(20, 140, 80));

  curY += 72;
  w.drawText(`NICHE PARAMETER PROFILE (${data.niche.toUpperCase()})`, margin, curY, { font: 'helveticaBold', size: 11, color: navy });
  w.drawLine(margin, curY + 4, margin + 180, curY + 4, { color: gold, thickness: 0.5 });
  curY += 18;

  const params = data.nicheParams && data.nicheParams.length > 0 ? data.nicheParams : [
    { label: "Content Aesthetic", value: "Natural Golden Hour / Clean Luxury" },
    { label: "Core Demographics", value: "82% Female / Ages 21-35 / US & Canada" },
    { label: "Commercial Rights", value: "Perpetual Whitelisting & 4K Master Cleared" }
  ];

  params.forEach(param => {
    w.drawRect(margin, curY, contentWidth, 24, { fill: true, color: nRgb(252, 252, 254), stroke: true, borderColor: nRgb(230, 233, 240), borderWidth: 0.5 });
    w.drawText(param.label.toUpperCase() + ':', margin + 10, curY + 15, { font: 'helveticaBold', size: 8.5, color: navy });
    w.drawText(param.value, margin + 180, curY + 15, { size: 8.5, color: nRgb(70, 80, 95) });
    curY += 28;
  });

  curY += 14;
  w.drawText('FEATURED 9:16 VERTICAL UGC ASSET SAMPLES', margin, curY, { font: 'helveticaBold', size: 11, color: navy });
  w.drawLine(margin, curY + 4, margin + 190, curY + 4, { color: gold, thickness: 0.5 });
  curY += 18;

  const samples = data.topDeliverables || [];
  const sampleWidth = (contentWidth - 20) / 3;
  samples.slice(0, 3).forEach((sample, i) => {
    const x = margin + i * (sampleWidth + 10);
    w.drawRect(x, curY, sampleWidth, 120, { fill: true, color: nRgb(245, 247, 250), stroke: true, borderColor: nRgb(215, 220, 230), borderWidth: 1 });
    w.drawText(sample.title, x + 8, curY + 70, { font: 'helveticaBold', size: 8.5, color: navy, maxWidth: sampleWidth - 16 });
    w.drawText(sample.format, x + 8, curY + 100, { size: 7.5, color: nRgb(100, 110, 125) });
    w.drawText(sample.views, x + 8, curY + 112, { font: 'helveticaBold', size: 7.5, color: nRgb(20, 140, 80) });
  });

  curY += 135;
  w.drawRect(margin, curY, contentWidth, 42, { fill: true, color: nRgb(248, 250, 252), stroke: true, borderColor: gold, borderWidth: 0.8 });
  w.drawText('[OK] 100% FTC COMPLIANCE REGISTRY CERTIFIED', margin + 14, curY + 18, { font: 'helveticaBold', size: 8.5, color: navy });
  w.drawText('[OK] COPYRIGHT & AUDIO COMMERCIAL CLEARANCE ACTIVE', margin + 14, curY + 32, { font: 'helveticaBold', size: 8.5, color: navy });

  const footerY = w.height - margin - 20;
  w.drawLine(margin, footerY, w.width - margin, footerY, { color: nRgb(230, 233, 240), thickness: 0.5 });
  w.drawText('COMMERCIAL REPRESENTATION & BOOKING MANAGEMENT: CLOONEY & CO.', margin, footerY + 14, { font: 'helveticaBold', size: 8.5, color: navy });
  w.drawText(`Inquiries & Rates: ${data.bookingEmail || 'bookings@clooneyandco.com'} | Web: https://clooneyandco.com`, margin, footerY + 26, { size: 8, color: nRgb(120, 130, 145) });

  await w.save(`${data.creatorName.toLowerCase().replace(/[^a-z0-9]/g, '_')}_white_paper_media_kit.pdf`);
}

export interface BrandInvoiceData {
  invoiceRef: string;
  campaignName: string;
  brandName: string;
  commitment: string;
  subtitle: string;
  terms: string;
  amount: number;
  status: string;
  date?: string;
  agencyName?: string;
}

/**
 * BRAND INVOICE PDF EXPORT
 */
export async function exportBrandInvoicePDF(data: BrandInvoiceData) {
  const w = await PdfLibWriter.create();
  const navy = hexToRgb('#0B1B3D');
  const gold = hexToRgb('#D4AF37');
  const margin = 48;
  const contentWidth = w.width - margin * 2;

  let curY = margin + 10;
  w.drawRect(margin, curY, contentWidth, 3, { fill: true, color: gold });
  curY += 24;

  const agencyTitle = (data.agencyName || 'BLOOM STUDIO').toUpperCase();
  w.drawText(agencyTitle, margin, curY, { font: 'helveticaBold', size: 22, color: navy });
  w.drawText('PREMIUM UGC CREATIVE PRODUCTION & ESCROW MANAGEMENT', margin, curY + 14, { size: 9, color: nRgb(120, 130, 145) });

  w.drawText('INVOICE / STATEMENT', w.width - margin, curY, { align: 'right', font: 'helveticaBold', size: 18, color: gold });
  w.drawText(`Reference: ${data.invoiceRef}`, w.width - margin, curY + 14, { align: 'right', size: 10, color: navy });

  curY += 45;
  w.drawLine(margin, curY, w.width - margin, curY, { color: nRgb(230, 233, 240) });
  curY += 24;

  const colWidth = contentWidth / 2;
  w.drawText('BILLED TO (CLIENT):', margin, curY, { font: 'helveticaBold', size: 10, color: nRgb(120, 130, 145) });
  w.drawText(data.brandName.toUpperCase(), margin, curY + 16, { font: 'helveticaBold', size: 12, color: navy });
  w.drawText(`Campaign: ${data.campaignName}`, margin, curY + 30, { size: 9, color: nRgb(90, 100, 115) });
  w.drawText(`Terms Arrangement: ${data.terms}`, margin, curY + 44, { size: 9, color: nRgb(90, 100, 115) });

  w.drawText('ISSUER & PAYEE:', margin + colWidth, curY, { font: 'helveticaBold', size: 10, color: nRgb(120, 130, 145) });
  const issuerPayee = (data.agencyName === 'BLOOM STUDIO' || !data.agencyName) ? 'BLOOM & CO NETWORK' : data.agencyName.toUpperCase();
  w.drawText(issuerPayee, margin + colWidth, curY + 16, { font: 'helveticaBold', size: 12, color: navy });
  w.drawText('8424 Santa Monica Blvd', margin + colWidth, curY + 30, { size: 9, color: nRgb(90, 100, 115) });
  w.drawText('West Hollywood, CA 90069', margin + colWidth, curY + 44, { size: 9, color: nRgb(90, 100, 115) });
  w.drawText('finance@bloomstudio.agency', margin + colWidth, curY + 58, { size: 9, color: nRgb(90, 100, 115) });

  curY += 85;
  const boxWidth = (contentWidth - 16) / 3;
  const drawMetaBox = (x: number, label: string, val: string) => {
    w.drawRect(x, curY, boxWidth, 42, { fill: true, color: nRgb(248, 249, 252), stroke: true, borderColor: nRgb(230, 233, 240), borderWidth: 1 });
    w.drawText(label.toUpperCase(), x + 10, curY + 16, { font: 'helveticaBold', size: 8, color: nRgb(120, 130, 145) });
    w.drawText(val, x + 10, curY + 30, { font: 'helveticaBold', size: 9.5, color: navy });
  };

  drawMetaBox(margin, 'Invoice Date', data.date || new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }));
  drawMetaBox(margin + boxWidth + 8, 'Payment Terms', data.terms);
  drawMetaBox(margin + (boxWidth + 8) * 2, 'Clearing Status', data.status);

  curY += 65;
  w.drawRect(margin, curY, contentWidth, 24, { fill: true, color: navy });
  w.drawText('DESCRIPTION / COMMITMENT DETAILS', margin + 12, curY + 15, { font: 'helveticaBold', size: 9, color: rgb(1, 1, 1) });
  w.drawText('TOTAL BILLED (USD)', w.width - margin - 12, curY + 15, { align: 'right', font: 'helveticaBold', size: 9, color: rgb(1, 1, 1) });

  curY += 24;
  w.drawRect(margin, curY, contentWidth, 54, { fill: true, color: nRgb(252, 253, 255), stroke: true, borderColor: nRgb(230, 233, 240), borderWidth: 1 });
  w.drawText(data.commitment, margin + 12, curY + 22, { font: 'helveticaBold', size: 10, color: navy });
  w.drawText(data.subtitle, margin + 12, curY + 36, { size: 8.5, color: nRgb(120, 130, 145) });
  w.drawText(`Sourced under Campaign Ref: ${data.campaignName}`, margin + 12, curY + 46, { size: 8.5, color: nRgb(120, 130, 145) });

  const formattedAmt = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(data.amount);
  w.drawText(formattedAmt, w.width - margin - 12, curY + 32, { align: 'right', font: 'helveticaBold', size: 11, color: navy });

  curY += 54 + 12;
  const totalBoxWidth = 220;
  const totalX = w.width - margin - totalBoxWidth;
  w.drawRect(totalX, curY, totalBoxWidth, 48, { fill: true, color: nRgb(248, 249, 252), stroke: true, borderColor: gold, borderWidth: 1 });
  w.drawText('GROSS OUTSTANDING TOTAL:', totalX + 12, curY + 18, { size: 9, color: nRgb(120, 130, 145) });
  w.drawText(formattedAmt, w.width - margin - 12, curY + 42, { align: 'right', font: 'helveticaBold', size: 14, color: navy });

  curY += 75;
  w.drawText('WIRE TRANSFER & SETTLEMENT DISPATCH INSTRUCTIONS', margin, curY, { font: 'helveticaBold', size: 10, color: navy });
  w.drawLine(margin, curY + 4, margin + 280, curY + 4, { color: gold, thickness: 0.5 });
  curY += 16;
  
  const instructionLines = [
    '\u2022 Please forward all wire transfers to the Bloom & Co Network production escrow clearing account listed on the master contract.',
    '\u2022 Include the Invoice Reference Number above on all remittance advices or check descriptors.',
    '\u2022 Funds are held in legal escrow pending verified delivery and brand acceptance of all UGC assets.',
    '\u2022 Thank you for your partnership with Bloom Studio.'
  ];
  w.drawText(instructionLines, margin, curY, { size: 8.5, color: nRgb(90, 100, 115), lineHeight: 11.9 });

  const footerY = w.height - margin - 20;
  w.drawLine(margin, footerY, w.width - margin, footerY, { color: nRgb(230, 233, 240), thickness: 0.5 });
  w.drawText('BLOOM STUDIO (BLOOM & CO NETWORK) \u2022 WWW.BLOOMSTUDIO.AGENCY', margin, footerY + 12, { font: 'helveticaBold', size: 8, color: navy });
  w.drawText('Licensed talent agency & digital production studio under state guidelines.', margin, footerY + 22, { size: 7.5, color: nRgb(120, 130, 145) });

  await w.save(`invoice_${data.invoiceRef.toLowerCase().replace(/[^a-z0-9]/g, '_')}.pdf`);
}
