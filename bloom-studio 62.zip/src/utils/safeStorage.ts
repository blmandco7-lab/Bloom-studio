/**
 * Resilient Storage Utility & Polyfill
 * Prevents DOMException: "The operation is insecure." when the app runs in
 * sandboxed iframes, third-party cookie restricted environments, or private browsing modes.
 */

class MemoryStorage implements Storage {
  private store = new Map<string, string>();

  get length(): number {
    return this.store.size;
  }

  clear(): void {
    this.store.clear();
  }

  getItem(key: string): string | null {
    return this.store.has(key) ? (this.store.get(key) ?? null) : null;
  }

  key(index: number): string | null {
    return Array.from(this.store.keys())[index] ?? null;
  }

  removeItem(key: string): void {
    this.store.delete(key);
  }

  setItem(key: string, value: string): void {
    this.store.set(key, String(value));
  }
}

const memoryStore = new MemoryStorage();

export const safeStorage = {
  getItem(key: string): string | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem(key);
      }
    } catch {
      // Fallback to memory store if localStorage is insecure / sandboxed
    }
    return memoryStore.getItem(key);
  },

  setItem(key: string, value: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, value);
      }
    } catch {
      // Ignore or fallback to memory store
    }
    memoryStore.setItem(key, value);
  },

  removeItem(key: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(key);
      }
    } catch {}
    memoryStore.removeItem(key);
  },

  clear(): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.clear();
      }
    } catch {}
    memoryStore.clear();
  },

  key(index: number): string | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.key(index);
      }
    } catch {}
    return memoryStore.key(index);
  },

  get length(): number {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.length;
      }
    } catch {}
    return memoryStore.length;
  }
};

/**
 * Installs memory fallbacks on `window.localStorage` and `window.sessionStorage`
 * if accessing them throws "The operation is insecure."
 */
export function initializeSafeStoragePolyfill(): void {
  if (typeof window === 'undefined') return;

  const sessionMemoryStore = new MemoryStorage();

  // 1. Wrap Storage.prototype methods if Storage exists, ensuring they never throw DOMException
  if (typeof Storage !== 'undefined' && Storage.prototype) {
    try {
      const origGetItem = Storage.prototype.getItem;
      const origSetItem = Storage.prototype.setItem;
      const origRemoveItem = Storage.prototype.removeItem;
      const origClear = Storage.prototype.clear;

      Storage.prototype.getItem = function (key: string): string | null {
        try {
          return origGetItem.call(this, key);
        } catch {
          return memoryStore.getItem(key);
        }
      };

      Storage.prototype.setItem = function (key: string, val: string): void {
        try {
          origSetItem.call(this, key, val);
        } catch {
          memoryStore.setItem(key, val);
        }
      };

      Storage.prototype.removeItem = function (key: string): void {
        try {
          origRemoveItem.call(this, key);
        } catch {
          memoryStore.removeItem(key);
        }
      };

      Storage.prototype.clear = function (): void {
        try {
          origClear.call(this);
        } catch {
          memoryStore.clear();
        }
      };
    } catch (e) {
      console.warn('[SafeStorage] Could not patch Storage.prototype:', e);
    }
  }

  // 2. Test and safeguard window.localStorage
  let localStorageAvailable = false;
  try {
    const testKey = '__ais_sec_test__';
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(testKey, testKey);
      window.localStorage.removeItem(testKey);
      localStorageAvailable = true;
    }
  } catch (err) {
    console.warn('[SafeStorage] window.localStorage threw a security exception. Installing safe memory storage fallback.');
  }

  if (!localStorageAvailable) {
    const targets = typeof Window !== 'undefined' && Window.prototype ? [Window.prototype, window] : [window];
    for (const target of targets) {
      try {
        Object.defineProperty(target, 'localStorage', {
          get() {
            return memoryStore;
          },
          set() {},
          configurable: true,
          enumerable: true
        });
      } catch {}
    }
  }

  // 3. Test and safeguard window.sessionStorage
  let sessionStorageAvailable = false;
  try {
    const testKey = '__ais_sec_test__';
    if (typeof window !== 'undefined' && window.sessionStorage) {
      window.sessionStorage.setItem(testKey, testKey);
      window.sessionStorage.removeItem(testKey);
      sessionStorageAvailable = true;
    }
  } catch (err) {
    console.warn('[SafeStorage] window.sessionStorage threw a security exception. Installing safe memory storage fallback.');
  }

  if (!sessionStorageAvailable) {
    const targets = typeof Window !== 'undefined' && Window.prototype ? [Window.prototype, window] : [window];
    for (const target of targets) {
      try {
        Object.defineProperty(target, 'sessionStorage', {
          get() {
            return sessionMemoryStore;
          },
          set() {},
          configurable: true,
          enumerable: true
        });
      } catch {}
    }
  }

  // 4. Test and safeguard window.indexedDB
  let indexedDBAvailable = false;
  try {
    if (typeof window !== 'undefined' && window.indexedDB) {
      indexedDBAvailable = true;
    }
  } catch (err) {
    console.warn('[SafeStorage] window.indexedDB threw a security exception. Installing safe null fallback.');
  }

  if (!indexedDBAvailable) {
    const targets = typeof Window !== 'undefined' && Window.prototype ? [Window.prototype, window] : [window];
    for (const target of targets) {
      try {
        Object.defineProperty(target, 'indexedDB', {
          get() {
            return null;
          },
          set() {},
          configurable: true,
          enumerable: true
        });
      } catch {}
    }
  }

  // 5. Safeguard History API (replaceState / pushState) against iframe origin security errors
  try {
    if (typeof window !== 'undefined' && window.history) {
      const origReplaceState = window.history.replaceState;
      if (origReplaceState) {
        window.history.replaceState = function (data: any, unused: string, url?: string | URL | null) {
          try {
            return origReplaceState.call(window.history, data, unused, url);
          } catch (err) {
            console.warn('[SafeStorage] Guarded history.replaceState:', err);
          }
        };
      }
      const origPushState = window.history.pushState;
      if (origPushState) {
        window.history.pushState = function (data: any, unused: string, url?: string | URL | null) {
          try {
            return origPushState.call(window.history, data, unused, url);
          } catch (err) {
            console.warn('[SafeStorage] Guarded history.pushState:', err);
          }
        };
      }
    }
  } catch (e) {}

  // 6. Safeguard Clipboard API
  try {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      const origWriteText = navigator.clipboard.writeText;
      if (origWriteText) {
        navigator.clipboard.writeText = async function (text: string): Promise<void> {
          try {
            return await origWriteText.call(navigator.clipboard, text);
          } catch (err) {
            console.warn('[SafeStorage] Guarded clipboard.writeText:', err);
            try {
              const textArea = document.createElement('textarea');
              textArea.value = text;
              textArea.style.position = 'fixed';
              textArea.style.left = '-9999px';
              document.body.appendChild(textArea);
              textArea.focus();
              textArea.select();
              document.execCommand('copy');
              document.body.removeChild(textArea);
            } catch {}
          }
        };
      }
    }
  } catch (e) {}
}
