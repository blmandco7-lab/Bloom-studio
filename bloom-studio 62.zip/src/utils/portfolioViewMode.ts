/**
 * Single source of truth for portfolio view mode and permissions.
 *
 * Scenarios:
 *   a) Anonymous visitor (not signed in) opening a public/shared portfolio link
 *      -> isBrandShareView: true, effectiveRole: 'brand'
 *   b) Signed-in user with role director/owner/agency, viewing through normal app navigation
 *      -> isBrandShareView: false, effectiveRole: real role (Full management access, real creator data, working navigation)
 *   c) Signed-in user with any other role (or authenticated brand user) viewing a shared portfolio link
 *      -> isBrandShareView: true, effectiveRole: their role or 'brand' (Restricted view, 5 creator limit, anonymized data, no internal navigation)
 */
export interface PortfolioViewMode {
  effectiveRole: string;
  isBrandShareView: boolean;
  isDirectorRole: boolean;
  isCreatorRole: boolean;
}

export function getPortfolioViewMode(currentUser: any, currentRole?: string): PortfolioViewMode {
  const roleFromUser = currentUser?.role;
  const roleRaw = (roleFromUser || currentRole || '').toLowerCase().trim();

  // Check if user is authenticated / signed in to the application
  const isAuthenticated = Boolean(
    currentUser &&
    (currentUser.id || currentUser.uid || currentUser.email) &&
    !currentUser.isAnonymous
  );

  // Resolve effective role
  const effectiveRole = (roleFromUser || currentRole || 'brand').toLowerCase();
  const isDirectorRole = ['director', 'owner', 'agency', 'platform_owner'].some(r => effectiveRole.includes(r)) || Boolean(currentUser?.isPlatformOwner);
  const isCreatorRole = effectiveRole === 'creator';

  // Explicit URL query forcing preview mode (?preview=true, #preview, ?brand=true, or #public-portfolio?brand=true)
  const isExplicitPreviewUrl = typeof window !== 'undefined' && (
    window.location.hash.includes('preview=true') ||
    window.location.search.includes('preview=true') ||
    window.location.hash.includes('brand=true') ||
    window.location.search.includes('brand=true')
  );

  // Restricted 5-creator Brand Share View applies ONLY if the user has NOT signed up / signed in
  const isBrandShareView = !isAuthenticated || isExplicitPreviewUrl;

  return {
    effectiveRole: roleFromUser || currentRole || (isBrandShareView ? 'brand' : 'director'),
    isBrandShareView,
    isDirectorRole,
    isCreatorRole,
  };
}
