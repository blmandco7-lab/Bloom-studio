import { db } from '../lib/firebase';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';

/**
 * DATABASE UTILITY: archiveCompletedCampaign
 * 
 * Non-destructive state modifier for Firestore architecture.
 * Safely moves active campaign documents into cold-archive storage.
 * 
 * @param campaignId - The specific campaign document identifier in studio-campaigns
 */
export async function archiveCompletedCampaign(campaignId: string): Promise<void> {
  if (!campaignId) {
    throw new Error('Missing required identifier: campaignId is required to archive a campaign.');
  }

  // Document Path in live studio-campaigns collection
  const campaignDocRef = doc(db, 'studio-campaigns', campaignId);

  // Non-destructive mutation: Toggle status index fields
  await updateDoc(campaignDocRef, {
    'status.isActive': false,
    'status.archivedAt': serverTimestamp(),
    'status.workflowPhase': 'Archived',
    isArchived: true
  });
}
