
export interface TrainingStep {
  id: string;
  title: string;
  desc: string;
  refCode?: string;
}

export interface TrainingPhase {
  id: string;
  number: number;
  title: string;
  desc: string;
  icon: string;
  steps: TrainingStep[];
  videoUrl: string;
  sheetContent: string;
}

export const AGENT_MANAGER_PHASES: TrainingPhase[] = [
  {
    id: 'phase_1',
    number: 1,
    title: 'Security Provisioning & Authentication Set',
    desc: 'Ensuring your digital identity and hardware meet agency encryption standards.',
    icon: 'Shield',
    videoUrl: 'https://www.w3schools.com/html/movie.mp4',
    sheetContent: `
### Phase 1: Security Provisioning & Authentication Set

This phase covers the foundational security requirements for all Agent Managers. Accessing sensitive creator data and brand contracts requires a verified, encrypted environment.

#### 1. Google Authentication Verification
*   **Action:** Complete your social login enrollment sequence.
*   **Goal:** Map your unique Firestore account user token cleanly to the Agent Manager role path.
*   **Reference Code:** [9hqWU2]

#### 2. Device Security Compliance Validation
*   **Action:** Verify the tablet or mobile device you use for login.
*   **Requirement:** Must utilize active encryption keys and passcode parameters.
*   **Standard:** Meets system secure infrastructure badges.

#### 3. Data Privacy Sign-Off
*   **Action:** Electronically sign the internal non-disclosure agreement (NDA).
*   **Scope:** Explicitly details that attempts to reverse-engineer brand payouts or share creator directories externally will trigger immediate account lockouts.
    `.trim(),
    steps: [
      { id: 's1_1', title: 'Google Auth Verification', desc: 'Map unique user token to Agent Manager role path.', refCode: '[9hqWU2]' },
      { id: 's1_2', title: 'Device Security Compliance', desc: 'Verify active encryption and passcode parameters on login devices.' },
      { id: 's1_3', title: 'Data Privacy Sign-Off', desc: 'Execute internal NDA regarding financial and directory confidentiality.' }
    ]
  },
  {
    id: 'phase_2',
    number: 2,
    title: 'Content Policing & Compliance Systems',
    desc: 'Mastering the AI-powered auditing tools for FTC and copyright safety.',
    icon: 'ShieldCheck',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    sheetContent: `
### Phase 2: Content Policing & Compliance Systems

You are the final gatekeeper for creator content. High-quality, compliant output is our core product.

#### 1. AI Copyright & Sound Scanner Audit
*   **Training:** Learn to process incoming creator UGC files.
*   **Protocols:** Screen video clips for unlicensed background tracks and flag unauthorized competitor logos.
*   **Reference Code:** [hqEvOB]

#### 2. FTC Compliance Desk Mastery
*   **System:** Utilize automated text scoreboards [A8RUdy].
*   **Procedure:** Audit caption text placements and video transcripts to ensure disclosures (#ad, #sponsored) are clear on the first pass.

#### 3. Revision Quality Gate Calibration
*   **Standard:** Define what triggers a "Revision Requested" survey vs. a "Straight Approval."
*   **Revision Triggers:** Low illumination, poor framing, or inadequate product close-ups in beauty/lifestyle niches.
    `.trim(),
    steps: [
      { id: 's2_1', title: 'Copyright Scanner Audit', desc: 'Screen clips for unlicensed tracks or competitor logos.', refCode: '[hqEvOB]' },
      { id: 's2_2', title: 'FTC Compliance Desk', desc: 'Audit caption placements and transcripts using scoreboards.', refCode: '[A8RUdy]' },
      { id: 's2_3', title: 'Quality Gate Calibration', desc: 'Establish standards for revision vs. approval triggers.' }
    ]
  },
  {
    id: 'phase_3',
    number: 3,
    title: 'Timeline & Deadline Management',
    desc: 'Coordinating the studio-fulfillment pipeline and 48-hour review windows.',
    icon: 'Clock',
    videoUrl: 'https://www.w3schools.com/html/movie.mp4',
    sheetContent: `
### Phase 3: Timeline & Deadline Management

Agencies run on strict schedules. You must maintain the heartbeat of the production pipeline.

#### 1. The 2-Day Review Clock Handshake
*   **SOP:** All content must be reviewed within 48 hours of submission [WgNXme].
*   **Automation:** Clicking "Approve" instantly pushes files to the client portal and locks in 12-hour warning timers for brands.
*   **Reference Code:** [WgNXme]

#### 2. Fulfillment Log Verification
*   **Pipeline:** Monitor the shared studio-fulfillment pipeline [9hqWU2].
*   **Inventory:** Check carrier codes for shipped product samples (cosmetics, pet merch). Follow up on shipments "In Transit" for too long.

#### 3. Production Calendar Enforcement
*   **Focus:** Review deliverable posting schedules to prevent talent timelines from running behind.
    `.trim(),
    steps: [
      { id: 's3_1', title: '2-Day Review Window', desc: 'Enforce the 48-hour corporate review protocol.', refCode: '[WgNXme]' },
      { id: 's3_2', title: 'Fulfillment Log Audit', desc: 'Monitor sample shipping and carrier code statuses.', refCode: '[9hqWU2]' },
      { id: 's3_3', title: 'Production Calendar Review', desc: 'Maintain posting schedules to prevent talent delays.' }
    ]
  },
  {
    id: 'phase_4',
    number: 4,
    title: 'Talent Curation & Crisis Handling',
    desc: 'Optimizing creator matching and documenting production emergencies.',
    icon: 'Users',
    videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
    sheetContent: `
### Phase 4: Talent Curation & Crisis Handling

Strategic matchmaking and rapid crisis response are key management metrics.

#### 1. Match or Pass Workspace Training
*   **Tool:** Fast-vetting profile swipe tool.
*   **Goal:** Map creators to incoming cosmetics, pet, or lifestyle briefs efficiently.
*   **Reference Code:** [9hqWU2]

#### 2. Audition Shortlist Optimization
*   **Grading:** Establish guidelines for grading casting call submissions.
*   **Verification:** Verify video URL lengths and move approved candidates to active states.

#### 3. Crisis Log Standard Procedures
*   **Protocol:** Record creator emergencies, late script filings, or brand disputes.
*   **System:** Log incidents inside the hidden log panels [9hqWU2].
    `.trim(),
    steps: [
      { id: 's4_1', title: 'Match or Pass Training', desc: 'Utilize profile swipe tool for niche brief mapping.', refCode: '[9hqWU2]' },
      { id: 's4_2', title: 'Audition Optimization', desc: 'Grade casting submissions and verify candidate URLs.' },
      { id: 's4_3', title: 'Crisis Log Procedures', desc: 'Document emergencies and disputes in hidden log panels.', refCode: '[9hqWU2]' }
    ]
  },
  {
    id: 'phase_5',
    number: 5,
    title: 'The Financial Discretion Protocol',
    desc: 'Handling buyout rates and maintaining financial data boundaries.',
    icon: 'DollarSign',
    videoUrl: 'https://www.w3schools.com/html/movie.mp4',
    sheetContent: `
### Phase 5: The Financial Discretion Protocol

Maintaining agency margins and financial focus is critical for professional boundaries.

#### 1. Flat-Fee Compensation Alignment
*   **Rule:** Offers must be presented strictly as flat dollar values.
*   **Boundary:** Prohibited from discussing macro agency margin percentages with talent.
*   **Reference Code:** [9hqWU2]

#### 2. Closed Mail Stream Boundaries
*   **Security:** System filters out financial terms from creator chat views.
*   **Escalation:** If brand pricing variables leak into chat, document immediately in the Director Watchdog Loop.
*   **Reference Code:** [9hqWU2]
    `.trim(),
    steps: [
      { id: 's5_1', title: 'Flat-Fee Alignment', desc: 'Communicate strictly flat-fee values without margin talk.', refCode: '[9hqWU2]' },
      { id: 's5_2', title: 'Closed Mail Boundaries', desc: 'Maintain financial filtering and report pricing leaks.', refCode: '[9hqWU2]' }
    ]
  }
];
