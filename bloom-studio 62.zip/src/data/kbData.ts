/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { KBArticle, TrainingGuide } from '../types';

export const DEFAULT_KB_ARTICLES: KBArticle[] = [
  {
    id: 'kb1',
    title: 'How to disclose sponsored content on TikTok',
    category: 'ftc',
    section: 'Creator',
    content: 'Every sponsored post must start with #ad or #sponsored as the FIRST thing in your caption. The FTC requires it visible before any "see more" cutoff. Also, make sure to toggle on the Paid Partnership label in TikTok post settings.'
  },
  {
    id: 'kb2',
    title: 'When and how you get paid',
    category: 'pay',
    section: 'Creator',
    content: 'Payments are processed within 5-7 business days after the brand confirms the campaign is complete and releases the funds from Escrow. Make sure your W-9 is uploaded and approved before requesting your first payout.'
  },
  {
    id: 'kb3',
    title: 'How to apply for casting calls',
    category: 'deals',
    section: 'Creator',
    content: 'Open casting calls appear in your "Available Deals" tab. Tap Apply, write a brief pitch, and your agent will review within 24 hours. Never contact brands directly — let us handle the contract negotiations.'
  },
  {
    id: 'kb4',
    title: 'What is a media kit',
    category: 'agency',
    section: 'Creator',
    content: 'Your media kit is a professional profile Bloom & Co sends to brand clients, showcasing your social statistics, audience demographics, niches, and rate card. Keep your social connections active to update these numbers.'
  },
  {
    id: 'kb5',
    title: 'Understanding your management contract',
    category: 'contracts',
    section: 'Creator',
    content: 'Your contract covers commission split, exclusivity terms, and deal structures. Exclusive creators get a higher payout percentage. Contracts are typically 12 months with 30 days notice required to end early.'
  },
  {
    id: 'kb6',
    title: 'How your rate is set',
    category: 'pay',
    section: 'Creator',
    content: 'Your rate is based on follower count, average engagement rate, niche, and platform. Your agent reviews rates quarterly. Never quote your own rates directly to brands — let us negotiate to get you top value.'
  },
  {
    id: 'kb7',
    title: 'FTC rules for Instagram and YouTube',
    category: 'ftc',
    section: 'Creator',
    content: 'Instagram: #ad must be in the first line of your caption, and you must use the Paid Partnership label. YouTube: verbally disclose sponsorship in the first 30 seconds and check the Paid Promotion box.'
  },
  {
    id: 'kb8',
    title: 'How content review works',
    category: 'agency',
    section: 'Creator',
    content: 'Submit caption drafts and video files to your agent at least 48 hours before the deadline. You will hear back within 24 hours. Do not post without approval, as failure to do so can void your payment.'
  },
  {
    id: 'kb9',
    title: 'Exclusive vs non-exclusive explained',
    category: 'contracts',
    section: 'Creator',
    content: 'Exclusive: you work only with Bloom & Co, higher payout (75-80%). Non-exclusive: you can work with other agencies, standard payout (60-70%) through us. Exclusive creators get priority on premium brand campaigns.'
  },
  {
    id: 'kb_brand1',
    title: 'How to launch a campaign with Bloom & Co',
    category: 'deals',
    section: 'Brand',
    content: 'Submit a campaign brief outlining your brand goals, target audience, deliverables, and budget. Our agents will curated a custom lineup of creators matching your niche and submit a formal proposal.'
  },
  {
    id: 'kb_brand2',
    title: 'Reviewing and approving creator content',
    category: 'agency',
    section: 'Brand',
    content: 'Once creators submit drafts, they will appear on your "Content Review" tab. You can view the videos, read caption drafts, flag specific seconds for revisions, or approve the post with a single tap.'
  },
  {
    id: 'kb_brand3',
    title: 'Stripe Escrow & Milestone Payments',
    category: 'pay',
    section: 'Brand',
    content: 'To secure creator availability, campaign funds are held securely in Stripe Escrow. You configure milestone release rules (e.g., 50% on draft approval, 50% on post going live). Funds are released only upon your explicit approval.'
  },
  {
    id: 'kb_brand4',
    title: 'Content licensing and usage rights guidelines',
    category: 'contracts',
    section: 'Brand',
    content: 'Standard campaigns license content for organic social use only. If you wish to run the creator\'s post as a paid ad (UGC repurposing) or display it on your website, you must secure additional usage rights in your contract.'
  },
  {
    id: 'kb_brand5',
    title: 'Tracking campaign ROI & EMV',
    category: 'platform',
    section: 'Brand',
    content: 'Every campaign delivers real-time views, clicks, and conversion analytics. Your post-campaign report includes Earned Media Value (EMV), indicating what equivalent reach would have cost in paid advertising.'
  },
  {
    id: 'kb_agent1',
    title: 'How to pitch a brand deal',
    category: 'deals',
    section: 'Agent',
    content: 'Confirm the creator is available first. Build a one-page deck with stats, niche, and proposed rate. Send via email, never DM from personal accounts. Follow up after 3 business days.'
  },
  {
    id: 'kb_agent2',
    title: 'Deal approval process',
    category: 'deals',
    section: 'Agent',
    content: 'Deals over $500 require Agent Manager approval before contracting. Submit in the Deal Pipeline as Pitched. Once approved, move to Contracted and send the NDA and contract.'
  },
  {
    id: 'kb_agent3',
    title: 'How commission is calculated',
    category: 'agency',
    section: 'Agent',
    content: 'Your commission is a percentage of every deal you close, set in your agent profile. It is paid out after the brand payment clears alongside the creator payout.'
  },
  {
    id: 'kb_mgr1',
    title: 'Reviewing agent performance',
    category: 'agency',
    section: 'Agent Manager',
    content: 'Check Agent Scoring monthly for deal volume, close rate, and creator satisfaction. Agents below threshold for 2 consecutive months should get a coaching check-in.'
  },
  {
    id: 'kb_dir1',
    title: 'Agency commission structure',
    category: 'agency',
    section: 'Director — Internal',
    content: 'Bloom & Co takes a commission on every closed deal. Exclusive creators get a higher payout than non-exclusive. Sub-agencies operate on a revenue split set per agreement.'
  },
  {
    id: 'kb_dir2',
    title: 'Setting brand blacklist criteria',
    category: 'agency',
    section: 'Director — Internal',
    content: 'Blacklist a brand for non-payment, FTC violations, contract breach, or brand safety risk. Document the reason and amount owed before adding to the blacklist.'
  },
  {
    id: 'kb_sub1',
    title: 'Sub-agency responsibilities',
    category: 'agency',
    section: 'Sub-Agency',
    content: 'You manage your own creators under Bloom & Co policies. All deals follow Bloom & Co FTC and content review standards. Deals over $5K need master agency approval.'
  }
];

export const DEFAULT_TRAINING_GUIDES: TrainingGuide[] = [
  {
    id: 'tr_creator',
    title: 'Creator: Navigation & Dashboard Walkthrough',
    role: 'Creator',
    category: 'Dashboard Navigation',
    type: 'Video',
    description: 'Learn how to navigate your personal dashboard. This guide explains how to view your statistics (followers, engagement rate, monthly earnings), claim available brand deals in the Casting Calls tab, submit post captions/video links for approval, and refer fellow creators for bonuses.',
    embedVideoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
  },
  {
    id: 'tr_creator_brands',
    title: 'What to Expect from Brands',
    role: 'Creator',
    category: 'Brand Relations & Etiquette',
    type: 'Video',
    description: 'Learn what to expect when collaborating with brands: typical campaign expectations, deliverable timelines, how revision requests are communicated and resolved, and professional communication norms throughout the deal lifecycle.',
    embedVideoUrl: 'https://www.w3schools.com/html/movie.mp4'
  },
  {
    id: 'tr_agent',
    title: 'Agent: Sourcing, Pitching & Managing Creators',
    role: 'Agent',
    category: 'Agent Onboarding',
    type: 'Video',
    description: 'A complete walkthrough of your active workspace. Learn how to monitor your assigned roster\'s availability calendar, move deals through the pipeline, review and approve draft captions, flag content for FTC compliance issues, and private log agent-only creator notes.',
    embedVideoUrl: 'https://www.w3schools.com/html/movie.mp4'
  },
  {
    id: 'tr_agentmgr',
    title: 'Agent Manager: Team Tracking & Overrides',
    role: 'Agent Manager',
    category: 'Team Management',
    type: 'Video',
    description: 'Learn how to manage your team of agents. This module covers monitoring agent performance via data-driven Scoring metrics, reviewing overall headcount, applying individual commission overrides for top-performers, and facilitating deal approvals.',
    embedVideoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
  },
  {
    id: 'tr_brand',
    title: 'Brand: Campaign Controls & Escrow Management',
    role: 'Brand',
    category: 'Client Onboarding',
    type: 'Video',
    description: 'Unlock your client portal. See how to trace active campaign progress, perform video moment-flagging inside the Content Review studio, establish Escrow milestones, sign licensing contracts, and send secure messages to your Account Manager.',
    embedVideoUrl: 'https://www.w3schools.com/html/movie.mp4'
  },
  {
    id: 'tr_subagency',
    title: 'Sub-Agency: Partner Collabs & Roster Syncing',
    role: 'Sub-Agency',
    category: 'Network Collaboration',
    type: 'Video',
    description: 'How to manage your independent sub-agency within the Bloom & Co network. Covers syncing your roster for master-agency matching, claiming open network deals, tracking revenue splits, and signing the anti-poaching non-solicitation agreement.',
    embedVideoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
  },
  {
    id: 'tr_agency',
    title: 'Agency: Collab Sourcing & Roster Optimization',
    role: 'Agency',
    category: 'Agency Workspace',
    type: 'Video',
    description: 'Master the agency portal. Learn how to discover open collab deals posted by Bloom & Co, submit matched creators, track your verified agency status, monitor split revenue campaigns, and configure platform profile demographics.',
    embedVideoUrl: 'https://www.w3schools.com/html/movie.mp4'
  },
  {
    id: 'tr_director',
    title: 'Director: Master Admin & Bot Configuration',
    role: 'Director',
    category: 'Master Administration',
    type: 'Video',
    description: 'Full platform administration. Learn how to configure the 12 automated bots, change default commission ratios, generate enterprise API access tokens, review the comprehensive system audit trail, manage shared role passwords, and export white-label platform builds.',
    embedVideoUrl: 'https://www.w3schools.com/html/movie.mp4'
  }
];
