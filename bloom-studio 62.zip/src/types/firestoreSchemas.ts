/**
 * FIRESTORE DATA BLUEPRINT & SCHEMA SPECIFICATIONS
 * 
 * 1. Multi-Tier User Schema ('users/{userId}')
 * 2. Personal Staff Sub-Collection ('users/{userId}/staffLedgers/{ledgerId}')
 * 3. Dynamic Cash-Flow Schedule ('clients/{clientId}/campaigns/{campaignId}.paymentTermsSchedule')
 */

export const FIRESTORE_SCHEMAS = {
  /**
   * 1. USERS COLLECTION SCHEMA: 'users/{userId}'
   */
  userDocumentExample: {
    uid: "usr_agent_8821",
    name: "Elena Rostova",
    email: "elena.r@bloomstudio.agency",
    // Explicit 4-Tier Roles: "Director" | "AgentManager" | "Agent" | "Coordinator"
    role: "Agent", 
    // Hierarchical reporting line to an AgentManager
    reportsToUserId: "usr_mgr_sarah_04", 
    // Isolated Pay Objects
    compensation: {
      campaignSplitPercentage: 15.0, // Used for AgentManager & Agent
      flatRatePerCampaign: 450.00,    // Alternative flat fee per project
      hourlyRate: null               // Coordinator specific field ($/hr)
    },
    coordinatorPayConfig: {
      hourlyRate: 35.00,             // Specific flat-rate or hourly tracking for Coordinators
      overtimeAllowed: false
    },
    createdAt: "2026-08-23T10:00:00Z",
    status: {
      isActive: true
    }
  },

  /**
   * 2. STAFF LEDGERS SUB-COLLECTION SCHEMA: 'users/{userId}/staffLedgers/{ledgerId}'
   * Zero references or equations to master inbound corporate brand contracts.
   */
  staffLedgerDocumentExample: {
    id: "ledger_2026_q3",
    userId: "usr_agent_8821",
    // Aggregated dollar amounts from campaigns currently marked active/in-progress
    expectedUpcomingPay: 1850.00,
    // Clear cumulative sum of completed and disbursed project payouts
    totalEarnedToDate: 14200.00,
    // Nested array tracking past actions exclusively from manually set staff rates
    campaignBreakdownLog: [
      {
        campaignId: "camp_glowlab_01",
        campaignName: "Summer Glow Botanical Serum",
        nicheCategory: "Beauty",
        userContractRole: "Lead Talent Casting Agent",
        lockedStaffPayoutAmount: 450.00,
        payoutStatus: "Locked for Payroll" // "Pending Verification" | "Locked for Payroll" | "Disbursed via Transfer"
      },
      {
        campaignId: "camp_barkhydrate_02",
        campaignName: "Organic Pet Hydration Balm",
        nicheCategory: "Pets",
        userContractRole: "Logistics Coordinator",
        lockedStaffPayoutAmount: 350.00,
        payoutStatus: "Disbursed via Transfer"
      }
    ],
    lastUpdated: "2026-08-23T12:00:00Z"
  },

  /**
   * 3. PAYMENT TERMS SCHEDULE SCHEMA: 'clients/{clientId}/campaigns/{campaignId}.paymentTermsSchedule'
   * Macro time-lock controlling staff-facing escrow milestone states.
   */
  campaignPaymentTermsScheduleExample: {
    // Brand Terms Tracker
    brandPaymentTerm: "Net 30", // "Upfront" | "Net 15" | "Net 30" | "Net 60"
    invoiceDate: "2026-08-01T00:00:00Z",
    estimatedClearDate: "2026-08-31T00:00:00Z",
    
    // Escrow Milestone States (Read by staff-facing earnings widgets)
    escrowStatus: "Cleared in Escrow", // "Awaiting Brand Deposit" | "Cleared in Escrow" | "Disbursed"
    
    escrowAuditHistory: [
      {
        state: "Awaiting Brand Deposit",
        timestamp: "2026-08-01T09:00:00Z",
        note: "Invoice #BLM-8849 sent to GlowLab Beauty Accounts Payable."
      },
      {
        state: "Cleared in Escrow",
        timestamp: "2026-08-15T14:30:00Z",
        note: "Wire deposit received. Funds secured in agency escrow account."
      }
    ]
  }
};
