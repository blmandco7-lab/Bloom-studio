import React, { useState, useEffect } from 'react';
import { getSafeUrl } from '../../utils/security';
import { db } from '../../lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { safeStorage } from '../../utils/safeStorage';
import {
  Sparkles,
  Play,
  Download,
  Copy,
  Check,
  Crown,
  Layers,
  Cpu,
  ShieldCheck,
  DollarSign,
  TrendingUp,
  Clock,
  RefreshCw,
  Video,
  Sliders,
  CheckCircle2,
  Film,
  Lock,
  ExternalLink,
  ChevronRight,
  Maximize2
} from 'lucide-react';

interface SyntheticMediaStudioProps {
  currentUser?: any;
  currentRole?: string;
  onAddActivityLog?: (userName: string, role: string, description: string) => void;
  triggerNotification?: (title: string, detail: string, type?: 'success' | 'warning' | 'danger' | 'info') => void;
}

interface VideoGenerationPayload {
  id: string;
  title: string;
  script: string;
  model: string;
  aspectRatio: '9:16' | '16:9' | '1:1';
  durationSeconds: number;
  timestamp: string;
  videoUrl: string;
  status: 'ready' | 'rendering' | 'queued';
  computeCost: number; // 0 for free open source
  fps: number;
  seed: number;
}

const FREE_MODELS = [
  { id: 'kling-free-space', name: 'Kling-Free-Space (HF Space v1.4)', endpoint: 'https://huggingface.co/spaces/kling-ai/video-open', latency: '3.8s' },
  { id: 'luma-gradio-node', name: 'Luma-Gradio-Node (DreamMachine Open)', endpoint: 'https://huggingface.co/spaces/luma-community/gradio-gen', latency: '4.2s' },
  { id: 'ltx-video-opensource', name: 'LTX-Video-OpenSource (Lightricks 0.9b)', endpoint: 'https://huggingface.co/spaces/Lightricks/LTX-Video', latency: '2.9s' },
  { id: 'cogvideox-freenode', name: 'CogVideoX-FreeNode (THUDM 5B)', endpoint: 'https://huggingface.co/spaces/THUDM/CogVideoX-5B-Space', latency: '5.1s' },
  { id: 'svd-open-space', name: 'Stable-Video-Diffusion (Stability Free Node)', endpoint: 'https://huggingface.co/spaces/stabilityai/stable-video-diffusion', latency: '3.4s' }
];

const SAMPLE_PAYLOADS: VideoGenerationPayload[] = [
  {
    id: 'syn-001',
    title: 'Matcha Clarifying Toner Hook',
    script: 'POV: You stopped using 10 different skincare serums and switched to this pure matcha clarifying mist. Glow in 3 days.',
    model: 'LTX-Video-OpenSource',
    aspectRatio: '9:16',
    durationSeconds: 6,
    timestamp: '2026-08-31 09:42',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    status: 'ready',
    computeCost: 0.00,
    fps: 24,
    seed: 9482104
  },
  {
    id: 'syn-002',
    title: 'Silk Velvet Lip Stain UGC Ad',
    script: 'Stop gatekeeping your lip routine. This velvet tint does NOT smudge on coffee cups. 12hr waterproof test.',
    model: 'Kling-Free-Space',
    aspectRatio: '9:16',
    durationSeconds: 5,
    timestamp: '2026-08-31 08:15',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    status: 'ready',
    computeCost: 0.00,
    fps: 30,
    seed: 8812903
  }
];

export const SyntheticMediaStudio: React.FC<SyntheticMediaStudioProps> = ({
  currentUser,
  currentRole = 'director',
  onAddActivityLog,
  triggerNotification
}) => {
  const role = (currentRole || '').toLowerCase();
  // Role-Based Privacy Bounds: Only Director/Owner can inspect macro backend expense tracking and 100% net cash flow ledgers
  const isDirector = role === 'director' || role === 'owner';

  const effectiveCreatorId = currentUser?.id || currentUser?.handle || 'creator_default';
  const effectiveHandle = currentUser?.handle || '@signed_talent';

  const [isLicenseActive, setIsLicenseActive] = useState<boolean>(false);
  const [activeLicenseData, setActiveLicenseData] = useState<any>(null);
  const [provisionedSeat, setProvisionedSeat] = useState<string | null>(() => {
    try {
      return safeStorage.getItem('wl_synthetic_seat') || null;
    } catch {
      return null;
    }
  });

  const handleProvisionSeat = (tierName: string) => {
    setProvisionedSeat(tierName);
    safeStorage.setItem('wl_synthetic_seat', tierName);
    if (triggerNotification) {
      triggerNotification('Seat Provisioned', `${tierName} Synthetic Studio seat assigned to creator instance.`, 'success');
    }
    if (onAddActivityLog) {
      onAddActivityLog(currentUser?.fullName || 'Agency Manager', currentRole || 'director', `Provisioned ${tierName} seat in Synthetic Media Studio`);
    }
  };

  // Real-time Firestore license status subscription
  useEffect(() => {
    if (!effectiveCreatorId || effectiveCreatorId === 'unknown') return;

    try {
      const cached = safeStorage.getItem(`likeness_license_${effectiveCreatorId}`) || safeStorage.getItem(`likeness_license_${effectiveHandle}`);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.status === 'Active') {
          setIsLicenseActive(true);
          setActiveLicenseData(parsed);
        }
      }
    } catch (e) {}

    const licenseDocRef = doc(db, 'studio-likeness-licenses', `${effectiveCreatorId}_likeness_license`);
    const unsubscribe = onSnapshot(licenseDocRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.status === 'Active') {
          setIsLicenseActive(true);
          setActiveLicenseData(data);
          try {
            safeStorage.setItem(`likeness_license_${effectiveCreatorId}`, JSON.stringify(data));
          } catch (e) {}
        } else {
          setIsLicenseActive(false);
          setActiveLicenseData(null);
        }
      } else {
        setIsLicenseActive(false);
        setActiveLicenseData(null);
      }
    }, (err) => {
      console.warn('Licensing subscription note:', err);
    });

    return () => unsubscribe();
  }, [effectiveCreatorId, effectiveHandle]);

  const [scriptInput, setScriptInput] = useState(
    'Show a luxury aesthetic skincare bottle unboxing in soft morning light. The formula sparkles with rose-gold pigments as the creator tests it on skin.'
  );
  const [selectedModel, setSelectedModel] = useState('ltx-video-opensource');
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '16:9' | '1:1'>('9:16');
  const [motionSpeed, setMotionSpeed] = useState(7);
  const [isRendering, setIsRendering] = useState(false);
  const [renderProgress, setRenderProgress] = useState(0);
  const [generatedVideos, setGeneratedVideos] = useState<VideoGenerationPayload[]>(SAMPLE_PAYLOADS);
  const [activePreviewVideo, setActivePreviewVideo] = useState<VideoGenerationPayload>(SAMPLE_PAYLOADS[0]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Executive Margin Simulation
  const executiveLedger = {
    grossSubscriptionsBilled: 14820.00,
    freeOpenSourceComputeExpense: 0.00,
    netRetainedCashMargin: 14820.00,
    profitMarginPercent: 100.0,
    activeCorporateClients: 38,
    averageMonthlyCreditsIssued: 42000
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    triggerNotification?.('Copied to Clipboard', 'Video asset parameters copied successfully.', 'info');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleRenderFreeVideo = async () => {
    if (!scriptInput.trim()) return;

    if (!isLicenseActive) {
      triggerNotification?.(
        'Consent Denied',
        'Biometric Likeness License must be signed before AI Twin video generation is permitted. Please sign the agreement in the Creator AI Twin module first.',
        'warning'
      );
      return;
    }

    setIsRendering(true);
    setRenderProgress(10);

    const modelObj = FREE_MODELS.find(m => m.id === selectedModel) || FREE_MODELS[0];

    // Call server endpoint with server-side isVerifiedActive and pod verification
    try {
      const response = await fetch('/api/ai-twin/generate-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          creatorId: effectiveCreatorId,
          creatorHandle: effectiveHandle,
          promptText: scriptInput,
          requestedModel: modelObj.name,
          aspectRatio,
          motionSpeed
        })
      });

      const resData = await response.json().catch(() => ({}));

      if (!response.ok || !resData.success) {
        setIsRendering(false);
        triggerNotification?.(
          'Generation Denied',
          resData.error || 'Server rejected generation due to unverified biometric consent or permissions.',
          'danger'
        );
        return;
      }

      triggerNotification?.(
        '🚀 Consent Verified — Free Node Handshake',
        `Validated Biometric Likeness License. Connecting to ${modelObj.name} at $0.00 compute cost.`,
        'info'
      );

      // Progressive Handshake Simulation against open source pipeline
      const interval = setInterval(() => {
        setRenderProgress(prev => {
          if (prev >= 90) {
            clearInterval(interval);
            return 95;
          }
          return prev + 25;
        });
      }, 450);

      setTimeout(() => {
        clearInterval(interval);
        setIsRendering(false);
        setRenderProgress(100);

        const newAsset: VideoGenerationPayload = {
          id: `syn-${Date.now().toString().slice(-4)}`,
          title: scriptInput.slice(0, 32) + (scriptInput.length > 32 ? '...' : ''),
          script: scriptInput,
          model: modelObj.name.split(' ')[0],
          aspectRatio,
          durationSeconds: 6,
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
          videoUrl: resData.draft?.videoUrl || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
          status: 'ready',
          computeCost: 0.00,
          fps: 24,
          seed: Math.floor(1000000 + Math.random() * 9000000)
        };

        setGeneratedVideos(prev => [newAsset, ...prev]);
        setActivePreviewVideo(newAsset);

        triggerNotification?.(
          '✨ Video Render Complete',
          `Vertical 9:16 MP4 rendered via open-source ${modelObj.name}. Cost: $0.00`,
          'success'
        );

        onAddActivityLog?.(
          currentUser?.name || 'Creative Engineer',
          currentRole,
          `Generated 9:16 synthetic video via ${modelObj.name} (Consent Verified)`
        );
      }, 2400);

    } catch (err: any) {
      setIsRendering(false);
      triggerNotification?.(
        'Generation Error',
        err?.message || 'Failed to verify consent with AI Twin service.',
        'danger'
      );
    }
  };

  return (
    <div id="synthetic-media-studio" className="min-h-screen bg-[#0B1B3D] text-slate-100 p-4 sm:p-6 lg:p-8 space-y-8 font-sans">
      {/* Top Header Card */}
      <div className="bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-2xl text-[#D4AF37]">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-wide flex items-center gap-3">
                  Synthetic Media Studio
                  <span className="text-xs font-mono px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full font-bold">
                    $0 Out-of-Pocket Open Source Pipeline
                  </span>
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 mt-1">
                  High-throughput AI video generation connecting directly to free Hugging Face Spaces & Gradio inference nodes. 100% software margins.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className={`px-4 py-2 border rounded-2xl text-xs font-mono flex items-center gap-2 ${
              isLicenseActive
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
            }`}>
              {isLicenseActive ? (
                <>
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold">Biometric License: Active</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 text-rose-400" />
                  <span className="font-bold">Biometric License: Required</span>
                </>
              )}
            </div>
            <div className="px-4 py-2 bg-[#0B1B3D] border border-white/10 rounded-2xl text-xs font-mono">
              <span className="text-slate-400">Pipeline State: </span>
              <span className="text-emerald-400 font-bold">⚡ Zero-Cost Free Cloud Nodes</span>
            </div>
            <div className="px-4 py-2 bg-[#0B1B3D] border border-[#D4AF37]/30 rounded-2xl text-xs font-mono">
              <span className="text-[#D4AF37] font-bold">Client Billing Model: 100% Margin</span>
            </div>
          </div>
        </div>
      </div>

      {/* License Requirement Alert Banner */}
      {!isLicenseActive && (
        <div className="bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-amber-500/10 border border-amber-500/30 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 border border-amber-500/30 rounded-xl text-amber-400 shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-amber-200">Biometric Likeness Consent Required</h4>
              <p className="text-xs text-slate-300 mt-0.5">
                AI video synthesis requires an active signed Biometric Likeness License to render synthetic voice or likeness assets.
              </p>
            </div>
          </div>
          <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-3 py-1.5 rounded-xl border border-amber-500/20 whitespace-nowrap">
            Sign in Creator AI Twin
          </span>
        </div>
      )}

      {/* COMPONENT MODULE 1: THE $0 GRADIO SCRIPT COMPILER & PREVIEW CANVAS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left-Side Column: Control Deck & Script Compiler */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-[#D4AF37]" />
                <h2 className="text-base font-bold text-white uppercase tracking-wider text-xs font-mono">
                  Gradio Script Compiler
                </h2>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full">
                $0.00 / Query
              </span>
            </div>

            {/* Model Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center justify-between">
                <span>Free Open-Source Model Node</span>
                <span className="text-[10px] text-slate-400 font-normal">Hugging Face Space / Gradio</span>
              </label>
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
                className="w-full bg-[#0B1B3D] border border-white/15 rounded-2xl px-4 py-3 text-sm text-white focus:border-[#D4AF37] outline-none font-mono"
              >
                {FREE_MODELS.map((m) => (
                  <option key={m.id} value={m.id} className="bg-[#0B1B3D] text-white">
                    {m.name} — Latency: {m.latency}
                  </option>
                ))}
              </select>
            </div>

            {/* Script Textarea */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center justify-between">
                <span>Input Free AI Ad Script</span>
                <span className="text-[10px] text-slate-400 font-normal">{scriptInput.length}/500 chars</span>
              </label>
              <textarea
                rows={4}
                value={scriptInput}
                onChange={(e) => setScriptInput(e.target.value)}
                className="w-full bg-[#0B1B3D] border border-white/15 rounded-2xl p-4 text-sm text-white focus:border-[#D4AF37] outline-none resize-none leading-relaxed"
              />
            </div>

            {/* Controls: Aspect Ratio & Motion */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300">Format</label>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#0B1B3D] rounded-xl border border-white/10">
                  {(['9:16', '16:9', '1:1'] as const).map((ratio) => (
                    <button
                      key={ratio}
                      type="button"
                      onClick={() => setAspectRatio(ratio)}
                      className={`py-1.5 text-xs font-mono font-bold rounded-lg transition-all ${
                        aspectRatio === ratio
                          ? 'bg-[#D4AF37] text-[#0B1B3D] shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {ratio}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex justify-between">
                  <span>Motion</span>
                  <span className="text-[#D4AF37] font-mono">{motionSpeed}/10</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={motionSpeed}
                  onChange={(e) => setMotionSpeed(parseInt(e.target.value))}
                  className="w-full accent-[#D4AF37] cursor-pointer mt-2"
                />
              </div>
            </div>

            {/* Render Progress Bar */}
            {isRendering && (
              <div className="p-4 bg-[#0B1B3D] border border-[#D4AF37]/30 rounded-2xl space-y-2 animate-pulse">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#D4AF37]">Streaming Gradio Weights...</span>
                  <span className="text-emerald-400">{renderProgress}%</span>
                </div>
                <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#D4AF37] to-emerald-400 transition-all duration-300 rounded-full"
                    style={{ width: `${renderProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Main Action Button */}
            <button
              type="button"
              disabled={isRendering}
              onClick={handleRenderFreeVideo}
              className="w-full py-4 px-6 bg-gradient-to-r from-[#D4AF37] via-[#E6C665] to-[#C9A46A] hover:brightness-110 active:scale-[0.99] text-[#0B1B3D] font-bold text-sm rounded-2xl shadow-xl shadow-[#D4AF37]/10 flex items-center justify-center gap-2 transition-all cursor-pointer font-mono tracking-wide"
            >
              {isRendering ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Compiling Free Gradio Stream...</span>
                </>
              ) : (
                <>
                  <Film className="w-5 h-5" />
                  <span>🚀 Render Free AI Video Asset</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right-Side Column: Video Payloads Canvas & Preview Cards */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-[#142850] border border-white/10 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Video className="w-5 h-5 text-[#D4AF37]" />
                <h2 className="text-base font-bold text-white uppercase tracking-wider text-xs font-mono">
                  Active Video Payloads & Live Stream
                </h2>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {generatedVideos.length} Assets in Session
              </span>
            </div>

            {/* Active Video Player Screen */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              <div className="md:col-span-6 flex justify-center">
                <div className="w-full max-w-[280px] aspect-[9/16] bg-[#0B1B3D] border-2 border-[#D4AF37]/40 rounded-3xl overflow-hidden shadow-2xl relative group flex flex-col justify-between">
                  <video
                    src={activePreviewVideo.videoUrl}
                    controls
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3 px-2.5 py-1 bg-black/60 backdrop-blur-md rounded-full text-[10px] font-mono text-[#D4AF37] border border-[#D4AF37]/30">
                    {activePreviewVideo.aspectRatio} • {activePreviewVideo.fps} FPS
                  </div>
                  <div className="absolute top-3 right-3 px-2.5 py-1 bg-emerald-950/80 backdrop-blur-md rounded-full text-[10px] font-mono text-emerald-400 border border-emerald-500/40">
                    Cost: $0.00
                  </div>
                </div>
              </div>

              {/* Video Metadata Breakdown */}
              <div className="md:col-span-6 space-y-4">
                <div className="bg-[#0B1B3D] border border-white/10 rounded-2xl p-4 space-y-3">
                  <span className="text-[10px] font-mono uppercase text-[#D4AF37] font-bold">Selected Asset Metadata</span>
                  <h3 className="text-base font-bold text-white">{activePreviewVideo.title}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed italic bg-white/5 p-3 rounded-xl">
                    "{activePreviewVideo.script}"
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2">
                    <div className="p-2.5 bg-white/5 rounded-xl">
                      <span className="text-slate-400 block text-[10px]">Model Node</span>
                      <strong className="text-white">{activePreviewVideo.model}</strong>
                    </div>
                    <div className="p-2.5 bg-white/5 rounded-xl">
                      <span className="text-slate-400 block text-[10px]">Duration</span>
                      <strong className="text-white">{activePreviewVideo.durationSeconds}s @ {activePreviewVideo.fps}fps</strong>
                    </div>
                    <div className="p-2.5 bg-white/5 rounded-xl">
                      <span className="text-slate-400 block text-[10px]">Seed</span>
                      <strong className="text-[#D4AF37]">{activePreviewVideo.seed}</strong>
                    </div>
                    <div className="p-2.5 bg-white/5 rounded-xl">
                      <span className="text-slate-400 block text-[10px]">Infrastructure Cost</span>
                      <strong className="text-emerald-400">$0.00 (Zero Out-of-Pocket)</strong>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <a
                      href={getSafeUrl(activePreviewVideo.videoUrl)}
                      download={`${activePreviewVideo.id}.mp4`}
                      className="flex-1 py-2.5 bg-[#D4AF37] text-[#0B1B3D] font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md font-mono"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download .MP4</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => handleCopy(activePreviewVideo.id, activePreviewVideo.script)}
                      className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-mono flex items-center gap-1.5"
                    >
                      {copiedId === activePreviewVideo.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Stream Queue History */}
                <div className="space-y-2">
                  <span className="text-xs font-bold font-mono text-slate-400 uppercase">Recent Session Queue</span>
                  <div className="space-y-2">
                    {generatedVideos.map((vid) => (
                      <div
                        key={vid.id}
                        onClick={() => setActivePreviewVideo(vid)}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                          activePreviewVideo.id === vid.id
                            ? 'bg-[#0B1B3D] border-[#D4AF37]'
                            : 'bg-[#0B1B3D]/60 border-white/5 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-[#D4AF37]/10 text-[#D4AF37] rounded-xl">
                            <Play className="w-3.5 h-3.5 fill-current" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white truncate max-w-[180px]">{vid.title}</p>
                            <span className="text-[10px] text-slate-400 font-mono">{vid.timestamp} • {vid.model}</span>
                          </div>
                        </div>
                        <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full">
                          $0.00 Cost
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* COMPONENT MODULE 2: REVENUE-GENERATING SUBSCRIPTION PRICING GRID */}
      <div className="bg-[#142850] border border-[#D4AF37]/20 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-mono uppercase font-bold text-[#D4AF37] tracking-widest">
            Commercial Client Monetization Matrix
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Client Subscription Pricing Plans
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Brand clients subscribe to access AI rendering batches. Since backend compute operates on 100% free open-source infrastructure, the agency retains 100% cash flow margin.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
          {/* Starter Tier */}
          <div className="bg-[#0B1B3D] border border-white/10 rounded-3xl p-6 flex flex-col justify-between space-y-6 relative hover:border-white/20 transition-all">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-bold text-white">Starter Studio</h3>
                <p className="text-xs text-slate-400 mt-1">For boutique brands testing TikTok/Reels hooks</p>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold font-mono text-white">$19</span>
                <span className="text-xs text-slate-400">/month</span>
              </div>

              <div className="space-y-2.5 pt-2 border-t border-white/10 text-xs">
                <div className="flex items-center gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>200 monthly generation credits</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Standard open-source rendering queues</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>9:16 vertical MP4 export</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center">
                <span className="text-[11px] font-mono font-bold text-emerald-400">Agency Profit Margin: 100% ($19.00/mo)</span>
              </div>
              <button
                type="button"
                onClick={() => handleProvisionSeat('Starter')}
                className={`w-full py-3 font-bold text-xs rounded-xl transition-all font-mono cursor-pointer ${
                  provisionedSeat === 'Starter'
                    ? 'bg-emerald-500 text-black'
                    : 'bg-white/10 hover:bg-white/15 text-white'
                }`}
              >
                {provisionedSeat === 'Starter' ? '✓ Starter Seat Active' : 'Assign Starter Seat'}
              </button>
            </div>
          </div>

          {/* Plus Tier (Gold Border & Crown Icon) */}
          <div className="bg-[#0B1B3D] border-2 border-[#D4AF37] rounded-3xl p-6 flex flex-col justify-between space-y-6 relative shadow-2xl shadow-[#D4AF37]/10 transform md:-translate-y-2">
            <div className="absolute -top-3.5 left-1/2 transform -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D] rounded-full text-[10px] font-bold uppercase tracking-wider font-mono flex items-center gap-1 shadow-lg">
              <Crown className="w-3 h-3 fill-current" />
              <span>Agency Top Recommendation</span>
            </div>

            <div className="space-y-4">
              <div className="pt-2">
                <div className="flex items-center gap-2">
                  <Crown className="w-5 h-5 text-[#D4AF37]" />
                  <h3 className="text-xl font-bold text-white">Plus Tier</h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">High-volume UGC brand marketing campaigns</p>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-bold font-mono text-[#D4AF37]">$49</span>
                <span className="text-xs text-slate-400">/month</span>
              </div>

              <div className="space-y-2.5 pt-2 border-t border-white/10 text-xs">
                <div className="flex items-center gap-2 text-slate-100 font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>1,000 monthly generation credits</span>
                </div>
                <div className="flex items-center gap-2 text-slate-100 font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Priority Gradio node processing</span>
                </div>
                <div className="flex items-center gap-2 text-slate-100 font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Automated Copyright & Audio Scanner</span>
                </div>
                <div className="flex items-center gap-2 text-slate-100 font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Multi-Creator likeness rights support</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="p-2.5 bg-[#D4AF37]/15 border border-[#D4AF37]/40 rounded-xl text-center">
                <span className="text-[11px] font-mono font-bold text-[#D4AF37]">Agency Profit Margin: 100% ($49.00/mo)</span>
              </div>
              <button
                type="button"
                onClick={() => handleProvisionSeat('Plus')}
                className={`w-full py-3.5 font-bold text-xs rounded-xl transition-all shadow-lg font-mono cursor-pointer ${
                  provisionedSeat === 'Plus'
                    ? 'bg-emerald-500 text-black'
                    : 'bg-gradient-to-r from-[#D4AF37] to-[#E3C48F] text-[#0B1B3D]'
                }`}
              >
                {provisionedSeat === 'Plus' ? '✓ Plus Seat Active' : 'Provision Plus Seat'}
              </button>
            </div>
          </div>

          {/* Ultra Tier */}
          <div className="bg-[#0B1B3D] border border-white/10 rounded-3xl p-6 flex flex-col justify-between space-y-6 relative hover:border-white/20 transition-all">
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-bold text-white">Ultra Enterprise</h3>
                <p className="text-xs text-slate-400 mt-1">Enterprise direct brand studios & scale ad agencies</p>
              </div>

              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold font-mono text-white">$99</span>
                <span className="text-xs text-slate-400">/month</span>
              </div>

              <div className="space-y-2.5 pt-2 border-t border-white/10 text-xs">
                <div className="flex items-center gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>3,000 monthly generation credits</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Parallel rendering engines (multi-stream)</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Custom brand voice & style fine-tuning</span>
                </div>
                <div className="flex items-center gap-2 text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Dedicated concierge SLA support</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center">
                <span className="text-[11px] font-mono font-bold text-emerald-400">Agency Profit Margin: 100% ($99.00/mo)</span>
              </div>
              <button
                type="button"
                onClick={() => handleProvisionSeat('Ultra')}
                className={`w-full py-3 font-bold text-xs rounded-xl transition-all font-mono cursor-pointer ${
                  provisionedSeat === 'Ultra'
                    ? 'bg-emerald-500 text-black'
                    : 'bg-white/10 hover:bg-white/15 text-white'
                }`}
              >
                {provisionedSeat === 'Ultra' ? '✓ Ultra Seat Active' : 'Provision Ultra Seat'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* COMPONENT MODULE 3: ABSOLUTE ROLE-BASED DATA BLINDSPOT ARCHITECTURE */}
      {/* If user.role === 'Director', unlock executive expense tracking table rows. If user is Manager, Agent, Coordinator, or Creator, completely omit and strip from DOM */}
      {isDirector ? (
        <div className="bg-[#142850] border border-[#D4AF37]/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in duration-300">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-xl text-[#D4AF37]">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2 font-mono">
                  Executive Cash Flow & Expense Ledger
                  <span className="text-[10px] px-2 py-0.5 bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37] rounded-full">
                    Director Only Privileged View
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Internal cash pool tracking. Masked and unmounted for all non-Director accounts.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>100% Zero Out-of-Pocket Compute Model</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
            <div className="p-4 bg-[#0B1B3D] border border-white/10 rounded-2xl space-y-1">
              <span className="text-[10px] uppercase font-mono text-slate-400">Gross Billed to Brands</span>
              <p className="text-xl font-bold font-mono text-white">${executiveLedger.grossSubscriptionsBilled.toFixed(2)}</p>
              <span className="text-[10px] text-slate-400">{executiveLedger.activeCorporateClients} corporate accounts active</span>
            </div>

            <div className="p-4 bg-[#0B1B3D] border border-white/10 rounded-2xl space-y-1">
              <span className="text-[10px] uppercase font-mono text-emerald-400">Compute Expense Outlay</span>
              <p className="text-xl font-bold font-mono text-emerald-400">${executiveLedger.freeOpenSourceComputeExpense.toFixed(2)}</p>
              <span className="text-[10px] text-slate-400">Open-source public inference nodes</span>
            </div>

            <div className="p-4 bg-[#0B1B3D] border border-[#D4AF37]/30 rounded-2xl space-y-1">
              <span className="text-[10px] uppercase font-mono text-[#D4AF37]">Net Retained Cash Margin</span>
              <p className="text-xl font-bold font-mono text-[#D4AF37]">${executiveLedger.netRetainedCashMargin.toFixed(2)}</p>
              <span className="text-[10px] text-emerald-400 font-mono">100.0% Net Flow</span>
            </div>

            <div className="p-4 bg-[#0B1B3D] border border-white/10 rounded-2xl space-y-1">
              <span className="text-[10px] uppercase font-mono text-cyan-400">Monthly Yield</span>
              <p className="text-xl font-bold font-mono text-cyan-400">{(executiveLedger.averageMonthlyCreditsIssued / 1000).toFixed(0)}k Credits</p>
              <span className="text-[10px] text-slate-400">Direct agency reserve deposit</span>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default SyntheticMediaStudio;
