/**
 * @file verifyBrandCreatorAccess.ts
 * @description Audit utility verifying that Firestore security rules and API boundaries
 * prevent the 'brand' role from accessing sensitive Creator PII (email, phone, address, tax/payment data).
 * 
 * Verifies:
 * 1. Firestore Security Rules: 'brand' role is DENIED direct read access to `studio-creators`.
 * 2. Discovery API Redaction: Returned dataset objects for brands contain 0 sensitive PII keys.
 * 3. Schema Compliance: Only non-sensitive performance metrics (followers, engagement, reach, velocity) are exposed.
 */

export interface AuditUserContext {
  uid: string;
  role: string;
  email?: string;
  subagency?: string;
  tenantId?: string;
  isPlatformOwner?: boolean;
  name?: string;
  handle?: string;
}

export interface CreatorDoc {
  id: string;
  name: string;
  handle: string;
  email?: string;
  phone?: string;
  address?: string;
  ssn?: string;
  taxId?: string;
  paymentDetails?: string;
  paymentMethod?: string;
  paymentNote?: string;
  stripeCardId?: string;
  stripeCardholderId?: string;
  subagency?: string;
  platform?: string;
  niche?: string;
  followers?: string;
  eng?: string;
  totalReach?: string;
  engagementRate?: string;
  avgVelocity?: string;
  status?: string;
  matchOrPassPrimaryPhoto?: string;
  avatar?: string;
  [key: string]: any;
}

/**
 * List of sensitive PII & financial/contract fields that MUST NEVER be present
 * in dataset objects delivered to brand-role sessions.
 */
export const SENSITIVE_PII_KEYS = [
  'email',
  'phone',
  'phoneNumber',
  'address',
  'streetAddress',
  'zipCode',
  'ssn',
  'taxId',
  'paymentDetails',
  'paymentMethod',
  'paymentNote',
  'stripeCardId',
  'stripeCardholderId',
  'contractId',
  'agreement',
  'exclusivityScope'
];

/**
 * Simulated Firestore Rule Engine evaluation for `studio-creators`
 * Replicating `firestore.rules` logic:
 * match /studio-creators/{docId} {
 *   allow read: if canManageExisting(resource.data) || (isStaff() && samePod(resource.data)) ||
 *     (isCreator() && (resource.data.id == request.auth.uid || ...));
 * }
 */
export function evaluateCreatorReadRule(user: AuditUserContext | null, creatorDoc: CreatorDoc): {
  allowed: boolean;
  reason: string;
} {
  if (!user) {
    return { allowed: false, reason: 'Unauthenticated read rejected (Default Deny)' };
  }

  const role = (user.role || '').toLowerCase();
  const userPod = user.subagency || user.tenantId || 'pod_main';
  const docPod = creatorDoc.subagency || creatorDoc.tenantId || 'pod_main';

  // 1. Platform Owner Bypass
  if (user.isPlatformOwner && (role === 'director' || role === 'owner' || role === 'agency')) {
    return { allowed: true, reason: 'Platform Owner cross-tenant read granted' };
  }

  // 2. Sub-Agency Director (In-Pod Management)
  if ((role === 'director' || role === 'owner' || role === 'agency') && userPod === docPod) {
    return { allowed: true, reason: 'Sub-Agency Director same-pod read granted' };
  }

  // 3. Agency Staff / Managers (In-Pod Staff)
  if ((role === 'agentmgr' || role === 'manager' || role === 'agent' || role === 'coordinator') && userPod === docPod) {
    return { allowed: true, reason: 'Staff same-pod read granted' };
  }

  // 4. Creator Self-Read
  if (role === 'creator' && (creatorDoc.id === user.uid || creatorDoc.handle === user.handle)) {
    return { allowed: true, reason: 'Creator self-profile read granted' };
  }

  // 5. Brand Role Check (Explicitly Denied in firestore.rules for studio-creators)
  if (role === 'brand' || role === 'client') {
    return { allowed: false, reason: 'Brand role explicitly DENIED direct read on studio-creators (Anti-Poaching Boundary)' };
  }

  return { allowed: false, reason: 'No matching read rule rule rule (Default Deny)' };
}

/**
 * Audit a dataset object to ensure NO sensitive PII keys are present.
 */
export function auditDatasetObjectForPII(obj: Record<string, any>): {
  hasPII: boolean;
  leakedKeys: string[];
} {
  const leakedKeys: string[] = [];

  for (const key of SENSITIVE_PII_KEYS) {
    if (Object.prototype.hasOwnProperty.call(obj, key) && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') {
      leakedKeys.push(key);
    }
  }

  return {
    hasPII: leakedKeys.length > 0,
    leakedKeys
  };
}

/**
 * Generates the frame-ancestors CSP header value based on request host and protocol.
 * Used to verify Finding #63 mitigation (eliminating wildcard matches like *.run.app and *.google.com).
 */
export function buildFrameAncestorsDirective(host?: string, isHttps = true): string {
  const protocol = isHttps ? "https" : "http";
  const selfOrigin = host ? `${protocol}://${host}` : "";

  const allowedAncestors = ["'self'", "https://ai.studio", "https://aistudio.google.com"];
  if (selfOrigin && !allowedAncestors.includes(selfOrigin)) {
    allowedAncestors.push(selfOrigin);
  }

  return `frame-ancestors ${allowedAncestors.join(" ")};`;
}

/**
 * Anonymizer function replicating `/api/creators/public-discovery` server-side logic
 */
export function anonymizeCreatorForBrandDiscovery(creator: CreatorDoc, index: number): Record<string, any> {
  const creatorNum = 100 + index;
  return {
    id: creator.id,
    creatorNumber: creatorNum,
    name: `Creator #${creatorNum}`,
    handle: `Creator #${creatorNum}`,
    avatar: creator.matchOrPassPrimaryPhoto || creator.avatar || "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=800&auto=format&fit=crop&q=80",
    platform: creator.platform || "Social Media",
    niche: creator.niche || "Lifestyle",
    bio: creator.bio || "Agency represented creator.",
    followers: creator.followers || "1M+",
    eng: creator.eng || "5%",
    totalReach: creator.totalReach || creator.followers || "1M+",
    engagementRate: creator.engagementRate || creator.eng || "5%",
    avgVelocity: creator.avgVelocity || "100K",
    followerCount: creator.followerCount || 1000000,
    location: creator.location || "United States",
    status: creator.status || "Active",
    subagency: creator.subagency || "pod_main"
  };
}

/**
 * Run the comprehensive Brand Creator Access & PII Audit
 */
export function runBrandCreatorPIIAudit(): { passed: boolean; totalTests: number; passedTests: number } {
  console.log('======================================================================');
  console.log('🔒 BLOOM STUDIO BRAND ROLE & CREATOR PII SECURITY AUDIT');
  console.log('======================================================================\n');

  let totalTests = 0;
  let passedTests = 0;

  function assert(condition: boolean, message: string) {
    totalTests++;
    if (condition) {
      passedTests++;
      console.log(`\x1b[32m✔ PASS: ${message}\x1b[0m`);
    } else {
      console.error(`\x1b[31m❌ FAIL: ${message}\x1b[0m`);
    }
  }

  // Sample Raw Creator Document with full PII
  const mockRawCreator: CreatorDoc = {
    id: 'creator_101',
    name: 'Sarah Connor',
    handle: '@sarah_beauty',
    email: 'sarah.connor@example.com',
    phone: '+1 (555) 234-5678',
    address: '742 Evergreen Terrace, Springfield, OR',
    ssn: 'XXX-XX-9876',
    taxId: 'XX-XXX1234',
    paymentDetails: 'Direct Deposit Account #987654321',
    paymentMethod: 'Agency Debit Card',
    paymentNote: 'Wire to Chase Bank',
    stripeCardId: 'ic_1N923847293847',
    stripeCardholderId: 'ich_1N923847293847',
    contractId: 'contract_2026_sc',
    agreement: 'Exclusive (80%)',
    exclusivityScope: 'Full Commercial & UGC',
    subagency: 'pod_a',
    platform: 'Instagram',
    niche: 'Beauty & Skincare',
    followers: '1.2M',
    eng: '4.8%',
    totalReach: '1.2M',
    engagementRate: '4.8%',
    avgVelocity: '120K',
    followerCount: 1200000,
    location: 'Los Angeles, CA',
    status: 'Active'
  };

  const brandUser: AuditUserContext = {
    uid: 'brand_user_01',
    role: 'brand',
    email: 'brand@nike.com',
    subagency: 'pod_a',
    name: 'Nike Marketing Team'
  };

  const directorUser: AuditUserContext = {
    uid: 'dir_user_01',
    role: 'director',
    email: 'director@bloom.co',
    subagency: 'pod_a',
    name: 'Director Alex'
  };

  const staffUser: AuditUserContext = {
    uid: 'staff_user_01',
    role: 'agentmgr',
    email: 'manager@bloom.co',
    subagency: 'pod_a',
    name: 'Manager Sam'
  };

  const creatorUser: AuditUserContext = {
    uid: 'creator_101',
    role: 'creator',
    email: 'sarah.connor@example.com',
    handle: '@sarah_beauty',
    subagency: 'pod_a'
  };

  // --- TEST GROUP 1: Direct Firestore Rules Access Controls ---
  console.log('--- TEST GROUP 1: Firestore Security Rules Direct Access Controls ---');
  
  const brandRead = evaluateCreatorReadRule(brandUser, mockRawCreator);
  assert(!brandRead.allowed, `Brand role direct read on studio-creators is REJECTED (${brandRead.reason})`);

  const directorRead = evaluateCreatorReadRule(directorUser, mockRawCreator);
  assert(directorRead.allowed, `Director same-pod read on studio-creators is ALLOWED (${directorRead.reason})`);

  const staffRead = evaluateCreatorReadRule(staffUser, mockRawCreator);
  assert(staffRead.allowed, `Staff same-pod read on studio-creators is ALLOWED (${staffRead.reason})`);

  const creatorSelfRead = evaluateCreatorReadRule(creatorUser, mockRawCreator);
  assert(creatorSelfRead.allowed, `Creator self-profile read on studio-creators is ALLOWED (${creatorSelfRead.reason})`);

  const crossPodBrandUser: AuditUserContext = { ...brandUser, subagency: 'pod_b' };
  const crossPodRead = evaluateCreatorReadRule(crossPodBrandUser, mockRawCreator);
  assert(!crossPodRead.allowed, `Cross-pod Brand direct read on studio-creators is REJECTED (${crossPodRead.reason})`);

  // --- TEST GROUP 2: Dataset Object PII Audit on Raw Document ---
  console.log('\n--- TEST GROUP 2: Dataset Object PII Audit (Raw vs Anonymized Objects) ---');

  const rawAudit = auditDatasetObjectForPII(mockRawCreator);
  assert(rawAudit.hasPII, `Raw Creator Document contains sensitive PII keys (${rawAudit.leakedKeys.join(', ')})`);

  const anonymizedObj = anonymizeCreatorForBrandDiscovery(mockRawCreator, 1);
  const anonymizedAudit = auditDatasetObjectForPII(anonymizedObj);
  assert(!anonymizedAudit.hasPII, `Anonymized Brand Discovery Object has 0 sensitive PII keys`);

  // --- TEST GROUP 3: Field-by-Field Anonymization Verification ---
  console.log('\n--- TEST GROUP 3: Field-by-Field Anonymization & Metric Verification ---');

  assert(anonymizedObj.name === 'Creator #101', `Real Name 'Sarah Connor' redacted to 'Creator #101'`);
  assert(anonymizedObj.handle === 'Creator #101', `Real Handle '@sarah_beauty' redacted to 'Creator #101'`);
  assert(anonymizedObj.email === undefined, `Email field is completely removed/undefined`);
  assert(anonymizedObj.phone === undefined, `Phone field is completely removed/undefined`);
  assert(anonymizedObj.address === undefined, `Address field is completely removed/undefined`);
  assert(anonymizedObj.ssn === undefined, `SSN field is completely removed/undefined`);
  assert(anonymizedObj.paymentDetails === undefined, `Payment Details field is completely removed/undefined`);
  assert(anonymizedObj.followers === '1.2M', `Non-sensitive Followers metric preserved ('1.2M')`);
  assert(anonymizedObj.eng === '4.8%', `Non-sensitive Engagement Rate metric preserved ('4.8%')`);
  assert(anonymizedObj.niche === 'Beauty & Skincare', `Niche metric preserved ('Beauty & Skincare')`);

  // --- TEST GROUP 4: CSP frame-ancestors Clickjacking Defense Verification (Finding #63) ---
  console.log('\n--- TEST GROUP 4: CSP frame-ancestors Clickjacking Defense Verification ---');

  const testHost = 'bloom-studio-app-4wahptpbcjyuhfekwf33uj-209610047898.us-west1.run.app';
  const cspHeader = buildFrameAncestorsDirective(testHost, true);

  assert(!cspHeader.includes('*.run.app'), `CSP header DOES NOT contain wildcard '*.run.app'`);
  assert(!cspHeader.includes('*.google.com'), `CSP header DOES NOT contain wildcard '*.google.com'`);
  assert(cspHeader.includes("frame-ancestors 'self' https://ai.studio https://aistudio.google.com"), `CSP header includes explicit trusted origins ('self', https://ai.studio, https://aistudio.google.com)`);
  assert(cspHeader.includes(`https://${testHost}`), `CSP header includes specific host origin ('https://${testHost}')`);

  console.log('\n======================================================================');
  console.log(`AUDIT SUMMARY: ${passedTests}/${totalTests} Security Assertions Passed`);
  console.log('======================================================================\n');

  return {
    passed: passedTests === totalTests,
    totalTests,
    passedTests
  };
}

// Auto-run if executed directly via CLI/tsx
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('verifyBrandCreatorAccess')) {
  const result = runBrandCreatorPIIAudit();
  if (!result.passed) {
    process.exit(1);
  }
}
