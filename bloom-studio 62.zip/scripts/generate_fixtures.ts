import fs from 'fs';
import path from 'path';
import { fillOfficialIrsW9Pdf, generateOfficial1099NecPdf } from '../src/lib/w9PdfGenerator';

async function generateFixtures() {
  const fixturesDir = path.join(process.cwd(), 'tests', 'fixtures');
  if (!fs.existsSync(fixturesDir)) {
    fs.mkdirSync(fixturesDir, { recursive: true });
  }

  // 1. Generate official_filled_w9_test.pdf
  const w9Result1 = await fillOfficialIrsW9Pdf({
    legalName: 'Elena Rostova',
    businessName: 'Rostova Media LLC',
    taxClassification: 'LLC',
    llcTaxClassification: 'S',
    address: '742 Evergreen Terrace',
    cityStateZip: 'Springfield, OR 97477',
    tinType: 'EIN',
    tinNumber: '12-3456789',
    signatureName: 'Elena Rostova',
    dateSigned: '2026-09-08',
    creatorHandle: '@elenarostova',
    auditHash: 'W9-AUDIT-9821034'
  });
  fs.writeFileSync(path.join(fixturesDir, 'official_filled_w9_test.pdf'), Buffer.from(w9Result1.pdfBytes));
  console.log('Generated official_filled_w9_test.pdf:', w9Result1.pdfBytes.byteLength, 'bytes');

  // 2. Generate test_filled.pdf
  const w9Result2 = await fillOfficialIrsW9Pdf({
    legalName: 'Alexander Jones',
    businessName: 'Alex Jones Creative Studio',
    taxClassification: 'Individual/sole proprietor',
    address: '100 Sunset Blvd, Suite 400',
    cityStateZip: 'Los Angeles, CA 90028',
    tinType: 'SSN',
    tinNumber: '123-45-6789',
    signatureName: 'Alexander Jones',
    dateSigned: '2026-09-08',
    creatorHandle: '@alexjones',
    auditHash: 'W9-AUDIT-1029384'
  });
  fs.writeFileSync(path.join(fixturesDir, 'test_filled.pdf'), Buffer.from(w9Result2.pdfBytes));
  console.log('Generated test_filled.pdf:', w9Result2.pdfBytes.byteLength, 'bytes');

  // 3. Generate test_generated_1099.pdf
  const result1099 = await generateOfficial1099NecPdf({
    payerName: 'Bloom Studio Inc.',
    payerTin: '98-7654321',
    payerAddress: '500 Howard St, Floor 5',
    payerCityStateZip: 'San Francisco, CA 94105',
    recipientName: 'Elena Rostova',
    recipientHandle: '@elenarostova',
    recipientTin: '12-3456789',
    recipientAddress: '742 Evergreen Terrace',
    recipientCityStateZip: 'Springfield, OR 97477',
    nonemployeeCompensation: 48500.00,
    federalTaxWithheld: 0.00,
    taxYear: 2026
  });
  fs.writeFileSync(path.join(fixturesDir, 'test_generated_1099.pdf'), Buffer.from(result1099.pdfBytes));
  console.log('Generated test_generated_1099.pdf:', result1099.pdfBytes.byteLength, 'bytes');
}

generateFixtures().catch(err => {
  console.error('Failed to generate fixtures:', err);
  process.exit(1);
});
