const fs = require('fs');
let content = fs.readFileSync('src/components/BrandPortalDashboard.tsx', 'utf8');

// Remove Review Console Button
content = content.replace(/<button\s+type="button"\s+onClick=\{\(\) => setActiveTab\('review'\)\}[\s\S]*?<\/button>/, '');

// Remove Financials & Escrow Button
content = content.replace(/<button\s+type="button"\s+onClick=\{\(\) => setActiveTab\('invoices'\)\}[\s\S]*?<\/button>/, '');

// Remove Review Console Content
content = content.replace(/\{\/\* Tab Content 1: Review Console \*\/\}\s*\{activeTab === 'review' && \([\s\S]*?\}\)\}/, '');

// Remove Financials & Escrow Content
content = content.replace(/\{\/\* Tab Content 4: Financials & Escrow \*\/\}\s*\{activeTab === 'invoices' && \([\s\S]*?\}\)\}/, '');

fs.writeFileSync('src/components/BrandPortalDashboard.tsx', content);
