with open("src/components/OperationBoard.tsx", "r") as f:
    lines = f.readlines()

start_idx = -1
end_idx = -1

for i, line in enumerate(lines):
    if "case 'production-calendar':" in line:
        start_idx = i
        break

for i in range(start_idx, len(lines)):
    if "case 'crisis-log':" in lines[i]:
        end_idx = i
        break

replacement = """      case 'unified-calendar':
      case 'production-calendar':
      case 'calendar-avail':
      case 'availability-calendar':
      case 'calendar':
        return (
          <UnifiedCalendarHub
            agencySchedules={agencySchedules}
            setAgencySchedules={setAgencySchedules}
            creators={creators}
            deals={deals}
            currentRole={currentRole}
            currentUser={currentUser}
            defaultTab={activeScreen.includes('avail') ? 'availability' : 'production'}
            onAddActivityLog={(u, r, a) => onAddActivityLog && onAddActivityLog(u, r, a)}
            triggerNotification={(t, d, typ) => triggerNotification && triggerNotification(t, d, typ || 'info')}
            primaryBrandColor={primaryBrandColor}
            cardBgColor={cardBgColor}
            onNavigateToScreen={(screenId) => setActiveScreen && setActiveScreen(screenId)}
            myHandles={myHandles}
          />
        );

"""

new_lines = lines[:start_idx] + [replacement] + lines[end_idx:]

with open("src/components/OperationBoard.tsx", "w") as f:
    f.writelines(new_lines)
