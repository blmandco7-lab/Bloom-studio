# Project Security Guidelines & Standing Rules

## Multi-Tenant Isolation & Partitioning
- **Rule**: Access to cross-tenant data (reads across the entire collection without a `tenantId` or `subagency` filter) is strictly restricted to the **Platform Owner**.
- **Role Boundary**: The `staff` role (including `director`, `agentmgr`, `agent`, `coordinator`) is always scoped to their own pod/tenant.
- **Middleware Enforcement**: 
    - Use `requirePlatformOwner` for any endpoint that needs to read data across all tenants (e.g., master financial ledger, global audit tools).
    - Use `requireStaff` for pod-scoped operations, ensuring that the database query explicitly includes a `.where("tenantId", "==", callerPod)` or similar filter.
- **Verification Routine**: Before shipping new features or modifications to the Express layer:
    - Grep for `isStaff()` or `requireStaff`.
    - Verify that any subsequent `Admin SDK` reads (e.g., `db.collection(...).get()`) are either document-specific (by ID) or explicitly filtered by the user's pod/tenant.
    - Any unscoped `.get()` or `.where(...)` without tenant isolation must be guarded by `requirePlatformOwner`.

## Firestore Rules Consistency
- Ensure `firestore.rules` logic mirrors the server-side isolation.
- Only `isPlatformOwner()` (verified via `platform-owners` collection or superuser email) should have top-level `{document=**}` read/write access.
- Any `isDirector()` or `isStaff()` check must be combined with `samePod(data)` or similar scoping functions.

## Secrets, Tokens & Credential Safety
- **Rule**: Never hardcode secrets, fixed passwords, fallback PINs, or static signing keys in the codebase.
- **Environment Driven**: Load all sensitive keys and webhook secrets from `process.env` (documented in `.env.example`).
- **Runtime Generation**: Any temporary session tokens or OTPs must be generated using cryptographically secure random entropy (e.g., `crypto.randomBytes`) rather than predictable pseudorandom strings.

## Canonical Helper & Sanitizer Reuse
- **Rule**: Never create ad-hoc reimplementations of security-critical routines or sanitization logic.
- **Established Utilities**:
    - Use `src/utils/security.ts` for CSV formula neutralization, URL sanitization (`getSafeUrl`), and XSS/input scrubbing.
    - Use `src/utils/safeStorage.ts` for sandboxed iframe-safe web storage access with memory fallbacks.
    - Use `src/lib/cryptoSignatures.ts` and `src/utils/cryptoUtils.ts` for SHA-256 digital signature digests and verification.

